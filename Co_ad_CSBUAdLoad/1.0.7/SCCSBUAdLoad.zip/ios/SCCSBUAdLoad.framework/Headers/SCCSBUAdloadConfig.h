//
//  SCCSBUAdloadConfig.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BUAdSDK/BUAdSDK.h>
#import "SCCSBUConfigModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SCCSBUAdloadConfig : NSObject

@property (nonatomic, strong, readonly) NSMutableArray<SCCSBUConfigModel *> *configs;

+ (instancetype)sharedInstance;
// MARK: - 激励视频展示配置 必须配置

+ (void)setRewardConfigWithMoudleId:(NSString *)modudleID userID:(NSString *)userID;

+ (void)setRewardConfigWithMoudleId:(NSString *)modudleID userID:(NSString *)userID ritScene:(BURitSceneType)ritScene ritSceneDescribe:(NSString * _Nullable)ritSceneDescribe;

// MARK: -  插屏配置 必需配置
+ (void)setInterstitialConfigWithMoudleId:(NSString *)modudleID adSize:(CGSize)adSize;

// MARK: - 插屏视频配置 可选配置
+ (void)setInterstitialVideoConfigWithMoudleId:(NSString *)modudleID ritSceneDescribe:(NSString * _Nullable)ritSceneDescribe;

@end

NS_ASSUME_NONNULL_END
