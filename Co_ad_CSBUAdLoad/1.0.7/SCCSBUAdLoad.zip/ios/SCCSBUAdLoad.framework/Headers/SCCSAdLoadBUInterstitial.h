//
//  SCCSAdLoadBUInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SCCSAdSDK/SCCSAdLoadInterstitial.h>
#import <SCCSAdSDK/SCCSAdLoadProtocol.h>
#import <SCCSAdSDK/SCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface SCCSAdLoadBUInterstitial : SCCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,SCCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
