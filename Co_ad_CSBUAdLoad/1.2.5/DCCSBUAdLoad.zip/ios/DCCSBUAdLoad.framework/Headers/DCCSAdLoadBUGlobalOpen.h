//
//  DCCSAdLoadBUGlobalOpen.h
//  DCCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <DCCSAdSDK/DCCSAdLoadOpen.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadBUGlobalOpen : DCCSAdLoadOpen<DCCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
