//
//  FRCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <FRCSAdSDK/FRCSAdLoadOpen.h>
#import <FRCSAdSDK/FRCSAdLoadProtocol.h>
#import <FRCSAdSDK/FRCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
#import <BUAdSDK/BUSplashAdView.h>

NS_ASSUME_NONNULL_BEGIN

@interface FRCSAdLoadBUOpen : FRCSAdLoadOpen<BUSplashAdDelegate,BUSplashZoomOutViewDelegate,FRCSAdLoadProtocol>

@property(nonatomic, strong) BUSplashAdView *ad;


@end

NS_ASSUME_NONNULL_END
