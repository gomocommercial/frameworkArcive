//
//  DCCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <DCCSAdSDK/DCCSAdLoadReward.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadBUReward : DCCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,DCCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
