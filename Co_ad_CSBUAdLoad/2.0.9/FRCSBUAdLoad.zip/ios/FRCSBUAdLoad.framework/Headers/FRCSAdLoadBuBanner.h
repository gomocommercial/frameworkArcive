//
//  FRCSAdLoadBuBanner.h
//  FRCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <FRCSAdSDK/FRCSAdLoadProtocol.h>
#import <FRCSAdSDK/FRCSAdLoadBanner.h>
#import <FRCSAdSDK/FRCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface FRCSAdLoadBuBanner : FRCSAdLoadBanner <BUNativeExpressBannerViewDelegate,FRCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

