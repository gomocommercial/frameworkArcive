//
//  PSCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <PSCSAdSDK/PSCSAdLoadOpen.h>
#import <PSCSAdSDK/PSCSAdLoadProtocol.h>
#import <PSCSAdSDK/PSCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSCSAdLoadBUOpen : PSCSAdLoadOpen<PSCSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
