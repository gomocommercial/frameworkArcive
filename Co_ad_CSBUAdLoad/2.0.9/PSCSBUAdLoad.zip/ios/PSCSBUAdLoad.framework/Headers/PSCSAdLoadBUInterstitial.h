////
////  PSCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <PSCSAdSDK/PSCSAdLoadInterstitial.h>
//#import <PSCSAdSDK/PSCSAdLoadProtocol.h>
//#import <PSCSAdSDK/PSCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface PSCSAdLoadBUInterstitial : PSCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,PSCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
