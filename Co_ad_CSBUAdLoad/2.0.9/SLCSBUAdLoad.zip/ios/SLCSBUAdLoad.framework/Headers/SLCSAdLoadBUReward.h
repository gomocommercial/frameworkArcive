//
//  SLCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SLCSAdSDK/SLCSAdLoadReward.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadBUReward : SLCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,SLCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
