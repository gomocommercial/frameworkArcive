//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <BCCSAdSDK/BCCSAdLoadInterstitial.h>
#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN
//TODO: 暂不使用
@interface BCCSAdLoadBUInterstitialVideo : BCCSAdLoadInterstitial<BUFullscreenVideoAdDelegate,BCCSAdLoadProtocol>
@property(nonatomic, strong) BUFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
