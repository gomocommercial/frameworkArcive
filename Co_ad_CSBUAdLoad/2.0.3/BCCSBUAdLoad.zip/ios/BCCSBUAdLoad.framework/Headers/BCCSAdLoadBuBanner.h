//
//  BCCSAdLoadBuBanner.h
//  BCCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadBanner.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface BCCSAdLoadBuBanner : BCCSAdLoadBanner <BUNativeExpressBannerViewDelegate,BCCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

