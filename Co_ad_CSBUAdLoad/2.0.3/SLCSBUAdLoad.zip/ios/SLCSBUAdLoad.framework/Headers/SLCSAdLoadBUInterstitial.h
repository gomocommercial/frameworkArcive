////
////  SLCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <SLCSAdSDK/SLCSAdLoadInterstitial.h>
//#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
//#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface SLCSAdLoadBUInterstitial : SLCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,SLCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
