//
//  BCCSAdLoadBUGlobalOpen.h
//  BCCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <BCCSAdSDK/BCCSAdLoadOpen.h>
#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface BCCSAdLoadBUGlobalOpen : BCCSAdLoadOpen<BCCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
