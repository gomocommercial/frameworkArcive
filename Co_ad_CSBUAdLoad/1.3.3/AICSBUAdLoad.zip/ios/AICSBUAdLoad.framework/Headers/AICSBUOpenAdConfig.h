//
//  AICSBUOpenAdConfig.h
//  AICSBUAdLoad
//
//  Created by qiaoming on 2020/12/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AICSBUOpenAdConfig : NSObject

/**
 Maximum allowable load timeout, default 3s, unit s.
 */
@property (nonatomic, assign) NSTimeInterval tolerateTimeout;


/**
 Whether hide skip button, default NO.
 If you hide the skip button, you need to customize the countdown.
 */
@property (nonatomic, assign) BOOL hideSkipButton;

///optional: Whether need splashZoomOutAd, default NO.
@property (nonatomic, assign) BOOL needSplashZoomOutAd;
@property (nonatomic, assign) BOOL needSplashCardViewAd;
//广告显示的位置大小 默认全屏显示
@property (nonatomic, assign) CGRect frame;

+ (instancetype)sharedInstance;

@end

NS_ASSUME_NONNULL_END
