//
//  AICSAdLoadBuBanner.h
//  AICSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <AICSAdSDK/AICSAdLoadProtocol.h>
#import <AICSAdSDK/AICSAdLoadBanner.h>
#import <AICSAdSDK/AICSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface AICSAdLoadBuBanner : AICSAdLoadBanner <BUNativeExpressBannerViewDelegate,AICSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

