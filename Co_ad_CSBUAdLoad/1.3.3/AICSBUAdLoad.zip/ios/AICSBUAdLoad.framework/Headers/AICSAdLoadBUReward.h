//
//  AICSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AICSAdSDK/AICSAdLoadReward.h>
#import <AICSAdSDK/AICSAdLoadProtocol.h>
#import <AICSAdSDK/AICSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AICSAdLoadBUReward : AICSAdLoadReward<BURewardedVideoAdDelegate,AICSAdLoadProtocol>

@property(nonatomic, strong) BURewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
