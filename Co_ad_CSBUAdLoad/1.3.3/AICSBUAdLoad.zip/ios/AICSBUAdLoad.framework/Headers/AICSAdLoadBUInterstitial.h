////
////  AICSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <AICSAdSDK/AICSAdLoadInterstitial.h>
//#import <AICSAdSDK/AICSAdLoadProtocol.h>
//#import <AICSAdSDK/AICSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface AICSAdLoadBUInterstitial : AICSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,AICSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
