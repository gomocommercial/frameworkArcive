//
//  AICSAdLoadBUGlobalOpen.h
//  AICSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <AICSAdSDK/AICSAdLoadOpen.h>
#import <AICSAdSDK/AICSAdLoadProtocol.h>
#import <AICSAdSDK/AICSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AICSAdLoadBUGlobalOpen : AICSAdLoadOpen<AICSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
