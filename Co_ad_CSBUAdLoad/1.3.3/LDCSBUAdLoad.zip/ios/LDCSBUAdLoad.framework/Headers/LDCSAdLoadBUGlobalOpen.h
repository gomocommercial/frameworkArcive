//
//  LDCSAdLoadBUGlobalOpen.h
//  LDCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <LDCSAdSDK/LDCSAdLoadOpen.h>
#import <LDCSAdSDK/LDCSAdLoadProtocol.h>
#import <LDCSAdSDK/LDCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface LDCSAdLoadBUGlobalOpen : LDCSAdLoadOpen<LDCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
