//
//  RVCSAdLoadBUGlobalOpen.h
//  RVCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <RVCSAdSDK/RVCSAdLoadOpen.h>
#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface RVCSAdLoadBUGlobalOpen : RVCSAdLoadOpen<RVCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
