//
//  Co_ad_CSAdLoadBUInterstitialVideo.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadInterstitial.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadProtocol.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdLoadBUExpressInterstitialVideo : Co_ad_CSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,Co_ad_CSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
