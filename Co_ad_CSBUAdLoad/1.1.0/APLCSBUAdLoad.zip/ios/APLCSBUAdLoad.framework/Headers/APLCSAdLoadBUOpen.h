//
//  APLCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <APLCSAdSDK/APLCSAdLoadOpen.h>
#import <APLCSAdSDK/APLCSAdLoadProtocol.h>
#import <APLCSAdSDK/APLCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
#import <BUAdSDK/BUSplashAdView.h>

NS_ASSUME_NONNULL_BEGIN

@interface APLCSAdLoadBUOpen : APLCSAdLoadOpen<BUSplashAdDelegate,BUSplashZoomOutViewDelegate,APLCSAdLoadProtocol>

@property(nonatomic, strong) BUSplashAdView *ad;


@end

NS_ASSUME_NONNULL_END
