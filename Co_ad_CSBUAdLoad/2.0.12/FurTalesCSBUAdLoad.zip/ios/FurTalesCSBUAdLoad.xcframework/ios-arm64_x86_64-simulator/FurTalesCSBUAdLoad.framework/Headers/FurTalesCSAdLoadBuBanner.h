//
//  FurTalesCSAdLoadBuBanner.h
//  FurTalesCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <FurTalesCSAdSDK/FurTalesCSAdLoadProtocol.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadBanner.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface FurTalesCSAdLoadBuBanner : FurTalesCSAdLoadBanner <BUNativeExpressBannerViewDelegate,FurTalesCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

