//
//  FurTalesCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FurTalesCSAdSDK/FurTalesCSAdLoadReward.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadProtocol.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdLoadBUReward : FurTalesCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,FurTalesCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
