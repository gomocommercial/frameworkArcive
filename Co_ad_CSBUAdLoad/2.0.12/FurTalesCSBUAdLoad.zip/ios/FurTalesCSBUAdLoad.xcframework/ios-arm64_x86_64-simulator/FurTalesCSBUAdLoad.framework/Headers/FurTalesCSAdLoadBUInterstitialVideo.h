//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FurTalesCSAdSDK/FurTalesCSAdLoadInterstitial.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadProtocol.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdLoadBUInterstitialVideo : FurTalesCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,FurTalesCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
