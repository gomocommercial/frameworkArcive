//
//  NDCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <NDCSAdSDK/NDCSAdLoadOpen.h>
#import <NDCSAdSDK/NDCSAdLoadProtocol.h>
#import <NDCSAdSDK/NDCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface NDCSAdLoadBUOpen : NDCSAdLoadOpen<NDCSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
