//
//  NDCSAdLoadBuBanner.h
//  NDCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <NDCSAdSDK/NDCSAdLoadProtocol.h>
#import <NDCSAdSDK/NDCSAdLoadBanner.h>
#import <NDCSAdSDK/NDCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface NDCSAdLoadBuBanner : NDCSAdLoadBanner <BUNativeExpressBannerViewDelegate,NDCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

