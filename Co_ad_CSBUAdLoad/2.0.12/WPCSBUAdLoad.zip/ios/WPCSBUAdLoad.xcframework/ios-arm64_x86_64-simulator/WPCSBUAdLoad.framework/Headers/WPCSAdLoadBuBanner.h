//
//  WPCSAdLoadBuBanner.h
//  WPCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <WPCSAdSDK/WPCSAdLoadProtocol.h>
#import <WPCSAdSDK/WPCSAdLoadBanner.h>
#import <WPCSAdSDK/WPCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface WPCSAdLoadBuBanner : WPCSAdLoadBanner <BUNativeExpressBannerViewDelegate,WPCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

