//
//  FSLPCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FSLPCSAdSDK/FSLPCSAdLoadReward.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadProtocol.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadBUExpressReward : FSLPCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,FSLPCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
