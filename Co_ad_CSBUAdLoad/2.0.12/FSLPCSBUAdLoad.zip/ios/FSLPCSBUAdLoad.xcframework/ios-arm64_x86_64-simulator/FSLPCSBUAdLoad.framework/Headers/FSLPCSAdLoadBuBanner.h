//
//  FSLPCSAdLoadBuBanner.h
//  FSLPCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <FSLPCSAdSDK/FSLPCSAdLoadProtocol.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadBanner.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface FSLPCSAdLoadBuBanner : FSLPCSAdLoadBanner <BUNativeExpressBannerViewDelegate,FSLPCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

