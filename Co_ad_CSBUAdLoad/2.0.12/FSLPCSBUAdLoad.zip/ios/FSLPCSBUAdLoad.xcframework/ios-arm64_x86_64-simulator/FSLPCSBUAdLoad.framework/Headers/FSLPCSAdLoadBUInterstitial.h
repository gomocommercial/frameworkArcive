////
////  FSLPCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <FSLPCSAdSDK/FSLPCSAdLoadInterstitial.h>
//#import <FSLPCSAdSDK/FSLPCSAdLoadProtocol.h>
//#import <FSLPCSAdSDK/FSLPCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface FSLPCSAdLoadBUInterstitial : FSLPCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,FSLPCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
