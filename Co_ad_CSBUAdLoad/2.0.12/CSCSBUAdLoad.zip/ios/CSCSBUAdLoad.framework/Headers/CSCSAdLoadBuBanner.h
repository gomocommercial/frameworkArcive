//
//  CSCSAdLoadBuBanner.h
//  CSCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadBanner.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface CSCSAdLoadBuBanner : CSCSAdLoadBanner <BUNativeExpressBannerViewDelegate,CSCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

