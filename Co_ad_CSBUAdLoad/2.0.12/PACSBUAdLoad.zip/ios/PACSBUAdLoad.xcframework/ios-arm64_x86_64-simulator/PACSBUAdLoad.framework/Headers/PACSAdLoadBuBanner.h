//
//  PACSAdLoadBuBanner.h
//  PACSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <PACSAdSDK/PACSAdLoadProtocol.h>
#import <PACSAdSDK/PACSAdLoadBanner.h>
#import <PACSAdSDK/PACSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface PACSAdLoadBuBanner : PACSAdLoadBanner <BUNativeExpressBannerViewDelegate,PACSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

