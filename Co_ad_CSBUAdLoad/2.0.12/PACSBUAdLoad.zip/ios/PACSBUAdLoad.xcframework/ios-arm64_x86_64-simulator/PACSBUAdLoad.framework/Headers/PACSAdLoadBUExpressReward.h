//
//  PACSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PACSAdSDK/PACSAdLoadReward.h>
#import <PACSAdSDK/PACSAdLoadProtocol.h>
#import <PACSAdSDK/PACSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PACSAdLoadBUExpressReward : PACSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,PACSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
