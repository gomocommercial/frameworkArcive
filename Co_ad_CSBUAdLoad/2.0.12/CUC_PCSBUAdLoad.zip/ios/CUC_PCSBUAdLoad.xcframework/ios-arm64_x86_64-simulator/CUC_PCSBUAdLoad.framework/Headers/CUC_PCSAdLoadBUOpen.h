//
//  CUC_PCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <CUC_PCSAdSDK/CUC_PCSAdLoadOpen.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadBUOpen : CUC_PCSAdLoadOpen<CUC_PCSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
