//
//  CUC_PCSAdLoadBuBanner.h
//  CUC_PCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadBanner.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface CUC_PCSAdLoadBuBanner : CUC_PCSAdLoadBanner <BUNativeExpressBannerViewDelegate,CUC_PCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

