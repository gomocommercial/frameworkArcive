//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadInterstitial.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadBUInterstitialVideo : CUC_PCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,CUC_PCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
