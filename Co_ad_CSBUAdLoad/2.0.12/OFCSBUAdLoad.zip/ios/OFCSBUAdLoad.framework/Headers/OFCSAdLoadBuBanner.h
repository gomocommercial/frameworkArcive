//
//  OFCSAdLoadBuBanner.h
//  OFCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <OFCSAdSDK/OFCSAdLoadProtocol.h>
#import <OFCSAdSDK/OFCSAdLoadBanner.h>
#import <OFCSAdSDK/OFCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface OFCSAdLoadBuBanner : OFCSAdLoadBanner <BUNativeExpressBannerViewDelegate,OFCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

