//
//  CFCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <CFCSAdSDK/CFCSAdLoadOpen.h>
#import <CFCSAdSDK/CFCSAdLoadProtocol.h>
#import <CFCSAdSDK/CFCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCSAdLoadBUOpen : CFCSAdLoadOpen<CFCSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
