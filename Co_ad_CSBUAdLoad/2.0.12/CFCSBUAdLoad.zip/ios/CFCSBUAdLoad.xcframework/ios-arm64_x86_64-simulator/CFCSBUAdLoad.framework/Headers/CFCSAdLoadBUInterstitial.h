////
////  CFCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <CFCSAdSDK/CFCSAdLoadInterstitial.h>
//#import <CFCSAdSDK/CFCSAdLoadProtocol.h>
//#import <CFCSAdSDK/CFCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface CFCSAdLoadBUInterstitial : CFCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,CFCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
