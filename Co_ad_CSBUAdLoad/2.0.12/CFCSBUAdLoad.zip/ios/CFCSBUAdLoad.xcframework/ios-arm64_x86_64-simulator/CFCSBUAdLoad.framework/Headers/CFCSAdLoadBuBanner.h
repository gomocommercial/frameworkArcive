//
//  CFCSAdLoadBuBanner.h
//  CFCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <CFCSAdSDK/CFCSAdLoadProtocol.h>
#import <CFCSAdSDK/CFCSAdLoadBanner.h>
#import <CFCSAdSDK/CFCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface CFCSAdLoadBuBanner : CFCSAdLoadBanner <BUNativeExpressBannerViewDelegate,CFCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

