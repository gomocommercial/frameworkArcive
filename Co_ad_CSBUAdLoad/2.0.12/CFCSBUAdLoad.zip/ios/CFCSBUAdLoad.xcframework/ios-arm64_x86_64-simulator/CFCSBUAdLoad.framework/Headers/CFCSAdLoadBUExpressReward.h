//
//  CFCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CFCSAdSDK/CFCSAdLoadReward.h>
#import <CFCSAdSDK/CFCSAdLoadProtocol.h>
#import <CFCSAdSDK/CFCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCSAdLoadBUExpressReward : CFCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,CFCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
