////
////  WACSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <WACSAdSDK/WACSAdLoadInterstitial.h>
//#import <WACSAdSDK/WACSAdLoadProtocol.h>
//#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface WACSAdLoadBUInterstitial : WACSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,WACSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
