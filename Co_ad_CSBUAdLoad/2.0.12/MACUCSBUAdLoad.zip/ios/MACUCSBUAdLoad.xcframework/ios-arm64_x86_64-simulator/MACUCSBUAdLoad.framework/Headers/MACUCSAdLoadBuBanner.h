//
//  MACUCSAdLoadBuBanner.h
//  MACUCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <MACUCSAdSDK/MACUCSAdLoadProtocol.h>
#import <MACUCSAdSDK/MACUCSAdLoadBanner.h>
#import <MACUCSAdSDK/MACUCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface MACUCSAdLoadBuBanner : MACUCSAdLoadBanner <BUNativeExpressBannerViewDelegate,MACUCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

