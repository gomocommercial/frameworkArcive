//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CSAdSDK/CSAdLoadInterstitial.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadBUExpressInterstitialVideo : CSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,CSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
