//
//  VPCSAdLoadBuBanner.h
//  VPCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <VPCSAdSDK/VPCSAdLoadProtocol.h>
#import <VPCSAdSDK/VPCSAdLoadBanner.h>
#import <VPCSAdSDK/VPCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface VPCSAdLoadBuBanner : VPCSAdLoadBanner <BUNativeExpressBannerViewDelegate,VPCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

