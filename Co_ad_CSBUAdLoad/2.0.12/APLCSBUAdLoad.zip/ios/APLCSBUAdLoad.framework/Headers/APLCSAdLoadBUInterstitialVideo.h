//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <APLCSAdSDK/APLCSAdLoadInterstitial.h>
#import <APLCSAdSDK/APLCSAdLoadProtocol.h>
#import <APLCSAdSDK/APLCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface APLCSAdLoadBUInterstitialVideo : APLCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,APLCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
