//
//  SSACSAdLoadBuBanner.h
//  SSACSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <SSACSAdSDK/SSACSAdLoadProtocol.h>
#import <SSACSAdSDK/SSACSAdLoadBanner.h>
#import <SSACSAdSDK/SSACSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface SSACSAdLoadBuBanner : SSACSAdLoadBanner <BUNativeExpressBannerViewDelegate,SSACSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

