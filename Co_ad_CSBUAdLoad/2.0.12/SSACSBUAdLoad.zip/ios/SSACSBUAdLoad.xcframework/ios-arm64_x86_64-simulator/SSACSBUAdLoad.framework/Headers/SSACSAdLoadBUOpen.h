//
//  SSACSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <SSACSAdSDK/SSACSAdLoadOpen.h>
#import <SSACSAdSDK/SSACSAdLoadProtocol.h>
#import <SSACSAdSDK/SSACSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface SSACSAdLoadBUOpen : SSACSAdLoadOpen<SSACSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
