////
////  AWCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <AWCSAdSDK/AWCSAdLoadInterstitial.h>
//#import <AWCSAdSDK/AWCSAdLoadProtocol.h>
//#import <AWCSAdSDK/AWCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface AWCSAdLoadBUInterstitial : AWCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,AWCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
