//
//  AWCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AWCSAdSDK/AWCSAdLoadReward.h>
#import <AWCSAdSDK/AWCSAdLoadProtocol.h>
#import <AWCSAdSDK/AWCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadBUReward : AWCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,AWCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
