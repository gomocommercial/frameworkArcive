//
//  AWCSAdLoadBuBanner.h
//  AWCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <AWCSAdSDK/AWCSAdLoadProtocol.h>
#import <AWCSAdSDK/AWCSAdLoadBanner.h>
#import <AWCSAdSDK/AWCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface AWCSAdLoadBuBanner : AWCSAdLoadBanner <BUNativeExpressBannerViewDelegate,AWCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

