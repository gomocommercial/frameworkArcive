//
//  PFCSAdLoadBuBanner.h
//  PFCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <PFCSAdSDK/PFCSAdLoadProtocol.h>
#import <PFCSAdSDK/PFCSAdLoadBanner.h>
#import <PFCSAdSDK/PFCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface PFCSAdLoadBuBanner : PFCSAdLoadBanner <BUNativeExpressBannerViewDelegate,PFCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

