//
//  SJCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SJCSAdSDK/SJCSAdLoadReward.h>
#import <SJCSAdSDK/SJCSAdLoadProtocol.h>
#import <SJCSAdSDK/SJCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJCSAdLoadBUExpressReward : SJCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,SJCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
