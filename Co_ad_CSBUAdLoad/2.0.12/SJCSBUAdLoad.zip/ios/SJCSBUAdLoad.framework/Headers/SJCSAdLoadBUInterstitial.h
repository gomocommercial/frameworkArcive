////
////  SJCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <SJCSAdSDK/SJCSAdLoadInterstitial.h>
//#import <SJCSAdSDK/SJCSAdLoadProtocol.h>
//#import <SJCSAdSDK/SJCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface SJCSAdLoadBUInterstitial : SJCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,SJCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
