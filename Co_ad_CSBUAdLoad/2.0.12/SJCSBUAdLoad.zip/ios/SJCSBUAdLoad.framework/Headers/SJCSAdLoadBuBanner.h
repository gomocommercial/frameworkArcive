//
//  SJCSAdLoadBuBanner.h
//  SJCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <SJCSAdSDK/SJCSAdLoadProtocol.h>
#import <SJCSAdSDK/SJCSAdLoadBanner.h>
#import <SJCSAdSDK/SJCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface SJCSAdLoadBuBanner : SJCSAdLoadBanner <BUNativeExpressBannerViewDelegate,SJCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

