//
//  PCCSBUConfigModel.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCCSBUConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;

@property (nonatomic, copy) NSString *rewardUserID;
@property (nonatomic, assign) BURitSceneType rewardRitScene;
@property (nonatomic, copy) NSString *rewardRitSceneDescribe;
@property (nonatomic, assign) CGSize interstitialAdSize;
@property (nonatomic, copy) NSString *interstitialSceneDescirbe;

//Banner专用 adSize为广告后台配置的尺寸 转换成对应屏幕尺寸的size 居中显示
@property (nonatomic, assign) CGSize adSize;
@property (nonatomic, assign) NSInteger interval;
@property (nonatomic, weak) UIViewController *rootVC;

@end

NS_ASSUME_NONNULL_END
