//
//  PCCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PCCSAdSDK/PCCSAdLoadReward.h>
#import <PCCSAdSDK/PCCSAdLoadProtocol.h>
#import <PCCSAdSDK/PCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCCSAdLoadBUExpressReward : PCCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,PCCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
