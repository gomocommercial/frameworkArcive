//
//  PCCSAdLoadBuBanner.h
//  PCCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <PCCSAdSDK/PCCSAdLoadProtocol.h>
#import <PCCSAdSDK/PCCSAdLoadBanner.h>
#import <PCCSAdSDK/PCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface PCCSAdLoadBuBanner : PCCSAdLoadBanner <BUNativeExpressBannerViewDelegate,PCCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

