//
//  APLCSAdLoadBUInterstitialVideo.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <APLCSAdSDK/APLCSAdLoadInterstitial.h>
#import <APLCSAdSDK/APLCSAdLoadProtocol.h>
#import <APLCSAdSDK/APLCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN
//TODO: 暂不使用
@interface APLCSAdLoadBUInterstitialVideo : APLCSAdLoadInterstitial<BUFullscreenVideoAdDelegate,APLCSAdLoadProtocol>
@property(nonatomic, strong) BUFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
