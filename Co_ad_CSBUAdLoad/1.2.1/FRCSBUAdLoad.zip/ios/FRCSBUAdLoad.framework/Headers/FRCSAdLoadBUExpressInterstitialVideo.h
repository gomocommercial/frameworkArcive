//
//  FRCSAdLoadBUInterstitialVideo.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FRCSAdSDK/FRCSAdLoadInterstitial.h>
#import <FRCSAdSDK/FRCSAdLoadProtocol.h>
#import <FRCSAdSDK/FRCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface FRCSAdLoadBUExpressInterstitialVideo : FRCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,FRCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
