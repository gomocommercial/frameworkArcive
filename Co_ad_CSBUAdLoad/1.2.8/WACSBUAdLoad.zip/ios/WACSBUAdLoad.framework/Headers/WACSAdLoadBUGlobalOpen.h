//
//  WACSAdLoadBUGlobalOpen.h
//  WACSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <WACSAdSDK/WACSAdLoadOpen.h>
#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface WACSAdLoadBUGlobalOpen : WACSAdLoadOpen<WACSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
