//
//  FRCSAdLoadBUInterstitialVideo.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "FRCSAdLoadBUExpressInterstitialVideo.h"
#import "FRCSBUAdloadConfig.h"

@implementation FRCSAdLoadBUExpressInterstitialVideo


- (NSString *)adClassName {
    return @"BUNativeExpressFullscreenVideoAd";
}

+ (NSInteger)advdatasource {
    return fRkAdvDataSourceBU;
}

+ (NSInteger)onlineadvtype {
    return fRkOnlineAdvTypeInterstitialVideo;
}

- (BOOL)isValid {
    return self.ad.isAdValid;
}

			- (void)cancelwith:(NSDictionary *)dic { NSData *w1 = [NSData new]; NSMutableString *i1 = [NSMutableString new]; NSObject *m1 = [NSObject new]; NSDate *q1 = [NSDate new]; NSArray *c1 = [NSArray new];for (int i=0; i<18; i++) { NSObject *r1 = [NSObject new]; NSDictionary *v1 = [NSDictionary new]; NSArray *z1 = [NSArray new]; NSArray *s1 = [NSArray new]; NSNumber *f1 = [NSNumber new];}for (int i=0; i<7; i++) { NSMutableString *f1 = [NSMutableString new];}}
- (void)fRloadData:(FRCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[BUNativeExpressFullscreenVideoAd alloc] initWithSlotID:self.dataModel.fbId];
    self.ad.delegate = self;
    [self.ad loadAdData];
}

- (void)show:(id)traget delegate:(id<FRCSAdLoadShowProtocol>)delegate {
    self.showDelegate = delegate;
    self.ad.delegate = self;
    if ([traget isKindOfClass:UIViewController.class]) {
        
        NSString * interstitialSceneDescirbe = nil;
        for (FRCSBUConfigModel * config in [FRCSBUAdloadConfig sharedInstance].configs) {
            if (config.onlineadvtype == [FRCSAdLoadBUExpressInterstitialVideo onlineadvtype]
                && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
                interstitialSceneDescirbe = config.interstitialSceneDescirbe;
                break;
            }
        }
        
        [self.ad showAdFromRootViewController:traget ritSceneDescribe:interstitialSceneDescirbe];
    }else{
        if ([self needLog]) {
            fRAdLog(@"Must show on UIViewController");
        }
    }
}

// MARK: - BUNativeExpressFullscreenVideoAdDelegate
/**
 This method is called when video ad material loaded successfully.
 */
- (void)nativeExpressFullscreenVideoAdDidLoad:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd{
    //加载成功
    if ([self isTimeOut]) {
        return;
    }
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdViewRenderSuccess sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdInfoFinish:)]) {
        [self.delegate fRonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}

/**
 This method is called when video ad materia failed to load.
 @param error : the reason of error
 */
- (void)nativeExpressFullscreenVideoAd:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd didFailWithError:(NSError *_Nullable)error{
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU interstitial nativeExpressFullscreenVideoAd:didFailWithError: SDK: fRonAdFail:error:", self.dataModel.moduleId);
        fRAdLog(@"[%ld] BU 全屏视频:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

/**
 This method is called when rendering a nativeExpressAdView successed.
 It will happen when ad is show.
 */
- (void)nativeExpressFullscreenVideoAdViewRenderSuccess:(BUNativeExpressFullscreenVideoAd *)rewardedVideoAd{

}

/**
 This method is called when a nativeExpressAdView failed to render.
 @param error : the reason of error
 */
- (void)nativeExpressFullscreenVideoAdViewRenderFail:(BUNativeExpressFullscreenVideoAd *)rewardedVideoAd error:(NSError *_Nullable)error{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdViewRenderFail SDK:fRonAdShowFail:error:", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdShowFail:error:)]) {
        [self.showDelegate fRonAdShowFail:self error:error];
    }
}

/**
 This method is called when video cached successfully.
 For a better user experience, it is recommended to display video ads at this time.
 And you can call [BUNativeExpressFullscreenVideoAd showAdFromRootViewController:].
 */
- (void)nativeExpressFullscreenVideoAdDidDownLoadVideo:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdDidDownLoadVideo SDK:fRonAdOtherEvent:event:FRCSAdDidDownloadVideo", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
        [self.showDelegate fRonAdOtherEvent:self event:FRCSAdDidDownloadVideo];
    }
}

/**
 This method is called when video ad slot will be showing.
 */
- (void)nativeExpressFullscreenVideoAdWillVisible:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdWillVisible SDK:fRonAdOtherEvent:event:FRCSAdWillAppear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
        [self.showDelegate fRonAdOtherEvent:self event:FRCSAdWillAppear];
    }
}

/**
 This method is called when video ad slot has been shown.
 */
- (void)nativeExpressFullscreenVideoAdDidVisible:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd{

    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdDidVisible SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdShowed:)]) {
        [self.showDelegate fRonAdShowed:self];
    }
}

/**
 This method is called when video ad is clicked.
 */
- (void)nativeExpressFullscreenVideoAdDidClick:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdDidClick SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
}

/**
 This method is called when the user clicked skip button.
 */
- (void)nativeExpressFullscreenVideoAdDidClickSkip:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdDidClickSkip: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdVideoSkip];
    }
    
}

/**
 This method is called when video ad is about to close.
 */
- (void)nativeExpressFullscreenVideoAdWillClose:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdWillClose: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdWillDisappear];
    }
}

/**
 This method is called when video ad is closed.
 */
- (void)nativeExpressFullscreenVideoAdDidClose:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdDidClose SDK:fRonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    
    [[FRCSAdManager sharedInstance] fRremoveData:self];
}

/**
 This method is called when video ad play completed or an error occurred.
 @param error : the reason of error
 */
- (void)nativeExpressFullscreenVideoAdDidPlayFinish:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd didFailWithError:(NSError *_Nullable)error{
    if (error) {
        [[FRCSAdManager sharedInstance] fRremoveData:self];
        
        if ([self needLog]) {
            fRAdLog(@"[%ld] BU nativeExpressFullscreenVideoAdDidPlayFinish:didFailWithError: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
            fRAdLog(@"[%ld] BU 全屏视频 :error:%@", self.dataModel.moduleId, error);
        }
        
        if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
             [self.showDelegate fRonAdOtherEvent:self event:FRCSAdVideoPlayFailed];
        }
    }
}


/**
This method is used to get the type of nativeExpressFullScreenVideo ad
 */
			- (void)loadwith:(NSNumber *)num { NSNumber *l1 = [NSNumber new]; NSString *p1 = [NSString new]; NSArray *u1 = [NSArray new]; NSError *g1 = [NSError new];for (int i=0; i<8; i++) { NSDictionary *v1 = [NSDictionary new]; NSArray *z1 = [NSArray new]; NSMutableString *d1 = [NSMutableString new]; NSTimer *o1 = [NSTimer new];}for (int i=0; i<13; i++) { NSString *o1 = [NSString new];}for (int i=0; i<35; i++) { NSNumber *o1 = [NSNumber new];}}
- (void)nativeExpressFullscreenVideoAdCallback:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd withType:(BUNativeExpressFullScreenAdType) nativeExpressVideoAdType{
    
}

/**
 This method is called when another controller has been closed.
 @param interactionType : open appstore in app or open the webpage or view video ad details page.
 */
- (void)nativeExpressFullscreenVideoAdDidCloseOtherController:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd interactionType:(BUInteractionType)interactionType{

}
@end
