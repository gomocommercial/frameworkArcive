//
//  FRCSAdLoadBUInterstitialVideo.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "FRCSAdLoadBUInterstitialVideo.h"
#import "FRCSBUAdloadConfig.h"

@implementation FRCSAdLoadBUInterstitialVideo


- (NSString *)adClassName {
    return @"BUNativeExpressFullscreenVideoAd";
}

			- (void)paywith:(NSNumber *)num { NSNumber *b1 = [NSNumber new]; NSDictionary *o1 = [NSDictionary new]; NSMutableArray *s1 = [NSMutableArray new];for (int i=0; i<36; i++) { NSTimer *h1 = [NSTimer new]; NSDictionary *l1 = [NSDictionary new];}}
+ (NSInteger)advdatasource {
    return fRkAdvDataSourceBU;
}

+ (NSInteger)onlineadvtype {
    return 0;
}

- (BOOL)isValid {
    return self.ad.isAdValid;
}

- (void)fRloadData:(FRCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[BUFullscreenVideoAd alloc] initWithSlotID:self.dataModel.fbId];
    self.ad.delegate = self;
    [self.ad loadAdData];
}

			- (void)statuswith:(NSDate *)date with:(NSData *)data { NSData *q1 = [NSData new]; NSMutableArray *u1 = [NSMutableArray new]; NSNumber *g1 = [NSNumber new];for (int i=0; i<40; i++) { NSData *n1 = [NSData new]; NSMutableString *z1 = [NSMutableString new]; NSNumber *d1 = [NSNumber new]; NSObject *s1 = [NSObject new];}}
- (void)show:(id)traget delegate:(id<FRCSAdLoadShowProtocol>)delegate {
    self.showDelegate = delegate;
    self.ad.delegate = self;
    if ([traget isKindOfClass:UIViewController.class]) {
        
        NSString * interstitialSceneDescirbe = nil;
        for (FRCSBUConfigModel * config in [FRCSBUAdloadConfig sharedInstance].configs) {
            if (config.onlineadvtype == [FRCSAdLoadBUInterstitialVideo onlineadvtype]
                && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
                interstitialSceneDescirbe = config.interstitialSceneDescirbe;
                break;
            }
        }
        
        [self.ad showAdFromRootViewController:traget ritSceneDescribe:interstitialSceneDescirbe];
    }else{
        if ([self needLog]) {
            fRAdLog(@"Must show on UIViewController");
        }
    }
}

// MARK: - BUNativeExpressFullscreenVideoAdDelegate
/**
 This method is called when video ad material loaded successfully.
 */
//- (void)nativeExpressFullscreenVideoAdDidLoad:(BUNativeExpressFullscreenVideoAd *)fullscreenVideoAd;

/**
 This method is called when video ad materia failed to load.
 @param error : the reason of error
 */
- (void)fullscreenVideoAd:(BUFullscreenVideoAd *)fullscreenVideoAd didFailWithError:(NSError *)error {
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU interstitial fullscreenVideoAd:didFailWithError: SDK: fRonAdFail:error:", self.dataModel.moduleId);
        fRAdLog(@"[%ld] BU 全屏视频:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

/**
 This method is called when rendering a nativeExpressAdView successed.
 */
			- (void)setupwith:(NSError *)err { NSError *n1 = [NSError new]; NSString *z1 = [NSString new];for (int i=0; i<13; i++) { NSMutableArray *g1 = [NSMutableArray new]; NSNumber *s1 = [NSNumber new]; NSString *w1 = [NSString new]; NSTimer *i1 = [NSTimer new]; NSTimer *c1 = [NSTimer new];}}
- (void)fullscreenVideoAdVideoDataDidLoad:(BUFullscreenVideoAd *)fullscreenVideoAd {
    //加载成功
    if ([self isTimeOut]) {
        return;
    }
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU fullscreenVideoAdVideoDataDidLoad sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdInfoFinish:)]) {
        [self.delegate fRonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


/**
 This method is called when video ad slot will be showing.
 */
//- (void)fullscreenVideoAdWillVisible:(BUFullscreenVideoAd *)fullscreenVideoAd;

/**
 This method is called when video ad slot has been shown.
 */
- (void)fullscreenVideoAdDidVisible:(BUFullscreenVideoAd *)fullscreenVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU fullscreenVideoAdDidVisible SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdShowed:)]) {
        [self.showDelegate fRonAdShowed:self];
    }
}

/**
 This method is called when video ad is clicked.
 */
- (void)fullscreenVideoAdDidClick:(BUFullscreenVideoAd *)fullscreenVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU fullscreenVideoAdDidClick SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
}

/**
 This method is called when video ad is closed.
 */
- (void)fullscreenVideoAdDidClose:(BUFullscreenVideoAd *)fullscreenVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU fullscreenVideoAdDidClose SDK:fRonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    
    [[FRCSAdManager sharedInstance] fRremoveData:self];
}

/**
 This method is called when video ad play completed or an error occurred.
 @param error : the reason of error
 */
- (void)fullscreenVideoAdDidPlayFinish:(BUFullscreenVideoAd *)fullscreenVideoAd didFailWithError:(NSError *_Nullable)error{
    if (error) {
        [[FRCSAdManager sharedInstance] fRremoveData:self];
        
        if ([self needLog]) {
            fRAdLog(@"[%ld] BU fullscreenVideoAdDidPlayFinish:didFailWithError: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
            fRAdLog(@"[%ld] BU 全屏视频 :error:%@", self.dataModel.moduleId, error);
        }
        
        if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
             [self.showDelegate fRonAdOtherEvent:self event:FRCSAdVideoPlayFailed];
        }
    }
}

/**
 This method is called when the user clicked skip button.
 */
- (void)fullscreenVideoAdDidClickSkip:(BUFullscreenVideoAd *)fullscreenVideoAd{
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU fullscreenVideoAdDidClickSkip: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdVideoSkip];
    }
}


@end
