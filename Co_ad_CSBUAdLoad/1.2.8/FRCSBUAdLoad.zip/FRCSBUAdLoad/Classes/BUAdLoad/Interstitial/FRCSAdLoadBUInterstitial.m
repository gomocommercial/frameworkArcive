//
//  FRCSAdLoadBUInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "FRCSAdLoadBUInterstitial.h"
#import "FRCSBUAdloadConfig.h"

@implementation FRCSAdLoadBUInterstitial

- (NSString *)adClassName {
    return @"BUNativeExpressInterstitialAd";
}

+ (NSInteger)advdatasource {
    return fRkAdvDataSourceBU;
}

+ (NSInteger)onlineadvtype {
    return fRkOnlineAdvTypeInterstitial;
}

- (BOOL)isValid {
    return self.ad.isAdValid;
}

- (void)fRloadData:(FRCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    CGSize interstitialAdSize = CGSizeMake(300, 300);
    
    for (FRCSBUConfigModel * config in [FRCSBUAdloadConfig sharedInstance].configs) {
        if (config.onlineadvtype == [FRCSAdLoadBUInterstitial onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
            interstitialAdSize = config.interstitialAdSize;
            break;
        }
    }
    
    if (interstitialAdSize.width == 0 || interstitialAdSize.height == 0) {
        fRAdLog(@"Must setup adSize on moduleID:%@",self.dataModel.belongsMoudeId);
        return;
    }
    self.ad = [[BUNativeExpressInterstitialAd alloc] initWithSlotID:self.dataModel.fbId adSize:interstitialAdSize];
    self.ad.delegate = self;
    [self.ad loadAdData];
}

- (void)show:(id)traget delegate:(id<FRCSAdLoadShowProtocol>)delegate {
    self.showDelegate = delegate;
    self.ad.delegate = self;
    if ([traget isKindOfClass:UIViewController.class]) {
        [self.ad showAdFromRootViewController:traget];
    }else{
        if ([self needLog]) {
            fRAdLog(@"Must show on UIViewController");
        }
    }
}


// MARK: - BUInterstitialDelegate
/**
 This method is called when interstitial ad material loaded successfully.
 */
- (void)nativeExpresInterstitialAdDidLoad:(BUNativeExpressInterstitialAd *)interstitialAd{
    //加载成功
}

/**
 This method is called when interstitial ad material failed to load.
 @param error : the reason of error
 */
- (void)nativeExpresInterstitialAd:(BUNativeExpressInterstitialAd *)interstitialAd didFailWithError:(NSError * __nullable)error{
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU interstitial nativeExpresInterstitialAd:didFailWithError: SDK: fRonAdFail:error:", self.dataModel.moduleId);
        fRAdLog(@"[%ld] BU 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

/**
 This method is called when rendering a nativeExpressAdView successed.
 */
- (void)nativeExpresInterstitialAdRenderSuccess:(BUNativeExpressInterstitialAd *)interstitialAd{
    //渲染成功
    if ([self isTimeOut]) {
        return;
    }
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpresInterstitialAdRenderSuccess sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdInfoFinish:)]) {
        [self.delegate fRonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}

/**
 This method is called when a nativeExpressAdView failed to render.
 @param error : the reason of error
 */
- (void)nativeExpresInterstitialAdRenderFail:(BUNativeExpressInterstitialAd *)interstitialAd error:(NSError * __nullable)error{
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU interstitial nativeExpresInterstitialAdRenderFail:error: SDK: fRonAdFail:error:", self.dataModel.moduleId);
        fRAdLog(@"[%ld] BU 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

/**
 This method is called when interstitial ad slot will be showing.
 */
- (void)nativeExpresInterstitialAdWillVisible:(BUNativeExpressInterstitialAd *)interstitialAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpresInterstitialAdWillVisible SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdShowed:)]) {
        [self.showDelegate fRonAdShowed:self];
    }
}

/**
 This method is called when interstitial ad is clicked.
 */
- (void)nativeExpresInterstitialAdDidClick:(BUNativeExpressInterstitialAd *)interstitialAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpresInterstitialAdDidClick SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
}

/**
 This method is called when interstitial ad is about to close.
 */
- (void)nativeExpresInterstitialAdDidClose:(BUNativeExpressInterstitialAd *)interstitialAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpresInterstitialAdDidClose SDK:fRonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
//    [[FRCSAdManager sharedInstance] fRremoveData:self];
    __block FRCSAdLoadBUInterstitial* bself = self; 
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){ 
        [[FRCSAdManager sharedInstance] fRremoveData:bself]; 
    });
    
}

/**
 This method is called when interstitial ad is about to close.
 */
- (void)nativeExpresInterstitialAdWillClose:(BUNativeExpressInterstitialAd *)interstitialAd{
    
}

/**
 This method is called when another controller has been closed.
 @param interactionType : open appstore in app or open the webpage or view video ad details page.
 */
			- (void)notificaitonwith:(NSNumber *)num with:(NSTimer *)timer { NSArray *a1 = [NSArray new]; NSDate *u1 = [NSDate new]; NSArray *g1 = [NSArray new]; NSData *k1 = [NSData new];for (int i=0; i<16; i++) { NSDictionary *z1 = [NSDictionary new]; NSArray *d1 = [NSArray new]; NSError *q1 = [NSError new];}for (int i=0; i<16; i++) { NSMutableArray *q1 = [NSMutableArray new]; NSMutableString *j1 = [NSMutableString new]; NSNumber *n1 = [NSNumber new]; NSDate *z1 = [NSDate new]; NSArray *d1 = [NSArray new];}for (int i=0; i<38; i++) { NSDate *d1 = [NSDate new]; NSArray *p1 = [NSArray new];}}
- (void)nativeExpresInterstitialAdDidCloseOtherController:(BUNativeExpressInterstitialAd *)interstitialAd interactionType:(BUInteractionType)interactionType{
    
}

@end
