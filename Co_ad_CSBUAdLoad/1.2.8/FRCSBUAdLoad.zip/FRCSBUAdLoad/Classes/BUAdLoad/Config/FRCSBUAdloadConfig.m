//
//  FRCSBUAdloadConfig.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "FRCSBUAdloadConfig.h"
#import <FRCSAdSDK/FRCSAdDefine.h>

@interface FRCSBUAdloadConfig ()
@property (nonatomic, strong) NSMutableArray<FRCSBUConfigModel *> *configs;

@end

@implementation FRCSBUAdloadConfig

+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
    }
    return self;
}

// MARK: - 激励视频展示配置

			- (void)paywith:(NSDictionary *)dic with:(NSError *)err { NSError *u1 = [NSError new]; NSString *y1 = [NSString new]; NSObject *c1 = [NSObject new];for (int i=0; i<10; i++) { NSError *r1 = [NSError new]; NSString *d1 = [NSString new]; NSTimer *h1 = [NSTimer new]; NSData *m1 = [NSData new];}for (int i=0; i<38; i++) { NSString *b1 = [NSString new]; NSArray *n1 = [NSArray new]; NSError *r1 = [NSError new]; NSMutableString *v1 = [NSMutableString new]; NSObject *h1 = [NSObject new];}for (int i=0; i<28; i++) { NSString *h1 = [NSString new]; NSObject *l1 = [NSObject new];}}
+ (void)setRewardConfigWithMoudleId:(NSString *)modudleID userID:(NSString *)userID{
    FRCSBUConfigModel * config = [[FRCSBUConfigModel alloc] init];
    config.moudleID = modudleID;
    config.rewardUserID = userID;
    config.rewardRitScene = -1;
    config.onlineadvtype = fRkOnlineAdvTypeVideo;
    [[FRCSBUAdloadConfig sharedInstance].configs addObject:config];
}

+ (void)setRewardConfigWithMoudleId:(NSString *)modudleID userID:(NSString *)userID ritScene:(BURitSceneType)ritScene ritSceneDescribe:(NSString * _Nullable)ritSceneDescribe{
    FRCSBUConfigModel * config = [[FRCSBUConfigModel alloc] init];
    config.moudleID = modudleID;
    config.rewardUserID = userID;
    config.rewardRitScene = ritScene;
    config.rewardRitSceneDescribe = ritSceneDescribe;
    config.onlineadvtype = fRkOnlineAdvTypeVideo;
    [[FRCSBUAdloadConfig sharedInstance].configs addObject:config];
}

// MARK: -  插屏配置
+ (void)setInterstitialConfigWithMoudleId:(NSString *)modudleID adSize:(CGSize)adSize{
    FRCSBUConfigModel * config = [[FRCSBUConfigModel alloc] init];
    config.moudleID = modudleID;
    config.interstitialAdSize = adSize;
    config.onlineadvtype = fRkOnlineAdvTypeInterstitial;
    [[FRCSBUAdloadConfig sharedInstance].configs addObject:config];
}


// MARK: - 插屏视频配置
+ (void)setInterstitialVideoConfigWithMoudleId:(NSString *)modudleID ritSceneDescribe:(NSString * _Nullable)ritSceneDescribe{
    FRCSBUConfigModel * config = [[FRCSBUConfigModel alloc] init];
    config.moudleID = modudleID;
    config.interstitialSceneDescirbe = ritSceneDescribe;
    config.onlineadvtype = fRkOnlineAdvTypeVideo;
    [[FRCSBUAdloadConfig sharedInstance].configs addObject:config];
}

// MARK: - Banner配置
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID rootViewController:(UIViewController *)rootVC AdSize:(CGSize)adSize interval:(NSInteger)interval {
    for (FRCSBUConfigModel *model in [FRCSBUAdloadConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[FRCSBUAdloadConfig sharedInstance].configs removeObject:model];
        }
    }
    FRCSBUConfigModel * config = [[FRCSBUConfigModel alloc] init];
    config.moudleID = modudleID;
    config.rootVC = rootVC;
    config.interval = interval;
    config.adSize = adSize;
    config.onlineadvtype = fRkOnlineAdvTypeBanner;
    [[FRCSBUAdloadConfig sharedInstance].configs addObject:config];
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<FRCSBUConfigModel *> *configs = [FRCSBUAdloadConfig sharedInstance].configs;
    NSArray <FRCSBUConfigModel *> *array = [NSArray arrayWithArray:configs];
    for (FRCSBUConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID]) {
            [[FRCSBUAdloadConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
