//
//  FRCSBUOpenAdConfig.m
//  FRCSBUAdLoad
//
//  Created by qiaoming on 2020/12/3.
//

#import "FRCSBUOpenAdConfig.h"

@implementation FRCSBUOpenAdConfig

+ (instancetype)sharedInstance {
    static FRCSBUOpenAdConfig *_sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
        _sharedInstance.hideSkipButton = NO;
        _sharedInstance.needSplashZoomOutAd = NO;
        _sharedInstance.needSplashCardViewAd = NO;
        _sharedInstance.tolerateTimeout = 3.5;
        _sharedInstance.frame = [UIScreen mainScreen].bounds;
    });
    
    return _sharedInstance;
}

@end
