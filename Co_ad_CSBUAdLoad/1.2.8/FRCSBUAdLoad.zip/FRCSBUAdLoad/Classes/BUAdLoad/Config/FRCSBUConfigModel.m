//
//  FRCSBUConfigModel.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "FRCSBUConfigModel.h"

@implementation FRCSBUConfigModel

@end
