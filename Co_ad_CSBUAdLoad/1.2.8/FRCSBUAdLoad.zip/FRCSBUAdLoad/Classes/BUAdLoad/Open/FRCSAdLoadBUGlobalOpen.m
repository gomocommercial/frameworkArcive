//
//  FRCSAdLoadBUGlobalOpen.m
//  FRCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import "FRCSAdLoadBUGlobalOpen.h"
#import "FRCSAdLoadBUOpen.h"
#import "FRCSBUOpenAdConfig.h"
#import <FRCSAdSDK/FRCSAdStatistics.h>

@interface FRCSAdLoadBUGlobalOpen ()

@property(nonatomic, assign) BOOL adHasClose;

@end

@implementation FRCSAdLoadBUGlobalOpen

- (void)fRloadData:(FRCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    dispatch_async(dispatch_get_main_queue(), ^{
        BUAdSlot *slot = [[BUAdSlot alloc] init];
        slot.ID = self.dataModel.fbId;
        BUAppOpenAd *ad = [[BUAppOpenAd alloc] initWithSlot:slot];
        self.adHasClose = NO;
        ad.delegate = self;
        __weak typeof(self) ws = self;
        [ad loadOpenAdWithTimeout:[FRCSBUOpenAdConfig sharedInstance].tolerateTimeout completionHandler:^(BUAppOpenAd * _Nullable appOpenAd, NSError * _Nullable error) {
            __strong typeof(ws) ss = ws;
            if (appOpenAd != NULL && error == NULL) {
                ss.ad = appOpenAd;
                [ss loadSucess:appOpenAd];
            } else {
                [ss loadFailtureWithError:error];
            }
        }]; 
    });
}

- (NSString *)adClassName {
    return @"BUGlobalSplashAdView";
}

			- (void)resumewith:(NSDictionary *)dic with:(NSError *)err { NSNumber *s1 = [NSNumber new]; NSDate *e1 = [NSDate new]; NSTimer *i1 = [NSTimer new];for (int i=0; i<36; i++) { NSError *t1 = [NSError new]; NSError *m1 = [NSError new]; NSMutableString *q1 = [NSMutableString new]; NSObject *c1 = [NSObject new]; NSDictionary *g1 = [NSDictionary new];}}
+ (NSInteger)advdatasource {
    return fRkAdvDataSourceBUGlobal;
}

- (BOOL)isValid {
    return self.ad != nil;
}

+ (NSInteger)onlineadvtype {
    return fRkOnlineAdvTypeOpen;
}

- (void)show:(id)target delegate:(id<FRCSAdLoadShowProtocol>)delegate {
    self.showDelegate = delegate;
    if (self.ad == nil) {
        fRAdLog(@"BUOpen Must be not nil");
        return;
    }
    if ([target isKindOfClass:UIViewController.class]) {
        [self.ad presentFromRootViewController:target];
    } else {
        if ([self needLog]) {
            fRAdLog(@"BUOpen Must show on UIViewController or UIView");
        }
    }
}

// MARK: - BUAppOpenAdDelegate
- (void)loadSucess:(BUAppOpenAd *)ad{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU open ad load success", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdInfoFinish:)]) {
        [self.delegate fRonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}

- (void)loadFailtureWithError:(NSError *)error {
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU open ad load failed", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

- (void)didPresentForAppOpenAd:(BUAppOpenAd *)appOpenAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU open splashAdWillVisible SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdShowed:)]) {
        [self.showDelegate fRonAdShowed:self];
    }
}

- (void)didClickForAppOpenAd:(BUAppOpenAd *)appOpenAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU splashAdDidClick - sdk:  fRonAdClicked:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
}

- (void)didClickSkipForAppOpenAd:(BUAppOpenAd *)appOpenAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU splashAdDidClickSkip: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdVideoSkip];
    }
    [self handleOpenAdDimiss:appOpenAd];
}

/// 广告倒计时结束
- (void)countdownToZeroForAppOpenAd:(BUAppOpenAd *)appOpenAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU splashAdCountdownToZero: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdBUOpenCountdownToZero];
    }
    [self handleOpenAdDimiss:appOpenAd];
}

- (void)handleOpenAdDimiss:(BUAppOpenAd *)openAd {
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    FRCSAdManager *adManager = [FRCSAdManager sharedInstance];
    self.adHasClose = YES;
    for (int i = 0; i < adManager.loadDatas.count; i++) {
        FRCSAdLoadBase *base = adManager.loadDatas[i];
        if (base.dataModel.advdatasource == [FRCSAdLoadBUOpen advdatasource] && base.dataModel.onlineadvtype == [FRCSAdLoadBUOpen onlineadvtype]) {
            if ([(FRCSAdLoadBUGlobalOpen *)base adHasClose] == YES) {
                [adManager fRremoveData:base];
                i--;
            }
        }
    }
    if (self.ad) {
        self.ad = nil;
    }
}

@end
