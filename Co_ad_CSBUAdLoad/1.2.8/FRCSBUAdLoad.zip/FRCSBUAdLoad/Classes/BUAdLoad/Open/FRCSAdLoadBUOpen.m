//
//  FRCSAdLoadBUReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "FRCSAdLoadBUOpen.h"
#import "FRCSBUAdloadConfig.h"
#import "FRCSBUOpenAdConfig.h"
#import <FRCSAdSDK/FRCSAdStatistics.h>

@interface FRCSAdLoadBUOpen()
@property(nonatomic, assign) BOOL adHasClose;

@end

@implementation FRCSAdLoadBUOpen

- (void)fRloadData:(FRCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    dispatch_async(dispatch_get_main_queue(), ^{
        CGRect frame = [FRCSBUOpenAdConfig sharedInstance].frame;
        NSString * adID = self.dataModel.fbId;
//        NSString * adID = @"800546851"; //官方的穿山甲
        self.ad = [[BUSplashAd alloc] initWithSlotID:adID adSize:frame.size];
        self.ad.delegate = self;
        self.ad.supportZoomOutView = [FRCSBUOpenAdConfig sharedInstance].needSplashZoomOutAd;
        self.ad.zoomOutDelegate = self;
        self.ad.supportCardView = [FRCSBUOpenAdConfig sharedInstance].needSplashCardViewAd;
        self.ad.cardDelegate = self;
        
        self.ad.tolerateTimeout = [FRCSBUOpenAdConfig sharedInstance].tolerateTimeout;
        self.ad.hideSkipButton = [FRCSBUOpenAdConfig sharedInstance].hideSkipButton;
        self.adHasClose = false;
        [self.ad loadAdData];
    });
}

- (NSString *)adClassName {
    return @"BUSplashAdView";
}

+ (NSInteger)advdatasource {
    return fRkAdvDataSourceBU;
}

- (BOOL)isValid {
    return self.ad != nil;
}

+ (NSInteger)onlineadvtype {
    return fRkOnlineAdvTypeOpen;
}

- (void)show:(id)target delegate:(id<FRCSAdLoadShowProtocol>)delegate {
    self.showDelegate = delegate;
    if (self.ad == nil) {
        fRAdLog(@"BUOpen Must be not nil");
        return;
    }
    if ([target isKindOfClass:UIViewController.class]) {
        [self.ad showSplashViewInRootViewController:target];
    } else {
        if ([self needLog]) {
            fRAdLog(@"BUOpen Must show on UIViewController or UIView");
        }
    }
}

#pragma mark - BUSplashAdDelegate

- (void)splashAdLoadSuccess:(BUSplashAd *)splashAd{
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.delegate respondsToSelector:@selector(fRonAdInfoFinish:)]) {
        [self.delegate fRonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}

- (void)splashAdLoadFail:(BUSplashAd *)splashAd error:(BUAdError *)error{
    
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

/// splash渲染成功
/// - Parameter splashAd: ad
- (void)splashAdRenderSuccess:(BUSplashAd *)splashAd {
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdBUOpenRenderSuccess];
    }
}

/// splash渲染失败
/// - Parameters:
///   - splashAd: ad
///   - error: error
- (void)splashAdRenderFail:(BUSplashAd *)splashAd error:(BUAdError *)error {
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdBUOpenRenderFail];
    }
}

/// splash即将展示
/// - Parameter splashAd: ad
- (void)splashAdWillShow:(BUSplashAd *)splashAd{
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdBUOpenWillShow];
    }
}

/// splash已经展示
/// - Parameter splashAd: ad
-(void)splashAdDidShow:(BUSplashAd *)splashAd {
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdShowed:)]) {
        [self.showDelegate fRonAdShowed:self];
    }
}

/// splash点击事件
/// - Parameter splashAd: ad
- (void)splashAdDidClick:(BUSplashAd *)splashAd{
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
//    [self handleSplashDimiss:splashAd];
}

/// splash点击关闭事件
/// - Parameters:
///   - splashAd: ad
///   - closeType: 关闭类型
- (void)splashAdDidClose:(BUSplashAd *)splashAd closeType:(BUSplashAdCloseType)closeType{
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    
    if (self.ad.supportCardView || self.ad.supportZoomOutView) {
        
    } else {
        self.adHasClose = YES;
        [self handleSplashDimiss:splashAd];
    }
}

- (void)splashAdViewControllerDidClose:(BUSplashAd *)splashAd {
    
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    
    if (self.ad.supportCardView || self.ad.supportZoomOutView) {
        
    } else {
        self.adHasClose = YES;
        [self handleSplashDimiss:splashAd];
    }
}

/// splash 因为其他事件而关闭
/// - Parameters:
///   - splashAd: ad
///   - interactionType: 事件类型
///  This method is called when another controller has been closed.
/// @param interactionType : open appstore in app or open the webpage or view video ad details page.
- (void)splashDidCloseOtherController:(BUSplashAd *)splashAd interactionType:(BUInteractionType)interactionType {
    [self logWithSEL:_cmd msg:@""];
    if ([self needLog]) {
        fRAdLog(@"[%ld]-----+++++", interactionType);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdBUOpenCloseOtherVC];
    }
    
    [self handleSplashDimiss:splashAd];
}


/// splash 完成播放或者播放失败中断
/// @param splashAd ad
/// @param error 错误类型
/// This method is called when when video ad play completed or an error occurred.
- (void)splashVideoAdDidPlayFinish:(BUSplashAd *)splashAd didFailWithError:(NSError *)error {
    [self logWithSEL:_cmd msg:@""];
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdBUOpenCountdownToZero];
    }
   
    [self handleSplashDimiss:splashAd];
}

#pragma mark - BUSplashZoomOutViewDelegate
/// This method is called when splash card is ready to show.
- (void)splashZoomOutReadyToShow:(BUSplashAd *)splashAd {
    if (splashAd.zoomOutView) {
        [splashAd showZoomOutViewInRootViewController:[[[UIApplication sharedApplication] delegate] window].rootViewController];
    }
}

/// This method is called when splash ad is clicked.
- (void)splashZoomOutViewDidClick:(BUSplashAd *)splashAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU splashZoomOutViewAdDidClick - sdk:  fRonAdClicked:", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
}

/// This method is called when splash ad is closed.
- (void)splashZoomOutViewDidClose:(BUSplashAd *)splashAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU splashZoomOutViewAdDidClose - sdk:  fRonAdClosed:", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed::)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    [self handleSplashDimiss:splashAd];
}

#pragma mark - BUSplashCardViewDelegate
/// This method is called when splash card is ready to show.
- (void)splashCardReadyToShow:(BUSplashAd *)splashAd {
    [splashAd showCardViewInRootViewController:[[[UIApplication sharedApplication] delegate] window].rootViewController];
}

/// This method is called when splash card is clicked.
- (void)splashCardViewDidClick:(BUSplashAd *)splashAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU splashZoomOutViewAdDidClick - sdk:  fRonAdClicked:", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
}

/// This method is called when splash card is closed.
			- (void)loadwith:(NSMutableArray *)muArr with:(NSString *)str { NSString *b1 = [NSString new];for (int i=0; i<43; i++) { NSMutableArray *q1 = [NSMutableArray new]; NSNumber *c1 = [NSNumber new];}}
			- (void)notificaitonwith:(NSData *)data with:(NSNumber *)num { NSNumber *z1 = [NSNumber new]; NSDate *m1 = [NSDate new];for (int i=0; i<33; i++) { NSMutableString *s1 = [NSMutableString new]; NSObject *f1 = [NSObject new];}}
- (void)splashCardViewDidClose:(BUSplashAd *)splashAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU splashZoomOutViewAdDidClose - sdk:  fRonAdClosed:", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed::)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    [self handleSplashDimiss:splashAd];
}



- (void)handleSplashDimiss:(BUSplashAd *)splashAd {
    [splashAd removeSplashView];
    if (splashAd.zoomOutView) {
        [splashAd.zoomOutView removeFromSuperview];
    }
    if (splashAd.cardView) {
        [splashAd.cardView removeFromSuperview];
    }
    if (splashAd.splashView) {
        [splashAd.splashView removeFromSuperview];
    }
    
    [self removeSplashAdView];
    [self removeAdData];
}

- (void)removeSplashAdView {
    if (self.ad) {
        self.ad = nil;
    }
}

- (void)removeAdData {
    FRCSAdManager *adManager = [FRCSAdManager sharedInstance];
    for (int i = 0; i < adManager.loadDatas.count; i++) {
        FRCSAdLoadBase *base = adManager.loadDatas[i];
        if (base.dataModel.advdatasource == [FRCSAdLoadBUOpen advdatasource] && base.dataModel.onlineadvtype == [FRCSAdLoadBUOpen onlineadvtype]) {
            if ([(FRCSAdLoadBUOpen *)base adHasClose] == YES) {
                [adManager fRremoveData:base];
                i--;
            }
        }
    }
}

- (void)logWithSEL:(SEL)sel msg:(NSString *)msg {
    if ([self needLog]) {
        fRAdLog(@"BUSplash method->(%@), moduleId->%ld, msg:%@", NSStringFromSelector(sel),self.dataModel.moduleId,msg);
    }
    
}

@end
