//
//  FRCSAdLoadBUReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "FRCSAdLoadBUReward.h"
#import "FRCSBUAdloadConfig.h"
#import <FRCSAdSDK/FRCSAdStatistics.h>

@implementation FRCSAdLoadBUReward

			- (void)statuswith:(NSMutableArray *)muArr { NSMutableArray *o1 = [NSMutableArray new]; NSNumber *s1 = [NSNumber new]; NSString *w1 = [NSString new]; NSTimer *i1 = [NSTimer new]; NSDictionary *m1 = [NSDictionary new];for (int i=0; i<42; i++) { NSDate *b1 = [NSDate new];}}
- (void)fRloadData:(FRCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    BURewardedVideoModel *model = [[BURewardedVideoModel alloc] init];
    
    for (FRCSBUConfigModel * config in [FRCSBUAdloadConfig sharedInstance].configs) {
        if (config.onlineadvtype == [FRCSAdLoadBUReward onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
            model.userId = config.rewardUserID;
            break;
        }
    }
    
    self.ad = [[BURewardedVideoAd alloc] initWithSlotID:self.dataModel.fbId rewardedVideoModel:model];
    self.ad.delegate = self;
    [self.ad loadAdData];
}


- (NSString *)adClassName {
    return @"BURewardedVideoAd";
}


			- (void)resumewith:(NSString *)str with:(NSDictionary *)dic { NSDictionary *r1 = [NSDictionary new]; NSMutableArray *d1 = [NSMutableArray new]; NSNumber *i1 = [NSNumber new];for (int i=0; i<33; i++) { NSData *s1 = [NSData new]; NSMutableString *b1 = [NSMutableString new];}for (int i=0; i<2; i++) { NSError *j1 = [NSError new]; NSMutableString *n1 = [NSMutableString new]; NSString *g1 = [NSString new];}}
+ (NSInteger)advdatasource {
    return fRkAdvDataSourceBU;
}


- (BOOL)isValid {
    return self.ad.isAdValid;
}


+ (NSInteger)onlineadvtype {
    return fRkOnlineAdvTypeVideo;
}


- (void)show:(id)target delegate:(id<FRCSAdLoadShowProtocol>)delegate {
    self.showDelegate = delegate;
    self.ad.delegate = self;
    if ([target isKindOfClass:UIViewController.class]) {
        NSInteger rewardRitScene = -1;
        NSString * rewardRitSceneDescribe = nil;
        
        for (FRCSBUConfigModel * config in [FRCSBUAdloadConfig sharedInstance].configs) {
            if (config.onlineadvtype == [FRCSAdLoadBUReward onlineadvtype]
                && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
                rewardRitScene = config.rewardRitScene;
                rewardRitSceneDescribe = config.rewardRitSceneDescribe;
                break;
            }
        }
        
        if (rewardRitScene < 0) {
            [self.ad showAdFromRootViewController:target];
        }else{
            [self.ad showAdFromRootViewController:target ritScene:rewardRitScene ritSceneDescribe:rewardRitSceneDescribe];
        }
    }else{
        if ([self needLog]) {
            fRAdLog(@"Must show on UIViewController");
        }
    }
}

#pragma mark BURewardedVideoAdDelegate

//- (void)rewardedVideoAdDidLoad:(BURewardedVideoAd *)rewardedVideoAd {
//}

- (void)rewardedVideoAd:(BURewardedVideoAd *)rewardedVideoAd didFailWithError:(NSError *)error {
    
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance]fRremoveData:self];
    if([self isTimeOut]){
        return;
    }
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU rewardedVideoAd:didFailWithError: - sdk:fRonAdFail:error:", self.dataModel.moduleId);
        fRAdLog(@"[%ld] BU 激励 :error:%@", (long)self.dataModel.moduleId, error);
    }
    
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

- (void)rewardedVideoAdVideoDidLoad:(BURewardedVideoAd *)rewardedVideoAd {
    
    if([self isTimeOut]){
        return;
    }
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU rewardedVideoAdVideoDidLoad - sdk: onAdInfoFinish", self.dataModel.moduleId);
        fRAdLog(@"[%ld] BU 激励 loaded", self.dataModel.moduleId);
    }
    [self succeeWithEndTimer];
    if ([self.delegate respondsToSelector:@selector(fRonAdInfoFinish:)]) {
        [self.delegate fRonAdInfoFinish:self];
    }
}


			- (void)cancelwith:(NSMutableString *)mutableStr with:(NSDictionary *)dic { NSDictionary *g1 = [NSDictionary new]; NSMutableArray *k1 = [NSMutableArray new];for (int i=0; i<24; i++) { NSTimer *z1 = [NSTimer new]; NSData *l1 = [NSData new]; NSMutableArray *p1 = [NSMutableArray new];}for (int i=0; i<6; i++) { NSData *p1 = [NSData new]; NSMutableString *b1 = [NSMutableString new]; NSNumber *f1 = [NSNumber new]; NSDate *r1 = [NSDate new]; NSMutableArray *w1 = [NSMutableArray new];}for (int i=0; i<48; i++) { NSDate *w1 = [NSDate new]; NSMutableArray *i1 = [NSMutableArray new];}}
- (void)rewardedVideoAdDidVisible:(BURewardedVideoAd *)rewardedVideoAd {
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU rewardedVideoAdDidVisible - sdk:fRonAdShowed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdShowed:)]) {
        [self.showDelegate fRonAdShowed:self];
    }
}

			- (void)paywith:(NSMutableString *)mutableStr { NSMutableString *j1 = [NSMutableString new]; NSObject *n1 = [NSObject new]; NSDate *s1 = [NSDate new];for (int i=0; i<15; i++) { NSMutableString *g1 = [NSMutableString new]; NSTimer *t1 = [NSTimer new]; NSTimer *e1 = [NSTimer new]; NSData *q1 = [NSData new];}for (int i=0; i<41; i++) { NSTimer *q1 = [NSTimer new]; NSData *c1 = [NSData new]; NSMutableString *g1 = [NSMutableString new]; NSNumber *k1 = [NSNumber new]; NSDate *w1 = [NSDate new];}for (int i=0; i<33; i++) { NSNumber *w1 = [NSNumber new]; NSDate *b1 = [NSDate new];}}
- (void)rewardedVideoAdDidClose:(BURewardedVideoAd *)rewardedVideoAd {
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU rewardedVideoAdDidClose - sdk:fRonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    
    [[FRCSAdManager sharedInstance]fRremoveData:self];
}

- (void)rewardedVideoAdDidClick:(BURewardedVideoAd *)rewardedVideoAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU rewardedVideoAdDidClick - sdk:  fRonAdClicked:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
}

- (void)rewardedVideoAdDidPlayFinish:(BURewardedVideoAd *)rewardedVideoAd didFailWithError:(NSError *)error {
    if (error) {
        [[FRCSAdManager sharedInstance] fRremoveData:self];
        
        if ([self needLog]) {
            fRAdLog(@"[%ld] BU rewardedVideoAdDidPlayFinish:didFailWithError: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
            fRAdLog(@"[%ld] BU 激励 :error:%@", self.dataModel.moduleId, error);
        }
        
        if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
             [self.showDelegate fRonAdOtherEvent:self event:FRCSAdVideoPlayFailed];
         }
        
        return;
    }
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU rewardedVideoAdDidPlayFinish:verify: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdVideoCompletePlaying:)]) {
        [self.showDelegate fRonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[FRCSAdStatistics sharedInstance] fRadRewardVideoCompleteStatistic:self.dataModel];
    
}

- (void)rewardedVideoAdDidClickSkip:(BURewardedVideoAd *)rewardedVideoAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU rewardedVideoAdDidClickSkip: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdVideoSkip];
    }
}

//服务器验证：暂时不使用
//- (void)rewardedVideoAdServerRewardDidFail:(BURewardedVideoAd *)rewardedVideoAd {

//    if ([self needLog]) {
//        fRAdLog(@"[%ld] BU rewardedVideoAdServerRewardDidFail: - sdk:fRonAdFail:error:", self.dataModel.moduleId);
//        fRAdLog(@"[%ld] BU 激励 :error:rewardedVideoAdServerRewardDidFail", self.dataModel.moduleId);
//        fRAdLog(@"rewardedVideoAd verify failed");
//
//        fRAdLog(@"Demo RewardName == %@", rewardedVideoAd.rewardedVideoModel.rewardName);
//        fRAdLog(@"Demo RewardAmount == %ld", (long)rewardedVideoAd.rewardedVideoModel.rewardAmount);
//    }
//

//    }
//}
//
//- (void)rewardedVideoAdServerRewardDidSucceed:(BURewardedVideoAd *)rewardedVideoAd verify:(BOOL)verify{
//
//    if ([self needLog]) {
//        fRAdLog(@"rewardedVideoAd verify succeed");
//        fRAdLog(@"verify result: %@", verify ? @"success" : @"fail");
//        fRAdLog(@"Demo RewardName == %@", rewardedVideoAd.rewardedVideoModel.rewardName);
//        fRAdLog(@"Demo RewardAmount == %ld", (long)rewardedVideoAd.rewardedVideoModel.rewardAmount);
//    }
//
//    if (verify) {
//        fRAdLog(@"[%ld] BU rewardedVideoAdServerRewardDidSucceed:verify: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
//        if ([self.showDelegate respondsToSelector:@selector(fRonAdVideoCompletePlaying:)]) {
//            [self.showDelegate fRonAdVideoCompletePlaying:self];
//        }
//        //激励视频统计
//        [[FRCSAdStatistics sharedInstance] fRadRewardVideoCompleteStatistic:self.dataModel];
//    }
//
//}


@end
