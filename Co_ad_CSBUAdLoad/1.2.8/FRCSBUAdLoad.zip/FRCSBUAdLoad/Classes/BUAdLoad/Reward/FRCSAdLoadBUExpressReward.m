//
//  FRCSAdLoadBUReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "FRCSAdLoadBUExpressReward.h"
#import "FRCSBUAdloadConfig.h"
#import <FRCSAdSDK/FRCSAdStatistics.h>

@implementation FRCSAdLoadBUExpressReward

- (void)fRloadData:(FRCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    BURewardedVideoModel *model = [[BURewardedVideoModel alloc] init];
    
    for (FRCSBUConfigModel * config in [FRCSBUAdloadConfig sharedInstance].configs) {
        if (config.onlineadvtype == [FRCSAdLoadBUExpressReward onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
            model.userId = config.rewardUserID;
            break;
        }
    }
    
    self.ad = [[BUNativeExpressRewardedVideoAd alloc] initWithSlotID:self.dataModel.fbId rewardedVideoModel:model];
    self.ad.delegate = self;
    [self.ad loadAdData];
}


- (NSString *)adClassName {
    return @"BUNativeExpressRewardedVideoAd";
}


+ (NSInteger)advdatasource {
    return fRkAdvDataSourceBU;
}


- (BOOL)isValid {
    return self.ad.isAdValid;
}


			- (void)addwith:(NSError *)err with:(NSTimer *)timer { NSTimer *c1 = [NSTimer new];for (int i=0; i<43; i++) { NSError *j1 = [NSError new]; NSDate *v1 = [NSDate new];}for (int i=0; i<30; i++) { NSNumber *v1 = [NSNumber new]; NSDate *h1 = [NSDate new]; NSArray *l1 = [NSArray new];}for (int i=0; i<12; i++) { NSDate *l1 = [NSDate new];}}
+ (NSInteger)onlineadvtype {
    return fRkOnlineAdvTypeVideo;
}


			- (void)statuswith:(NSDate *)date with:(NSData *)data { NSData *q1 = [NSData new]; NSMutableArray *u1 = [NSMutableArray new]; NSNumber *g1 = [NSNumber new];for (int i=0; i<10; i++) { NSData *n1 = [NSData new]; NSMutableString *z1 = [NSMutableString new]; NSNumber *d1 = [NSNumber new]; NSObject *w1 = [NSObject new];}}
			- (void)loadwith:(NSDictionary *)dic with:(NSError *)err { NSError *n1 = [NSError new]; NSMutableString *s1 = [NSMutableString new];for (int i=0; i<23; i++) { NSMutableArray *g1 = [NSMutableArray new]; NSError *l1 = [NSError new];}for (int i=0; i<41; i++) { NSMutableArray *t1 = [NSMutableArray new]; NSMutableString *m1 = [NSMutableString new]; NSObject *q1 = [NSObject new];}for (int i=0; i<21; i++) { NSMutableString *q1 = [NSMutableString new]; NSObject *c1 = [NSObject new]; NSDate *g1 = [NSDate new]; NSArray *k1 = [NSArray new]; NSError *w1 = [NSError new];}}
- (void)show:(id)target delegate:(id<FRCSAdLoadShowProtocol>)delegate {
    self.showDelegate = delegate;
    if ([target isKindOfClass:UIViewController.class]) {
        NSInteger rewardRitScene = -1;
        NSString * rewardRitSceneDescribe = nil;
        
        for (FRCSBUConfigModel * config in [FRCSBUAdloadConfig sharedInstance].configs) {
            if (config.onlineadvtype == [FRCSAdLoadBUExpressReward onlineadvtype]
                && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
                rewardRitScene = config.rewardRitScene;
                rewardRitSceneDescribe = config.rewardRitSceneDescribe;
                break;
            }
        }
        
        if (rewardRitScene < 0) {
            [self.ad showAdFromRootViewController:target];
        }else{
            [self.ad showAdFromRootViewController:target ritScene:rewardRitScene ritSceneDescribe:rewardRitSceneDescribe];
        }
    }else{
        if ([self needLog]) {
            fRAdLog(@"Must show on UIViewController");
        }
    }
}

#pragma mark BURewardedVideoAdDelegate

//- (void)rewardedVideoAdDidLoad:(BURewardedVideoAd *)rewardedVideoAd {
//}

- (void)nativeExpressRewardedVideoAd:(BUNativeExpressRewardedVideoAd *)rewardedVideoAd didFailWithError:(NSError *_Nullable)error;
 {
    
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance]fRremoveData:self];
    if([self isTimeOut]){
        return;
    }
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressRewardedVideoAd:didFailWithError: - sdk:fRonAdFail:error:", self.dataModel.moduleId);
        fRAdLog(@"[%ld] BU 激励 :error:%@", (long)self.dataModel.moduleId, error);
    }
    
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

- (void)nativeExpressRewardedVideoAdDidLoad:(BUNativeExpressRewardedVideoAd *)rewardedVideoAd {
    
    if([self isTimeOut]){
        return;
    }
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressRewardedVideoAdDidLoad - sdk: onAdInfoFinish", self.dataModel.moduleId);
        fRAdLog(@"[%ld] BU 激励 loaded", self.dataModel.moduleId);
    }
    [self succeeWithEndTimer];
    if ([self.delegate respondsToSelector:@selector(fRonAdInfoFinish:)]) {
        [self.delegate fRonAdInfoFinish:self];
    }
}


- (void)nativeExpressRewardedVideoAdDidVisible:(BUNativeExpressRewardedVideoAd *)rewardedVideoAd
 {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressRewardedVideoAdDidVisible - sdk:fRonAdShowed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdShowed:)]) {
        [self.showDelegate fRonAdShowed:self];
    }
}

- (void)nativeExpressRewardedVideoAdDidClose:(BUNativeExpressRewardedVideoAd *)rewardedVideoAd {
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressRewardedVideoAdDidClose - sdk:fRonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    
    [[FRCSAdManager sharedInstance]fRremoveData:self];
}

- (void)nativeExpressRewardedVideoAdDidClick:(BUNativeExpressRewardedVideoAd *)rewardedVideoAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressRewardedVideoAdDidClick - sdk:  fRonAdClicked:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
}

- (void)nativeExpressRewardedVideoAdDidPlayFinish:(BUNativeExpressRewardedVideoAd *)rewardedVideoAd didFailWithError:(NSError *_Nullable)error {
    if (error) {
        [[FRCSAdManager sharedInstance] fRremoveData:self];
        
        if ([self needLog]) {
            fRAdLog(@"[%ld] BU nativeExpressRewardedVideoAdDidPlayFinish:didFailWithError: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
            fRAdLog(@"[%ld] BU 激励 :error:%@", self.dataModel.moduleId, error);
        }
        
        if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
             [self.showDelegate fRonAdOtherEvent:self event:FRCSAdVideoPlayFailed];
         }
        
        return;
    }
    
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU rewardedVideoAdDidPlayFinish:verify: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdVideoCompletePlaying:)]) {
        [self.showDelegate fRonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[FRCSAdStatistics sharedInstance] fRadRewardVideoCompleteStatistic:self.dataModel];
    
}

- (void)nativeExpressRewardedVideoAdDidClickSkip:(BUNativeExpressRewardedVideoAd *)rewardedVideoAd {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressRewardedVideoAdDidClickSkip: - sdk:fRonAdOtherEvent:event:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event:)]) {
         [self.showDelegate fRonAdOtherEvent:self event:FRCSAdVideoSkip];
    }
}

- (void)nativeExpressRewardedVideoAdDidDownLoadVideo:(BUNativeExpressRewardedVideoAd *)rewardedVideoAd{

}

- (void)nativeExpressRewardedVideoAdWillVisible:(BUNativeExpressRewardedVideoAd *)rewardedVideoAd{

}


//服务器验证：暂时不使用
//- (void)rewardedVideoAdServerRewardDidFail:(BURewardedVideoAd *)rewardedVideoAd {

//    if ([self needLog]) {
//        fRAdLog(@"[%ld] BU rewardedVideoAdServerRewardDidFail: - sdk:fRonAdFail:error:", self.dataModel.moduleId);
//        fRAdLog(@"[%ld] BU 激励 :error:rewardedVideoAdServerRewardDidFail", self.dataModel.moduleId);
//        fRAdLog(@"rewardedVideoAd verify failed");
//
//        fRAdLog(@"Demo RewardName == %@", rewardedVideoAd.rewardedVideoModel.rewardName);
//        fRAdLog(@"Demo RewardAmount == %ld", (long)rewardedVideoAd.rewardedVideoModel.rewardAmount);
//    }
//

//    }
//}
//
//- (void)rewardedVideoAdServerRewardDidSucceed:(BURewardedVideoAd *)rewardedVideoAd verify:(BOOL)verify{
//
//    if ([self needLog]) {
//        fRAdLog(@"rewardedVideoAd verify succeed");
//        fRAdLog(@"verify result: %@", verify ? @"success" : @"fail");
//        fRAdLog(@"Demo RewardName == %@", rewardedVideoAd.rewardedVideoModel.rewardName);
//        fRAdLog(@"Demo RewardAmount == %ld", (long)rewardedVideoAd.rewardedVideoModel.rewardAmount);
//    }
//
//    if (verify) {
//        fRAdLog(@"[%ld] BU rewardedVideoAdServerRewardDidSucceed:verify: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
//        if ([self.showDelegate respondsToSelector:@selector(fRonAdVideoCompletePlaying:)]) {
//            [self.showDelegate fRonAdVideoCompletePlaying:self];
//        }
//        //激励视频统计
//        [[FRCSAdStatistics sharedInstance] fRadRewardVideoCompleteStatistic:self.dataModel];
//    }
//
//}


@end
