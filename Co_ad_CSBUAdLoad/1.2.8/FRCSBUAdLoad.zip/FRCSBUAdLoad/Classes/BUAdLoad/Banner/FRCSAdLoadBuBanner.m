//
//  FRCSAdLoadBuBanner.m
//  FRCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import "FRCSAdLoadBuBanner.h"
#import "FRCSBUAdloadConfig.h"
#import <FRCSAdSDK/FRCSAdStatistics.h>

@interface FRCSAdLoadBuBanner()

@end

@implementation FRCSAdLoadBuBanner

- (void)closeAd{
    if ([self needLog]) {
        fRAdLog(@"[%ld] bu banner close SDK:fRonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    [self.ad removeFromSuperview];
}

- (NSString *)adClassName { 
    return @"BUNativeExpressBannerView";
}

+ (NSInteger)advdatasource { 
    return fRkAdvDataSourceBU;
}
- (void)fRloadData:(FRCSAdLoadCompleteBlock)csAdLoadCompleteBlock { 
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;

    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController * rootCtrl = nil;
        CGSize bannerSize = CGSizeMake(300, 150);
        NSInteger interval = nil;
        for (FRCSBUConfigModel *model in [FRCSBUAdloadConfig sharedInstance].configs) {
            if (model.onlineadvtype == fRkOnlineAdvTypeBanner
                && ([model.moudleID isEqualToString:self.dataModel.belongsMoudeId] || [model.moudleID isEqualToString:[NSString stringWithFormat:@"%ld", self.dataModel.moduleId]])) {
                rootCtrl = model.rootVC;
                bannerSize = model.adSize;
                interval = model.interval;
                break;
            }
        }

        if (rootCtrl == nil) {
            if ([self needLog]) {
                fRAdLog(@"Banner广告依赖的rootViewController 为空，请检查是否被释放或请调用 FRCSBUAdloadConfig里面关于Banner的配置方法");
            }
            csAdLoadCompleteBlock == nil ?:csAdLoadCompleteBlock(FRCSAdLoadFailure);
            return;
        }
        
        self.ad = [[BUNativeExpressBannerView alloc] initWithSlotID:self.dataModel.fbId rootViewController:rootCtrl adSize:bannerSize interval:interval];
        self.ad.delegate = self;
        self.ad.frame = CGRectMake(0, 0, bannerSize.width, bannerSize.height);
        [self.ad loadAdData];
    });
    
}

- (BOOL)isValid { 
    return self.ad != nil;
}

+ (NSInteger)onlineadvtype { 
    return fRkOnlineAdvTypeBanner;
}

			- (void)resetwith:(NSString *)str { NSString *n1 = [NSString new]; NSObject *r1 = [NSObject new]; NSDictionary *d1 = [NSDictionary new]; NSMutableArray *i1 = [NSMutableArray new]; NSNumber *m1 = [NSNumber new];for (int i=0; i<8; i++) { NSData *b1 = [NSData new];}for (int i=0; i<30; i++) { NSArray *j1 = [NSArray new];}}
- (void)show:(id)target delegate:(id<FRCSAdLoadShowProtocol>)delegate { 
    self.showDelegate = delegate;

    if ([target isKindOfClass:UIViewController.class]) {
        [[(UIViewController *)target view] addSubview:self.ad];
    } else if ([target isKindOfClass:UIView.class]) {
        [(UIView *)target addSubview:self.ad];
    } else {
        if ([self needLog]) {
            fRAdLog(@"BUBanner Must show on UIViewController or UIView");
        }
    }
}

#pragma mark - BUNativeExpressBannerViewDelegate
/**
广告加载成功回调
 */
-(void)nativeExpressBannerAdViewDidLoad:(BUNativeExpressBannerView *)bannerAdView {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU Banner nativeExpressBannerAdViewDidLoad", self.dataModel.moduleId);
    }
}

/**
广告加载失败的原因，
 */
- (void)nativeExpressBannerAdView:(BUNativeExpressBannerView *)bannerAdView didLoadFailWithError:(NSError *_Nullable)error {
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU Banner ad load failed", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

/**
 渲染成功回调
 在此回调方法中进行广告的展示，可保证播放流畅和展示流畅，用户体验更好。
 */
-(void)nativeExpressBannerAdViewRenderSuccess:(BUNativeExpressBannerView *)bannerAdView {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU Banner ad Render success", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdInfoFinish:)]) {
        [self.delegate fRonAdInfoFinish:self];
    }
    self.ad = bannerAdView;
    [self succeeWithEndTimer];
}

/**
 渲染失败，网络原因或者硬件原因导致渲染失败,可以更换手机或者网络环境测试。建议升级到穿山甲平台最新版本
 */
-(void)nativeExpressBannerAdViewRenderFail:(BUNativeExpressBannerView *)bannerAdView error:(NSError * __nullable)error {
    [self failureWithEndTimer];
    [[FRCSAdManager sharedInstance] fRremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU Banner ad Render failed", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(fRonAdFail:error:)]) {
        [self.delegate fRonAdFail:self error:error];
    }
}

/**
当显示新的广告时调用此方法
 */
-(void)nativeExpressBannerAdViewWillBecomVisible:(BUNativeExpressBannerView *)bannerAdView {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU Banner nativeExpressBannerAdViewWillBecomVisible SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(fRonAdShowed:)]) {
        [self.showDelegate fRonAdShowed:self];
    }
}

/**
点击回调
 */
-(void)nativeExpressBannerAdViewDidClick:(BUNativeExpressBannerView *)bannerAdView {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU splashAdDidClick - sdk:  fRonAdClicked:", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClicked:)]) {
        [self.showDelegate fRonAdClicked:self];
    }
}

/**
回调方法，需要在此回调方法中进行广告的移除操作，并将广告对象置为nil，如若不实现此回调方法，关闭按钮将不会生效
 */
-(void)nativeExpressBannerAdView:(BUNativeExpressBannerView *)bannerAdView dislikeWithReason:(NSArray<BUDislikeWords *> *_Nullable)filterwords {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressBannerAdView:dislikeWithReason: - sdk:fRonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdClosed:)]) {
        [self.showDelegate fRonAdClosed:self];
    }
    [[FRCSAdManager sharedInstance] fRremoveData:self]; 
    for (FRCSBUConfigModel *model in [FRCSBUAdloadConfig sharedInstance].configs) {
        
        if (model.onlineadvtype == fRkOnlineAdvTypeBanner
            && ([model.moudleID isEqualToString:self.dataModel.belongsMoudeId] || [model.moudleID isEqualToString:[NSString stringWithFormat:@"%ld", self.dataModel.moduleId]])) {
            [[FRCSBUAdloadConfig sharedInstance].configs removeObject:model];
            break;
        }
    }
    [self handleSplashDimiss:bannerAdView];
    
}

/**
 此回调在广告跳转到其他控制器时，该控制器被关闭时调用interactionType：此参数可区分是打开的appstore/网页/详情页面等等
 */
-(void)nativeExpressBannerAdViewDidCloseOtherController:(BUNativeExpressBannerView *)bannerAdView interactionType:(BUInteractionType)interactionType {
    if ([self needLog]) {
        fRAdLog(@"[%ld] BU nativeExpressBannerAdViewDidCloseOtherController - sdk:fRonAdOtherEvent", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(fRonAdOtherEvent:event::)]) {
        [self.showDelegate fRonAdOtherEvent:self event:FRCSAdBUBannerCloseOtherVC];
    }
}

- (void)handleSplashDimiss:(BUNativeExpressBannerView *)splashAd {
    [UIView animateWithDuration:0.25 animations:^{
        splashAd.alpha = 0;
    } completion:^(BOOL finished) {
        [splashAd removeFromSuperview];
        self.ad = nil;
    }];
}

@end
