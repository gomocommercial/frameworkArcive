//
//  CSCSAdLoadBUGlobalOpen.h
//  CSCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <CSCSAdSDK/CSCSAdLoadOpen.h>
#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSCSAdLoadBUGlobalOpen : CSCSAdLoadOpen<CSCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
