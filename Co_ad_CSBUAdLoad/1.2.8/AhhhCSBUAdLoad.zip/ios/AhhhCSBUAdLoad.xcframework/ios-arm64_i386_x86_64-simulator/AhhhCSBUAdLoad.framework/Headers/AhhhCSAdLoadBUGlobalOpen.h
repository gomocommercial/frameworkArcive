//
//  AhhhCSAdLoadBUGlobalOpen.h
//  AhhhCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadOpen.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadBUGlobalOpen : AhhhCSAdLoadOpen<AhhhCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
