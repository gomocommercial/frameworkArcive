//
//  PSCSAdLoadBuBanner.h
//  PSCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <PSCSAdSDK/PSCSAdLoadProtocol.h>
#import <PSCSAdSDK/PSCSAdLoadBanner.h>
#import <PSCSAdSDK/PSCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface PSCSAdLoadBuBanner : PSCSAdLoadBanner <BUNativeExpressBannerViewDelegate,PSCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

