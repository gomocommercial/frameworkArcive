//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PSCSAdSDK/PSCSAdLoadInterstitial.h>
#import <PSCSAdSDK/PSCSAdLoadProtocol.h>
#import <PSCSAdSDK/PSCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface PSCSAdLoadBUExpressInterstitialVideo : PSCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,PSCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
