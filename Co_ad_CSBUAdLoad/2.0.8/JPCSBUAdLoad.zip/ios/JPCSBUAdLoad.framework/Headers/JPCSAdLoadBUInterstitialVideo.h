//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <JPCSAdSDK/JPCSAdLoadInterstitial.h>
#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN
//TODO: 暂不使用
@interface JPCSAdLoadBUInterstitialVideo : JPCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,JPCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
