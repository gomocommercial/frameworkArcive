//
//  JPCSAdLoadBuBanner.h
//  JPCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadBanner.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface JPCSAdLoadBuBanner : JPCSAdLoadBanner <BUNativeExpressBannerViewDelegate,JPCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

