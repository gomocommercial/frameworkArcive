////
////  JPCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <JPCSAdSDK/JPCSAdLoadInterstitial.h>
//#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
//#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface JPCSAdLoadBUInterstitial : JPCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,JPCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
