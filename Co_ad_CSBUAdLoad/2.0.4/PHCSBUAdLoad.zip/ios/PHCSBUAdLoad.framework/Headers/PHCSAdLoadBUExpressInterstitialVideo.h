//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PHCSAdSDK/PHCSAdLoadInterstitial.h>
#import <PHCSAdSDK/PHCSAdLoadProtocol.h>
#import <PHCSAdSDK/PHCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface PHCSAdLoadBUExpressInterstitialVideo : PHCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,PHCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
