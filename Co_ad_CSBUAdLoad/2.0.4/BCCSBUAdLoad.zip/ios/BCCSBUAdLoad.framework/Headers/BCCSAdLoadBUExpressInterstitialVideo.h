//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <BCCSAdSDK/BCCSAdLoadInterstitial.h>
#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface BCCSAdLoadBUExpressInterstitialVideo : BCCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,BCCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
