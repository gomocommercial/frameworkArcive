//
//  MEETAICSAdLoadBuBanner.h
//  MEETAICSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <MEETAICSAdSDK/MEETAICSAdLoadProtocol.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadBanner.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface MEETAICSAdLoadBuBanner : MEETAICSAdLoadBanner <BUNativeExpressBannerViewDelegate,MEETAICSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

