//
//  MEETAICSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MEETAICSAdSDK/MEETAICSAdLoadReward.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadProtocol.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface MEETAICSAdLoadBUExpressReward : MEETAICSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,MEETAICSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
