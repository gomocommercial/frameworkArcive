//
//  DCCSBUBannerAdConfig.h
//  DCCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCCSBUBannerAdConfig : NSObject
//Banner专用
@property (nonatomic, assign) CGRect adFrame;
//轮播间隔 轮播间隔时间为30s～120s之间 默认为40秒
@property (nonatomic, assign) NSInteger interval;
//由于穿山甲banner初始化 必须传入一个rootVC, 否则关闭按钮不起作用, 所以请设置bannerRootVC, 请求和展示广告都在bannerRootVC上面, 关闭之后sdk会将bannerRootVC 置为空, 下次请求请重新设置 默认为空
@property (nonatomic, strong) UIViewController *bannerRootVC;
+ (instancetype)sharedInstance;
//初始化 banner配置
-(void)setBannerConfigWithAdSize:(CGRect)adFrame interval:(NSInteger)interval;
//设置显示位置时候使用
-(void)setBannerConfigAdSize:(CGRect)adFrame;
@end

NS_ASSUME_NONNULL_END
