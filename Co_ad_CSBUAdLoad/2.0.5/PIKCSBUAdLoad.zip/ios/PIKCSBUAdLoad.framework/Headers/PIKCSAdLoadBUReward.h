//
//  PIKCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PIKCSAdSDK/PIKCSAdLoadReward.h>
#import <PIKCSAdSDK/PIKCSAdLoadProtocol.h>
#import <PIKCSAdSDK/PIKCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PIKCSAdLoadBUReward : PIKCSAdLoadReward<BURewardedVideoAdDelegate,PIKCSAdLoadProtocol>

@property(nonatomic, strong) BURewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
