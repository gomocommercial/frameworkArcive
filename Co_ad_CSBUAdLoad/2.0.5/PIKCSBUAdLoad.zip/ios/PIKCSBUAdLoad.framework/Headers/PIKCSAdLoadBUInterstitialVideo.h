//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PIKCSAdSDK/PIKCSAdLoadInterstitial.h>
#import <PIKCSAdSDK/PIKCSAdLoadProtocol.h>
#import <PIKCSAdSDK/PIKCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN
//TODO: 暂不使用
@interface PIKCSAdLoadBUInterstitialVideo : PIKCSAdLoadInterstitial<BUFullscreenVideoAdDelegate,PIKCSAdLoadProtocol>
@property(nonatomic, strong) BUFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
