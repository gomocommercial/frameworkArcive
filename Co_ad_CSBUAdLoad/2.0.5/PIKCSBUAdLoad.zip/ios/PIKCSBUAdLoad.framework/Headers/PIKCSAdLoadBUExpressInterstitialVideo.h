//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PIKCSAdSDK/PIKCSAdLoadInterstitial.h>
#import <PIKCSAdSDK/PIKCSAdLoadProtocol.h>
#import <PIKCSAdSDK/PIKCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface PIKCSAdLoadBUExpressInterstitialVideo : PIKCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,PIKCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
