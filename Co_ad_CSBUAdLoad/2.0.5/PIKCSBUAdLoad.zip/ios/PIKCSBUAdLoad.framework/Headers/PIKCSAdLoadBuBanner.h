//
//  PIKCSAdLoadBuBanner.h
//  PIKCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <PIKCSAdSDK/PIKCSAdLoadProtocol.h>
#import <PIKCSAdSDK/PIKCSAdLoadBanner.h>
#import <PIKCSAdSDK/PIKCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface PIKCSAdLoadBuBanner : PIKCSAdLoadBanner <BUNativeExpressBannerViewDelegate,PIKCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

