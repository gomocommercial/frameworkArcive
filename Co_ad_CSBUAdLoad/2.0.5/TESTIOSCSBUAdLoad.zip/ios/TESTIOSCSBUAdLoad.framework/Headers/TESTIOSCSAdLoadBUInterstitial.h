////
////  TESTIOSCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadInterstitial.h>
//#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadProtocol.h>
//#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface TESTIOSCSAdLoadBUInterstitial : TESTIOSCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,TESTIOSCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
