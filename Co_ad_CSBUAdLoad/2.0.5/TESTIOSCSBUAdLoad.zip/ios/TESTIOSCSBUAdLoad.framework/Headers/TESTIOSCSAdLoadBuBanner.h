//
//  TESTIOSCSAdLoadBuBanner.h
//  TESTIOSCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadProtocol.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadBanner.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface TESTIOSCSAdLoadBuBanner : TESTIOSCSAdLoadBanner <BUNativeExpressBannerViewDelegate,TESTIOSCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

