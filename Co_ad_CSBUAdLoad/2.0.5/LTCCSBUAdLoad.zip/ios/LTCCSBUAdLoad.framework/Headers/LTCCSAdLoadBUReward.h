//
//  LTCCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <LTCCSAdSDK/LTCCSAdLoadReward.h>
#import <LTCCSAdSDK/LTCCSAdLoadProtocol.h>
#import <LTCCSAdSDK/LTCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface LTCCSAdLoadBUReward : LTCCSAdLoadReward<BURewardedVideoAdDelegate,LTCCSAdLoadProtocol>

@property(nonatomic, strong) BURewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
