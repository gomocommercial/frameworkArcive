//
//  LTCCSAdLoadBuBanner.h
//  LTCCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <LTCCSAdSDK/LTCCSAdLoadProtocol.h>
#import <LTCCSAdSDK/LTCCSAdLoadBanner.h>
#import <LTCCSAdSDK/LTCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface LTCCSAdLoadBuBanner : LTCCSAdLoadBanner <BUNativeExpressBannerViewDelegate,LTCCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

