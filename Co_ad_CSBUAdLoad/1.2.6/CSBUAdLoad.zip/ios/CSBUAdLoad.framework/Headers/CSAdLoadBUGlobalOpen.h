//
//  CSAdLoadBUGlobalOpen.h
//  CSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <CSAdSDK/CSAdLoadOpen.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadBUGlobalOpen : CSAdLoadOpen<CSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
