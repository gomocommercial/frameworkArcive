//
//  FaceVCSAdLoadBUGlobalOpen.h
//  FaceVCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <FaceVCSAdSDK/FaceVCSAdLoadOpen.h>
#import <FaceVCSAdSDK/FaceVCSAdLoadProtocol.h>
#import <FaceVCSAdSDK/FaceVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface FaceVCSAdLoadBUGlobalOpen : FaceVCSAdLoadOpen<FaceVCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
