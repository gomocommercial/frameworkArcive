//
//  LTCSAdLoadBuBanner.h
//  LTCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <LTCSAdSDK/LTCSAdLoadProtocol.h>
#import <LTCSAdSDK/LTCSAdLoadBanner.h>
#import <LTCSAdSDK/LTCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface LTCSAdLoadBuBanner : LTCSAdLoadBanner <BUNativeExpressBannerViewDelegate,LTCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

