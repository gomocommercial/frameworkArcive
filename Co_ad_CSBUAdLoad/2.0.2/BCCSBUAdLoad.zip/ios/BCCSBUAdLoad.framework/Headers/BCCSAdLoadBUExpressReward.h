//
//  BCCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <BCCSAdSDK/BCCSAdLoadReward.h>
#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface BCCSAdLoadBUExpressReward : BCCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,BCCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
