//
//  MBCSAdLoadBuBanner.h
//  MBCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <MBCSAdSDK/MBCSAdLoadProtocol.h>
#import <MBCSAdSDK/MBCSAdLoadBanner.h>
#import <MBCSAdSDK/MBCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface MBCSAdLoadBuBanner : MBCSAdLoadBanner <BUNativeExpressBannerViewDelegate,MBCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

