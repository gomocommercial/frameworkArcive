//
//  SVCSAdLoadBuBanner.h
//  SVCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <SVCSAdSDK/SVCSAdLoadProtocol.h>
#import <SVCSAdSDK/SVCSAdLoadBanner.h>
#import <SVCSAdSDK/SVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface SVCSAdLoadBuBanner : SVCSAdLoadBanner <BUNativeExpressBannerViewDelegate,SVCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

