//
//  SVCSAdLoadBUInterstitialVideo.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SVCSAdSDK/SVCSAdLoadInterstitial.h>
#import <SVCSAdSDK/SVCSAdLoadProtocol.h>
#import <SVCSAdSDK/SVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface SVCSAdLoadBUExpressInterstitialVideo : SVCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,SVCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
