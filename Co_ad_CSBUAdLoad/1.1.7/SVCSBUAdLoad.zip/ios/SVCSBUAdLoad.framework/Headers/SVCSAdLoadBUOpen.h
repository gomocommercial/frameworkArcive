//
//  SVCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <SVCSAdSDK/SVCSAdLoadOpen.h>
#import <SVCSAdSDK/SVCSAdLoadProtocol.h>
#import <SVCSAdSDK/SVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
#import <BUAdSDK/BUSplashAdView.h>

NS_ASSUME_NONNULL_BEGIN

@interface SVCSAdLoadBUOpen : SVCSAdLoadOpen<BUSplashAdDelegate,BUSplashZoomOutViewDelegate,SVCSAdLoadProtocol>

@property(nonatomic, strong) BUSplashAdView *ad;


@end

NS_ASSUME_NONNULL_END
