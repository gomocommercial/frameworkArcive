//
//  FLCSAdLoadBuBanner.h
//  FLCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <FLCSAdSDK/FLCSAdLoadProtocol.h>
#import <FLCSAdSDK/FLCSAdLoadBanner.h>
#import <FLCSAdSDK/FLCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface FLCSAdLoadBuBanner : FLCSAdLoadBanner <BUNativeExpressBannerViewDelegate,FLCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

