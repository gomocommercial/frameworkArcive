//
//  collagiosCSAdLoadBUInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <collagiosCSAdSDK/collagiosCSAdLoadInterstitial.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadProtocol.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface collagiosCSAdLoadBUInterstitial : collagiosCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,collagiosCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
