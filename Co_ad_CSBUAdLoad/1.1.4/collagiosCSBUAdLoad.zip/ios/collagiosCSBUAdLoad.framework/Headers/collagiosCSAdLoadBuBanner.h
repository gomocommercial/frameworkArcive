//
//  collagiosCSAdLoadBuBanner.h
//  collagiosCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <collagiosCSAdSDK/collagiosCSAdLoadProtocol.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadBanner.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface collagiosCSAdLoadBuBanner : collagiosCSAdLoadBanner <BUNativeExpressBannerViewDelegate,collagiosCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

