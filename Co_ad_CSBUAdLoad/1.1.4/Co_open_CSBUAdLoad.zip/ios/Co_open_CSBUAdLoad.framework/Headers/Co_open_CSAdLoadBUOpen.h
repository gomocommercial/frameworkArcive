//
//  Co_open_CSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <Co_open_CSAdSDK/Co_open_CSAdLoadOpen.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadProtocol.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
#import <BUAdSDK/BUSplashAdView.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_open_CSAdLoadBUOpen : Co_open_CSAdLoadOpen<BUSplashAdDelegate,BUSplashZoomOutViewDelegate,Co_open_CSAdLoadProtocol>

@property(nonatomic, strong) BUSplashAdView *ad;


@end

NS_ASSUME_NONNULL_END
