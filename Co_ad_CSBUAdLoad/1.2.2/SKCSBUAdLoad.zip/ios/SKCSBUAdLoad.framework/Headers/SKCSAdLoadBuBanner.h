//
//  SKCSAdLoadBuBanner.h
//  SKCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <SKCSAdSDK/SKCSAdLoadProtocol.h>
#import <SKCSAdSDK/SKCSAdLoadBanner.h>
#import <SKCSAdSDK/SKCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface SKCSAdLoadBuBanner : SKCSAdLoadBanner <BUNativeExpressBannerViewDelegate,SKCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

