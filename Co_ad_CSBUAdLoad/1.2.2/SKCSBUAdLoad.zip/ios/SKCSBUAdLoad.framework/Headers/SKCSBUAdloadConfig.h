//
//  SKCSBUAdloadConfig.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BUAdSDK/BUAdSDK.h>
#import "SKCSBUConfigModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SKCSBUAdloadConfig : NSObject

@property (nonatomic, strong, readonly) NSMutableArray<SKCSBUConfigModel *> *configs;

+ (instancetype)sharedInstance;
// MARK: - 激励视频展示配置 必须配置

+ (void)setRewardConfigWithMoudleId:(NSString *)modudleID userID:(NSString *)userID;

+ (void)setRewardConfigWithMoudleId:(NSString *)modudleID userID:(NSString *)userID ritScene:(BURitSceneType)ritScene ritSceneDescribe:(NSString * _Nullable)ritSceneDescribe;

// MARK: -  插屏配置 必需配置
+ (void)setInterstitialConfigWithMoudleId:(NSString *)modudleID adSize:(CGSize)adSize;

// MARK: - 插屏视频配置 可选配置
+ (void)setInterstitialVideoConfigWithMoudleId:(NSString *)modudleID ritSceneDescribe:(NSString * _Nullable)ritSceneDescribe;

// MARK: - Banner配置 必须配置 每次请求Banner的之前时候配置, 每次请求之前都需要配置, 如果需要显示不同的banner尺寸和位置, 请使用不用的modudleID, 一个modudleID只能对应一个rootVC和adSize
//interval轮播间隔 轮播间隔时间为30s～120s之间 默认为40秒, 请设置大于30秒的值
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID rootViewController:(UIViewController *)rootVC AdSize:(CGSize)adSize interval:(NSInteger)interval;
//移除Banner配置, 目的是解决循环引用的问题
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID;
@end

NS_ASSUME_NONNULL_END
