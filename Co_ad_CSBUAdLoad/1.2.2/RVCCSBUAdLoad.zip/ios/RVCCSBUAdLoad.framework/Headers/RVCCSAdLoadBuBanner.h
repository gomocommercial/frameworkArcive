//
//  RVCCSAdLoadBuBanner.h
//  RVCCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <RVCCSAdSDK/RVCCSAdLoadProtocol.h>
#import <RVCCSAdSDK/RVCCSAdLoadBanner.h>
#import <RVCCSAdSDK/RVCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface RVCCSAdLoadBuBanner : RVCCSAdLoadBanner <BUNativeExpressBannerViewDelegate,RVCCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

