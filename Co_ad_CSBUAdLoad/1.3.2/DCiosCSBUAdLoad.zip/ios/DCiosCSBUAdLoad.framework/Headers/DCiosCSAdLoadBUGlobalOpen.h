//
//  DCiosCSAdLoadBUGlobalOpen.h
//  DCiosCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <DCiosCSAdSDK/DCiosCSAdLoadOpen.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadProtocol.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCiosCSAdLoadBUGlobalOpen : DCiosCSAdLoadOpen<DCiosCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
