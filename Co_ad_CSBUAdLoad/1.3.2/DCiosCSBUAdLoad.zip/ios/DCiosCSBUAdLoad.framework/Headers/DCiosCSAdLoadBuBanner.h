//
//  DCiosCSAdLoadBuBanner.h
//  DCiosCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <DCiosCSAdSDK/DCiosCSAdLoadProtocol.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadBanner.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface DCiosCSAdLoadBuBanner : DCiosCSAdLoadBanner <BUNativeExpressBannerViewDelegate,DCiosCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

