//
//  SWCSAdLoadBuBanner.h
//  SWCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadBanner.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface SWCSAdLoadBuBanner : SWCSAdLoadBanner <BUNativeExpressBannerViewDelegate,SWCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

