//
//  SWCSAdLoadBUGlobalOpen.h
//  SWCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <SWCSAdSDK/SWCSAdLoadOpen.h>
#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface SWCSAdLoadBUGlobalOpen : SWCSAdLoadOpen<SWCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
