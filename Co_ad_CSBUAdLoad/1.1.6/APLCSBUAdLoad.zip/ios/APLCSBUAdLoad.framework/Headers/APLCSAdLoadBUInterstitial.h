//
//  APLCSAdLoadBUInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <APLCSAdSDK/APLCSAdLoadInterstitial.h>
#import <APLCSAdSDK/APLCSAdLoadProtocol.h>
#import <APLCSAdSDK/APLCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface APLCSAdLoadBUInterstitial : APLCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,APLCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
