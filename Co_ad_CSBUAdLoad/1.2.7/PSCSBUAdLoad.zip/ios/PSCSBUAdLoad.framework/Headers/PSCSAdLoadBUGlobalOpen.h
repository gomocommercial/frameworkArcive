//
//  PSCSAdLoadBUGlobalOpen.h
//  PSCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <PSCSAdSDK/PSCSAdLoadOpen.h>
#import <PSCSAdSDK/PSCSAdLoadProtocol.h>
#import <PSCSAdSDK/PSCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSCSAdLoadBUGlobalOpen : PSCSAdLoadOpen<PSCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
