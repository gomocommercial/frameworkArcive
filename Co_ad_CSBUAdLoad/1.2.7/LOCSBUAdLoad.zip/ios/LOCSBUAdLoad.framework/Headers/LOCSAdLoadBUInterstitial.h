//
//  LOCSAdLoadBUInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <LOCSAdSDK/LOCSAdLoadInterstitial.h>
#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdLoadBUInterstitial : LOCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,LOCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
