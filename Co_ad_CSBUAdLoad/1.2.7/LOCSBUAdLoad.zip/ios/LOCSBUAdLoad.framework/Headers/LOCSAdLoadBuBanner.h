//
//  LOCSAdLoadBuBanner.h
//  LOCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadBanner.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface LOCSAdLoadBuBanner : LOCSAdLoadBanner <BUNativeExpressBannerViewDelegate,LOCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

