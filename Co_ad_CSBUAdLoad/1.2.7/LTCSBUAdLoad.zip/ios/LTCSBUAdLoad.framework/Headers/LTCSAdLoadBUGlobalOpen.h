//
//  LTCSAdLoadBUGlobalOpen.h
//  LTCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <LTCSAdSDK/LTCSAdLoadOpen.h>
#import <LTCSAdSDK/LTCSAdLoadProtocol.h>
#import <LTCSAdSDK/LTCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface LTCSAdLoadBUGlobalOpen : LTCSAdLoadOpen<LTCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
