//
//  Co_ad_CSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadReward.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadProtocol.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdLoadBUExpressReward : Co_ad_CSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,Co_ad_CSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
