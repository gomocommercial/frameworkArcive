//
//  SLCSAdLoadBuBanner.h
//  SLCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadBanner.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface SLCSAdLoadBuBanner : SLCSAdLoadBanner <BUNativeExpressBannerViewDelegate,SLCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

