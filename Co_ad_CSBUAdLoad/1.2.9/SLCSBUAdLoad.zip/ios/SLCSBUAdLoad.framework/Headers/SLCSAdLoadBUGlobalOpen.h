//
//  SLCSAdLoadBUGlobalOpen.h
//  SLCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <SLCSAdSDK/SLCSAdLoadOpen.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadBUGlobalOpen : SLCSAdLoadOpen<SLCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
