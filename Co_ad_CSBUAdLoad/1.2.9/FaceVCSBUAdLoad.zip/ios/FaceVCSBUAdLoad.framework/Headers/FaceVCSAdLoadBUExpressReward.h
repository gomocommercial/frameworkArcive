//
//  FaceVCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FaceVCSAdSDK/FaceVCSAdLoadReward.h>
#import <FaceVCSAdSDK/FaceVCSAdLoadProtocol.h>
#import <FaceVCSAdSDK/FaceVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface FaceVCSAdLoadBUExpressReward : FaceVCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,FaceVCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
