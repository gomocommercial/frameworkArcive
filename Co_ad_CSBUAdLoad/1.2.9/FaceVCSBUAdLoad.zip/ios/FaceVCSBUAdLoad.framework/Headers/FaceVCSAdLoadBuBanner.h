//
//  FaceVCSAdLoadBuBanner.h
//  FaceVCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <FaceVCSAdSDK/FaceVCSAdLoadProtocol.h>
#import <FaceVCSAdSDK/FaceVCSAdLoadBanner.h>
#import <FaceVCSAdSDK/FaceVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface FaceVCSAdLoadBuBanner : FaceVCSAdLoadBanner <BUNativeExpressBannerViewDelegate,FaceVCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

