//
//  AhhhCSAdLoadBuBanner.h
//  AhhhCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadBanner.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface AhhhCSAdLoadBuBanner : AhhhCSAdLoadBanner <BUNativeExpressBannerViewDelegate,AhhhCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

