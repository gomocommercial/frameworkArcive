//
//  FRCSAdLoadBUGlobalOpen.h
//  FRCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <FRCSAdSDK/FRCSAdLoadOpen.h>
#import <FRCSAdSDK/FRCSAdLoadProtocol.h>
#import <FRCSAdSDK/FRCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface FRCSAdLoadBUGlobalOpen : FRCSAdLoadOpen<FRCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
