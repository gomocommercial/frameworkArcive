//
//  HOCSAdLoadBUGlobalOpen.h
//  HOCSBUAdLoad
//
//  Created by lv jiaxing on 2022/4/28.
//

#import <HOCSAdSDK/HOCSAdLoadOpen.h>
#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface HOCSAdLoadBUGlobalOpen : HOCSAdLoadOpen<HOCSAdLoadProtocol,BUAppOpenAdDelegate>

@property (nonatomic, strong) BUAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
