//
//  HOCSAdLoadBUInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <HOCSAdSDK/HOCSAdLoadInterstitial.h>
#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface HOCSAdLoadBUInterstitial : HOCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,HOCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
