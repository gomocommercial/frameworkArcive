//
//  HOCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <HOCSAdSDK/HOCSAdLoadOpen.h>
#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface HOCSAdLoadBUOpen : HOCSAdLoadOpen<HOCSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
