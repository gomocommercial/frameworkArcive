//
//  HOCSAdLoadBuBanner.h
//  HOCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
#import <HOCSAdSDK/HOCSAdLoadBanner.h>
#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface HOCSAdLoadBuBanner : HOCSAdLoadBanner <BUNativeExpressBannerViewDelegate,HOCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

