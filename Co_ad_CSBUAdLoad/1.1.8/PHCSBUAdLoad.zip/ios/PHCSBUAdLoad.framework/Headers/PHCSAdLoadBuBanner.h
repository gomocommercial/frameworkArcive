//
//  PHCSAdLoadBuBanner.h
//  PHCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <PHCSAdSDK/PHCSAdLoadProtocol.h>
#import <PHCSAdSDK/PHCSAdLoadBanner.h>
#import <PHCSAdSDK/PHCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface PHCSAdLoadBuBanner : PHCSAdLoadBanner <BUNativeExpressBannerViewDelegate,PHCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

