//
//  AKCSAdLoadBuBanner.h
//  AKCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <AKCSAdSDK/AKCSAdLoadProtocol.h>
#import <AKCSAdSDK/AKCSAdLoadBanner.h>
#import <AKCSAdSDK/AKCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface AKCSAdLoadBuBanner : AKCSAdLoadBanner <BUNativeExpressBannerViewDelegate,AKCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

