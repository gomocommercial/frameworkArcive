//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FFCSAdSDK/FFCSAdLoadInterstitial.h>
#import <FFCSAdSDK/FFCSAdLoadProtocol.h>
#import <FFCSAdSDK/FFCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdLoadBUInterstitialVideo : FFCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,FFCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
