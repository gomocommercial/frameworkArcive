//
//  FFCSAdLoadBuBanner.h
//  FFCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <FFCSAdSDK/FFCSAdLoadProtocol.h>
#import <FFCSAdSDK/FFCSAdLoadBanner.h>
#import <FFCSAdSDK/FFCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface FFCSAdLoadBuBanner : FFCSAdLoadBanner <BUNativeExpressBannerViewDelegate,FFCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

