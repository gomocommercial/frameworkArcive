////
////  FFCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <FFCSAdSDK/FFCSAdLoadInterstitial.h>
//#import <FFCSAdSDK/FFCSAdLoadProtocol.h>
//#import <FFCSAdSDK/FFCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface FFCSAdLoadBUInterstitial : FFCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,FFCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
