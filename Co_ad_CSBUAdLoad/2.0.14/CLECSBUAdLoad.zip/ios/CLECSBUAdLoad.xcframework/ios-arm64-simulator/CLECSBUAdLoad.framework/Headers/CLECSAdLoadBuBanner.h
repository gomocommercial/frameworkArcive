//
//  CLECSAdLoadBuBanner.h
//  CLECSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <CLECSAdSDK/CLECSAdLoadProtocol.h>
#import <CLECSAdSDK/CLECSAdLoadBanner.h>
#import <CLECSAdSDK/CLECSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface CLECSAdLoadBuBanner : CLECSAdLoadBanner <BUNativeExpressBannerViewDelegate,CLECSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

