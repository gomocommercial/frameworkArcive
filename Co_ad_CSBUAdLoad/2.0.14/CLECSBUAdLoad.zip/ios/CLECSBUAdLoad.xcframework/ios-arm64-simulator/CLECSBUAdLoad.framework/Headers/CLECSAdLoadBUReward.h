//
//  CLECSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CLECSAdSDK/CLECSAdLoadReward.h>
#import <CLECSAdSDK/CLECSAdLoadProtocol.h>
#import <CLECSAdSDK/CLECSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLECSAdLoadBUReward : CLECSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,CLECSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
