////
////  CLECSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <CLECSAdSDK/CLECSAdLoadInterstitial.h>
//#import <CLECSAdSDK/CLECSAdLoadProtocol.h>
//#import <CLECSAdSDK/CLECSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface CLECSAdLoadBUInterstitial : CLECSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,CLECSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
