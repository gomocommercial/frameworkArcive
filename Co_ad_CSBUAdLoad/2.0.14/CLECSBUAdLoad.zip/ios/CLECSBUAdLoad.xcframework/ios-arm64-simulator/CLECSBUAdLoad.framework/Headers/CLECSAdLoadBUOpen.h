//
//  CLECSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <CLECSAdSDK/CLECSAdLoadOpen.h>
#import <CLECSAdSDK/CLECSAdLoadProtocol.h>
#import <CLECSAdSDK/CLECSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLECSAdLoadBUOpen : CLECSAdLoadOpen<CLECSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
