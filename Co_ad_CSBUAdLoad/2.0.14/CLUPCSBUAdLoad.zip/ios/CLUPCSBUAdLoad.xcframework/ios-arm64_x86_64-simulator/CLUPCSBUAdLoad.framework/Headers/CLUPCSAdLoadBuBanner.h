//
//  CLUPCSAdLoadBuBanner.h
//  CLUPCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <CLUPCSAdSDK/CLUPCSAdLoadProtocol.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadBanner.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface CLUPCSAdLoadBuBanner : CLUPCSAdLoadBanner <BUNativeExpressBannerViewDelegate,CLUPCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

