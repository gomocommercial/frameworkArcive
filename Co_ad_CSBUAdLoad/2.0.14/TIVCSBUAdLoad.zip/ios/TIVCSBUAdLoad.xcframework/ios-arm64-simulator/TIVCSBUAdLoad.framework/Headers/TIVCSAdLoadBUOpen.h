//
//  TIVCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <TIVCSAdSDK/TIVCSAdLoadOpen.h>
#import <TIVCSAdSDK/TIVCSAdLoadProtocol.h>
#import <TIVCSAdSDK/TIVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdLoadBUOpen : TIVCSAdLoadOpen<TIVCSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
