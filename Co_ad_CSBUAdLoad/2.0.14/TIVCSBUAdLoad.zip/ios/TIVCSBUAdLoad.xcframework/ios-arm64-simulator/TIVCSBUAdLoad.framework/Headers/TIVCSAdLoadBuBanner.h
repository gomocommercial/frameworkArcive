//
//  TIVCSAdLoadBuBanner.h
//  TIVCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <TIVCSAdSDK/TIVCSAdLoadProtocol.h>
#import <TIVCSAdSDK/TIVCSAdLoadBanner.h>
#import <TIVCSAdSDK/TIVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface TIVCSAdLoadBuBanner : TIVCSAdLoadBanner <BUNativeExpressBannerViewDelegate,TIVCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

