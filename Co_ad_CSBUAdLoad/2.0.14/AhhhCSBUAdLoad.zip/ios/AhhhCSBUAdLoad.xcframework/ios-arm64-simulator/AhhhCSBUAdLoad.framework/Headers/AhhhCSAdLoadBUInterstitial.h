////
////  AhhhCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <AhhhCSAdSDK/AhhhCSAdLoadInterstitial.h>
//#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
//#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface AhhhCSAdLoadBUInterstitial : AhhhCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,AhhhCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
