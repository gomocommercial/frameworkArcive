////
////  HPFCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <HPFCSAdSDK/HPFCSAdLoadInterstitial.h>
//#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
//#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface HPFCSAdLoadBUInterstitial : HPFCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,HPFCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
