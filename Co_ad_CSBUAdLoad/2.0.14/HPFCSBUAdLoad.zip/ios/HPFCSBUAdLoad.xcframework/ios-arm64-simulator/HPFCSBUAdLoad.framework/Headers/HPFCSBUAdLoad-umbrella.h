#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "HPFCSAdLoadBuBanner.h"
#import "HPFCSBUAdloadConfig.h"
#import "HPFCSBUConfigModel.h"
#import "HPFCSBUOpenAdConfig.h"
#import "HPFCSAdLoadBUExpressInterstitialVideo.h"
#import "HPFCSAdLoadBUInterstitial.h"
#import "HPFCSAdLoadBUInterstitialVideo.h"
#import "HPFCSAdLoadBUOpen.h"
#import "HPFCSAdLoadBUExpressReward.h"
#import "HPFCSAdLoadBUReward.h"

FOUNDATION_EXPORT double HPFCSBUAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char HPFCSBUAdLoadVersionString[];

