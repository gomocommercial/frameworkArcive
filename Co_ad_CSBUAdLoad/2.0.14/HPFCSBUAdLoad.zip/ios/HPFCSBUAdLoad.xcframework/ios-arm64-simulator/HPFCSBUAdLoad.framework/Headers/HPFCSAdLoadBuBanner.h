//
//  HPFCSAdLoadBuBanner.h
//  HPFCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadBanner.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface HPFCSAdLoadBuBanner : HPFCSAdLoadBanner <BUNativeExpressBannerViewDelegate,HPFCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

