//
//  HPFCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <HPFCSAdSDK/HPFCSAdLoadOpen.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadBUOpen : HPFCSAdLoadOpen<HPFCSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
