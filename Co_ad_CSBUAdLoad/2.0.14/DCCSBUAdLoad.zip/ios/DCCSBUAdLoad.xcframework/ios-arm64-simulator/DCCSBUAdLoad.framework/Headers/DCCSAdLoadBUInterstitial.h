////
////  DCCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <DCCSAdSDK/DCCSAdLoadInterstitial.h>
//#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
//#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface DCCSAdLoadBUInterstitial : DCCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,DCCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
