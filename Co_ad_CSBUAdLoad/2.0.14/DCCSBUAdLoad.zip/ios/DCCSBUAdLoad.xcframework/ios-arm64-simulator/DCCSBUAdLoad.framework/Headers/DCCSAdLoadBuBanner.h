//
//  DCCSAdLoadBuBanner.h
//  DCCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadBanner.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface DCCSAdLoadBuBanner : DCCSAdLoadBanner <BUNativeExpressBannerViewDelegate,DCCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

