////
////  LUMCSAdLoadBUInterstitial.h
////  CSAdSDK_Example
////
////  Created by Zy on 2019/10/9.
////  Copyright © 2019 dengnengwei. All rights reserved.
////
//
//#import <LUMCSAdSDK/LUMCSAdLoadInterstitial.h>
//#import <LUMCSAdSDK/LUMCSAdLoadProtocol.h>
//#import <LUMCSAdSDK/LUMCSAdLoadShowProtocol.h>
//#import <BUAdSDK/BUAdSDK.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface LUMCSAdLoadBUInterstitial : LUMCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,LUMCSAdLoadProtocol>
//
//@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;
//
//@end
//
//NS_ASSUME_NONNULL_END
