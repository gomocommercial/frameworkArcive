//
//  LUMCSAdLoadBuBanner.h
//  LUMCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <LUMCSAdSDK/LUMCSAdLoadProtocol.h>
#import <LUMCSAdSDK/LUMCSAdLoadBanner.h>
#import <LUMCSAdSDK/LUMCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface LUMCSAdLoadBuBanner : LUMCSAdLoadBanner <BUNativeExpressBannerViewDelegate,LUMCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

