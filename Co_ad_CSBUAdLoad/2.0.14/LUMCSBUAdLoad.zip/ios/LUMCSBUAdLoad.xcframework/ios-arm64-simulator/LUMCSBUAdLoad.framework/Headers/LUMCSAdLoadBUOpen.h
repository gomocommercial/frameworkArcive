//
//  LUMCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <LUMCSAdSDK/LUMCSAdLoadOpen.h>
#import <LUMCSAdSDK/LUMCSAdLoadProtocol.h>
#import <LUMCSAdSDK/LUMCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface LUMCSAdLoadBUOpen : LUMCSAdLoadOpen<LUMCSAdLoadProtocol,BUSplashAdDelegate, BUSplashCardDelegate, BUSplashZoomOutDelegate>

@property(nonatomic, strong) BUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
