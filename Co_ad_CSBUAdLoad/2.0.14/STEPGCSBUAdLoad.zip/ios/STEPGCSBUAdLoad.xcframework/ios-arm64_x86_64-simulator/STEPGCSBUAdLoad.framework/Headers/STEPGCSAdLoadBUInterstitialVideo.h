//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <STEPGCSAdSDK/STEPGCSAdLoadInterstitial.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadProtocol.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface STEPGCSAdLoadBUInterstitialVideo : STEPGCSAdLoadInterstitial<BUNativeExpressFullscreenVideoAdDelegate,STEPGCSAdLoadProtocol>
@property(nonatomic, strong) BUNativeExpressFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
