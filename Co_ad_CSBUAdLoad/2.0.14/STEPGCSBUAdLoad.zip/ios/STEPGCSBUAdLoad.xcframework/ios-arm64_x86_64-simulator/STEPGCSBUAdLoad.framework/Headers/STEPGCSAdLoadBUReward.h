//
//  STEPGCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <STEPGCSAdSDK/STEPGCSAdLoadReward.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadProtocol.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STEPGCSAdLoadBUReward : STEPGCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,STEPGCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
