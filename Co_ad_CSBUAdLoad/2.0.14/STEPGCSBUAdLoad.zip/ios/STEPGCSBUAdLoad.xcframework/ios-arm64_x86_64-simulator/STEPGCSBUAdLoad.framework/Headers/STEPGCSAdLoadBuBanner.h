//
//  STEPGCSAdLoadBuBanner.h
//  STEPGCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <STEPGCSAdSDK/STEPGCSAdLoadProtocol.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadBanner.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface STEPGCSAdLoadBuBanner : STEPGCSAdLoadBanner <BUNativeExpressBannerViewDelegate,STEPGCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

