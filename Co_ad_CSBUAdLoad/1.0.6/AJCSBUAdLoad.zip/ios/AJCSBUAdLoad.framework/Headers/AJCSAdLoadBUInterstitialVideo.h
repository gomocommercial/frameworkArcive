//
//  AJCSAdLoadBUInterstitialVideo.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AJCSAdSDK/AJCSAdLoadInterstitial.h>
#import <AJCSAdSDK/AJCSAdLoadProtocol.h>
#import <AJCSAdSDK/AJCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface AJCSAdLoadBUInterstitialVideo : AJCSAdLoadInterstitial<BUFullscreenVideoAdDelegate,AJCSAdLoadProtocol>
@property(nonatomic, strong) BUFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
