//
//  AJCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AJCSAdSDK/AJCSAdLoadReward.h>
#import <AJCSAdSDK/AJCSAdLoadProtocol.h>
#import <AJCSAdSDK/AJCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AJCSAdLoadBUReward : AJCSAdLoadReward<BURewardedVideoAdDelegate,AJCSAdLoadProtocol>

@property(nonatomic, strong) BURewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
