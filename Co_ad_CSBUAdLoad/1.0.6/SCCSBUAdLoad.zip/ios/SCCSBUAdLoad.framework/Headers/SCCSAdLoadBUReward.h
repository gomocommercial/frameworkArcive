//
//  SCCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SCCSAdSDK/SCCSAdLoadReward.h>
#import <SCCSAdSDK/SCCSAdLoadProtocol.h>
#import <SCCSAdSDK/SCCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface SCCSAdLoadBUReward : SCCSAdLoadReward<BURewardedVideoAdDelegate,SCCSAdLoadProtocol>

@property(nonatomic, strong) BURewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
