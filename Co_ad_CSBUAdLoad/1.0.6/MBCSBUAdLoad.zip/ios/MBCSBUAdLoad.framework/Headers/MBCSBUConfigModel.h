//
//  MBCSBUConfigModel.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface MBCSBUConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;

@property (nonatomic, copy) NSString *rewardUserID;
@property (nonatomic, assign) BURitSceneType rewardRitScene;
@property (nonatomic, copy) NSString *rewardRitSceneDescribe;
@property (nonatomic, assign) CGSize interstitialAdSize;
@property (nonatomic, strong) BUSize *interstitialBUSize;
@property (nonatomic, copy) NSString *interstitialSceneDescirbe;

@end

NS_ASSUME_NONNULL_END
