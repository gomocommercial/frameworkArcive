//
//  FXiosCSAdLoadBuBanner.h
//  FXiosCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <FXiosCSAdSDK/FXiosCSAdLoadProtocol.h>
#import <FXiosCSAdSDK/FXiosCSAdLoadBanner.h>
#import <FXiosCSAdSDK/FXiosCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface FXiosCSAdLoadBuBanner : FXiosCSAdLoadBanner <BUNativeExpressBannerViewDelegate,FXiosCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

