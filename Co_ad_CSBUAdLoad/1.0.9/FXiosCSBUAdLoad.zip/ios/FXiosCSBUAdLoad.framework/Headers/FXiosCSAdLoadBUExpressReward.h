//
//  FXiosCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FXiosCSAdSDK/FXiosCSAdLoadReward.h>
#import <FXiosCSAdSDK/FXiosCSAdLoadProtocol.h>
#import <FXiosCSAdSDK/FXiosCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface FXiosCSAdLoadBUExpressReward : FXiosCSAdLoadReward<BUNativeExpressRewardedVideoAdDelegate,FXiosCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressRewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
