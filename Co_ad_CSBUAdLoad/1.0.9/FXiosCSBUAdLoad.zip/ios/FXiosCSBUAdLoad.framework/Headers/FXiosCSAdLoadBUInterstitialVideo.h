//
//  FXiosCSAdLoadBUInterstitialVideo.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FXiosCSAdSDK/FXiosCSAdLoadInterstitial.h>
#import <FXiosCSAdSDK/FXiosCSAdLoadProtocol.h>
#import <FXiosCSAdSDK/FXiosCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface FXiosCSAdLoadBUInterstitialVideo : FXiosCSAdLoadInterstitial<BUFullscreenVideoAdDelegate,FXiosCSAdLoadProtocol>
@property(nonatomic, strong) BUFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
