//
//  WACSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <WACSAdSDK/WACSAdLoadOpen.h>
#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
#import <BUAdSDK/BUSplashAdView.h>

NS_ASSUME_NONNULL_BEGIN

@interface WACSAdLoadBUOpen : WACSAdLoadOpen<BUSplashAdDelegate,BUSplashZoomOutViewDelegate,WACSAdLoadProtocol>

@property(nonatomic, strong) BUSplashAdView *ad;


@end

NS_ASSUME_NONNULL_END
