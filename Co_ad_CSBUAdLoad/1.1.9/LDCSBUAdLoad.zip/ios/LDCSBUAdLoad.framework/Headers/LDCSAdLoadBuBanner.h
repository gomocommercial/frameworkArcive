//
//  LDCSAdLoadBuBanner.h
//  LDCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <LDCSAdSDK/LDCSAdLoadProtocol.h>
#import <LDCSAdSDK/LDCSAdLoadBanner.h>
#import <LDCSAdSDK/LDCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface LDCSAdLoadBuBanner : LDCSAdLoadBanner <BUNativeExpressBannerViewDelegate,LDCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

