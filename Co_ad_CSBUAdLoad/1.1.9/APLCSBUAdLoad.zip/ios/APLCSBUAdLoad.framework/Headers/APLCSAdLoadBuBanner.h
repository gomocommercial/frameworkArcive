//
//  APLCSAdLoadBuBanner.h
//  APLCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <APLCSAdSDK/APLCSAdLoadProtocol.h>
#import <APLCSAdSDK/APLCSAdLoadBanner.h>
#import <APLCSAdSDK/APLCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface APLCSAdLoadBuBanner : APLCSAdLoadBanner <BUNativeExpressBannerViewDelegate,APLCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

