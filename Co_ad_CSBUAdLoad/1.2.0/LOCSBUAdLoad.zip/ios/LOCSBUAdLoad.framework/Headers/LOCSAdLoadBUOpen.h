//
//  LOCSAdLoadBUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <LOCSAdSDK/LOCSAdLoadOpen.h>
#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
#import <BUAdSDK/BUSplashAdView.h>

NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdLoadBUOpen : LOCSAdLoadOpen<BUSplashAdDelegate,BUSplashZoomOutViewDelegate,LOCSAdLoadProtocol>

@property(nonatomic, strong) BUSplashAdView *ad;


@end

NS_ASSUME_NONNULL_END
