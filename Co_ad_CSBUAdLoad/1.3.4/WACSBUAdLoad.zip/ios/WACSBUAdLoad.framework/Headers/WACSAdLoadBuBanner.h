//
//  WACSAdLoadBuBanner.h
//  WACSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadBanner.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface WACSAdLoadBuBanner : WACSAdLoadBanner <BUNativeExpressBannerViewDelegate,WACSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

