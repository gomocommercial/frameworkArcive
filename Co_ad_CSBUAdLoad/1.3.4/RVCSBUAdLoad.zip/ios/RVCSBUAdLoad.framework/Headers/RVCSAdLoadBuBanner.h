//
//  RVCSAdLoadBuBanner.h
//  RVCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadBanner.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

@interface RVCSAdLoadBuBanner : RVCSAdLoadBanner <BUNativeExpressBannerViewDelegate,RVCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressBannerView *ad;

@end

