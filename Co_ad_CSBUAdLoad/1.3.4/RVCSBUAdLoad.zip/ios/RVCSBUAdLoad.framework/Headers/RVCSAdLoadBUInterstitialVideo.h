//
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <RVCSAdSDK/RVCSAdLoadInterstitial.h>
#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN
//TODO: 暂不使用
@interface RVCSAdLoadBUInterstitialVideo : RVCSAdLoadInterstitial<BUFullscreenVideoAdDelegate,RVCSAdLoadProtocol>
@property(nonatomic, strong) BUFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
