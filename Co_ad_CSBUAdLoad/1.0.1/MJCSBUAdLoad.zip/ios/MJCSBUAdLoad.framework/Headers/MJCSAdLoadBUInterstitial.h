//
//  MJCSAdLoadBUInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MJCSAdSDK/MJCSAdLoadInterstitial.h>
#import <MJCSAdSDK/MJCSAdLoadProtocol.h>
#import <MJCSAdSDK/MJCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface MJCSAdLoadBUInterstitial : MJCSAdLoadInterstitial<BUNativeExpresInterstitialAdDelegate,MJCSAdLoadProtocol>

@property(nonatomic, strong) BUNativeExpressInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
