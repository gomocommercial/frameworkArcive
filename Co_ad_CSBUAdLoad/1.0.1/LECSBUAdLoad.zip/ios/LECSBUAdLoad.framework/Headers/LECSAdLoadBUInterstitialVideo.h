//
//  LECSAdLoadBUInterstitialVideo.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <LECSAdSDK/LECSAdLoadInterstitial.h>
#import <LECSAdSDK/LECSAdLoadProtocol.h>
#import <LECSAdSDK/LECSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface LECSAdLoadBUInterstitialVideo : LECSAdLoadInterstitial<BUFullscreenVideoAdDelegate,LECSAdLoadProtocol>
@property(nonatomic, strong) BUFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
