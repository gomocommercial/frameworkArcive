//
//  QRCSAdLoadBUInterstitialVideo.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <QRCSAdSDK/QRCSAdLoadInterstitial.h>
#import <QRCSAdSDK/QRCSAdLoadProtocol.h>
#import <QRCSAdSDK/QRCSAdLoadShowProtocol.h>
#import <BUAdSDK/BUAdSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface QRCSAdLoadBUInterstitialVideo : QRCSAdLoadInterstitial<BUFullscreenVideoAdDelegate,QRCSAdLoadProtocol>
@property(nonatomic, strong) BUFullscreenVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
