//
//  SWCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <SWCSAdSDK/SWCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface SWCSAdLoadAdmobInterstitial : SWCSAdLoadInterstitial<SWCSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

@end

NS_ASSUME_NONNULL_END
