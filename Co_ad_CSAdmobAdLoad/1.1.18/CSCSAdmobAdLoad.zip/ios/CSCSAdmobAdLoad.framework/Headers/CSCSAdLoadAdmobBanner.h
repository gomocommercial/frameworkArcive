//
//  CSCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CSCSAdSDK/CSCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface CSCSAdLoadAdmobBanner : CSCSAdLoadBanner<CSCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
