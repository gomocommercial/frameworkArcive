//
//  VECSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <VECSAdSDK/VECSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <VECSAdSDK/VECSAdLoadProtocol.h>
#import <VECSAdSDK/VECSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface VECSAdLoadAdmobBanner : VECSAdLoadBanner<VECSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
