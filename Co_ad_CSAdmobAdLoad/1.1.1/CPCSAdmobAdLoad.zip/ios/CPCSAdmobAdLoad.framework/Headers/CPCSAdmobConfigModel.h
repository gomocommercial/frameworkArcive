//
//  CPCSAdmobConfigModel.h
//  AFNetworking
//
//  Created by Zy on 2020/11/2.
//

#import <Foundation/Foundation.h>
#import <CPCSAdSDK/CPCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface CPCSAdmobConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;

//Banner
@property (nonatomic, assign) GADAdSize bannerSize;
@property (nonatomic, strong) UIViewController *rootViewController;

//Open
@property (nonatomic, assign) UIInterfaceOrientation orientation;

@end

NS_ASSUME_NONNULL_END
