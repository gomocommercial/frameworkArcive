//
//  PSECSAdLoadAmobInterstitialVideo.h
//  PSECSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <PSECSAdSDK/PSECSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PSECSAdSDK/PSECSAdLoadProtocol.h>
#import <PSECSAdSDK/PSECSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdLoadAmobInterstitialVideo : PSECSAdLoadInterstitial<PSECSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
