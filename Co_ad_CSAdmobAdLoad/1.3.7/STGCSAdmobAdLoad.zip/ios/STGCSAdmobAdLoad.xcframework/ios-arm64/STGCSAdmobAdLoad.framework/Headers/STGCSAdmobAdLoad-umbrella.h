#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "STGCSAdLoadAdmobBanner.h"
#import "STGCSAdLoadAdmobConfig.h"
#import "STGCSAdmobConfigModel.h"
#import "STGCSAdLoadAdmobInterstitial.h"
#import "STGCSAdLoadAmobInterstitialVideo.h"
#import "STGCSAdLoadAdmobNative.h"
#import "STGCSAdLoadAdmobOpen.h"
#import "STGCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double STGCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char STGCSAdmobAdLoadVersionString[];

