//
//  DESCSAdLoadAmobInterstitialVideo.h
//  DESCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <DESCSAdSDK/DESCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DESCSAdSDK/DESCSAdLoadProtocol.h>
#import <DESCSAdSDK/DESCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DESCSAdLoadAmobInterstitialVideo : DESCSAdLoadInterstitial<DESCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
