#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "DESCSAdLoadAdmobBanner.h"
#import "DESCSAdLoadAdmobConfig.h"
#import "DESCSAdmobConfigModel.h"
#import "DESCSAdLoadAdmobInterstitial.h"
#import "DESCSAdLoadAmobInterstitialVideo.h"
#import "DESCSAdLoadAdmobNative.h"
#import "DESCSAdLoadAdmobOpen.h"
#import "DESCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double DESCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char DESCSAdmobAdLoadVersionString[];

