//
//  LUCCSAdLoadAmobInterstitialVideo.h
//  LUCCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <LUCCSAdSDK/LUCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LUCCSAdSDK/LUCCSAdLoadProtocol.h>
#import <LUCCSAdSDK/LUCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LUCCSAdLoadAmobInterstitialVideo : LUCCSAdLoadInterstitial<LUCCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
