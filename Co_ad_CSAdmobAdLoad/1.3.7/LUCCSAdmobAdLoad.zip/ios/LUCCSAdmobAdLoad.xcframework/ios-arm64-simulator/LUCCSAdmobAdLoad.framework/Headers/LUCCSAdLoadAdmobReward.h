//
//  LUCCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <LUCCSAdSDK/LUCCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LUCCSAdSDK/LUCCSAdLoadProtocol.h>
#import <LUCCSAdSDK/LUCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LUCCSAdLoadAdmobReward : LUCCSAdLoadReward<GADFullScreenContentDelegate,LUCCSAdLoadProtocol>

@property(nonatomic, strong) GADRewardedAd *ad;


/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
