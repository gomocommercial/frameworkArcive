#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "CLUPCSAdLoadAdmobBanner.h"
#import "CLUPCSAdLoadAdmobConfig.h"
#import "CLUPCSAdmobConfigModel.h"
#import "CLUPCSAdLoadAdmobInterstitial.h"
#import "CLUPCSAdLoadAmobInterstitialVideo.h"
#import "CLUPCSAdLoadAdmobNative.h"
#import "CLUPCSAdLoadAdmobOpen.h"
#import "CLUPCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double CLUPCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char CLUPCSAdmobAdLoadVersionString[];

