//
//  TAUCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <TAUCSAdSDK/TAUCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TAUCSAdSDK/TAUCSAdLoadProtocol.h>
#import <TAUCSAdSDK/TAUCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TAUCSAdLoadAdmobInterstitial : TAUCSAdLoadInterstitial<TAUCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
