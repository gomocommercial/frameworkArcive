#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TAUCSAdLoadAdmobBanner.h"
#import "TAUCSAdLoadAdmobConfig.h"
#import "TAUCSAdmobConfigModel.h"
#import "TAUCSAdLoadAdmobInterstitial.h"
#import "TAUCSAdLoadAmobInterstitialVideo.h"
#import "TAUCSAdLoadAdmobNative.h"
#import "TAUCSAdLoadAdmobOpen.h"
#import "TAUCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double TAUCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TAUCSAdmobAdLoadVersionString[];

