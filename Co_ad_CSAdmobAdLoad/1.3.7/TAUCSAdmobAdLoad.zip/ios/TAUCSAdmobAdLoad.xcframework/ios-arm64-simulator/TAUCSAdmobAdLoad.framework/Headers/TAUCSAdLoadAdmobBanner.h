//
//  TAUCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TAUCSAdSDK/TAUCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TAUCSAdSDK/TAUCSAdLoadProtocol.h>
#import <TAUCSAdSDK/TAUCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface TAUCSAdLoadAdmobBanner : TAUCSAdLoadBanner<TAUCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
