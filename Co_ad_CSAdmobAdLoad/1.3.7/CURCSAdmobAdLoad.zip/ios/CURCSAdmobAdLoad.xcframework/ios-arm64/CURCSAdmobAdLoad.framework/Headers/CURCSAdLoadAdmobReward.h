//
//  CURCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <CURCSAdSDK/CURCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CURCSAdSDK/CURCSAdLoadProtocol.h>
#import <CURCSAdSDK/CURCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CURCSAdLoadAdmobReward : CURCSAdLoadReward<GADFullScreenContentDelegate,CURCSAdLoadProtocol>

@property(nonatomic, strong) GADRewardedAd *ad;


/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
