//
//  CURCSAdLoadAmobInterstitialVideo.h
//  CURCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <CURCSAdSDK/CURCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CURCSAdSDK/CURCSAdLoadProtocol.h>
#import <CURCSAdSDK/CURCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CURCSAdLoadAmobInterstitialVideo : CURCSAdLoadInterstitial<CURCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
