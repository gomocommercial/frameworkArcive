//
//  CURCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <CURCSAdSDK/CURCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CURCSAdSDK/CURCSAdLoadProtocol.h>
#import <CURCSAdSDK/CURCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CURCSAdLoadAdmobInterstitial : CURCSAdLoadInterstitial<CURCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
