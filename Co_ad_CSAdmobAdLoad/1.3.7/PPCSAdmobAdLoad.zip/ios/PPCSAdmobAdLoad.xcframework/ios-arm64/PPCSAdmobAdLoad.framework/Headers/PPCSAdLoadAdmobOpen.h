//
//  PPCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PPCSAdSDK/PPCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PPCSAdSDK/PPCSAdLoadProtocol.h>
#import <PPCSAdSDK/PPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PPCSAdLoadAdmobOpen : PPCSAdLoadOpen <PPCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
