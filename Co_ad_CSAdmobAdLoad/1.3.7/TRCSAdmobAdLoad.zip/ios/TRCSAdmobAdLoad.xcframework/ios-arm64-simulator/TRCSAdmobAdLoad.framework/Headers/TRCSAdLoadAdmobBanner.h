//
//  TRCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TRCSAdSDK/TRCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TRCSAdSDK/TRCSAdLoadProtocol.h>
#import <TRCSAdSDK/TRCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface TRCSAdLoadAdmobBanner : TRCSAdLoadBanner<TRCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
