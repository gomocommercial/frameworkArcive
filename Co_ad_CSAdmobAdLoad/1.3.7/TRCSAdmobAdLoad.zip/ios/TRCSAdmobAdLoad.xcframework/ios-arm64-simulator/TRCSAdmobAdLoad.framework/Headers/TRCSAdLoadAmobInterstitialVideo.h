//
//  TRCSAdLoadAmobInterstitialVideo.h
//  TRCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <TRCSAdSDK/TRCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TRCSAdSDK/TRCSAdLoadProtocol.h>
#import <TRCSAdSDK/TRCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TRCSAdLoadAmobInterstitialVideo : TRCSAdLoadInterstitial<TRCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
