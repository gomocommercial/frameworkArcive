#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "DITCSAdLoadAdmobBanner.h"
#import "DITCSAdLoadAdmobConfig.h"
#import "DITCSAdmobConfigModel.h"
#import "DITCSAdLoadAdmobInterstitial.h"
#import "DITCSAdLoadAmobInterstitialVideo.h"
#import "DITCSAdLoadAdmobNative.h"
#import "DITCSAdLoadAdmobOpen.h"
#import "DITCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double DITCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char DITCSAdmobAdLoadVersionString[];

