//
//  DITCSAdLoadAmobInterstitialVideo.h
//  DITCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <DITCSAdSDK/DITCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DITCSAdSDK/DITCSAdLoadProtocol.h>
#import <DITCSAdSDK/DITCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdLoadAmobInterstitialVideo : DITCSAdLoadInterstitial<DITCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
