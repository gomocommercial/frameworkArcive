//
//  DITCSAdmobConfigModel.h
//  AFNetworking
//
//  Created by Zy on 2020/11/2.
//

#import <Foundation/Foundation.h>
#import <DITCSAdSDK/DITCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdmobConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;

//Banner
@property (nonatomic, assign) GADAdSize bannerSize;
@property (nonatomic, weak) UIViewController *rootViewController;

//Open
@property (nonatomic, assign) UIInterfaceOrientation orientation;

@end

NS_ASSUME_NONNULL_END
