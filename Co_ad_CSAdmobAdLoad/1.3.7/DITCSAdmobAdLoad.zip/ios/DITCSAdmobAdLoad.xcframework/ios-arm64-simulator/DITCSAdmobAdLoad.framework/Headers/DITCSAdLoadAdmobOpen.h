//
//  DITCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <DITCSAdSDK/DITCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DITCSAdSDK/DITCSAdLoadProtocol.h>
#import <DITCSAdSDK/DITCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdLoadAdmobOpen : DITCSAdLoadOpen <DITCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
