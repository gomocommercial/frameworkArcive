//
//  DITCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DITCSAdSDK/DITCSAdLoadNative.h>
#import <DITCSAdSDK/DITCSAdLoadProtocol.h>
#import <DITCSAdSDK/DITCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdLoadAdmobNative : DITCSAdLoadNative<DITCSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
