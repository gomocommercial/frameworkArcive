//
//  StepWisdomCSAdLoadAmobInterstitialVideo.h
//  StepWisdomCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadAmobInterstitialVideo : StepWisdomCSAdLoadInterstitial<StepWisdomCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
