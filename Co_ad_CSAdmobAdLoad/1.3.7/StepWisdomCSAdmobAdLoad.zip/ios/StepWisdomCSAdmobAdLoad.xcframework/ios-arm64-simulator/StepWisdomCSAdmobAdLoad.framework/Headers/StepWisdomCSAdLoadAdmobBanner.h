//
//  StepWisdomCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface StepWisdomCSAdLoadAdmobBanner : StepWisdomCSAdLoadBanner<StepWisdomCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
