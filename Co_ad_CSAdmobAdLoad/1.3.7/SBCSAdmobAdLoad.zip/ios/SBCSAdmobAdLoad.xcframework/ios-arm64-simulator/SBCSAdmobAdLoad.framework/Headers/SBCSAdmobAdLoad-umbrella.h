#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "SBCSAdLoadAdmobBanner.h"
#import "SBCSAdLoadAdmobConfig.h"
#import "SBCSAdmobConfigModel.h"
#import "SBCSAdLoadAdmobInterstitial.h"
#import "SBCSAdLoadAmobInterstitialVideo.h"
#import "SBCSAdLoadAdmobNative.h"
#import "SBCSAdLoadAdmobOpen.h"
#import "SBCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double SBCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char SBCSAdmobAdLoadVersionString[];

