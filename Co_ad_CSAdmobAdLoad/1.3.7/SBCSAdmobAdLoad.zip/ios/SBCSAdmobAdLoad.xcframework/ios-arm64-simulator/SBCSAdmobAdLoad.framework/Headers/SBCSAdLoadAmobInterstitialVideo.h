//
//  SBCSAdLoadAmobInterstitialVideo.h
//  SBCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <SBCSAdSDK/SBCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SBCSAdSDK/SBCSAdLoadProtocol.h>
#import <SBCSAdSDK/SBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SBCSAdLoadAmobInterstitialVideo : SBCSAdLoadInterstitial<SBCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
