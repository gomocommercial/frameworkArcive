//
//  PICCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PICCSAdSDK/PICCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PICCSAdSDK/PICCSAdLoadProtocol.h>
#import <PICCSAdSDK/PICCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PICCSAdLoadAdmobOpen : PICCSAdLoadOpen <PICCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
