//
//  PICCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PICCSAdSDK/PICCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PICCSAdSDK/PICCSAdLoadProtocol.h>
#import <PICCSAdSDK/PICCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface PICCSAdLoadAdmobBanner : PICCSAdLoadBanner<PICCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
