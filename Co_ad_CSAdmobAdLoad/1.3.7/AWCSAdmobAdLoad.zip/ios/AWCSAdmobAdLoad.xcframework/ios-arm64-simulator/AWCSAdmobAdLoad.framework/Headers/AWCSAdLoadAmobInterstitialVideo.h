//
//  AWCSAdLoadAmobInterstitialVideo.h
//  AWCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <AWCSAdSDK/AWCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <AWCSAdSDK/AWCSAdLoadProtocol.h>
#import <AWCSAdSDK/AWCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadAmobInterstitialVideo : AWCSAdLoadInterstitial<AWCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
