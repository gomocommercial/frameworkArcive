//
//  MOVCSAdLoadAmobInterstitialVideo.h
//  MOVCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <MOVCSAdSDK/MOVCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MOVCSAdSDK/MOVCSAdLoadProtocol.h>
#import <MOVCSAdSDK/MOVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MOVCSAdLoadAmobInterstitialVideo : MOVCSAdLoadInterstitial<MOVCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
