//
//  MOVCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <MOVCSAdSDK/MOVCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MOVCSAdSDK/MOVCSAdLoadProtocol.h>
#import <MOVCSAdSDK/MOVCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MOVCSAdLoadAdmobInterstitial : MOVCSAdLoadInterstitial<MOVCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
