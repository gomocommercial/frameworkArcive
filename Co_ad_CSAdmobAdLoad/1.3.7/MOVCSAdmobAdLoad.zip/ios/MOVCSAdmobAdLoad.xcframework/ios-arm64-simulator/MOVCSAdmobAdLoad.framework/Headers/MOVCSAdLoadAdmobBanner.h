//
//  MOVCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MOVCSAdSDK/MOVCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MOVCSAdSDK/MOVCSAdLoadProtocol.h>
#import <MOVCSAdSDK/MOVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface MOVCSAdLoadAdmobBanner : MOVCSAdLoadBanner<MOVCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
