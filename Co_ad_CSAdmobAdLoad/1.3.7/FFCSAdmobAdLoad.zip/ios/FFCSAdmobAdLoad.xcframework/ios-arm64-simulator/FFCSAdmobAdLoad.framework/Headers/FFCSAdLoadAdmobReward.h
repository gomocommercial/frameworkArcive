//
//  FFCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FFCSAdSDK/FFCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <FFCSAdSDK/FFCSAdLoadProtocol.h>
#import <FFCSAdSDK/FFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdLoadAdmobReward : FFCSAdLoadReward<GADFullScreenContentDelegate,FFCSAdLoadProtocol>

@property(nonatomic, strong) GADRewardedAd *ad;


/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
