//
//  LASCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <LASCSAdSDK/LASCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LASCSAdSDK/LASCSAdLoadProtocol.h>
#import <LASCSAdSDK/LASCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdLoadAdmobInterstitial : LASCSAdLoadInterstitial<LASCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
