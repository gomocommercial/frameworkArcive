//
//  LASCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LASCSAdSDK/LASCSAdLoadNative.h>
#import <LASCSAdSDK/LASCSAdLoadProtocol.h>
#import <LASCSAdSDK/LASCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdLoadAdmobNative : LASCSAdLoadNative<LASCSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
