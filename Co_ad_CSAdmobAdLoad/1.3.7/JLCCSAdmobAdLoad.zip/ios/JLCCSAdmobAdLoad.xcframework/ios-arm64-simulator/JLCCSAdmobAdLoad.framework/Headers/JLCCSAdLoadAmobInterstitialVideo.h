//
//  JLCCSAdLoadAmobInterstitialVideo.h
//  JLCCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <JLCCSAdSDK/JLCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <JLCCSAdSDK/JLCCSAdLoadProtocol.h>
#import <JLCCSAdSDK/JLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadAmobInterstitialVideo : JLCCSAdLoadInterstitial<JLCCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
