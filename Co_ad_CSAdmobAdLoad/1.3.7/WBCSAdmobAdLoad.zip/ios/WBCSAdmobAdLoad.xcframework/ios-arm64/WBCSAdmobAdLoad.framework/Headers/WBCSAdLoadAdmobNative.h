//
//  WBCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <WBCSAdSDK/WBCSAdLoadNative.h>
#import <WBCSAdSDK/WBCSAdLoadProtocol.h>
#import <WBCSAdSDK/WBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface WBCSAdLoadAdmobNative : WBCSAdLoadNative<WBCSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
