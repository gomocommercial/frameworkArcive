#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WBCSAdLoadAdmobBanner.h"
#import "WBCSAdLoadAdmobConfig.h"
#import "WBCSAdmobConfigModel.h"
#import "WBCSAdLoadAdmobInterstitial.h"
#import "WBCSAdLoadAmobInterstitialVideo.h"
#import "WBCSAdLoadAdmobNative.h"
#import "WBCSAdLoadAdmobOpen.h"
#import "WBCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double WBCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char WBCSAdmobAdLoadVersionString[];

