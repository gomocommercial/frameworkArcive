//
//  MGCSAdLoadAmobInterstitialVideo.h
//  MGCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <MGCSAdSDK/MGCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MGCSAdSDK/MGCSAdLoadProtocol.h>
#import <MGCSAdSDK/MGCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGCSAdLoadAmobInterstitialVideo : MGCSAdLoadInterstitial<MGCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
