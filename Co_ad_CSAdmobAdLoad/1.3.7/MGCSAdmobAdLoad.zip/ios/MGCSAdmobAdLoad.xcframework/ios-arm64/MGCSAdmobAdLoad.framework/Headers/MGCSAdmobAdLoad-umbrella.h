#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MGCSAdLoadAdmobBanner.h"
#import "MGCSAdLoadAdmobConfig.h"
#import "MGCSAdmobConfigModel.h"
#import "MGCSAdLoadAdmobInterstitial.h"
#import "MGCSAdLoadAmobInterstitialVideo.h"
#import "MGCSAdLoadAdmobNative.h"
#import "MGCSAdLoadAdmobOpen.h"
#import "MGCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double MGCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char MGCSAdmobAdLoadVersionString[];

