//
//  TRCCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TRCCSAdSDK/TRCCSAdLoadNative.h>
#import <TRCCSAdSDK/TRCCSAdLoadProtocol.h>
#import <TRCCSAdSDK/TRCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TRCCSAdLoadAdmobNative : TRCCSAdLoadNative<TRCCSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
