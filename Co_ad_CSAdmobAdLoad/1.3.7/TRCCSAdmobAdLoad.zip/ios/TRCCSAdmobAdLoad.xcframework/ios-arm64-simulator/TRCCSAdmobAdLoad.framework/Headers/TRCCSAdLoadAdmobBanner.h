//
//  TRCCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TRCCSAdSDK/TRCCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TRCCSAdSDK/TRCCSAdLoadProtocol.h>
#import <TRCCSAdSDK/TRCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface TRCCSAdLoadAdmobBanner : TRCCSAdLoadBanner<TRCCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
