#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TRCCSAdLoadAdmobBanner.h"
#import "TRCCSAdLoadAdmobConfig.h"
#import "TRCCSAdmobConfigModel.h"
#import "TRCCSAdLoadAdmobInterstitial.h"
#import "TRCCSAdLoadAmobInterstitialVideo.h"
#import "TRCCSAdLoadAdmobNative.h"
#import "TRCCSAdLoadAdmobOpen.h"
#import "TRCCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double TRCCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TRCCSAdmobAdLoadVersionString[];

