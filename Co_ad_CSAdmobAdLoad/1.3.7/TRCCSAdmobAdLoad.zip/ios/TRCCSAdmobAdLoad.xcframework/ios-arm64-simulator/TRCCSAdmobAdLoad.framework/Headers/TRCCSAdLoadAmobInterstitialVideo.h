//
//  TRCCSAdLoadAmobInterstitialVideo.h
//  TRCCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <TRCCSAdSDK/TRCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TRCCSAdSDK/TRCCSAdLoadProtocol.h>
#import <TRCCSAdSDK/TRCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TRCCSAdLoadAmobInterstitialVideo : TRCCSAdLoadInterstitial<TRCCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
