//
//  TRCCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <TRCCSAdSDK/TRCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TRCCSAdSDK/TRCCSAdLoadProtocol.h>
#import <TRCCSAdSDK/TRCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TRCCSAdLoadAdmobInterstitial : TRCCSAdLoadInterstitial<TRCCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
