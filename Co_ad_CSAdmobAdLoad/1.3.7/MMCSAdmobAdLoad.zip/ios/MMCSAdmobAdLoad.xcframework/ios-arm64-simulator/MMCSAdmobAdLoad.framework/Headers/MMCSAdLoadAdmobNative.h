//
//  MMCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MMCSAdSDK/MMCSAdLoadNative.h>
#import <MMCSAdSDK/MMCSAdLoadProtocol.h>
#import <MMCSAdSDK/MMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MMCSAdLoadAdmobNative : MMCSAdLoadNative<MMCSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
