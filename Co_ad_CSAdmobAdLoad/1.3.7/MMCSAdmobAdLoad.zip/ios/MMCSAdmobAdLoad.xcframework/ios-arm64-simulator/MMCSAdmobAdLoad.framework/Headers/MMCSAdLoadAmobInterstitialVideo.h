//
//  MMCSAdLoadAmobInterstitialVideo.h
//  MMCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <MMCSAdSDK/MMCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MMCSAdSDK/MMCSAdLoadProtocol.h>
#import <MMCSAdSDK/MMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MMCSAdLoadAmobInterstitialVideo : MMCSAdLoadInterstitial<MMCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
