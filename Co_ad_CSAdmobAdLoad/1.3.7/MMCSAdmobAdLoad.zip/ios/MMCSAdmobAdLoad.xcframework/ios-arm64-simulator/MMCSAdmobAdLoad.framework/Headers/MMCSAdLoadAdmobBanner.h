//
//  MMCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MMCSAdSDK/MMCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MMCSAdSDK/MMCSAdLoadProtocol.h>
#import <MMCSAdSDK/MMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface MMCSAdLoadAdmobBanner : MMCSAdLoadBanner<MMCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
