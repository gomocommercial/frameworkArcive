//
//  CSPCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CSPCSAdSDK/CSPCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CSPCSAdSDK/CSPCSAdLoadProtocol.h>
#import <CSPCSAdSDK/CSPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface CSPCSAdLoadAdmobBanner : CSPCSAdLoadBanner<CSPCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
