//
//  STEPGCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <STEPGCSAdSDK/STEPGCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadProtocol.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface STEPGCSAdLoadAdmobInterstitial : STEPGCSAdLoadInterstitial<STEPGCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
