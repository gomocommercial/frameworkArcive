//
//  LUMCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LUMCSAdSDK/LUMCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LUMCSAdSDK/LUMCSAdLoadProtocol.h>
#import <LUMCSAdSDK/LUMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface LUMCSAdLoadAdmobBanner : LUMCSAdLoadBanner<LUMCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
