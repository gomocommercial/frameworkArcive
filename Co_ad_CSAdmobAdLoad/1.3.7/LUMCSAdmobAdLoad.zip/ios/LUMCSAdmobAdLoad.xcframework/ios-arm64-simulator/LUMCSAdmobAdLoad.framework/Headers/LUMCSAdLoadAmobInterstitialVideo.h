//
//  LUMCSAdLoadAmobInterstitialVideo.h
//  LUMCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <LUMCSAdSDK/LUMCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LUMCSAdSDK/LUMCSAdLoadProtocol.h>
#import <LUMCSAdSDK/LUMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LUMCSAdLoadAmobInterstitialVideo : LUMCSAdLoadInterstitial<LUMCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
