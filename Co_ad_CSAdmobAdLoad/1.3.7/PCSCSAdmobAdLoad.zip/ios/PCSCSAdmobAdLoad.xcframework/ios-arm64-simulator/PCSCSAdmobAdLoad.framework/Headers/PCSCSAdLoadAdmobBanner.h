//
//  PCSCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PCSCSAdSDK/PCSCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface PCSCSAdLoadAdmobBanner : PCSCSAdLoadBanner<PCSCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
