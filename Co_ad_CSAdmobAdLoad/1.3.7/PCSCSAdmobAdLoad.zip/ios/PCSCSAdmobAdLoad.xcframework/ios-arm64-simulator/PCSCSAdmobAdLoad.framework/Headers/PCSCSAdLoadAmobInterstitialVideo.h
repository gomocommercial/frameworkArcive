//
//  PCSCSAdLoadAmobInterstitialVideo.h
//  PCSCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <PCSCSAdSDK/PCSCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadAmobInterstitialVideo : PCSCSAdLoadInterstitial<PCSCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
