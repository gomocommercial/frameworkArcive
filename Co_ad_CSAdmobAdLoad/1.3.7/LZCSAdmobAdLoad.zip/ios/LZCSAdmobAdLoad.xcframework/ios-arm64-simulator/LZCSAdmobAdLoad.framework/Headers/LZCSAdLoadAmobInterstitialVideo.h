//
//  LZCSAdLoadAmobInterstitialVideo.h
//  LZCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <LZCSAdSDK/LZCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LZCSAdSDK/LZCSAdLoadProtocol.h>
#import <LZCSAdSDK/LZCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZCSAdLoadAmobInterstitialVideo : LZCSAdLoadInterstitial<LZCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
