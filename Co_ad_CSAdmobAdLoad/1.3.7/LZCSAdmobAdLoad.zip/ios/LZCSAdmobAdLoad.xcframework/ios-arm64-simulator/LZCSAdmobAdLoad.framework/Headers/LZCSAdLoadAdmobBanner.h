//
//  LZCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LZCSAdSDK/LZCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LZCSAdSDK/LZCSAdLoadProtocol.h>
#import <LZCSAdSDK/LZCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface LZCSAdLoadAdmobBanner : LZCSAdLoadBanner<LZCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
