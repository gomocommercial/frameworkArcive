//
//  AhhhCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadAdmobOpen : AhhhCSAdLoadOpen <AhhhCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
