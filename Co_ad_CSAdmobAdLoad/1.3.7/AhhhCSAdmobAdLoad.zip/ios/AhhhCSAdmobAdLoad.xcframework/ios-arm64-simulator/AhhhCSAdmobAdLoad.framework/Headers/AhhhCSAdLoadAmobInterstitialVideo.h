//
//  AhhhCSAdLoadAmobInterstitialVideo.h
//  AhhhCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadAmobInterstitialVideo : AhhhCSAdLoadInterstitial<AhhhCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
