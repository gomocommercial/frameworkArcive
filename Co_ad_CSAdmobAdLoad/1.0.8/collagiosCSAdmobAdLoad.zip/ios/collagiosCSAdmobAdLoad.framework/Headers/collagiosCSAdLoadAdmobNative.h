//
//  collagiosCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadNative.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadProtocol.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface collagiosCSAdLoadAdmobNative : collagiosCSAdLoadNative<collagiosCSAdLoadProtocol,GADUnifiedNativeAdLoaderDelegate, GADUnifiedNativeAdDelegate>

@property (nonatomic, strong) GADUnifiedNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
