//
//  collagiosCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <collagiosCSAdSDK/collagiosCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadProtocol.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface collagiosCSAdLoadAdmobBanner : collagiosCSAdLoadBanner<collagiosCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
