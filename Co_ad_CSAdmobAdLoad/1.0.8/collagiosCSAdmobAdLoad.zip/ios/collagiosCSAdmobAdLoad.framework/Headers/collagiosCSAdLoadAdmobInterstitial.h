//
//  collagiosCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <collagiosCSAdSDK/collagiosCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadProtocol.h>
#import <collagiosCSAdSDK/collagiosCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface collagiosCSAdLoadAdmobInterstitial : collagiosCSAdLoadInterstitial<collagiosCSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
