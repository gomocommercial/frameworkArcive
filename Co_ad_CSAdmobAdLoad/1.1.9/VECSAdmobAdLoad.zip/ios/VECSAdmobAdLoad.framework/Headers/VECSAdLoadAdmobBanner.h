//
//  VECSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <VECSAdSDK/VECSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <VECSAdSDK/VECSAdLoadProtocol.h>
#import <VECSAdSDK/VECSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface VECSAdLoadAdmobBanner : VECSAdLoadBanner<VECSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
