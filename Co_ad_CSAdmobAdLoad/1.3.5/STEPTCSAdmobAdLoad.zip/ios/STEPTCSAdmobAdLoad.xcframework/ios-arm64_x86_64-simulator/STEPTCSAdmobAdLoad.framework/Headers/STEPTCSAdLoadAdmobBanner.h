//
//  STEPTCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <STEPTCSAdSDK/STEPTCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadProtocol.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface STEPTCSAdLoadAdmobBanner : STEPTCSAdLoadBanner<STEPTCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
