//
//  BBBCSAdLoadAmobInterstitialVideo.h
//  BBBCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <BBBCSAdSDK/BBBCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <BBBCSAdSDK/BBBCSAdLoadProtocol.h>
#import <BBBCSAdSDK/BBBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface BBBCSAdLoadAmobInterstitialVideo : BBBCSAdLoadInterstitial<BBBCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
