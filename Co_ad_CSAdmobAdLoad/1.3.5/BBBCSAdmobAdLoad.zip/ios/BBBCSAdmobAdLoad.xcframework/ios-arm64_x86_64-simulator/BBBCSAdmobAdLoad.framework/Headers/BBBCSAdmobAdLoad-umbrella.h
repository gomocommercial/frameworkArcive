#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "BBBCSAdLoadAdmobBanner.h"
#import "BBBCSAdLoadAdmobConfig.h"
#import "BBBCSAdmobConfigModel.h"
#import "BBBCSAdLoadAdmobInterstitial.h"
#import "BBBCSAdLoadAmobInterstitialVideo.h"
#import "BBBCSAdLoadAdmobNative.h"
#import "BBBCSAdLoadAdmobOpen.h"
#import "BBBCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double BBBCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char BBBCSAdmobAdLoadVersionString[];

