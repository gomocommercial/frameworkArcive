#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WACSAdLoadAdmobBanner.h"
#import "WACSAdLoadAdmobConfig.h"
#import "WACSAdmobConfigModel.h"
#import "WACSAdLoadAdmobInterstitial.h"
#import "WACSAdLoadAmobInterstitialVideo.h"
#import "WACSAdLoadAdmobNative.h"
#import "WACSAdLoadAdmobOpen.h"
#import "WACSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double WACSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char WACSAdmobAdLoadVersionString[];

