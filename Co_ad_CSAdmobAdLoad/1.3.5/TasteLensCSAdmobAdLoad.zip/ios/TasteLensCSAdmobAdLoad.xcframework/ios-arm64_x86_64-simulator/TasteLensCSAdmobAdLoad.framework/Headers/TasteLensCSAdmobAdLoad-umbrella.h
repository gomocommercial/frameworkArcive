#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TasteLensCSAdLoadAdmobBanner.h"
#import "TasteLensCSAdLoadAdmobConfig.h"
#import "TasteLensCSAdmobConfigModel.h"
#import "TasteLensCSAdLoadAdmobInterstitial.h"
#import "TasteLensCSAdLoadAmobInterstitialVideo.h"
#import "TasteLensCSAdLoadAdmobNative.h"
#import "TasteLensCSAdLoadAdmobOpen.h"
#import "TasteLensCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double TasteLensCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TasteLensCSAdmobAdLoadVersionString[];

