//
//  TasteLensCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <TasteLensCSAdSDK/TasteLensCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadProtocol.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TasteLensCSAdLoadAdmobReward : TasteLensCSAdLoadReward<GADFullScreenContentDelegate,TasteLensCSAdLoadProtocol>

@property(nonatomic, strong) GADRewardedAd *ad;


/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
