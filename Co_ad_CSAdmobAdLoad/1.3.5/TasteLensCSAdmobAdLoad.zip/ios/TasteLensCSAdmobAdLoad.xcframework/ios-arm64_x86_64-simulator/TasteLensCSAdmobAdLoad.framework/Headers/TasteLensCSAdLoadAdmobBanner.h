//
//  TasteLensCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TasteLensCSAdSDK/TasteLensCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadProtocol.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface TasteLensCSAdLoadAdmobBanner : TasteLensCSAdLoadBanner<TasteLensCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
