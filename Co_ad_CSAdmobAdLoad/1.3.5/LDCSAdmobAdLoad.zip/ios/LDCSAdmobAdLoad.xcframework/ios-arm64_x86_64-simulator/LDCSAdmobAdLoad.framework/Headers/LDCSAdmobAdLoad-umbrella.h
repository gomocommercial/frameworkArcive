#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "LDCSAdLoadAdmobBanner.h"
#import "LDCSAdLoadAdmobConfig.h"
#import "LDCSAdmobConfigModel.h"
#import "LDCSAdLoadAdmobInterstitial.h"
#import "LDCSAdLoadAmobInterstitialVideo.h"
#import "LDCSAdLoadAdmobNative.h"
#import "LDCSAdLoadAdmobOpen.h"
#import "LDCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double LDCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char LDCSAdmobAdLoadVersionString[];

