#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "AMACSAdLoadAdmobBanner.h"
#import "AMACSAdLoadAdmobConfig.h"
#import "AMACSAdmobConfigModel.h"
#import "AMACSAdLoadAdmobInterstitial.h"
#import "AMACSAdLoadAmobInterstitialVideo.h"
#import "AMACSAdLoadAdmobNative.h"
#import "AMACSAdLoadAdmobOpen.h"
#import "AMACSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double AMACSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char AMACSAdmobAdLoadVersionString[];

