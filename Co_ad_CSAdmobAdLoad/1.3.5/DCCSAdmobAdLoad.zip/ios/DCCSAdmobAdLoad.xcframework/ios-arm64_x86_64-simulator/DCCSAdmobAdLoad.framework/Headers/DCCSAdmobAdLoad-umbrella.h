#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "DCCSAdLoadAdmobBanner.h"
#import "DCCSAdLoadAdmobConfig.h"
#import "DCCSAdmobConfigModel.h"
#import "DCCSAdLoadAdmobInterstitial.h"
#import "DCCSAdLoadAmobInterstitialVideo.h"
#import "DCCSAdLoadAdmobNative.h"
#import "DCCSAdLoadAdmobOpen.h"
#import "DCCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double DCCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char DCCSAdmobAdLoadVersionString[];

