#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "CPSCSAdLoadAdmobBanner.h"
#import "CPSCSAdLoadAdmobConfig.h"
#import "CPSCSAdmobConfigModel.h"
#import "CPSCSAdLoadAdmobInterstitial.h"
#import "CPSCSAdLoadAmobInterstitialVideo.h"
#import "CPSCSAdLoadAdmobNative.h"
#import "CPSCSAdLoadAdmobOpen.h"
#import "CPSCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double CPSCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char CPSCSAdmobAdLoadVersionString[];

