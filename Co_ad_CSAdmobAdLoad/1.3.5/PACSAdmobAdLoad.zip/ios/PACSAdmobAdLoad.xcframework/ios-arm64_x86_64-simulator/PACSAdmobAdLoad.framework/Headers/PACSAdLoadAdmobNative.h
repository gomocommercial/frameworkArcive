//
//  PACSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PACSAdSDK/PACSAdLoadNative.h>
#import <PACSAdSDK/PACSAdLoadProtocol.h>
#import <PACSAdSDK/PACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PACSAdLoadAdmobNative : PACSAdLoadNative<PACSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
