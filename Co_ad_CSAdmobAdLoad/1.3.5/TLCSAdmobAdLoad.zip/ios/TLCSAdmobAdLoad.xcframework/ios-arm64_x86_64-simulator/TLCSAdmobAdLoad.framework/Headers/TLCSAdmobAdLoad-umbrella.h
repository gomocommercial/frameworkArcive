#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TLCSAdLoadAdmobBanner.h"
#import "TLCSAdLoadAdmobConfig.h"
#import "TLCSAdmobConfigModel.h"
#import "TLCSAdLoadAdmobInterstitial.h"
#import "TLCSAdLoadAmobInterstitialVideo.h"
#import "TLCSAdLoadAdmobNative.h"
#import "TLCSAdLoadAdmobOpen.h"
#import "TLCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double TLCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TLCSAdmobAdLoadVersionString[];

