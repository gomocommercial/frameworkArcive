//
//  MBCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MBCSAdSDK/MBCSAdLoadNative.h>
#import <MBCSAdSDK/MBCSAdLoadProtocol.h>
#import <MBCSAdSDK/MBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MBCSAdLoadAdmobNative : MBCSAdLoadNative<MBCSAdLoadProtocol,GADUnifiedNativeAdLoaderDelegate, GADUnifiedNativeAdDelegate>

@property (nonatomic, strong) GADUnifiedNativeAd * ad;

@end

NS_ASSUME_NONNULL_END
