//
//  CPCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CPCSAdSDK/CPCSAdLoadNative.h>
#import <CPCSAdSDK/CPCSAdLoadProtocol.h>
#import <CPCSAdSDK/CPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CPCSAdLoadAdmobNative : CPCSAdLoadNative<CPCSAdLoadProtocol,GADUnifiedNativeAdLoaderDelegate, GADUnifiedNativeAdDelegate>

@property (nonatomic, strong) GADUnifiedNativeAd * ad;

@end

NS_ASSUME_NONNULL_END
