//
//  CPCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <CPCSAdSDK/CPCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CPCSAdSDK/CPCSAdLoadProtocol.h>
#import <CPCSAdSDK/CPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CPCSAdLoadAdmobInterstitial : CPCSAdLoadInterstitial<CPCSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

@end

NS_ASSUME_NONNULL_END
