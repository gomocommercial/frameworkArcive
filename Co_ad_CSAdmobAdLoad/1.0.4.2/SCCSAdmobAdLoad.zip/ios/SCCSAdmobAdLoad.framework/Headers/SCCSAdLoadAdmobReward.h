//
//  SCCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <SCCSAdSDK/SCCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SCCSAdSDK/SCCSAdLoadProtocol.h>
#import <SCCSAdSDK/SCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SCCSAdLoadAdmobReward : SCCSAdLoadReward<GADRewardBasedVideoAdDelegate,SCCSAdLoadProtocol>

@end

NS_ASSUME_NONNULL_END
