//
//  SCCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SCCSAdSDK/SCCSAdLoadNative.h>
#import <SCCSAdSDK/SCCSAdLoadProtocol.h>
#import <SCCSAdSDK/SCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SCCSAdLoadAdmobNative : SCCSAdLoadNative<SCCSAdLoadProtocol,GADUnifiedNativeAdLoaderDelegate, GADUnifiedNativeAdDelegate>

@property (nonatomic, strong) GADUnifiedNativeAd * ad;

@end

NS_ASSUME_NONNULL_END
