//
//  SCCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <SCCSAdSDK/SCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SCCSAdSDK/SCCSAdLoadProtocol.h>
#import <SCCSAdSDK/SCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface SCCSAdLoadAdmobInterstitial : SCCSAdLoadInterstitial<SCCSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

@end

NS_ASSUME_NONNULL_END
