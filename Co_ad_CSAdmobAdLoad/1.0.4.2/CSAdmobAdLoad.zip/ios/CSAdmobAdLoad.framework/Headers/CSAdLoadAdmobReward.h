//
//  CSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <CSAdSDK/CSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadAdmobReward : CSAdLoadReward<GADRewardBasedVideoAdDelegate,CSAdLoadProtocol>

@end

NS_ASSUME_NONNULL_END
