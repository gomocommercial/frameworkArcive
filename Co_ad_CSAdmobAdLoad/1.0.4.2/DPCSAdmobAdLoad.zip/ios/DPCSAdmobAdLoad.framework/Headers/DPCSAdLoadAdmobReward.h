//
//  DPCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <DPCSAdSDK/DPCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DPCSAdSDK/DPCSAdLoadProtocol.h>
#import <DPCSAdSDK/DPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DPCSAdLoadAdmobReward : DPCSAdLoadReward<GADRewardBasedVideoAdDelegate,DPCSAdLoadProtocol>

@end

NS_ASSUME_NONNULL_END
