//
//  DPCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <DPCSAdSDK/DPCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DPCSAdSDK/DPCSAdLoadProtocol.h>
#import <DPCSAdSDK/DPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DPCSAdLoadAdmobInterstitial : DPCSAdLoadInterstitial<DPCSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

@end

NS_ASSUME_NONNULL_END
