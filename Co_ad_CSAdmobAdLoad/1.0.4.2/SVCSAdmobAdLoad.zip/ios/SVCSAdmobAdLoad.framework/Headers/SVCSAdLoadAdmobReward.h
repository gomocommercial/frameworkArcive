//
//  SVCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <SVCSAdSDK/SVCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SVCSAdSDK/SVCSAdLoadProtocol.h>
#import <SVCSAdSDK/SVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SVCSAdLoadAdmobReward : SVCSAdLoadReward<GADRewardBasedVideoAdDelegate,SVCSAdLoadProtocol>

@end

NS_ASSUME_NONNULL_END
