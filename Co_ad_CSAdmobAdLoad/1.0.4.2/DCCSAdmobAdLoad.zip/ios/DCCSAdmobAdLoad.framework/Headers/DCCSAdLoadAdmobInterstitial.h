//
//  DCCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <DCCSAdSDK/DCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadAdmobInterstitial : DCCSAdLoadInterstitial<DCCSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

@end

NS_ASSUME_NONNULL_END
