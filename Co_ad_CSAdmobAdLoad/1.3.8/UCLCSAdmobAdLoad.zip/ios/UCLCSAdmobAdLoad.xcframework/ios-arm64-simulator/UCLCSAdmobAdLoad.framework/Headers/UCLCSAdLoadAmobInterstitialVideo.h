//
//  UCLCSAdLoadAmobInterstitialVideo.h
//  UCLCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <UCLCSAdSDK/UCLCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <UCLCSAdSDK/UCLCSAdLoadProtocol.h>
#import <UCLCSAdSDK/UCLCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface UCLCSAdLoadAmobInterstitialVideo : UCLCSAdLoadInterstitial<UCLCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
