//
//  CLECSAdLoadAmobInterstitialVideo.h
//  CLECSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <CLECSAdSDK/CLECSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CLECSAdSDK/CLECSAdLoadProtocol.h>
#import <CLECSAdSDK/CLECSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLECSAdLoadAmobInterstitialVideo : CLECSAdLoadInterstitial<CLECSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
