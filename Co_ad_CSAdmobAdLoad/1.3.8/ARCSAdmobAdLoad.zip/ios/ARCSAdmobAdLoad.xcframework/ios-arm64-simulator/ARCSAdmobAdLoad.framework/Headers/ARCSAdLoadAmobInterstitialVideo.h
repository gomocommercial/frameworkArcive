//
//  ARCSAdLoadAmobInterstitialVideo.h
//  ARCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <ARCSAdSDK/ARCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <ARCSAdSDK/ARCSAdLoadProtocol.h>
#import <ARCSAdSDK/ARCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface ARCSAdLoadAmobInterstitialVideo : ARCSAdLoadInterstitial<ARCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
