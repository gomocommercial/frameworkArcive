//
//  PCRCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PCRCSAdSDK/PCRCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PCRCSAdSDK/PCRCSAdLoadProtocol.h>
#import <PCRCSAdSDK/PCRCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface PCRCSAdLoadAdmobBanner : PCRCSAdLoadBanner<PCRCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
