//
//  PCRCSAdLoadAmobInterstitialVideo.h
//  PCRCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <PCRCSAdSDK/PCRCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PCRCSAdSDK/PCRCSAdLoadProtocol.h>
#import <PCRCSAdSDK/PCRCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCRCSAdLoadAmobInterstitialVideo : PCRCSAdLoadInterstitial<PCRCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
