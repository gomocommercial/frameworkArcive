#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "FurTalesCSAdLoadAdmobBanner.h"
#import "FurTalesCSAdLoadAdmobConfig.h"
#import "FurTalesCSAdmobConfigModel.h"
#import "FurTalesCSAdLoadAdmobInterstitial.h"
#import "FurTalesCSAdLoadAmobInterstitialVideo.h"
#import "FurTalesCSAdLoadAdmobNative.h"
#import "FurTalesCSAdLoadAdmobOpen.h"
#import "FurTalesCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double FurTalesCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char FurTalesCSAdmobAdLoadVersionString[];

