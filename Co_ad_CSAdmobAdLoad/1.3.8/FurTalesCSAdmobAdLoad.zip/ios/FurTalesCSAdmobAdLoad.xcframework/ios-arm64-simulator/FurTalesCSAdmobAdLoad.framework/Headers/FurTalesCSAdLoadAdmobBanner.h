//
//  FurTalesCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FurTalesCSAdSDK/FurTalesCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadProtocol.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface FurTalesCSAdLoadAdmobBanner : FurTalesCSAdLoadBanner<FurTalesCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
