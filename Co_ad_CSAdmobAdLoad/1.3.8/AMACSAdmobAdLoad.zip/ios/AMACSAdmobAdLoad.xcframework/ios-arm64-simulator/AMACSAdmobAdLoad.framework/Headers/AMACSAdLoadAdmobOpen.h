//
//  AMACSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <AMACSAdSDK/AMACSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <AMACSAdSDK/AMACSAdLoadProtocol.h>
#import <AMACSAdSDK/AMACSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AMACSAdLoadAdmobOpen : AMACSAdLoadOpen <AMACSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
