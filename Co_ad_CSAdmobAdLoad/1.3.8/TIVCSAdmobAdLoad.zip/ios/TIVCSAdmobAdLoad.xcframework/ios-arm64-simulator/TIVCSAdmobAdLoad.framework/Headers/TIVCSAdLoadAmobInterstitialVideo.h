//
//  TIVCSAdLoadAmobInterstitialVideo.h
//  TIVCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <TIVCSAdSDK/TIVCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TIVCSAdSDK/TIVCSAdLoadProtocol.h>
#import <TIVCSAdSDK/TIVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdLoadAmobInterstitialVideo : TIVCSAdLoadInterstitial<TIVCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
