//
//  TIVCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <TIVCSAdSDK/TIVCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TIVCSAdSDK/TIVCSAdLoadProtocol.h>
#import <TIVCSAdSDK/TIVCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdLoadAdmobInterstitial : TIVCSAdLoadInterstitial<TIVCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
