#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TIVCSAdLoadAdmobBanner.h"
#import "TIVCSAdLoadAdmobConfig.h"
#import "TIVCSAdmobConfigModel.h"
#import "TIVCSAdLoadAdmobInterstitial.h"
#import "TIVCSAdLoadAmobInterstitialVideo.h"
#import "TIVCSAdLoadAdmobNative.h"
#import "TIVCSAdLoadAdmobOpen.h"
#import "TIVCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double TIVCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TIVCSAdmobAdLoadVersionString[];

