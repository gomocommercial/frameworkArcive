#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "QLCSAdLoadAdmobBanner.h"
#import "QLCSAdLoadAdmobConfig.h"
#import "QLCSAdmobConfigModel.h"
#import "QLCSAdLoadAdmobInterstitial.h"
#import "QLCSAdLoadAmobInterstitialVideo.h"
#import "QLCSAdLoadAdmobNative.h"
#import "QLCSAdLoadAdmobOpen.h"
#import "QLCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double QLCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char QLCSAdmobAdLoadVersionString[];

