//
//  STPBCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <STPBCSAdSDK/STPBCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface STPBCSAdLoadAdmobBanner : STPBCSAdLoadBanner<STPBCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
