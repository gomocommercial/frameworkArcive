#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "STPBCSAdLoadAdmobBanner.h"
#import "STPBCSAdLoadAdmobConfig.h"
#import "STPBCSAdmobConfigModel.h"
#import "STPBCSAdLoadAdmobInterstitial.h"
#import "STPBCSAdLoadAmobInterstitialVideo.h"
#import "STPBCSAdLoadAdmobNative.h"
#import "STPBCSAdLoadAdmobOpen.h"
#import "STPBCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double STPBCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char STPBCSAdmobAdLoadVersionString[];

