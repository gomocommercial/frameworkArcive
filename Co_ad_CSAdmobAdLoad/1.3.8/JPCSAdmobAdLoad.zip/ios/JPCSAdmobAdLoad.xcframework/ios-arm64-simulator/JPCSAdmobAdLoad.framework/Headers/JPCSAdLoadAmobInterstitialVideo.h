//
//  JPCSAdLoadAmobInterstitialVideo.h
//  JPCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <JPCSAdSDK/JPCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdLoadAmobInterstitialVideo : JPCSAdLoadInterstitial<JPCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
