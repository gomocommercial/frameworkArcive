#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "JPCSAdLoadAdmobBanner.h"
#import "JPCSAdLoadAdmobConfig.h"
#import "JPCSAdmobConfigModel.h"
#import "JPCSAdLoadAdmobInterstitial.h"
#import "JPCSAdLoadAmobInterstitialVideo.h"
#import "JPCSAdLoadAdmobNative.h"
#import "JPCSAdLoadAdmobOpen.h"
#import "JPCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double JPCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char JPCSAdmobAdLoadVersionString[];

