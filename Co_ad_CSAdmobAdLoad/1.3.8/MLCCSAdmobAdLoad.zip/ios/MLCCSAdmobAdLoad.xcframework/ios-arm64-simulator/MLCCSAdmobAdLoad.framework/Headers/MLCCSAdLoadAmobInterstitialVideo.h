//
//  MLCCSAdLoadAmobInterstitialVideo.h
//  MLCCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <MLCCSAdSDK/MLCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MLCCSAdSDK/MLCCSAdLoadProtocol.h>
#import <MLCCSAdSDK/MLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MLCCSAdLoadAmobInterstitialVideo : MLCCSAdLoadInterstitial<MLCCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
