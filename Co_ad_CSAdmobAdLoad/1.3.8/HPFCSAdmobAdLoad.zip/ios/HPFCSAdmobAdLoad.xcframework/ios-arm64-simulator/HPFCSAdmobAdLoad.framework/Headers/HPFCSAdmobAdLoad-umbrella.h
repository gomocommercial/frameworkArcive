#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "HPFCSAdLoadAdmobBanner.h"
#import "HPFCSAdLoadAdmobConfig.h"
#import "HPFCSAdmobConfigModel.h"
#import "HPFCSAdLoadAdmobInterstitial.h"
#import "HPFCSAdLoadAmobInterstitialVideo.h"
#import "HPFCSAdLoadAdmobNative.h"
#import "HPFCSAdLoadAdmobOpen.h"
#import "HPFCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double HPFCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char HPFCSAdmobAdLoadVersionString[];

