//
//  HPFCSAdLoadAmobInterstitialVideo.h
//  HPFCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <HPFCSAdSDK/HPFCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadAmobInterstitialVideo : HPFCSAdLoadInterstitial<HPFCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
