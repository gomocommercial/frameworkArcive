//
//  FSLPCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FSLPCSAdSDK/FSLPCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadProtocol.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadAdmobReward : FSLPCSAdLoadReward<GADFullScreenContentDelegate,FSLPCSAdLoadProtocol>

@property(nonatomic, strong) GADRewardedAd *ad;


/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
