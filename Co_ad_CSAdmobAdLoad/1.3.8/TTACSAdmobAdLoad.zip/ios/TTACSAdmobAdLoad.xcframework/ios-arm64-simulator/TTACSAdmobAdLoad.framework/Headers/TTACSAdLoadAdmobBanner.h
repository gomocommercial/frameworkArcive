//
//  TTACSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TTACSAdSDK/TTACSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TTACSAdSDK/TTACSAdLoadProtocol.h>
#import <TTACSAdSDK/TTACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface TTACSAdLoadAdmobBanner : TTACSAdLoadBanner<TTACSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
