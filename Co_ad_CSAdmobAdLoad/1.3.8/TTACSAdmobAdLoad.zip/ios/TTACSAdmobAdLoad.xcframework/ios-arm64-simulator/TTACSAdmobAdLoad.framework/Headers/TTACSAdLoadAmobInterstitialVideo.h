//
//  TTACSAdLoadAmobInterstitialVideo.h
//  TTACSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <TTACSAdSDK/TTACSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TTACSAdSDK/TTACSAdLoadProtocol.h>
#import <TTACSAdSDK/TTACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdLoadAmobInterstitialVideo : TTACSAdLoadInterstitial<TTACSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
