//
//  TTACSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <TTACSAdSDK/TTACSAdLoadNative.h>
#import <TTACSAdSDK/TTACSAdLoadProtocol.h>
#import <TTACSAdSDK/TTACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdLoadAdmobNative : TTACSAdLoadNative<TTACSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
