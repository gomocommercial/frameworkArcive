//
//  LTCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <LTCSAdSDK/LTCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LTCSAdSDK/LTCSAdLoadProtocol.h>
#import <LTCSAdSDK/LTCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LTCSAdLoadAdmobInterstitial : LTCSAdLoadInterstitial<LTCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
