//
//  LTCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LTCSAdSDK/LTCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LTCSAdSDK/LTCSAdLoadProtocol.h>
#import <LTCSAdSDK/LTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface LTCSAdLoadAdmobBanner : LTCSAdLoadBanner<LTCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
