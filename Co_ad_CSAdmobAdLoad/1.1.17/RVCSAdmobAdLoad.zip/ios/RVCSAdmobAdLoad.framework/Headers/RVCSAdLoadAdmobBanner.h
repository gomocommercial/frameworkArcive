//
//  RVCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <RVCSAdSDK/RVCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface RVCSAdLoadAdmobBanner : RVCSAdLoadBanner<RVCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
