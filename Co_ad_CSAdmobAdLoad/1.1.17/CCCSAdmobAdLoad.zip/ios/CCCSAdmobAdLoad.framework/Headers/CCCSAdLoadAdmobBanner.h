//
//  CCCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CCCSAdSDK/CCCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CCCSAdSDK/CCCSAdLoadProtocol.h>
#import <CCCSAdSDK/CCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface CCCSAdLoadAdmobBanner : CCCSAdLoadBanner<CCCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
