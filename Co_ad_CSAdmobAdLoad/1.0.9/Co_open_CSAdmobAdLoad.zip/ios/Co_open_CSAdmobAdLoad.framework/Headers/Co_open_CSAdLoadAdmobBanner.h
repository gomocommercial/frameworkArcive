//
//  Co_open_CSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <Co_open_CSAdSDK/Co_open_CSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadProtocol.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface Co_open_CSAdLoadAdmobBanner : Co_open_CSAdLoadBanner<Co_open_CSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
