//
//  Co_open_CSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadNative.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadProtocol.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_open_CSAdLoadAdmobNative : Co_open_CSAdLoadNative<Co_open_CSAdLoadProtocol,GADUnifiedNativeAdLoaderDelegate, GADUnifiedNativeAdDelegate>

@property (nonatomic, strong) GADUnifiedNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
