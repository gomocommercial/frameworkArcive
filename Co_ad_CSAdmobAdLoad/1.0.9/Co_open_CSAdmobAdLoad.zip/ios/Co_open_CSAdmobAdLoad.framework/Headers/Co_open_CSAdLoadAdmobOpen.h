//
//  Co_open_CSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <Co_open_CSAdSDK/Co_open_CSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadProtocol.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface Co_open_CSAdLoadAdmobOpen : Co_open_CSAdLoadOpen <Co_open_CSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
