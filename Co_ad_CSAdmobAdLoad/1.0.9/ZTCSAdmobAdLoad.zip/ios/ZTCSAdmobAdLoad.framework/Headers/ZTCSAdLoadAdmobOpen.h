//
//  ZTCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <ZTCSAdSDK/ZTCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <ZTCSAdSDK/ZTCSAdLoadProtocol.h>
#import <ZTCSAdSDK/ZTCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface ZTCSAdLoadAdmobOpen : ZTCSAdLoadOpen <ZTCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
