//
//  LOCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LOCSAdSDK/LOCSAdLoadNative.h>
#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdLoadAdmobNative : LOCSAdLoadNative<LOCSAdLoadProtocol,GADUnifiedNativeAdLoaderDelegate, GADUnifiedNativeAdDelegate>

@property (nonatomic, strong) GADUnifiedNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
