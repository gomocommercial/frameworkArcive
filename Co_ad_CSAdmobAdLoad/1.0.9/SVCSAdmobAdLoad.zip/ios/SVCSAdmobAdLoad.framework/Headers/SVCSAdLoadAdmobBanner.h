//
//  SVCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <SVCSAdSDK/SVCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SVCSAdSDK/SVCSAdLoadProtocol.h>
#import <SVCSAdSDK/SVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface SVCSAdLoadAdmobBanner : SVCSAdLoadBanner<SVCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
