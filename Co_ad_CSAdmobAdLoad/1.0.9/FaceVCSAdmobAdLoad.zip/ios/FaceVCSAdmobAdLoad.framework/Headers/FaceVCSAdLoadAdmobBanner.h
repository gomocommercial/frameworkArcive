//
//  FaceVCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FaceVCSAdSDK/FaceVCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <FaceVCSAdSDK/FaceVCSAdLoadProtocol.h>
#import <FaceVCSAdSDK/FaceVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface FaceVCSAdLoadAdmobBanner : FaceVCSAdLoadBanner<FaceVCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
