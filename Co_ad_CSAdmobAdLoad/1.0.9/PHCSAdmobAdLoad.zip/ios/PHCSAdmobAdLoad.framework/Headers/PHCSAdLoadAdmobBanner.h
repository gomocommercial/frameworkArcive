//
//  PHCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PHCSAdSDK/PHCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PHCSAdSDK/PHCSAdLoadProtocol.h>
#import <PHCSAdSDK/PHCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface PHCSAdLoadAdmobBanner : PHCSAdLoadBanner<PHCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
