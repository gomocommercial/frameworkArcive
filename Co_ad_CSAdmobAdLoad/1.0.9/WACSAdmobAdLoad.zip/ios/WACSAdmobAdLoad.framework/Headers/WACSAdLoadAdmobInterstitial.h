//
//  WACSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <WACSAdSDK/WACSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface WACSAdLoadAdmobInterstitial : WACSAdLoadInterstitial<WACSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
