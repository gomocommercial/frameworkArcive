//
//  FLCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <FLCSAdSDK/FLCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <FLCSAdSDK/FLCSAdLoadProtocol.h>
#import <FLCSAdSDK/FLCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FLCSAdLoadAdmobInterstitial : FLCSAdLoadInterstitial<FLCSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
