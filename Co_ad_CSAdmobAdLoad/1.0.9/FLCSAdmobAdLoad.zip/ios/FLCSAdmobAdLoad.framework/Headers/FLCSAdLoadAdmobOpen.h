//
//  FLCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FLCSAdSDK/FLCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <FLCSAdSDK/FLCSAdLoadProtocol.h>
#import <FLCSAdSDK/FLCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FLCSAdLoadAdmobOpen : FLCSAdLoadOpen <FLCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
