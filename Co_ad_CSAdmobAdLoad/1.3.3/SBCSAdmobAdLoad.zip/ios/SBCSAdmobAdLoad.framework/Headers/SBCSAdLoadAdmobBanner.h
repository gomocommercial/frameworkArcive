//
//  SBCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <SBCSAdSDK/SBCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SBCSAdSDK/SBCSAdLoadProtocol.h>
#import <SBCSAdSDK/SBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface SBCSAdLoadAdmobBanner : SBCSAdLoadBanner<SBCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
