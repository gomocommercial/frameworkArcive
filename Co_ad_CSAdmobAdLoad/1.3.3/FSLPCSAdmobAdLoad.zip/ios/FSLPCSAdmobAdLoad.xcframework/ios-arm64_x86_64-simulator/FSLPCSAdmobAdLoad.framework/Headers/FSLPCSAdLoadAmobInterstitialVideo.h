//
//  FSLPCSAdLoadAmobInterstitialVideo.h
//  FSLPCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <FSLPCSAdSDK/FSLPCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadProtocol.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadAmobInterstitialVideo : FSLPCSAdLoadInterstitial<FSLPCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
