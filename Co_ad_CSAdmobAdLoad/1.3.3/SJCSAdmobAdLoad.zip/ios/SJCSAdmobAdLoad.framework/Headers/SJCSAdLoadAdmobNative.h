//
//  SJCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SJCSAdSDK/SJCSAdLoadNative.h>
#import <SJCSAdSDK/SJCSAdLoadProtocol.h>
#import <SJCSAdSDK/SJCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJCSAdLoadAdmobNative : SJCSAdLoadNative<SJCSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
