//
//  PTCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PTCSAdSDK/PTCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PTCSAdSDK/PTCSAdLoadProtocol.h>
#import <PTCSAdSDK/PTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface PTCSAdLoadAdmobBanner : PTCSAdLoadBanner<PTCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
