//
//  HSCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <HSCSAdSDK/HSCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <HSCSAdSDK/HSCSAdLoadProtocol.h>
#import <HSCSAdSDK/HSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface HSCSAdLoadAdmobBanner : HSCSAdLoadBanner<HSCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
