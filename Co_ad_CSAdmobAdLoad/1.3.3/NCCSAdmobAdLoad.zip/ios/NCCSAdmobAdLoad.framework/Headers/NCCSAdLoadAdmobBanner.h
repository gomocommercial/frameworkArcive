//
//  NCCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <NCCSAdSDK/NCCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <NCCSAdSDK/NCCSAdLoadProtocol.h>
#import <NCCSAdSDK/NCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface NCCSAdLoadAdmobBanner : NCCSAdLoadBanner<NCCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
