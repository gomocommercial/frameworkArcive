//
//  CUC_PCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface CUC_PCSAdLoadAdmobBanner : CUC_PCSAdLoadBanner<CUC_PCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
