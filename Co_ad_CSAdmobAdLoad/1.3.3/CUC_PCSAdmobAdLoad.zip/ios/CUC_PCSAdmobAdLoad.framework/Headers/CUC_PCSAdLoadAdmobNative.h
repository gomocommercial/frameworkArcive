//
//  CUC_PCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadNative.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadAdmobNative : CUC_PCSAdLoadNative<CUC_PCSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
