//
//  AWCSAdLoadAdmobConfig.h
//  AFNetworking
//
//  Created by Zy on 2020/11/2.
//

#import <Foundation/Foundation.h>
#import <AWCSAdmobAdLoad/AWCSAdmobConfigModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadAdmobConfig : NSObject

@property (nonatomic, strong, readonly) NSMutableArray<AWCSAdmobConfigModel *> *configs;


+ (instancetype)sharedInstance;

// MARK: - Banner配置(必须设置)
/// 设置谷歌Banner广告配置
/// @param modudleID 模块ID
/// @param bannerSize 因为提供的广告尺寸会为横幅广告提供固有内容尺寸，用来调整视图大小。如果您不想使用以常量定义的标准尺寸，则可以使用 GADAdSizeFromCGSize 设置自定义尺寸。
/// @param rootViewController(强引用,需要释放时需主动调用移除方法) 此视图控制器用于在用户点击广告后呈现重叠式广告。通常应将其设置为包含 GADBannerView 的视图控制器。
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdSize:(GADAdSize)bannerSize rootViewController:(UIViewController *)rootViewController;

//移除Banner配置
+ (void)removeBannerConfigWithMoudleId:(NSString *)modudleID;

// MARK: - Open开屏配置(可选配置)
/// 设置开屏广告配置
/// @param modudleID 模块ID
/// @param orientation 窗口方向（默认为UIInterfaceOrientationPortrait）
+ (void)setOpenConfigWithMoudleId:(NSString *)modudleID orientation:(UIInterfaceOrientation)orientation;

/// 最大值为5,不设置的话,就用谷歌默认值1
@property (nonatomic, assign) NSInteger nativeAdNumber;
@end

NS_ASSUME_NONNULL_END
