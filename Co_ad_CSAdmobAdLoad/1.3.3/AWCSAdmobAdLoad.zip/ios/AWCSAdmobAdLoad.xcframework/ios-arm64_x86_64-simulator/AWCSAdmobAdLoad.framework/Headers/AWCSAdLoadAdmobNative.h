//
//  AWCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <AWCSAdSDK/AWCSAdLoadNative.h>
#import <AWCSAdSDK/AWCSAdLoadProtocol.h>
#import <AWCSAdSDK/AWCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadAdmobNative : AWCSAdLoadNative<AWCSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
