//
//  PFCSAdLoadAmobInterstitialVideo.h
//  PFCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <PFCSAdSDK/PFCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PFCSAdSDK/PFCSAdLoadProtocol.h>
#import <PFCSAdSDK/PFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PFCSAdLoadAmobInterstitialVideo : PFCSAdLoadInterstitial<PFCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
