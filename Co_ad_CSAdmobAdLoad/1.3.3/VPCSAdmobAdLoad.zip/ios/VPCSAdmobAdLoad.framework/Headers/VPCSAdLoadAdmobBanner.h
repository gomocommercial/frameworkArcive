//
//  VPCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <VPCSAdSDK/VPCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <VPCSAdSDK/VPCSAdLoadProtocol.h>
#import <VPCSAdSDK/VPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface VPCSAdLoadAdmobBanner : VPCSAdLoadBanner<VPCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
