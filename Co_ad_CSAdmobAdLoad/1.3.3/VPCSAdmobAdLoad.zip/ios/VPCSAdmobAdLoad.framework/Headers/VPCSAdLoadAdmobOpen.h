//
//  VPCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <VPCSAdSDK/VPCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <VPCSAdSDK/VPCSAdLoadProtocol.h>
#import <VPCSAdSDK/VPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface VPCSAdLoadAdmobOpen : VPCSAdLoadOpen <VPCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
