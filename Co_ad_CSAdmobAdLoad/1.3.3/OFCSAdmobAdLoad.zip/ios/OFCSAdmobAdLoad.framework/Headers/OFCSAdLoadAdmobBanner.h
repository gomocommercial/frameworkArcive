//
//  OFCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <OFCSAdSDK/OFCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <OFCSAdSDK/OFCSAdLoadProtocol.h>
#import <OFCSAdSDK/OFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface OFCSAdLoadAdmobBanner : OFCSAdLoadBanner<OFCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
