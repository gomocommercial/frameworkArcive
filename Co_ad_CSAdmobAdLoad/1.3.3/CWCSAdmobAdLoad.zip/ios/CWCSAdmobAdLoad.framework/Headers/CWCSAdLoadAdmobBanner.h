//
//  CWCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CWCSAdSDK/CWCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CWCSAdSDK/CWCSAdLoadProtocol.h>
#import <CWCSAdSDK/CWCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface CWCSAdLoadAdmobBanner : CWCSAdLoadBanner<CWCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
