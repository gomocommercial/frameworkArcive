//
//  MGCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MGCSAdSDK/MGCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MGCSAdSDK/MGCSAdLoadProtocol.h>
#import <MGCSAdSDK/MGCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface MGCSAdLoadAdmobBanner : MGCSAdLoadBanner<MGCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
