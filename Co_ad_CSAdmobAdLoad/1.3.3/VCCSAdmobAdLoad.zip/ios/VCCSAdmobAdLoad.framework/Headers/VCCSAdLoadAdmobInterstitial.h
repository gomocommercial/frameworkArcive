//
//  VCCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <VCCSAdSDK/VCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <VCCSAdSDK/VCCSAdLoadProtocol.h>
#import <VCCSAdSDK/VCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface VCCSAdLoadAdmobInterstitial : VCCSAdLoadInterstitial<VCCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
