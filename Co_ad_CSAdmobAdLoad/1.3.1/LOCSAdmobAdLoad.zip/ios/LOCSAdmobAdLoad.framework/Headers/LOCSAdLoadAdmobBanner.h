//
//  LOCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LOCSAdSDK/LOCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface LOCSAdLoadAdmobBanner : LOCSAdLoadBanner<LOCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
