//
//  JPCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <JPCSAdSDK/JPCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdLoadAdmobOpen : JPCSAdLoadOpen <JPCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
