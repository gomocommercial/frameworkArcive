//
//  JPCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <JPCSAdSDK/JPCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdLoadAdmobReward : JPCSAdLoadReward<GADFullScreenContentDelegate,JPCSAdLoadProtocol>

@property(nonatomic, strong) GADRewardedAd *ad;


/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
