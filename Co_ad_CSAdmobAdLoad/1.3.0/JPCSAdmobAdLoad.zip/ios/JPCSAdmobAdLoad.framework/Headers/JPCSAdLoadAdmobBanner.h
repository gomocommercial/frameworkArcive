//
//  JPCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <JPCSAdSDK/JPCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface JPCSAdLoadAdmobBanner : JPCSAdLoadBanner<JPCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
