//
//  CSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CSAdSDK/CSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface CSAdLoadAdmobBanner : CSAdLoadBanner<CSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
