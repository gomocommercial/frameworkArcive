//
//  SMCSAdLoadAmobInterstitialVideo.h
//  SMCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <SMCSAdSDK/SMCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SMCSAdSDK/SMCSAdLoadProtocol.h>
#import <SMCSAdSDK/SMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SMCSAdLoadAmobInterstitialVideo : SMCSAdLoadInterstitial<SMCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
