//
//  SMCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <SMCSAdSDK/SMCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SMCSAdSDK/SMCSAdLoadProtocol.h>
#import <SMCSAdSDK/SMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface SMCSAdLoadAdmobBanner : SMCSAdLoadBanner<SMCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
