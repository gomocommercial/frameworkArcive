//
//  DCiosCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <DCiosCSAdSDK/DCiosCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadProtocol.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DCiosCSAdLoadAdmobInterstitial : DCiosCSAdLoadInterstitial<DCiosCSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

@end

NS_ASSUME_NONNULL_END
