//
//  DCiosCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <DCiosCSAdSDK/DCiosCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadProtocol.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DCiosCSAdLoadAdmobOpen : DCiosCSAdLoadOpen <DCiosCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
