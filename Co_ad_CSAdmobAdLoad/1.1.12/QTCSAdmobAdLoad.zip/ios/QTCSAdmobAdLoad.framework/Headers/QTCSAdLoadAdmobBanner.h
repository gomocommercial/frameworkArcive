//
//  QTCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <QTCSAdSDK/QTCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <QTCSAdSDK/QTCSAdLoadProtocol.h>
#import <QTCSAdSDK/QTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface QTCSAdLoadAdmobBanner : QTCSAdLoadBanner<QTCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
