//
//  SWCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <SWCSAdSDK/SWCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SWCSAdLoadAdmobReward : SWCSAdLoadReward<GADRewardBasedVideoAdDelegate,SWCSAdLoadProtocol>

@end

NS_ASSUME_NONNULL_END
