//
//  LTCCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LTCCSAdSDK/LTCCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LTCCSAdSDK/LTCCSAdLoadProtocol.h>
#import <LTCCSAdSDK/LTCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface LTCCSAdLoadAdmobBanner : LTCCSAdLoadBanner<LTCCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
