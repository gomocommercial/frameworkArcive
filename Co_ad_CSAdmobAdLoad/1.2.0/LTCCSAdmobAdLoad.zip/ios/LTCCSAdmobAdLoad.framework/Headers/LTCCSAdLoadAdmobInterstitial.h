//
//  LTCCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <LTCCSAdSDK/LTCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LTCCSAdSDK/LTCCSAdLoadProtocol.h>
#import <LTCCSAdSDK/LTCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LTCCSAdLoadAdmobInterstitial : LTCCSAdLoadInterstitial<LTCCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
