//
//  QRCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <QRCSAdSDK/QRCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <QRCSAdSDK/QRCSAdLoadProtocol.h>
#import <QRCSAdSDK/QRCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QRCSAdLoadAdmobReward : QRCSAdLoadReward<GADRewardBasedVideoAdDelegate,QRCSAdLoadProtocol>

@end

NS_ASSUME_NONNULL_END
