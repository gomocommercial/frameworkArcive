//
//  MJCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <MJCSAdSDK/MJCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MJCSAdSDK/MJCSAdLoadProtocol.h>
#import <MJCSAdSDK/MJCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MJCSAdLoadAdmobReward : MJCSAdLoadReward<GADRewardBasedVideoAdDelegate,MJCSAdLoadProtocol>

@end

NS_ASSUME_NONNULL_END
