//
//  MJCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <MJCSAdSDK/MJCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MJCSAdSDK/MJCSAdLoadProtocol.h>
#import <MJCSAdSDK/MJCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MJCSAdLoadAdmobInterstitial : MJCSAdLoadInterstitial<MJCSAdLoadProtocol,GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *ad;

@end

NS_ASSUME_NONNULL_END
