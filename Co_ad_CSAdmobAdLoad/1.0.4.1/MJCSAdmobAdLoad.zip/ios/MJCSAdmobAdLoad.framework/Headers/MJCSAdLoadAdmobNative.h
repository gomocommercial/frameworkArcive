//
//  MJCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MJCSAdSDK/MJCSAdLoadNative.h>
#import <MJCSAdSDK/MJCSAdLoadProtocol.h>
#import <MJCSAdSDK/MJCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MJCSAdLoadAdmobNative : MJCSAdLoadNative<MJCSAdLoadProtocol,GADUnifiedNativeAdLoaderDelegate, GADUnifiedNativeAdDelegate>

@property (nonatomic, strong) GADUnifiedNativeAd * ad;

@end

NS_ASSUME_NONNULL_END
