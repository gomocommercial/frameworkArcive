//
//  QTCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <QTCSAdSDK/QTCSAdLoadNative.h>
#import <QTCSAdSDK/QTCSAdLoadProtocol.h>
#import <QTCSAdSDK/QTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QTCSAdLoadAdmobNative : QTCSAdLoadNative<QTCSAdLoadProtocol,GADUnifiedNativeAdLoaderDelegate, GADUnifiedNativeAdDelegate>

@property (nonatomic, strong) GADUnifiedNativeAd * ad;

@end

NS_ASSUME_NONNULL_END
