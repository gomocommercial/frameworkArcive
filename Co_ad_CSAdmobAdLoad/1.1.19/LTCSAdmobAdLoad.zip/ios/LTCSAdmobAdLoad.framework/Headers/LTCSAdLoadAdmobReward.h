//
//  LTCSAdLoadAdmobReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/21.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <LTCSAdSDK/LTCSAdLoadReward.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <LTCSAdSDK/LTCSAdLoadProtocol.h>
#import <LTCSAdSDK/LTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LTCSAdLoadAdmobReward : LTCSAdLoadReward<GADFullScreenContentDelegate,LTCSAdLoadProtocol>

@property(nonatomic, strong) GADRewardedAd *ad;


/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
