//
//  DCCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <DCCSAdSDK/DCCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadAdmobInterstitial : DCCSAdLoadInterstitial<DCCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
