//
//  SSACSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <SSACSAdSDK/SSACSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <SSACSAdSDK/SSACSAdLoadProtocol.h>
#import <SSACSAdSDK/SSACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface SSACSAdLoadAdmobBanner : SSACSAdLoadBanner<SSACSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
