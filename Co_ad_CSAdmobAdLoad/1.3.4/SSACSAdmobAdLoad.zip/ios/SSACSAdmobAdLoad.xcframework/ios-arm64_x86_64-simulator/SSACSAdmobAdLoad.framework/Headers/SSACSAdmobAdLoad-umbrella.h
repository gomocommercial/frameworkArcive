#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "SSACSAdLoadAdmobBanner.h"
#import "SSACSAdLoadAdmobConfig.h"
#import "SSACSAdmobConfigModel.h"
#import "SSACSAdLoadAdmobInterstitial.h"
#import "SSACSAdLoadAmobInterstitialVideo.h"
#import "SSACSAdLoadAdmobNative.h"
#import "SSACSAdLoadAdmobOpen.h"
#import "SSACSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double SSACSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char SSACSAdmobAdLoadVersionString[];

