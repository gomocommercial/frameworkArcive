//
//  CUC_PCSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadAdmobInterstitial : CUC_PCSAdLoadInterstitial<CUC_PCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
