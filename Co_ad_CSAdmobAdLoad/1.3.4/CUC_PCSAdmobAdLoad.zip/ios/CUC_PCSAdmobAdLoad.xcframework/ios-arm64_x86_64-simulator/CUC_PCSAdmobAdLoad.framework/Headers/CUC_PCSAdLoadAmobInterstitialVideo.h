//
//  CUC_PCSAdLoadAmobInterstitialVideo.h
//  CUC_PCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadAmobInterstitialVideo : CUC_PCSAdLoadInterstitial<CUC_PCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
