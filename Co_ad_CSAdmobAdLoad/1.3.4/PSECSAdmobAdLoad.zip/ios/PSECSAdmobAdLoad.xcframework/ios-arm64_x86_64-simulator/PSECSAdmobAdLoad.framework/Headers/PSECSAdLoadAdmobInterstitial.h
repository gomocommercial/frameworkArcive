//
//  PSECSAdLoadAdmobInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <PSECSAdSDK/PSECSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PSECSAdSDK/PSECSAdLoadProtocol.h>
#import <PSECSAdSDK/PSECSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdLoadAdmobInterstitial : PSECSAdLoadInterstitial<PSECSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
