//
//  MLCCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MLCCSAdSDK/MLCCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MLCCSAdSDK/MLCCSAdLoadProtocol.h>
#import <MLCCSAdSDK/MLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface MLCCSAdLoadAdmobBanner : MLCCSAdLoadBanner<MLCCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
