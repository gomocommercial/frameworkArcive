//
//  JLCCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <JLCCSAdSDK/JLCCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <JLCCSAdSDK/JLCCSAdLoadProtocol.h>
#import <JLCCSAdSDK/JLCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadAdmobOpen : JLCCSAdLoadOpen <JLCCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
