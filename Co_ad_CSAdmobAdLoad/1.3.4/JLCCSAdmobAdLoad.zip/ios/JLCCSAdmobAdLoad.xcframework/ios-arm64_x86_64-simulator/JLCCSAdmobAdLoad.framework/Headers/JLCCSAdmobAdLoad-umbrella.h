#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "JLCCSAdLoadAdmobBanner.h"
#import "JLCCSAdLoadAdmobConfig.h"
#import "JLCCSAdmobConfigModel.h"
#import "JLCCSAdLoadAdmobInterstitial.h"
#import "JLCCSAdLoadAmobInterstitialVideo.h"
#import "JLCCSAdLoadAdmobNative.h"
#import "JLCCSAdLoadAdmobOpen.h"
#import "JLCCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double JLCCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char JLCCSAdmobAdLoadVersionString[];

