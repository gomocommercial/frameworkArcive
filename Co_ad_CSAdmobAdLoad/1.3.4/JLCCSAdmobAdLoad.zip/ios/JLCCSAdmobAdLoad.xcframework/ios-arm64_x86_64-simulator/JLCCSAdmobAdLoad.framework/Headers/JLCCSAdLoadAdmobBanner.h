//
//  JLCCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <JLCCSAdSDK/JLCCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <JLCCSAdSDK/JLCCSAdLoadProtocol.h>
#import <JLCCSAdSDK/JLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface JLCCSAdLoadAdmobBanner : JLCCSAdLoadBanner<JLCCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
