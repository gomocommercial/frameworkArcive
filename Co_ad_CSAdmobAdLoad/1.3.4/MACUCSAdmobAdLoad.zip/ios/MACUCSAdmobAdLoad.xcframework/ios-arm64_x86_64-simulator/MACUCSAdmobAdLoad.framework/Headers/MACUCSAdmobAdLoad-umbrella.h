#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MACUCSAdLoadAdmobBanner.h"
#import "MACUCSAdLoadAdmobConfig.h"
#import "MACUCSAdmobConfigModel.h"
#import "MACUCSAdLoadAdmobInterstitial.h"
#import "MACUCSAdLoadAmobInterstitialVideo.h"
#import "MACUCSAdLoadAdmobNative.h"
#import "MACUCSAdLoadAdmobOpen.h"
#import "MACUCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double MACUCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char MACUCSAdmobAdLoadVersionString[];

