#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "RVCSAdLoadAdmobBanner.h"
#import "RVCSAdLoadAdmobConfig.h"
#import "RVCSAdmobConfigModel.h"
#import "RVCSAdLoadAdmobInterstitial.h"
#import "RVCSAdLoadAmobInterstitialVideo.h"
#import "RVCSAdLoadAdmobNative.h"
#import "RVCSAdLoadAdmobOpen.h"
#import "RVCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double RVCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char RVCSAdmobAdLoadVersionString[];

