#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "PPP_PCSAdLoadAdmobBanner.h"
#import "PPP_PCSAdLoadAdmobConfig.h"
#import "PPP_PCSAdmobConfigModel.h"
#import "PPP_PCSAdLoadAdmobInterstitial.h"
#import "PPP_PCSAdLoadAmobInterstitialVideo.h"
#import "PPP_PCSAdLoadAdmobNative.h"
#import "PPP_PCSAdLoadAdmobOpen.h"
#import "PPP_PCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double PPP_PCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char PPP_PCSAdmobAdLoadVersionString[];

