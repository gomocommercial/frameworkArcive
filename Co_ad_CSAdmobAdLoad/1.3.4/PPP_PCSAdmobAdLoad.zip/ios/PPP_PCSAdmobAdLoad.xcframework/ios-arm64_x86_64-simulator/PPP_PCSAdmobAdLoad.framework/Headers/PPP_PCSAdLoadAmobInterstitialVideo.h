//
//  PPP_PCSAdLoadAmobInterstitialVideo.h
//  PPP_PCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <PPP_PCSAdSDK/PPP_PCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PPP_PCSAdSDK/PPP_PCSAdLoadProtocol.h>
#import <PPP_PCSAdSDK/PPP_PCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PCSAdLoadAmobInterstitialVideo : PPP_PCSAdLoadInterstitial<PPP_PCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
