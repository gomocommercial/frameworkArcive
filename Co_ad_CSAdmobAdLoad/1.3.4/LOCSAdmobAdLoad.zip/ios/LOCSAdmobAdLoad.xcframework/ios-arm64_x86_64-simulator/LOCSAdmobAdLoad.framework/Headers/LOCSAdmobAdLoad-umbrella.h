#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "LOCSAdLoadAdmobBanner.h"
#import "LOCSAdLoadAdmobConfig.h"
#import "LOCSAdmobConfigModel.h"
#import "LOCSAdLoadAdmobInterstitial.h"
#import "LOCSAdLoadAmobInterstitialVideo.h"
#import "LOCSAdLoadAdmobNative.h"
#import "LOCSAdLoadAdmobOpen.h"
#import "LOCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double LOCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char LOCSAdmobAdLoadVersionString[];

