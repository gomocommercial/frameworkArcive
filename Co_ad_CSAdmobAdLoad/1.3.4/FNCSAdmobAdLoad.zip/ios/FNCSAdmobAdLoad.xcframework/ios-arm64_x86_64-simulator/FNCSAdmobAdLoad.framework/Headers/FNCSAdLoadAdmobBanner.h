//
//  FNCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FNCSAdSDK/FNCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <FNCSAdSDK/FNCSAdLoadProtocol.h>
#import <FNCSAdSDK/FNCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface FNCSAdLoadAdmobBanner : FNCSAdLoadBanner<FNCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
