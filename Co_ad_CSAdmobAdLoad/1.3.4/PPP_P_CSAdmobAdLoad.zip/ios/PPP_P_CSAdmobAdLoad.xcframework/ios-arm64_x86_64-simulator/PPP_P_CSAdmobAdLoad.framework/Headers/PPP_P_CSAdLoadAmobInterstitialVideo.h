//
//  PPP_P_CSAdLoadAmobInterstitialVideo.h
//  PPP_P_CSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadProtocol.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSAdLoadAmobInterstitialVideo : PPP_P_CSAdLoadInterstitial<PPP_P_CSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
