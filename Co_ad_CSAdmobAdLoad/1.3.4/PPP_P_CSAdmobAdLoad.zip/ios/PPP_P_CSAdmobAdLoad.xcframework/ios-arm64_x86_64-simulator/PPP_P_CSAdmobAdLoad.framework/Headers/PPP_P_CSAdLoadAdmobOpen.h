//
//  PPP_P_CSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadProtocol.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSAdLoadAdmobOpen : PPP_P_CSAdLoadOpen <PPP_P_CSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
