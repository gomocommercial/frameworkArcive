//
//  PPP_P_CSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadProtocol.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface PPP_P_CSAdLoadAdmobBanner : PPP_P_CSAdLoadBanner<PPP_P_CSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
