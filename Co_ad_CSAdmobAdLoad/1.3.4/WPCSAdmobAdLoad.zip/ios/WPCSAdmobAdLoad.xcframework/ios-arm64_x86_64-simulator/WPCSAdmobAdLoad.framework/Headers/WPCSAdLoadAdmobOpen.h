//
//  WPCSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <WPCSAdSDK/WPCSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <WPCSAdSDK/WPCSAdLoadProtocol.h>
#import <WPCSAdSDK/WPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface WPCSAdLoadAdmobOpen : WPCSAdLoadOpen <WPCSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
