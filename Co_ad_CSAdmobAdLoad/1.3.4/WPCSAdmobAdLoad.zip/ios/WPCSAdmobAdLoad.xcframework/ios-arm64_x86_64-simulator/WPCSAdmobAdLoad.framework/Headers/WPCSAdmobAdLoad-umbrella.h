#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WPCSAdLoadAdmobBanner.h"
#import "WPCSAdLoadAdmobConfig.h"
#import "WPCSAdmobConfigModel.h"
#import "WPCSAdLoadAdmobInterstitial.h"
#import "WPCSAdLoadAmobInterstitialVideo.h"
#import "WPCSAdLoadAdmobNative.h"
#import "WPCSAdLoadAdmobOpen.h"
#import "WPCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double WPCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char WPCSAdmobAdLoadVersionString[];

