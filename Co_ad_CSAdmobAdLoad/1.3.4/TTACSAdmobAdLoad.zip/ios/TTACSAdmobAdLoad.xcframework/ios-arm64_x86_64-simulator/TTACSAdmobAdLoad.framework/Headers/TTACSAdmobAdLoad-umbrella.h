#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TTACSAdLoadAdmobBanner.h"
#import "TTACSAdLoadAdmobConfig.h"
#import "TTACSAdmobConfigModel.h"
#import "TTACSAdLoadAdmobInterstitial.h"
#import "TTACSAdLoadAmobInterstitialVideo.h"
#import "TTACSAdLoadAdmobNative.h"
#import "TTACSAdLoadAdmobOpen.h"
#import "TTACSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double TTACSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TTACSAdmobAdLoadVersionString[];

