//
//  JMSCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <JMSCSAdSDK/JMSCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <JMSCSAdSDK/JMSCSAdLoadProtocol.h>
#import <JMSCSAdSDK/JMSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface JMSCSAdLoadAdmobBanner : JMSCSAdLoadBanner<JMSCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
