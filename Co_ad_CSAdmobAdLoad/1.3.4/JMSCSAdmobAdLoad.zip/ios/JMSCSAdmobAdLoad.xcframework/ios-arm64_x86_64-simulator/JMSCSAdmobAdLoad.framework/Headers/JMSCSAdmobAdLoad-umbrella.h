#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "JMSCSAdLoadAdmobBanner.h"
#import "JMSCSAdLoadAdmobConfig.h"
#import "JMSCSAdmobConfigModel.h"
#import "JMSCSAdLoadAdmobInterstitial.h"
#import "JMSCSAdLoadAmobInterstitialVideo.h"
#import "JMSCSAdLoadAdmobNative.h"
#import "JMSCSAdLoadAdmobOpen.h"
#import "JMSCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double JMSCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char JMSCSAdmobAdLoadVersionString[];

