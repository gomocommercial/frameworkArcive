#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WPSCSAdLoadAdmobBanner.h"
#import "WPSCSAdLoadAdmobConfig.h"
#import "WPSCSAdmobConfigModel.h"
#import "WPSCSAdLoadAdmobInterstitial.h"
#import "WPSCSAdLoadAmobInterstitialVideo.h"
#import "WPSCSAdLoadAdmobNative.h"
#import "WPSCSAdLoadAdmobOpen.h"
#import "WPSCSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double WPSCSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char WPSCSAdmobAdLoadVersionString[];

