//
//  WPSCSAdLoadAmobInterstitialVideo.h
//  WPSCSAdmobAdLoad
//
//  Created by lv jiaxing on 2022/4/27.
//

#import <WPSCSAdSDK/WPSCSAdLoadInterstitial.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <WPSCSAdSDK/WPSCSAdLoadProtocol.h>
#import <WPSCSAdSDK/WPSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface WPSCSAdLoadAmobInterstitialVideo : WPSCSAdLoadInterstitial<WPSCSAdLoadProtocol,GADFullScreenContentDelegate>

@property(nonatomic, strong) GADRewardedInterstitialAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
