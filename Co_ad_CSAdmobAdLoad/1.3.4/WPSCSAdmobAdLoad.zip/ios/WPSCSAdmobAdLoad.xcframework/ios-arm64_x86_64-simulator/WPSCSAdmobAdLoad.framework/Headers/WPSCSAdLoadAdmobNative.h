//
//  WPSCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <WPSCSAdSDK/WPSCSAdLoadNative.h>
#import <WPSCSAdSDK/WPSCSAdLoadProtocol.h>
#import <WPSCSAdSDK/WPSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface WPSCSAdLoadAdmobNative : WPSCSAdLoadNative<WPSCSAdLoadProtocol,GADNativeAdLoaderDelegate, GADNativeAdDelegate>

@property (nonatomic, strong) GADNativeAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
