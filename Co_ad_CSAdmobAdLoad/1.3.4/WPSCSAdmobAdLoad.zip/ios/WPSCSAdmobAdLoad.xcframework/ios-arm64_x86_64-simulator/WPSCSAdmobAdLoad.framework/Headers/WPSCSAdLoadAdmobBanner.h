//
//  WPSCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <WPSCSAdSDK/WPSCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <WPSCSAdSDK/WPSCSAdLoadProtocol.h>
#import <WPSCSAdSDK/WPSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface WPSCSAdLoadAdmobBanner : WPSCSAdLoadBanner<WPSCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
