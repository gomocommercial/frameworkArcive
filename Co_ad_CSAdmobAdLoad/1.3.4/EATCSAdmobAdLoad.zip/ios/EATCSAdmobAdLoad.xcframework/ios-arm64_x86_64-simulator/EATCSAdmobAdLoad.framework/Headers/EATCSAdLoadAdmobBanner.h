//
//  EATCSAdLoadAdmobBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <EATCSAdSDK/EATCSAdLoadBanner.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <EATCSAdSDK/EATCSAdLoadProtocol.h>
#import <EATCSAdSDK/EATCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

//banner调用Show方法时target需传View
@interface EATCSAdLoadAdmobBanner : EATCSAdLoadBanner<EATCSAdLoadProtocol,GADBannerViewDelegate>


@property(nonatomic, strong) GADBannerView *ad;


@end

NS_ASSUME_NONNULL_END
