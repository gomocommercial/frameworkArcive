//
//  MEETAICSAdLoadAdmobOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MEETAICSAdSDK/MEETAICSAdLoadOpen.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadProtocol.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MEETAICSAdLoadAdmobOpen : MEETAICSAdLoadOpen <MEETAICSAdLoadProtocol,GADFullScreenContentDelegate>

@property (nonatomic, strong) GADAppOpenAd *ad;

/// 是否可以通过控制器展示
/// @param viewController 控制器
- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
