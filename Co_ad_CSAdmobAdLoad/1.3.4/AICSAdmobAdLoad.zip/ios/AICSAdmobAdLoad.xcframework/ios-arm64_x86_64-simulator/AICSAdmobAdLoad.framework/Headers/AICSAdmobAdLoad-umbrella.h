#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "AICSAdLoadAdmobBanner.h"
#import "AICSAdLoadAdmobConfig.h"
#import "AICSAdmobConfigModel.h"
#import "AICSAdLoadAdmobInterstitial.h"
#import "AICSAdLoadAmobInterstitialVideo.h"
#import "AICSAdLoadAdmobNative.h"
#import "AICSAdLoadAdmobOpen.h"
#import "AICSAdLoadAdmobReward.h"

FOUNDATION_EXPORT double AICSAdmobAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char AICSAdmobAdLoadVersionString[];

