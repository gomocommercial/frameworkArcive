//
//  WOCSAdLoadFacebookNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <WOCSAdSDK/WOCSAdLoadNative.h>
#import <WOCSAdSDK/WOCSAdLoadProtocol.h>
#import <WOCSAdSDK/WOCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface WOCSAdLoadFacebookNative : WOCSAdLoadNative<WOCSAdLoadProtocol,FBNativeAdDelegate>

@property(strong, nonatomic) FBNativeAd *ad;

@end

NS_ASSUME_NONNULL_END
