//
//  LECSAdLoadFacebookReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <LECSAdSDK/LECSAdLoadReward.h>
#import <LECSAdSDK/LECSAdLoadProtocol.h>
#import <LECSAdSDK/LECSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LECSAdLoadFacebookReward : LECSAdLoadReward<LECSAdLoadProtocol,FBRewardedVideoAdDelegate>

@property(nonatomic, strong) FBRewardedVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
