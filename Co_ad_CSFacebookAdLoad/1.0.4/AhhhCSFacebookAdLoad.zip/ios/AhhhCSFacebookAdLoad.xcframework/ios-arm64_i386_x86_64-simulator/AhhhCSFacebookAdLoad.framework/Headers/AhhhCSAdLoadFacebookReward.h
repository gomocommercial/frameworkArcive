//
//  AhhhCSAdLoadFacebookReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadReward.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadFacebookReward : AhhhCSAdLoadReward<AhhhCSAdLoadProtocol,FBRewardedVideoAdDelegate>

@property(nonatomic, strong) FBRewardedVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
