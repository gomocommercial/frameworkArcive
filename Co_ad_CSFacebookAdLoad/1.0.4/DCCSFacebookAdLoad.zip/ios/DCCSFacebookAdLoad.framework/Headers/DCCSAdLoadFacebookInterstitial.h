//
//  DCCSAdLoadFacebookInterstitial.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <DCCSAdSDK/DCCSAdLoadInterstitial.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadFacebookInterstitial : DCCSAdLoadInterstitial<DCCSAdLoadProtocol,FBInterstitialAdDelegate>

@property(nonatomic, strong) FBInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
