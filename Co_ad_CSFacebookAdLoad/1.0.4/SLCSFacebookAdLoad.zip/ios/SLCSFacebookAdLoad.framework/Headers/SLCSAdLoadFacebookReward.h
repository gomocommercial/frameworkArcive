//
//  SLCSAdLoadFacebookReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <SLCSAdSDK/SLCSAdLoadReward.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadFacebookReward : SLCSAdLoadReward<SLCSAdLoadProtocol,FBRewardedVideoAdDelegate>

@property(nonatomic, strong) FBRewardedVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
