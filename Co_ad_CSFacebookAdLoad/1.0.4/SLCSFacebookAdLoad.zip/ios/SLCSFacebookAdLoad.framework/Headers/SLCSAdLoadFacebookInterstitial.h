//
//  SLCSAdLoadFacebookInterstitial.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <SLCSAdSDK/SLCSAdLoadInterstitial.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadFacebookInterstitial : SLCSAdLoadInterstitial<SLCSAdLoadProtocol,FBInterstitialAdDelegate>

@property(nonatomic, strong) FBInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
