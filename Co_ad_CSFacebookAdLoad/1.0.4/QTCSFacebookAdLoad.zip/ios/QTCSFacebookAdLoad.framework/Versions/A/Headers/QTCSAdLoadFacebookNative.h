//
//  QTCSAdLoadFacebookNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <QTCSAdSDK/QTCSAdLoadNative.h>
#import <QTCSAdSDK/QTCSAdLoadProtocol.h>
#import <QTCSAdSDK/QTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QTCSAdLoadFacebookNative : QTCSAdLoadNative<QTCSAdLoadProtocol,FBNativeAdDelegate>

@property(strong, nonatomic) FBNativeAd *ad;

@end

NS_ASSUME_NONNULL_END
