//
//  QTCSAdLoadFacebookReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <QTCSAdSDK/QTCSAdLoadReward.h>
#import <QTCSAdSDK/QTCSAdLoadProtocol.h>
#import <QTCSAdSDK/QTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QTCSAdLoadFacebookReward : QTCSAdLoadReward<QTCSAdLoadProtocol,FBRewardedVideoAdDelegate>

@property(nonatomic, strong) FBRewardedVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
