//
//  QRCSAdLoadFacebookReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <QRCSAdSDK/QRCSAdLoadReward.h>
#import <QRCSAdSDK/QRCSAdLoadProtocol.h>
#import <QRCSAdSDK/QRCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QRCSAdLoadFacebookReward : QRCSAdLoadReward<QRCSAdLoadProtocol,FBRewardedVideoAdDelegate>

@property(nonatomic, strong) FBRewardedVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
