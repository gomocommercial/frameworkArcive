//
//  CSAdLoadFacebookNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <CSAdSDK/CSAdLoadNative.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadFacebookNative : CSAdLoadNative<CSAdLoadProtocol,FBNativeAdDelegate>

@property(strong, nonatomic) FBNativeAd *ad;

@end

NS_ASSUME_NONNULL_END
