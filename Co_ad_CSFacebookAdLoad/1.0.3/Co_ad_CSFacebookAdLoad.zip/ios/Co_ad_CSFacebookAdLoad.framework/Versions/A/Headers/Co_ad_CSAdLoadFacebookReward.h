//
//  Co_ad_CSAdLoadFacebookReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadReward.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadProtocol.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdLoadFacebookReward : Co_ad_CSAdLoadReward<Co_ad_CSAdLoadProtocol,FBRewardedVideoAdDelegate>

@property(nonatomic, strong) FBRewardedVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
