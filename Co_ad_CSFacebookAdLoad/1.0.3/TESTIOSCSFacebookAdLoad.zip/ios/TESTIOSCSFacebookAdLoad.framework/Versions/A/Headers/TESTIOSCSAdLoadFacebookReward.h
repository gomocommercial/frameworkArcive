//
//  TESTIOSCSAdLoadFacebookReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadReward.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadProtocol.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TESTIOSCSAdLoadFacebookReward : TESTIOSCSAdLoadReward<TESTIOSCSAdLoadProtocol,FBRewardedVideoAdDelegate>

@property(nonatomic, strong) FBRewardedVideoAd *ad;

@end

NS_ASSUME_NONNULL_END
