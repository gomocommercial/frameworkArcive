//
//  CSAdLoadDataProtocol.h
//  CSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "CSAdTypedef.h"

@class CSAdDataModel;
@class CSAdLoadBase;

@protocol CSAdLoadProtocol;

@protocol CSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)onAdInfoFinish:(CSAdLoadBase<CSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)onLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)onAdFail:(CSAdLoadBase<CSAdLoadProtocol> *)adload error:(NSError *)error;
@end
