//
//  SWCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sWkAdvDataSourceFacebook   2 //FB 广告数据源
#define sWkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sWkAdvDataSourceMopub      39//Mopub 广告数据源
#define sWkAdvDataSourceApplovin   20//applovin 广告数据源

#define sWkAdvDataSourceGDT        62//广点通 广告数据源
#define sWkAdvDataSourceBaidu      63//百度 广告数据源
#define sWkAdvDataSourceBU         64//头条 广告数据源
#define sWkAdvDataSourceABU         70//头条聚合 广告数据源
#define sWkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define sWkAdvDataSourcePangle     74//pangle 广告数据源

#define sWkOnlineAdvTypeBanner                   1  //banner
#define sWkOnlineAdvTypeInterstitial             2  //全屏
#define sWkOnlineAdvTypeNative                   3 //native
#define sWkOnlineAdvTypeVideo                    4 //视频
#define sWkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sWkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sWkOnlineAdvTypeOpen                     8 //开屏
#define sWkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define sWkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define sWkAdServerConfigError  -1 //服务器返回数据不正确
#define sWkAdLoadConfigFailed  -2 //广告加载失败


#define sWAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sWkCSAdInstallDays @"sWkCSAdInstallDays"
#define sWkCSAdModule_key @"sWkCSAdModule_key_%@"
#define sWkCSNewAdModule_key @"sWkCSNewAdModule_key_%@"
#define sWkCSAdInstallTime @"sWkCSAdInstallTime"
#define sWkCSAdInstallHours @"sWkCSAdInstallHours"
#define sWkCSAdLastGetServerTime @"sWkCSAdLastRequestTime"
#define sWkCSAdloadTime 30

#define sWkCSLoadAdTimeOutNotification @"sWKCSLoadAdTimeOutNotification"
#define sWkCSLoadAdTimeOutNotificationKey @"sWKCSLoadAdTimeOutKey"

