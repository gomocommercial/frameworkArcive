//
//  DCiosCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define dCioskAdvDataSourceFacebook   2 //FB 广告数据源
#define dCioskAdvDataSourceAdmob      8 //Admob 广告数据源
#define dCioskAdvDataSourceMopub      39//Mopub 广告数据源
#define dCioskAdvDataSourceApplovin   20//applovin 广告数据源

#define dCioskAdvDataSourceGDT        62//广点通 广告数据源
#define dCioskAdvDataSourceBaidu      63//百度 广告数据源
#define dCioskAdvDataSourceBU         64//头条 广告数据源
#define dCioskAdvDataSourceABU         70//头条聚合 广告数据源
#define dCioskAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define dCioskAdvDataSourcePangle     74//pangle 广告数据源

#define dCioskOnlineAdvTypeBanner                   1  //banner
#define dCioskOnlineAdvTypeInterstitial             2  //全屏
#define dCioskOnlineAdvTypeNative                   3 //native
#define dCioskOnlineAdvTypeVideo                    4 //视频
#define dCioskOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define dCioskOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define dCioskOnlineAdvTypeOpen                     8 //开屏
#define dCioskOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define dCioskOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define dCioskAdServerConfigError  -1 //服务器返回数据不正确
#define dCioskAdLoadConfigFailed  -2 //广告加载失败


#define dCiosAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define dCioskCSAdInstallDays @"dCioskCSAdInstallDays"
#define dCioskCSAdModule_key @"dCioskCSAdModule_key_%@"
#define dCioskCSNewAdModule_key @"dCioskCSNewAdModule_key_%@"
#define dCioskCSAdInstallTime @"dCioskCSAdInstallTime"
#define dCioskCSAdInstallHours @"dCioskCSAdInstallHours"
#define dCioskCSAdLastGetServerTime @"dCioskCSAdLastRequestTime"
#define dCioskCSAdloadTime 30

#define dCioskCSLoadAdTimeOutNotification @"dCiosKCSLoadAdTimeOutNotification"
#define dCioskCSLoadAdTimeOutNotificationKey @"dCiosKCSLoadAdTimeOutKey"

