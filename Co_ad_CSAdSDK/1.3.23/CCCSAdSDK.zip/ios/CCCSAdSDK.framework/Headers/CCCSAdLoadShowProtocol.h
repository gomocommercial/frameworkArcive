//
//  CCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CCCSAdTypedef.h"

@class CCCSAdLoadBase;

@protocol CCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cConAdShowed:(CCCSAdLoadBase<CCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cConAdClicked:(CCCSAdLoadBase<CCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cConAdClosed:(CCCSAdLoadBase<CCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cConAdVideoCompletePlaying:(CCCSAdLoadBase<CCCSAdLoadProtocol> *)adload;
/**
 激励视频获得奖励
 */
-(void)cConAdVideoGotReward:(CCCSAdLoadBase<CCCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)cConAdShowFail:(CCCSAdLoadBase<CCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cConAdOtherEvent:(CCCSAdLoadBase<CCCSAdLoadProtocol> *)adload event:(CCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
