//
//  Co_ad_CSAdLoadDataProtocol.h
//  Co_ad_CSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "Co_ad_CSAdTypedef.h"

@class Co_ad_CSAdDataModel;
@class Co_ad_CSAdLoadBase;

@protocol Co_ad_CSAdLoadProtocol;

@protocol Co_ad_CSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)co_ad_onAdInfoFinish:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)co_ad_onLoadAdConfigFail:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload error:(NSError *)error;


/**
 开始展示广告
 */
- (void)co_ad_onAdShowed:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)co_ad_onAdClicked:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload;


/**
 关闭广告
 */
- (void)co_ad_onAdClosed:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)co_ad_onAdVideoCompletePlaying:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)co_ad_onAdFail:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)co_ad_onAdOtherEvent:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload event:(Co_ad_CSAdEvent)event;

@end
