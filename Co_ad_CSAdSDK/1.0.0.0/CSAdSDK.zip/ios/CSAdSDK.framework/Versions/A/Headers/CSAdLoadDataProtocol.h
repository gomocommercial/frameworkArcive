//
//  CSAdLoadDataProtocol.h
//  CSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "CSAdTypedef.h"

@class CSAdDataModel;
@class CSAdLoadBase;

@protocol CSAdLoadProtocol;

@protocol CSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)onAdInfoFinish:(CSAdLoadBase<CSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)onLoadAdConfigFail:(CSAdLoadBase<CSAdLoadProtocol> *)adload error:(NSError *)error;


/**
 开始展示广告
 */
- (void)onAdShowed:(CSAdLoadBase<CSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)onAdClicked:(CSAdLoadBase<CSAdLoadProtocol> *)adload;


/**
 关闭广告
 */
- (void)onAdClosed:(CSAdLoadBase<CSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)onAdVideoCompletePlaying:(CSAdLoadBase<CSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)onAdFail:(CSAdLoadBase<CSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)onAdOtherEvent:(CSAdLoadBase<CSAdLoadProtocol> *)adload event:(CSAdEvent)event;

@end
