//
//  APLCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define aPLkAdvDataSourceFacebook   2 //FB 广告数据源
#define aPLkAdvDataSourceAdmob      8 //Admob 广告数据源
#define aPLkAdvDataSourceMopub      39//Mopub 广告数据源
#define aPLkAdvDataSourceApplovin   20//applovin 广告数据源

#define aPLkAdvDataSourceGDT        62//广点通 广告数据源
#define aPLkAdvDataSourceBaidu      63//百度 广告数据源
#define aPLkAdvDataSourceBU         64//头条 广告数据源


#define aPLkOnlineAdvTypeBanner                   1  //banner
#define aPLkOnlineAdvTypeInterstitial             2  //全屏
#define aPLkOnlineAdvTypeNative                   3 //native
#define aPLkOnlineAdvTypeVideo                    4 //视频
#define aPLkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define aPLkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define aPLkOnlineAdvTypeOpen                     8 //开屏

#define aPLkAdServerConfigError  -1 //服务器返回数据不正确
#define aPLkAdLoadConfigFailed  -2 //广告加载失败


#define aPLAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define aPLkCSAdInstallDays @"aPLkCSAdInstallDays"
#define aPLkCSAdModule_key @"aPLkCSAdModule_key_%@"
#define aPLkCSAdInstallTime @"aPLkCSAdInstallTime"
#define aPLkCSAdLastGetServerTime @"aPLkCSAdLastRequestTime"
#define aPLkCSAdloadTime 30

#define aPLkCSLoadAdTimeOutNotification @"aPLKCSLoadAdTimeOutNotification"
#define aPLkCSLoadAdTimeOutNotificationKey @"aPLKCSLoadAdTimeOutKey"

