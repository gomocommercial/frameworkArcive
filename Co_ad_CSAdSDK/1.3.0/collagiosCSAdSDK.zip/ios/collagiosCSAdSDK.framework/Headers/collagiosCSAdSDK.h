//
//  collagiosCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "collagiosCSAdLoadBase.h"
#import "collagiosCSAdDataModel.h"
#import "collagiosCSAdLoadProtocol.h"
#import "collagiosCSAdLoadDataProtocol.h"
#import "collagiosCSAdLoadShowProtocol.h"
#import "collagiosCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface collagiosCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)collagiossetupByBlock:(void (^ _Nonnull)(collagiosCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)collagiosloadAd:(NSString *)moduleId delegate:(id<collagiosCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)collagiosadShowStatistic:(collagiosCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)collagiosadClickStatistic:(collagiosCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)collagiosaddCustomFecher:(Class<collagiosCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
