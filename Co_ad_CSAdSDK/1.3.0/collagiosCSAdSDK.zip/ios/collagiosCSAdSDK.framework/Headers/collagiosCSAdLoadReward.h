//
//  collagiosCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "collagiosCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface collagiosCSAdLoadReward : collagiosCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
