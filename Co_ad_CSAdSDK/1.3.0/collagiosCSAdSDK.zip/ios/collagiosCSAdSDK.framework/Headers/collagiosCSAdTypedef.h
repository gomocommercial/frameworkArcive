//
//  collagiosCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    collagiosCSAdLoadSuccess = 1,
    collagiosCSAdLoadFailure = -1,
    collagiosCSAdLoadTimeout = -2
} collagiosCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    collagiosCSAdPreloadSuccess = 1,
    //预加载失败
    collagiosCSAdPreloadFailure = -1,
    //重复加载
    collagiosCSAdPreloadRepeat = -2,
} collagiosCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    collagiosCSAdWillAppear,//即将出现
    collagiosCSAdDidAppear,//已经出现
    collagiosCSAdWillDisappear,//即将消失
    collagiosCSAdDidDisappear,//已经消失
    collagiosCSAdMuted,//静音广告
    collagiosCSAdWillLeaveApplication,//将要离开App

    collagiosCSAdVideoStart,//开始播放 常用于video
    collagiosCSAdVideoComplete,//播放完成 常用于video
    collagiosCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    collagiosCSAdVideoServerFail,//连接服务器成功，常用于fb video

    collagiosCSAdNativeDidDownload,//下载完成 常用于fb Native
    collagiosCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    collagiosCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    collagiosCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    collagiosCSAdVideoSkip,//跳过播放
    
    //广点通 插屏专用
    collagiosCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    collagiosCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    collagiosCSAdDidPresentFullScreen,//插屏弹出全屏广告
    collagiosCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    collagiosCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    collagiosCSAdPlayerStatusStarted,//开始播放
    collagiosCSAdPlayerStatusPaused,//用户行为导致暂停
    collagiosCSAdPlayerStatusStoped,//播放停止
    collagiosCSAdPlayerStatusError,//播放出错
    collagiosCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    collagiosCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    collagiosCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    collagiosCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    collagiosCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    collagiosCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    collagiosCSAdRecordImpression, //广告曝光已记录
    collagiosCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    collagiosCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    collagiosCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开

} collagiosCSAdEvent;

typedef void (^collagiosCSAdLoadCompleteBlock)(collagiosCSAdLoadStatus adLoadStatus);

@class collagiosCSAdSetupParamsMaker;
@class collagiosCSAdSetupParams;

typedef collagiosCSAdSetupParamsMaker *(^collagiosCSAdStringInit)(NSString *);
typedef collagiosCSAdSetupParamsMaker *(^collagiosCSAdBoolInit)(BOOL);
typedef collagiosCSAdSetupParamsMaker *(^collagiosCSAdIntegerInit)(NSInteger);
typedef collagiosCSAdSetupParamsMaker *(^collagiosCSAdLongInit)(long);
typedef collagiosCSAdSetupParamsMaker *(^collagiosCSAdArrayInit)(NSArray *);
typedef collagiosCSAdSetupParams *(^collagiosCSAdMakeInit)(void);


@class collagiosCSAdDataModel;
typedef void (^collagiosCSAdRequestCompleteBlock)(NSMutableArray<collagiosCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^collagiosCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^collagiosCSAdPreloadCompleteBlock)(collagiosCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
