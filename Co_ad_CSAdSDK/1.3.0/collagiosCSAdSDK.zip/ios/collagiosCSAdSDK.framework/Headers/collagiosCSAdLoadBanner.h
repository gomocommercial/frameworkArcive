//
//  collagiosCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "collagiosCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface collagiosCSAdLoadBanner : collagiosCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
