//
//  DCCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "DCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadOpen : DCCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
