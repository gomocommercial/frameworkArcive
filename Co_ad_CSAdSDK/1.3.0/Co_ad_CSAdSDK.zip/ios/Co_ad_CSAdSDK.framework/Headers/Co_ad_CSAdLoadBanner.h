//
//  Co_ad_CSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "Co_ad_CSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdLoadBanner : Co_ad_CSAdLoadBase

@end

NS_ASSUME_NONNULL_END
