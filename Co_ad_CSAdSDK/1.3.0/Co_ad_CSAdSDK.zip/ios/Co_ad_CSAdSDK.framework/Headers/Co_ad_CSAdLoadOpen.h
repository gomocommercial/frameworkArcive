//
//  Co_ad_CSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "Co_ad_CSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdLoadOpen : Co_ad_CSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
