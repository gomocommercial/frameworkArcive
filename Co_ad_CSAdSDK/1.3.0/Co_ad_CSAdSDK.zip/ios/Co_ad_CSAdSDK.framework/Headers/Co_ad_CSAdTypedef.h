//
//  Co_ad_CSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    Co_ad_CSAdLoadSuccess = 1,
    Co_ad_CSAdLoadFailure = -1,
    Co_ad_CSAdLoadTimeout = -2
} Co_ad_CSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    Co_ad_CSAdPreloadSuccess = 1,
    //预加载失败
    Co_ad_CSAdPreloadFailure = -1,
    //重复加载
    Co_ad_CSAdPreloadRepeat = -2,
} Co_ad_CSAdPreloadStatus;


typedef enum : NSUInteger {
    
    Co_ad_CSAdWillAppear,//即将出现
    Co_ad_CSAdDidAppear,//已经出现
    Co_ad_CSAdWillDisappear,//即将消失
    Co_ad_CSAdDidDisappear,//已经消失
    Co_ad_CSAdMuted,//静音广告
    Co_ad_CSAdWillLeaveApplication,//将要离开App

    Co_ad_CSAdVideoStart,//开始播放 常用于video
    Co_ad_CSAdVideoComplete,//播放完成 常用于video
    Co_ad_CSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    Co_ad_CSAdVideoServerFail,//连接服务器成功，常用于fb video

    Co_ad_CSAdNativeDidDownload,//下载完成 常用于fb Native
    Co_ad_CSAdNativeFinishClick,//完成点击 常用与fb Native
    
    Co_ad_CSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    Co_ad_CSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    Co_ad_CSAdVideoSkip,//跳过播放
    
    //广点通 插屏专用
    Co_ad_CSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    Co_ad_CSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    Co_ad_CSAdDidPresentFullScreen,//插屏弹出全屏广告
    Co_ad_CSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    Co_ad_CSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    Co_ad_CSAdPlayerStatusStarted,//开始播放
    Co_ad_CSAdPlayerStatusPaused,//用户行为导致暂停
    Co_ad_CSAdPlayerStatusStoped,//播放停止
    Co_ad_CSAdPlayerStatusError,//播放出错
    Co_ad_CSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    Co_ad_CSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    Co_ad_CSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    Co_ad_CSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    Co_ad_CSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    Co_ad_CSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    Co_ad_CSAdRecordImpression, //广告曝光已记录
    Co_ad_CSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    Co_ad_CSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    Co_ad_CSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开

} Co_ad_CSAdEvent;

typedef void (^Co_ad_CSAdLoadCompleteBlock)(Co_ad_CSAdLoadStatus adLoadStatus);

@class Co_ad_CSAdSetupParamsMaker;
@class Co_ad_CSAdSetupParams;

typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdStringInit)(NSString *);
typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdBoolInit)(BOOL);
typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdIntegerInit)(NSInteger);
typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdLongInit)(long);
typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdArrayInit)(NSArray *);
typedef Co_ad_CSAdSetupParams *(^Co_ad_CSAdMakeInit)(void);


@class Co_ad_CSAdDataModel;
typedef void (^Co_ad_CSAdRequestCompleteBlock)(NSMutableArray<Co_ad_CSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^Co_ad_CSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^Co_ad_CSAdPreloadCompleteBlock)(Co_ad_CSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
