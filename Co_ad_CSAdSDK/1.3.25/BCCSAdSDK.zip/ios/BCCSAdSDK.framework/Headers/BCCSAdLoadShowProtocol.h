//
//  BCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "BCCSAdTypedef.h"

@class BCCSAdLoadBase;

@protocol BCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol BCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)bConAdShowed:(BCCSAdLoadBase<BCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)bConAdClicked:(BCCSAdLoadBase<BCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)bConAdClosed:(BCCSAdLoadBase<BCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)bConAdVideoCompletePlaying:(BCCSAdLoadBase<BCCSAdLoadProtocol> *)adload;
/**
 激励视频获得奖励
 */
-(void)bConAdVideoGotReward:(BCCSAdLoadBase<BCCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)bConAdShowFail:(BCCSAdLoadBase<BCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)bConAdOtherEvent:(BCCSAdLoadBase<BCCSAdLoadProtocol> *)adload event:(BCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
