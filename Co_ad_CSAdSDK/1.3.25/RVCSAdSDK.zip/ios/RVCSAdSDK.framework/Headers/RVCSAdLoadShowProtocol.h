//
//  RVCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "RVCSAdTypedef.h"

@class RVCSAdLoadBase;

@protocol RVCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol RVCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)rVonAdShowed:(RVCSAdLoadBase<RVCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)rVonAdClicked:(RVCSAdLoadBase<RVCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)rVonAdClosed:(RVCSAdLoadBase<RVCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)rVonAdVideoCompletePlaying:(RVCSAdLoadBase<RVCSAdLoadProtocol> *)adload;
/**
 激励视频获得奖励
 */
-(void)rVonAdVideoGotReward:(RVCSAdLoadBase<RVCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)rVonAdShowFail:(RVCSAdLoadBase<RVCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)rVonAdOtherEvent:(RVCSAdLoadBase<RVCSAdLoadProtocol> *)adload event:(RVCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
