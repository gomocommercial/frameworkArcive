//
//  RVCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "RVCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface RVCSAdLoadNative : RVCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
