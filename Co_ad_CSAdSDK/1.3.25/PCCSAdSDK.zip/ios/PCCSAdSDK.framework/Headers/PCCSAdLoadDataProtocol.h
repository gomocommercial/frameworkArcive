//
//  PCCSAdLoadDataProtocol.h
//  PCCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PCCSAdTypedef.h"

@class PCCSAdDataModel;
@class PCCSAdLoadBase;

@protocol PCCSAdLoadProtocol;

@protocol PCCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)pConAdInfoFinish:(PCCSAdLoadBase<PCCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)pConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)pConAdFail:(PCCSAdLoadBase<PCCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
