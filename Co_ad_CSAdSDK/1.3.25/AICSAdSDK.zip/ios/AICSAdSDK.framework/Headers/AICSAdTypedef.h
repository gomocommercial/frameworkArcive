//
//  AICSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    AICSAdLoadSuccess = 1,
    AICSAdLoadFailure = -1,
    AICSAdLoadTimeout = -2
} AICSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    AICSAdPreloadSuccess = 1,
    //预加载失败
    AICSAdPreloadFailure = -1,
    //重复加载
    AICSAdPreloadRepeat = -2,
} AICSAdPreloadStatus;


typedef enum : NSUInteger {
    
    AICSAdWillAppear,//即将出现
    AICSAdDidAppear,//已经出现
    AICSAdWillDisappear,//即将消失
    AICSAdDidDisappear,//已经消失
    AICSAdMuted,//静音广告
    AICSAdWillLeaveApplication,//将要离开App

    AICSAdVideoStart,//开始播放 常用于video
    AICSAdVideoComplete,//播放完成 常用于video
    AICSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    AICSAdVideoServerFail,//连接服务器成功，常用于fb video

    AICSAdNativeDidDownload,//下载完成 常用于fb Native
    AICSAdNativeFinishClick,//完成点击 常用与fb Native
    
    AICSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    AICSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    AICSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    AICSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    AICSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    AICSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    AICSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    AICSAdBUOpenDidAutoDimiss,//开屏自动消失
    AICSAdBUOpenRenderSuccess, //渲染成功
    AICSAdBUOpenRenderFail, //渲染失败
    AICSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    AICSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    AICSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    AICSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    AICSAdDidPresentFullScreen,//插屏弹出全屏广告
    AICSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    AICSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    AICSAdPlayerStatusStarted,//开始播放
    AICSAdPlayerStatusPaused,//用户行为导致暂停
    AICSAdPlayerStatusStoped,//播放停止
    AICSAdPlayerStatusError,//播放出错
    AICSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    AICSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    AICSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    AICSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    AICSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    AICSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    AICSAdRecordImpression, //广告曝光已记录
    AICSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    AICSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    AICSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    AICSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    AICSAdABUOpenWillPresentFullScreen,
    AICSAdABUOpenDidShowFailed,
    AICSAdABUOpenWillDissmissFullScreen,
    AICSAdABUOpenCountdownToZero,
    
    AICSAdABUBannerWillPresentFullScreen,
    AICSAdABUBannerWillDismissFullScreen,
    
    AICSAdABURewardDidLoad,
    AICSAdABURewardRenderFail,
    AICSAdABURewardDidShowFailed,

} AICSAdEvent;

typedef void (^AICSAdLoadCompleteBlock)(AICSAdLoadStatus adLoadStatus);

@class AICSAdSetupParamsMaker;
@class AICSAdSetupParams;

typedef AICSAdSetupParamsMaker *(^AICSAdStringInit)(NSString *);
typedef AICSAdSetupParamsMaker *(^AICSAdBoolInit)(BOOL);
typedef AICSAdSetupParamsMaker *(^AICSAdIntegerInit)(NSInteger);
typedef AICSAdSetupParamsMaker *(^AICSAdLongInit)(long);
typedef AICSAdSetupParamsMaker *(^AICSAdArrayInit)(NSArray *);
typedef AICSAdSetupParams *(^AICSAdMakeInit)(void);


@class AICSAdDataModel;
typedef void (^AICSAdRequestCompleteBlock)(NSMutableArray<AICSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^AICSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^AICSAdPreloadCompleteBlock)(AICSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
