//
//  AICSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "AICSAdTypedef.h"

@class AICSAdLoadBase;

@protocol AICSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol AICSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)aIonAdShowed:(AICSAdLoadBase<AICSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)aIonAdClicked:(AICSAdLoadBase<AICSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)aIonAdClosed:(AICSAdLoadBase<AICSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)aIonAdVideoCompletePlaying:(AICSAdLoadBase<AICSAdLoadProtocol> *)adload;
/**
 激励视频获得奖励
 */
-(void)aIonAdVideoGotReward:(AICSAdLoadBase<AICSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)aIonAdShowFail:(AICSAdLoadBase<AICSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)aIonAdOtherEvent:(AICSAdLoadBase<AICSAdLoadProtocol> *)adload event:(AICSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
