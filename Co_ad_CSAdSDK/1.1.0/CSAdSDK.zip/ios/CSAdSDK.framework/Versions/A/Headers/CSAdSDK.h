//
//  CSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "CSAdLoadBase.h"
#import "CSAdDataModel.h"
#import "CSAdLoadProtocol.h"
#import "CSAdLoadDataProtocol.h"
#import "CSAdLoadShowProtocol.h"
#import "CSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)setupByBlock:(void (^ _Nonnull)(CSAdSetupParamsMaker *maker))block;


// MARK: - -------------------预加载接口(对广告实例进行管理 仅限管理一条广告数据，仅支持插屏和激励视频广告)--------------------------

/**
 广告预加载

 @param moduleId 模块ID
 @param completion 加载完成回调
 */
+ (void)preload:(NSString *)moduleId completion:(CSAdPreloadCompleteBlock _Nullable)completion;


/**
 广告是否已经准备好
 */
+ (BOOL)preloadValid;

/**
 广告展示

 @param viewCtrl 控制器
 @param showDelegate 展示代理
 */
+ (void)preloadShow:(UIViewController *)viewCtrl showDelegate:(id<CSAdLoadShowProtocol>)showDelegate;



// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)loadAd:(NSString *)moduleId delegate:(id<CSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)adShowStatistic:(CSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)adClickStatistic:(CSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)addCustomFecher:(Class<CSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
