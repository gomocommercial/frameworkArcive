//
//  CSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CSAdLoadSuccess = 1,
    CSAdLoadFailure = -1,
    CSAdLoadTimeout = -2
} CSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CSAdPreloadSuccess = 1,
    //预加载失败
    CSAdPreloadFailure = -1,
    //重复加载
    CSAdPreloadRepeat = -2,
} CSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CSAdWillAppear,//即将出现
    CSAdDidAppear,//已经出现
    CSAdWillDisappear,//即将消失
    CSAdDidDisappear,//已经消失
    CSAdMuted,//静音广告
    CSAdWillLeaveApplication,//将要离开App

    CSAdVideoStart,//开始播放 常用于video
    CSAdVideoComplete,//播放完成 常用于video
    CSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CSAdVideoServerFail,//连接服务器成功，常用于fb video

    CSAdNativeDidDownload,//下载完成 常用于fb Native
    CSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CSAdVideoSkip//跳过播放
} CSAdEvent;

typedef void (^CSAdLoadCompleteBlock)(CSAdLoadStatus adLoadStatus);

@class CSAdSetupParamsMaker;
@class CSAdSetupParams;

typedef CSAdSetupParamsMaker *(^CSAdStringInit)(NSString *);
typedef CSAdSetupParamsMaker *(^CSAdBoolInit)(BOOL);
typedef CSAdSetupParamsMaker *(^CSAdIntegerInit)(NSInteger);
typedef CSAdSetupParamsMaker *(^CSAdLongInit)(long);
typedef CSAdSetupParamsMaker *(^CSAdArrayInit)(NSArray *);
typedef CSAdSetupParams *(^CSAdMakeInit)(void);


@class CSAdDataModel;
typedef void (^CSAdRequestCompleteBlock)(NSMutableArray<CSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CSAdPreloadCompleteBlock)(CSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
