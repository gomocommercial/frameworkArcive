//
//  QTCSAdLoadDataProtocol.h
//  QTCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "QTCSAdTypedef.h"

@class QTCSAdDataModel;
@class QTCSAdLoadBase;

@protocol QTCSAdLoadProtocol;

@protocol QTCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)qTonAdInfoFinish:(QTCSAdLoadBase<QTCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)qTonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)qTonAdFail:(QTCSAdLoadBase<QTCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
