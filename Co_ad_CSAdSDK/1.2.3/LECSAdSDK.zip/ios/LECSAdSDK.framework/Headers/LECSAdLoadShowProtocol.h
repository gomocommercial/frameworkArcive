//
//  LECSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LECSAdTypedef.h"

@class LECSAdLoadBase;

@protocol LECSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LECSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lEonAdShowed:(LECSAdLoadBase<LECSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)lEonAdClicked:(LECSAdLoadBase<LECSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lEonAdClosed:(LECSAdLoadBase<LECSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lEonAdVideoCompletePlaying:(LECSAdLoadBase<LECSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)lEonAdShowFail:(LECSAdLoadBase<LECSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lEonAdOtherEvent:(LECSAdLoadBase<LECSAdLoadProtocol> *)adload event:(LECSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
