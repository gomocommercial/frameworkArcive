//
//  LECSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "LECSAdLoadBase.h"
#import "LECSAdDataModel.h"
#import "LECSAdLoadProtocol.h"
#import "LECSAdLoadDataProtocol.h"
#import "LECSAdLoadShowProtocol.h"
#import "LECSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface LECSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)lEsetupByBlock:(void (^ _Nonnull)(LECSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)lEloadAd:(NSString *)moduleId delegate:(id<LECSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)lEadShowStatistic:(LECSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)lEadClickStatistic:(LECSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)lEaddCustomFecher:(Class<LECSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
