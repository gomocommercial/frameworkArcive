//
//  LECSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lEkAdvDataSourceFacebook   2 //FB 广告数据源
#define lEkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lEkAdvDataSourceMopub      39//Mopub 广告数据源
#define lEkAdvDataSourceApplovin   20//applovin 广告数据源

#define lEkAdvDataSourceGDT        62//广点通 广告数据源
#define lEkAdvDataSourceBaidu      63//百度 广告数据源
#define lEkAdvDataSourceBU         64//头条 广告数据源


#define lEkOnlineAdvTypeBanner                   1  //banner
#define lEkOnlineAdvTypeInterstitial             2  //全屏
#define lEkOnlineAdvTypeNative                   3 //native
#define lEkOnlineAdvTypeVideo                    4 //视频
#define lEkOnlineAdvTypeMinBanner                5 //banner(300*250)
#define lEkOnlineAdvTypeInterstitialVideo        7 //插屏视频

#define lEkAdServerConfigError  -1 //服务器返回数据不正确
#define lEkAdLoadConfigFailed  -2 //广告加载失败


#define lEAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lEkCSAdInstallDays @"lEkCSAdInstallDays"
#define lEkCSAdModule_key @"lEkCSAdModule_key_%@"
#define lEkCSAdInstallTime @"lEkCSAdInstallTime"
#define lEkCSAdLastGetServerTime @"lEkCSAdLastRequestTime"
#define lEkCSAdloadTime 30

#define lEkCSLoadAdTimeOutNotification @"lEKCSLoadAdTimeOutNotification"
#define lEkCSLoadAdTimeOutNotificationKey @"lEKCSLoadAdTimeOutKey"

