//
//  LECSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    LECSAdLoadSuccess = 1,
    LECSAdLoadFailure = -1,
    LECSAdLoadTimeout = -2
} LECSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    LECSAdPreloadSuccess = 1,
    //预加载失败
    LECSAdPreloadFailure = -1,
    //重复加载
    LECSAdPreloadRepeat = -2,
} LECSAdPreloadStatus;


typedef enum : NSUInteger {
    
    LECSAdWillAppear,//即将出现
    LECSAdDidAppear,//已经出现
    LECSAdWillDisappear,//即将消失
    LECSAdDidDisappear,//已经消失
    LECSAdMuted,//静音广告
    LECSAdWillLeaveApplication,//将要离开App

    LECSAdVideoStart,//开始播放 常用于video
    LECSAdVideoComplete,//播放完成 常用于video
    LECSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    LECSAdVideoServerFail,//连接服务器成功，常用于fb video

    LECSAdNativeDidDownload,//下载完成 常用于fb Native
    LECSAdNativeFinishClick,//完成点击 常用与fb Native
    
    LECSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    LECSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    LECSAdVideoSkip//跳过播放
} LECSAdEvent;

typedef void (^LECSAdLoadCompleteBlock)(LECSAdLoadStatus adLoadStatus);

@class LECSAdSetupParamsMaker;
@class LECSAdSetupParams;

typedef LECSAdSetupParamsMaker *(^LECSAdStringInit)(NSString *);
typedef LECSAdSetupParamsMaker *(^LECSAdBoolInit)(BOOL);
typedef LECSAdSetupParamsMaker *(^LECSAdIntegerInit)(NSInteger);
typedef LECSAdSetupParamsMaker *(^LECSAdLongInit)(long);
typedef LECSAdSetupParamsMaker *(^LECSAdArrayInit)(NSArray *);
typedef LECSAdSetupParams *(^LECSAdMakeInit)(void);


@class LECSAdDataModel;
typedef void (^LECSAdRequestCompleteBlock)(NSMutableArray<LECSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^LECSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^LECSAdPreloadCompleteBlock)(LECSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
