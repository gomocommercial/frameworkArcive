//
//  LECSAdLoadDataProtocol.h
//  LECSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "LECSAdTypedef.h"

@class LECSAdDataModel;
@class LECSAdLoadBase;

@protocol LECSAdLoadProtocol;

@protocol LECSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)lEonAdInfoFinish:(LECSAdLoadBase<LECSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)lEonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)lEonAdFail:(LECSAdLoadBase<LECSAdLoadProtocol> *)adload error:(NSError *)error;
@end
