//
//  MJCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    MJCSAdLoadSuccess = 1,
    MJCSAdLoadFailure = -1,
    MJCSAdLoadTimeout = -2
} MJCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    MJCSAdPreloadSuccess = 1,
    //预加载失败
    MJCSAdPreloadFailure = -1,
    //重复加载
    MJCSAdPreloadRepeat = -2,
} MJCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    MJCSAdWillAppear,//即将出现
    MJCSAdDidAppear,//已经出现
    MJCSAdWillDisappear,//即将消失
    MJCSAdDidDisappear,//已经消失
    MJCSAdMuted,//静音广告
    MJCSAdWillLeaveApplication,//将要离开App

    MJCSAdVideoStart,//开始播放 常用于video
    MJCSAdVideoComplete,//播放完成 常用于video
    MJCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    MJCSAdVideoServerFail,//连接服务器成功，常用于fb video

    MJCSAdNativeDidDownload,//下载完成 常用于fb Native
    MJCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    MJCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    MJCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    MJCSAdVideoSkip//跳过播放
} MJCSAdEvent;

typedef void (^MJCSAdLoadCompleteBlock)(MJCSAdLoadStatus adLoadStatus);

@class MJCSAdSetupParamsMaker;
@class MJCSAdSetupParams;

typedef MJCSAdSetupParamsMaker *(^MJCSAdStringInit)(NSString *);
typedef MJCSAdSetupParamsMaker *(^MJCSAdBoolInit)(BOOL);
typedef MJCSAdSetupParamsMaker *(^MJCSAdIntegerInit)(NSInteger);
typedef MJCSAdSetupParamsMaker *(^MJCSAdLongInit)(long);
typedef MJCSAdSetupParamsMaker *(^MJCSAdArrayInit)(NSArray *);
typedef MJCSAdSetupParams *(^MJCSAdMakeInit)(void);


@class MJCSAdDataModel;
typedef void (^MJCSAdRequestCompleteBlock)(NSMutableArray<MJCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^MJCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^MJCSAdPreloadCompleteBlock)(MJCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
