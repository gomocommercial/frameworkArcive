//
//  JPCSAdLoadDataProtocol.h
//  JPCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "JPCSAdTypedef.h"

@class JPCSAdDataModel;
@class JPCSAdLoadBase;

@protocol JPCSAdLoadProtocol;

@protocol JPCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)jPonAdInfoFinish:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)jPonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)jPonAdFail:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
