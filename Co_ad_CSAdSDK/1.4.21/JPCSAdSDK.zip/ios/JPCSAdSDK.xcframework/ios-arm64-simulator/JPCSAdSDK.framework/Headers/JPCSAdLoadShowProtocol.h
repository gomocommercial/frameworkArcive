//
//  JPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "JPCSAdTypedef.h"

@class JPCSAdLoadBase;

@protocol JPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol JPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)jPonAdShowed:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)jPonAdClicked:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)jPonAdClosed:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)jPonAdVideoCompletePlaying:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)jPonAdVideoGotReward:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload;
-(void)jPonAdDidPayRevenue:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)jPonAdDidGetEcpm:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)jPonAdShowFail:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)jPonAdOtherEvent:(JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload event:(JPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
