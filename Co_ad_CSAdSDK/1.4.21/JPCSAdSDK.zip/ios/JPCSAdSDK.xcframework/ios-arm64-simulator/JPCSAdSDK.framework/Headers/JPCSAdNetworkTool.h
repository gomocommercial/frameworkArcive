//
//  JPCSAdNetworkTool.h
//  JPCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "JPCSAdDataModel.h"
#import "JPCSAdTypedef.h"
#import "JPCSNewStoreLiteRequestTool.h"
#import "NSString+JPCSGenerateHash.h"

@interface JPCSAdNetworkTool : NSObject

+ (JPCSAdNetworkTool *)shared;
@property(nonatomic, copy) JPCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)jPrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(JPCSAdRequestCompleteBlock)complete;

- (void)jPsetCDay:(void(^ _Nullable)(bool success))handle;
@end
