//
//  JPCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "JPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdLoadOpen : JPCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
