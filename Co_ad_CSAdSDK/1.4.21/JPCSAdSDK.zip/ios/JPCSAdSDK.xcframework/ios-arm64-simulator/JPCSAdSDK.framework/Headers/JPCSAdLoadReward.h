//
//  JPCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "JPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdLoadReward : JPCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
