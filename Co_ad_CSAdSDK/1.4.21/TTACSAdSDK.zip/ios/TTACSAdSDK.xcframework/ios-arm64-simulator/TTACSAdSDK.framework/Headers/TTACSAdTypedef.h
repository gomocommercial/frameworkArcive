//
//  TTACSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TTACSAdLoadSuccess = 1,
    TTACSAdLoadFailure = -1,
    TTACSAdLoadTimeout = -2
} TTACSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TTACSAdPreloadSuccess = 1,
    //预加载失败
    TTACSAdPreloadFailure = -1,
    //重复加载
    TTACSAdPreloadRepeat = -2,
} TTACSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TTACSAdWillAppear,//即将出现
    TTACSAdDidAppear,//已经出现
    TTACSAdWillDisappear,//即将消失
    TTACSAdDidDisappear,//已经消失
    TTACSAdMuted,//静音广告
    TTACSAdWillLeaveApplication,//将要离开App

    TTACSAdVideoStart,//开始播放 常用于video
    TTACSAdVideoComplete,//播放完成 常用于video
    TTACSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TTACSAdVideoServerFail,//连接服务器成功，常用于fb video

    TTACSAdNativeDidDownload,//下载完成 常用于fb Native
    TTACSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TTACSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    TTACSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    TTACSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    TTACSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    TTACSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    TTACSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    TTACSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    TTACSAdBUOpenDidAutoDimiss,//开屏自动消失
    TTACSAdBUOpenRenderSuccess, //渲染成功
    TTACSAdBUOpenRenderFail, //渲染失败
    TTACSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    TTACSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    TTACSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    TTACSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    TTACSAdDidPresentFullScreen,//插屏弹出全屏广告
    TTACSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    TTACSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    TTACSAdPlayerStatusStarted,//开始播放
    TTACSAdPlayerStatusPaused,//用户行为导致暂停
    TTACSAdPlayerStatusStoped,//播放停止
    TTACSAdPlayerStatusError,//播放出错
    TTACSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    TTACSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    TTACSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    TTACSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    TTACSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    TTACSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    TTACSAdRecordImpression, //广告曝光已记录
    TTACSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    TTACSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    TTACSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    TTACSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    TTACSAdABUOpenWillPresentFullScreen,
    TTACSAdABUOpenDidShowFailed,
    TTACSAdABUOpenWillDissmissFullScreen,
    TTACSAdABUOpenCountdownToZero,
    
    TTACSAdABUBannerWillPresentFullScreen,
    TTACSAdABUBannerWillDismissFullScreen,
    
    TTACSAdABURewardDidLoad,
    TTACSAdABURewardRenderFail,
    TTACSAdABURewardDidShowFailed,

} TTACSAdEvent;

typedef void (^TTACSAdLoadCompleteBlock)(TTACSAdLoadStatus adLoadStatus);

@class TTACSAdSetupParamsMaker;
@class TTACSAdSetupParams;

typedef TTACSAdSetupParamsMaker *(^TTACSAdStringInit)(NSString *);
typedef TTACSAdSetupParamsMaker *(^TTACSAdBoolInit)(BOOL);
typedef TTACSAdSetupParamsMaker *(^TTACSAdIntegerInit)(NSInteger);
typedef TTACSAdSetupParamsMaker *(^TTACSAdLongInit)(long);
typedef TTACSAdSetupParamsMaker *(^TTACSAdArrayInit)(NSArray *);
typedef TTACSAdSetupParams *(^TTACSAdMakeInit)(void);


@class TTACSAdDataModel;
typedef void (^TTACSAdRequestCompleteBlock)(NSMutableArray<TTACSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TTACSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TTACSAdPreloadCompleteBlock)(TTACSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
