//
//  TTACSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "TTACSAdLoadBase.h"
#import "TTACSAdDataModel.h"
#import "TTACSAdLoadProtocol.h"
#import "TTACSAdLoadDataProtocol.h"
#import "TTACSAdLoadShowProtocol.h"
#import "TTACSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)tTAsetupByBlock:(void (^ _Nonnull)(TTACSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)tTAloadAd:(NSString *)moduleId delegate:(id<TTACSAdLoadDataProtocol>)delegate;

+ (void)tTAloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<TTACSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)tTAadShowStatistic:(TTACSAdDataModel *)dataModel adload:(nonnull TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)tTAadClickStatistic:(TTACSAdDataModel *)dataModel adload:(nonnull TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)tTAaddCustomFecher:(Class<TTACSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
