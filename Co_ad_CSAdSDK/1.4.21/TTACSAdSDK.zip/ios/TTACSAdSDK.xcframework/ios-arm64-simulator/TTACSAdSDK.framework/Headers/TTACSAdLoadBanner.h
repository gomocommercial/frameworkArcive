//
//  TTACSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "TTACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdLoadBanner : TTACSAdLoadBase

//开始刷新(若广告源支持)
- (void)stopRefresh;

//停止刷新(若广告源支持)
- (void)startRefresh;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
