//
//  TTACSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TTACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdLoadInterstitial : TTACSAdLoadBase


@end

NS_ASSUME_NONNULL_END
