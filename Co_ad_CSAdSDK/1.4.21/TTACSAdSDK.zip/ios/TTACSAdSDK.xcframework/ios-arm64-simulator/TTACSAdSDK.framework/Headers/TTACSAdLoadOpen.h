//
//  TTACSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "TTACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdLoadOpen : TTACSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
