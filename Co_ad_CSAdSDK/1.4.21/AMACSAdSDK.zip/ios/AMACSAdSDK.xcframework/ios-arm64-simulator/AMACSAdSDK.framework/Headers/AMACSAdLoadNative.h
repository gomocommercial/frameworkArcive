//
//  AMACSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "AMACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AMACSAdLoadNative : AMACSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
