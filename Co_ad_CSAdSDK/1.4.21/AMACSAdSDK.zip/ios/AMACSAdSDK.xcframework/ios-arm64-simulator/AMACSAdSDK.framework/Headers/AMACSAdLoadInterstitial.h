//
//  AMACSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "AMACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AMACSAdLoadInterstitial : AMACSAdLoadBase


@end

NS_ASSUME_NONNULL_END
