//
//  MBCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MBCSAdLoadInterstitial : MBCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
