//
//  PSCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PSCSAdLoadBase.h"
#import "PSCSAdDataModel.h"
#import "PSCSAdLoadProtocol.h"
#import "PSCSAdLoadDataProtocol.h"
#import "PSCSAdLoadShowProtocol.h"
#import "PSCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pSsetupByBlock:(void (^ _Nonnull)(PSCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pSloadAd:(NSString *)moduleId delegate:(id<PSCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pSadShowStatistic:(PSCSAdDataModel *)dataModel adload:(nonnull PSCSAdLoadBase<PSCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pSadClickStatistic:(PSCSAdDataModel *)dataModel adload:(nonnull PSCSAdLoadBase<PSCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pSaddCustomFecher:(Class<PSCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
