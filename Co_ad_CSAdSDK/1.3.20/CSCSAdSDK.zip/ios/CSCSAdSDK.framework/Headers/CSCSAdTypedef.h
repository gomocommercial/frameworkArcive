//
//  CSCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CSCSAdLoadSuccess = 1,
    CSCSAdLoadFailure = -1,
    CSCSAdLoadTimeout = -2
} CSCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CSCSAdPreloadSuccess = 1,
    //预加载失败
    CSCSAdPreloadFailure = -1,
    //重复加载
    CSCSAdPreloadRepeat = -2,
} CSCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CSCSAdWillAppear,//即将出现
    CSCSAdDidAppear,//已经出现
    CSCSAdWillDisappear,//即将消失
    CSCSAdDidDisappear,//已经消失
    CSCSAdMuted,//静音广告
    CSCSAdWillLeaveApplication,//将要离开App

    CSCSAdVideoStart,//开始播放 常用于video
    CSCSAdVideoComplete,//播放完成 常用于video
    CSCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CSCSAdVideoServerFail,//连接服务器成功，常用于fb video

    CSCSAdNativeDidDownload,//下载完成 常用于fb Native
    CSCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CSCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CSCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CSCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CSCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CSCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    CSCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CSCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CSCSAdBUOpenDidAutoDimiss,//开屏自动消失
    CSCSAdBUOpenRenderSuccess, //渲染成功
    CSCSAdBUOpenRenderFail, //渲染失败
    CSCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    CSCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CSCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CSCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CSCSAdDidPresentFullScreen,//插屏弹出全屏广告
    CSCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CSCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CSCSAdPlayerStatusStarted,//开始播放
    CSCSAdPlayerStatusPaused,//用户行为导致暂停
    CSCSAdPlayerStatusStoped,//播放停止
    CSCSAdPlayerStatusError,//播放出错
    CSCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CSCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CSCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CSCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CSCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CSCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CSCSAdRecordImpression, //广告曝光已记录
    CSCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CSCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CSCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    CSCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    CSCSAdABUOpenWillPresentFullScreen,
    CSCSAdABUOpenDidShowFailed,
    CSCSAdABUOpenWillDissmissFullScreen,
    CSCSAdABUOpenCountdownToZero,
    
    CSCSAdABUBannerWillPresentFullScreen,
    CSCSAdABUBannerWillDismissFullScreen,
    
    CSCSAdABURewardDidLoad,
    CSCSAdABURewardRenderFail,
    CSCSAdABURewardDidShowFailed,

} CSCSAdEvent;

typedef void (^CSCSAdLoadCompleteBlock)(CSCSAdLoadStatus adLoadStatus);

@class CSCSAdSetupParamsMaker;
@class CSCSAdSetupParams;

typedef CSCSAdSetupParamsMaker *(^CSCSAdStringInit)(NSString *);
typedef CSCSAdSetupParamsMaker *(^CSCSAdBoolInit)(BOOL);
typedef CSCSAdSetupParamsMaker *(^CSCSAdIntegerInit)(NSInteger);
typedef CSCSAdSetupParamsMaker *(^CSCSAdLongInit)(long);
typedef CSCSAdSetupParamsMaker *(^CSCSAdArrayInit)(NSArray *);
typedef CSCSAdSetupParams *(^CSCSAdMakeInit)(void);


@class CSCSAdDataModel;
typedef void (^CSCSAdRequestCompleteBlock)(NSMutableArray<CSCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CSCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CSCSAdPreloadCompleteBlock)(CSCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
