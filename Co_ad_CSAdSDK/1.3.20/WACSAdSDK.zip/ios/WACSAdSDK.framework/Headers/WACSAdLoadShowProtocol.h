//
//  WACSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "WACSAdTypedef.h"

@class WACSAdLoadBase;

@protocol WACSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol WACSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)wAonAdShowed:(WACSAdLoadBase<WACSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)wAonAdClicked:(WACSAdLoadBase<WACSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)wAonAdClosed:(WACSAdLoadBase<WACSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)wAonAdVideoCompletePlaying:(WACSAdLoadBase<WACSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)wAonAdShowFail:(WACSAdLoadBase<WACSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)wAonAdOtherEvent:(WACSAdLoadBase<WACSAdLoadProtocol> *)adload event:(WACSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
