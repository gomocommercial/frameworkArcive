//
//  DCiosCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "DCiosCSAdLoadBase.h"
#import "DCiosCSAdDataModel.h"
#import "DCiosCSAdLoadProtocol.h"
#import "DCiosCSAdLoadDataProtocol.h"
#import "DCiosCSAdLoadShowProtocol.h"
#import "DCiosCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCiosCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)dCiossetupByBlock:(void (^ _Nonnull)(DCiosCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)dCiosloadAd:(NSString *)moduleId delegate:(id<DCiosCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)dCiosadShowStatistic:(DCiosCSAdDataModel *)dataModel adload:(nonnull DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)dCiosadClickStatistic:(DCiosCSAdDataModel *)dataModel adload:(nonnull DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)dCiosaddCustomFecher:(Class<DCiosCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
