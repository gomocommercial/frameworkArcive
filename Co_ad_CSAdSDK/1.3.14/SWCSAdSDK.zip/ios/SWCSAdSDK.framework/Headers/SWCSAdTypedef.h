//
//  SWCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    SWCSAdLoadSuccess = 1,
    SWCSAdLoadFailure = -1,
    SWCSAdLoadTimeout = -2
} SWCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    SWCSAdPreloadSuccess = 1,
    //预加载失败
    SWCSAdPreloadFailure = -1,
    //重复加载
    SWCSAdPreloadRepeat = -2,
} SWCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    SWCSAdWillAppear,//即将出现
    SWCSAdDidAppear,//已经出现
    SWCSAdWillDisappear,//即将消失
    SWCSAdDidDisappear,//已经消失
    SWCSAdMuted,//静音广告
    SWCSAdWillLeaveApplication,//将要离开App

    SWCSAdVideoStart,//开始播放 常用于video
    SWCSAdVideoComplete,//播放完成 常用于video
    SWCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    SWCSAdVideoServerFail,//连接服务器成功，常用于fb video

    SWCSAdNativeDidDownload,//下载完成 常用于fb Native
    SWCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    SWCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    SWCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    SWCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    SWCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    SWCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    SWCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    SWCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    SWCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    SWCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    SWCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    SWCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    SWCSAdDidPresentFullScreen,//插屏弹出全屏广告
    SWCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    SWCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    SWCSAdPlayerStatusStarted,//开始播放
    SWCSAdPlayerStatusPaused,//用户行为导致暂停
    SWCSAdPlayerStatusStoped,//播放停止
    SWCSAdPlayerStatusError,//播放出错
    SWCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    SWCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    SWCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    SWCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    SWCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    SWCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    SWCSAdRecordImpression, //广告曝光已记录
    SWCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    SWCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    SWCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    SWCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    SWCSAdABUOpenWillPresentFullScreen,
    SWCSAdABUOpenDidShowFailed,
    SWCSAdABUOpenWillDissmissFullScreen,
    SWCSAdABUOpenCountdownToZero,
    
    SWCSAdABUBannerWillPresentFullScreen,
    SWCSAdABUBannerWillDismissFullScreen,
    
    SWCSAdABURewardDidLoad,
    SWCSAdABURewardRenderFail,
    SWCSAdABURewardDidShowFailed,

} SWCSAdEvent;

typedef void (^SWCSAdLoadCompleteBlock)(SWCSAdLoadStatus adLoadStatus);

@class SWCSAdSetupParamsMaker;
@class SWCSAdSetupParams;

typedef SWCSAdSetupParamsMaker *(^SWCSAdStringInit)(NSString *);
typedef SWCSAdSetupParamsMaker *(^SWCSAdBoolInit)(BOOL);
typedef SWCSAdSetupParamsMaker *(^SWCSAdIntegerInit)(NSInteger);
typedef SWCSAdSetupParamsMaker *(^SWCSAdLongInit)(long);
typedef SWCSAdSetupParamsMaker *(^SWCSAdArrayInit)(NSArray *);
typedef SWCSAdSetupParams *(^SWCSAdMakeInit)(void);


@class SWCSAdDataModel;
typedef void (^SWCSAdRequestCompleteBlock)(NSMutableArray<SWCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^SWCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^SWCSAdPreloadCompleteBlock)(SWCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
