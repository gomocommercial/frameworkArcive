//
//  LDCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LDCSAdTypedef.h"

@class LDCSAdLoadBase;

@protocol LDCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LDCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lDonAdShowed:(LDCSAdLoadBase<LDCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)lDonAdClicked:(LDCSAdLoadBase<LDCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lDonAdClosed:(LDCSAdLoadBase<LDCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lDonAdVideoCompletePlaying:(LDCSAdLoadBase<LDCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)lDonAdShowFail:(LDCSAdLoadBase<LDCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lDonAdOtherEvent:(LDCSAdLoadBase<LDCSAdLoadProtocol> *)adload event:(LDCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
