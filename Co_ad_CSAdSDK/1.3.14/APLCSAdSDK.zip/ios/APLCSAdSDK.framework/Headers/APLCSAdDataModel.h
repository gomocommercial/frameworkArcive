//
//  APLCSAdDataModel.h
//  APLCSAdSDK
//
//  Created by Zy on 2018/7/16.

#import <Foundation/Foundation.h>

@interface APLCSAdDataModel : NSObject
@property(nonatomic, assign) NSInteger moduleId;
@property(nonatomic, assign) NSInteger showrandom;
@property(nonatomic, assign) NSInteger gorandom;
@property(nonatomic, assign) NSInteger acttype;
@property(nonatomic, assign) NSInteger sequence;
@property(nonatomic, assign) NSInteger preloadswitch;
@property(nonatomic, assign) NSInteger preloadswitchtype;
@property(nonatomic, assign) NSInteger adfrequency;
@property(nonatomic, assign) NSInteger adfirst;
@property(nonatomic, assign) NSInteger adsplit;
@property(nonatomic, assign) NSInteger adsplit_inner;
@property(nonatomic, assign) NSInteger adcolsetype;
@property(nonatomic, assign) NSInteger onlineadvpositionid;
@property(nonatomic, assign) NSInteger effect;
@property(nonatomic, assign) NSInteger click_effect;
@property(nonatomic, assign) NSInteger advdatasource;
@property(nonatomic, assign) NSInteger advscene;
@property(nonatomic, assign) NSInteger fbadvcount;
@property(nonatomic, assign) NSInteger advdatasourcetype;
@property(nonatomic, assign) NSInteger isTransfer;
@property(nonatomic, assign) NSInteger fbadvpos;
@property(nonatomic, assign) NSInteger fbnumperline;
@property(nonatomic, assign) NSInteger hasanimation;
@property(nonatomic, assign) NSInteger fbadvabplan;
@property(nonatomic, assign) NSInteger admobbanner;
@property(nonatomic, assign) NSInteger onlineadvtype;
@property(nonatomic, assign) NSInteger isVideo;
@property(nonatomic, assign) NSInteger adcacheFlag;
@property(nonatomic, assign) NSInteger dataType;
@property(nonatomic, assign) NSInteger layout;
@property(nonatomic, assign) NSInteger pages;
@property(nonatomic, assign) NSInteger pageid;
@property(nonatomic, assign) NSInteger statisticstype;
@property(nonatomic, assign) NSInteger clearflag;
@property(nonatomic, assign) NSInteger refreshTimeSplit;
@property(nonatomic, assign) NSInteger diluteRefresh;
@property(nonatomic, assign) NSString *intParam;
@property(nonatomic, copy) NSString *belongsMoudeId;
@property(nonatomic, copy) NSString *advpositionId;
@property(nonatomic, copy) NSString *moduleName;
@property(nonatomic, copy) NSString *moduleDesc;
@property(nonatomic, copy) NSString *moduleSubtitle;
@property(nonatomic, copy) NSString *backImage;
@property(nonatomic, copy) NSString *banner;
@property(nonatomic, copy) NSString *preview;
@property(nonatomic, copy) NSString *icon;
@property(nonatomic, copy) NSString *url;
@property(nonatomic, copy) NSDictionary *advdatasourceextinfo;
@property(nonatomic, copy) NSDictionary *advsceneextinfo;
@property(nonatomic, copy) NSString *fbId;
@property(nonatomic, copy) NSString *fbTabId;
@property(nonatomic, copy) NSString *adidRelation;
@property(nonatomic, copy) NSString *pkgReplace;
@property(nonatomic) long dataVersion;
@property(nonatomic, copy) NSArray *childmodules;
@property(nonatomic, copy) NSArray *contents;

@property(nonatomic, copy) NSDictionary *flgDic;

+ (instancetype)aPLmodelWithJSON:(NSDictionary *)json;

- (NSString *)aPLgetStatistic105Remark;
@end
