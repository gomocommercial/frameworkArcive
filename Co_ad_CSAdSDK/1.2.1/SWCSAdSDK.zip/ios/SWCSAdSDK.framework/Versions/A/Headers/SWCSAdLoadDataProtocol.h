//
//  SWCSAdLoadDataProtocol.h
//  SWCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "SWCSAdTypedef.h"

@class SWCSAdDataModel;
@class SWCSAdLoadBase;

@protocol SWCSAdLoadProtocol;

@protocol SWCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)sWonAdInfoFinish:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)sWonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)sWonAdFail:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
