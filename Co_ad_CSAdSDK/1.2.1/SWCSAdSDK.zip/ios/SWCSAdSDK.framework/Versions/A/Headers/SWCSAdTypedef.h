//
//  SWCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    SWCSAdLoadSuccess = 1,
    SWCSAdLoadFailure = -1,
    SWCSAdLoadTimeout = -2
} SWCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    SWCSAdPreloadSuccess = 1,
    //预加载失败
    SWCSAdPreloadFailure = -1,
    //重复加载
    SWCSAdPreloadRepeat = -2,
} SWCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    SWCSAdWillAppear,//即将出现
    SWCSAdDidAppear,//已经出现
    SWCSAdWillDisappear,//即将消失
    SWCSAdDidDisappear,//已经消失
    SWCSAdMuted,//静音广告
    SWCSAdWillLeaveApplication,//将要离开App

    SWCSAdVideoStart,//开始播放 常用于video
    SWCSAdVideoComplete,//播放完成 常用于video
    SWCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    SWCSAdVideoServerFail,//连接服务器成功，常用于fb video

    SWCSAdNativeDidDownload,//下载完成 常用于fb Native
    SWCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    SWCSAdDidExpire //已到期 常用于mopub interstitial 和 rewardVideo
} SWCSAdEvent;

typedef void (^SWCSAdLoadCompleteBlock)(SWCSAdLoadStatus adLoadStatus);

@class SWCSAdSetupParamsMaker;
@class SWCSAdSetupParams;

typedef SWCSAdSetupParamsMaker *(^SWCSAdStringInit)(NSString *);
typedef SWCSAdSetupParamsMaker *(^SWCSAdBoolInit)(BOOL);
typedef SWCSAdSetupParamsMaker *(^SWCSAdIntegerInit)(NSInteger);
typedef SWCSAdSetupParamsMaker *(^SWCSAdLongInit)(long);
typedef SWCSAdSetupParamsMaker *(^SWCSAdArrayInit)(NSArray *);
typedef SWCSAdSetupParams *(^SWCSAdMakeInit)(void);


@class SWCSAdDataModel;
typedef void (^SWCSAdRequestCompleteBlock)(NSMutableArray<SWCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^SWCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^SWCSAdPreloadCompleteBlock)(SWCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
