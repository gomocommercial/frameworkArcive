//
//  MJCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MJCSAdTypedef.h"

@class MJCSAdLoadBase;

@protocol MJCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MJCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mJonAdShowed:(MJCSAdLoadBase<MJCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)mJonAdClicked:(MJCSAdLoadBase<MJCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mJonAdClosed:(MJCSAdLoadBase<MJCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mJonAdVideoCompletePlaying:(MJCSAdLoadBase<MJCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)mJonAdShowFail:(MJCSAdLoadBase<MJCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mJonAdOtherEvent:(MJCSAdLoadBase<MJCSAdLoadProtocol> *)adload event:(MJCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
