//
//  MJCSAdLoadProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <UIKit/UIKit.h>
#import "MJCSAdTypedef.h"

@protocol MJCSAdLoadShowProtocol;

@protocol MJCSAdLoadProtocol <NSObject>

@required

/**
 广告源
 */
+ (NSInteger)advdatasource;

/**
 广告类型
 */
+ (NSInteger)onlineadvtype;

/**
 广告是否已准备完成
 */
- (BOOL)isValid;

/**
 在目标中展示(video或interstitial 为UIViewController,Native无需参数）自定义广告源可根据需要使用
 * 在applivin 中无需传target
 */
- (void)show:(id)traget delegate:(id<MJCSAdLoadShowProtocol>)delegate;


/**
 广告源类名
 */
- (NSString *)adClassName;

/**
 开始加载广告(SDK内部调用,无需外部使用)
 */
- (void)mJloadData:(MJCSAdLoadCompleteBlock) csAdLoadCompleteBlock;
@end

