//
//  Co_ad_CSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    Co_ad_CSAdLoadSuccess = 1,
    Co_ad_CSAdLoadFailure = -1,
    Co_ad_CSAdLoadTimeout = -2
} Co_ad_CSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    Co_ad_CSAdPreloadSuccess = 1,
    //预加载失败
    Co_ad_CSAdPreloadFailure = -1,
    //重复加载
    Co_ad_CSAdPreloadRepeat = -2,
} Co_ad_CSAdPreloadStatus;


typedef enum : NSUInteger {
    
    Co_ad_CSAdWillAppear,//即将出现
    Co_ad_CSAdDidAppear,//已经出现
    Co_ad_CSAdWillDisappear,//即将消失
    Co_ad_CSAdDidDisappear,//已经消失
    Co_ad_CSAdMuted,//静音广告
    Co_ad_CSAdWillLeaveApplication,//将要离开App

    Co_ad_CSAdVideoStart,//开始播放 常用于video
    Co_ad_CSAdVideoComplete,//播放完成 常用于video
    Co_ad_CSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    Co_ad_CSAdVideoServerFail,//连接服务器成功，常用于fb video

    Co_ad_CSAdNativeDidDownload,//下载完成 常用于fb Native
    Co_ad_CSAdNativeFinishClick,//完成点击 常用与fb Native
    
    Co_ad_CSAdDidExpire //已到期 常用于mopub interstitial 和 rewardVideo
} Co_ad_CSAdEvent;

typedef void (^Co_ad_CSAdLoadCompleteBlock)(Co_ad_CSAdLoadStatus adLoadStatus);

@class Co_ad_CSAdSetupParamsMaker;
@class Co_ad_CSAdSetupParams;

typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdStringInit)(NSString *);
typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdBoolInit)(BOOL);
typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdIntegerInit)(NSInteger);
typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdLongInit)(long);
typedef Co_ad_CSAdSetupParamsMaker *(^Co_ad_CSAdArrayInit)(NSArray *);
typedef Co_ad_CSAdSetupParams *(^Co_ad_CSAdMakeInit)(void);


@class Co_ad_CSAdDataModel;
typedef void (^Co_ad_CSAdRequestCompleteBlock)(NSMutableArray<Co_ad_CSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^Co_ad_CSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^Co_ad_CSAdPreloadCompleteBlock)(Co_ad_CSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
