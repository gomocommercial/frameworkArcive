//
//  AJCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define aJkAdvDataSourceFacebook   2 //FB 广告数据源
#define aJkAdvDataSourceAdmob      8 //Admob 广告数据源
#define aJkAdvDataSourceMopub      39//Mopub 广告数据源
#define aJkAdvDataSourceApplovin   20//applovin 广告数据源

#define aJkAdvDataSourceGDT        62//广点通 广告数据源
#define aJkAdvDataSourceBaidu      63//百度 广告数据源
#define aJkAdvDataSourceBU         64//头条 广告数据源


#define aJkOnlineAdvTypeBanner                   1  //banner
#define aJkOnlineAdvTypeInterstitial             2  //全屏
#define aJkOnlineAdvTypeNative                   3 //native
#define aJkOnlineAdvTypeVideo                    4 //视频
#define aJkOnlineAdvTypeMinBanner                5 //banner(300*250)
#define aJkOnlineAdvTypeInterstitialVideo        7 //插屏视频

#define aJkAdServerConfigError  -1 //服务器返回数据不正确
#define aJkAdLoadConfigFailed  -2 //广告加载失败


#define aJAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define aJkCSAdInstallDays @"aJkCSAdInstallDays"
#define aJkCSAdModule_key @"aJkCSAdModule_key_%@"
#define aJkCSAdInstallTime @"aJkCSAdInstallTime"
#define aJkCSAdLastGetServerTime @"aJkCSAdLastRequestTime"
#define aJkCSAdloadTime 30

#define aJkCSLoadAdTimeOutNotification @"aJKCSLoadAdTimeOutNotification"
#define aJkCSLoadAdTimeOutNotificationKey @"aJKCSLoadAdTimeOutKey"

