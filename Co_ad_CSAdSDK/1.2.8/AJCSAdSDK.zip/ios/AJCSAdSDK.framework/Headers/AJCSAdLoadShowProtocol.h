//
//  AJCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "AJCSAdTypedef.h"

@class AJCSAdLoadBase;

@protocol AJCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol AJCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)aJonAdShowed:(AJCSAdLoadBase<AJCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)aJonAdClicked:(AJCSAdLoadBase<AJCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)aJonAdClosed:(AJCSAdLoadBase<AJCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)aJonAdVideoCompletePlaying:(AJCSAdLoadBase<AJCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)aJonAdShowFail:(AJCSAdLoadBase<AJCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)aJonAdOtherEvent:(AJCSAdLoadBase<AJCSAdLoadProtocol> *)adload event:(AJCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
