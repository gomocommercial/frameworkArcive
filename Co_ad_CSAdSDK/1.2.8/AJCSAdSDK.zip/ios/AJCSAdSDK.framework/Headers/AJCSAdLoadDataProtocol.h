//
//  AJCSAdLoadDataProtocol.h
//  AJCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "AJCSAdTypedef.h"

@class AJCSAdDataModel;
@class AJCSAdLoadBase;

@protocol AJCSAdLoadProtocol;

@protocol AJCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)aJonAdInfoFinish:(AJCSAdLoadBase<AJCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)aJonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)aJonAdFail:(AJCSAdLoadBase<AJCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
