//
//  AJCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    AJCSAdLoadSuccess = 1,
    AJCSAdLoadFailure = -1,
    AJCSAdLoadTimeout = -2
} AJCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    AJCSAdPreloadSuccess = 1,
    //预加载失败
    AJCSAdPreloadFailure = -1,
    //重复加载
    AJCSAdPreloadRepeat = -2,
} AJCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    AJCSAdWillAppear,//即将出现
    AJCSAdDidAppear,//已经出现
    AJCSAdWillDisappear,//即将消失
    AJCSAdDidDisappear,//已经消失
    AJCSAdMuted,//静音广告
    AJCSAdWillLeaveApplication,//将要离开App

    AJCSAdVideoStart,//开始播放 常用于video
    AJCSAdVideoComplete,//播放完成 常用于video
    AJCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    AJCSAdVideoServerFail,//连接服务器成功，常用于fb video

    AJCSAdNativeDidDownload,//下载完成 常用于fb Native
    AJCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    AJCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    AJCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    AJCSAdVideoSkip,//跳过播放
    
    //广点通 插屏专用
    AJCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    AJCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    AJCSAdDidPresentFullScreen,//插屏弹出全屏广告
    AJCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    AJCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    AJCSAdPlayerStatusStarted,//开始播放
    AJCSAdPlayerStatusPaused,//用户行为导致暂停
    AJCSAdPlayerStatusStoped,//播放停止
    AJCSAdPlayerStatusError,//播放出错
    AJCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    AJCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    AJCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    AJCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    AJCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    AJCSAdVideoDidLoad//激励视频数据下载成功
} AJCSAdEvent;

typedef void (^AJCSAdLoadCompleteBlock)(AJCSAdLoadStatus adLoadStatus);

@class AJCSAdSetupParamsMaker;
@class AJCSAdSetupParams;

typedef AJCSAdSetupParamsMaker *(^AJCSAdStringInit)(NSString *);
typedef AJCSAdSetupParamsMaker *(^AJCSAdBoolInit)(BOOL);
typedef AJCSAdSetupParamsMaker *(^AJCSAdIntegerInit)(NSInteger);
typedef AJCSAdSetupParamsMaker *(^AJCSAdLongInit)(long);
typedef AJCSAdSetupParamsMaker *(^AJCSAdArrayInit)(NSArray *);
typedef AJCSAdSetupParams *(^AJCSAdMakeInit)(void);


@class AJCSAdDataModel;
typedef void (^AJCSAdRequestCompleteBlock)(NSMutableArray<AJCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^AJCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^AJCSAdPreloadCompleteBlock)(AJCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
