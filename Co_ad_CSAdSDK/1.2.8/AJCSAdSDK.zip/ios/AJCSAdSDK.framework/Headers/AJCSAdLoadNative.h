//
//  AJCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "AJCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AJCSAdLoadNative : AJCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
