//
//  CPCSAdLoadDataProtocol.h
//  CPCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "CPCSAdTypedef.h"

@class CPCSAdDataModel;
@class CPCSAdLoadBase;

@protocol CPCSAdLoadProtocol;

@protocol CPCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)cPonAdInfoFinish:(CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)cPonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)cPonAdFail:(CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
