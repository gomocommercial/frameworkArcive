//
//  CPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define cPkAdvDataSourceFacebook   2 //FB 广告数据源
#define cPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define cPkAdvDataSourceMopub      39//Mopub 广告数据源
#define cPkAdvDataSourceApplovin   20//applovin 广告数据源

#define cPkAdvDataSourceGDT        62//广点通 广告数据源
#define cPkAdvDataSourceBaidu      63//百度 广告数据源
#define cPkAdvDataSourceBU         64//头条 广告数据源


#define cPkOnlineAdvTypeBanner                   1  //banner
#define cPkOnlineAdvTypeInterstitial             2  //全屏
#define cPkOnlineAdvTypeNative                   3 //native
#define cPkOnlineAdvTypeVideo                    4 //视频
#define cPkOnlineAdvTypeMinBanner                5 //banner(300*250)
#define cPkOnlineAdvTypeInterstitialVideo        7 //插屏视频

#define cPkAdServerConfigError  -1 //服务器返回数据不正确
#define cPkAdLoadConfigFailed  -2 //广告加载失败


#define cPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define cPkCSAdInstallDays @"cPkCSAdInstallDays"
#define cPkCSAdModule_key @"cPkCSAdModule_key_%@"
#define cPkCSAdInstallTime @"cPkCSAdInstallTime"
#define cPkCSAdLastGetServerTime @"cPkCSAdLastRequestTime"
#define cPkCSAdloadTime 30

#define cPkCSLoadAdTimeOutNotification @"cPKCSLoadAdTimeOutNotification"
#define cPkCSLoadAdTimeOutNotificationKey @"cPKCSLoadAdTimeOutKey"

