//
//  SVCSAdLoadDataProtocol.h
//  SVCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "SVCSAdTypedef.h"

@class SVCSAdDataModel;
@class SVCSAdLoadBase;

@protocol SVCSAdLoadProtocol;

@protocol SVCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)sVonAdInfoFinish:(SVCSAdLoadBase<SVCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)sVonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)sVonAdFail:(SVCSAdLoadBase<SVCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
