//
//  PTCSAdLoadDataProtocol.h
//  PTCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PTCSAdTypedef.h"

@class PTCSAdDataModel;
@class PTCSAdLoadBase;

@protocol PTCSAdLoadProtocol;

@protocol PTCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)pTonAdInfoFinish:(PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)pTonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)pTonAdFail:(PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
