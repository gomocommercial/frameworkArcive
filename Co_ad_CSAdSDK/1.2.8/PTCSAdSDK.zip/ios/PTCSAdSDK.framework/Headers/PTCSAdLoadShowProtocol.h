//
//  PTCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PTCSAdTypedef.h"

@class PTCSAdLoadBase;

@protocol PTCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PTCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pTonAdShowed:(PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)pTonAdClicked:(PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pTonAdClosed:(PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pTonAdVideoCompletePlaying:(PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)pTonAdShowFail:(PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pTonAdOtherEvent:(PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload event:(PTCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
