//
//  LOCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lOkAdvDataSourceFacebook   2 //FB 广告数据源
#define lOkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lOkAdvDataSourceMopub      39//Mopub 广告数据源
#define lOkAdvDataSourceApplovin   20//applovin 广告数据源

#define lOkAdvDataSourceGDT        62//广点通 广告数据源
#define lOkAdvDataSourceBaidu      63//百度 广告数据源
#define lOkAdvDataSourceBU         64//头条 广告数据源
#define lOkAdvDataSourceABU         70//头条聚合 广告数据源
#define lOkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define lOkAdvDataSourcePangle     74//pangle 广告数据源
#define lOkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define lOkOnlineAdvTypeBanner                   1  //banner
#define lOkOnlineAdvTypeInterstitial             2  //全屏
#define lOkOnlineAdvTypeNative                   3 //native
#define lOkOnlineAdvTypeVideo                    4 //视频
#define lOkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define lOkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define lOkOnlineAdvTypeOpen                     8 //开屏
#define lOkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define lOkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define lOkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define lOkAdServerConfigError  -1 //服务器返回数据不正确
#define lOkAdLoadConfigFailed  -2 //广告加载失败


#define lOAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lOkCSAdInstallDays @"lOkCSAdInstallDays"
#define lOkCSAdModule_key @"lOkCSAdModule_key_%@"
#define lOkCSNewAdModule_key @"lOkCSNewAdModule_key_%@"
#define lOkCSAdInstallTime @"lOkCSAdInstallTime"
#define lOkCSAdInstallHours @"lOkCSAdInstallHours"
#define lOkCSAdLastGetServerTime @"lOkCSAdLastRequestTime"
#define lOkCSAdloadTime 30

#define lOkCSLoadAdTimeOutNotification @"lOKCSLoadAdTimeOutNotification"
#define lOkCSLoadAdTimeOutNotificationKey @"lOKCSLoadAdTimeOutKey"

