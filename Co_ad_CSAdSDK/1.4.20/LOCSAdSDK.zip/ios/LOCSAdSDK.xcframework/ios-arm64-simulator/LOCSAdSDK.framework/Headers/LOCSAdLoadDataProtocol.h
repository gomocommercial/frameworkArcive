//
//  LOCSAdLoadDataProtocol.h
//  LOCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "LOCSAdTypedef.h"

@class LOCSAdDataModel;
@class LOCSAdLoadBase;

@protocol LOCSAdLoadProtocol;

@protocol LOCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)lOonAdInfoFinish:(LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)lOonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)lOonAdFail:(LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
