//
//  QLCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "QLCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadOpen : QLCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
