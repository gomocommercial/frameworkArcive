//
//  QLCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "QLCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadReward : QLCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
