//
//  QLCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "QLCSAdLoadBase.h"
#import "QLCSAdDataModel.h"
#import "QLCSAdLoadProtocol.h"
#import "QLCSAdLoadDataProtocol.h"
#import "QLCSAdLoadShowProtocol.h"
#import "QLCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)qLsetupByBlock:(void (^ _Nonnull)(QLCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)qLloadAd:(NSString *)moduleId delegate:(id<QLCSAdLoadDataProtocol>)delegate;

+ (void)qLloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<QLCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)qLadShowStatistic:(QLCSAdDataModel *)dataModel adload:(nonnull QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)qLadClickStatistic:(QLCSAdDataModel *)dataModel adload:(nonnull QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)qLaddCustomFecher:(Class<QLCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
