//
//  QLCSAdNetworkTool.h
//  QLCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "QLCSAdDataModel.h"
#import "QLCSAdTypedef.h"
#import "QLCSNewStoreLiteRequestTool.h"
#import "NSString+QLCSGenerateHash.h"

@interface QLCSAdNetworkTool : NSObject

+ (QLCSAdNetworkTool *)shared;
@property(nonatomic, copy) QLCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)qLrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(QLCSAdRequestCompleteBlock)complete;

- (void)qLsetCDay:(void(^ _Nullable)(bool success))handle;
@end
