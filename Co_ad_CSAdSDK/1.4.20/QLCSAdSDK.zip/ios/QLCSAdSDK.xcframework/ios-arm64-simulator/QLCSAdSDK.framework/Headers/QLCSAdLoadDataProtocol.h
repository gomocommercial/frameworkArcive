//
//  QLCSAdLoadDataProtocol.h
//  QLCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "QLCSAdTypedef.h"

@class QLCSAdDataModel;
@class QLCSAdLoadBase;

@protocol QLCSAdLoadProtocol;

@protocol QLCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)qLonAdInfoFinish:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)qLonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)qLonAdFail:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
