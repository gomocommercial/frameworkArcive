//
//  QLCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    QLCSAdLoadSuccess = 1,
    QLCSAdLoadFailure = -1,
    QLCSAdLoadTimeout = -2
} QLCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    QLCSAdPreloadSuccess = 1,
    //预加载失败
    QLCSAdPreloadFailure = -1,
    //重复加载
    QLCSAdPreloadRepeat = -2,
} QLCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    QLCSAdWillAppear,//即将出现
    QLCSAdDidAppear,//已经出现
    QLCSAdWillDisappear,//即将消失
    QLCSAdDidDisappear,//已经消失
    QLCSAdMuted,//静音广告
    QLCSAdWillLeaveApplication,//将要离开App

    QLCSAdVideoStart,//开始播放 常用于video
    QLCSAdVideoComplete,//播放完成 常用于video
    QLCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    QLCSAdVideoServerFail,//连接服务器成功，常用于fb video

    QLCSAdNativeDidDownload,//下载完成 常用于fb Native
    QLCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    QLCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    QLCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    QLCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    QLCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    QLCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    QLCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    QLCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    QLCSAdBUOpenDidAutoDimiss,//开屏自动消失
    QLCSAdBUOpenRenderSuccess, //渲染成功
    QLCSAdBUOpenRenderFail, //渲染失败
    QLCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    QLCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    QLCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    QLCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    QLCSAdDidPresentFullScreen,//插屏弹出全屏广告
    QLCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    QLCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    QLCSAdPlayerStatusStarted,//开始播放
    QLCSAdPlayerStatusPaused,//用户行为导致暂停
    QLCSAdPlayerStatusStoped,//播放停止
    QLCSAdPlayerStatusError,//播放出错
    QLCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    QLCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    QLCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    QLCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    QLCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    QLCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    QLCSAdRecordImpression, //广告曝光已记录
    QLCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    QLCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    QLCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    QLCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    QLCSAdABUOpenWillPresentFullScreen,
    QLCSAdABUOpenDidShowFailed,
    QLCSAdABUOpenWillDissmissFullScreen,
    QLCSAdABUOpenCountdownToZero,
    
    QLCSAdABUBannerWillPresentFullScreen,
    QLCSAdABUBannerWillDismissFullScreen,
    
    QLCSAdABURewardDidLoad,
    QLCSAdABURewardRenderFail,
    QLCSAdABURewardDidShowFailed,

} QLCSAdEvent;

typedef void (^QLCSAdLoadCompleteBlock)(QLCSAdLoadStatus adLoadStatus);

@class QLCSAdSetupParamsMaker;
@class QLCSAdSetupParams;

typedef QLCSAdSetupParamsMaker *(^QLCSAdStringInit)(NSString *);
typedef QLCSAdSetupParamsMaker *(^QLCSAdBoolInit)(BOOL);
typedef QLCSAdSetupParamsMaker *(^QLCSAdIntegerInit)(NSInteger);
typedef QLCSAdSetupParamsMaker *(^QLCSAdLongInit)(long);
typedef QLCSAdSetupParamsMaker *(^QLCSAdArrayInit)(NSArray *);
typedef QLCSAdSetupParams *(^QLCSAdMakeInit)(void);


@class QLCSAdDataModel;
typedef void (^QLCSAdRequestCompleteBlock)(NSMutableArray<QLCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^QLCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^QLCSAdPreloadCompleteBlock)(QLCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
