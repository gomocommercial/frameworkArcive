//
//  QLCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define qLkAdvDataSourceFacebook   2 //FB 广告数据源
#define qLkAdvDataSourceAdmob      8 //Admob 广告数据源
#define qLkAdvDataSourceMopub      39//Mopub 广告数据源
#define qLkAdvDataSourceApplovin   20//applovin 广告数据源

#define qLkAdvDataSourceGDT        62//广点通 广告数据源
#define qLkAdvDataSourceBaidu      63//百度 广告数据源
#define qLkAdvDataSourceBU         64//头条 广告数据源
#define qLkAdvDataSourceABU         70//头条聚合 广告数据源
#define qLkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define qLkAdvDataSourcePangle     74//pangle 广告数据源
#define qLkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define qLkOnlineAdvTypeBanner                   1  //banner
#define qLkOnlineAdvTypeInterstitial             2  //全屏
#define qLkOnlineAdvTypeNative                   3 //native
#define qLkOnlineAdvTypeVideo                    4 //视频
#define qLkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define qLkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define qLkOnlineAdvTypeOpen                     8 //开屏
#define qLkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define qLkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define qLkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define qLkAdServerConfigError  -1 //服务器返回数据不正确
#define qLkAdLoadConfigFailed  -2 //广告加载失败


#define qLAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define qLkCSAdInstallDays @"qLkCSAdInstallDays"
#define qLkCSAdModule_key @"qLkCSAdModule_key_%@"
#define qLkCSNewAdModule_key @"qLkCSNewAdModule_key_%@"
#define qLkCSAdInstallTime @"qLkCSAdInstallTime"
#define qLkCSAdInstallHours @"qLkCSAdInstallHours"
#define qLkCSAdLastGetServerTime @"qLkCSAdLastRequestTime"
#define qLkCSAdloadTime 30

#define qLkCSLoadAdTimeOutNotification @"qLKCSLoadAdTimeOutNotification"
#define qLkCSLoadAdTimeOutNotificationKey @"qLKCSLoadAdTimeOutKey"

