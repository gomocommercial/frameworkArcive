//
//  QLCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "QLCSAdTypedef.h"

@class QLCSAdLoadBase;

@protocol QLCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol QLCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)qLonAdShowed:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)qLonAdClicked:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)qLonAdClosed:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)qLonAdVideoCompletePlaying:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)qLonAdVideoGotReward:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload;
-(void)qLonAdDidPayRevenue:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)qLonAdDidGetEcpm:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)qLonAdShowFail:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)qLonAdOtherEvent:(QLCSAdLoadBase<QLCSAdLoadProtocol> *)adload event:(QLCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
