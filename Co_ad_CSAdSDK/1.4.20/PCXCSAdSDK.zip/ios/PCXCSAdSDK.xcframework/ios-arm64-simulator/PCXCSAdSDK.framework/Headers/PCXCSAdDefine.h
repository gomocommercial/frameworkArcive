//
//  PCXCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pCXkAdvDataSourceFacebook   2 //FB 广告数据源
#define pCXkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pCXkAdvDataSourceMopub      39//Mopub 广告数据源
#define pCXkAdvDataSourceApplovin   20//applovin 广告数据源

#define pCXkAdvDataSourceGDT        62//广点通 广告数据源
#define pCXkAdvDataSourceBaidu      63//百度 广告数据源
#define pCXkAdvDataSourceBU         64//头条 广告数据源
#define pCXkAdvDataSourceABU         70//头条聚合 广告数据源
#define pCXkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pCXkAdvDataSourcePangle     74//pangle 广告数据源
#define pCXkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define pCXkOnlineAdvTypeBanner                   1  //banner
#define pCXkOnlineAdvTypeInterstitial             2  //全屏
#define pCXkOnlineAdvTypeNative                   3 //native
#define pCXkOnlineAdvTypeVideo                    4 //视频
#define pCXkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pCXkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pCXkOnlineAdvTypeOpen                     8 //开屏
#define pCXkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pCXkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pCXkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pCXkAdServerConfigError  -1 //服务器返回数据不正确
#define pCXkAdLoadConfigFailed  -2 //广告加载失败


#define pCXAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pCXkCSAdInstallDays @"pCXkCSAdInstallDays"
#define pCXkCSAdModule_key @"pCXkCSAdModule_key_%@"
#define pCXkCSNewAdModule_key @"pCXkCSNewAdModule_key_%@"
#define pCXkCSAdInstallTime @"pCXkCSAdInstallTime"
#define pCXkCSAdInstallHours @"pCXkCSAdInstallHours"
#define pCXkCSAdLastGetServerTime @"pCXkCSAdLastRequestTime"
#define pCXkCSAdloadTime 30

#define pCXkCSLoadAdTimeOutNotification @"pCXKCSLoadAdTimeOutNotification"
#define pCXkCSLoadAdTimeOutNotificationKey @"pCXKCSLoadAdTimeOutKey"

