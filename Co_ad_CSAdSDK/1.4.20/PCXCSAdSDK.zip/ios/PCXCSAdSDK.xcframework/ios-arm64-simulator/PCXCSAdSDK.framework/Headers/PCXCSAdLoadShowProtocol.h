//
//  PCXCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PCXCSAdTypedef.h"

@class PCXCSAdLoadBase;

@protocol PCXCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PCXCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pCXonAdShowed:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pCXonAdClicked:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pCXonAdClosed:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pCXonAdVideoCompletePlaying:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pCXonAdVideoGotReward:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload;
-(void)pCXonAdDidPayRevenue:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)pCXonAdDidGetEcpm:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)pCXonAdShowFail:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pCXonAdOtherEvent:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload event:(PCXCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
