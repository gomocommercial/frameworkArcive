//
//  PCXCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PCXCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCXCSAdLoadOpen : PCXCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
