//
//  PCXCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PCXCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCXCSAdLoadReward : PCXCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
