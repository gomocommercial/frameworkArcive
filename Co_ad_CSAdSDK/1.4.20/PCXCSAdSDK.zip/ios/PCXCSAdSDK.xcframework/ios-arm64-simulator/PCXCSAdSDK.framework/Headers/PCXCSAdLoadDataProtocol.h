//
//  PCXCSAdLoadDataProtocol.h
//  PCXCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PCXCSAdTypedef.h"

@class PCXCSAdDataModel;
@class PCXCSAdLoadBase;

@protocol PCXCSAdLoadProtocol;

@protocol PCXCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)pCXonAdInfoFinish:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)pCXonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)pCXonAdFail:(PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
