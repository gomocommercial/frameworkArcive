//
//  PCXCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PCXCSAdLoadSuccess = 1,
    PCXCSAdLoadFailure = -1,
    PCXCSAdLoadTimeout = -2
} PCXCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PCXCSAdPreloadSuccess = 1,
    //预加载失败
    PCXCSAdPreloadFailure = -1,
    //重复加载
    PCXCSAdPreloadRepeat = -2,
} PCXCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PCXCSAdWillAppear,//即将出现
    PCXCSAdDidAppear,//已经出现
    PCXCSAdWillDisappear,//即将消失
    PCXCSAdDidDisappear,//已经消失
    PCXCSAdMuted,//静音广告
    PCXCSAdWillLeaveApplication,//将要离开App

    PCXCSAdVideoStart,//开始播放 常用于video
    PCXCSAdVideoComplete,//播放完成 常用于video
    PCXCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PCXCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PCXCSAdNativeDidDownload,//下载完成 常用于fb Native
    PCXCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PCXCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PCXCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PCXCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PCXCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PCXCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PCXCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PCXCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PCXCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PCXCSAdBUOpenRenderSuccess, //渲染成功
    PCXCSAdBUOpenRenderFail, //渲染失败
    PCXCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PCXCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PCXCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PCXCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PCXCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PCXCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PCXCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PCXCSAdPlayerStatusStarted,//开始播放
    PCXCSAdPlayerStatusPaused,//用户行为导致暂停
    PCXCSAdPlayerStatusStoped,//播放停止
    PCXCSAdPlayerStatusError,//播放出错
    PCXCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PCXCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PCXCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PCXCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PCXCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PCXCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PCXCSAdRecordImpression, //广告曝光已记录
    PCXCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PCXCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PCXCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PCXCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PCXCSAdABUOpenWillPresentFullScreen,
    PCXCSAdABUOpenDidShowFailed,
    PCXCSAdABUOpenWillDissmissFullScreen,
    PCXCSAdABUOpenCountdownToZero,
    
    PCXCSAdABUBannerWillPresentFullScreen,
    PCXCSAdABUBannerWillDismissFullScreen,
    
    PCXCSAdABURewardDidLoad,
    PCXCSAdABURewardRenderFail,
    PCXCSAdABURewardDidShowFailed,

} PCXCSAdEvent;

typedef void (^PCXCSAdLoadCompleteBlock)(PCXCSAdLoadStatus adLoadStatus);

@class PCXCSAdSetupParamsMaker;
@class PCXCSAdSetupParams;

typedef PCXCSAdSetupParamsMaker *(^PCXCSAdStringInit)(NSString *);
typedef PCXCSAdSetupParamsMaker *(^PCXCSAdBoolInit)(BOOL);
typedef PCXCSAdSetupParamsMaker *(^PCXCSAdIntegerInit)(NSInteger);
typedef PCXCSAdSetupParamsMaker *(^PCXCSAdLongInit)(long);
typedef PCXCSAdSetupParamsMaker *(^PCXCSAdArrayInit)(NSArray *);
typedef PCXCSAdSetupParams *(^PCXCSAdMakeInit)(void);


@class PCXCSAdDataModel;
typedef void (^PCXCSAdRequestCompleteBlock)(NSMutableArray<PCXCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PCXCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PCXCSAdPreloadCompleteBlock)(PCXCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
