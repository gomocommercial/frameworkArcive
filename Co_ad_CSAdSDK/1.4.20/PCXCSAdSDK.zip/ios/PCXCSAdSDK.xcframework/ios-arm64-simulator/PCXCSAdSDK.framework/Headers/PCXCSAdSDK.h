//
//  PCXCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PCXCSAdLoadBase.h"
#import "PCXCSAdDataModel.h"
#import "PCXCSAdLoadProtocol.h"
#import "PCXCSAdLoadDataProtocol.h"
#import "PCXCSAdLoadShowProtocol.h"
#import "PCXCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCXCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pCXsetupByBlock:(void (^ _Nonnull)(PCXCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pCXloadAd:(NSString *)moduleId delegate:(id<PCXCSAdLoadDataProtocol>)delegate;

+ (void)pCXloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<PCXCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pCXadShowStatistic:(PCXCSAdDataModel *)dataModel adload:(nonnull PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pCXadClickStatistic:(PCXCSAdDataModel *)dataModel adload:(nonnull PCXCSAdLoadBase<PCXCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pCXaddCustomFecher:(Class<PCXCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
