//
//  PCXCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PCXCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCXCSAdLoadNative : PCXCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
