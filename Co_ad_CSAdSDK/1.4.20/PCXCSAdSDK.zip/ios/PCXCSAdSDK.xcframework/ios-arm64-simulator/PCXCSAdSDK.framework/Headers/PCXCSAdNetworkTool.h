//
//  PCXCSAdNetworkTool.h
//  PCXCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PCXCSAdDataModel.h"
#import "PCXCSAdTypedef.h"
#import "PCXCSNewStoreLiteRequestTool.h"
#import "NSString+PCXCSGenerateHash.h"

@interface PCXCSAdNetworkTool : NSObject

+ (PCXCSAdNetworkTool *)shared;
@property(nonatomic, copy) PCXCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pCXrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PCXCSAdRequestCompleteBlock)complete;

- (void)pCXsetCDay:(void(^ _Nullable)(bool success))handle;
@end
