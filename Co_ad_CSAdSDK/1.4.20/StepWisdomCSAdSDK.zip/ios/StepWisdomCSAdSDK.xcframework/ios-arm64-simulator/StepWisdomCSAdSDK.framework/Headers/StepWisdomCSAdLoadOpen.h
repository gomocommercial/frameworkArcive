//
//  StepWisdomCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "StepWisdomCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadOpen : StepWisdomCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
