//
//  StepWisdomCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "StepWisdomCSAdTypedef.h"

@class StepWisdomCSAdLoadBase;

@protocol StepWisdomCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol StepWisdomCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)stepWisdomonAdShowed:(StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)stepWisdomonAdClicked:(StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)stepWisdomonAdClosed:(StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)stepWisdomonAdVideoCompletePlaying:(StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)stepWisdomonAdVideoGotReward:(StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload;
-(void)stepWisdomonAdDidPayRevenue:(StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)stepWisdomonAdDidGetEcpm:(StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)stepWisdomonAdShowFail:(StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)stepWisdomonAdOtherEvent:(StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload event:(StepWisdomCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
