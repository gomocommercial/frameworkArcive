//
//  StepWisdomCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "StepWisdomCSAdLoadBase.h"
#import "StepWisdomCSAdDataModel.h"
#import "StepWisdomCSAdLoadProtocol.h"
#import "StepWisdomCSAdLoadDataProtocol.h"
#import "StepWisdomCSAdLoadShowProtocol.h"
#import "StepWisdomCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)stepWisdomsetupByBlock:(void (^ _Nonnull)(StepWisdomCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)stepWisdomloadAd:(NSString *)moduleId delegate:(id<StepWisdomCSAdLoadDataProtocol>)delegate;

+ (void)stepWisdomloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<StepWisdomCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)stepWisdomadShowStatistic:(StepWisdomCSAdDataModel *)dataModel adload:(nonnull StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)stepWisdomadClickStatistic:(StepWisdomCSAdDataModel *)dataModel adload:(nonnull StepWisdomCSAdLoadBase<StepWisdomCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)stepWisdomaddCustomFecher:(Class<StepWisdomCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
