//
//  StepWisdomCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "StepWisdomCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadInterstitial : StepWisdomCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
