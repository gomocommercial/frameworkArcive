//
//  StepWisdomCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define stepWisdomkAdvDataSourceFacebook   2 //FB 广告数据源
#define stepWisdomkAdvDataSourceAdmob      8 //Admob 广告数据源
#define stepWisdomkAdvDataSourceMopub      39//Mopub 广告数据源
#define stepWisdomkAdvDataSourceApplovin   20//applovin 广告数据源

#define stepWisdomkAdvDataSourceGDT        62//广点通 广告数据源
#define stepWisdomkAdvDataSourceBaidu      63//百度 广告数据源
#define stepWisdomkAdvDataSourceBU         64//头条 广告数据源
#define stepWisdomkAdvDataSourceABU         70//头条聚合 广告数据源
#define stepWisdomkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define stepWisdomkAdvDataSourcePangle     74//pangle 广告数据源
#define stepWisdomkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define stepWisdomkOnlineAdvTypeBanner                   1  //banner
#define stepWisdomkOnlineAdvTypeInterstitial             2  //全屏
#define stepWisdomkOnlineAdvTypeNative                   3 //native
#define stepWisdomkOnlineAdvTypeVideo                    4 //视频
#define stepWisdomkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define stepWisdomkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define stepWisdomkOnlineAdvTypeOpen                     8 //开屏
#define stepWisdomkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define stepWisdomkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define stepWisdomkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define stepWisdomkAdServerConfigError  -1 //服务器返回数据不正确
#define stepWisdomkAdLoadConfigFailed  -2 //广告加载失败


#define stepWisdomAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define stepWisdomkCSAdInstallDays @"stepWisdomkCSAdInstallDays"
#define stepWisdomkCSAdModule_key @"stepWisdomkCSAdModule_key_%@"
#define stepWisdomkCSNewAdModule_key @"stepWisdomkCSNewAdModule_key_%@"
#define stepWisdomkCSAdInstallTime @"stepWisdomkCSAdInstallTime"
#define stepWisdomkCSAdInstallHours @"stepWisdomkCSAdInstallHours"
#define stepWisdomkCSAdLastGetServerTime @"stepWisdomkCSAdLastRequestTime"
#define stepWisdomkCSAdloadTime 30

#define stepWisdomkCSLoadAdTimeOutNotification @"stepWisdomKCSLoadAdTimeOutNotification"
#define stepWisdomkCSLoadAdTimeOutNotificationKey @"stepWisdomKCSLoadAdTimeOutKey"

