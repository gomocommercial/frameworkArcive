//
//  StepWisdomCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    StepWisdomCSAdLoadSuccess = 1,
    StepWisdomCSAdLoadFailure = -1,
    StepWisdomCSAdLoadTimeout = -2
} StepWisdomCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    StepWisdomCSAdPreloadSuccess = 1,
    //预加载失败
    StepWisdomCSAdPreloadFailure = -1,
    //重复加载
    StepWisdomCSAdPreloadRepeat = -2,
} StepWisdomCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    StepWisdomCSAdWillAppear,//即将出现
    StepWisdomCSAdDidAppear,//已经出现
    StepWisdomCSAdWillDisappear,//即将消失
    StepWisdomCSAdDidDisappear,//已经消失
    StepWisdomCSAdMuted,//静音广告
    StepWisdomCSAdWillLeaveApplication,//将要离开App

    StepWisdomCSAdVideoStart,//开始播放 常用于video
    StepWisdomCSAdVideoComplete,//播放完成 常用于video
    StepWisdomCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    StepWisdomCSAdVideoServerFail,//连接服务器成功，常用于fb video

    StepWisdomCSAdNativeDidDownload,//下载完成 常用于fb Native
    StepWisdomCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    StepWisdomCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    StepWisdomCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    StepWisdomCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    StepWisdomCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    StepWisdomCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    StepWisdomCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    StepWisdomCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    StepWisdomCSAdBUOpenDidAutoDimiss,//开屏自动消失
    StepWisdomCSAdBUOpenRenderSuccess, //渲染成功
    StepWisdomCSAdBUOpenRenderFail, //渲染失败
    StepWisdomCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    StepWisdomCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    StepWisdomCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    StepWisdomCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    StepWisdomCSAdDidPresentFullScreen,//插屏弹出全屏广告
    StepWisdomCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    StepWisdomCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    StepWisdomCSAdPlayerStatusStarted,//开始播放
    StepWisdomCSAdPlayerStatusPaused,//用户行为导致暂停
    StepWisdomCSAdPlayerStatusStoped,//播放停止
    StepWisdomCSAdPlayerStatusError,//播放出错
    StepWisdomCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    StepWisdomCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    StepWisdomCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    StepWisdomCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    StepWisdomCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    StepWisdomCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    StepWisdomCSAdRecordImpression, //广告曝光已记录
    StepWisdomCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    StepWisdomCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    StepWisdomCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    StepWisdomCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    StepWisdomCSAdABUOpenWillPresentFullScreen,
    StepWisdomCSAdABUOpenDidShowFailed,
    StepWisdomCSAdABUOpenWillDissmissFullScreen,
    StepWisdomCSAdABUOpenCountdownToZero,
    
    StepWisdomCSAdABUBannerWillPresentFullScreen,
    StepWisdomCSAdABUBannerWillDismissFullScreen,
    
    StepWisdomCSAdABURewardDidLoad,
    StepWisdomCSAdABURewardRenderFail,
    StepWisdomCSAdABURewardDidShowFailed,

} StepWisdomCSAdEvent;

typedef void (^StepWisdomCSAdLoadCompleteBlock)(StepWisdomCSAdLoadStatus adLoadStatus);

@class StepWisdomCSAdSetupParamsMaker;
@class StepWisdomCSAdSetupParams;

typedef StepWisdomCSAdSetupParamsMaker *(^StepWisdomCSAdStringInit)(NSString *);
typedef StepWisdomCSAdSetupParamsMaker *(^StepWisdomCSAdBoolInit)(BOOL);
typedef StepWisdomCSAdSetupParamsMaker *(^StepWisdomCSAdIntegerInit)(NSInteger);
typedef StepWisdomCSAdSetupParamsMaker *(^StepWisdomCSAdLongInit)(long);
typedef StepWisdomCSAdSetupParamsMaker *(^StepWisdomCSAdArrayInit)(NSArray *);
typedef StepWisdomCSAdSetupParams *(^StepWisdomCSAdMakeInit)(void);


@class StepWisdomCSAdDataModel;
typedef void (^StepWisdomCSAdRequestCompleteBlock)(NSMutableArray<StepWisdomCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^StepWisdomCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^StepWisdomCSAdPreloadCompleteBlock)(StepWisdomCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
