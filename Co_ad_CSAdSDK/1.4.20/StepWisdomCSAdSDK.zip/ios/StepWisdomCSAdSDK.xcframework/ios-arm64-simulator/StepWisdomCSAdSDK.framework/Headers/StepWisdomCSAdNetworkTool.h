//
//  StepWisdomCSAdNetworkTool.h
//  StepWisdomCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "StepWisdomCSAdDataModel.h"
#import "StepWisdomCSAdTypedef.h"
#import "StepWisdomCSNewStoreLiteRequestTool.h"
#import "NSString+StepWisdomCSGenerateHash.h"

@interface StepWisdomCSAdNetworkTool : NSObject

+ (StepWisdomCSAdNetworkTool *)shared;
@property(nonatomic, copy) StepWisdomCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)stepWisdomrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(StepWisdomCSAdRequestCompleteBlock)complete;

- (void)stepWisdomsetCDay:(void(^ _Nullable)(bool success))handle;
@end
