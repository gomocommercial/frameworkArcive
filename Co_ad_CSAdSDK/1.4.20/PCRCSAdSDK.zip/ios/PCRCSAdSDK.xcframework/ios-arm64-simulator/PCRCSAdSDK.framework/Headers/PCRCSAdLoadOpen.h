//
//  PCRCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PCRCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCRCSAdLoadOpen : PCRCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
