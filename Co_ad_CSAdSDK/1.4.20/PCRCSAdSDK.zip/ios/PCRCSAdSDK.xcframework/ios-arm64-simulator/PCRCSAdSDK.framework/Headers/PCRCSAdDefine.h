//
//  PCRCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pCRkAdvDataSourceFacebook   2 //FB 广告数据源
#define pCRkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pCRkAdvDataSourceMopub      39//Mopub 广告数据源
#define pCRkAdvDataSourceApplovin   20//applovin 广告数据源

#define pCRkAdvDataSourceGDT        62//广点通 广告数据源
#define pCRkAdvDataSourceBaidu      63//百度 广告数据源
#define pCRkAdvDataSourceBU         64//头条 广告数据源
#define pCRkAdvDataSourceABU         70//头条聚合 广告数据源
#define pCRkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pCRkAdvDataSourcePangle     74//pangle 广告数据源
#define pCRkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define pCRkOnlineAdvTypeBanner                   1  //banner
#define pCRkOnlineAdvTypeInterstitial             2  //全屏
#define pCRkOnlineAdvTypeNative                   3 //native
#define pCRkOnlineAdvTypeVideo                    4 //视频
#define pCRkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pCRkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pCRkOnlineAdvTypeOpen                     8 //开屏
#define pCRkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pCRkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pCRkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pCRkAdServerConfigError  -1 //服务器返回数据不正确
#define pCRkAdLoadConfigFailed  -2 //广告加载失败


#define pCRAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pCRkCSAdInstallDays @"pCRkCSAdInstallDays"
#define pCRkCSAdModule_key @"pCRkCSAdModule_key_%@"
#define pCRkCSNewAdModule_key @"pCRkCSNewAdModule_key_%@"
#define pCRkCSAdInstallTime @"pCRkCSAdInstallTime"
#define pCRkCSAdInstallHours @"pCRkCSAdInstallHours"
#define pCRkCSAdLastGetServerTime @"pCRkCSAdLastRequestTime"
#define pCRkCSAdloadTime 30

#define pCRkCSLoadAdTimeOutNotification @"pCRKCSLoadAdTimeOutNotification"
#define pCRkCSLoadAdTimeOutNotificationKey @"pCRKCSLoadAdTimeOutKey"

