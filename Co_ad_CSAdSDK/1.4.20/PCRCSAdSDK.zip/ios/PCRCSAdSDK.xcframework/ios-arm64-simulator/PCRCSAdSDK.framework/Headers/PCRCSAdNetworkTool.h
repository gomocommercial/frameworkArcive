//
//  PCRCSAdNetworkTool.h
//  PCRCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PCRCSAdDataModel.h"
#import "PCRCSAdTypedef.h"
#import "PCRCSNewStoreLiteRequestTool.h"
#import "NSString+PCRCSGenerateHash.h"

@interface PCRCSAdNetworkTool : NSObject

+ (PCRCSAdNetworkTool *)shared;
@property(nonatomic, copy) PCRCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pCRrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PCRCSAdRequestCompleteBlock)complete;

- (void)pCRsetCDay:(void(^ _Nullable)(bool success))handle;
@end
