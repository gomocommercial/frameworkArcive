//
//  PCRCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PCRCSAdTypedef.h"

@class PCRCSAdLoadBase;

@protocol PCRCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PCRCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pCRonAdShowed:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pCRonAdClicked:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pCRonAdClosed:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pCRonAdVideoCompletePlaying:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pCRonAdVideoGotReward:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload;
-(void)pCRonAdDidPayRevenue:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)pCRonAdDidGetEcpm:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)pCRonAdShowFail:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pCRonAdOtherEvent:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload event:(PCRCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
