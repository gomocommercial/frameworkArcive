//
//  PCRCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PCRCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCRCSAdLoadInterstitial : PCRCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
