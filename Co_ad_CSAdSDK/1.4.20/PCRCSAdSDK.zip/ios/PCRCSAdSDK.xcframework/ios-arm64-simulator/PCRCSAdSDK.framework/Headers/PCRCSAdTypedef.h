//
//  PCRCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PCRCSAdLoadSuccess = 1,
    PCRCSAdLoadFailure = -1,
    PCRCSAdLoadTimeout = -2
} PCRCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PCRCSAdPreloadSuccess = 1,
    //预加载失败
    PCRCSAdPreloadFailure = -1,
    //重复加载
    PCRCSAdPreloadRepeat = -2,
} PCRCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PCRCSAdWillAppear,//即将出现
    PCRCSAdDidAppear,//已经出现
    PCRCSAdWillDisappear,//即将消失
    PCRCSAdDidDisappear,//已经消失
    PCRCSAdMuted,//静音广告
    PCRCSAdWillLeaveApplication,//将要离开App

    PCRCSAdVideoStart,//开始播放 常用于video
    PCRCSAdVideoComplete,//播放完成 常用于video
    PCRCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PCRCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PCRCSAdNativeDidDownload,//下载完成 常用于fb Native
    PCRCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PCRCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PCRCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PCRCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PCRCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PCRCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PCRCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PCRCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PCRCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PCRCSAdBUOpenRenderSuccess, //渲染成功
    PCRCSAdBUOpenRenderFail, //渲染失败
    PCRCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PCRCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PCRCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PCRCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PCRCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PCRCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PCRCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PCRCSAdPlayerStatusStarted,//开始播放
    PCRCSAdPlayerStatusPaused,//用户行为导致暂停
    PCRCSAdPlayerStatusStoped,//播放停止
    PCRCSAdPlayerStatusError,//播放出错
    PCRCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PCRCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PCRCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PCRCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PCRCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PCRCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PCRCSAdRecordImpression, //广告曝光已记录
    PCRCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PCRCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PCRCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PCRCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PCRCSAdABUOpenWillPresentFullScreen,
    PCRCSAdABUOpenDidShowFailed,
    PCRCSAdABUOpenWillDissmissFullScreen,
    PCRCSAdABUOpenCountdownToZero,
    
    PCRCSAdABUBannerWillPresentFullScreen,
    PCRCSAdABUBannerWillDismissFullScreen,
    
    PCRCSAdABURewardDidLoad,
    PCRCSAdABURewardRenderFail,
    PCRCSAdABURewardDidShowFailed,

} PCRCSAdEvent;

typedef void (^PCRCSAdLoadCompleteBlock)(PCRCSAdLoadStatus adLoadStatus);

@class PCRCSAdSetupParamsMaker;
@class PCRCSAdSetupParams;

typedef PCRCSAdSetupParamsMaker *(^PCRCSAdStringInit)(NSString *);
typedef PCRCSAdSetupParamsMaker *(^PCRCSAdBoolInit)(BOOL);
typedef PCRCSAdSetupParamsMaker *(^PCRCSAdIntegerInit)(NSInteger);
typedef PCRCSAdSetupParamsMaker *(^PCRCSAdLongInit)(long);
typedef PCRCSAdSetupParamsMaker *(^PCRCSAdArrayInit)(NSArray *);
typedef PCRCSAdSetupParams *(^PCRCSAdMakeInit)(void);


@class PCRCSAdDataModel;
typedef void (^PCRCSAdRequestCompleteBlock)(NSMutableArray<PCRCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PCRCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PCRCSAdPreloadCompleteBlock)(PCRCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
