//
//  PCRCSAdLoadDataProtocol.h
//  PCRCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PCRCSAdTypedef.h"

@class PCRCSAdDataModel;
@class PCRCSAdLoadBase;

@protocol PCRCSAdLoadProtocol;

@protocol PCRCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)pCRonAdInfoFinish:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)pCRonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)pCRonAdFail:(PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
