//
//  PCRCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PCRCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCRCSAdLoadNative : PCRCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
