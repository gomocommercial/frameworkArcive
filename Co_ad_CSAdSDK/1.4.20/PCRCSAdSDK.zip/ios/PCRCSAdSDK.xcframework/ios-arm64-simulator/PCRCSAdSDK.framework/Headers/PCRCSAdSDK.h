//
//  PCRCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PCRCSAdLoadBase.h"
#import "PCRCSAdDataModel.h"
#import "PCRCSAdLoadProtocol.h"
#import "PCRCSAdLoadDataProtocol.h"
#import "PCRCSAdLoadShowProtocol.h"
#import "PCRCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCRCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pCRsetupByBlock:(void (^ _Nonnull)(PCRCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pCRloadAd:(NSString *)moduleId delegate:(id<PCRCSAdLoadDataProtocol>)delegate;

+ (void)pCRloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<PCRCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pCRadShowStatistic:(PCRCSAdDataModel *)dataModel adload:(nonnull PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pCRadClickStatistic:(PCRCSAdDataModel *)dataModel adload:(nonnull PCRCSAdLoadBase<PCRCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pCRaddCustomFecher:(Class<PCRCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
