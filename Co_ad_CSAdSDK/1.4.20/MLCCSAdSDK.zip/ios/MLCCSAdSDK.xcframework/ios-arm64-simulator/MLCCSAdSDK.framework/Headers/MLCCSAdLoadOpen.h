//
//  MLCCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "MLCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MLCCSAdLoadOpen : MLCCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
