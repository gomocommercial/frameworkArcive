//
//  MLCCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MLCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MLCCSAdLoadNative : MLCCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
