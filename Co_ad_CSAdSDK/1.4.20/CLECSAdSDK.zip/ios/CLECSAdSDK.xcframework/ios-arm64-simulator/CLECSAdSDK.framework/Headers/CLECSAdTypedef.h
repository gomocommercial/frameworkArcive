//
//  CLECSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CLECSAdLoadSuccess = 1,
    CLECSAdLoadFailure = -1,
    CLECSAdLoadTimeout = -2
} CLECSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CLECSAdPreloadSuccess = 1,
    //预加载失败
    CLECSAdPreloadFailure = -1,
    //重复加载
    CLECSAdPreloadRepeat = -2,
} CLECSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CLECSAdWillAppear,//即将出现
    CLECSAdDidAppear,//已经出现
    CLECSAdWillDisappear,//即将消失
    CLECSAdDidDisappear,//已经消失
    CLECSAdMuted,//静音广告
    CLECSAdWillLeaveApplication,//将要离开App

    CLECSAdVideoStart,//开始播放 常用于video
    CLECSAdVideoComplete,//播放完成 常用于video
    CLECSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CLECSAdVideoServerFail,//连接服务器成功，常用于fb video

    CLECSAdNativeDidDownload,//下载完成 常用于fb Native
    CLECSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CLECSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CLECSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CLECSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CLECSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CLECSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    CLECSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CLECSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CLECSAdBUOpenDidAutoDimiss,//开屏自动消失
    CLECSAdBUOpenRenderSuccess, //渲染成功
    CLECSAdBUOpenRenderFail, //渲染失败
    CLECSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    CLECSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CLECSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CLECSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CLECSAdDidPresentFullScreen,//插屏弹出全屏广告
    CLECSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CLECSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CLECSAdPlayerStatusStarted,//开始播放
    CLECSAdPlayerStatusPaused,//用户行为导致暂停
    CLECSAdPlayerStatusStoped,//播放停止
    CLECSAdPlayerStatusError,//播放出错
    CLECSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CLECSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CLECSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CLECSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CLECSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CLECSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CLECSAdRecordImpression, //广告曝光已记录
    CLECSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CLECSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CLECSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    CLECSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    CLECSAdABUOpenWillPresentFullScreen,
    CLECSAdABUOpenDidShowFailed,
    CLECSAdABUOpenWillDissmissFullScreen,
    CLECSAdABUOpenCountdownToZero,
    
    CLECSAdABUBannerWillPresentFullScreen,
    CLECSAdABUBannerWillDismissFullScreen,
    
    CLECSAdABURewardDidLoad,
    CLECSAdABURewardRenderFail,
    CLECSAdABURewardDidShowFailed,

} CLECSAdEvent;

typedef void (^CLECSAdLoadCompleteBlock)(CLECSAdLoadStatus adLoadStatus);

@class CLECSAdSetupParamsMaker;
@class CLECSAdSetupParams;

typedef CLECSAdSetupParamsMaker *(^CLECSAdStringInit)(NSString *);
typedef CLECSAdSetupParamsMaker *(^CLECSAdBoolInit)(BOOL);
typedef CLECSAdSetupParamsMaker *(^CLECSAdIntegerInit)(NSInteger);
typedef CLECSAdSetupParamsMaker *(^CLECSAdLongInit)(long);
typedef CLECSAdSetupParamsMaker *(^CLECSAdArrayInit)(NSArray *);
typedef CLECSAdSetupParams *(^CLECSAdMakeInit)(void);


@class CLECSAdDataModel;
typedef void (^CLECSAdRequestCompleteBlock)(NSMutableArray<CLECSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CLECSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CLECSAdPreloadCompleteBlock)(CLECSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
