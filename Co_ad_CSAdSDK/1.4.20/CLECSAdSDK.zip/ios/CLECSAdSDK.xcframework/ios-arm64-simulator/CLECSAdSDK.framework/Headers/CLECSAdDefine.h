//
//  CLECSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define cLEkAdvDataSourceFacebook   2 //FB 广告数据源
#define cLEkAdvDataSourceAdmob      8 //Admob 广告数据源
#define cLEkAdvDataSourceMopub      39//Mopub 广告数据源
#define cLEkAdvDataSourceApplovin   20//applovin 广告数据源

#define cLEkAdvDataSourceGDT        62//广点通 广告数据源
#define cLEkAdvDataSourceBaidu      63//百度 广告数据源
#define cLEkAdvDataSourceBU         64//头条 广告数据源
#define cLEkAdvDataSourceABU         70//头条聚合 广告数据源
#define cLEkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define cLEkAdvDataSourcePangle     74//pangle 广告数据源
#define cLEkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define cLEkOnlineAdvTypeBanner                   1  //banner
#define cLEkOnlineAdvTypeInterstitial             2  //全屏
#define cLEkOnlineAdvTypeNative                   3 //native
#define cLEkOnlineAdvTypeVideo                    4 //视频
#define cLEkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define cLEkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define cLEkOnlineAdvTypeOpen                     8 //开屏
#define cLEkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define cLEkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define cLEkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define cLEkAdServerConfigError  -1 //服务器返回数据不正确
#define cLEkAdLoadConfigFailed  -2 //广告加载失败


#define cLEAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define cLEkCSAdInstallDays @"cLEkCSAdInstallDays"
#define cLEkCSAdModule_key @"cLEkCSAdModule_key_%@"
#define cLEkCSNewAdModule_key @"cLEkCSNewAdModule_key_%@"
#define cLEkCSAdInstallTime @"cLEkCSAdInstallTime"
#define cLEkCSAdInstallHours @"cLEkCSAdInstallHours"
#define cLEkCSAdLastGetServerTime @"cLEkCSAdLastRequestTime"
#define cLEkCSAdloadTime 30

#define cLEkCSLoadAdTimeOutNotification @"cLEKCSLoadAdTimeOutNotification"
#define cLEkCSLoadAdTimeOutNotificationKey @"cLEKCSLoadAdTimeOutKey"

