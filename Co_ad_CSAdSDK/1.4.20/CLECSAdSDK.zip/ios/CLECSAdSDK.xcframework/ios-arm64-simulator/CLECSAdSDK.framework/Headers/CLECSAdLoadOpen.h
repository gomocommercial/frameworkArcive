//
//  CLECSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "CLECSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CLECSAdLoadOpen : CLECSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
