//
//  CLECSAdLoadDataProtocol.h
//  CLECSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "CLECSAdTypedef.h"

@class CLECSAdDataModel;
@class CLECSAdLoadBase;

@protocol CLECSAdLoadProtocol;

@protocol CLECSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)cLEonAdInfoFinish:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)cLEonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)cLEonAdFail:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload error:(NSError *)error;
@end
