//
//  CLECSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "CLECSAdLoadBase.h"
#import "CLECSAdDataModel.h"
#import "CLECSAdLoadProtocol.h"
#import "CLECSAdLoadDataProtocol.h"
#import "CLECSAdLoadShowProtocol.h"
#import "CLECSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface CLECSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)cLEsetupByBlock:(void (^ _Nonnull)(CLECSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)cLEloadAd:(NSString *)moduleId delegate:(id<CLECSAdLoadDataProtocol>)delegate;

+ (void)cLEloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<CLECSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)cLEadShowStatistic:(CLECSAdDataModel *)dataModel adload:(nonnull CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)cLEadClickStatistic:(CLECSAdDataModel *)dataModel adload:(nonnull CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)cLEaddCustomFecher:(Class<CLECSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
