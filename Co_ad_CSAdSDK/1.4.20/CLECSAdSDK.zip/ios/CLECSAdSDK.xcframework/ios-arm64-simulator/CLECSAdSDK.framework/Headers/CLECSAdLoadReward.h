//
//  CLECSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CLECSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CLECSAdLoadReward : CLECSAdLoadBase

@end

NS_ASSUME_NONNULL_END
