//
//  CLECSAdNetworkTool.h
//  CLECSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CLECSAdDataModel.h"
#import "CLECSAdTypedef.h"
#import "CLECSNewStoreLiteRequestTool.h"
#import "NSString+CLECSGenerateHash.h"

@interface CLECSAdNetworkTool : NSObject

+ (CLECSAdNetworkTool *)shared;
@property(nonatomic, copy) CLECSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)cLErequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CLECSAdRequestCompleteBlock)complete;

- (void)cLEsetCDay:(void(^ _Nullable)(bool success))handle;
@end
