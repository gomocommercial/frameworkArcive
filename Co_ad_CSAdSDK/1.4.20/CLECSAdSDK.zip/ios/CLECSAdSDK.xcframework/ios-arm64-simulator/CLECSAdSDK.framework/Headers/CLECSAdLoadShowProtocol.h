//
//  CLECSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CLECSAdTypedef.h"

@class CLECSAdLoadBase;

@protocol CLECSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CLECSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cLEonAdShowed:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cLEonAdClicked:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cLEonAdClosed:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cLEonAdVideoCompletePlaying:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)cLEonAdVideoGotReward:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload;
-(void)cLEonAdDidPayRevenue:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)cLEonAdDidGetEcpm:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)cLEonAdShowFail:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cLEonAdOtherEvent:(CLECSAdLoadBase<CLECSAdLoadProtocol> *)adload event:(CLECSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
