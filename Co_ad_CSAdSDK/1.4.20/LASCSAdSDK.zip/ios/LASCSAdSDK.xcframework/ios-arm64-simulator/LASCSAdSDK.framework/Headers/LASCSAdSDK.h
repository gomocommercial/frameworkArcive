//
//  LASCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "LASCSAdLoadBase.h"
#import "LASCSAdDataModel.h"
#import "LASCSAdLoadProtocol.h"
#import "LASCSAdLoadDataProtocol.h"
#import "LASCSAdLoadShowProtocol.h"
#import "LASCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)lASsetupByBlock:(void (^ _Nonnull)(LASCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)lASloadAd:(NSString *)moduleId delegate:(id<LASCSAdLoadDataProtocol>)delegate;

+ (void)lASloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<LASCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)lASadShowStatistic:(LASCSAdDataModel *)dataModel adload:(nonnull LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)lASadClickStatistic:(LASCSAdDataModel *)dataModel adload:(nonnull LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)lASaddCustomFecher:(Class<LASCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
