//
//  FSLPCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "FSLPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadOpen : FSLPCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
