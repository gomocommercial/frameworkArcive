//
//  FSLPCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "FSLPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadInterstitial : FSLPCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
