//
//  FSLPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define fSLPkAdvDataSourceFacebook   2 //FB 广告数据源
#define fSLPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define fSLPkAdvDataSourceMopub      39//Mopub 广告数据源
#define fSLPkAdvDataSourceApplovin   20//applovin 广告数据源

#define fSLPkAdvDataSourceGDT        62//广点通 广告数据源
#define fSLPkAdvDataSourceBaidu      63//百度 广告数据源
#define fSLPkAdvDataSourceBU         64//头条 广告数据源
#define fSLPkAdvDataSourceABU         70//头条聚合 广告数据源
#define fSLPkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define fSLPkAdvDataSourcePangle     74//pangle 广告数据源
#define fSLPkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define fSLPkOnlineAdvTypeBanner                   1  //banner
#define fSLPkOnlineAdvTypeInterstitial             2  //全屏
#define fSLPkOnlineAdvTypeNative                   3 //native
#define fSLPkOnlineAdvTypeVideo                    4 //视频
#define fSLPkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define fSLPkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define fSLPkOnlineAdvTypeOpen                     8 //开屏
#define fSLPkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define fSLPkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define fSLPkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define fSLPkAdServerConfigError  -1 //服务器返回数据不正确
#define fSLPkAdLoadConfigFailed  -2 //广告加载失败


#define fSLPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define fSLPkCSAdInstallDays @"fSLPkCSAdInstallDays"
#define fSLPkCSAdModule_key @"fSLPkCSAdModule_key_%@"
#define fSLPkCSNewAdModule_key @"fSLPkCSNewAdModule_key_%@"
#define fSLPkCSAdInstallTime @"fSLPkCSAdInstallTime"
#define fSLPkCSAdInstallHours @"fSLPkCSAdInstallHours"
#define fSLPkCSAdLastGetServerTime @"fSLPkCSAdLastRequestTime"
#define fSLPkCSAdloadTime 30

#define fSLPkCSLoadAdTimeOutNotification @"fSLPKCSLoadAdTimeOutNotification"
#define fSLPkCSLoadAdTimeOutNotificationKey @"fSLPKCSLoadAdTimeOutKey"

