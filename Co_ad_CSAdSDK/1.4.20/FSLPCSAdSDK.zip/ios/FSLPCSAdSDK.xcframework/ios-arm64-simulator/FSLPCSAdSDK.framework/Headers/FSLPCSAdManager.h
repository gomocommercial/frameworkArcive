//
//  FSLPCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FSLPCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)fSLPloadAd:(NSString *)moduleId delegate:(id<FSLPCSAdLoadDataProtocol>)delegate;

- (void)fSLPloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<FSLPCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)fSLPremoveData:(id)obj;
- (NSDictionary *)getDevicesInfo;

@end

NS_ASSUME_NONNULL_END
