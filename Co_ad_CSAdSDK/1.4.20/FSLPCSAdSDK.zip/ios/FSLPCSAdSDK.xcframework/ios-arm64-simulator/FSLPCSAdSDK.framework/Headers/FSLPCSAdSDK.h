//
//  FSLPCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "FSLPCSAdLoadBase.h"
#import "FSLPCSAdDataModel.h"
#import "FSLPCSAdLoadProtocol.h"
#import "FSLPCSAdLoadDataProtocol.h"
#import "FSLPCSAdLoadShowProtocol.h"
#import "FSLPCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)fSLPsetupByBlock:(void (^ _Nonnull)(FSLPCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)fSLPloadAd:(NSString *)moduleId delegate:(id<FSLPCSAdLoadDataProtocol>)delegate;

+ (void)fSLPloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<FSLPCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)fSLPadShowStatistic:(FSLPCSAdDataModel *)dataModel adload:(nonnull FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)fSLPadClickStatistic:(FSLPCSAdDataModel *)dataModel adload:(nonnull FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)fSLPaddCustomFecher:(Class<FSLPCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
