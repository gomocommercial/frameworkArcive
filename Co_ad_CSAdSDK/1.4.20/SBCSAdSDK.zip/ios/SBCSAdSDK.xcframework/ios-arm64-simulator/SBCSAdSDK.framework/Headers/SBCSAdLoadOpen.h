//
//  SBCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "SBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBCSAdLoadOpen : SBCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
