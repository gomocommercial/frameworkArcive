//
//  SBCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBCSAdLoadNative : SBCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
