//
//  SBCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "SBCSAdLoadBase.h"
#import "SBCSAdDataModel.h"
#import "SBCSAdLoadProtocol.h"
#import "SBCSAdLoadDataProtocol.h"
#import "SBCSAdLoadShowProtocol.h"
#import "SBCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)sBsetupByBlock:(void (^ _Nonnull)(SBCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)sBloadAd:(NSString *)moduleId delegate:(id<SBCSAdLoadDataProtocol>)delegate;

+ (void)sBloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<SBCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)sBadShowStatistic:(SBCSAdDataModel *)dataModel adload:(nonnull SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)sBadClickStatistic:(SBCSAdDataModel *)dataModel adload:(nonnull SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)sBaddCustomFecher:(Class<SBCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
