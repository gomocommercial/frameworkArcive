//
//  SBCSAdLoadDataProtocol.h
//  SBCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "SBCSAdTypedef.h"

@class SBCSAdDataModel;
@class SBCSAdLoadBase;

@protocol SBCSAdLoadProtocol;

@protocol SBCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)sBonAdInfoFinish:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)sBonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)sBonAdFail:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
