//
//  PCSCSAdSetupParamsMaker.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PCSCSAdSetupParams.h"
#import "PCSCSAdTypedef.h"

NS_ASSUME_NONNULL_BEGIN

@class PCSCSAdSetupParamsMaker;

@interface PCSCSAdSetupParamsMaker : NSObject

// MARK: - 必填
/**
 产品ID
 */
@property (assign, nonatomic, readonly) PCSCSAdIntegerInit cid;

/**
 真实渠道号（app发布渠道）
 */
@property (assign, nonatomic, readonly) PCSCSAdIntegerInit channel;

/**
 数据渠道（产品数据渠道）
  使用新广告后台（useNewStoreLite为true时），该字段不用传
 */
@property (assign, nonatomic, readonly) PCSCSAdIntegerInit dataChannel;

/**
 是否使用新的广告接口服务
 useNewStoreLite为true时，Appid,apiKey，apiSecret，desKey和appid必须配置
 AVAILABLE(1.3.16)
 */@property (assign, nonatomic, readonly) PCSCSAdBoolInit useNewStoreLite;


// MARK: - 选填

/**
 是否开启log默认不开启:false
 */
@property (assign, nonatomic, readonly) PCSCSAdBoolInit debugLog;

/**
 客户端版本号(默认获取build号)
 */
@property (assign, nonatomic, readonly) PCSCSAdIntegerInit cversion;

/**
 是否为测试服默认开启:true
 */
@property (assign, nonatomic, readonly) PCSCSAdBoolInit isTest;

/**
 des长度默认:8 * 1024
 */
@property (assign, nonatomic, readonly) PCSCSAdLongInit desBytesCount;

/**
 用户来源类型，一般从买量SDK获取
 */
@property (assign, nonatomic, readonly) PCSCSAdStringInit userFrom;

/**
 用户买量渠道：选填 如：fb；一般从买量SDK获取
 */
@property (assign, nonatomic, readonly) PCSCSAdStringInit buyChannel;

/**
 是否为升级用户 选填，0.未知(此时服务器会认为是升级用户) 1.是升级用户 2.不是升级用户
 */
@property (assign, nonatomic, readonly) PCSCSAdIntegerInit upgrade;

/**
 //入口ID SDK默认设置1 ： 1 主包 2 主题  3 主题商城 4 广告widget 101.自定义-1
 */
@property (assign, nonatomic, readonly) PCSCSAdIntegerInit entranceId;



/**
 选填：如果项目有特定的用户id则必填，没有则不填
 */
@property (assign, nonatomic, readonly) PCSCSAdStringInit uid;

/**
 缓存时间：默认4小时
 */
@property (assign, nonatomic, readonly) PCSCSAdIntegerInit cacheTime;

/**
 测试设备列表（identifier）
 */
@property (assign, nonatomic, readonly) PCSCSAdArrayInit testDevices;

/**
 是否使用iP发起请求
 */
@property (assign, nonatomic, readonly) PCSCSAdBoolInit useIP;

/**
 * 构建CSAdSetupParams对象
 */
@property (strong, nonatomic, readonly) PCSCSAdMakeInit make;
/**
 选填:加密秘钥(SDK已配置，可重新设置)
 */
@property (assign, nonatomic, readonly) PCSCSAdStringInit desKey;


/**
 appId，useNewStoreLite为true时必填
 */
@property (nonatomic,assign,readonly) PCSCSAdStringInit appId;
/**
 apiKey，useNewStoreLite为true时必填
 */
@property (nonatomic,assign,readonly) PCSCSAdStringInit apiKey;
/**
 apiSecret，useNewStoreLite为true时必填
 */
@property (nonatomic,assign,readonly) PCSCSAdStringInit apiSecret;
@end

NS_ASSUME_NONNULL_END
