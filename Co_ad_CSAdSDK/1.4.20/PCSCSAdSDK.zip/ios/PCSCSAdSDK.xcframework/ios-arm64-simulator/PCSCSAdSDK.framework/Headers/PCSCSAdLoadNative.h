//
//  PCSCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PCSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadNative : PCSCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
