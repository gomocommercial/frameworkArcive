//
//  PCSCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PCSCSAdLoadSuccess = 1,
    PCSCSAdLoadFailure = -1,
    PCSCSAdLoadTimeout = -2
} PCSCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PCSCSAdPreloadSuccess = 1,
    //预加载失败
    PCSCSAdPreloadFailure = -1,
    //重复加载
    PCSCSAdPreloadRepeat = -2,
} PCSCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PCSCSAdWillAppear,//即将出现
    PCSCSAdDidAppear,//已经出现
    PCSCSAdWillDisappear,//即将消失
    PCSCSAdDidDisappear,//已经消失
    PCSCSAdMuted,//静音广告
    PCSCSAdWillLeaveApplication,//将要离开App

    PCSCSAdVideoStart,//开始播放 常用于video
    PCSCSAdVideoComplete,//播放完成 常用于video
    PCSCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PCSCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PCSCSAdNativeDidDownload,//下载完成 常用于fb Native
    PCSCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PCSCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PCSCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PCSCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PCSCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PCSCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PCSCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PCSCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PCSCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PCSCSAdBUOpenRenderSuccess, //渲染成功
    PCSCSAdBUOpenRenderFail, //渲染失败
    PCSCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PCSCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PCSCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PCSCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PCSCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PCSCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PCSCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PCSCSAdPlayerStatusStarted,//开始播放
    PCSCSAdPlayerStatusPaused,//用户行为导致暂停
    PCSCSAdPlayerStatusStoped,//播放停止
    PCSCSAdPlayerStatusError,//播放出错
    PCSCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PCSCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PCSCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PCSCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PCSCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PCSCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PCSCSAdRecordImpression, //广告曝光已记录
    PCSCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PCSCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PCSCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PCSCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PCSCSAdABUOpenWillPresentFullScreen,
    PCSCSAdABUOpenDidShowFailed,
    PCSCSAdABUOpenWillDissmissFullScreen,
    PCSCSAdABUOpenCountdownToZero,
    
    PCSCSAdABUBannerWillPresentFullScreen,
    PCSCSAdABUBannerWillDismissFullScreen,
    
    PCSCSAdABURewardDidLoad,
    PCSCSAdABURewardRenderFail,
    PCSCSAdABURewardDidShowFailed,

} PCSCSAdEvent;

typedef void (^PCSCSAdLoadCompleteBlock)(PCSCSAdLoadStatus adLoadStatus);

@class PCSCSAdSetupParamsMaker;
@class PCSCSAdSetupParams;

typedef PCSCSAdSetupParamsMaker *(^PCSCSAdStringInit)(NSString *);
typedef PCSCSAdSetupParamsMaker *(^PCSCSAdBoolInit)(BOOL);
typedef PCSCSAdSetupParamsMaker *(^PCSCSAdIntegerInit)(NSInteger);
typedef PCSCSAdSetupParamsMaker *(^PCSCSAdLongInit)(long);
typedef PCSCSAdSetupParamsMaker *(^PCSCSAdArrayInit)(NSArray *);
typedef PCSCSAdSetupParams *(^PCSCSAdMakeInit)(void);


@class PCSCSAdDataModel;
typedef void (^PCSCSAdRequestCompleteBlock)(NSMutableArray<PCSCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PCSCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PCSCSAdPreloadCompleteBlock)(PCSCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
