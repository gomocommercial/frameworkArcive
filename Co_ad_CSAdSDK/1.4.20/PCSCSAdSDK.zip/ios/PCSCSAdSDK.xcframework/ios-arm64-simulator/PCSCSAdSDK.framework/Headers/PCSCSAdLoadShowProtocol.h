//
//  PCSCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PCSCSAdTypedef.h"

@class PCSCSAdLoadBase;

@protocol PCSCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PCSCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pCSonAdShowed:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pCSonAdClicked:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pCSonAdClosed:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pCSonAdVideoCompletePlaying:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pCSonAdVideoGotReward:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload;
-(void)pCSonAdDidPayRevenue:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)pCSonAdDidGetEcpm:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)pCSonAdShowFail:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pCSonAdOtherEvent:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload event:(PCSCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
