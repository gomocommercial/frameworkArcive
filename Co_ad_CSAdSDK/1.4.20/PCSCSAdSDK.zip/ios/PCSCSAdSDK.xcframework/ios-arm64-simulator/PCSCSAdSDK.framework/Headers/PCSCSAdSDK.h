//
//  PCSCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PCSCSAdLoadBase.h"
#import "PCSCSAdDataModel.h"
#import "PCSCSAdLoadProtocol.h"
#import "PCSCSAdLoadDataProtocol.h"
#import "PCSCSAdLoadShowProtocol.h"
#import "PCSCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pCSsetupByBlock:(void (^ _Nonnull)(PCSCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pCSloadAd:(NSString *)moduleId delegate:(id<PCSCSAdLoadDataProtocol>)delegate;

+ (void)pCSloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<PCSCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pCSadShowStatistic:(PCSCSAdDataModel *)dataModel adload:(nonnull PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pCSadClickStatistic:(PCSCSAdDataModel *)dataModel adload:(nonnull PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pCSaddCustomFecher:(Class<PCSCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
