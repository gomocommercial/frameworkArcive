//
//  PCSCSAdLoadDataProtocol.h
//  PCSCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PCSCSAdTypedef.h"

@class PCSCSAdDataModel;
@class PCSCSAdLoadBase;

@protocol PCSCSAdLoadProtocol;

@protocol PCSCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)pCSonAdInfoFinish:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)pCSonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)pCSonAdFail:(PCSCSAdLoadBase<PCSCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
