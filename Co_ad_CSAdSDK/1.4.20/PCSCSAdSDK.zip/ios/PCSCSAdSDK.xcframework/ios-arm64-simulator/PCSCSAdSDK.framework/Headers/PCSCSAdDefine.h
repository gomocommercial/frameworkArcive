//
//  PCSCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pCSkAdvDataSourceFacebook   2 //FB 广告数据源
#define pCSkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pCSkAdvDataSourceMopub      39//Mopub 广告数据源
#define pCSkAdvDataSourceApplovin   20//applovin 广告数据源

#define pCSkAdvDataSourceGDT        62//广点通 广告数据源
#define pCSkAdvDataSourceBaidu      63//百度 广告数据源
#define pCSkAdvDataSourceBU         64//头条 广告数据源
#define pCSkAdvDataSourceABU         70//头条聚合 广告数据源
#define pCSkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pCSkAdvDataSourcePangle     74//pangle 广告数据源
#define pCSkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define pCSkOnlineAdvTypeBanner                   1  //banner
#define pCSkOnlineAdvTypeInterstitial             2  //全屏
#define pCSkOnlineAdvTypeNative                   3 //native
#define pCSkOnlineAdvTypeVideo                    4 //视频
#define pCSkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pCSkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pCSkOnlineAdvTypeOpen                     8 //开屏
#define pCSkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pCSkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pCSkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pCSkAdServerConfigError  -1 //服务器返回数据不正确
#define pCSkAdLoadConfigFailed  -2 //广告加载失败


#define pCSAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pCSkCSAdInstallDays @"pCSkCSAdInstallDays"
#define pCSkCSAdModule_key @"pCSkCSAdModule_key_%@"
#define pCSkCSNewAdModule_key @"pCSkCSNewAdModule_key_%@"
#define pCSkCSAdInstallTime @"pCSkCSAdInstallTime"
#define pCSkCSAdInstallHours @"pCSkCSAdInstallHours"
#define pCSkCSAdLastGetServerTime @"pCSkCSAdLastRequestTime"
#define pCSkCSAdloadTime 30

#define pCSkCSLoadAdTimeOutNotification @"pCSKCSLoadAdTimeOutNotification"
#define pCSkCSLoadAdTimeOutNotificationKey @"pCSKCSLoadAdTimeOutKey"

