//
//  PCSCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PCSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadReward : PCSCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
