//
//  PCSCSAdNetworkTool.h
//  PCSCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PCSCSAdDataModel.h"
#import "PCSCSAdTypedef.h"
#import "PCSCSNewStoreLiteRequestTool.h"
#import "NSString+PCSCSGenerateHash.h"

@interface PCSCSAdNetworkTool : NSObject

+ (PCSCSAdNetworkTool *)shared;
@property(nonatomic, copy) PCSCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pCSrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PCSCSAdRequestCompleteBlock)complete;

- (void)pCSsetCDay:(void(^ _Nullable)(bool success))handle;
@end
