//
//  STPBCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "STPBCSAdLoadBase.h"
#import "STPBCSAdDataModel.h"
#import "STPBCSAdLoadProtocol.h"
#import "STPBCSAdLoadDataProtocol.h"
#import "STPBCSAdLoadShowProtocol.h"
#import "STPBCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)sTPBsetupByBlock:(void (^ _Nonnull)(STPBCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)sTPBloadAd:(NSString *)moduleId delegate:(id<STPBCSAdLoadDataProtocol>)delegate;

+ (void)sTPBloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<STPBCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)sTPBadShowStatistic:(STPBCSAdDataModel *)dataModel adload:(nonnull STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)sTPBadClickStatistic:(STPBCSAdDataModel *)dataModel adload:(nonnull STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)sTPBaddCustomFecher:(Class<STPBCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
