//
//  STPBCSAdNetworkTool.h
//  STPBCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "STPBCSAdDataModel.h"
#import "STPBCSAdTypedef.h"
#import "STPBCSNewStoreLiteRequestTool.h"
#import "NSString+STPBCSGenerateHash.h"

@interface STPBCSAdNetworkTool : NSObject

+ (STPBCSAdNetworkTool *)shared;
@property(nonatomic, copy) STPBCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sTPBrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(STPBCSAdRequestCompleteBlock)complete;

- (void)sTPBsetCDay:(void(^ _Nullable)(bool success))handle;
@end
