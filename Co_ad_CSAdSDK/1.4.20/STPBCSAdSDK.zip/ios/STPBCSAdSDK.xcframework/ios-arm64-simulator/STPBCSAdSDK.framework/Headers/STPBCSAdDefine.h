//
//  STPBCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sTPBkAdvDataSourceFacebook   2 //FB 广告数据源
#define sTPBkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sTPBkAdvDataSourceMopub      39//Mopub 广告数据源
#define sTPBkAdvDataSourceApplovin   20//applovin 广告数据源

#define sTPBkAdvDataSourceGDT        62//广点通 广告数据源
#define sTPBkAdvDataSourceBaidu      63//百度 广告数据源
#define sTPBkAdvDataSourceBU         64//头条 广告数据源
#define sTPBkAdvDataSourceABU         70//头条聚合 广告数据源
#define sTPBkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define sTPBkAdvDataSourcePangle     74//pangle 广告数据源
#define sTPBkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define sTPBkOnlineAdvTypeBanner                   1  //banner
#define sTPBkOnlineAdvTypeInterstitial             2  //全屏
#define sTPBkOnlineAdvTypeNative                   3 //native
#define sTPBkOnlineAdvTypeVideo                    4 //视频
#define sTPBkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sTPBkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sTPBkOnlineAdvTypeOpen                     8 //开屏
#define sTPBkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define sTPBkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define sTPBkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define sTPBkAdServerConfigError  -1 //服务器返回数据不正确
#define sTPBkAdLoadConfigFailed  -2 //广告加载失败


#define sTPBAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sTPBkCSAdInstallDays @"sTPBkCSAdInstallDays"
#define sTPBkCSAdModule_key @"sTPBkCSAdModule_key_%@"
#define sTPBkCSNewAdModule_key @"sTPBkCSNewAdModule_key_%@"
#define sTPBkCSAdInstallTime @"sTPBkCSAdInstallTime"
#define sTPBkCSAdInstallHours @"sTPBkCSAdInstallHours"
#define sTPBkCSAdLastGetServerTime @"sTPBkCSAdLastRequestTime"
#define sTPBkCSAdloadTime 30

#define sTPBkCSLoadAdTimeOutNotification @"sTPBKCSLoadAdTimeOutNotification"
#define sTPBkCSLoadAdTimeOutNotificationKey @"sTPBKCSLoadAdTimeOutKey"

