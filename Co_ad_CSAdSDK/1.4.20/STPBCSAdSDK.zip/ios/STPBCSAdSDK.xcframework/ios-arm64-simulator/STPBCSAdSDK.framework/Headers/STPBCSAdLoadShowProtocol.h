//
//  STPBCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "STPBCSAdTypedef.h"

@class STPBCSAdLoadBase;

@protocol STPBCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol STPBCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sTPBonAdShowed:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sTPBonAdClicked:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sTPBonAdClosed:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sTPBonAdVideoCompletePlaying:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sTPBonAdVideoGotReward:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload;
-(void)sTPBonAdDidPayRevenue:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)sTPBonAdDidGetEcpm:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)sTPBonAdShowFail:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sTPBonAdOtherEvent:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload event:(STPBCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
