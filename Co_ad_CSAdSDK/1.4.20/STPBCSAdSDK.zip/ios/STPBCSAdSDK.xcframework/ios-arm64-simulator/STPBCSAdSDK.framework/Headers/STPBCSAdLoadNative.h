//
//  STPBCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "STPBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadNative : STPBCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
