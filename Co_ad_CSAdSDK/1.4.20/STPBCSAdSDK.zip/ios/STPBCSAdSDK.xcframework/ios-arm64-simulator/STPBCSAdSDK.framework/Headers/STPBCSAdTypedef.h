//
//  STPBCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    STPBCSAdLoadSuccess = 1,
    STPBCSAdLoadFailure = -1,
    STPBCSAdLoadTimeout = -2
} STPBCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    STPBCSAdPreloadSuccess = 1,
    //预加载失败
    STPBCSAdPreloadFailure = -1,
    //重复加载
    STPBCSAdPreloadRepeat = -2,
} STPBCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    STPBCSAdWillAppear,//即将出现
    STPBCSAdDidAppear,//已经出现
    STPBCSAdWillDisappear,//即将消失
    STPBCSAdDidDisappear,//已经消失
    STPBCSAdMuted,//静音广告
    STPBCSAdWillLeaveApplication,//将要离开App

    STPBCSAdVideoStart,//开始播放 常用于video
    STPBCSAdVideoComplete,//播放完成 常用于video
    STPBCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    STPBCSAdVideoServerFail,//连接服务器成功，常用于fb video

    STPBCSAdNativeDidDownload,//下载完成 常用于fb Native
    STPBCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    STPBCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    STPBCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    STPBCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    STPBCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    STPBCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    STPBCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    STPBCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    STPBCSAdBUOpenDidAutoDimiss,//开屏自动消失
    STPBCSAdBUOpenRenderSuccess, //渲染成功
    STPBCSAdBUOpenRenderFail, //渲染失败
    STPBCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    STPBCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    STPBCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    STPBCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    STPBCSAdDidPresentFullScreen,//插屏弹出全屏广告
    STPBCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    STPBCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    STPBCSAdPlayerStatusStarted,//开始播放
    STPBCSAdPlayerStatusPaused,//用户行为导致暂停
    STPBCSAdPlayerStatusStoped,//播放停止
    STPBCSAdPlayerStatusError,//播放出错
    STPBCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    STPBCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    STPBCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    STPBCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    STPBCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    STPBCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    STPBCSAdRecordImpression, //广告曝光已记录
    STPBCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    STPBCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    STPBCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    STPBCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    STPBCSAdABUOpenWillPresentFullScreen,
    STPBCSAdABUOpenDidShowFailed,
    STPBCSAdABUOpenWillDissmissFullScreen,
    STPBCSAdABUOpenCountdownToZero,
    
    STPBCSAdABUBannerWillPresentFullScreen,
    STPBCSAdABUBannerWillDismissFullScreen,
    
    STPBCSAdABURewardDidLoad,
    STPBCSAdABURewardRenderFail,
    STPBCSAdABURewardDidShowFailed,

} STPBCSAdEvent;

typedef void (^STPBCSAdLoadCompleteBlock)(STPBCSAdLoadStatus adLoadStatus);

@class STPBCSAdSetupParamsMaker;
@class STPBCSAdSetupParams;

typedef STPBCSAdSetupParamsMaker *(^STPBCSAdStringInit)(NSString *);
typedef STPBCSAdSetupParamsMaker *(^STPBCSAdBoolInit)(BOOL);
typedef STPBCSAdSetupParamsMaker *(^STPBCSAdIntegerInit)(NSInteger);
typedef STPBCSAdSetupParamsMaker *(^STPBCSAdLongInit)(long);
typedef STPBCSAdSetupParamsMaker *(^STPBCSAdArrayInit)(NSArray *);
typedef STPBCSAdSetupParams *(^STPBCSAdMakeInit)(void);


@class STPBCSAdDataModel;
typedef void (^STPBCSAdRequestCompleteBlock)(NSMutableArray<STPBCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^STPBCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^STPBCSAdPreloadCompleteBlock)(STPBCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
