//
//  STPBCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "STPBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadOpen : STPBCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
