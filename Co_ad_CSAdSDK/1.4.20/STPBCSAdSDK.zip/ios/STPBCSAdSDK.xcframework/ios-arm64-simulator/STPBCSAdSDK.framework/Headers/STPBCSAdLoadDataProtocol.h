//
//  STPBCSAdLoadDataProtocol.h
//  STPBCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "STPBCSAdTypedef.h"

@class STPBCSAdDataModel;
@class STPBCSAdLoadBase;

@protocol STPBCSAdLoadProtocol;

@protocol STPBCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)sTPBonAdInfoFinish:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)sTPBonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)sTPBonAdFail:(STPBCSAdLoadBase<STPBCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
