//
//  LUMCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lUMkAdvDataSourceFacebook   2 //FB 广告数据源
#define lUMkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lUMkAdvDataSourceMopub      39//Mopub 广告数据源
#define lUMkAdvDataSourceApplovin   20//applovin 广告数据源

#define lUMkAdvDataSourceGDT        62//广点通 广告数据源
#define lUMkAdvDataSourceBaidu      63//百度 广告数据源
#define lUMkAdvDataSourceBU         64//头条 广告数据源
#define lUMkAdvDataSourceABU         70//头条聚合 广告数据源
#define lUMkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define lUMkAdvDataSourcePangle     74//pangle 广告数据源
#define lUMkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define lUMkOnlineAdvTypeBanner                   1  //banner
#define lUMkOnlineAdvTypeInterstitial             2  //全屏
#define lUMkOnlineAdvTypeNative                   3 //native
#define lUMkOnlineAdvTypeVideo                    4 //视频
#define lUMkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define lUMkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define lUMkOnlineAdvTypeOpen                     8 //开屏
#define lUMkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define lUMkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define lUMkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define lUMkAdServerConfigError  -1 //服务器返回数据不正确
#define lUMkAdLoadConfigFailed  -2 //广告加载失败


#define lUMAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lUMkCSAdInstallDays @"lUMkCSAdInstallDays"
#define lUMkCSAdModule_key @"lUMkCSAdModule_key_%@"
#define lUMkCSNewAdModule_key @"lUMkCSNewAdModule_key_%@"
#define lUMkCSAdInstallTime @"lUMkCSAdInstallTime"
#define lUMkCSAdInstallHours @"lUMkCSAdInstallHours"
#define lUMkCSAdLastGetServerTime @"lUMkCSAdLastRequestTime"
#define lUMkCSAdloadTime 30

#define lUMkCSLoadAdTimeOutNotification @"lUMKCSLoadAdTimeOutNotification"
#define lUMkCSLoadAdTimeOutNotificationKey @"lUMKCSLoadAdTimeOutKey"

