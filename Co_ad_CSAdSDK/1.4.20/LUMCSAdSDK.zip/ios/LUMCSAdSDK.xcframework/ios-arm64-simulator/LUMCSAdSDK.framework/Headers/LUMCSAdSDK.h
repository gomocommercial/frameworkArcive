//
//  LUMCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "LUMCSAdLoadBase.h"
#import "LUMCSAdDataModel.h"
#import "LUMCSAdLoadProtocol.h"
#import "LUMCSAdLoadDataProtocol.h"
#import "LUMCSAdLoadShowProtocol.h"
#import "LUMCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUMCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)lUMsetupByBlock:(void (^ _Nonnull)(LUMCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)lUMloadAd:(NSString *)moduleId delegate:(id<LUMCSAdLoadDataProtocol>)delegate;

+ (void)lUMloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<LUMCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)lUMadShowStatistic:(LUMCSAdDataModel *)dataModel adload:(nonnull LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)lUMadClickStatistic:(LUMCSAdDataModel *)dataModel adload:(nonnull LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)lUMaddCustomFecher:(Class<LUMCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
