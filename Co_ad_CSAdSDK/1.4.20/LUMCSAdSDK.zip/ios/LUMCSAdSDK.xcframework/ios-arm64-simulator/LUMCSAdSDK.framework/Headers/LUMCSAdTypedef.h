//
//  LUMCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    LUMCSAdLoadSuccess = 1,
    LUMCSAdLoadFailure = -1,
    LUMCSAdLoadTimeout = -2
} LUMCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    LUMCSAdPreloadSuccess = 1,
    //预加载失败
    LUMCSAdPreloadFailure = -1,
    //重复加载
    LUMCSAdPreloadRepeat = -2,
} LUMCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    LUMCSAdWillAppear,//即将出现
    LUMCSAdDidAppear,//已经出现
    LUMCSAdWillDisappear,//即将消失
    LUMCSAdDidDisappear,//已经消失
    LUMCSAdMuted,//静音广告
    LUMCSAdWillLeaveApplication,//将要离开App

    LUMCSAdVideoStart,//开始播放 常用于video
    LUMCSAdVideoComplete,//播放完成 常用于video
    LUMCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    LUMCSAdVideoServerFail,//连接服务器成功，常用于fb video

    LUMCSAdNativeDidDownload,//下载完成 常用于fb Native
    LUMCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    LUMCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    LUMCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    LUMCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    LUMCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    LUMCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    LUMCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    LUMCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    LUMCSAdBUOpenDidAutoDimiss,//开屏自动消失
    LUMCSAdBUOpenRenderSuccess, //渲染成功
    LUMCSAdBUOpenRenderFail, //渲染失败
    LUMCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    LUMCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    LUMCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    LUMCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    LUMCSAdDidPresentFullScreen,//插屏弹出全屏广告
    LUMCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    LUMCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    LUMCSAdPlayerStatusStarted,//开始播放
    LUMCSAdPlayerStatusPaused,//用户行为导致暂停
    LUMCSAdPlayerStatusStoped,//播放停止
    LUMCSAdPlayerStatusError,//播放出错
    LUMCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    LUMCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    LUMCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    LUMCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    LUMCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    LUMCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    LUMCSAdRecordImpression, //广告曝光已记录
    LUMCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    LUMCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    LUMCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    LUMCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    LUMCSAdABUOpenWillPresentFullScreen,
    LUMCSAdABUOpenDidShowFailed,
    LUMCSAdABUOpenWillDissmissFullScreen,
    LUMCSAdABUOpenCountdownToZero,
    
    LUMCSAdABUBannerWillPresentFullScreen,
    LUMCSAdABUBannerWillDismissFullScreen,
    
    LUMCSAdABURewardDidLoad,
    LUMCSAdABURewardRenderFail,
    LUMCSAdABURewardDidShowFailed,

} LUMCSAdEvent;

typedef void (^LUMCSAdLoadCompleteBlock)(LUMCSAdLoadStatus adLoadStatus);

@class LUMCSAdSetupParamsMaker;
@class LUMCSAdSetupParams;

typedef LUMCSAdSetupParamsMaker *(^LUMCSAdStringInit)(NSString *);
typedef LUMCSAdSetupParamsMaker *(^LUMCSAdBoolInit)(BOOL);
typedef LUMCSAdSetupParamsMaker *(^LUMCSAdIntegerInit)(NSInteger);
typedef LUMCSAdSetupParamsMaker *(^LUMCSAdLongInit)(long);
typedef LUMCSAdSetupParamsMaker *(^LUMCSAdArrayInit)(NSArray *);
typedef LUMCSAdSetupParams *(^LUMCSAdMakeInit)(void);


@class LUMCSAdDataModel;
typedef void (^LUMCSAdRequestCompleteBlock)(NSMutableArray<LUMCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^LUMCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^LUMCSAdPreloadCompleteBlock)(LUMCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
