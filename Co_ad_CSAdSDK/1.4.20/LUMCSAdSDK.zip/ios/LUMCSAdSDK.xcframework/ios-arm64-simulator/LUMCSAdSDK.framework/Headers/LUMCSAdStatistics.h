//
//  LUMCSAdStatistics.h
//  LUMCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "LUMCSAdDataModel.h"
#import "LUMCSAdTypedef.h"
#import "LUMCSAdLoadBase.h"
@interface LUMCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)lUMadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)lUMadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)lUMadRewardVideoCompleteStatistic:(LUMCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)lUMadShowStatistic:(LUMCSAdDataModel *)dataModel adload:(nonnull LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)lUMadClickStatistic:(LUMCSAdDataModel *)dataModel adload:(nonnull LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)lUMadUploadRevenueStatistic:(LUMCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
