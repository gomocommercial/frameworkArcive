//
//  LUMCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LUMCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUMCSAdLoadInterstitial : LUMCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
