//
//  LUMCSAdNetworkTool.h
//  LUMCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "LUMCSAdDataModel.h"
#import "LUMCSAdTypedef.h"
#import "LUMCSNewStoreLiteRequestTool.h"
#import "NSString+LUMCSGenerateHash.h"

@interface LUMCSAdNetworkTool : NSObject

+ (LUMCSAdNetworkTool *)shared;
@property(nonatomic, copy) LUMCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)lUMrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(LUMCSAdRequestCompleteBlock)complete;

- (void)lUMsetCDay:(void(^ _Nullable)(bool success))handle;
@end
