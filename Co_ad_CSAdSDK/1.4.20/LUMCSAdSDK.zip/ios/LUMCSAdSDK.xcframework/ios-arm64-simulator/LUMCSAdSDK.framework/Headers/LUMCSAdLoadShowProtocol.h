//
//  LUMCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LUMCSAdTypedef.h"

@class LUMCSAdLoadBase;

@protocol LUMCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LUMCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lUMonAdShowed:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)lUMonAdClicked:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lUMonAdClosed:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lUMonAdVideoCompletePlaying:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)lUMonAdVideoGotReward:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;
-(void)lUMonAdDidPayRevenue:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)lUMonAdDidGetEcpm:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)lUMonAdShowFail:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lUMonAdOtherEvent:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload event:(LUMCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
