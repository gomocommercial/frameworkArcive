//
//  LUMCSAdLoadDataProtocol.h
//  LUMCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "LUMCSAdTypedef.h"

@class LUMCSAdDataModel;
@class LUMCSAdLoadBase;

@protocol LUMCSAdLoadProtocol;

@protocol LUMCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)lUMonAdInfoFinish:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)lUMonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)lUMonAdFail:(LUMCSAdLoadBase<LUMCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
