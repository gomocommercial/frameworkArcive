//
//  LUMCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LUMCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUMCSAdLoadNative : LUMCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
