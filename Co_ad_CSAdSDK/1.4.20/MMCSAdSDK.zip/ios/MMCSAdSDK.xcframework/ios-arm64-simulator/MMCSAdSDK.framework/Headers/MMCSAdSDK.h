//
//  MMCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "MMCSAdLoadBase.h"
#import "MMCSAdDataModel.h"
#import "MMCSAdLoadProtocol.h"
#import "MMCSAdLoadDataProtocol.h"
#import "MMCSAdLoadShowProtocol.h"
#import "MMCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface MMCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)mMsetupByBlock:(void (^ _Nonnull)(MMCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)mMloadAd:(NSString *)moduleId delegate:(id<MMCSAdLoadDataProtocol>)delegate;

+ (void)mMloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<MMCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)mMadShowStatistic:(MMCSAdDataModel *)dataModel adload:(nonnull MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)mMadClickStatistic:(MMCSAdDataModel *)dataModel adload:(nonnull MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)mMaddCustomFecher:(Class<MMCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
