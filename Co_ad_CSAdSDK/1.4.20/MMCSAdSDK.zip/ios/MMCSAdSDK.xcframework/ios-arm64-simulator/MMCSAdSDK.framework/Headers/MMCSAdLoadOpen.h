//
//  MMCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "MMCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MMCSAdLoadOpen : MMCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
