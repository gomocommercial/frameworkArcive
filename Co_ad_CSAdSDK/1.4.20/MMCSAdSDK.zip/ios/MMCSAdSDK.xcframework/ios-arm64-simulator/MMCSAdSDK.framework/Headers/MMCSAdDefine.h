//
//  MMCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define mMkAdvDataSourceFacebook   2 //FB 广告数据源
#define mMkAdvDataSourceAdmob      8 //Admob 广告数据源
#define mMkAdvDataSourceMopub      39//Mopub 广告数据源
#define mMkAdvDataSourceApplovin   20//applovin 广告数据源

#define mMkAdvDataSourceGDT        62//广点通 广告数据源
#define mMkAdvDataSourceBaidu      63//百度 广告数据源
#define mMkAdvDataSourceBU         64//头条 广告数据源
#define mMkAdvDataSourceABU         70//头条聚合 广告数据源
#define mMkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define mMkAdvDataSourcePangle     74//pangle 广告数据源
#define mMkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define mMkOnlineAdvTypeBanner                   1  //banner
#define mMkOnlineAdvTypeInterstitial             2  //全屏
#define mMkOnlineAdvTypeNative                   3 //native
#define mMkOnlineAdvTypeVideo                    4 //视频
#define mMkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define mMkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define mMkOnlineAdvTypeOpen                     8 //开屏
#define mMkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define mMkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define mMkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define mMkAdServerConfigError  -1 //服务器返回数据不正确
#define mMkAdLoadConfigFailed  -2 //广告加载失败


#define mMAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define mMkCSAdInstallDays @"mMkCSAdInstallDays"
#define mMkCSAdModule_key @"mMkCSAdModule_key_%@"
#define mMkCSNewAdModule_key @"mMkCSNewAdModule_key_%@"
#define mMkCSAdInstallTime @"mMkCSAdInstallTime"
#define mMkCSAdInstallHours @"mMkCSAdInstallHours"
#define mMkCSAdLastGetServerTime @"mMkCSAdLastRequestTime"
#define mMkCSAdloadTime 30

#define mMkCSLoadAdTimeOutNotification @"mMKCSLoadAdTimeOutNotification"
#define mMkCSLoadAdTimeOutNotificationKey @"mMKCSLoadAdTimeOutKey"

