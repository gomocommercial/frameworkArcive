//
//  MMCSAdLoadDataProtocol.h
//  MMCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "MMCSAdTypedef.h"

@class MMCSAdDataModel;
@class MMCSAdLoadBase;

@protocol MMCSAdLoadProtocol;

@protocol MMCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)mMonAdInfoFinish:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)mMonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)mMonAdFail:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
