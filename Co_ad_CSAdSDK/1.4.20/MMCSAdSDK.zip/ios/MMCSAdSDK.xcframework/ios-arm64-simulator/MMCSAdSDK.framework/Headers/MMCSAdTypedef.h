//
//  MMCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    MMCSAdLoadSuccess = 1,
    MMCSAdLoadFailure = -1,
    MMCSAdLoadTimeout = -2
} MMCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    MMCSAdPreloadSuccess = 1,
    //预加载失败
    MMCSAdPreloadFailure = -1,
    //重复加载
    MMCSAdPreloadRepeat = -2,
} MMCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    MMCSAdWillAppear,//即将出现
    MMCSAdDidAppear,//已经出现
    MMCSAdWillDisappear,//即将消失
    MMCSAdDidDisappear,//已经消失
    MMCSAdMuted,//静音广告
    MMCSAdWillLeaveApplication,//将要离开App

    MMCSAdVideoStart,//开始播放 常用于video
    MMCSAdVideoComplete,//播放完成 常用于video
    MMCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    MMCSAdVideoServerFail,//连接服务器成功，常用于fb video

    MMCSAdNativeDidDownload,//下载完成 常用于fb Native
    MMCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    MMCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    MMCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    MMCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    MMCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    MMCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    MMCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    MMCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    MMCSAdBUOpenDidAutoDimiss,//开屏自动消失
    MMCSAdBUOpenRenderSuccess, //渲染成功
    MMCSAdBUOpenRenderFail, //渲染失败
    MMCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    MMCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    MMCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    MMCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    MMCSAdDidPresentFullScreen,//插屏弹出全屏广告
    MMCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    MMCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    MMCSAdPlayerStatusStarted,//开始播放
    MMCSAdPlayerStatusPaused,//用户行为导致暂停
    MMCSAdPlayerStatusStoped,//播放停止
    MMCSAdPlayerStatusError,//播放出错
    MMCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    MMCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    MMCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    MMCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    MMCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    MMCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    MMCSAdRecordImpression, //广告曝光已记录
    MMCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    MMCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    MMCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    MMCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    MMCSAdABUOpenWillPresentFullScreen,
    MMCSAdABUOpenDidShowFailed,
    MMCSAdABUOpenWillDissmissFullScreen,
    MMCSAdABUOpenCountdownToZero,
    
    MMCSAdABUBannerWillPresentFullScreen,
    MMCSAdABUBannerWillDismissFullScreen,
    
    MMCSAdABURewardDidLoad,
    MMCSAdABURewardRenderFail,
    MMCSAdABURewardDidShowFailed,

} MMCSAdEvent;

typedef void (^MMCSAdLoadCompleteBlock)(MMCSAdLoadStatus adLoadStatus);

@class MMCSAdSetupParamsMaker;
@class MMCSAdSetupParams;

typedef MMCSAdSetupParamsMaker *(^MMCSAdStringInit)(NSString *);
typedef MMCSAdSetupParamsMaker *(^MMCSAdBoolInit)(BOOL);
typedef MMCSAdSetupParamsMaker *(^MMCSAdIntegerInit)(NSInteger);
typedef MMCSAdSetupParamsMaker *(^MMCSAdLongInit)(long);
typedef MMCSAdSetupParamsMaker *(^MMCSAdArrayInit)(NSArray *);
typedef MMCSAdSetupParams *(^MMCSAdMakeInit)(void);


@class MMCSAdDataModel;
typedef void (^MMCSAdRequestCompleteBlock)(NSMutableArray<MMCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^MMCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^MMCSAdPreloadCompleteBlock)(MMCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
