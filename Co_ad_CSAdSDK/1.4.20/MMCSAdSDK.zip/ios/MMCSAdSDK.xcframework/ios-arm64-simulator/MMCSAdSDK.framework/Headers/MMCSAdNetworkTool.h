//
//  MMCSAdNetworkTool.h
//  MMCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "MMCSAdDataModel.h"
#import "MMCSAdTypedef.h"
#import "MMCSNewStoreLiteRequestTool.h"
#import "NSString+MMCSGenerateHash.h"

@interface MMCSAdNetworkTool : NSObject

+ (MMCSAdNetworkTool *)shared;
@property(nonatomic, copy) MMCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)mMrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(MMCSAdRequestCompleteBlock)complete;

- (void)mMsetCDay:(void(^ _Nullable)(bool success))handle;
@end
