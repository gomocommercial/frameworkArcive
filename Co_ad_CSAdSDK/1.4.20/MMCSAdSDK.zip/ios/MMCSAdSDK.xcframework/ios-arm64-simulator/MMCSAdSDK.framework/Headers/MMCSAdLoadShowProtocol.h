//
//  MMCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MMCSAdTypedef.h"

@class MMCSAdLoadBase;

@protocol MMCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MMCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mMonAdShowed:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)mMonAdClicked:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mMonAdClosed:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mMonAdVideoCompletePlaying:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)mMonAdVideoGotReward:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload;
-(void)mMonAdDidPayRevenue:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)mMonAdDidGetEcpm:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)mMonAdShowFail:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mMonAdOtherEvent:(MMCSAdLoadBase<MMCSAdLoadProtocol> *)adload event:(MMCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
