//
//  MMCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MMCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MMCSAdLoadNative : MMCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
