//
//  MoveCashCSAdLoadDataProtocol.h
//  MoveCashCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "MoveCashCSAdTypedef.h"

@class MoveCashCSAdDataModel;
@class MoveCashCSAdLoadBase;

@protocol MoveCashCSAdLoadProtocol;

@protocol MoveCashCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)moveCashonAdInfoFinish:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)moveCashonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)moveCashonAdFail:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
