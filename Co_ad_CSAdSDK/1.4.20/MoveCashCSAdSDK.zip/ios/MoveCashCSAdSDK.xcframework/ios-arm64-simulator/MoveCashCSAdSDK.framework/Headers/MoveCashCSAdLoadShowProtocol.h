//
//  MoveCashCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MoveCashCSAdTypedef.h"

@class MoveCashCSAdLoadBase;

@protocol MoveCashCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MoveCashCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)moveCashonAdShowed:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)moveCashonAdClicked:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)moveCashonAdClosed:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)moveCashonAdVideoCompletePlaying:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)moveCashonAdVideoGotReward:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload;
-(void)moveCashonAdDidPayRevenue:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)moveCashonAdDidGetEcpm:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)moveCashonAdShowFail:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)moveCashonAdOtherEvent:(MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload event:(MoveCashCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
