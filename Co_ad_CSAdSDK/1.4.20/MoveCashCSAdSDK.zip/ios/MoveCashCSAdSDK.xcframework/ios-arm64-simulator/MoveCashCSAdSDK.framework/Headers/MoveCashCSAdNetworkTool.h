//
//  MoveCashCSAdNetworkTool.h
//  MoveCashCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "MoveCashCSAdDataModel.h"
#import "MoveCashCSAdTypedef.h"
#import "MoveCashCSNewStoreLiteRequestTool.h"
#import "NSString+MoveCashCSGenerateHash.h"

@interface MoveCashCSAdNetworkTool : NSObject

+ (MoveCashCSAdNetworkTool *)shared;
@property(nonatomic, copy) MoveCashCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)moveCashrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(MoveCashCSAdRequestCompleteBlock)complete;

- (void)moveCashsetCDay:(void(^ _Nullable)(bool success))handle;
@end
