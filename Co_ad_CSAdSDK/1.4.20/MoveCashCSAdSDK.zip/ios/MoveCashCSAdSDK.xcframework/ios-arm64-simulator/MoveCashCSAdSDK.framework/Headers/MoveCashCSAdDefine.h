//
//  MoveCashCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define moveCashkAdvDataSourceFacebook   2 //FB 广告数据源
#define moveCashkAdvDataSourceAdmob      8 //Admob 广告数据源
#define moveCashkAdvDataSourceMopub      39//Mopub 广告数据源
#define moveCashkAdvDataSourceApplovin   20//applovin 广告数据源

#define moveCashkAdvDataSourceGDT        62//广点通 广告数据源
#define moveCashkAdvDataSourceBaidu      63//百度 广告数据源
#define moveCashkAdvDataSourceBU         64//头条 广告数据源
#define moveCashkAdvDataSourceABU         70//头条聚合 广告数据源
#define moveCashkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define moveCashkAdvDataSourcePangle     74//pangle 广告数据源
#define moveCashkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define moveCashkOnlineAdvTypeBanner                   1  //banner
#define moveCashkOnlineAdvTypeInterstitial             2  //全屏
#define moveCashkOnlineAdvTypeNative                   3 //native
#define moveCashkOnlineAdvTypeVideo                    4 //视频
#define moveCashkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define moveCashkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define moveCashkOnlineAdvTypeOpen                     8 //开屏
#define moveCashkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define moveCashkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define moveCashkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define moveCashkAdServerConfigError  -1 //服务器返回数据不正确
#define moveCashkAdLoadConfigFailed  -2 //广告加载失败


#define moveCashAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define moveCashkCSAdInstallDays @"moveCashkCSAdInstallDays"
#define moveCashkCSAdModule_key @"moveCashkCSAdModule_key_%@"
#define moveCashkCSNewAdModule_key @"moveCashkCSNewAdModule_key_%@"
#define moveCashkCSAdInstallTime @"moveCashkCSAdInstallTime"
#define moveCashkCSAdInstallHours @"moveCashkCSAdInstallHours"
#define moveCashkCSAdLastGetServerTime @"moveCashkCSAdLastRequestTime"
#define moveCashkCSAdloadTime 30

#define moveCashkCSLoadAdTimeOutNotification @"moveCashKCSLoadAdTimeOutNotification"
#define moveCashkCSLoadAdTimeOutNotificationKey @"moveCashKCSLoadAdTimeOutKey"

