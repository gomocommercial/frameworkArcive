//
//  MoveCashCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    MoveCashCSAdLoadSuccess = 1,
    MoveCashCSAdLoadFailure = -1,
    MoveCashCSAdLoadTimeout = -2
} MoveCashCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    MoveCashCSAdPreloadSuccess = 1,
    //预加载失败
    MoveCashCSAdPreloadFailure = -1,
    //重复加载
    MoveCashCSAdPreloadRepeat = -2,
} MoveCashCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    MoveCashCSAdWillAppear,//即将出现
    MoveCashCSAdDidAppear,//已经出现
    MoveCashCSAdWillDisappear,//即将消失
    MoveCashCSAdDidDisappear,//已经消失
    MoveCashCSAdMuted,//静音广告
    MoveCashCSAdWillLeaveApplication,//将要离开App

    MoveCashCSAdVideoStart,//开始播放 常用于video
    MoveCashCSAdVideoComplete,//播放完成 常用于video
    MoveCashCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    MoveCashCSAdVideoServerFail,//连接服务器成功，常用于fb video

    MoveCashCSAdNativeDidDownload,//下载完成 常用于fb Native
    MoveCashCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    MoveCashCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    MoveCashCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    MoveCashCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    MoveCashCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    MoveCashCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    MoveCashCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    MoveCashCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    MoveCashCSAdBUOpenDidAutoDimiss,//开屏自动消失
    MoveCashCSAdBUOpenRenderSuccess, //渲染成功
    MoveCashCSAdBUOpenRenderFail, //渲染失败
    MoveCashCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    MoveCashCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    MoveCashCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    MoveCashCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    MoveCashCSAdDidPresentFullScreen,//插屏弹出全屏广告
    MoveCashCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    MoveCashCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    MoveCashCSAdPlayerStatusStarted,//开始播放
    MoveCashCSAdPlayerStatusPaused,//用户行为导致暂停
    MoveCashCSAdPlayerStatusStoped,//播放停止
    MoveCashCSAdPlayerStatusError,//播放出错
    MoveCashCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    MoveCashCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    MoveCashCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    MoveCashCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    MoveCashCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    MoveCashCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    MoveCashCSAdRecordImpression, //广告曝光已记录
    MoveCashCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    MoveCashCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    MoveCashCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    MoveCashCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    MoveCashCSAdABUOpenWillPresentFullScreen,
    MoveCashCSAdABUOpenDidShowFailed,
    MoveCashCSAdABUOpenWillDissmissFullScreen,
    MoveCashCSAdABUOpenCountdownToZero,
    
    MoveCashCSAdABUBannerWillPresentFullScreen,
    MoveCashCSAdABUBannerWillDismissFullScreen,
    
    MoveCashCSAdABURewardDidLoad,
    MoveCashCSAdABURewardRenderFail,
    MoveCashCSAdABURewardDidShowFailed,

} MoveCashCSAdEvent;

typedef void (^MoveCashCSAdLoadCompleteBlock)(MoveCashCSAdLoadStatus adLoadStatus);

@class MoveCashCSAdSetupParamsMaker;
@class MoveCashCSAdSetupParams;

typedef MoveCashCSAdSetupParamsMaker *(^MoveCashCSAdStringInit)(NSString *);
typedef MoveCashCSAdSetupParamsMaker *(^MoveCashCSAdBoolInit)(BOOL);
typedef MoveCashCSAdSetupParamsMaker *(^MoveCashCSAdIntegerInit)(NSInteger);
typedef MoveCashCSAdSetupParamsMaker *(^MoveCashCSAdLongInit)(long);
typedef MoveCashCSAdSetupParamsMaker *(^MoveCashCSAdArrayInit)(NSArray *);
typedef MoveCashCSAdSetupParams *(^MoveCashCSAdMakeInit)(void);


@class MoveCashCSAdDataModel;
typedef void (^MoveCashCSAdRequestCompleteBlock)(NSMutableArray<MoveCashCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^MoveCashCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^MoveCashCSAdPreloadCompleteBlock)(MoveCashCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
