//
//  MoveCashCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "MoveCashCSAdLoadBase.h"
#import "MoveCashCSAdDataModel.h"
#import "MoveCashCSAdLoadProtocol.h"
#import "MoveCashCSAdLoadDataProtocol.h"
#import "MoveCashCSAdLoadShowProtocol.h"
#import "MoveCashCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface MoveCashCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)moveCashsetupByBlock:(void (^ _Nonnull)(MoveCashCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)moveCashloadAd:(NSString *)moduleId delegate:(id<MoveCashCSAdLoadDataProtocol>)delegate;

+ (void)moveCashloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<MoveCashCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)moveCashadShowStatistic:(MoveCashCSAdDataModel *)dataModel adload:(nonnull MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)moveCashadClickStatistic:(MoveCashCSAdDataModel *)dataModel adload:(nonnull MoveCashCSAdLoadBase<MoveCashCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)moveCashaddCustomFecher:(Class<MoveCashCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
