//
//  MoveCashCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MoveCashCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MoveCashCSAdLoadInterstitial : MoveCashCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
