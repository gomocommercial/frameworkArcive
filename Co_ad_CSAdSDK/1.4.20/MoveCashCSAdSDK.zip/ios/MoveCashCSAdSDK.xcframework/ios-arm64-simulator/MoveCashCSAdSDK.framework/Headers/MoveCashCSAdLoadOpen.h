//
//  MoveCashCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "MoveCashCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MoveCashCSAdLoadOpen : MoveCashCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
