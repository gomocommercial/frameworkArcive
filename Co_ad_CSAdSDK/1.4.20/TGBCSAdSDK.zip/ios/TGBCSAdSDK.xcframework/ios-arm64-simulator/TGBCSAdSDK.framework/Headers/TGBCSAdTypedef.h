//
//  TGBCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TGBCSAdLoadSuccess = 1,
    TGBCSAdLoadFailure = -1,
    TGBCSAdLoadTimeout = -2
} TGBCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TGBCSAdPreloadSuccess = 1,
    //预加载失败
    TGBCSAdPreloadFailure = -1,
    //重复加载
    TGBCSAdPreloadRepeat = -2,
} TGBCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TGBCSAdWillAppear,//即将出现
    TGBCSAdDidAppear,//已经出现
    TGBCSAdWillDisappear,//即将消失
    TGBCSAdDidDisappear,//已经消失
    TGBCSAdMuted,//静音广告
    TGBCSAdWillLeaveApplication,//将要离开App

    TGBCSAdVideoStart,//开始播放 常用于video
    TGBCSAdVideoComplete,//播放完成 常用于video
    TGBCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TGBCSAdVideoServerFail,//连接服务器成功，常用于fb video

    TGBCSAdNativeDidDownload,//下载完成 常用于fb Native
    TGBCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TGBCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    TGBCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    TGBCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    TGBCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    TGBCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    TGBCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    TGBCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    TGBCSAdBUOpenDidAutoDimiss,//开屏自动消失
    TGBCSAdBUOpenRenderSuccess, //渲染成功
    TGBCSAdBUOpenRenderFail, //渲染失败
    TGBCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    TGBCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    TGBCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    TGBCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    TGBCSAdDidPresentFullScreen,//插屏弹出全屏广告
    TGBCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    TGBCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    TGBCSAdPlayerStatusStarted,//开始播放
    TGBCSAdPlayerStatusPaused,//用户行为导致暂停
    TGBCSAdPlayerStatusStoped,//播放停止
    TGBCSAdPlayerStatusError,//播放出错
    TGBCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    TGBCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    TGBCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    TGBCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    TGBCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    TGBCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    TGBCSAdRecordImpression, //广告曝光已记录
    TGBCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    TGBCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    TGBCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    TGBCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    TGBCSAdABUOpenWillPresentFullScreen,
    TGBCSAdABUOpenDidShowFailed,
    TGBCSAdABUOpenWillDissmissFullScreen,
    TGBCSAdABUOpenCountdownToZero,
    
    TGBCSAdABUBannerWillPresentFullScreen,
    TGBCSAdABUBannerWillDismissFullScreen,
    
    TGBCSAdABURewardDidLoad,
    TGBCSAdABURewardRenderFail,
    TGBCSAdABURewardDidShowFailed,

} TGBCSAdEvent;

typedef void (^TGBCSAdLoadCompleteBlock)(TGBCSAdLoadStatus adLoadStatus);

@class TGBCSAdSetupParamsMaker;
@class TGBCSAdSetupParams;

typedef TGBCSAdSetupParamsMaker *(^TGBCSAdStringInit)(NSString *);
typedef TGBCSAdSetupParamsMaker *(^TGBCSAdBoolInit)(BOOL);
typedef TGBCSAdSetupParamsMaker *(^TGBCSAdIntegerInit)(NSInteger);
typedef TGBCSAdSetupParamsMaker *(^TGBCSAdLongInit)(long);
typedef TGBCSAdSetupParamsMaker *(^TGBCSAdArrayInit)(NSArray *);
typedef TGBCSAdSetupParams *(^TGBCSAdMakeInit)(void);


@class TGBCSAdDataModel;
typedef void (^TGBCSAdRequestCompleteBlock)(NSMutableArray<TGBCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TGBCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TGBCSAdPreloadCompleteBlock)(TGBCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
