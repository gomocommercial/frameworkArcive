//
//  TGBCSAdNetworkTool.h
//  TGBCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "TGBCSAdDataModel.h"
#import "TGBCSAdTypedef.h"
#import "TGBCSNewStoreLiteRequestTool.h"
#import "NSString+TGBCSGenerateHash.h"

@interface TGBCSAdNetworkTool : NSObject

+ (TGBCSAdNetworkTool *)shared;
@property(nonatomic, copy) TGBCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)tGBrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(TGBCSAdRequestCompleteBlock)complete;

- (void)tGBsetCDay:(void(^ _Nullable)(bool success))handle;
@end
