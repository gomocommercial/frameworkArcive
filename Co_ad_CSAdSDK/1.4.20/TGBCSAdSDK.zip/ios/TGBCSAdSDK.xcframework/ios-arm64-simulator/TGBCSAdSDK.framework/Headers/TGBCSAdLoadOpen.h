//
//  TGBCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "TGBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadOpen : TGBCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
