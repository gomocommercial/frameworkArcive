//
//  TGBCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "TGBCSAdTypedef.h"

@class TGBCSAdLoadBase;

@protocol TGBCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol TGBCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)tGBonAdShowed:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)tGBonAdClicked:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)tGBonAdClosed:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)tGBonAdVideoCompletePlaying:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)tGBonAdVideoGotReward:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload;
-(void)tGBonAdDidPayRevenue:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)tGBonAdDidGetEcpm:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)tGBonAdShowFail:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)tGBonAdOtherEvent:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload event:(TGBCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
