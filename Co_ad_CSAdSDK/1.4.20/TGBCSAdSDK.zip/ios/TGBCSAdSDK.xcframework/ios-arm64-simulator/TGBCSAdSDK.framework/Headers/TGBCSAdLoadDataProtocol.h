//
//  TGBCSAdLoadDataProtocol.h
//  TGBCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "TGBCSAdTypedef.h"

@class TGBCSAdDataModel;
@class TGBCSAdLoadBase;

@protocol TGBCSAdLoadProtocol;

@protocol TGBCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)tGBonAdInfoFinish:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)tGBonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)tGBonAdFail:(TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
