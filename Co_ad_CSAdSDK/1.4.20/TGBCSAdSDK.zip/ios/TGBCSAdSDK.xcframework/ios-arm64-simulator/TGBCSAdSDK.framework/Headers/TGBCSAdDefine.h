//
//  TGBCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tGBkAdvDataSourceFacebook   2 //FB 广告数据源
#define tGBkAdvDataSourceAdmob      8 //Admob 广告数据源
#define tGBkAdvDataSourceMopub      39//Mopub 广告数据源
#define tGBkAdvDataSourceApplovin   20//applovin 广告数据源

#define tGBkAdvDataSourceGDT        62//广点通 广告数据源
#define tGBkAdvDataSourceBaidu      63//百度 广告数据源
#define tGBkAdvDataSourceBU         64//头条 广告数据源
#define tGBkAdvDataSourceABU         70//头条聚合 广告数据源
#define tGBkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define tGBkAdvDataSourcePangle     74//pangle 广告数据源
#define tGBkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define tGBkOnlineAdvTypeBanner                   1  //banner
#define tGBkOnlineAdvTypeInterstitial             2  //全屏
#define tGBkOnlineAdvTypeNative                   3 //native
#define tGBkOnlineAdvTypeVideo                    4 //视频
#define tGBkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define tGBkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define tGBkOnlineAdvTypeOpen                     8 //开屏
#define tGBkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define tGBkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define tGBkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define tGBkAdServerConfigError  -1 //服务器返回数据不正确
#define tGBkAdLoadConfigFailed  -2 //广告加载失败


#define tGBAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tGBkCSAdInstallDays @"tGBkCSAdInstallDays"
#define tGBkCSAdModule_key @"tGBkCSAdModule_key_%@"
#define tGBkCSNewAdModule_key @"tGBkCSNewAdModule_key_%@"
#define tGBkCSAdInstallTime @"tGBkCSAdInstallTime"
#define tGBkCSAdInstallHours @"tGBkCSAdInstallHours"
#define tGBkCSAdLastGetServerTime @"tGBkCSAdLastRequestTime"
#define tGBkCSAdloadTime 30

#define tGBkCSLoadAdTimeOutNotification @"tGBKCSLoadAdTimeOutNotification"
#define tGBkCSLoadAdTimeOutNotificationKey @"tGBKCSLoadAdTimeOutKey"

