//
//  TGBCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TGBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadNative : TGBCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
