//
//  TGBCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "TGBCSAdLoadBase.h"
#import "TGBCSAdDataModel.h"
#import "TGBCSAdLoadProtocol.h"
#import "TGBCSAdLoadDataProtocol.h"
#import "TGBCSAdLoadShowProtocol.h"
#import "TGBCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)tGBsetupByBlock:(void (^ _Nonnull)(TGBCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)tGBloadAd:(NSString *)moduleId delegate:(id<TGBCSAdLoadDataProtocol>)delegate;

+ (void)tGBloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<TGBCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)tGBadShowStatistic:(TGBCSAdDataModel *)dataModel adload:(nonnull TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)tGBadClickStatistic:(TGBCSAdDataModel *)dataModel adload:(nonnull TGBCSAdLoadBase<TGBCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)tGBaddCustomFecher:(Class<TGBCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
