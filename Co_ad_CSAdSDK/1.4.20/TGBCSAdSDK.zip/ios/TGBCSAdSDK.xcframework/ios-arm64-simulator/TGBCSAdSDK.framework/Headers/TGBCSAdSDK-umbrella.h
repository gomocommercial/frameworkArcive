#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TGBCSAdSDK.h"
#import "TGBCSAdPreload.h"
#import "TGBCSAdLoadDataProtocol.h"
#import "TGBCSAdLoadShowProtocol.h"
#import "TGBCSAdLoadProtocol.h"
#import "TGBCSAdLoadBase.h"
#import "TGBCSAdLoadInterstitial.h"
#import "TGBCSAdLoadNative.h"
#import "TGBCSAdLoadReward.h"
#import "TGBCSAdLoadOpen.h"
#import "TGBCSAdLoadBanner.h"
#import "TGBCSAdManager.h"
#import "TGBCSAdSetupParams.h"
#import "TGBCSAdSetupParamsMaker.h"
#import "TGBCSAdDefine.h"
#import "TGBCSAdTypedef.h"
#import "TGBCSAdStatistics.h"
#import "TGBCSAdDataModel.h"
#import "TGBCSAdNetworkTool.h"
#import "TGBCSNewStoreLiteRequestTool.h"
#import "NSString+TGBCSGenerateHash.h"

FOUNDATION_EXPORT double TGBCSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char TGBCSAdSDKVersionString[];

