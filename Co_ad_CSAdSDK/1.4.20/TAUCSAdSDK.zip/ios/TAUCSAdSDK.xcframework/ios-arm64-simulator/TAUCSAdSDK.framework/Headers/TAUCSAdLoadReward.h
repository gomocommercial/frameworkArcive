//
//  TAUCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TAUCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TAUCSAdLoadReward : TAUCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
