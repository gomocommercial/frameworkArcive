//
//  TAUCSAdStatistics.h
//  TAUCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "TAUCSAdDataModel.h"
#import "TAUCSAdTypedef.h"
#import "TAUCSAdLoadBase.h"
@interface TAUCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)tAUadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)tAUadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)tAUadRewardVideoCompleteStatistic:(TAUCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)tAUadShowStatistic:(TAUCSAdDataModel *)dataModel adload:(nonnull TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)tAUadClickStatistic:(TAUCSAdDataModel *)dataModel adload:(nonnull TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)tAUadUploadRevenueStatistic:(TAUCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
