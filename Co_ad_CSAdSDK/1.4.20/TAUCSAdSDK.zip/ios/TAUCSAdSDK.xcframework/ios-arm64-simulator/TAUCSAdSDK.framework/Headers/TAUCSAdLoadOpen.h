//
//  TAUCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "TAUCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TAUCSAdLoadOpen : TAUCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
