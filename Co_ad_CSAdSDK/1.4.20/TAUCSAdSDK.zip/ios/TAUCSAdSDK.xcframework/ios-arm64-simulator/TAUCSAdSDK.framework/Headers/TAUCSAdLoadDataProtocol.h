//
//  TAUCSAdLoadDataProtocol.h
//  TAUCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "TAUCSAdTypedef.h"

@class TAUCSAdDataModel;
@class TAUCSAdLoadBase;

@protocol TAUCSAdLoadProtocol;

@protocol TAUCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)tAUonAdInfoFinish:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)tAUonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)tAUonAdFail:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
