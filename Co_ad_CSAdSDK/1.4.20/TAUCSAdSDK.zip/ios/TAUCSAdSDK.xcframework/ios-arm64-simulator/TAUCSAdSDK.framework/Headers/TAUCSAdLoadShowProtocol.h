//
//  TAUCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "TAUCSAdTypedef.h"

@class TAUCSAdLoadBase;

@protocol TAUCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol TAUCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)tAUonAdShowed:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)tAUonAdClicked:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)tAUonAdClosed:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)tAUonAdVideoCompletePlaying:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)tAUonAdVideoGotReward:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;
-(void)tAUonAdDidPayRevenue:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)tAUonAdDidGetEcpm:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)tAUonAdShowFail:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)tAUonAdOtherEvent:(TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload event:(TAUCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
