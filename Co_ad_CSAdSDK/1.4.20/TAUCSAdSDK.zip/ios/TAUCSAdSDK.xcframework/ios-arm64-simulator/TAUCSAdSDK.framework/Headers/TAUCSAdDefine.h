//
//  TAUCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tAUkAdvDataSourceFacebook   2 //FB 广告数据源
#define tAUkAdvDataSourceAdmob      8 //Admob 广告数据源
#define tAUkAdvDataSourceMopub      39//Mopub 广告数据源
#define tAUkAdvDataSourceApplovin   20//applovin 广告数据源

#define tAUkAdvDataSourceGDT        62//广点通 广告数据源
#define tAUkAdvDataSourceBaidu      63//百度 广告数据源
#define tAUkAdvDataSourceBU         64//头条 广告数据源
#define tAUkAdvDataSourceABU         70//头条聚合 广告数据源
#define tAUkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define tAUkAdvDataSourcePangle     74//pangle 广告数据源
#define tAUkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define tAUkOnlineAdvTypeBanner                   1  //banner
#define tAUkOnlineAdvTypeInterstitial             2  //全屏
#define tAUkOnlineAdvTypeNative                   3 //native
#define tAUkOnlineAdvTypeVideo                    4 //视频
#define tAUkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define tAUkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define tAUkOnlineAdvTypeOpen                     8 //开屏
#define tAUkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define tAUkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define tAUkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define tAUkAdServerConfigError  -1 //服务器返回数据不正确
#define tAUkAdLoadConfigFailed  -2 //广告加载失败


#define tAUAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tAUkCSAdInstallDays @"tAUkCSAdInstallDays"
#define tAUkCSAdModule_key @"tAUkCSAdModule_key_%@"
#define tAUkCSNewAdModule_key @"tAUkCSNewAdModule_key_%@"
#define tAUkCSAdInstallTime @"tAUkCSAdInstallTime"
#define tAUkCSAdInstallHours @"tAUkCSAdInstallHours"
#define tAUkCSAdLastGetServerTime @"tAUkCSAdLastRequestTime"
#define tAUkCSAdloadTime 30

#define tAUkCSLoadAdTimeOutNotification @"tAUKCSLoadAdTimeOutNotification"
#define tAUkCSLoadAdTimeOutNotificationKey @"tAUKCSLoadAdTimeOutKey"

