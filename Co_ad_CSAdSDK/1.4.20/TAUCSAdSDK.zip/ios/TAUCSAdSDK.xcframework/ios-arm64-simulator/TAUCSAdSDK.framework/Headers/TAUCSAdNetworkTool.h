//
//  TAUCSAdNetworkTool.h
//  TAUCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "TAUCSAdDataModel.h"
#import "TAUCSAdTypedef.h"
#import "TAUCSNewStoreLiteRequestTool.h"
#import "NSString+TAUCSGenerateHash.h"

@interface TAUCSAdNetworkTool : NSObject

+ (TAUCSAdNetworkTool *)shared;
@property(nonatomic, copy) TAUCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)tAUrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(TAUCSAdRequestCompleteBlock)complete;

- (void)tAUsetCDay:(void(^ _Nullable)(bool success))handle;
@end
