//
//  TAUCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TAUCSAdLoadSuccess = 1,
    TAUCSAdLoadFailure = -1,
    TAUCSAdLoadTimeout = -2
} TAUCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TAUCSAdPreloadSuccess = 1,
    //预加载失败
    TAUCSAdPreloadFailure = -1,
    //重复加载
    TAUCSAdPreloadRepeat = -2,
} TAUCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TAUCSAdWillAppear,//即将出现
    TAUCSAdDidAppear,//已经出现
    TAUCSAdWillDisappear,//即将消失
    TAUCSAdDidDisappear,//已经消失
    TAUCSAdMuted,//静音广告
    TAUCSAdWillLeaveApplication,//将要离开App

    TAUCSAdVideoStart,//开始播放 常用于video
    TAUCSAdVideoComplete,//播放完成 常用于video
    TAUCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TAUCSAdVideoServerFail,//连接服务器成功，常用于fb video

    TAUCSAdNativeDidDownload,//下载完成 常用于fb Native
    TAUCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TAUCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    TAUCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    TAUCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    TAUCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    TAUCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    TAUCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    TAUCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    TAUCSAdBUOpenDidAutoDimiss,//开屏自动消失
    TAUCSAdBUOpenRenderSuccess, //渲染成功
    TAUCSAdBUOpenRenderFail, //渲染失败
    TAUCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    TAUCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    TAUCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    TAUCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    TAUCSAdDidPresentFullScreen,//插屏弹出全屏广告
    TAUCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    TAUCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    TAUCSAdPlayerStatusStarted,//开始播放
    TAUCSAdPlayerStatusPaused,//用户行为导致暂停
    TAUCSAdPlayerStatusStoped,//播放停止
    TAUCSAdPlayerStatusError,//播放出错
    TAUCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    TAUCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    TAUCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    TAUCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    TAUCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    TAUCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    TAUCSAdRecordImpression, //广告曝光已记录
    TAUCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    TAUCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    TAUCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    TAUCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    TAUCSAdABUOpenWillPresentFullScreen,
    TAUCSAdABUOpenDidShowFailed,
    TAUCSAdABUOpenWillDissmissFullScreen,
    TAUCSAdABUOpenCountdownToZero,
    
    TAUCSAdABUBannerWillPresentFullScreen,
    TAUCSAdABUBannerWillDismissFullScreen,
    
    TAUCSAdABURewardDidLoad,
    TAUCSAdABURewardRenderFail,
    TAUCSAdABURewardDidShowFailed,

} TAUCSAdEvent;

typedef void (^TAUCSAdLoadCompleteBlock)(TAUCSAdLoadStatus adLoadStatus);

@class TAUCSAdSetupParamsMaker;
@class TAUCSAdSetupParams;

typedef TAUCSAdSetupParamsMaker *(^TAUCSAdStringInit)(NSString *);
typedef TAUCSAdSetupParamsMaker *(^TAUCSAdBoolInit)(BOOL);
typedef TAUCSAdSetupParamsMaker *(^TAUCSAdIntegerInit)(NSInteger);
typedef TAUCSAdSetupParamsMaker *(^TAUCSAdLongInit)(long);
typedef TAUCSAdSetupParamsMaker *(^TAUCSAdArrayInit)(NSArray *);
typedef TAUCSAdSetupParams *(^TAUCSAdMakeInit)(void);


@class TAUCSAdDataModel;
typedef void (^TAUCSAdRequestCompleteBlock)(NSMutableArray<TAUCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TAUCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TAUCSAdPreloadCompleteBlock)(TAUCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
