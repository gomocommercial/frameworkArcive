//
//  TAUCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "TAUCSAdLoadBase.h"
#import "TAUCSAdDataModel.h"
#import "TAUCSAdLoadProtocol.h"
#import "TAUCSAdLoadDataProtocol.h"
#import "TAUCSAdLoadShowProtocol.h"
#import "TAUCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface TAUCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)tAUsetupByBlock:(void (^ _Nonnull)(TAUCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)tAUloadAd:(NSString *)moduleId delegate:(id<TAUCSAdLoadDataProtocol>)delegate;

+ (void)tAUloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<TAUCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)tAUadShowStatistic:(TAUCSAdDataModel *)dataModel adload:(nonnull TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)tAUadClickStatistic:(TAUCSAdDataModel *)dataModel adload:(nonnull TAUCSAdLoadBase<TAUCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)tAUaddCustomFecher:(Class<TAUCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
