//
//  TIVCSAdLoadDataProtocol.h
//  TIVCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "TIVCSAdTypedef.h"

@class TIVCSAdDataModel;
@class TIVCSAdLoadBase;

@protocol TIVCSAdLoadProtocol;

@protocol TIVCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)tIVonAdInfoFinish:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)tIVonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)tIVonAdFail:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
