//
//  TIVCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "TIVCSAdLoadBase.h"
#import "TIVCSAdDataModel.h"
#import "TIVCSAdLoadProtocol.h"
#import "TIVCSAdLoadDataProtocol.h"
#import "TIVCSAdLoadShowProtocol.h"
#import "TIVCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)tIVsetupByBlock:(void (^ _Nonnull)(TIVCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)tIVloadAd:(NSString *)moduleId delegate:(id<TIVCSAdLoadDataProtocol>)delegate;

+ (void)tIVloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<TIVCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)tIVadShowStatistic:(TIVCSAdDataModel *)dataModel adload:(nonnull TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)tIVadClickStatistic:(TIVCSAdDataModel *)dataModel adload:(nonnull TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)tIVaddCustomFecher:(Class<TIVCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
