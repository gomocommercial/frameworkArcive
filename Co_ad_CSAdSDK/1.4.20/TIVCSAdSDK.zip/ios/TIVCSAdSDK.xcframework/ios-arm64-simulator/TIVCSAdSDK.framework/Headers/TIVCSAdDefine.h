//
//  TIVCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tIVkAdvDataSourceFacebook   2 //FB 广告数据源
#define tIVkAdvDataSourceAdmob      8 //Admob 广告数据源
#define tIVkAdvDataSourceMopub      39//Mopub 广告数据源
#define tIVkAdvDataSourceApplovin   20//applovin 广告数据源

#define tIVkAdvDataSourceGDT        62//广点通 广告数据源
#define tIVkAdvDataSourceBaidu      63//百度 广告数据源
#define tIVkAdvDataSourceBU         64//头条 广告数据源
#define tIVkAdvDataSourceABU         70//头条聚合 广告数据源
#define tIVkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define tIVkAdvDataSourcePangle     74//pangle 广告数据源
#define tIVkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define tIVkOnlineAdvTypeBanner                   1  //banner
#define tIVkOnlineAdvTypeInterstitial             2  //全屏
#define tIVkOnlineAdvTypeNative                   3 //native
#define tIVkOnlineAdvTypeVideo                    4 //视频
#define tIVkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define tIVkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define tIVkOnlineAdvTypeOpen                     8 //开屏
#define tIVkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define tIVkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define tIVkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define tIVkAdServerConfigError  -1 //服务器返回数据不正确
#define tIVkAdLoadConfigFailed  -2 //广告加载失败


#define tIVAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tIVkCSAdInstallDays @"tIVkCSAdInstallDays"
#define tIVkCSAdModule_key @"tIVkCSAdModule_key_%@"
#define tIVkCSNewAdModule_key @"tIVkCSNewAdModule_key_%@"
#define tIVkCSAdInstallTime @"tIVkCSAdInstallTime"
#define tIVkCSAdInstallHours @"tIVkCSAdInstallHours"
#define tIVkCSAdLastGetServerTime @"tIVkCSAdLastRequestTime"
#define tIVkCSAdloadTime 30

#define tIVkCSLoadAdTimeOutNotification @"tIVKCSLoadAdTimeOutNotification"
#define tIVkCSLoadAdTimeOutNotificationKey @"tIVKCSLoadAdTimeOutKey"

