//
//  TIVCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TIVCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdLoadInterstitial : TIVCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
