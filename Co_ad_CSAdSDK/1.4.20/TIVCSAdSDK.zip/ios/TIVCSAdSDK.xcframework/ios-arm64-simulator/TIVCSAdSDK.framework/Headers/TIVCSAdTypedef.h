//
//  TIVCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TIVCSAdLoadSuccess = 1,
    TIVCSAdLoadFailure = -1,
    TIVCSAdLoadTimeout = -2
} TIVCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TIVCSAdPreloadSuccess = 1,
    //预加载失败
    TIVCSAdPreloadFailure = -1,
    //重复加载
    TIVCSAdPreloadRepeat = -2,
} TIVCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TIVCSAdWillAppear,//即将出现
    TIVCSAdDidAppear,//已经出现
    TIVCSAdWillDisappear,//即将消失
    TIVCSAdDidDisappear,//已经消失
    TIVCSAdMuted,//静音广告
    TIVCSAdWillLeaveApplication,//将要离开App

    TIVCSAdVideoStart,//开始播放 常用于video
    TIVCSAdVideoComplete,//播放完成 常用于video
    TIVCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TIVCSAdVideoServerFail,//连接服务器成功，常用于fb video

    TIVCSAdNativeDidDownload,//下载完成 常用于fb Native
    TIVCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TIVCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    TIVCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    TIVCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    TIVCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    TIVCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    TIVCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    TIVCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    TIVCSAdBUOpenDidAutoDimiss,//开屏自动消失
    TIVCSAdBUOpenRenderSuccess, //渲染成功
    TIVCSAdBUOpenRenderFail, //渲染失败
    TIVCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    TIVCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    TIVCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    TIVCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    TIVCSAdDidPresentFullScreen,//插屏弹出全屏广告
    TIVCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    TIVCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    TIVCSAdPlayerStatusStarted,//开始播放
    TIVCSAdPlayerStatusPaused,//用户行为导致暂停
    TIVCSAdPlayerStatusStoped,//播放停止
    TIVCSAdPlayerStatusError,//播放出错
    TIVCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    TIVCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    TIVCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    TIVCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    TIVCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    TIVCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    TIVCSAdRecordImpression, //广告曝光已记录
    TIVCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    TIVCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    TIVCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    TIVCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    TIVCSAdABUOpenWillPresentFullScreen,
    TIVCSAdABUOpenDidShowFailed,
    TIVCSAdABUOpenWillDissmissFullScreen,
    TIVCSAdABUOpenCountdownToZero,
    
    TIVCSAdABUBannerWillPresentFullScreen,
    TIVCSAdABUBannerWillDismissFullScreen,
    
    TIVCSAdABURewardDidLoad,
    TIVCSAdABURewardRenderFail,
    TIVCSAdABURewardDidShowFailed,

} TIVCSAdEvent;

typedef void (^TIVCSAdLoadCompleteBlock)(TIVCSAdLoadStatus adLoadStatus);

@class TIVCSAdSetupParamsMaker;
@class TIVCSAdSetupParams;

typedef TIVCSAdSetupParamsMaker *(^TIVCSAdStringInit)(NSString *);
typedef TIVCSAdSetupParamsMaker *(^TIVCSAdBoolInit)(BOOL);
typedef TIVCSAdSetupParamsMaker *(^TIVCSAdIntegerInit)(NSInteger);
typedef TIVCSAdSetupParamsMaker *(^TIVCSAdLongInit)(long);
typedef TIVCSAdSetupParamsMaker *(^TIVCSAdArrayInit)(NSArray *);
typedef TIVCSAdSetupParams *(^TIVCSAdMakeInit)(void);


@class TIVCSAdDataModel;
typedef void (^TIVCSAdRequestCompleteBlock)(NSMutableArray<TIVCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TIVCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TIVCSAdPreloadCompleteBlock)(TIVCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
