//
//  TIVCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "TIVCSAdTypedef.h"

@class TIVCSAdLoadBase;

@protocol TIVCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol TIVCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)tIVonAdShowed:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)tIVonAdClicked:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)tIVonAdClosed:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)tIVonAdVideoCompletePlaying:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)tIVonAdVideoGotReward:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload;
-(void)tIVonAdDidPayRevenue:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)tIVonAdDidGetEcpm:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)tIVonAdShowFail:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)tIVonAdOtherEvent:(TIVCSAdLoadBase<TIVCSAdLoadProtocol> *)adload event:(TIVCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
