//
//  TIVCSAdNetworkTool.h
//  TIVCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "TIVCSAdDataModel.h"
#import "TIVCSAdTypedef.h"
#import "TIVCSNewStoreLiteRequestTool.h"
#import "NSString+TIVCSGenerateHash.h"

@interface TIVCSAdNetworkTool : NSObject

+ (TIVCSAdNetworkTool *)shared;
@property(nonatomic, copy) TIVCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)tIVrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(TIVCSAdRequestCompleteBlock)complete;

- (void)tIVsetCDay:(void(^ _Nullable)(bool success))handle;
@end
