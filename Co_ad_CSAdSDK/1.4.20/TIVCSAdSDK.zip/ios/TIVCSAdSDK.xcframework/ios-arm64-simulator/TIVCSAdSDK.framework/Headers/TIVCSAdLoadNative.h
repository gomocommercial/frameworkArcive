//
//  TIVCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TIVCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdLoadNative : TIVCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
