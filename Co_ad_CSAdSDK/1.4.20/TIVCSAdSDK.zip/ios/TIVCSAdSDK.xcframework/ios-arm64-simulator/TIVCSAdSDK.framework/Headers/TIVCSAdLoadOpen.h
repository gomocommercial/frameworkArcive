//
//  TIVCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "TIVCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdLoadOpen : TIVCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
