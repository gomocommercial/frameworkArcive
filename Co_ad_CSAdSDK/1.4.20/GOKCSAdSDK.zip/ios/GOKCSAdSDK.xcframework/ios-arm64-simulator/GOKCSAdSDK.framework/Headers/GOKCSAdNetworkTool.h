//
//  GOKCSAdNetworkTool.h
//  GOKCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "GOKCSAdDataModel.h"
#import "GOKCSAdTypedef.h"
#import "GOKCSNewStoreLiteRequestTool.h"
#import "NSString+GOKCSGenerateHash.h"

@interface GOKCSAdNetworkTool : NSObject

+ (GOKCSAdNetworkTool *)shared;
@property(nonatomic, copy) GOKCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)gOKrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(GOKCSAdRequestCompleteBlock)complete;

- (void)gOKsetCDay:(void(^ _Nullable)(bool success))handle;
@end
