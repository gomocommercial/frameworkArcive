//
//  GOKCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "GOKCSAdLoadBase.h"
#import "GOKCSAdDataModel.h"
#import "GOKCSAdLoadProtocol.h"
#import "GOKCSAdLoadDataProtocol.h"
#import "GOKCSAdLoadShowProtocol.h"
#import "GOKCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)gOKsetupByBlock:(void (^ _Nonnull)(GOKCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)gOKloadAd:(NSString *)moduleId delegate:(id<GOKCSAdLoadDataProtocol>)delegate;

+ (void)gOKloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<GOKCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)gOKadShowStatistic:(GOKCSAdDataModel *)dataModel adload:(nonnull GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)gOKadClickStatistic:(GOKCSAdDataModel *)dataModel adload:(nonnull GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)gOKaddCustomFecher:(Class<GOKCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
