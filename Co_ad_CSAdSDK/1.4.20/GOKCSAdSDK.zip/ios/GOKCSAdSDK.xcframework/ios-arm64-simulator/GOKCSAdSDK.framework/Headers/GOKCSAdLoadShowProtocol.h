//
//  GOKCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "GOKCSAdTypedef.h"

@class GOKCSAdLoadBase;

@protocol GOKCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol GOKCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)gOKonAdShowed:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)gOKonAdClicked:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)gOKonAdClosed:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)gOKonAdVideoCompletePlaying:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)gOKonAdVideoGotReward:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload;
-(void)gOKonAdDidPayRevenue:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)gOKonAdDidGetEcpm:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)gOKonAdShowFail:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)gOKonAdOtherEvent:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload event:(GOKCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
