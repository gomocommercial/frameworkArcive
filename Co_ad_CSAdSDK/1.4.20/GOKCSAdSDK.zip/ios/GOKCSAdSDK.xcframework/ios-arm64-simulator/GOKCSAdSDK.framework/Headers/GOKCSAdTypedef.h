//
//  GOKCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    GOKCSAdLoadSuccess = 1,
    GOKCSAdLoadFailure = -1,
    GOKCSAdLoadTimeout = -2
} GOKCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    GOKCSAdPreloadSuccess = 1,
    //预加载失败
    GOKCSAdPreloadFailure = -1,
    //重复加载
    GOKCSAdPreloadRepeat = -2,
} GOKCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    GOKCSAdWillAppear,//即将出现
    GOKCSAdDidAppear,//已经出现
    GOKCSAdWillDisappear,//即将消失
    GOKCSAdDidDisappear,//已经消失
    GOKCSAdMuted,//静音广告
    GOKCSAdWillLeaveApplication,//将要离开App

    GOKCSAdVideoStart,//开始播放 常用于video
    GOKCSAdVideoComplete,//播放完成 常用于video
    GOKCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    GOKCSAdVideoServerFail,//连接服务器成功，常用于fb video

    GOKCSAdNativeDidDownload,//下载完成 常用于fb Native
    GOKCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    GOKCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    GOKCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    GOKCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    GOKCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    GOKCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    GOKCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    GOKCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    GOKCSAdBUOpenDidAutoDimiss,//开屏自动消失
    GOKCSAdBUOpenRenderSuccess, //渲染成功
    GOKCSAdBUOpenRenderFail, //渲染失败
    GOKCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    GOKCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    GOKCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    GOKCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    GOKCSAdDidPresentFullScreen,//插屏弹出全屏广告
    GOKCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    GOKCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    GOKCSAdPlayerStatusStarted,//开始播放
    GOKCSAdPlayerStatusPaused,//用户行为导致暂停
    GOKCSAdPlayerStatusStoped,//播放停止
    GOKCSAdPlayerStatusError,//播放出错
    GOKCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    GOKCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    GOKCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    GOKCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    GOKCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    GOKCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    GOKCSAdRecordImpression, //广告曝光已记录
    GOKCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    GOKCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    GOKCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    GOKCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    GOKCSAdABUOpenWillPresentFullScreen,
    GOKCSAdABUOpenDidShowFailed,
    GOKCSAdABUOpenWillDissmissFullScreen,
    GOKCSAdABUOpenCountdownToZero,
    
    GOKCSAdABUBannerWillPresentFullScreen,
    GOKCSAdABUBannerWillDismissFullScreen,
    
    GOKCSAdABURewardDidLoad,
    GOKCSAdABURewardRenderFail,
    GOKCSAdABURewardDidShowFailed,

} GOKCSAdEvent;

typedef void (^GOKCSAdLoadCompleteBlock)(GOKCSAdLoadStatus adLoadStatus);

@class GOKCSAdSetupParamsMaker;
@class GOKCSAdSetupParams;

typedef GOKCSAdSetupParamsMaker *(^GOKCSAdStringInit)(NSString *);
typedef GOKCSAdSetupParamsMaker *(^GOKCSAdBoolInit)(BOOL);
typedef GOKCSAdSetupParamsMaker *(^GOKCSAdIntegerInit)(NSInteger);
typedef GOKCSAdSetupParamsMaker *(^GOKCSAdLongInit)(long);
typedef GOKCSAdSetupParamsMaker *(^GOKCSAdArrayInit)(NSArray *);
typedef GOKCSAdSetupParams *(^GOKCSAdMakeInit)(void);


@class GOKCSAdDataModel;
typedef void (^GOKCSAdRequestCompleteBlock)(NSMutableArray<GOKCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^GOKCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^GOKCSAdPreloadCompleteBlock)(GOKCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
