//
//  GOKCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GOKCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)gOKloadAd:(NSString *)moduleId delegate:(id<GOKCSAdLoadDataProtocol>)delegate;

- (void)gOKloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<GOKCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)gOKremoveData:(id)obj;
- (NSDictionary *)getDevicesInfo;

@end

NS_ASSUME_NONNULL_END
