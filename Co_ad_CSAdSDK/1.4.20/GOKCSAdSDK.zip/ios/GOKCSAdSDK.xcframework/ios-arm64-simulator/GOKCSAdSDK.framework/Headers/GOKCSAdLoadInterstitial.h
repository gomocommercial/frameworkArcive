//
//  GOKCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "GOKCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadInterstitial : GOKCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
