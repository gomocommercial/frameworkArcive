//
//  GOKCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define gOKkAdvDataSourceFacebook   2 //FB 广告数据源
#define gOKkAdvDataSourceAdmob      8 //Admob 广告数据源
#define gOKkAdvDataSourceMopub      39//Mopub 广告数据源
#define gOKkAdvDataSourceApplovin   20//applovin 广告数据源

#define gOKkAdvDataSourceGDT        62//广点通 广告数据源
#define gOKkAdvDataSourceBaidu      63//百度 广告数据源
#define gOKkAdvDataSourceBU         64//头条 广告数据源
#define gOKkAdvDataSourceABU         70//头条聚合 广告数据源
#define gOKkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define gOKkAdvDataSourcePangle     74//pangle 广告数据源
#define gOKkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define gOKkOnlineAdvTypeBanner                   1  //banner
#define gOKkOnlineAdvTypeInterstitial             2  //全屏
#define gOKkOnlineAdvTypeNative                   3 //native
#define gOKkOnlineAdvTypeVideo                    4 //视频
#define gOKkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define gOKkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define gOKkOnlineAdvTypeOpen                     8 //开屏
#define gOKkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define gOKkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define gOKkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define gOKkAdServerConfigError  -1 //服务器返回数据不正确
#define gOKkAdLoadConfigFailed  -2 //广告加载失败


#define gOKAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define gOKkCSAdInstallDays @"gOKkCSAdInstallDays"
#define gOKkCSAdModule_key @"gOKkCSAdModule_key_%@"
#define gOKkCSNewAdModule_key @"gOKkCSNewAdModule_key_%@"
#define gOKkCSAdInstallTime @"gOKkCSAdInstallTime"
#define gOKkCSAdInstallHours @"gOKkCSAdInstallHours"
#define gOKkCSAdLastGetServerTime @"gOKkCSAdLastRequestTime"
#define gOKkCSAdloadTime 30

#define gOKkCSLoadAdTimeOutNotification @"gOKKCSLoadAdTimeOutNotification"
#define gOKkCSLoadAdTimeOutNotificationKey @"gOKKCSLoadAdTimeOutKey"

