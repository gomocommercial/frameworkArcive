//
//  GOKCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "GOKCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadOpen : GOKCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
