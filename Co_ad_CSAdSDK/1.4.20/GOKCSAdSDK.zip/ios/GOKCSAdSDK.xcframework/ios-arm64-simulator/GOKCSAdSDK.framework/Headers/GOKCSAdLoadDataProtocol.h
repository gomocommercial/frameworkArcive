//
//  GOKCSAdLoadDataProtocol.h
//  GOKCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "GOKCSAdTypedef.h"

@class GOKCSAdDataModel;
@class GOKCSAdLoadBase;

@protocol GOKCSAdLoadProtocol;

@protocol GOKCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)gOKonAdInfoFinish:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)gOKonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)gOKonAdFail:(GOKCSAdLoadBase<GOKCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
