//
//  DCCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "DCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadInterstitial : DCCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
