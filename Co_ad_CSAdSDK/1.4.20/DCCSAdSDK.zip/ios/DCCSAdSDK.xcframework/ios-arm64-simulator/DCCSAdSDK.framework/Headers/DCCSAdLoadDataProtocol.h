//
//  DCCSAdLoadDataProtocol.h
//  DCCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "DCCSAdTypedef.h"

@class DCCSAdDataModel;
@class DCCSAdLoadBase;

@protocol DCCSAdLoadProtocol;

@protocol DCCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)dConAdInfoFinish:(DCCSAdLoadBase<DCCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)dConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)dConAdFail:(DCCSAdLoadBase<DCCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
