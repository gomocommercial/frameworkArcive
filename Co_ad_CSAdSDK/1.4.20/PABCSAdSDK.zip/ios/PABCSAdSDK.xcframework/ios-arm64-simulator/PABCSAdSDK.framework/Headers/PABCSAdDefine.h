//
//  PABCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pABkAdvDataSourceFacebook   2 //FB 广告数据源
#define pABkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pABkAdvDataSourceMopub      39//Mopub 广告数据源
#define pABkAdvDataSourceApplovin   20//applovin 广告数据源

#define pABkAdvDataSourceGDT        62//广点通 广告数据源
#define pABkAdvDataSourceBaidu      63//百度 广告数据源
#define pABkAdvDataSourceBU         64//头条 广告数据源
#define pABkAdvDataSourceABU         70//头条聚合 广告数据源
#define pABkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pABkAdvDataSourcePangle     74//pangle 广告数据源
#define pABkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define pABkOnlineAdvTypeBanner                   1  //banner
#define pABkOnlineAdvTypeInterstitial             2  //全屏
#define pABkOnlineAdvTypeNative                   3 //native
#define pABkOnlineAdvTypeVideo                    4 //视频
#define pABkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pABkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pABkOnlineAdvTypeOpen                     8 //开屏
#define pABkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pABkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pABkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pABkAdServerConfigError  -1 //服务器返回数据不正确
#define pABkAdLoadConfigFailed  -2 //广告加载失败


#define pABAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pABkCSAdInstallDays @"pABkCSAdInstallDays"
#define pABkCSAdModule_key @"pABkCSAdModule_key_%@"
#define pABkCSNewAdModule_key @"pABkCSNewAdModule_key_%@"
#define pABkCSAdInstallTime @"pABkCSAdInstallTime"
#define pABkCSAdInstallHours @"pABkCSAdInstallHours"
#define pABkCSAdLastGetServerTime @"pABkCSAdLastRequestTime"
#define pABkCSAdloadTime 30

#define pABkCSLoadAdTimeOutNotification @"pABKCSLoadAdTimeOutNotification"
#define pABkCSLoadAdTimeOutNotificationKey @"pABKCSLoadAdTimeOutKey"

