//
//  PABCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PABCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PABCSAdLoadOpen : PABCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
