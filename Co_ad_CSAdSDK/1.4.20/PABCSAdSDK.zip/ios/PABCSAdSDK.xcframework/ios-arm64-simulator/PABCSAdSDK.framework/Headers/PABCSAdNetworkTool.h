//
//  PABCSAdNetworkTool.h
//  PABCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PABCSAdDataModel.h"
#import "PABCSAdTypedef.h"
#import "PABCSNewStoreLiteRequestTool.h"
#import "NSString+PABCSGenerateHash.h"

@interface PABCSAdNetworkTool : NSObject

+ (PABCSAdNetworkTool *)shared;
@property(nonatomic, copy) PABCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pABrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PABCSAdRequestCompleteBlock)complete;

- (void)pABsetCDay:(void(^ _Nullable)(bool success))handle;
@end
