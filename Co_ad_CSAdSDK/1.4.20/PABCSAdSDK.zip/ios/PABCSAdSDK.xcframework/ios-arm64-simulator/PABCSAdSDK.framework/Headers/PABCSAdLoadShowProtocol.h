//
//  PABCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PABCSAdTypedef.h"

@class PABCSAdLoadBase;

@protocol PABCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PABCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pABonAdShowed:(PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pABonAdClicked:(PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pABonAdClosed:(PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pABonAdVideoCompletePlaying:(PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pABonAdVideoGotReward:(PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload;
-(void)pABonAdDidPayRevenue:(PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)pABonAdDidGetEcpm:(PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)pABonAdShowFail:(PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pABonAdOtherEvent:(PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload event:(PABCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
