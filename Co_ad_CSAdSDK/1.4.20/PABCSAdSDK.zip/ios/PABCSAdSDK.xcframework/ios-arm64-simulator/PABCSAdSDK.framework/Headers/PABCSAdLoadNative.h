//
//  PABCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PABCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PABCSAdLoadNative : PABCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
