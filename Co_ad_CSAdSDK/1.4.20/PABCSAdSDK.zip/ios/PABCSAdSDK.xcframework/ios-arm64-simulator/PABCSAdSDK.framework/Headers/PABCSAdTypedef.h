//
//  PABCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PABCSAdLoadSuccess = 1,
    PABCSAdLoadFailure = -1,
    PABCSAdLoadTimeout = -2
} PABCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PABCSAdPreloadSuccess = 1,
    //预加载失败
    PABCSAdPreloadFailure = -1,
    //重复加载
    PABCSAdPreloadRepeat = -2,
} PABCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PABCSAdWillAppear,//即将出现
    PABCSAdDidAppear,//已经出现
    PABCSAdWillDisappear,//即将消失
    PABCSAdDidDisappear,//已经消失
    PABCSAdMuted,//静音广告
    PABCSAdWillLeaveApplication,//将要离开App

    PABCSAdVideoStart,//开始播放 常用于video
    PABCSAdVideoComplete,//播放完成 常用于video
    PABCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PABCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PABCSAdNativeDidDownload,//下载完成 常用于fb Native
    PABCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PABCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PABCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PABCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PABCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PABCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PABCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PABCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PABCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PABCSAdBUOpenRenderSuccess, //渲染成功
    PABCSAdBUOpenRenderFail, //渲染失败
    PABCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PABCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PABCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PABCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PABCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PABCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PABCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PABCSAdPlayerStatusStarted,//开始播放
    PABCSAdPlayerStatusPaused,//用户行为导致暂停
    PABCSAdPlayerStatusStoped,//播放停止
    PABCSAdPlayerStatusError,//播放出错
    PABCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PABCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PABCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PABCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PABCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PABCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PABCSAdRecordImpression, //广告曝光已记录
    PABCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PABCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PABCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PABCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PABCSAdABUOpenWillPresentFullScreen,
    PABCSAdABUOpenDidShowFailed,
    PABCSAdABUOpenWillDissmissFullScreen,
    PABCSAdABUOpenCountdownToZero,
    
    PABCSAdABUBannerWillPresentFullScreen,
    PABCSAdABUBannerWillDismissFullScreen,
    
    PABCSAdABURewardDidLoad,
    PABCSAdABURewardRenderFail,
    PABCSAdABURewardDidShowFailed,

} PABCSAdEvent;

typedef void (^PABCSAdLoadCompleteBlock)(PABCSAdLoadStatus adLoadStatus);

@class PABCSAdSetupParamsMaker;
@class PABCSAdSetupParams;

typedef PABCSAdSetupParamsMaker *(^PABCSAdStringInit)(NSString *);
typedef PABCSAdSetupParamsMaker *(^PABCSAdBoolInit)(BOOL);
typedef PABCSAdSetupParamsMaker *(^PABCSAdIntegerInit)(NSInteger);
typedef PABCSAdSetupParamsMaker *(^PABCSAdLongInit)(long);
typedef PABCSAdSetupParamsMaker *(^PABCSAdArrayInit)(NSArray *);
typedef PABCSAdSetupParams *(^PABCSAdMakeInit)(void);


@class PABCSAdDataModel;
typedef void (^PABCSAdRequestCompleteBlock)(NSMutableArray<PABCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PABCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PABCSAdPreloadCompleteBlock)(PABCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
