//
//  PABCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PABCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface PABCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)pABloadAd:(NSString *)moduleId delegate:(id<PABCSAdLoadDataProtocol>)delegate;

- (void)pABloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<PABCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)pABremoveData:(id)obj;
- (NSDictionary *)getDevicesInfo;

@end

NS_ASSUME_NONNULL_END
