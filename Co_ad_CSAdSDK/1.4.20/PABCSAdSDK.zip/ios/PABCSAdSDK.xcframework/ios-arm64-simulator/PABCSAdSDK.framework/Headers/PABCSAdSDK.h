//
//  PABCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PABCSAdLoadBase.h"
#import "PABCSAdDataModel.h"
#import "PABCSAdLoadProtocol.h"
#import "PABCSAdLoadDataProtocol.h"
#import "PABCSAdLoadShowProtocol.h"
#import "PABCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PABCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pABsetupByBlock:(void (^ _Nonnull)(PABCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pABloadAd:(NSString *)moduleId delegate:(id<PABCSAdLoadDataProtocol>)delegate;

+ (void)pABloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<PABCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pABadShowStatistic:(PABCSAdDataModel *)dataModel adload:(nonnull PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pABadClickStatistic:(PABCSAdDataModel *)dataModel adload:(nonnull PABCSAdLoadBase<PABCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pABaddCustomFecher:(Class<PABCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
