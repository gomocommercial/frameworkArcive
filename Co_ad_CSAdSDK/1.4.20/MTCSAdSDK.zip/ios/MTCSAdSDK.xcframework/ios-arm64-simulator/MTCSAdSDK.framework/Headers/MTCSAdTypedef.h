//
//  MTCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    MTCSAdLoadSuccess = 1,
    MTCSAdLoadFailure = -1,
    MTCSAdLoadTimeout = -2
} MTCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    MTCSAdPreloadSuccess = 1,
    //预加载失败
    MTCSAdPreloadFailure = -1,
    //重复加载
    MTCSAdPreloadRepeat = -2,
} MTCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    MTCSAdWillAppear,//即将出现
    MTCSAdDidAppear,//已经出现
    MTCSAdWillDisappear,//即将消失
    MTCSAdDidDisappear,//已经消失
    MTCSAdMuted,//静音广告
    MTCSAdWillLeaveApplication,//将要离开App

    MTCSAdVideoStart,//开始播放 常用于video
    MTCSAdVideoComplete,//播放完成 常用于video
    MTCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    MTCSAdVideoServerFail,//连接服务器成功，常用于fb video

    MTCSAdNativeDidDownload,//下载完成 常用于fb Native
    MTCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    MTCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    MTCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    MTCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    MTCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    MTCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    MTCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    MTCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    MTCSAdBUOpenDidAutoDimiss,//开屏自动消失
    MTCSAdBUOpenRenderSuccess, //渲染成功
    MTCSAdBUOpenRenderFail, //渲染失败
    MTCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    MTCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    MTCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    MTCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    MTCSAdDidPresentFullScreen,//插屏弹出全屏广告
    MTCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    MTCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    MTCSAdPlayerStatusStarted,//开始播放
    MTCSAdPlayerStatusPaused,//用户行为导致暂停
    MTCSAdPlayerStatusStoped,//播放停止
    MTCSAdPlayerStatusError,//播放出错
    MTCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    MTCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    MTCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    MTCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    MTCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    MTCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    MTCSAdRecordImpression, //广告曝光已记录
    MTCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    MTCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    MTCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    MTCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    MTCSAdABUOpenWillPresentFullScreen,
    MTCSAdABUOpenDidShowFailed,
    MTCSAdABUOpenWillDissmissFullScreen,
    MTCSAdABUOpenCountdownToZero,
    
    MTCSAdABUBannerWillPresentFullScreen,
    MTCSAdABUBannerWillDismissFullScreen,
    
    MTCSAdABURewardDidLoad,
    MTCSAdABURewardRenderFail,
    MTCSAdABURewardDidShowFailed,

} MTCSAdEvent;

typedef void (^MTCSAdLoadCompleteBlock)(MTCSAdLoadStatus adLoadStatus);

@class MTCSAdSetupParamsMaker;
@class MTCSAdSetupParams;

typedef MTCSAdSetupParamsMaker *(^MTCSAdStringInit)(NSString *);
typedef MTCSAdSetupParamsMaker *(^MTCSAdBoolInit)(BOOL);
typedef MTCSAdSetupParamsMaker *(^MTCSAdIntegerInit)(NSInteger);
typedef MTCSAdSetupParamsMaker *(^MTCSAdLongInit)(long);
typedef MTCSAdSetupParamsMaker *(^MTCSAdArrayInit)(NSArray *);
typedef MTCSAdSetupParams *(^MTCSAdMakeInit)(void);


@class MTCSAdDataModel;
typedef void (^MTCSAdRequestCompleteBlock)(NSMutableArray<MTCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^MTCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^MTCSAdPreloadCompleteBlock)(MTCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
