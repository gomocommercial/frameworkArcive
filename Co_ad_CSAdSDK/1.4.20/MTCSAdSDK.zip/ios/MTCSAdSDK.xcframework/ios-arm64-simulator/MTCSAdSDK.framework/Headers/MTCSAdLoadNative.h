//
//  MTCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MTCSAdLoadNative : MTCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
