//
//  MTCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "MTCSAdLoadBase.h"
#import "MTCSAdDataModel.h"
#import "MTCSAdLoadProtocol.h"
#import "MTCSAdLoadDataProtocol.h"
#import "MTCSAdLoadShowProtocol.h"
#import "MTCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface MTCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)mTsetupByBlock:(void (^ _Nonnull)(MTCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)mTloadAd:(NSString *)moduleId delegate:(id<MTCSAdLoadDataProtocol>)delegate;

+ (void)mTloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<MTCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)mTadShowStatistic:(MTCSAdDataModel *)dataModel adload:(nonnull MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)mTadClickStatistic:(MTCSAdDataModel *)dataModel adload:(nonnull MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)mTaddCustomFecher:(Class<MTCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
