//
//  MTCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MTCSAdLoadReward : MTCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
