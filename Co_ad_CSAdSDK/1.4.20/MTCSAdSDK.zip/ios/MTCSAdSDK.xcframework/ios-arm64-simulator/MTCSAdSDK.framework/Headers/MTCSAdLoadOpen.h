//
//  MTCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "MTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MTCSAdLoadOpen : MTCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
