//
//  PaceCashCSAdNetworkTool.h
//  PaceCashCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PaceCashCSAdDataModel.h"
#import "PaceCashCSAdTypedef.h"
#import "PaceCashCSNewStoreLiteRequestTool.h"
#import "NSString+PaceCashCSGenerateHash.h"

@interface PaceCashCSAdNetworkTool : NSObject

+ (PaceCashCSAdNetworkTool *)shared;
@property(nonatomic, copy) PaceCashCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)paceCashrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PaceCashCSAdRequestCompleteBlock)complete;

- (void)paceCashsetCDay:(void(^ _Nullable)(bool success))handle;
@end
