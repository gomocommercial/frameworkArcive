//
//  PaceCashCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PaceCashCSAdTypedef.h"

@class PaceCashCSAdLoadBase;

@protocol PaceCashCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PaceCashCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)paceCashonAdShowed:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)paceCashonAdClicked:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)paceCashonAdClosed:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)paceCashonAdVideoCompletePlaying:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)paceCashonAdVideoGotReward:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;
-(void)paceCashonAdDidPayRevenue:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)paceCashonAdDidGetEcpm:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)paceCashonAdShowFail:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)paceCashonAdOtherEvent:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload event:(PaceCashCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
