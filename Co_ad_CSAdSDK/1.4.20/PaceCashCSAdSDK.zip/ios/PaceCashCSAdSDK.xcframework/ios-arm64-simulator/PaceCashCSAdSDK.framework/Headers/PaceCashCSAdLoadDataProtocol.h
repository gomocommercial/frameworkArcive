//
//  PaceCashCSAdLoadDataProtocol.h
//  PaceCashCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PaceCashCSAdTypedef.h"

@class PaceCashCSAdDataModel;
@class PaceCashCSAdLoadBase;

@protocol PaceCashCSAdLoadProtocol;

@protocol PaceCashCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)paceCashonAdInfoFinish:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)paceCashonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)paceCashonAdFail:(PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
