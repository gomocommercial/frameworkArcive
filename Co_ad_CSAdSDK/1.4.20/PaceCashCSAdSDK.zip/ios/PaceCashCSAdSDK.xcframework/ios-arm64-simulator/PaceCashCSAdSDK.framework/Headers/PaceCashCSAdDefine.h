//
//  PaceCashCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define paceCashkAdvDataSourceFacebook   2 //FB 广告数据源
#define paceCashkAdvDataSourceAdmob      8 //Admob 广告数据源
#define paceCashkAdvDataSourceMopub      39//Mopub 广告数据源
#define paceCashkAdvDataSourceApplovin   20//applovin 广告数据源

#define paceCashkAdvDataSourceGDT        62//广点通 广告数据源
#define paceCashkAdvDataSourceBaidu      63//百度 广告数据源
#define paceCashkAdvDataSourceBU         64//头条 广告数据源
#define paceCashkAdvDataSourceABU         70//头条聚合 广告数据源
#define paceCashkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define paceCashkAdvDataSourcePangle     74//pangle 广告数据源
#define paceCashkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define paceCashkOnlineAdvTypeBanner                   1  //banner
#define paceCashkOnlineAdvTypeInterstitial             2  //全屏
#define paceCashkOnlineAdvTypeNative                   3 //native
#define paceCashkOnlineAdvTypeVideo                    4 //视频
#define paceCashkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define paceCashkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define paceCashkOnlineAdvTypeOpen                     8 //开屏
#define paceCashkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define paceCashkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define paceCashkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define paceCashkAdServerConfigError  -1 //服务器返回数据不正确
#define paceCashkAdLoadConfigFailed  -2 //广告加载失败


#define paceCashAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define paceCashkCSAdInstallDays @"paceCashkCSAdInstallDays"
#define paceCashkCSAdModule_key @"paceCashkCSAdModule_key_%@"
#define paceCashkCSNewAdModule_key @"paceCashkCSNewAdModule_key_%@"
#define paceCashkCSAdInstallTime @"paceCashkCSAdInstallTime"
#define paceCashkCSAdInstallHours @"paceCashkCSAdInstallHours"
#define paceCashkCSAdLastGetServerTime @"paceCashkCSAdLastRequestTime"
#define paceCashkCSAdloadTime 30

#define paceCashkCSLoadAdTimeOutNotification @"paceCashKCSLoadAdTimeOutNotification"
#define paceCashkCSLoadAdTimeOutNotificationKey @"paceCashKCSLoadAdTimeOutKey"

