//
//  PaceCashCSAdStatistics.h
//  PaceCashCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "PaceCashCSAdDataModel.h"
#import "PaceCashCSAdTypedef.h"
#import "PaceCashCSAdLoadBase.h"
@interface PaceCashCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)paceCashadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)paceCashadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)paceCashadRewardVideoCompleteStatistic:(PaceCashCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)paceCashadShowStatistic:(PaceCashCSAdDataModel *)dataModel adload:(nonnull PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)paceCashadClickStatistic:(PaceCashCSAdDataModel *)dataModel adload:(nonnull PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)paceCashadUploadRevenueStatistic:(PaceCashCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
