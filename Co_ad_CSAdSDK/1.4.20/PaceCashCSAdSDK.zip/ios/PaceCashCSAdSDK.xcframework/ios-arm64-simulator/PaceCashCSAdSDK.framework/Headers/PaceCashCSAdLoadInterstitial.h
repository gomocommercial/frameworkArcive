//
//  PaceCashCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PaceCashCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashCSAdLoadInterstitial : PaceCashCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
