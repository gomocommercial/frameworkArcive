//
//  PaceCashCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PaceCashCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashCSAdLoadNative : PaceCashCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
