//
//  PaceCashCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PaceCashCSAdLoadSuccess = 1,
    PaceCashCSAdLoadFailure = -1,
    PaceCashCSAdLoadTimeout = -2
} PaceCashCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PaceCashCSAdPreloadSuccess = 1,
    //预加载失败
    PaceCashCSAdPreloadFailure = -1,
    //重复加载
    PaceCashCSAdPreloadRepeat = -2,
} PaceCashCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PaceCashCSAdWillAppear,//即将出现
    PaceCashCSAdDidAppear,//已经出现
    PaceCashCSAdWillDisappear,//即将消失
    PaceCashCSAdDidDisappear,//已经消失
    PaceCashCSAdMuted,//静音广告
    PaceCashCSAdWillLeaveApplication,//将要离开App

    PaceCashCSAdVideoStart,//开始播放 常用于video
    PaceCashCSAdVideoComplete,//播放完成 常用于video
    PaceCashCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PaceCashCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PaceCashCSAdNativeDidDownload,//下载完成 常用于fb Native
    PaceCashCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PaceCashCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PaceCashCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PaceCashCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PaceCashCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PaceCashCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PaceCashCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PaceCashCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PaceCashCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PaceCashCSAdBUOpenRenderSuccess, //渲染成功
    PaceCashCSAdBUOpenRenderFail, //渲染失败
    PaceCashCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PaceCashCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PaceCashCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PaceCashCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PaceCashCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PaceCashCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PaceCashCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PaceCashCSAdPlayerStatusStarted,//开始播放
    PaceCashCSAdPlayerStatusPaused,//用户行为导致暂停
    PaceCashCSAdPlayerStatusStoped,//播放停止
    PaceCashCSAdPlayerStatusError,//播放出错
    PaceCashCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PaceCashCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PaceCashCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PaceCashCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PaceCashCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PaceCashCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PaceCashCSAdRecordImpression, //广告曝光已记录
    PaceCashCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PaceCashCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PaceCashCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PaceCashCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PaceCashCSAdABUOpenWillPresentFullScreen,
    PaceCashCSAdABUOpenDidShowFailed,
    PaceCashCSAdABUOpenWillDissmissFullScreen,
    PaceCashCSAdABUOpenCountdownToZero,
    
    PaceCashCSAdABUBannerWillPresentFullScreen,
    PaceCashCSAdABUBannerWillDismissFullScreen,
    
    PaceCashCSAdABURewardDidLoad,
    PaceCashCSAdABURewardRenderFail,
    PaceCashCSAdABURewardDidShowFailed,

} PaceCashCSAdEvent;

typedef void (^PaceCashCSAdLoadCompleteBlock)(PaceCashCSAdLoadStatus adLoadStatus);

@class PaceCashCSAdSetupParamsMaker;
@class PaceCashCSAdSetupParams;

typedef PaceCashCSAdSetupParamsMaker *(^PaceCashCSAdStringInit)(NSString *);
typedef PaceCashCSAdSetupParamsMaker *(^PaceCashCSAdBoolInit)(BOOL);
typedef PaceCashCSAdSetupParamsMaker *(^PaceCashCSAdIntegerInit)(NSInteger);
typedef PaceCashCSAdSetupParamsMaker *(^PaceCashCSAdLongInit)(long);
typedef PaceCashCSAdSetupParamsMaker *(^PaceCashCSAdArrayInit)(NSArray *);
typedef PaceCashCSAdSetupParams *(^PaceCashCSAdMakeInit)(void);


@class PaceCashCSAdDataModel;
typedef void (^PaceCashCSAdRequestCompleteBlock)(NSMutableArray<PaceCashCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PaceCashCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PaceCashCSAdPreloadCompleteBlock)(PaceCashCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
