//
//  PaceCashCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PaceCashCSAdLoadBase.h"
#import "PaceCashCSAdDataModel.h"
#import "PaceCashCSAdLoadProtocol.h"
#import "PaceCashCSAdLoadDataProtocol.h"
#import "PaceCashCSAdLoadShowProtocol.h"
#import "PaceCashCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)paceCashsetupByBlock:(void (^ _Nonnull)(PaceCashCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)paceCashloadAd:(NSString *)moduleId delegate:(id<PaceCashCSAdLoadDataProtocol>)delegate;

+ (void)paceCashloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<PaceCashCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)paceCashadShowStatistic:(PaceCashCSAdDataModel *)dataModel adload:(nonnull PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)paceCashadClickStatistic:(PaceCashCSAdDataModel *)dataModel adload:(nonnull PaceCashCSAdLoadBase<PaceCashCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)paceCashaddCustomFecher:(Class<PaceCashCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
