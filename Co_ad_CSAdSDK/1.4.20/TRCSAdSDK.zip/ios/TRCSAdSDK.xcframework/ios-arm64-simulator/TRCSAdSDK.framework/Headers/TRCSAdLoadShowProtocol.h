//
//  TRCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "TRCSAdTypedef.h"

@class TRCSAdLoadBase;

@protocol TRCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol TRCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)tRonAdShowed:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)tRonAdClicked:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)tRonAdClosed:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)tRonAdVideoCompletePlaying:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)tRonAdVideoGotReward:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload;
-(void)tRonAdDidPayRevenue:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)tRonAdDidGetEcpm:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)tRonAdShowFail:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)tRonAdOtherEvent:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload event:(TRCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
