//
//  TRCSAdNetworkTool.h
//  TRCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "TRCSAdDataModel.h"
#import "TRCSAdTypedef.h"
#import "TRCSNewStoreLiteRequestTool.h"
#import "NSString+TRCSGenerateHash.h"

@interface TRCSAdNetworkTool : NSObject

+ (TRCSAdNetworkTool *)shared;
@property(nonatomic, copy) TRCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)tRrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(TRCSAdRequestCompleteBlock)complete;

- (void)tRsetCDay:(void(^ _Nullable)(bool success))handle;
@end
