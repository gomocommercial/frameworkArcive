//
//  TRCSAdLoadDataProtocol.h
//  TRCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "TRCSAdTypedef.h"

@class TRCSAdDataModel;
@class TRCSAdLoadBase;

@protocol TRCSAdLoadProtocol;

@protocol TRCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)tRonAdInfoFinish:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)tRonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)tRonAdFail:(TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
