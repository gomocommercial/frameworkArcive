//
//  TRCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "TRCSAdLoadBase.h"
#import "TRCSAdDataModel.h"
#import "TRCSAdLoadProtocol.h"
#import "TRCSAdLoadDataProtocol.h"
#import "TRCSAdLoadShowProtocol.h"
#import "TRCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)tRsetupByBlock:(void (^ _Nonnull)(TRCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)tRloadAd:(NSString *)moduleId delegate:(id<TRCSAdLoadDataProtocol>)delegate;

+ (void)tRloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<TRCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)tRadShowStatistic:(TRCSAdDataModel *)dataModel adload:(nonnull TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)tRadClickStatistic:(TRCSAdDataModel *)dataModel adload:(nonnull TRCSAdLoadBase<TRCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)tRaddCustomFecher:(Class<TRCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
