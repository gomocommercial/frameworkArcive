//
//  TRCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TRCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCSAdLoadInterstitial : TRCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
