//
//  TRCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TRCSAdLoadSuccess = 1,
    TRCSAdLoadFailure = -1,
    TRCSAdLoadTimeout = -2
} TRCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TRCSAdPreloadSuccess = 1,
    //预加载失败
    TRCSAdPreloadFailure = -1,
    //重复加载
    TRCSAdPreloadRepeat = -2,
} TRCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TRCSAdWillAppear,//即将出现
    TRCSAdDidAppear,//已经出现
    TRCSAdWillDisappear,//即将消失
    TRCSAdDidDisappear,//已经消失
    TRCSAdMuted,//静音广告
    TRCSAdWillLeaveApplication,//将要离开App

    TRCSAdVideoStart,//开始播放 常用于video
    TRCSAdVideoComplete,//播放完成 常用于video
    TRCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TRCSAdVideoServerFail,//连接服务器成功，常用于fb video

    TRCSAdNativeDidDownload,//下载完成 常用于fb Native
    TRCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TRCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    TRCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    TRCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    TRCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    TRCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    TRCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    TRCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    TRCSAdBUOpenDidAutoDimiss,//开屏自动消失
    TRCSAdBUOpenRenderSuccess, //渲染成功
    TRCSAdBUOpenRenderFail, //渲染失败
    TRCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    TRCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    TRCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    TRCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    TRCSAdDidPresentFullScreen,//插屏弹出全屏广告
    TRCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    TRCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    TRCSAdPlayerStatusStarted,//开始播放
    TRCSAdPlayerStatusPaused,//用户行为导致暂停
    TRCSAdPlayerStatusStoped,//播放停止
    TRCSAdPlayerStatusError,//播放出错
    TRCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    TRCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    TRCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    TRCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    TRCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    TRCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    TRCSAdRecordImpression, //广告曝光已记录
    TRCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    TRCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    TRCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    TRCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    TRCSAdABUOpenWillPresentFullScreen,
    TRCSAdABUOpenDidShowFailed,
    TRCSAdABUOpenWillDissmissFullScreen,
    TRCSAdABUOpenCountdownToZero,
    
    TRCSAdABUBannerWillPresentFullScreen,
    TRCSAdABUBannerWillDismissFullScreen,
    
    TRCSAdABURewardDidLoad,
    TRCSAdABURewardRenderFail,
    TRCSAdABURewardDidShowFailed,

} TRCSAdEvent;

typedef void (^TRCSAdLoadCompleteBlock)(TRCSAdLoadStatus adLoadStatus);

@class TRCSAdSetupParamsMaker;
@class TRCSAdSetupParams;

typedef TRCSAdSetupParamsMaker *(^TRCSAdStringInit)(NSString *);
typedef TRCSAdSetupParamsMaker *(^TRCSAdBoolInit)(BOOL);
typedef TRCSAdSetupParamsMaker *(^TRCSAdIntegerInit)(NSInteger);
typedef TRCSAdSetupParamsMaker *(^TRCSAdLongInit)(long);
typedef TRCSAdSetupParamsMaker *(^TRCSAdArrayInit)(NSArray *);
typedef TRCSAdSetupParams *(^TRCSAdMakeInit)(void);


@class TRCSAdDataModel;
typedef void (^TRCSAdRequestCompleteBlock)(NSMutableArray<TRCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TRCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TRCSAdPreloadCompleteBlock)(TRCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
