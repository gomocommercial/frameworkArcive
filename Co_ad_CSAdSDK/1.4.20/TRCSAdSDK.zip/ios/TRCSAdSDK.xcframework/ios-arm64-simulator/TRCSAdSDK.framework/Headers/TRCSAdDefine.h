//
//  TRCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tRkAdvDataSourceFacebook   2 //FB 广告数据源
#define tRkAdvDataSourceAdmob      8 //Admob 广告数据源
#define tRkAdvDataSourceMopub      39//Mopub 广告数据源
#define tRkAdvDataSourceApplovin   20//applovin 广告数据源

#define tRkAdvDataSourceGDT        62//广点通 广告数据源
#define tRkAdvDataSourceBaidu      63//百度 广告数据源
#define tRkAdvDataSourceBU         64//头条 广告数据源
#define tRkAdvDataSourceABU         70//头条聚合 广告数据源
#define tRkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define tRkAdvDataSourcePangle     74//pangle 广告数据源
#define tRkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define tRkOnlineAdvTypeBanner                   1  //banner
#define tRkOnlineAdvTypeInterstitial             2  //全屏
#define tRkOnlineAdvTypeNative                   3 //native
#define tRkOnlineAdvTypeVideo                    4 //视频
#define tRkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define tRkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define tRkOnlineAdvTypeOpen                     8 //开屏
#define tRkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define tRkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define tRkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define tRkAdServerConfigError  -1 //服务器返回数据不正确
#define tRkAdLoadConfigFailed  -2 //广告加载失败


#define tRAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tRkCSAdInstallDays @"tRkCSAdInstallDays"
#define tRkCSAdModule_key @"tRkCSAdModule_key_%@"
#define tRkCSNewAdModule_key @"tRkCSNewAdModule_key_%@"
#define tRkCSAdInstallTime @"tRkCSAdInstallTime"
#define tRkCSAdInstallHours @"tRkCSAdInstallHours"
#define tRkCSAdLastGetServerTime @"tRkCSAdLastRequestTime"
#define tRkCSAdloadTime 30

#define tRkCSLoadAdTimeOutNotification @"tRKCSLoadAdTimeOutNotification"
#define tRkCSLoadAdTimeOutNotificationKey @"tRKCSLoadAdTimeOutKey"

