//
//  TRCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TRCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCSAdLoadNative : TRCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
