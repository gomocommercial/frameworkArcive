//
//  AhhhCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "AhhhCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadReward : AhhhCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
