//
//  AhhhCSAdNetworkTool.h
//  AhhhCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "AhhhCSAdDataModel.h"
#import "AhhhCSAdTypedef.h"
#import "AhhhCSNewStoreLiteRequestTool.h"
#import "NSString+AhhhCSGenerateHash.h"

@interface AhhhCSAdNetworkTool : NSObject

+ (AhhhCSAdNetworkTool *)shared;
@property(nonatomic, copy) AhhhCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)ahhhrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(AhhhCSAdRequestCompleteBlock)complete;

- (void)ahhhsetCDay:(void(^ _Nullable)(bool success))handle;
@end
