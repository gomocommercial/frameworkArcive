//
//  AhhhCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "AhhhCSAdLoadBase.h"
#import "AhhhCSAdDataModel.h"
#import "AhhhCSAdLoadProtocol.h"
#import "AhhhCSAdLoadDataProtocol.h"
#import "AhhhCSAdLoadShowProtocol.h"
#import "AhhhCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)ahhhsetupByBlock:(void (^ _Nonnull)(AhhhCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)ahhhloadAd:(NSString *)moduleId delegate:(id<AhhhCSAdLoadDataProtocol>)delegate;

+ (void)ahhhloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<AhhhCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)ahhhadShowStatistic:(AhhhCSAdDataModel *)dataModel adload:(nonnull AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)ahhhadClickStatistic:(AhhhCSAdDataModel *)dataModel adload:(nonnull AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)ahhhaddCustomFecher:(Class<AhhhCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
