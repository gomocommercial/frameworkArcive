//
//  FFCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    FFCSAdLoadSuccess = 1,
    FFCSAdLoadFailure = -1,
    FFCSAdLoadTimeout = -2
} FFCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    FFCSAdPreloadSuccess = 1,
    //预加载失败
    FFCSAdPreloadFailure = -1,
    //重复加载
    FFCSAdPreloadRepeat = -2,
} FFCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    FFCSAdWillAppear,//即将出现
    FFCSAdDidAppear,//已经出现
    FFCSAdWillDisappear,//即将消失
    FFCSAdDidDisappear,//已经消失
    FFCSAdMuted,//静音广告
    FFCSAdWillLeaveApplication,//将要离开App

    FFCSAdVideoStart,//开始播放 常用于video
    FFCSAdVideoComplete,//播放完成 常用于video
    FFCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    FFCSAdVideoServerFail,//连接服务器成功，常用于fb video

    FFCSAdNativeDidDownload,//下载完成 常用于fb Native
    FFCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    FFCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    FFCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    FFCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    FFCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    FFCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    FFCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    FFCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    FFCSAdBUOpenDidAutoDimiss,//开屏自动消失
    FFCSAdBUOpenRenderSuccess, //渲染成功
    FFCSAdBUOpenRenderFail, //渲染失败
    FFCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    FFCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    FFCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    FFCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    FFCSAdDidPresentFullScreen,//插屏弹出全屏广告
    FFCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    FFCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    FFCSAdPlayerStatusStarted,//开始播放
    FFCSAdPlayerStatusPaused,//用户行为导致暂停
    FFCSAdPlayerStatusStoped,//播放停止
    FFCSAdPlayerStatusError,//播放出错
    FFCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    FFCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    FFCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    FFCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    FFCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    FFCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    FFCSAdRecordImpression, //广告曝光已记录
    FFCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    FFCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    FFCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    FFCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    FFCSAdABUOpenWillPresentFullScreen,
    FFCSAdABUOpenDidShowFailed,
    FFCSAdABUOpenWillDissmissFullScreen,
    FFCSAdABUOpenCountdownToZero,
    
    FFCSAdABUBannerWillPresentFullScreen,
    FFCSAdABUBannerWillDismissFullScreen,
    
    FFCSAdABURewardDidLoad,
    FFCSAdABURewardRenderFail,
    FFCSAdABURewardDidShowFailed,

} FFCSAdEvent;

typedef void (^FFCSAdLoadCompleteBlock)(FFCSAdLoadStatus adLoadStatus);

@class FFCSAdSetupParamsMaker;
@class FFCSAdSetupParams;

typedef FFCSAdSetupParamsMaker *(^FFCSAdStringInit)(NSString *);
typedef FFCSAdSetupParamsMaker *(^FFCSAdBoolInit)(BOOL);
typedef FFCSAdSetupParamsMaker *(^FFCSAdIntegerInit)(NSInteger);
typedef FFCSAdSetupParamsMaker *(^FFCSAdLongInit)(long);
typedef FFCSAdSetupParamsMaker *(^FFCSAdArrayInit)(NSArray *);
typedef FFCSAdSetupParams *(^FFCSAdMakeInit)(void);


@class FFCSAdDataModel;
typedef void (^FFCSAdRequestCompleteBlock)(NSMutableArray<FFCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^FFCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^FFCSAdPreloadCompleteBlock)(FFCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
