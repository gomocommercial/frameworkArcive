//
//  FFCSAdLoadDataProtocol.h
//  FFCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "FFCSAdTypedef.h"

@class FFCSAdDataModel;
@class FFCSAdLoadBase;

@protocol FFCSAdLoadProtocol;

@protocol FFCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)fFonAdInfoFinish:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)fFonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)fFonAdFail:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
