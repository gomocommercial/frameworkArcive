//
//  FFCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define fFkAdvDataSourceFacebook   2 //FB 广告数据源
#define fFkAdvDataSourceAdmob      8 //Admob 广告数据源
#define fFkAdvDataSourceMopub      39//Mopub 广告数据源
#define fFkAdvDataSourceApplovin   20//applovin 广告数据源

#define fFkAdvDataSourceGDT        62//广点通 广告数据源
#define fFkAdvDataSourceBaidu      63//百度 广告数据源
#define fFkAdvDataSourceBU         64//头条 广告数据源
#define fFkAdvDataSourceABU         70//头条聚合 广告数据源
#define fFkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define fFkAdvDataSourcePangle     74//pangle 广告数据源
#define fFkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define fFkOnlineAdvTypeBanner                   1  //banner
#define fFkOnlineAdvTypeInterstitial             2  //全屏
#define fFkOnlineAdvTypeNative                   3 //native
#define fFkOnlineAdvTypeVideo                    4 //视频
#define fFkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define fFkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define fFkOnlineAdvTypeOpen                     8 //开屏
#define fFkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define fFkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define fFkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define fFkAdServerConfigError  -1 //服务器返回数据不正确
#define fFkAdLoadConfigFailed  -2 //广告加载失败


#define fFAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define fFkCSAdInstallDays @"fFkCSAdInstallDays"
#define fFkCSAdModule_key @"fFkCSAdModule_key_%@"
#define fFkCSNewAdModule_key @"fFkCSNewAdModule_key_%@"
#define fFkCSAdInstallTime @"fFkCSAdInstallTime"
#define fFkCSAdInstallHours @"fFkCSAdInstallHours"
#define fFkCSAdLastGetServerTime @"fFkCSAdLastRequestTime"
#define fFkCSAdloadTime 30

#define fFkCSLoadAdTimeOutNotification @"fFKCSLoadAdTimeOutNotification"
#define fFkCSLoadAdTimeOutNotificationKey @"fFKCSLoadAdTimeOutKey"

