//
//  FFCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "FFCSAdLoadBase.h"
#import "FFCSAdDataModel.h"
#import "FFCSAdLoadProtocol.h"
#import "FFCSAdLoadDataProtocol.h"
#import "FFCSAdLoadShowProtocol.h"
#import "FFCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)fFsetupByBlock:(void (^ _Nonnull)(FFCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)fFloadAd:(NSString *)moduleId delegate:(id<FFCSAdLoadDataProtocol>)delegate;

+ (void)fFloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<FFCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)fFadShowStatistic:(FFCSAdDataModel *)dataModel adload:(nonnull FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)fFadClickStatistic:(FFCSAdDataModel *)dataModel adload:(nonnull FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)fFaddCustomFecher:(Class<FFCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
