//
//  FFCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FFCSAdTypedef.h"

@class FFCSAdLoadBase;

@protocol FFCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FFCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)fFonAdShowed:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)fFonAdClicked:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)fFonAdClosed:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)fFonAdVideoCompletePlaying:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)fFonAdVideoGotReward:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload;
-(void)fFonAdDidPayRevenue:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)fFonAdDidGetEcpm:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)fFonAdShowFail:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)fFonAdOtherEvent:(FFCSAdLoadBase<FFCSAdLoadProtocol> *)adload event:(FFCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
