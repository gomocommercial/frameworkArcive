//
//  FFCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "FFCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdLoadOpen : FFCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
