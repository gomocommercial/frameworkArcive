//
//  FFCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "FFCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdLoadReward : FFCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
