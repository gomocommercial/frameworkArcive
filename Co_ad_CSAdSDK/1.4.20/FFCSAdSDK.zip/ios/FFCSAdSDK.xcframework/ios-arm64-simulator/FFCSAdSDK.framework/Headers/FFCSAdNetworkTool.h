//
//  FFCSAdNetworkTool.h
//  FFCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "FFCSAdDataModel.h"
#import "FFCSAdTypedef.h"
#import "FFCSNewStoreLiteRequestTool.h"
#import "NSString+FFCSGenerateHash.h"

@interface FFCSAdNetworkTool : NSObject

+ (FFCSAdNetworkTool *)shared;
@property(nonatomic, copy) FFCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)fFrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(FFCSAdRequestCompleteBlock)complete;

- (void)fFsetCDay:(void(^ _Nullable)(bool success))handle;
@end
