//
//  FurTalesCSAdLoadDataProtocol.h
//  FurTalesCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "FurTalesCSAdTypedef.h"

@class FurTalesCSAdDataModel;
@class FurTalesCSAdLoadBase;

@protocol FurTalesCSAdLoadProtocol;

@protocol FurTalesCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)furTalesonAdInfoFinish:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)furTalesonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)furTalesonAdFail:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
