//
//  FurTalesCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    FurTalesCSAdLoadSuccess = 1,
    FurTalesCSAdLoadFailure = -1,
    FurTalesCSAdLoadTimeout = -2
} FurTalesCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    FurTalesCSAdPreloadSuccess = 1,
    //预加载失败
    FurTalesCSAdPreloadFailure = -1,
    //重复加载
    FurTalesCSAdPreloadRepeat = -2,
} FurTalesCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    FurTalesCSAdWillAppear,//即将出现
    FurTalesCSAdDidAppear,//已经出现
    FurTalesCSAdWillDisappear,//即将消失
    FurTalesCSAdDidDisappear,//已经消失
    FurTalesCSAdMuted,//静音广告
    FurTalesCSAdWillLeaveApplication,//将要离开App

    FurTalesCSAdVideoStart,//开始播放 常用于video
    FurTalesCSAdVideoComplete,//播放完成 常用于video
    FurTalesCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    FurTalesCSAdVideoServerFail,//连接服务器成功，常用于fb video

    FurTalesCSAdNativeDidDownload,//下载完成 常用于fb Native
    FurTalesCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    FurTalesCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    FurTalesCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    FurTalesCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    FurTalesCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    FurTalesCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    FurTalesCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    FurTalesCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    FurTalesCSAdBUOpenDidAutoDimiss,//开屏自动消失
    FurTalesCSAdBUOpenRenderSuccess, //渲染成功
    FurTalesCSAdBUOpenRenderFail, //渲染失败
    FurTalesCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    FurTalesCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    FurTalesCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    FurTalesCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    FurTalesCSAdDidPresentFullScreen,//插屏弹出全屏广告
    FurTalesCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    FurTalesCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    FurTalesCSAdPlayerStatusStarted,//开始播放
    FurTalesCSAdPlayerStatusPaused,//用户行为导致暂停
    FurTalesCSAdPlayerStatusStoped,//播放停止
    FurTalesCSAdPlayerStatusError,//播放出错
    FurTalesCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    FurTalesCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    FurTalesCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    FurTalesCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    FurTalesCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    FurTalesCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    FurTalesCSAdRecordImpression, //广告曝光已记录
    FurTalesCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    FurTalesCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    FurTalesCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    FurTalesCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    FurTalesCSAdABUOpenWillPresentFullScreen,
    FurTalesCSAdABUOpenDidShowFailed,
    FurTalesCSAdABUOpenWillDissmissFullScreen,
    FurTalesCSAdABUOpenCountdownToZero,
    
    FurTalesCSAdABUBannerWillPresentFullScreen,
    FurTalesCSAdABUBannerWillDismissFullScreen,
    
    FurTalesCSAdABURewardDidLoad,
    FurTalesCSAdABURewardRenderFail,
    FurTalesCSAdABURewardDidShowFailed,

} FurTalesCSAdEvent;

typedef void (^FurTalesCSAdLoadCompleteBlock)(FurTalesCSAdLoadStatus adLoadStatus);

@class FurTalesCSAdSetupParamsMaker;
@class FurTalesCSAdSetupParams;

typedef FurTalesCSAdSetupParamsMaker *(^FurTalesCSAdStringInit)(NSString *);
typedef FurTalesCSAdSetupParamsMaker *(^FurTalesCSAdBoolInit)(BOOL);
typedef FurTalesCSAdSetupParamsMaker *(^FurTalesCSAdIntegerInit)(NSInteger);
typedef FurTalesCSAdSetupParamsMaker *(^FurTalesCSAdLongInit)(long);
typedef FurTalesCSAdSetupParamsMaker *(^FurTalesCSAdArrayInit)(NSArray *);
typedef FurTalesCSAdSetupParams *(^FurTalesCSAdMakeInit)(void);


@class FurTalesCSAdDataModel;
typedef void (^FurTalesCSAdRequestCompleteBlock)(NSMutableArray<FurTalesCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^FurTalesCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^FurTalesCSAdPreloadCompleteBlock)(FurTalesCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
