//
//  FurTalesCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FurTalesCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)furTalesloadAd:(NSString *)moduleId delegate:(id<FurTalesCSAdLoadDataProtocol>)delegate;

- (void)furTalesloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<FurTalesCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)furTalesremoveData:(id)obj;
- (NSDictionary *)getDevicesInfo;

@end

NS_ASSUME_NONNULL_END
