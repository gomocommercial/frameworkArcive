//
//  AKCSAdLoadDataProtocol.h
//  AKCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "AKCSAdTypedef.h"

@class AKCSAdDataModel;
@class AKCSAdLoadBase;

@protocol AKCSAdLoadProtocol;

@protocol AKCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)aKonAdInfoFinish:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)aKonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)aKonAdFail:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
