//
//  AKCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "AKCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AKCSAdLoadOpen : AKCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
