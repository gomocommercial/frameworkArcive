//
//  AKCSAdNetworkTool.h
//  AKCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "AKCSAdDataModel.h"
#import "AKCSAdTypedef.h"
#import "AKCSNewStoreLiteRequestTool.h"
#import "NSString+AKCSGenerateHash.h"

@interface AKCSAdNetworkTool : NSObject

+ (AKCSAdNetworkTool *)shared;
@property(nonatomic, copy) AKCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)aKrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(AKCSAdRequestCompleteBlock)complete;

- (void)aKsetCDay:(void(^ _Nullable)(bool success))handle;
@end
