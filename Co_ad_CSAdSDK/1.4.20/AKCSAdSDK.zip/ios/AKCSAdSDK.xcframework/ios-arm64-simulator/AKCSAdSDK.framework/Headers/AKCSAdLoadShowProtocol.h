//
//  AKCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "AKCSAdTypedef.h"

@class AKCSAdLoadBase;

@protocol AKCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol AKCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)aKonAdShowed:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)aKonAdClicked:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)aKonAdClosed:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)aKonAdVideoCompletePlaying:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)aKonAdVideoGotReward:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload;
-(void)aKonAdDidPayRevenue:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)aKonAdDidGetEcpm:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)aKonAdShowFail:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)aKonAdOtherEvent:(AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload event:(AKCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
