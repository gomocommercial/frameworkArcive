//
//  AKCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "AKCSAdLoadBase.h"
#import "AKCSAdDataModel.h"
#import "AKCSAdLoadProtocol.h"
#import "AKCSAdLoadDataProtocol.h"
#import "AKCSAdLoadShowProtocol.h"
#import "AKCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface AKCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)aKsetupByBlock:(void (^ _Nonnull)(AKCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)aKloadAd:(NSString *)moduleId delegate:(id<AKCSAdLoadDataProtocol>)delegate;

+ (void)aKloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<AKCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)aKadShowStatistic:(AKCSAdDataModel *)dataModel adload:(nonnull AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)aKadClickStatistic:(AKCSAdDataModel *)dataModel adload:(nonnull AKCSAdLoadBase<AKCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)aKaddCustomFecher:(Class<AKCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
