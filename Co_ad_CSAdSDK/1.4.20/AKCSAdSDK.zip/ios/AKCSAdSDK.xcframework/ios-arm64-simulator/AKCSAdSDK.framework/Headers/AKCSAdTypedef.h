//
//  AKCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    AKCSAdLoadSuccess = 1,
    AKCSAdLoadFailure = -1,
    AKCSAdLoadTimeout = -2
} AKCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    AKCSAdPreloadSuccess = 1,
    //预加载失败
    AKCSAdPreloadFailure = -1,
    //重复加载
    AKCSAdPreloadRepeat = -2,
} AKCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    AKCSAdWillAppear,//即将出现
    AKCSAdDidAppear,//已经出现
    AKCSAdWillDisappear,//即将消失
    AKCSAdDidDisappear,//已经消失
    AKCSAdMuted,//静音广告
    AKCSAdWillLeaveApplication,//将要离开App

    AKCSAdVideoStart,//开始播放 常用于video
    AKCSAdVideoComplete,//播放完成 常用于video
    AKCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    AKCSAdVideoServerFail,//连接服务器成功，常用于fb video

    AKCSAdNativeDidDownload,//下载完成 常用于fb Native
    AKCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    AKCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    AKCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    AKCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    AKCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    AKCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    AKCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    AKCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    AKCSAdBUOpenDidAutoDimiss,//开屏自动消失
    AKCSAdBUOpenRenderSuccess, //渲染成功
    AKCSAdBUOpenRenderFail, //渲染失败
    AKCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    AKCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    AKCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    AKCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    AKCSAdDidPresentFullScreen,//插屏弹出全屏广告
    AKCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    AKCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    AKCSAdPlayerStatusStarted,//开始播放
    AKCSAdPlayerStatusPaused,//用户行为导致暂停
    AKCSAdPlayerStatusStoped,//播放停止
    AKCSAdPlayerStatusError,//播放出错
    AKCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    AKCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    AKCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    AKCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    AKCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    AKCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    AKCSAdRecordImpression, //广告曝光已记录
    AKCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    AKCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    AKCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    AKCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    AKCSAdABUOpenWillPresentFullScreen,
    AKCSAdABUOpenDidShowFailed,
    AKCSAdABUOpenWillDissmissFullScreen,
    AKCSAdABUOpenCountdownToZero,
    
    AKCSAdABUBannerWillPresentFullScreen,
    AKCSAdABUBannerWillDismissFullScreen,
    
    AKCSAdABURewardDidLoad,
    AKCSAdABURewardRenderFail,
    AKCSAdABURewardDidShowFailed,

} AKCSAdEvent;

typedef void (^AKCSAdLoadCompleteBlock)(AKCSAdLoadStatus adLoadStatus);

@class AKCSAdSetupParamsMaker;
@class AKCSAdSetupParams;

typedef AKCSAdSetupParamsMaker *(^AKCSAdStringInit)(NSString *);
typedef AKCSAdSetupParamsMaker *(^AKCSAdBoolInit)(BOOL);
typedef AKCSAdSetupParamsMaker *(^AKCSAdIntegerInit)(NSInteger);
typedef AKCSAdSetupParamsMaker *(^AKCSAdLongInit)(long);
typedef AKCSAdSetupParamsMaker *(^AKCSAdArrayInit)(NSArray *);
typedef AKCSAdSetupParams *(^AKCSAdMakeInit)(void);


@class AKCSAdDataModel;
typedef void (^AKCSAdRequestCompleteBlock)(NSMutableArray<AKCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^AKCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^AKCSAdPreloadCompleteBlock)(AKCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
