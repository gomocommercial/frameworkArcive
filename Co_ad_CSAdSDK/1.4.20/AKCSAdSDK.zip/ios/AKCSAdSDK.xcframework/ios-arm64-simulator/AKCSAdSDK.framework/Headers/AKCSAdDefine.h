//
//  AKCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define aKkAdvDataSourceFacebook   2 //FB 广告数据源
#define aKkAdvDataSourceAdmob      8 //Admob 广告数据源
#define aKkAdvDataSourceMopub      39//Mopub 广告数据源
#define aKkAdvDataSourceApplovin   20//applovin 广告数据源

#define aKkAdvDataSourceGDT        62//广点通 广告数据源
#define aKkAdvDataSourceBaidu      63//百度 广告数据源
#define aKkAdvDataSourceBU         64//头条 广告数据源
#define aKkAdvDataSourceABU         70//头条聚合 广告数据源
#define aKkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define aKkAdvDataSourcePangle     74//pangle 广告数据源
#define aKkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define aKkOnlineAdvTypeBanner                   1  //banner
#define aKkOnlineAdvTypeInterstitial             2  //全屏
#define aKkOnlineAdvTypeNative                   3 //native
#define aKkOnlineAdvTypeVideo                    4 //视频
#define aKkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define aKkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define aKkOnlineAdvTypeOpen                     8 //开屏
#define aKkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define aKkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define aKkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define aKkAdServerConfigError  -1 //服务器返回数据不正确
#define aKkAdLoadConfigFailed  -2 //广告加载失败


#define aKAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define aKkCSAdInstallDays @"aKkCSAdInstallDays"
#define aKkCSAdModule_key @"aKkCSAdModule_key_%@"
#define aKkCSNewAdModule_key @"aKkCSNewAdModule_key_%@"
#define aKkCSAdInstallTime @"aKkCSAdInstallTime"
#define aKkCSAdInstallHours @"aKkCSAdInstallHours"
#define aKkCSAdLastGetServerTime @"aKkCSAdLastRequestTime"
#define aKkCSAdloadTime 30

#define aKkCSLoadAdTimeOutNotification @"aKKCSLoadAdTimeOutNotification"
#define aKkCSLoadAdTimeOutNotificationKey @"aKKCSLoadAdTimeOutKey"

