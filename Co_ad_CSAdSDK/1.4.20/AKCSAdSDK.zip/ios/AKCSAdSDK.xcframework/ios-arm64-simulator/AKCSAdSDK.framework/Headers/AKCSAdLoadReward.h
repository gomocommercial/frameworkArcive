//
//  AKCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "AKCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AKCSAdLoadReward : AKCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
