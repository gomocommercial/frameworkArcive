//
//  ARCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    ARCSAdLoadSuccess = 1,
    ARCSAdLoadFailure = -1,
    ARCSAdLoadTimeout = -2
} ARCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    ARCSAdPreloadSuccess = 1,
    //预加载失败
    ARCSAdPreloadFailure = -1,
    //重复加载
    ARCSAdPreloadRepeat = -2,
} ARCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    ARCSAdWillAppear,//即将出现
    ARCSAdDidAppear,//已经出现
    ARCSAdWillDisappear,//即将消失
    ARCSAdDidDisappear,//已经消失
    ARCSAdMuted,//静音广告
    ARCSAdWillLeaveApplication,//将要离开App

    ARCSAdVideoStart,//开始播放 常用于video
    ARCSAdVideoComplete,//播放完成 常用于video
    ARCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    ARCSAdVideoServerFail,//连接服务器成功，常用于fb video

    ARCSAdNativeDidDownload,//下载完成 常用于fb Native
    ARCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    ARCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    ARCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    ARCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    ARCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    ARCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    ARCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    ARCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    ARCSAdBUOpenDidAutoDimiss,//开屏自动消失
    ARCSAdBUOpenRenderSuccess, //渲染成功
    ARCSAdBUOpenRenderFail, //渲染失败
    ARCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    ARCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    ARCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    ARCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    ARCSAdDidPresentFullScreen,//插屏弹出全屏广告
    ARCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    ARCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    ARCSAdPlayerStatusStarted,//开始播放
    ARCSAdPlayerStatusPaused,//用户行为导致暂停
    ARCSAdPlayerStatusStoped,//播放停止
    ARCSAdPlayerStatusError,//播放出错
    ARCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    ARCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    ARCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    ARCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    ARCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    ARCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    ARCSAdRecordImpression, //广告曝光已记录
    ARCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    ARCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    ARCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    ARCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    ARCSAdABUOpenWillPresentFullScreen,
    ARCSAdABUOpenDidShowFailed,
    ARCSAdABUOpenWillDissmissFullScreen,
    ARCSAdABUOpenCountdownToZero,
    
    ARCSAdABUBannerWillPresentFullScreen,
    ARCSAdABUBannerWillDismissFullScreen,
    
    ARCSAdABURewardDidLoad,
    ARCSAdABURewardRenderFail,
    ARCSAdABURewardDidShowFailed,

} ARCSAdEvent;

typedef void (^ARCSAdLoadCompleteBlock)(ARCSAdLoadStatus adLoadStatus);

@class ARCSAdSetupParamsMaker;
@class ARCSAdSetupParams;

typedef ARCSAdSetupParamsMaker *(^ARCSAdStringInit)(NSString *);
typedef ARCSAdSetupParamsMaker *(^ARCSAdBoolInit)(BOOL);
typedef ARCSAdSetupParamsMaker *(^ARCSAdIntegerInit)(NSInteger);
typedef ARCSAdSetupParamsMaker *(^ARCSAdLongInit)(long);
typedef ARCSAdSetupParamsMaker *(^ARCSAdArrayInit)(NSArray *);
typedef ARCSAdSetupParams *(^ARCSAdMakeInit)(void);


@class ARCSAdDataModel;
typedef void (^ARCSAdRequestCompleteBlock)(NSMutableArray<ARCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^ARCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^ARCSAdPreloadCompleteBlock)(ARCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
