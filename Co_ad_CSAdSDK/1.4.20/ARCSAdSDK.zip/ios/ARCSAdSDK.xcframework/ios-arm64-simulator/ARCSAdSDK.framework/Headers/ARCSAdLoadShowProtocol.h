//
//  ARCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "ARCSAdTypedef.h"

@class ARCSAdLoadBase;

@protocol ARCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol ARCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)aRonAdShowed:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)aRonAdClicked:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)aRonAdClosed:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)aRonAdVideoCompletePlaying:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)aRonAdVideoGotReward:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload;
-(void)aRonAdDidPayRevenue:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)aRonAdDidGetEcpm:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)aRonAdShowFail:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)aRonAdOtherEvent:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload event:(ARCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
