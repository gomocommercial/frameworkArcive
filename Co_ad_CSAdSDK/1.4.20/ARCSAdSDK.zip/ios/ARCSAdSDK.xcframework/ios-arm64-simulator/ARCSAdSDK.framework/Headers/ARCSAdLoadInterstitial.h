//
//  ARCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "ARCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface ARCSAdLoadInterstitial : ARCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
