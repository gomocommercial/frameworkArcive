//
//  ARCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define aRkAdvDataSourceFacebook   2 //FB 广告数据源
#define aRkAdvDataSourceAdmob      8 //Admob 广告数据源
#define aRkAdvDataSourceMopub      39//Mopub 广告数据源
#define aRkAdvDataSourceApplovin   20//applovin 广告数据源

#define aRkAdvDataSourceGDT        62//广点通 广告数据源
#define aRkAdvDataSourceBaidu      63//百度 广告数据源
#define aRkAdvDataSourceBU         64//头条 广告数据源
#define aRkAdvDataSourceABU         70//头条聚合 广告数据源
#define aRkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define aRkAdvDataSourcePangle     74//pangle 广告数据源
#define aRkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define aRkOnlineAdvTypeBanner                   1  //banner
#define aRkOnlineAdvTypeInterstitial             2  //全屏
#define aRkOnlineAdvTypeNative                   3 //native
#define aRkOnlineAdvTypeVideo                    4 //视频
#define aRkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define aRkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define aRkOnlineAdvTypeOpen                     8 //开屏
#define aRkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define aRkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define aRkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define aRkAdServerConfigError  -1 //服务器返回数据不正确
#define aRkAdLoadConfigFailed  -2 //广告加载失败


#define aRAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define aRkCSAdInstallDays @"aRkCSAdInstallDays"
#define aRkCSAdModule_key @"aRkCSAdModule_key_%@"
#define aRkCSNewAdModule_key @"aRkCSNewAdModule_key_%@"
#define aRkCSAdInstallTime @"aRkCSAdInstallTime"
#define aRkCSAdInstallHours @"aRkCSAdInstallHours"
#define aRkCSAdLastGetServerTime @"aRkCSAdLastRequestTime"
#define aRkCSAdloadTime 30

#define aRkCSLoadAdTimeOutNotification @"aRKCSLoadAdTimeOutNotification"
#define aRkCSLoadAdTimeOutNotificationKey @"aRKCSLoadAdTimeOutKey"

