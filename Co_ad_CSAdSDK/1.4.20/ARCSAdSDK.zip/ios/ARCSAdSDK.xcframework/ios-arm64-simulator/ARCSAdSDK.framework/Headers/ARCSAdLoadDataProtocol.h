//
//  ARCSAdLoadDataProtocol.h
//  ARCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "ARCSAdTypedef.h"

@class ARCSAdDataModel;
@class ARCSAdLoadBase;

@protocol ARCSAdLoadProtocol;

@protocol ARCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)aRonAdInfoFinish:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)aRonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)aRonAdFail:(ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
