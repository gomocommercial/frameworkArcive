//
//  ARCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "ARCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface ARCSAdLoadNative : ARCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
