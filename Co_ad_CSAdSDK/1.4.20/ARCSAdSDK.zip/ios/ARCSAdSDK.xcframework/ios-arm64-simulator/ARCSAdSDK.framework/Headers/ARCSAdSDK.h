//
//  ARCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "ARCSAdLoadBase.h"
#import "ARCSAdDataModel.h"
#import "ARCSAdLoadProtocol.h"
#import "ARCSAdLoadDataProtocol.h"
#import "ARCSAdLoadShowProtocol.h"
#import "ARCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface ARCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)aRsetupByBlock:(void (^ _Nonnull)(ARCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)aRloadAd:(NSString *)moduleId delegate:(id<ARCSAdLoadDataProtocol>)delegate;

+ (void)aRloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<ARCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)aRadShowStatistic:(ARCSAdDataModel *)dataModel adload:(nonnull ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)aRadClickStatistic:(ARCSAdDataModel *)dataModel adload:(nonnull ARCSAdLoadBase<ARCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)aRaddCustomFecher:(Class<ARCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
