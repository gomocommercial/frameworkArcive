//
//  ARCSAdNetworkTool.h
//  ARCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "ARCSAdDataModel.h"
#import "ARCSAdTypedef.h"
#import "ARCSNewStoreLiteRequestTool.h"
#import "NSString+ARCSGenerateHash.h"

@interface ARCSAdNetworkTool : NSObject

+ (ARCSAdNetworkTool *)shared;
@property(nonatomic, copy) ARCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)aRrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(ARCSAdRequestCompleteBlock)complete;

- (void)aRsetCDay:(void(^ _Nullable)(bool success))handle;
@end
