//
//  ARCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "ARCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface ARCSAdLoadOpen : ARCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
