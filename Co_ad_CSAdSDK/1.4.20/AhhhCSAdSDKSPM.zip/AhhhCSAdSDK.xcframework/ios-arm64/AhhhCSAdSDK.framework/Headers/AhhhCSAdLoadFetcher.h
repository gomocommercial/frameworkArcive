//
//  AhhhCSAdLoadFetcher.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <Foundation/Foundation.h>
#import "AhhhCSAdLoadProtocol.h"
#import "AhhhCSAdLoadBase.h"


@class AhhhCSAdDataModel;

@interface AhhhCSAdLoadFetcher : NSObject

+ (instancetype)sharedInstance;

- (void)ahhhaddFetcher:(Class<AhhhCSAdLoadProtocol>)fetcher;

+ (AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> * _Nullable)ahhhgetInstance:(AhhhCSAdDataModel *)model;

@end

