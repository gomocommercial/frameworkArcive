//
//  HPFCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "HPFCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadOpen : HPFCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
