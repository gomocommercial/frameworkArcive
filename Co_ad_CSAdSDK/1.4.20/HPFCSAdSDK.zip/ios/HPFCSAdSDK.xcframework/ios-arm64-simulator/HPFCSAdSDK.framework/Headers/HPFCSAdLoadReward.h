//
//  HPFCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "HPFCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadReward : HPFCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
