//
//  HPFCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define hPFkAdvDataSourceFacebook   2 //FB 广告数据源
#define hPFkAdvDataSourceAdmob      8 //Admob 广告数据源
#define hPFkAdvDataSourceMopub      39//Mopub 广告数据源
#define hPFkAdvDataSourceApplovin   20//applovin 广告数据源

#define hPFkAdvDataSourceGDT        62//广点通 广告数据源
#define hPFkAdvDataSourceBaidu      63//百度 广告数据源
#define hPFkAdvDataSourceBU         64//头条 广告数据源
#define hPFkAdvDataSourceABU         70//头条聚合 广告数据源
#define hPFkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define hPFkAdvDataSourcePangle     74//pangle 广告数据源
#define hPFkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define hPFkOnlineAdvTypeBanner                   1  //banner
#define hPFkOnlineAdvTypeInterstitial             2  //全屏
#define hPFkOnlineAdvTypeNative                   3 //native
#define hPFkOnlineAdvTypeVideo                    4 //视频
#define hPFkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define hPFkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define hPFkOnlineAdvTypeOpen                     8 //开屏
#define hPFkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define hPFkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define hPFkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define hPFkAdServerConfigError  -1 //服务器返回数据不正确
#define hPFkAdLoadConfigFailed  -2 //广告加载失败


#define hPFAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define hPFkCSAdInstallDays @"hPFkCSAdInstallDays"
#define hPFkCSAdModule_key @"hPFkCSAdModule_key_%@"
#define hPFkCSNewAdModule_key @"hPFkCSNewAdModule_key_%@"
#define hPFkCSAdInstallTime @"hPFkCSAdInstallTime"
#define hPFkCSAdInstallHours @"hPFkCSAdInstallHours"
#define hPFkCSAdLastGetServerTime @"hPFkCSAdLastRequestTime"
#define hPFkCSAdloadTime 30

#define hPFkCSLoadAdTimeOutNotification @"hPFKCSLoadAdTimeOutNotification"
#define hPFkCSLoadAdTimeOutNotificationKey @"hPFKCSLoadAdTimeOutKey"

