//
//  HPFCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "HPFCSAdLoadBase.h"
#import "HPFCSAdDataModel.h"
#import "HPFCSAdLoadProtocol.h"
#import "HPFCSAdLoadDataProtocol.h"
#import "HPFCSAdLoadShowProtocol.h"
#import "HPFCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)hPFsetupByBlock:(void (^ _Nonnull)(HPFCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)hPFloadAd:(NSString *)moduleId delegate:(id<HPFCSAdLoadDataProtocol>)delegate;

+ (void)hPFloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<HPFCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)hPFadShowStatistic:(HPFCSAdDataModel *)dataModel adload:(nonnull HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)hPFadClickStatistic:(HPFCSAdDataModel *)dataModel adload:(nonnull HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)hPFaddCustomFecher:(Class<HPFCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
