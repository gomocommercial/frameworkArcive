//
//  HPFCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    HPFCSAdLoadSuccess = 1,
    HPFCSAdLoadFailure = -1,
    HPFCSAdLoadTimeout = -2
} HPFCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    HPFCSAdPreloadSuccess = 1,
    //预加载失败
    HPFCSAdPreloadFailure = -1,
    //重复加载
    HPFCSAdPreloadRepeat = -2,
} HPFCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    HPFCSAdWillAppear,//即将出现
    HPFCSAdDidAppear,//已经出现
    HPFCSAdWillDisappear,//即将消失
    HPFCSAdDidDisappear,//已经消失
    HPFCSAdMuted,//静音广告
    HPFCSAdWillLeaveApplication,//将要离开App

    HPFCSAdVideoStart,//开始播放 常用于video
    HPFCSAdVideoComplete,//播放完成 常用于video
    HPFCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    HPFCSAdVideoServerFail,//连接服务器成功，常用于fb video

    HPFCSAdNativeDidDownload,//下载完成 常用于fb Native
    HPFCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    HPFCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    HPFCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    HPFCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    HPFCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    HPFCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    HPFCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    HPFCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    HPFCSAdBUOpenDidAutoDimiss,//开屏自动消失
    HPFCSAdBUOpenRenderSuccess, //渲染成功
    HPFCSAdBUOpenRenderFail, //渲染失败
    HPFCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    HPFCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    HPFCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    HPFCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    HPFCSAdDidPresentFullScreen,//插屏弹出全屏广告
    HPFCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    HPFCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    HPFCSAdPlayerStatusStarted,//开始播放
    HPFCSAdPlayerStatusPaused,//用户行为导致暂停
    HPFCSAdPlayerStatusStoped,//播放停止
    HPFCSAdPlayerStatusError,//播放出错
    HPFCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    HPFCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    HPFCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    HPFCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    HPFCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    HPFCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    HPFCSAdRecordImpression, //广告曝光已记录
    HPFCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    HPFCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    HPFCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    HPFCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    HPFCSAdABUOpenWillPresentFullScreen,
    HPFCSAdABUOpenDidShowFailed,
    HPFCSAdABUOpenWillDissmissFullScreen,
    HPFCSAdABUOpenCountdownToZero,
    
    HPFCSAdABUBannerWillPresentFullScreen,
    HPFCSAdABUBannerWillDismissFullScreen,
    
    HPFCSAdABURewardDidLoad,
    HPFCSAdABURewardRenderFail,
    HPFCSAdABURewardDidShowFailed,

} HPFCSAdEvent;

typedef void (^HPFCSAdLoadCompleteBlock)(HPFCSAdLoadStatus adLoadStatus);

@class HPFCSAdSetupParamsMaker;
@class HPFCSAdSetupParams;

typedef HPFCSAdSetupParamsMaker *(^HPFCSAdStringInit)(NSString *);
typedef HPFCSAdSetupParamsMaker *(^HPFCSAdBoolInit)(BOOL);
typedef HPFCSAdSetupParamsMaker *(^HPFCSAdIntegerInit)(NSInteger);
typedef HPFCSAdSetupParamsMaker *(^HPFCSAdLongInit)(long);
typedef HPFCSAdSetupParamsMaker *(^HPFCSAdArrayInit)(NSArray *);
typedef HPFCSAdSetupParams *(^HPFCSAdMakeInit)(void);


@class HPFCSAdDataModel;
typedef void (^HPFCSAdRequestCompleteBlock)(NSMutableArray<HPFCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^HPFCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^HPFCSAdPreloadCompleteBlock)(HPFCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
