//
//  HPFCSAdLoadDataProtocol.h
//  HPFCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "HPFCSAdTypedef.h"

@class HPFCSAdDataModel;
@class HPFCSAdLoadBase;

@protocol HPFCSAdLoadProtocol;

@protocol HPFCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)hPFonAdInfoFinish:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)hPFonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)hPFonAdFail:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
