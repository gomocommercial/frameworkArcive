//
//  HPFCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "HPFCSAdTypedef.h"

@class HPFCSAdLoadBase;

@protocol HPFCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol HPFCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)hPFonAdShowed:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)hPFonAdClicked:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)hPFonAdClosed:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)hPFonAdVideoCompletePlaying:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)hPFonAdVideoGotReward:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload;
-(void)hPFonAdDidPayRevenue:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)hPFonAdDidGetEcpm:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)hPFonAdShowFail:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)hPFonAdOtherEvent:(HPFCSAdLoadBase<HPFCSAdLoadProtocol> *)adload event:(HPFCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
