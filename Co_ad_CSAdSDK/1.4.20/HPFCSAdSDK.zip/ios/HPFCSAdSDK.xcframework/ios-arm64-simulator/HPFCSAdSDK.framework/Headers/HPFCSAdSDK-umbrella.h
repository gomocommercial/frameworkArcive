#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "HPFCSAdSDK.h"
#import "HPFCSAdPreload.h"
#import "HPFCSAdLoadDataProtocol.h"
#import "HPFCSAdLoadShowProtocol.h"
#import "HPFCSAdLoadProtocol.h"
#import "HPFCSAdLoadBase.h"
#import "HPFCSAdLoadInterstitial.h"
#import "HPFCSAdLoadNative.h"
#import "HPFCSAdLoadReward.h"
#import "HPFCSAdLoadOpen.h"
#import "HPFCSAdLoadBanner.h"
#import "HPFCSAdManager.h"
#import "HPFCSAdSetupParams.h"
#import "HPFCSAdSetupParamsMaker.h"
#import "HPFCSAdDefine.h"
#import "HPFCSAdTypedef.h"
#import "HPFCSAdStatistics.h"
#import "HPFCSAdDataModel.h"
#import "HPFCSAdNetworkTool.h"
#import "HPFCSNewStoreLiteRequestTool.h"
#import "NSString+HPFCSGenerateHash.h"

FOUNDATION_EXPORT double HPFCSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char HPFCSAdSDKVersionString[];

