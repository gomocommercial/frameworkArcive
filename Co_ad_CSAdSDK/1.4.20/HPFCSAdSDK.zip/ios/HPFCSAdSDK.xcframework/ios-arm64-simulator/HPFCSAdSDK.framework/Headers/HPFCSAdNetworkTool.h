//
//  HPFCSAdNetworkTool.h
//  HPFCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "HPFCSAdDataModel.h"
#import "HPFCSAdTypedef.h"
#import "HPFCSNewStoreLiteRequestTool.h"
#import "NSString+HPFCSGenerateHash.h"

@interface HPFCSAdNetworkTool : NSObject

+ (HPFCSAdNetworkTool *)shared;
@property(nonatomic, copy) HPFCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)hPFrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(HPFCSAdRequestCompleteBlock)complete;

- (void)hPFsetCDay:(void(^ _Nullable)(bool success))handle;
@end
