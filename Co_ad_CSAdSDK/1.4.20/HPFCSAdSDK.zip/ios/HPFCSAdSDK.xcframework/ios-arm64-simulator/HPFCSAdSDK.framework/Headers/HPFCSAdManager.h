//
//  HPFCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HPFCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)hPFloadAd:(NSString *)moduleId delegate:(id<HPFCSAdLoadDataProtocol>)delegate;

- (void)hPFloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<HPFCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)hPFremoveData:(id)obj;
- (NSDictionary *)getDevicesInfo;

@end

NS_ASSUME_NONNULL_END
