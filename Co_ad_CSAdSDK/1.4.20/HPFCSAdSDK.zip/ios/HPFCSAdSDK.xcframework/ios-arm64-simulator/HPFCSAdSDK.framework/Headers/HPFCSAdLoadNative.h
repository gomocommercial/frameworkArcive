//
//  HPFCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "HPFCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadNative : HPFCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
