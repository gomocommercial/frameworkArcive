//
//  UCLCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    UCLCSAdLoadSuccess = 1,
    UCLCSAdLoadFailure = -1,
    UCLCSAdLoadTimeout = -2
} UCLCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    UCLCSAdPreloadSuccess = 1,
    //预加载失败
    UCLCSAdPreloadFailure = -1,
    //重复加载
    UCLCSAdPreloadRepeat = -2,
} UCLCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    UCLCSAdWillAppear,//即将出现
    UCLCSAdDidAppear,//已经出现
    UCLCSAdWillDisappear,//即将消失
    UCLCSAdDidDisappear,//已经消失
    UCLCSAdMuted,//静音广告
    UCLCSAdWillLeaveApplication,//将要离开App

    UCLCSAdVideoStart,//开始播放 常用于video
    UCLCSAdVideoComplete,//播放完成 常用于video
    UCLCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    UCLCSAdVideoServerFail,//连接服务器成功，常用于fb video

    UCLCSAdNativeDidDownload,//下载完成 常用于fb Native
    UCLCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    UCLCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    UCLCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    UCLCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    UCLCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    UCLCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    UCLCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    UCLCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    UCLCSAdBUOpenDidAutoDimiss,//开屏自动消失
    UCLCSAdBUOpenRenderSuccess, //渲染成功
    UCLCSAdBUOpenRenderFail, //渲染失败
    UCLCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    UCLCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    UCLCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    UCLCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    UCLCSAdDidPresentFullScreen,//插屏弹出全屏广告
    UCLCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    UCLCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    UCLCSAdPlayerStatusStarted,//开始播放
    UCLCSAdPlayerStatusPaused,//用户行为导致暂停
    UCLCSAdPlayerStatusStoped,//播放停止
    UCLCSAdPlayerStatusError,//播放出错
    UCLCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    UCLCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    UCLCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    UCLCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    UCLCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    UCLCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    UCLCSAdRecordImpression, //广告曝光已记录
    UCLCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    UCLCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    UCLCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    UCLCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    UCLCSAdABUOpenWillPresentFullScreen,
    UCLCSAdABUOpenDidShowFailed,
    UCLCSAdABUOpenWillDissmissFullScreen,
    UCLCSAdABUOpenCountdownToZero,
    
    UCLCSAdABUBannerWillPresentFullScreen,
    UCLCSAdABUBannerWillDismissFullScreen,
    
    UCLCSAdABURewardDidLoad,
    UCLCSAdABURewardRenderFail,
    UCLCSAdABURewardDidShowFailed,

} UCLCSAdEvent;

typedef void (^UCLCSAdLoadCompleteBlock)(UCLCSAdLoadStatus adLoadStatus);

@class UCLCSAdSetupParamsMaker;
@class UCLCSAdSetupParams;

typedef UCLCSAdSetupParamsMaker *(^UCLCSAdStringInit)(NSString *);
typedef UCLCSAdSetupParamsMaker *(^UCLCSAdBoolInit)(BOOL);
typedef UCLCSAdSetupParamsMaker *(^UCLCSAdIntegerInit)(NSInteger);
typedef UCLCSAdSetupParamsMaker *(^UCLCSAdLongInit)(long);
typedef UCLCSAdSetupParamsMaker *(^UCLCSAdArrayInit)(NSArray *);
typedef UCLCSAdSetupParams *(^UCLCSAdMakeInit)(void);


@class UCLCSAdDataModel;
typedef void (^UCLCSAdRequestCompleteBlock)(NSMutableArray<UCLCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^UCLCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^UCLCSAdPreloadCompleteBlock)(UCLCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
