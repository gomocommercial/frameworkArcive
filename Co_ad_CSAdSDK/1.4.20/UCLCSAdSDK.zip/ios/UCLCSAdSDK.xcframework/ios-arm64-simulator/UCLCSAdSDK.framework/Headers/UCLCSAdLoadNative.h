//
//  UCLCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "UCLCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface UCLCSAdLoadNative : UCLCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
