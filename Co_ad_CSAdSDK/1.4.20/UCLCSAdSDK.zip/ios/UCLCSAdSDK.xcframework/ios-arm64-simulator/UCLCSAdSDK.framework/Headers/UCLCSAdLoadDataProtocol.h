//
//  UCLCSAdLoadDataProtocol.h
//  UCLCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "UCLCSAdTypedef.h"

@class UCLCSAdDataModel;
@class UCLCSAdLoadBase;

@protocol UCLCSAdLoadProtocol;

@protocol UCLCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)uCLonAdInfoFinish:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)uCLonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)uCLonAdFail:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
