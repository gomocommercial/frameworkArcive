//
//  UCLCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "UCLCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface UCLCSAdLoadOpen : UCLCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
