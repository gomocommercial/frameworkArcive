//
//  UCLCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define uCLkAdvDataSourceFacebook   2 //FB 广告数据源
#define uCLkAdvDataSourceAdmob      8 //Admob 广告数据源
#define uCLkAdvDataSourceMopub      39//Mopub 广告数据源
#define uCLkAdvDataSourceApplovin   20//applovin 广告数据源

#define uCLkAdvDataSourceGDT        62//广点通 广告数据源
#define uCLkAdvDataSourceBaidu      63//百度 广告数据源
#define uCLkAdvDataSourceBU         64//头条 广告数据源
#define uCLkAdvDataSourceABU         70//头条聚合 广告数据源
#define uCLkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define uCLkAdvDataSourcePangle     74//pangle 广告数据源
#define uCLkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define uCLkOnlineAdvTypeBanner                   1  //banner
#define uCLkOnlineAdvTypeInterstitial             2  //全屏
#define uCLkOnlineAdvTypeNative                   3 //native
#define uCLkOnlineAdvTypeVideo                    4 //视频
#define uCLkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define uCLkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define uCLkOnlineAdvTypeOpen                     8 //开屏
#define uCLkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define uCLkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define uCLkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define uCLkAdServerConfigError  -1 //服务器返回数据不正确
#define uCLkAdLoadConfigFailed  -2 //广告加载失败


#define uCLAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define uCLkCSAdInstallDays @"uCLkCSAdInstallDays"
#define uCLkCSAdModule_key @"uCLkCSAdModule_key_%@"
#define uCLkCSNewAdModule_key @"uCLkCSNewAdModule_key_%@"
#define uCLkCSAdInstallTime @"uCLkCSAdInstallTime"
#define uCLkCSAdInstallHours @"uCLkCSAdInstallHours"
#define uCLkCSAdLastGetServerTime @"uCLkCSAdLastRequestTime"
#define uCLkCSAdloadTime 30

#define uCLkCSLoadAdTimeOutNotification @"uCLKCSLoadAdTimeOutNotification"
#define uCLkCSLoadAdTimeOutNotificationKey @"uCLKCSLoadAdTimeOutKey"

