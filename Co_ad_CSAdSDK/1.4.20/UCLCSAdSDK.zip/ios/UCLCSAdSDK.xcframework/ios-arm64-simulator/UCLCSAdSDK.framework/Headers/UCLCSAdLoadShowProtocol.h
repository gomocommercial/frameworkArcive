//
//  UCLCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "UCLCSAdTypedef.h"

@class UCLCSAdLoadBase;

@protocol UCLCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol UCLCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)uCLonAdShowed:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)uCLonAdClicked:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)uCLonAdClosed:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)uCLonAdVideoCompletePlaying:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)uCLonAdVideoGotReward:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload;
-(void)uCLonAdDidPayRevenue:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)uCLonAdDidGetEcpm:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)uCLonAdShowFail:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)uCLonAdOtherEvent:(UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload event:(UCLCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
