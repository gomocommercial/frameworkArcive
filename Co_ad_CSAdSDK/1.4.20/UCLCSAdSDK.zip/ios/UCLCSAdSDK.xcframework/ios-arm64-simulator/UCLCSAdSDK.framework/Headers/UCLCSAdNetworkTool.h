//
//  UCLCSAdNetworkTool.h
//  UCLCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "UCLCSAdDataModel.h"
#import "UCLCSAdTypedef.h"
#import "UCLCSNewStoreLiteRequestTool.h"
#import "NSString+UCLCSGenerateHash.h"

@interface UCLCSAdNetworkTool : NSObject

+ (UCLCSAdNetworkTool *)shared;
@property(nonatomic, copy) UCLCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)uCLrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(UCLCSAdRequestCompleteBlock)complete;

- (void)uCLsetCDay:(void(^ _Nullable)(bool success))handle;
@end
