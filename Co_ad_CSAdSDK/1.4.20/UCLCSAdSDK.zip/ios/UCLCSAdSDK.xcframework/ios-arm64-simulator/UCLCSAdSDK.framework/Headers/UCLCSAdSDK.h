//
//  UCLCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "UCLCSAdLoadBase.h"
#import "UCLCSAdDataModel.h"
#import "UCLCSAdLoadProtocol.h"
#import "UCLCSAdLoadDataProtocol.h"
#import "UCLCSAdLoadShowProtocol.h"
#import "UCLCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface UCLCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)uCLsetupByBlock:(void (^ _Nonnull)(UCLCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)uCLloadAd:(NSString *)moduleId delegate:(id<UCLCSAdLoadDataProtocol>)delegate;

+ (void)uCLloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<UCLCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)uCLadShowStatistic:(UCLCSAdDataModel *)dataModel adload:(nonnull UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)uCLadClickStatistic:(UCLCSAdDataModel *)dataModel adload:(nonnull UCLCSAdLoadBase<UCLCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)uCLaddCustomFecher:(Class<UCLCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
