//
//  GACCSAdNetworkTool.h
//  GACCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "GACCSAdDataModel.h"
#import "GACCSAdTypedef.h"
#import "GACCSNewStoreLiteRequestTool.h"
#import "NSString+GACCSGenerateHash.h"

@interface GACCSAdNetworkTool : NSObject

+ (GACCSAdNetworkTool *)shared;
@property(nonatomic, copy) GACCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)gACrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(GACCSAdRequestCompleteBlock)complete;

- (void)gACsetCDay:(void(^ _Nullable)(bool success))handle;
@end
