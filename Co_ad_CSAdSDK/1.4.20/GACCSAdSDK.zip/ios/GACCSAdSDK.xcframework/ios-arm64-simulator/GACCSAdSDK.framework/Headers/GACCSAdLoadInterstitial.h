//
//  GACCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "GACCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadInterstitial : GACCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
