//
//  GACCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "GACCSAdLoadBase.h"
#import "GACCSAdDataModel.h"
#import "GACCSAdLoadProtocol.h"
#import "GACCSAdLoadDataProtocol.h"
#import "GACCSAdLoadShowProtocol.h"
#import "GACCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)gACsetupByBlock:(void (^ _Nonnull)(GACCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)gACloadAd:(NSString *)moduleId delegate:(id<GACCSAdLoadDataProtocol>)delegate;

+ (void)gACloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<GACCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)gACadShowStatistic:(GACCSAdDataModel *)dataModel adload:(nonnull GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)gACadClickStatistic:(GACCSAdDataModel *)dataModel adload:(nonnull GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)gACaddCustomFecher:(Class<GACCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
