//
//  GACCSAdLoadDataProtocol.h
//  GACCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "GACCSAdTypedef.h"

@class GACCSAdDataModel;
@class GACCSAdLoadBase;

@protocol GACCSAdLoadProtocol;

@protocol GACCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)gAConAdInfoFinish:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)gAConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)gAConAdFail:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
