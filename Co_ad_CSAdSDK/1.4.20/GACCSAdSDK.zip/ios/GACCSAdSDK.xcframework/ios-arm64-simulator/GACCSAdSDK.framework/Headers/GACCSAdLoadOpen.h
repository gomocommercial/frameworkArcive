//
//  GACCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "GACCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadOpen : GACCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
