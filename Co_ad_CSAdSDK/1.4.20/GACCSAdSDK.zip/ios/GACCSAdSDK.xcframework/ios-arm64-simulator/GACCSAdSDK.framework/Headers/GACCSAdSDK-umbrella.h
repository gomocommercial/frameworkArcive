#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "GACCSAdSDK.h"
#import "GACCSAdPreload.h"
#import "GACCSAdLoadDataProtocol.h"
#import "GACCSAdLoadShowProtocol.h"
#import "GACCSAdLoadProtocol.h"
#import "GACCSAdLoadBase.h"
#import "GACCSAdLoadInterstitial.h"
#import "GACCSAdLoadNative.h"
#import "GACCSAdLoadReward.h"
#import "GACCSAdLoadOpen.h"
#import "GACCSAdLoadBanner.h"
#import "GACCSAdManager.h"
#import "GACCSAdSetupParams.h"
#import "GACCSAdSetupParamsMaker.h"
#import "GACCSAdDefine.h"
#import "GACCSAdTypedef.h"
#import "GACCSAdStatistics.h"
#import "GACCSAdDataModel.h"
#import "GACCSAdNetworkTool.h"
#import "GACCSNewStoreLiteRequestTool.h"
#import "NSString+GACCSGenerateHash.h"

FOUNDATION_EXPORT double GACCSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char GACCSAdSDKVersionString[];

