//
//  GACCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define gACkAdvDataSourceFacebook   2 //FB 广告数据源
#define gACkAdvDataSourceAdmob      8 //Admob 广告数据源
#define gACkAdvDataSourceMopub      39//Mopub 广告数据源
#define gACkAdvDataSourceApplovin   20//applovin 广告数据源

#define gACkAdvDataSourceGDT        62//广点通 广告数据源
#define gACkAdvDataSourceBaidu      63//百度 广告数据源
#define gACkAdvDataSourceBU         64//头条 广告数据源
#define gACkAdvDataSourceABU         70//头条聚合 广告数据源
#define gACkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define gACkAdvDataSourcePangle     74//pangle 广告数据源
#define gACkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define gACkOnlineAdvTypeBanner                   1  //banner
#define gACkOnlineAdvTypeInterstitial             2  //全屏
#define gACkOnlineAdvTypeNative                   3 //native
#define gACkOnlineAdvTypeVideo                    4 //视频
#define gACkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define gACkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define gACkOnlineAdvTypeOpen                     8 //开屏
#define gACkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define gACkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define gACkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define gACkAdServerConfigError  -1 //服务器返回数据不正确
#define gACkAdLoadConfigFailed  -2 //广告加载失败


#define gACAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define gACkCSAdInstallDays @"gACkCSAdInstallDays"
#define gACkCSAdModule_key @"gACkCSAdModule_key_%@"
#define gACkCSNewAdModule_key @"gACkCSNewAdModule_key_%@"
#define gACkCSAdInstallTime @"gACkCSAdInstallTime"
#define gACkCSAdInstallHours @"gACkCSAdInstallHours"
#define gACkCSAdLastGetServerTime @"gACkCSAdLastRequestTime"
#define gACkCSAdloadTime 30

#define gACkCSLoadAdTimeOutNotification @"gACKCSLoadAdTimeOutNotification"
#define gACkCSLoadAdTimeOutNotificationKey @"gACKCSLoadAdTimeOutKey"

