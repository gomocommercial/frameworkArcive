//
//  GACCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "GACCSAdTypedef.h"

@class GACCSAdLoadBase;

@protocol GACCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol GACCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)gAConAdShowed:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)gAConAdClicked:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)gAConAdClosed:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)gAConAdVideoCompletePlaying:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)gAConAdVideoGotReward:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload;
-(void)gAConAdDidPayRevenue:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)gAConAdDidGetEcpm:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)gAConAdShowFail:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)gAConAdOtherEvent:(GACCSAdLoadBase<GACCSAdLoadProtocol> *)adload event:(GACCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
