//
//  GACCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    GACCSAdLoadSuccess = 1,
    GACCSAdLoadFailure = -1,
    GACCSAdLoadTimeout = -2
} GACCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    GACCSAdPreloadSuccess = 1,
    //预加载失败
    GACCSAdPreloadFailure = -1,
    //重复加载
    GACCSAdPreloadRepeat = -2,
} GACCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    GACCSAdWillAppear,//即将出现
    GACCSAdDidAppear,//已经出现
    GACCSAdWillDisappear,//即将消失
    GACCSAdDidDisappear,//已经消失
    GACCSAdMuted,//静音广告
    GACCSAdWillLeaveApplication,//将要离开App

    GACCSAdVideoStart,//开始播放 常用于video
    GACCSAdVideoComplete,//播放完成 常用于video
    GACCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    GACCSAdVideoServerFail,//连接服务器成功，常用于fb video

    GACCSAdNativeDidDownload,//下载完成 常用于fb Native
    GACCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    GACCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    GACCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    GACCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    GACCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    GACCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    GACCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    GACCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    GACCSAdBUOpenDidAutoDimiss,//开屏自动消失
    GACCSAdBUOpenRenderSuccess, //渲染成功
    GACCSAdBUOpenRenderFail, //渲染失败
    GACCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    GACCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    GACCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    GACCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    GACCSAdDidPresentFullScreen,//插屏弹出全屏广告
    GACCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    GACCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    GACCSAdPlayerStatusStarted,//开始播放
    GACCSAdPlayerStatusPaused,//用户行为导致暂停
    GACCSAdPlayerStatusStoped,//播放停止
    GACCSAdPlayerStatusError,//播放出错
    GACCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    GACCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    GACCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    GACCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    GACCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    GACCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    GACCSAdRecordImpression, //广告曝光已记录
    GACCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    GACCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    GACCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    GACCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    GACCSAdABUOpenWillPresentFullScreen,
    GACCSAdABUOpenDidShowFailed,
    GACCSAdABUOpenWillDissmissFullScreen,
    GACCSAdABUOpenCountdownToZero,
    
    GACCSAdABUBannerWillPresentFullScreen,
    GACCSAdABUBannerWillDismissFullScreen,
    
    GACCSAdABURewardDidLoad,
    GACCSAdABURewardRenderFail,
    GACCSAdABURewardDidShowFailed,

} GACCSAdEvent;

typedef void (^GACCSAdLoadCompleteBlock)(GACCSAdLoadStatus adLoadStatus);

@class GACCSAdSetupParamsMaker;
@class GACCSAdSetupParams;

typedef GACCSAdSetupParamsMaker *(^GACCSAdStringInit)(NSString *);
typedef GACCSAdSetupParamsMaker *(^GACCSAdBoolInit)(BOOL);
typedef GACCSAdSetupParamsMaker *(^GACCSAdIntegerInit)(NSInteger);
typedef GACCSAdSetupParamsMaker *(^GACCSAdLongInit)(long);
typedef GACCSAdSetupParamsMaker *(^GACCSAdArrayInit)(NSArray *);
typedef GACCSAdSetupParams *(^GACCSAdMakeInit)(void);


@class GACCSAdDataModel;
typedef void (^GACCSAdRequestCompleteBlock)(NSMutableArray<GACCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^GACCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^GACCSAdPreloadCompleteBlock)(GACCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
