//
//  LSTCSAdLoadDataProtocol.h
//  LSTCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "LSTCSAdTypedef.h"

@class LSTCSAdDataModel;
@class LSTCSAdLoadBase;

@protocol LSTCSAdLoadProtocol;

@protocol LSTCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)lSTonAdInfoFinish:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)lSTonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)lSTonAdFail:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
