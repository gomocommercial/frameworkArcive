//
//  LSTCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    LSTCSAdLoadSuccess = 1,
    LSTCSAdLoadFailure = -1,
    LSTCSAdLoadTimeout = -2
} LSTCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    LSTCSAdPreloadSuccess = 1,
    //预加载失败
    LSTCSAdPreloadFailure = -1,
    //重复加载
    LSTCSAdPreloadRepeat = -2,
} LSTCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    LSTCSAdWillAppear,//即将出现
    LSTCSAdDidAppear,//已经出现
    LSTCSAdWillDisappear,//即将消失
    LSTCSAdDidDisappear,//已经消失
    LSTCSAdMuted,//静音广告
    LSTCSAdWillLeaveApplication,//将要离开App

    LSTCSAdVideoStart,//开始播放 常用于video
    LSTCSAdVideoComplete,//播放完成 常用于video
    LSTCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    LSTCSAdVideoServerFail,//连接服务器成功，常用于fb video

    LSTCSAdNativeDidDownload,//下载完成 常用于fb Native
    LSTCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    LSTCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    LSTCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    LSTCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    LSTCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    LSTCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    LSTCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    LSTCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    LSTCSAdBUOpenDidAutoDimiss,//开屏自动消失
    LSTCSAdBUOpenRenderSuccess, //渲染成功
    LSTCSAdBUOpenRenderFail, //渲染失败
    LSTCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    LSTCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    LSTCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    LSTCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    LSTCSAdDidPresentFullScreen,//插屏弹出全屏广告
    LSTCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    LSTCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    LSTCSAdPlayerStatusStarted,//开始播放
    LSTCSAdPlayerStatusPaused,//用户行为导致暂停
    LSTCSAdPlayerStatusStoped,//播放停止
    LSTCSAdPlayerStatusError,//播放出错
    LSTCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    LSTCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    LSTCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    LSTCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    LSTCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    LSTCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    LSTCSAdRecordImpression, //广告曝光已记录
    LSTCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    LSTCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    LSTCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    LSTCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    LSTCSAdABUOpenWillPresentFullScreen,
    LSTCSAdABUOpenDidShowFailed,
    LSTCSAdABUOpenWillDissmissFullScreen,
    LSTCSAdABUOpenCountdownToZero,
    
    LSTCSAdABUBannerWillPresentFullScreen,
    LSTCSAdABUBannerWillDismissFullScreen,
    
    LSTCSAdABURewardDidLoad,
    LSTCSAdABURewardRenderFail,
    LSTCSAdABURewardDidShowFailed,

} LSTCSAdEvent;

typedef void (^LSTCSAdLoadCompleteBlock)(LSTCSAdLoadStatus adLoadStatus);

@class LSTCSAdSetupParamsMaker;
@class LSTCSAdSetupParams;

typedef LSTCSAdSetupParamsMaker *(^LSTCSAdStringInit)(NSString *);
typedef LSTCSAdSetupParamsMaker *(^LSTCSAdBoolInit)(BOOL);
typedef LSTCSAdSetupParamsMaker *(^LSTCSAdIntegerInit)(NSInteger);
typedef LSTCSAdSetupParamsMaker *(^LSTCSAdLongInit)(long);
typedef LSTCSAdSetupParamsMaker *(^LSTCSAdArrayInit)(NSArray *);
typedef LSTCSAdSetupParams *(^LSTCSAdMakeInit)(void);


@class LSTCSAdDataModel;
typedef void (^LSTCSAdRequestCompleteBlock)(NSMutableArray<LSTCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^LSTCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^LSTCSAdPreloadCompleteBlock)(LSTCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
