//
//  LSTCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LSTCSAdTypedef.h"

@class LSTCSAdLoadBase;

@protocol LSTCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LSTCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lSTonAdShowed:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)lSTonAdClicked:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lSTonAdClosed:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lSTonAdVideoCompletePlaying:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)lSTonAdVideoGotReward:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload;
-(void)lSTonAdDidPayRevenue:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)lSTonAdDidGetEcpm:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)lSTonAdShowFail:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lSTonAdOtherEvent:(LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload event:(LSTCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
