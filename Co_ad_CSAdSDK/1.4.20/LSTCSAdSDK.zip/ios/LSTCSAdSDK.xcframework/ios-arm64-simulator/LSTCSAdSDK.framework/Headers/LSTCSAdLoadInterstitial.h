//
//  LSTCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LSTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadInterstitial : LSTCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
