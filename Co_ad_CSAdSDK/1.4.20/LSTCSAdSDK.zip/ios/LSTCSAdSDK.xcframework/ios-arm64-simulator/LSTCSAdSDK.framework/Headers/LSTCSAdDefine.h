//
//  LSTCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lSTkAdvDataSourceFacebook   2 //FB 广告数据源
#define lSTkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lSTkAdvDataSourceMopub      39//Mopub 广告数据源
#define lSTkAdvDataSourceApplovin   20//applovin 广告数据源

#define lSTkAdvDataSourceGDT        62//广点通 广告数据源
#define lSTkAdvDataSourceBaidu      63//百度 广告数据源
#define lSTkAdvDataSourceBU         64//头条 广告数据源
#define lSTkAdvDataSourceABU         70//头条聚合 广告数据源
#define lSTkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define lSTkAdvDataSourcePangle     74//pangle 广告数据源
#define lSTkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define lSTkOnlineAdvTypeBanner                   1  //banner
#define lSTkOnlineAdvTypeInterstitial             2  //全屏
#define lSTkOnlineAdvTypeNative                   3 //native
#define lSTkOnlineAdvTypeVideo                    4 //视频
#define lSTkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define lSTkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define lSTkOnlineAdvTypeOpen                     8 //开屏
#define lSTkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define lSTkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define lSTkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define lSTkAdServerConfigError  -1 //服务器返回数据不正确
#define lSTkAdLoadConfigFailed  -2 //广告加载失败


#define lSTAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lSTkCSAdInstallDays @"lSTkCSAdInstallDays"
#define lSTkCSAdModule_key @"lSTkCSAdModule_key_%@"
#define lSTkCSNewAdModule_key @"lSTkCSNewAdModule_key_%@"
#define lSTkCSAdInstallTime @"lSTkCSAdInstallTime"
#define lSTkCSAdInstallHours @"lSTkCSAdInstallHours"
#define lSTkCSAdLastGetServerTime @"lSTkCSAdLastRequestTime"
#define lSTkCSAdloadTime 30

#define lSTkCSLoadAdTimeOutNotification @"lSTKCSLoadAdTimeOutNotification"
#define lSTkCSLoadAdTimeOutNotificationKey @"lSTKCSLoadAdTimeOutKey"

