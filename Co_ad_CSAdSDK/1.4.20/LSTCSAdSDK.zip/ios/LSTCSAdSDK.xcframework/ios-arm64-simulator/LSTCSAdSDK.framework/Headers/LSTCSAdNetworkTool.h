//
//  LSTCSAdNetworkTool.h
//  LSTCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "LSTCSAdDataModel.h"
#import "LSTCSAdTypedef.h"
#import "LSTCSNewStoreLiteRequestTool.h"
#import "NSString+LSTCSGenerateHash.h"

@interface LSTCSAdNetworkTool : NSObject

+ (LSTCSAdNetworkTool *)shared;
@property(nonatomic, copy) LSTCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)lSTrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(LSTCSAdRequestCompleteBlock)complete;

- (void)lSTsetCDay:(void(^ _Nullable)(bool success))handle;
@end
