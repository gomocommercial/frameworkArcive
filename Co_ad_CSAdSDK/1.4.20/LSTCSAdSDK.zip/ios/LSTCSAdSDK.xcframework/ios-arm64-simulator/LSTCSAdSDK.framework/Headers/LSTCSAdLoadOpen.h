//
//  LSTCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "LSTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadOpen : LSTCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
