//
//  NSString+LSTCSGenerateHash.h
//  AFNetworking
//
//  Created by zhangxin on 2022/4/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (LSTCSGenerateHash)
- (NSString *)hmacSHA256StrAndBase64WithKey:(NSString *)key;
- (NSString *)UrlSafeStr;
- (NSString *)reverseSafeUrlString;
@end

NS_ASSUME_NONNULL_END
