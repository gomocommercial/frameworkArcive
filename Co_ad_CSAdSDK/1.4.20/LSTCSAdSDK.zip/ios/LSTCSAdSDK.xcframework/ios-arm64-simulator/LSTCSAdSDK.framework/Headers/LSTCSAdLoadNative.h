//
//  LSTCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LSTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadNative : LSTCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
