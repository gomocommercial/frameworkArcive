//
//  LSTCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "LSTCSAdLoadBase.h"
#import "LSTCSAdDataModel.h"
#import "LSTCSAdLoadProtocol.h"
#import "LSTCSAdLoadDataProtocol.h"
#import "LSTCSAdLoadShowProtocol.h"
#import "LSTCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)lSTsetupByBlock:(void (^ _Nonnull)(LSTCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)lSTloadAd:(NSString *)moduleId delegate:(id<LSTCSAdLoadDataProtocol>)delegate;

+ (void)lSTloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<LSTCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)lSTadShowStatistic:(LSTCSAdDataModel *)dataModel adload:(nonnull LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)lSTadClickStatistic:(LSTCSAdDataModel *)dataModel adload:(nonnull LSTCSAdLoadBase<LSTCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)lSTaddCustomFecher:(Class<LSTCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
