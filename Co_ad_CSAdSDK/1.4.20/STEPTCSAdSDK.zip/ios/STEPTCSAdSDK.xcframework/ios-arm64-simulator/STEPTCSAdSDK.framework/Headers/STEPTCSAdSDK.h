//
//  STEPTCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "STEPTCSAdLoadBase.h"
#import "STEPTCSAdDataModel.h"
#import "STEPTCSAdLoadProtocol.h"
#import "STEPTCSAdLoadDataProtocol.h"
#import "STEPTCSAdLoadShowProtocol.h"
#import "STEPTCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)sTEPTsetupByBlock:(void (^ _Nonnull)(STEPTCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)sTEPTloadAd:(NSString *)moduleId delegate:(id<STEPTCSAdLoadDataProtocol>)delegate;

+ (void)sTEPTloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<STEPTCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)sTEPTadShowStatistic:(STEPTCSAdDataModel *)dataModel adload:(nonnull STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)sTEPTadClickStatistic:(STEPTCSAdDataModel *)dataModel adload:(nonnull STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)sTEPTaddCustomFecher:(Class<STEPTCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
