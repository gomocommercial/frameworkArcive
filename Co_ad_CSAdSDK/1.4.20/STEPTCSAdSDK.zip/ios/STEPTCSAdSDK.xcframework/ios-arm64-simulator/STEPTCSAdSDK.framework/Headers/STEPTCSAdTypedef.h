//
//  STEPTCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    STEPTCSAdLoadSuccess = 1,
    STEPTCSAdLoadFailure = -1,
    STEPTCSAdLoadTimeout = -2
} STEPTCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    STEPTCSAdPreloadSuccess = 1,
    //预加载失败
    STEPTCSAdPreloadFailure = -1,
    //重复加载
    STEPTCSAdPreloadRepeat = -2,
} STEPTCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    STEPTCSAdWillAppear,//即将出现
    STEPTCSAdDidAppear,//已经出现
    STEPTCSAdWillDisappear,//即将消失
    STEPTCSAdDidDisappear,//已经消失
    STEPTCSAdMuted,//静音广告
    STEPTCSAdWillLeaveApplication,//将要离开App

    STEPTCSAdVideoStart,//开始播放 常用于video
    STEPTCSAdVideoComplete,//播放完成 常用于video
    STEPTCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    STEPTCSAdVideoServerFail,//连接服务器成功，常用于fb video

    STEPTCSAdNativeDidDownload,//下载完成 常用于fb Native
    STEPTCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    STEPTCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    STEPTCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    STEPTCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    STEPTCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    STEPTCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    STEPTCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    STEPTCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    STEPTCSAdBUOpenDidAutoDimiss,//开屏自动消失
    STEPTCSAdBUOpenRenderSuccess, //渲染成功
    STEPTCSAdBUOpenRenderFail, //渲染失败
    STEPTCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    STEPTCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    STEPTCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    STEPTCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    STEPTCSAdDidPresentFullScreen,//插屏弹出全屏广告
    STEPTCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    STEPTCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    STEPTCSAdPlayerStatusStarted,//开始播放
    STEPTCSAdPlayerStatusPaused,//用户行为导致暂停
    STEPTCSAdPlayerStatusStoped,//播放停止
    STEPTCSAdPlayerStatusError,//播放出错
    STEPTCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    STEPTCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    STEPTCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    STEPTCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    STEPTCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    STEPTCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    STEPTCSAdRecordImpression, //广告曝光已记录
    STEPTCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    STEPTCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    STEPTCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    STEPTCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    STEPTCSAdABUOpenWillPresentFullScreen,
    STEPTCSAdABUOpenDidShowFailed,
    STEPTCSAdABUOpenWillDissmissFullScreen,
    STEPTCSAdABUOpenCountdownToZero,
    
    STEPTCSAdABUBannerWillPresentFullScreen,
    STEPTCSAdABUBannerWillDismissFullScreen,
    
    STEPTCSAdABURewardDidLoad,
    STEPTCSAdABURewardRenderFail,
    STEPTCSAdABURewardDidShowFailed,

} STEPTCSAdEvent;

typedef void (^STEPTCSAdLoadCompleteBlock)(STEPTCSAdLoadStatus adLoadStatus);

@class STEPTCSAdSetupParamsMaker;
@class STEPTCSAdSetupParams;

typedef STEPTCSAdSetupParamsMaker *(^STEPTCSAdStringInit)(NSString *);
typedef STEPTCSAdSetupParamsMaker *(^STEPTCSAdBoolInit)(BOOL);
typedef STEPTCSAdSetupParamsMaker *(^STEPTCSAdIntegerInit)(NSInteger);
typedef STEPTCSAdSetupParamsMaker *(^STEPTCSAdLongInit)(long);
typedef STEPTCSAdSetupParamsMaker *(^STEPTCSAdArrayInit)(NSArray *);
typedef STEPTCSAdSetupParams *(^STEPTCSAdMakeInit)(void);


@class STEPTCSAdDataModel;
typedef void (^STEPTCSAdRequestCompleteBlock)(NSMutableArray<STEPTCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^STEPTCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^STEPTCSAdPreloadCompleteBlock)(STEPTCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
