//
//  STEPTCSAdLoadDataProtocol.h
//  STEPTCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "STEPTCSAdTypedef.h"

@class STEPTCSAdDataModel;
@class STEPTCSAdLoadBase;

@protocol STEPTCSAdLoadProtocol;

@protocol STEPTCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)sTEPTonAdInfoFinish:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)sTEPTonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)sTEPTonAdFail:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
