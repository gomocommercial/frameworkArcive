//
//  STEPTCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sTEPTkAdvDataSourceFacebook   2 //FB 广告数据源
#define sTEPTkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sTEPTkAdvDataSourceMopub      39//Mopub 广告数据源
#define sTEPTkAdvDataSourceApplovin   20//applovin 广告数据源

#define sTEPTkAdvDataSourceGDT        62//广点通 广告数据源
#define sTEPTkAdvDataSourceBaidu      63//百度 广告数据源
#define sTEPTkAdvDataSourceBU         64//头条 广告数据源
#define sTEPTkAdvDataSourceABU         70//头条聚合 广告数据源
#define sTEPTkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define sTEPTkAdvDataSourcePangle     74//pangle 广告数据源
#define sTEPTkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define sTEPTkOnlineAdvTypeBanner                   1  //banner
#define sTEPTkOnlineAdvTypeInterstitial             2  //全屏
#define sTEPTkOnlineAdvTypeNative                   3 //native
#define sTEPTkOnlineAdvTypeVideo                    4 //视频
#define sTEPTkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sTEPTkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sTEPTkOnlineAdvTypeOpen                     8 //开屏
#define sTEPTkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define sTEPTkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define sTEPTkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define sTEPTkAdServerConfigError  -1 //服务器返回数据不正确
#define sTEPTkAdLoadConfigFailed  -2 //广告加载失败


#define sTEPTAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sTEPTkCSAdInstallDays @"sTEPTkCSAdInstallDays"
#define sTEPTkCSAdModule_key @"sTEPTkCSAdModule_key_%@"
#define sTEPTkCSNewAdModule_key @"sTEPTkCSNewAdModule_key_%@"
#define sTEPTkCSAdInstallTime @"sTEPTkCSAdInstallTime"
#define sTEPTkCSAdInstallHours @"sTEPTkCSAdInstallHours"
#define sTEPTkCSAdLastGetServerTime @"sTEPTkCSAdLastRequestTime"
#define sTEPTkCSAdloadTime 30

#define sTEPTkCSLoadAdTimeOutNotification @"sTEPTKCSLoadAdTimeOutNotification"
#define sTEPTkCSLoadAdTimeOutNotificationKey @"sTEPTKCSLoadAdTimeOutKey"

