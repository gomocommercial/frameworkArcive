//
//  TRCCSAdNetworkTool.h
//  TRCCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "TRCCSAdDataModel.h"
#import "TRCCSAdTypedef.h"
#import "TRCCSNewStoreLiteRequestTool.h"
#import "NSString+TRCCSGenerateHash.h"

@interface TRCCSAdNetworkTool : NSObject

+ (TRCCSAdNetworkTool *)shared;
@property(nonatomic, copy) TRCCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)tRCrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(TRCCSAdRequestCompleteBlock)complete;

- (void)tRCsetCDay:(void(^ _Nullable)(bool success))handle;
@end
