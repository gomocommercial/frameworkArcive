//
//  TRCCSAdLoadDataProtocol.h
//  TRCCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "TRCCSAdTypedef.h"

@class TRCCSAdDataModel;
@class TRCCSAdLoadBase;

@protocol TRCCSAdLoadProtocol;

@protocol TRCCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)tRConAdInfoFinish:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)tRConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)tRConAdFail:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
