//
//  TRCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "TRCCSAdTypedef.h"

@class TRCCSAdLoadBase;

@protocol TRCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol TRCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)tRConAdShowed:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)tRConAdClicked:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)tRConAdClosed:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)tRConAdVideoCompletePlaying:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)tRConAdVideoGotReward:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload;
-(void)tRConAdDidPayRevenue:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)tRConAdDidGetEcpm:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)tRConAdShowFail:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)tRConAdOtherEvent:(TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload event:(TRCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
