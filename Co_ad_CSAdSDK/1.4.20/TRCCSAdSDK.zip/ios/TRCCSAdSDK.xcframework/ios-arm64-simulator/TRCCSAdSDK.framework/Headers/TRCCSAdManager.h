//
//  TRCCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TRCCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface TRCCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)tRCloadAd:(NSString *)moduleId delegate:(id<TRCCSAdLoadDataProtocol>)delegate;

- (void)tRCloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<TRCCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)tRCremoveData:(id)obj;
- (NSDictionary *)getDevicesInfo;

@end

NS_ASSUME_NONNULL_END
