//
//  TRCCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TRCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCCSAdLoadReward : TRCCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
