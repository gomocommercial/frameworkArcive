//
//  TRCCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "TRCCSAdLoadBase.h"
#import "TRCCSAdDataModel.h"
#import "TRCCSAdLoadProtocol.h"
#import "TRCCSAdLoadDataProtocol.h"
#import "TRCCSAdLoadShowProtocol.h"
#import "TRCCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)tRCsetupByBlock:(void (^ _Nonnull)(TRCCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)tRCloadAd:(NSString *)moduleId delegate:(id<TRCCSAdLoadDataProtocol>)delegate;

+ (void)tRCloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<TRCCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)tRCadShowStatistic:(TRCCSAdDataModel *)dataModel adload:(nonnull TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)tRCadClickStatistic:(TRCCSAdDataModel *)dataModel adload:(nonnull TRCCSAdLoadBase<TRCCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)tRCaddCustomFecher:(Class<TRCCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
