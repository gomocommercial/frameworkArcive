//
//  TRCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tRCkAdvDataSourceFacebook   2 //FB 广告数据源
#define tRCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define tRCkAdvDataSourceMopub      39//Mopub 广告数据源
#define tRCkAdvDataSourceApplovin   20//applovin 广告数据源

#define tRCkAdvDataSourceGDT        62//广点通 广告数据源
#define tRCkAdvDataSourceBaidu      63//百度 广告数据源
#define tRCkAdvDataSourceBU         64//头条 广告数据源
#define tRCkAdvDataSourceABU         70//头条聚合 广告数据源
#define tRCkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define tRCkAdvDataSourcePangle     74//pangle 广告数据源
#define tRCkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define tRCkOnlineAdvTypeBanner                   1  //banner
#define tRCkOnlineAdvTypeInterstitial             2  //全屏
#define tRCkOnlineAdvTypeNative                   3 //native
#define tRCkOnlineAdvTypeVideo                    4 //视频
#define tRCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define tRCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define tRCkOnlineAdvTypeOpen                     8 //开屏
#define tRCkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define tRCkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define tRCkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define tRCkAdServerConfigError  -1 //服务器返回数据不正确
#define tRCkAdLoadConfigFailed  -2 //广告加载失败


#define tRCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tRCkCSAdInstallDays @"tRCkCSAdInstallDays"
#define tRCkCSAdModule_key @"tRCkCSAdModule_key_%@"
#define tRCkCSNewAdModule_key @"tRCkCSNewAdModule_key_%@"
#define tRCkCSAdInstallTime @"tRCkCSAdInstallTime"
#define tRCkCSAdInstallHours @"tRCkCSAdInstallHours"
#define tRCkCSAdLastGetServerTime @"tRCkCSAdLastRequestTime"
#define tRCkCSAdloadTime 30

#define tRCkCSLoadAdTimeOutNotification @"tRCKCSLoadAdTimeOutNotification"
#define tRCkCSLoadAdTimeOutNotificationKey @"tRCKCSLoadAdTimeOutKey"

