//
//  TRCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TRCCSAdLoadSuccess = 1,
    TRCCSAdLoadFailure = -1,
    TRCCSAdLoadTimeout = -2
} TRCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TRCCSAdPreloadSuccess = 1,
    //预加载失败
    TRCCSAdPreloadFailure = -1,
    //重复加载
    TRCCSAdPreloadRepeat = -2,
} TRCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TRCCSAdWillAppear,//即将出现
    TRCCSAdDidAppear,//已经出现
    TRCCSAdWillDisappear,//即将消失
    TRCCSAdDidDisappear,//已经消失
    TRCCSAdMuted,//静音广告
    TRCCSAdWillLeaveApplication,//将要离开App

    TRCCSAdVideoStart,//开始播放 常用于video
    TRCCSAdVideoComplete,//播放完成 常用于video
    TRCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TRCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    TRCCSAdNativeDidDownload,//下载完成 常用于fb Native
    TRCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TRCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    TRCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    TRCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    TRCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    TRCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    TRCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    TRCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    TRCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    TRCCSAdBUOpenRenderSuccess, //渲染成功
    TRCCSAdBUOpenRenderFail, //渲染失败
    TRCCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    TRCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    TRCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    TRCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    TRCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    TRCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    TRCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    TRCCSAdPlayerStatusStarted,//开始播放
    TRCCSAdPlayerStatusPaused,//用户行为导致暂停
    TRCCSAdPlayerStatusStoped,//播放停止
    TRCCSAdPlayerStatusError,//播放出错
    TRCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    TRCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    TRCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    TRCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    TRCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    TRCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    TRCCSAdRecordImpression, //广告曝光已记录
    TRCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    TRCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    TRCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    TRCCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    TRCCSAdABUOpenWillPresentFullScreen,
    TRCCSAdABUOpenDidShowFailed,
    TRCCSAdABUOpenWillDissmissFullScreen,
    TRCCSAdABUOpenCountdownToZero,
    
    TRCCSAdABUBannerWillPresentFullScreen,
    TRCCSAdABUBannerWillDismissFullScreen,
    
    TRCCSAdABURewardDidLoad,
    TRCCSAdABURewardRenderFail,
    TRCCSAdABURewardDidShowFailed,

} TRCCSAdEvent;

typedef void (^TRCCSAdLoadCompleteBlock)(TRCCSAdLoadStatus adLoadStatus);

@class TRCCSAdSetupParamsMaker;
@class TRCCSAdSetupParams;

typedef TRCCSAdSetupParamsMaker *(^TRCCSAdStringInit)(NSString *);
typedef TRCCSAdSetupParamsMaker *(^TRCCSAdBoolInit)(BOOL);
typedef TRCCSAdSetupParamsMaker *(^TRCCSAdIntegerInit)(NSInteger);
typedef TRCCSAdSetupParamsMaker *(^TRCCSAdLongInit)(long);
typedef TRCCSAdSetupParamsMaker *(^TRCCSAdArrayInit)(NSArray *);
typedef TRCCSAdSetupParams *(^TRCCSAdMakeInit)(void);


@class TRCCSAdDataModel;
typedef void (^TRCCSAdRequestCompleteBlock)(NSMutableArray<TRCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TRCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TRCCSAdPreloadCompleteBlock)(TRCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
