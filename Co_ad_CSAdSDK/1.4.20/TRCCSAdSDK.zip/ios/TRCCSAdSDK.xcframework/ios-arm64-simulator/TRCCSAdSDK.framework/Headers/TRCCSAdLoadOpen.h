//
//  TRCCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "TRCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCCSAdLoadOpen : TRCCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
