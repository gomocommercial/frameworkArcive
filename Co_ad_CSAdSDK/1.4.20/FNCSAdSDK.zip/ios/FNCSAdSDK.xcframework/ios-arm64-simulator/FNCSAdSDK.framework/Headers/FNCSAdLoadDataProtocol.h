//
//  FNCSAdLoadDataProtocol.h
//  FNCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "FNCSAdTypedef.h"

@class FNCSAdDataModel;
@class FNCSAdLoadBase;

@protocol FNCSAdLoadProtocol;

@protocol FNCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)fNonAdInfoFinish:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)fNonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)fNonAdFail:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
