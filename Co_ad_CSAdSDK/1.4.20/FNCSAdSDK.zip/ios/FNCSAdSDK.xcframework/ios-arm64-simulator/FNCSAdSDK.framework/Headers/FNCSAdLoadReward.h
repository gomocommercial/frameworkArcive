//
//  FNCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "FNCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNCSAdLoadReward : FNCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
