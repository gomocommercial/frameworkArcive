//
//  FNCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define fNkAdvDataSourceFacebook   2 //FB 广告数据源
#define fNkAdvDataSourceAdmob      8 //Admob 广告数据源
#define fNkAdvDataSourceMopub      39//Mopub 广告数据源
#define fNkAdvDataSourceApplovin   20//applovin 广告数据源

#define fNkAdvDataSourceGDT        62//广点通 广告数据源
#define fNkAdvDataSourceBaidu      63//百度 广告数据源
#define fNkAdvDataSourceBU         64//头条 广告数据源
#define fNkAdvDataSourceABU         70//头条聚合 广告数据源
#define fNkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define fNkAdvDataSourcePangle     74//pangle 广告数据源
#define fNkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define fNkOnlineAdvTypeBanner                   1  //banner
#define fNkOnlineAdvTypeInterstitial             2  //全屏
#define fNkOnlineAdvTypeNative                   3 //native
#define fNkOnlineAdvTypeVideo                    4 //视频
#define fNkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define fNkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define fNkOnlineAdvTypeOpen                     8 //开屏
#define fNkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define fNkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define fNkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define fNkAdServerConfigError  -1 //服务器返回数据不正确
#define fNkAdLoadConfigFailed  -2 //广告加载失败


#define fNAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define fNkCSAdInstallDays @"fNkCSAdInstallDays"
#define fNkCSAdModule_key @"fNkCSAdModule_key_%@"
#define fNkCSNewAdModule_key @"fNkCSNewAdModule_key_%@"
#define fNkCSAdInstallTime @"fNkCSAdInstallTime"
#define fNkCSAdInstallHours @"fNkCSAdInstallHours"
#define fNkCSAdLastGetServerTime @"fNkCSAdLastRequestTime"
#define fNkCSAdloadTime 30

#define fNkCSLoadAdTimeOutNotification @"fNKCSLoadAdTimeOutNotification"
#define fNkCSLoadAdTimeOutNotificationKey @"fNKCSLoadAdTimeOutKey"

