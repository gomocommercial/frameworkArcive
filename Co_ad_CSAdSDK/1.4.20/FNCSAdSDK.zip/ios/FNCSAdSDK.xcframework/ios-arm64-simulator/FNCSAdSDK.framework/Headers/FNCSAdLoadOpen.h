//
//  FNCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "FNCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNCSAdLoadOpen : FNCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
