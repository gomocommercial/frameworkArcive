//
//  EDCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "EDCSAdTypedef.h"

@class EDCSAdLoadBase;

@protocol EDCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol EDCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)eDonAdShowed:(EDCSAdLoadBase<EDCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)eDonAdClicked:(EDCSAdLoadBase<EDCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)eDonAdClosed:(EDCSAdLoadBase<EDCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)eDonAdVideoCompletePlaying:(EDCSAdLoadBase<EDCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)eDonAdShowFail:(EDCSAdLoadBase<EDCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)eDonAdOtherEvent:(EDCSAdLoadBase<EDCSAdLoadProtocol> *)adload event:(EDCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
