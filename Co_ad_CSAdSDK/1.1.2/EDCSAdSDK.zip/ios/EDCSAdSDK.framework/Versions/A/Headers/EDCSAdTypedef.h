//
//  EDCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    EDCSAdLoadSuccess = 1,
    EDCSAdLoadFailure = -1,
    EDCSAdLoadTimeout = -2
} EDCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    EDCSAdPreloadSuccess = 1,
    //预加载失败
    EDCSAdPreloadFailure = -1,
    //重复加载
    EDCSAdPreloadRepeat = -2,
} EDCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    EDCSAdWillAppear,//即将出现
    EDCSAdDidAppear,//已经出现
    EDCSAdWillDisappear,//即将消失
    EDCSAdDidDisappear,//已经消失
    EDCSAdMuted,//静音广告
    EDCSAdWillLeaveApplication,//将要离开App

    EDCSAdVideoStart,//开始播放 常用于video
    EDCSAdVideoComplete,//播放完成 常用于video
    EDCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    EDCSAdVideoServerFail,//连接服务器成功，常用于fb video

    EDCSAdNativeDidDownload,//下载完成 常用于fb Native
    EDCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    EDCSAdDidExpire //已到期 常用于mopub interstitial 和 rewardVideo
} EDCSAdEvent;

typedef void (^EDCSAdLoadCompleteBlock)(EDCSAdLoadStatus adLoadStatus);

@class EDCSAdSetupParamsMaker;
@class EDCSAdSetupParams;

typedef EDCSAdSetupParamsMaker *(^EDCSAdStringInit)(NSString *);
typedef EDCSAdSetupParamsMaker *(^EDCSAdBoolInit)(BOOL);
typedef EDCSAdSetupParamsMaker *(^EDCSAdIntegerInit)(NSInteger);
typedef EDCSAdSetupParamsMaker *(^EDCSAdLongInit)(long);
typedef EDCSAdSetupParamsMaker *(^EDCSAdArrayInit)(NSArray *);
typedef EDCSAdSetupParams *(^EDCSAdMakeInit)(void);


@class EDCSAdDataModel;
typedef void (^EDCSAdRequestCompleteBlock)(NSMutableArray<EDCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^EDCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^EDCSAdPreloadCompleteBlock)(EDCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
