//
//  EDCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "EDCSAdLoadBase.h"
#import "EDCSAdDataModel.h"
#import "EDCSAdLoadProtocol.h"
#import "EDCSAdLoadDataProtocol.h"
#import "EDCSAdLoadShowProtocol.h"
#import "EDCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface EDCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)eDsetupByBlock:(void (^ _Nonnull)(EDCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)eDloadAd:(NSString *)moduleId delegate:(id<EDCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)eDadShowStatistic:(EDCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)eDadClickStatistic:(EDCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)eDaddCustomFecher:(Class<EDCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
