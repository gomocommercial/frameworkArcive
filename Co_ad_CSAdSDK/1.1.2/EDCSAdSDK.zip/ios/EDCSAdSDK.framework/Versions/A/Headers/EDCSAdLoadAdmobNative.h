//
//  EDCSAdLoadAdmobNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import "EDCSAdLoadNative.h"
#import <GoogleMobileAds/GoogleMobileAds.h>
#import "EDCSAdLoadProtocol.h"
#import "EDCSAdLoadShowProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface EDCSAdLoadAdmobNative : EDCSAdLoadNative<EDCSAdLoadProtocol,GADUnifiedNativeAdLoaderDelegate, GADUnifiedNativeAdDelegate>

@property (nonatomic, strong) GADUnifiedNativeAd * ad;

@end

NS_ASSUME_NONNULL_END
