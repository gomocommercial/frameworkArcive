//
//  EDCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define eDkAdvDataSourceFacebook   2 //FB 广告数据源
#define eDkAdvDataSourceAdmob      8 //Admob 广告数据源
#define eDkAdvDataSourceMopub      39//Mopub 广告数据源

#define eDkOnlineAdvTypeBanner           1  //banner
#define eDkOnlineAdvTypeInterstitial     2  //全屏
#define eDkOnlineAdvTypeNative           3 //native
#define eDkOnlineAdvTypeVideo            4 //视频
#define eDkOnlineAdvTypeMinBanner        5 //banner(300*250)

#define eDkAdServerConfigError  -1 //服务器返回数据不正确
#define eDkAdLoadConfigFailed  -2 //广告加载失败


#define eDAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define eDkCSAdInstallDays @"eDkCSAdInstallDays"
#define eDkCSAdModule_key @"eDkCSAdModule_key_%@"
#define eDkCSAdInstallTime @"eDkCSAdInstallTime"
#define eDkCSAdLastGetServerTime @"eDkCSAdLastRequestTime"
#define eDkCSAdloadTime 30

 
