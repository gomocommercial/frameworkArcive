//
//  SVCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SVCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

static NSMutableArray * sVadmobRewardLoadList;
static NSMutableArray * sVfbRewardLoadList;

@interface SVCSAdLoadReward : SVCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
