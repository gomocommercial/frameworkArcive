//
//  SVCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    SVCSAdLoadSuccess = 1,
    SVCSAdLoadFailure = -1,
    SVCSAdLoadTimeout = -2
} SVCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    SVCSAdPreloadSuccess = 1,
    //预加载失败
    SVCSAdPreloadFailure = -1,
    //重复加载
    SVCSAdPreloadRepeat = -2,
} SVCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    SVCSAdWillAppear,//即将出现
    SVCSAdDidAppear,//已经出现
    SVCSAdWillDisappear,//即将消失
    SVCSAdDidDisappear,//已经消失
    SVCSAdMuted,//静音广告
    SVCSAdWillLeaveApplication,//将要离开App

    SVCSAdVideoStart,//开始播放 常用于video
    SVCSAdVideoComplete,//播放完成 常用于video
    SVCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    SVCSAdVideoServerFail,//连接服务器成功，常用于fb video

    SVCSAdNativeDidDownload,//下载完成 常用于fb Native
    SVCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    SVCSAdDidExpire //已到期 常用于mopub interstitial 和 rewardVideo
} SVCSAdEvent;

typedef void (^SVCSAdLoadCompleteBlock)(SVCSAdLoadStatus adLoadStatus);

@class SVCSAdSetupParamsMaker;
@class SVCSAdSetupParams;

typedef SVCSAdSetupParamsMaker *(^SVCSAdStringInit)(NSString *);
typedef SVCSAdSetupParamsMaker *(^SVCSAdBoolInit)(BOOL);
typedef SVCSAdSetupParamsMaker *(^SVCSAdIntegerInit)(NSInteger);
typedef SVCSAdSetupParamsMaker *(^SVCSAdLongInit)(long);
typedef SVCSAdSetupParamsMaker *(^SVCSAdArrayInit)(NSArray *);
typedef SVCSAdSetupParams *(^SVCSAdMakeInit)(void);


@class SVCSAdDataModel;
typedef void (^SVCSAdRequestCompleteBlock)(NSMutableArray<SVCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^SVCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^SVCSAdPreloadCompleteBlock)(SVCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
