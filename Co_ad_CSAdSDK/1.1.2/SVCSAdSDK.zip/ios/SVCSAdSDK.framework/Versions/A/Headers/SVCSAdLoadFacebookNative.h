//
//  SVCSAdLoadFacebookNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import "SVCSAdLoadNative.h"
#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import "SVCSAdLoadProtocol.h"
#import "SVCSAdLoadShowProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface SVCSAdLoadFacebookNative : SVCSAdLoadNative<SVCSAdLoadProtocol,FBNativeAdDelegate>

@property(strong, nonatomic) FBNativeAd *ad;

@end

NS_ASSUME_NONNULL_END
