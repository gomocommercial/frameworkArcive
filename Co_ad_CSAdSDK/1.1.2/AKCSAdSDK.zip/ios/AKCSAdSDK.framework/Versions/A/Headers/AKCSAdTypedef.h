//
//  AKCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    AKCSAdLoadSuccess = 1,
    AKCSAdLoadFailure = -1,
    AKCSAdLoadTimeout = -2
} AKCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    AKCSAdPreloadSuccess = 1,
    //预加载失败
    AKCSAdPreloadFailure = -1,
    //重复加载
    AKCSAdPreloadRepeat = -2,
} AKCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    AKCSAdWillAppear,//即将出现
    AKCSAdDidAppear,//已经出现
    AKCSAdWillDisappear,//即将消失
    AKCSAdDidDisappear,//已经消失
    AKCSAdMuted,//静音广告
    AKCSAdWillLeaveApplication,//将要离开App

    AKCSAdVideoStart,//开始播放 常用于video
    AKCSAdVideoComplete,//播放完成 常用于video
    AKCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    AKCSAdVideoServerFail,//连接服务器成功，常用于fb video

    AKCSAdNativeDidDownload,//下载完成 常用于fb Native
    AKCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    AKCSAdDidExpire //已到期 常用于mopub interstitial 和 rewardVideo
} AKCSAdEvent;

typedef void (^AKCSAdLoadCompleteBlock)(AKCSAdLoadStatus adLoadStatus);

@class AKCSAdSetupParamsMaker;
@class AKCSAdSetupParams;

typedef AKCSAdSetupParamsMaker *(^AKCSAdStringInit)(NSString *);
typedef AKCSAdSetupParamsMaker *(^AKCSAdBoolInit)(BOOL);
typedef AKCSAdSetupParamsMaker *(^AKCSAdIntegerInit)(NSInteger);
typedef AKCSAdSetupParamsMaker *(^AKCSAdLongInit)(long);
typedef AKCSAdSetupParamsMaker *(^AKCSAdArrayInit)(NSArray *);
typedef AKCSAdSetupParams *(^AKCSAdMakeInit)(void);


@class AKCSAdDataModel;
typedef void (^AKCSAdRequestCompleteBlock)(NSMutableArray<AKCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^AKCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^AKCSAdPreloadCompleteBlock)(AKCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
