//
//  AKCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define aKkAdvDataSourceFacebook   2 //FB 广告数据源
#define aKkAdvDataSourceAdmob      8 //Admob 广告数据源
#define aKkAdvDataSourceMopub      39//Mopub 广告数据源

#define aKkOnlineAdvTypeBanner           1  //banner
#define aKkOnlineAdvTypeInterstitial     2  //全屏
#define aKkOnlineAdvTypeNative           3 //native
#define aKkOnlineAdvTypeVideo            4 //视频
#define aKkOnlineAdvTypeMinBanner        5 //banner(300*250)

#define aKkAdServerConfigError  -1 //服务器返回数据不正确
#define aKkAdLoadConfigFailed  -2 //广告加载失败


#define aKAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define aKkCSAdInstallDays @"aKkCSAdInstallDays"
#define aKkCSAdModule_key @"aKkCSAdModule_key_%@"
#define aKkCSAdInstallTime @"aKkCSAdInstallTime"
#define aKkCSAdLastGetServerTime @"aKkCSAdLastRequestTime"
#define aKkCSAdloadTime 30

 
