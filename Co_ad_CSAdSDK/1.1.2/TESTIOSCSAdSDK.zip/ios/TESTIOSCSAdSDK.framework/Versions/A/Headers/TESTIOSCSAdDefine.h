//
//  TESTIOSCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tESTIOSkAdvDataSourceFacebook   2 //FB 广告数据源
#define tESTIOSkAdvDataSourceAdmob      8 //Admob 广告数据源
#define tESTIOSkAdvDataSourceMopub      39//Mopub 广告数据源

#define tESTIOSkOnlineAdvTypeBanner           1  //banner
#define tESTIOSkOnlineAdvTypeInterstitial     2  //全屏
#define tESTIOSkOnlineAdvTypeNative           3 //native
#define tESTIOSkOnlineAdvTypeVideo            4 //视频
#define tESTIOSkOnlineAdvTypeMinBanner        5 //banner(300*250)

#define tESTIOSkAdServerConfigError  -1 //服务器返回数据不正确
#define tESTIOSkAdLoadConfigFailed  -2 //广告加载失败


#define tESTIOSAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tESTIOSkCSAdInstallDays @"tESTIOSkCSAdInstallDays"
#define tESTIOSkCSAdModule_key @"tESTIOSkCSAdModule_key_%@"
#define tESTIOSkCSAdInstallTime @"tESTIOSkCSAdInstallTime"
#define tESTIOSkCSAdLastGetServerTime @"tESTIOSkCSAdLastRequestTime"
#define tESTIOSkCSAdloadTime 30

 
