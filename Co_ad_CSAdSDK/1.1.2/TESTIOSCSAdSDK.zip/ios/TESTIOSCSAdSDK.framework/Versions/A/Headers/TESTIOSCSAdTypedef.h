//
//  TESTIOSCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TESTIOSCSAdLoadSuccess = 1,
    TESTIOSCSAdLoadFailure = -1,
    TESTIOSCSAdLoadTimeout = -2
} TESTIOSCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TESTIOSCSAdPreloadSuccess = 1,
    //预加载失败
    TESTIOSCSAdPreloadFailure = -1,
    //重复加载
    TESTIOSCSAdPreloadRepeat = -2,
} TESTIOSCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TESTIOSCSAdWillAppear,//即将出现
    TESTIOSCSAdDidAppear,//已经出现
    TESTIOSCSAdWillDisappear,//即将消失
    TESTIOSCSAdDidDisappear,//已经消失
    TESTIOSCSAdMuted,//静音广告
    TESTIOSCSAdWillLeaveApplication,//将要离开App

    TESTIOSCSAdVideoStart,//开始播放 常用于video
    TESTIOSCSAdVideoComplete,//播放完成 常用于video
    TESTIOSCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TESTIOSCSAdVideoServerFail,//连接服务器成功，常用于fb video

    TESTIOSCSAdNativeDidDownload,//下载完成 常用于fb Native
    TESTIOSCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TESTIOSCSAdDidExpire //已到期 常用于mopub interstitial 和 rewardVideo
} TESTIOSCSAdEvent;

typedef void (^TESTIOSCSAdLoadCompleteBlock)(TESTIOSCSAdLoadStatus adLoadStatus);

@class TESTIOSCSAdSetupParamsMaker;
@class TESTIOSCSAdSetupParams;

typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdStringInit)(NSString *);
typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdBoolInit)(BOOL);
typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdIntegerInit)(NSInteger);
typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdLongInit)(long);
typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdArrayInit)(NSArray *);
typedef TESTIOSCSAdSetupParams *(^TESTIOSCSAdMakeInit)(void);


@class TESTIOSCSAdDataModel;
typedef void (^TESTIOSCSAdRequestCompleteBlock)(NSMutableArray<TESTIOSCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TESTIOSCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TESTIOSCSAdPreloadCompleteBlock)(TESTIOSCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
