//
//  MJCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define mJkAdvDataSourceFacebook   2 //FB 广告数据源
#define mJkAdvDataSourceAdmob      8 //Admob 广告数据源
#define mJkAdvDataSourceMopub      39//Mopub 广告数据源

#define mJkOnlineAdvTypeBanner           1  //banner
#define mJkOnlineAdvTypeInterstitial     2  //全屏
#define mJkOnlineAdvTypeNative           3 //native
#define mJkOnlineAdvTypeVideo            4 //视频
#define mJkOnlineAdvTypeMinBanner        5 //banner(300*250)

#define mJkAdServerConfigError  -1 //服务器返回数据不正确
#define mJkAdLoadConfigFailed  -2 //广告加载失败


#define mJAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define mJkCSAdInstallDays @"mJkCSAdInstallDays"
#define mJkCSAdModule_key @"mJkCSAdModule_key_%@"
#define mJkCSAdInstallTime @"mJkCSAdInstallTime"
#define mJkCSAdLastGetServerTime @"mJkCSAdLastRequestTime"
#define mJkCSAdloadTime 30

 
