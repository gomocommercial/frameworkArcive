//
//  MJCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MJCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MJCSAdLoadInterstitial : MJCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
