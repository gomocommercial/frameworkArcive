//
//  MJCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MJCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

static NSMutableArray * mJadmobRewardLoadList;
static NSMutableArray * mJfbRewardLoadList;

@interface MJCSAdLoadReward : MJCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
