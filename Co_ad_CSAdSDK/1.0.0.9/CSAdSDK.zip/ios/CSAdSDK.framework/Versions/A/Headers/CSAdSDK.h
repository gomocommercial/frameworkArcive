//
//  CSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "CSAdLoadBase.h"
#import "CSAdDataModel.h"
#import "CSAdLoadProtocol.h"
#import "CSAdLoadDataProtocol.h"
#import "CSAdLoadShowProtocol.h"
#import "CSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)setupByBlock:(void (^ _Nonnull)(CSAdSetupParamsMaker *maker))block;

/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)loadAd:(NSString *)moduleId delegate:(id<CSAdLoadDataProtocol>)delegate;

/**
 展示广告统计
 */
+ (void)adShowStatistic:(CSAdDataModel *)dataModel;

/**
 点击广告告统计
 */
+ (void)adClickStatistic:(CSAdDataModel *)dataModel;

//重置所有广告代理(当多个地方同时加载广告时，可重置代理，用于确定代理回调位置)
+ (void)resetAllDelegate:(id<CSAdLoadDataProtocol>) delegate;


// MARK: - 增加自定义广告源
+ (void)addCustomFecher:(Class<CSAdLoadProtocol>)fetcher;
@end

NS_ASSUME_NONNULL_END
