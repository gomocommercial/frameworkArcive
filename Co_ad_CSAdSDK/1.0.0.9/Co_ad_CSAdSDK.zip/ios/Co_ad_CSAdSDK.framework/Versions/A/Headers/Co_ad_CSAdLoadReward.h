//
//  Co_ad_CSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "Co_ad_CSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

static NSMutableArray * co_ad_admobRewardLoadList;
static NSMutableArray * co_ad_fbRewardLoadList;

@interface Co_ad_CSAdLoadReward : Co_ad_CSAdLoadBase

@end

NS_ASSUME_NONNULL_END
