//
//  MEETAICSAdLoadDataProtocol.h
//  MEETAICSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "MEETAICSAdTypedef.h"

@class MEETAICSAdDataModel;
@class MEETAICSAdLoadBase;

@protocol MEETAICSAdLoadProtocol;

@protocol MEETAICSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)mEETAIonAdInfoFinish:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)mEETAIonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)mEETAIonAdFail:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload error:(NSError *)error;
@end
