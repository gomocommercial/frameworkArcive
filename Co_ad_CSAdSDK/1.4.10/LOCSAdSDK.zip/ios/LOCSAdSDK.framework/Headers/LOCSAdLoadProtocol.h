//
//  LOCSAdLoadProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import <UIKit/UIKit.h>
#import "LOCSAdTypedef.h"

@protocol LOCSAdLoadShowProtocol;

@protocol LOCSAdLoadProtocol <NSObject>

@required

/**
 广告源
 */
+ (NSInteger)advdatasource;

/**
 广告类型
 */
+ (NSInteger)onlineadvtype;

/**
 广告是否已准备完成
 */
- (BOOL)isValid;


/// 展示广告
/// 在目标中展示(video或interstitial 为UIViewController,Native无需参数）自定义广告源可根据需要使用
/// 在applivin 中，当设置isShowInCustomerView为true时，traget必须传，false时不需要传
/// - Parameters:
///   - traget: 广告展示的目标视图
///   - delegate: 广告展示的代理方法
- (void)show:(id)traget delegate:(id<LOCSAdLoadShowProtocol>)delegate;


/**
 广告源类名
 */
- (NSString *)adClassName;

/**
 开始加载广告(SDK内部调用,无需外部使用)
 */
- (void)lOloadData:(LOCSAdLoadCompleteBlock) csAdLoadCompleteBlock;
@end

