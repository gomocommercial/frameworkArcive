//
//  LOCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "LOCSAdLoadBase.h"
#import "LOCSAdDataModel.h"
#import "LOCSAdLoadProtocol.h"
#import "LOCSAdLoadDataProtocol.h"
#import "LOCSAdLoadShowProtocol.h"
#import "LOCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)lOsetupByBlock:(void (^ _Nonnull)(LOCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)lOloadAd:(NSString *)moduleId delegate:(id<LOCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)lOadShowStatistic:(LOCSAdDataModel *)dataModel adload:(nonnull LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)lOadClickStatistic:(LOCSAdDataModel *)dataModel adload:(nonnull LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)lOaddCustomFecher:(Class<LOCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
