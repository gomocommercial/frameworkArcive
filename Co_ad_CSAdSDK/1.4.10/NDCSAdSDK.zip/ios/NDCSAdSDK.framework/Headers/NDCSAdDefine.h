//
//  NDCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define nDkAdvDataSourceFacebook   2 //FB 广告数据源
#define nDkAdvDataSourceAdmob      8 //Admob 广告数据源
#define nDkAdvDataSourceMopub      39//Mopub 广告数据源
#define nDkAdvDataSourceApplovin   20//applovin 广告数据源

#define nDkAdvDataSourceGDT        62//广点通 广告数据源
#define nDkAdvDataSourceBaidu      63//百度 广告数据源
#define nDkAdvDataSourceBU         64//头条 广告数据源
#define nDkAdvDataSourceABU         70//头条聚合 广告数据源
#define nDkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define nDkAdvDataSourcePangle     74//pangle 广告数据源

#define nDkOnlineAdvTypeBanner                   1  //banner
#define nDkOnlineAdvTypeInterstitial             2  //全屏
#define nDkOnlineAdvTypeNative                   3 //native
#define nDkOnlineAdvTypeVideo                    4 //视频
#define nDkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define nDkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define nDkOnlineAdvTypeOpen                     8 //开屏
#define nDkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define nDkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define nDkAdServerConfigError  -1 //服务器返回数据不正确
#define nDkAdLoadConfigFailed  -2 //广告加载失败


#define nDAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define nDkCSAdInstallDays @"nDkCSAdInstallDays"
#define nDkCSAdModule_key @"nDkCSAdModule_key_%@"
#define nDkCSNewAdModule_key @"nDkCSNewAdModule_key_%@"
#define nDkCSAdInstallTime @"nDkCSAdInstallTime"
#define nDkCSAdInstallHours @"nDkCSAdInstallHours"
#define nDkCSAdLastGetServerTime @"nDkCSAdLastRequestTime"
#define nDkCSAdloadTime 30

#define nDkCSLoadAdTimeOutNotification @"nDKCSLoadAdTimeOutNotification"
#define nDkCSLoadAdTimeOutNotificationKey @"nDKCSLoadAdTimeOutKey"

