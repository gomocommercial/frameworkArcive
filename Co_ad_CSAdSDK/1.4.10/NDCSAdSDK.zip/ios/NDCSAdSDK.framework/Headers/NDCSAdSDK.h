//
//  NDCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "NDCSAdLoadBase.h"
#import "NDCSAdDataModel.h"
#import "NDCSAdLoadProtocol.h"
#import "NDCSAdLoadDataProtocol.h"
#import "NDCSAdLoadShowProtocol.h"
#import "NDCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface NDCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)nDsetupByBlock:(void (^ _Nonnull)(NDCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)nDloadAd:(NSString *)moduleId delegate:(id<NDCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)nDadShowStatistic:(NDCSAdDataModel *)dataModel adload:(nonnull NDCSAdLoadBase<NDCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)nDadClickStatistic:(NDCSAdDataModel *)dataModel adload:(nonnull NDCSAdLoadBase<NDCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)nDaddCustomFecher:(Class<NDCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
