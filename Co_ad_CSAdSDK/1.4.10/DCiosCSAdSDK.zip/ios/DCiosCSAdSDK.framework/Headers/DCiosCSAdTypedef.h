//
//  DCiosCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    DCiosCSAdLoadSuccess = 1,
    DCiosCSAdLoadFailure = -1,
    DCiosCSAdLoadTimeout = -2
} DCiosCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    DCiosCSAdPreloadSuccess = 1,
    //预加载失败
    DCiosCSAdPreloadFailure = -1,
    //重复加载
    DCiosCSAdPreloadRepeat = -2,
} DCiosCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    DCiosCSAdWillAppear,//即将出现
    DCiosCSAdDidAppear,//已经出现
    DCiosCSAdWillDisappear,//即将消失
    DCiosCSAdDidDisappear,//已经消失
    DCiosCSAdMuted,//静音广告
    DCiosCSAdWillLeaveApplication,//将要离开App

    DCiosCSAdVideoStart,//开始播放 常用于video
    DCiosCSAdVideoComplete,//播放完成 常用于video
    DCiosCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    DCiosCSAdVideoServerFail,//连接服务器成功，常用于fb video

    DCiosCSAdNativeDidDownload,//下载完成 常用于fb Native
    DCiosCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    DCiosCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    DCiosCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    DCiosCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    DCiosCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    DCiosCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    DCiosCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    DCiosCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    DCiosCSAdBUOpenDidAutoDimiss,//开屏自动消失
    DCiosCSAdBUOpenRenderSuccess, //渲染成功
    DCiosCSAdBUOpenRenderFail, //渲染失败
    DCiosCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    DCiosCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    DCiosCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    DCiosCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    DCiosCSAdDidPresentFullScreen,//插屏弹出全屏广告
    DCiosCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    DCiosCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    DCiosCSAdPlayerStatusStarted,//开始播放
    DCiosCSAdPlayerStatusPaused,//用户行为导致暂停
    DCiosCSAdPlayerStatusStoped,//播放停止
    DCiosCSAdPlayerStatusError,//播放出错
    DCiosCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    DCiosCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    DCiosCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    DCiosCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    DCiosCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    DCiosCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    DCiosCSAdRecordImpression, //广告曝光已记录
    DCiosCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    DCiosCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    DCiosCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    DCiosCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    DCiosCSAdABUOpenWillPresentFullScreen,
    DCiosCSAdABUOpenDidShowFailed,
    DCiosCSAdABUOpenWillDissmissFullScreen,
    DCiosCSAdABUOpenCountdownToZero,
    
    DCiosCSAdABUBannerWillPresentFullScreen,
    DCiosCSAdABUBannerWillDismissFullScreen,
    
    DCiosCSAdABURewardDidLoad,
    DCiosCSAdABURewardRenderFail,
    DCiosCSAdABURewardDidShowFailed,

} DCiosCSAdEvent;

typedef void (^DCiosCSAdLoadCompleteBlock)(DCiosCSAdLoadStatus adLoadStatus);

@class DCiosCSAdSetupParamsMaker;
@class DCiosCSAdSetupParams;

typedef DCiosCSAdSetupParamsMaker *(^DCiosCSAdStringInit)(NSString *);
typedef DCiosCSAdSetupParamsMaker *(^DCiosCSAdBoolInit)(BOOL);
typedef DCiosCSAdSetupParamsMaker *(^DCiosCSAdIntegerInit)(NSInteger);
typedef DCiosCSAdSetupParamsMaker *(^DCiosCSAdLongInit)(long);
typedef DCiosCSAdSetupParamsMaker *(^DCiosCSAdArrayInit)(NSArray *);
typedef DCiosCSAdSetupParams *(^DCiosCSAdMakeInit)(void);


@class DCiosCSAdDataModel;
typedef void (^DCiosCSAdRequestCompleteBlock)(NSMutableArray<DCiosCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^DCiosCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^DCiosCSAdPreloadCompleteBlock)(DCiosCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
