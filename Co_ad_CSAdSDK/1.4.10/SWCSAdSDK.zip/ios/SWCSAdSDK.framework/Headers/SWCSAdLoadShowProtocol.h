//
//  SWCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "SWCSAdTypedef.h"

@class SWCSAdLoadBase;

@protocol SWCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol SWCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sWonAdShowed:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sWonAdClicked:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sWonAdClosed:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sWonAdVideoCompletePlaying:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sWonAdVideoGotReward:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload;
-(void)sWonAdDidPayRevenue:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)sWonAdShowFail:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sWonAdOtherEvent:(SWCSAdLoadBase<SWCSAdLoadProtocol> *)adload event:(SWCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
