//
//  SMCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "SMCSAdLoadBase.h"
#import "SMCSAdDataModel.h"
#import "SMCSAdLoadProtocol.h"
#import "SMCSAdLoadDataProtocol.h"
#import "SMCSAdLoadShowProtocol.h"
#import "SMCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface SMCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)sMsetupByBlock:(void (^ _Nonnull)(SMCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)sMloadAd:(NSString *)moduleId delegate:(id<SMCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)sMadShowStatistic:(SMCSAdDataModel *)dataModel adload:(nonnull SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)sMadClickStatistic:(SMCSAdDataModel *)dataModel adload:(nonnull SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)sMaddCustomFecher:(Class<SMCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
