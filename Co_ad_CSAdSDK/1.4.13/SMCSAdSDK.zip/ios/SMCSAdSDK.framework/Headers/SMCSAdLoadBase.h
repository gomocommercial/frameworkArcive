//
//  SMCSAdLoadBase.h
//  AdDemo
//
//  Created by Zy on 2019/3/18.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SMCSAdManager.h"
#import "SMCSAdLoadDataProtocol.h"
#import "SMCSAdDataModel.h"
#import "SMCSAdTypedef.h"
#import "SMCSAdDefine.h"
#import "SMCSAdLoadShowProtocol.h"
/**
 广告加载器基类
 1.需遵循SMCSAdLoadProtocol协议：
 1)在loadData方法中完成自定义广告实例的初始化、delegate的设置,showDelegate的设置、csAdLoadCompleteBlock的赋值、以及开始加载广告
 2)根据广告SDK的展示代理的不同，选择适合的展示代理
 3.在广告加载过程中正确调用SMCSAdLoadDataProtocol中的协议已实现代理的正确加载
 4.自行判断是否使用计时器，默认超时时间30秒
 若使用计时器：
 1)开始加载广告数据时应调用startTimer;
 2)加载完成广告数据时应先判断是否超时然后调用succeeWithEndTimer;
 3)加载失败时先判断是否超时然后调用failureWithEndTimer;
 4)无需对csAdLoadCompleteBlock操作;
 若不适用计时器:
 1)需自行在广告数据加载完成时调用csAdLoadCompleteBlock;
 
 */
@interface SMCSAdLoadBase : NSObject

@property(nonatomic, weak) id <SMCSAdLoadDataProtocol> _Nullable delegate;


/**
 广告代理
 */
@property(nonatomic, weak) id <SMCSAdLoadShowProtocol> _Nullable showDelegate;

/**
 广告配置数据
 */
@property(nonatomic, strong) SMCSAdDataModel * _Nullable dataModel;

/**
 计时器
 */
@property(nonatomic, strong) NSTimer * _Nullable timer;


/**
 加载广告数据的回调block(必须调用)
 */
@property(nonatomic, copy) SMCSAdLoadCompleteBlock _Nullable csAdLoadCompleteBlock;


/// 支持自行预设codeId(真实使用的广告ID)。
@property (nonatomic, copy)NSString * nextAdId;

/// 支持自行预设ecpm。(必须要有codeId)
/// 历史原因,这是单次广告的价格
@property (nonatomic, copy)NSString * preEcpm;

/**
 获取测试设备
 */
- (NSArray<NSString *> * _Nullable)getTestDevices;


/**
 开始计时超时时间为sMkCSAdloadTime
 */
- (void)startTimer;

/**
 判断是否超时
 */
- (BOOL)isTimeOut;
/**
 超时结束并执行csAdLoadCompleteBlock
 */
- (void)failureWithTimeOut;

/**
 成功结束并执行csAdLoadCompleteBlock
 */
- (void)succeeWithEndTimer;

/**
 失败结束并执行csAdLoadCompleteBlock
 */
- (void)failureWithEndTimer;


/**
 是否需要打印信息
 */
- (BOOL)needLog;


/// 获取ECPM值，目前仅穿山甲聚合支持.需要做广告展示后获取，默认为空。
/// 历史原因,这是单次广告的价格
- (NSString * _Nonnull)getPreEcpm;


/// 聚合广告下一层ID，默认为空。
- (NSString * _Nonnull)nextCodeId;
@end

