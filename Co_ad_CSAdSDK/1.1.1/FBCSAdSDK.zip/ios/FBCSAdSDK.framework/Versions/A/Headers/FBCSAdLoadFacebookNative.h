//
//  FBCSAdLoadFacebookNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import "FBCSAdLoadNative.h"
#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import "FBCSAdLoadProtocol.h"
#import "FBCSAdLoadShowProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface FBCSAdLoadFacebookNative : FBCSAdLoadNative<FBCSAdLoadProtocol,FBNativeAdDelegate>

@property(strong, nonatomic) FBNativeAd *ad;

@end

NS_ASSUME_NONNULL_END
