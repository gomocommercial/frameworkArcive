//
//  FBCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FBCSAdTypedef.h"

@class FBCSAdLoadBase;

@protocol FBCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FBCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)fBonAdShowed:(FBCSAdLoadBase<FBCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)fBonAdClicked:(FBCSAdLoadBase<FBCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)fBonAdClosed:(FBCSAdLoadBase<FBCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)fBonAdVideoCompletePlaying:(FBCSAdLoadBase<FBCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)fBonAdShowFail:(FBCSAdLoadBase<FBCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)fBonAdOtherEvent:(FBCSAdLoadBase<FBCSAdLoadProtocol> *)adload event:(FBCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
