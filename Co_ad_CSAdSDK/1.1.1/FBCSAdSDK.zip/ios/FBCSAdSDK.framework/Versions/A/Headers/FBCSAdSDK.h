//
//  FBCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "FBCSAdLoadBase.h"
#import "FBCSAdDataModel.h"
#import "FBCSAdLoadProtocol.h"
#import "FBCSAdLoadDataProtocol.h"
#import "FBCSAdLoadShowProtocol.h"
#import "FBCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface FBCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)fBsetupByBlock:(void (^ _Nonnull)(FBCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)fBloadAd:(NSString *)moduleId delegate:(id<FBCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)fBadShowStatistic:(FBCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)fBadClickStatistic:(FBCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)fBaddCustomFecher:(Class<FBCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
