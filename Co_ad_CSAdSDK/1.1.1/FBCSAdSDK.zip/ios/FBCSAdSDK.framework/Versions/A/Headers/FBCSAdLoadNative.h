//
//  FBCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "FBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FBCSAdLoadNative : FBCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
