//
//  FBCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    FBCSAdLoadSuccess = 1,
    FBCSAdLoadFailure = -1,
    FBCSAdLoadTimeout = -2
} FBCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    FBCSAdPreloadSuccess = 1,
    //预加载失败
    FBCSAdPreloadFailure = -1,
    //重复加载
    FBCSAdPreloadRepeat = -2,
} FBCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    FBCSAdWillAppear,//即将出现
    FBCSAdDidAppear,//已经出现
    FBCSAdWillDisappear,//即将消失
    FBCSAdDidDisappear,//已经消失
    FBCSAdMuted,//静音广告
    FBCSAdWillLeaveApplication,//将要离开App

    FBCSAdVideoStart,//开始播放 常用于video
    FBCSAdVideoComplete,//播放完成 常用于video
    FBCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    FBCSAdVideoServerFail,//连接服务器成功，常用于fb video

    FBCSAdNativeDidDownload,//下载完成 常用于fb Native
    FBCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    FBCSAdDidExpire //已到期 常用于mopub interstitial 和 rewardVideo
} FBCSAdEvent;

typedef void (^FBCSAdLoadCompleteBlock)(FBCSAdLoadStatus adLoadStatus);

@class FBCSAdSetupParamsMaker;
@class FBCSAdSetupParams;

typedef FBCSAdSetupParamsMaker *(^FBCSAdStringInit)(NSString *);
typedef FBCSAdSetupParamsMaker *(^FBCSAdBoolInit)(BOOL);
typedef FBCSAdSetupParamsMaker *(^FBCSAdIntegerInit)(NSInteger);
typedef FBCSAdSetupParamsMaker *(^FBCSAdLongInit)(long);
typedef FBCSAdSetupParamsMaker *(^FBCSAdArrayInit)(NSArray *);
typedef FBCSAdSetupParams *(^FBCSAdMakeInit)(void);


@class FBCSAdDataModel;
typedef void (^FBCSAdRequestCompleteBlock)(NSMutableArray<FBCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^FBCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^FBCSAdPreloadCompleteBlock)(FBCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
