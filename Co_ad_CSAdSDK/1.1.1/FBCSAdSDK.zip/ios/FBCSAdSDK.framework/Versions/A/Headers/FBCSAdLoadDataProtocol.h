//
//  FBCSAdLoadDataProtocol.h
//  FBCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "FBCSAdTypedef.h"

@class FBCSAdDataModel;
@class FBCSAdLoadBase;

@protocol FBCSAdLoadProtocol;

@protocol FBCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)fBonAdInfoFinish:(FBCSAdLoadBase<FBCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)fBonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)fBonAdFail:(FBCSAdLoadBase<FBCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
