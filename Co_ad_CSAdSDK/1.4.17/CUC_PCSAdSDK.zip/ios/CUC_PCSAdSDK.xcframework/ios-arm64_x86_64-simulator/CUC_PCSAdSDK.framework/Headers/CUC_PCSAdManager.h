//
//  CUC_PCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CUC_PCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)cUC_PloadAd:(NSString *)moduleId delegate:(id<CUC_PCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)cUC_PremoveData:(id)obj;
- (NSDictionary *)getDevicesInfo;

@end

NS_ASSUME_NONNULL_END
