//
//  CUC_PCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "CUC_PCSAdLoadBase.h"
#import "CUC_PCSAdDataModel.h"
#import "CUC_PCSAdLoadProtocol.h"
#import "CUC_PCSAdLoadDataProtocol.h"
#import "CUC_PCSAdLoadShowProtocol.h"
#import "CUC_PCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)cUC_PsetupByBlock:(void (^ _Nonnull)(CUC_PCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)cUC_PloadAd:(NSString *)moduleId delegate:(id<CUC_PCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)cUC_PadShowStatistic:(CUC_PCSAdDataModel *)dataModel adload:(nonnull CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)cUC_PadClickStatistic:(CUC_PCSAdDataModel *)dataModel adload:(nonnull CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)cUC_PaddCustomFecher:(Class<CUC_PCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
