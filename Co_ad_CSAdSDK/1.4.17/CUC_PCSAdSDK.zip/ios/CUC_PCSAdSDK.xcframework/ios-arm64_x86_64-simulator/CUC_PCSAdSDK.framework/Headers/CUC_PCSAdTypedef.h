//
//  CUC_PCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CUC_PCSAdLoadSuccess = 1,
    CUC_PCSAdLoadFailure = -1,
    CUC_PCSAdLoadTimeout = -2
} CUC_PCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CUC_PCSAdPreloadSuccess = 1,
    //预加载失败
    CUC_PCSAdPreloadFailure = -1,
    //重复加载
    CUC_PCSAdPreloadRepeat = -2,
} CUC_PCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CUC_PCSAdWillAppear,//即将出现
    CUC_PCSAdDidAppear,//已经出现
    CUC_PCSAdWillDisappear,//即将消失
    CUC_PCSAdDidDisappear,//已经消失
    CUC_PCSAdMuted,//静音广告
    CUC_PCSAdWillLeaveApplication,//将要离开App

    CUC_PCSAdVideoStart,//开始播放 常用于video
    CUC_PCSAdVideoComplete,//播放完成 常用于video
    CUC_PCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CUC_PCSAdVideoServerFail,//连接服务器成功，常用于fb video

    CUC_PCSAdNativeDidDownload,//下载完成 常用于fb Native
    CUC_PCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CUC_PCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CUC_PCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CUC_PCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CUC_PCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CUC_PCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    CUC_PCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CUC_PCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CUC_PCSAdBUOpenDidAutoDimiss,//开屏自动消失
    CUC_PCSAdBUOpenRenderSuccess, //渲染成功
    CUC_PCSAdBUOpenRenderFail, //渲染失败
    CUC_PCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    CUC_PCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CUC_PCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CUC_PCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CUC_PCSAdDidPresentFullScreen,//插屏弹出全屏广告
    CUC_PCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CUC_PCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CUC_PCSAdPlayerStatusStarted,//开始播放
    CUC_PCSAdPlayerStatusPaused,//用户行为导致暂停
    CUC_PCSAdPlayerStatusStoped,//播放停止
    CUC_PCSAdPlayerStatusError,//播放出错
    CUC_PCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CUC_PCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CUC_PCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CUC_PCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CUC_PCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CUC_PCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CUC_PCSAdRecordImpression, //广告曝光已记录
    CUC_PCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CUC_PCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CUC_PCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    CUC_PCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    CUC_PCSAdABUOpenWillPresentFullScreen,
    CUC_PCSAdABUOpenDidShowFailed,
    CUC_PCSAdABUOpenWillDissmissFullScreen,
    CUC_PCSAdABUOpenCountdownToZero,
    
    CUC_PCSAdABUBannerWillPresentFullScreen,
    CUC_PCSAdABUBannerWillDismissFullScreen,
    
    CUC_PCSAdABURewardDidLoad,
    CUC_PCSAdABURewardRenderFail,
    CUC_PCSAdABURewardDidShowFailed,

} CUC_PCSAdEvent;

typedef void (^CUC_PCSAdLoadCompleteBlock)(CUC_PCSAdLoadStatus adLoadStatus);

@class CUC_PCSAdSetupParamsMaker;
@class CUC_PCSAdSetupParams;

typedef CUC_PCSAdSetupParamsMaker *(^CUC_PCSAdStringInit)(NSString *);
typedef CUC_PCSAdSetupParamsMaker *(^CUC_PCSAdBoolInit)(BOOL);
typedef CUC_PCSAdSetupParamsMaker *(^CUC_PCSAdIntegerInit)(NSInteger);
typedef CUC_PCSAdSetupParamsMaker *(^CUC_PCSAdLongInit)(long);
typedef CUC_PCSAdSetupParamsMaker *(^CUC_PCSAdArrayInit)(NSArray *);
typedef CUC_PCSAdSetupParams *(^CUC_PCSAdMakeInit)(void);


@class CUC_PCSAdDataModel;
typedef void (^CUC_PCSAdRequestCompleteBlock)(NSMutableArray<CUC_PCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CUC_PCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CUC_PCSAdPreloadCompleteBlock)(CUC_PCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
