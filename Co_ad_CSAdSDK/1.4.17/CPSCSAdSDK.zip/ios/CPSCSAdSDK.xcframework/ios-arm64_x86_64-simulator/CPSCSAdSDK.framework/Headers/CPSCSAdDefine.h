//
//  CPSCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define cPSkAdvDataSourceFacebook   2 //FB 广告数据源
#define cPSkAdvDataSourceAdmob      8 //Admob 广告数据源
#define cPSkAdvDataSourceMopub      39//Mopub 广告数据源
#define cPSkAdvDataSourceApplovin   20//applovin 广告数据源

#define cPSkAdvDataSourceGDT        62//广点通 广告数据源
#define cPSkAdvDataSourceBaidu      63//百度 广告数据源
#define cPSkAdvDataSourceBU         64//头条 广告数据源
#define cPSkAdvDataSourceABU         70//头条聚合 广告数据源
#define cPSkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define cPSkAdvDataSourcePangle     74//pangle 广告数据源

#define cPSkOnlineAdvTypeBanner                   1  //banner
#define cPSkOnlineAdvTypeInterstitial             2  //全屏
#define cPSkOnlineAdvTypeNative                   3 //native
#define cPSkOnlineAdvTypeVideo                    4 //视频
#define cPSkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define cPSkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define cPSkOnlineAdvTypeOpen                     8 //开屏
#define cPSkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define cPSkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define cPSkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define cPSkAdServerConfigError  -1 //服务器返回数据不正确
#define cPSkAdLoadConfigFailed  -2 //广告加载失败


#define cPSAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define cPSkCSAdInstallDays @"cPSkCSAdInstallDays"
#define cPSkCSAdModule_key @"cPSkCSAdModule_key_%@"
#define cPSkCSNewAdModule_key @"cPSkCSNewAdModule_key_%@"
#define cPSkCSAdInstallTime @"cPSkCSAdInstallTime"
#define cPSkCSAdInstallHours @"cPSkCSAdInstallHours"
#define cPSkCSAdLastGetServerTime @"cPSkCSAdLastRequestTime"
#define cPSkCSAdloadTime 30

#define cPSkCSLoadAdTimeOutNotification @"cPSKCSLoadAdTimeOutNotification"
#define cPSkCSLoadAdTimeOutNotificationKey @"cPSKCSLoadAdTimeOutKey"

