//
//  CPSCSAdNetworkTool.h
//  CPSCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CPSCSAdDataModel.h"
#import "CPSCSAdTypedef.h"
#import "CPSCSNewStoreLiteRequestTool.h"
#import "NSString+CPSCSGenerateHash.h"

@interface CPSCSAdNetworkTool : NSObject

+ (CPSCSAdNetworkTool *)shared;
@property(nonatomic, copy) CPSCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)cPSrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CPSCSAdRequestCompleteBlock)complete;

- (void)cPSsetCDay:(void(^ _Nullable)(bool success))handle;
@end
