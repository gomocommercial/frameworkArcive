//
//  CPSCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CPSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPSCSAdLoadInterstitial : CPSCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
