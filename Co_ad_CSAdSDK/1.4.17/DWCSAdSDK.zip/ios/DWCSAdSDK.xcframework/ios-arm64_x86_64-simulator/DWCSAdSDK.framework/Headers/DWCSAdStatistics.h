//
//  DWCSAdStatistics.h
//  DWCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "DWCSAdDataModel.h"
#import "DWCSAdTypedef.h"
#import "DWCSAdLoadBase.h"
@interface DWCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)dWadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)dWadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)dWadRewardVideoCompleteStatistic:(DWCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)dWadShowStatistic:(DWCSAdDataModel *)dataModel adload:(nonnull DWCSAdLoadBase<DWCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)dWadClickStatistic:(DWCSAdDataModel *)dataModel adload:(nonnull DWCSAdLoadBase<DWCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)dWadUploadRevenueStatistic:(DWCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
