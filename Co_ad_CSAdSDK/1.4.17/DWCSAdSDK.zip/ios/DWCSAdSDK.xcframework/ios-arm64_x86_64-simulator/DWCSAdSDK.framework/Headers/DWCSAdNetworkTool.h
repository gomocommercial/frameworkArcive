//
//  DWCSAdNetworkTool.h
//  DWCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "DWCSAdDataModel.h"
#import "DWCSAdTypedef.h"
#import "DWCSNewStoreLiteRequestTool.h"
#import "NSString+DWCSGenerateHash.h"

@interface DWCSAdNetworkTool : NSObject

+ (DWCSAdNetworkTool *)shared;
@property(nonatomic, copy) DWCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)dWrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(DWCSAdRequestCompleteBlock)complete;

- (void)dWsetCDay:(void(^ _Nullable)(bool success))handle;
@end
