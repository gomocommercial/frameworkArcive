//
//  DWCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    DWCSAdLoadSuccess = 1,
    DWCSAdLoadFailure = -1,
    DWCSAdLoadTimeout = -2
} DWCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    DWCSAdPreloadSuccess = 1,
    //预加载失败
    DWCSAdPreloadFailure = -1,
    //重复加载
    DWCSAdPreloadRepeat = -2,
} DWCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    DWCSAdWillAppear,//即将出现
    DWCSAdDidAppear,//已经出现
    DWCSAdWillDisappear,//即将消失
    DWCSAdDidDisappear,//已经消失
    DWCSAdMuted,//静音广告
    DWCSAdWillLeaveApplication,//将要离开App

    DWCSAdVideoStart,//开始播放 常用于video
    DWCSAdVideoComplete,//播放完成 常用于video
    DWCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    DWCSAdVideoServerFail,//连接服务器成功，常用于fb video

    DWCSAdNativeDidDownload,//下载完成 常用于fb Native
    DWCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    DWCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    DWCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    DWCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    DWCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    DWCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    DWCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    DWCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    DWCSAdBUOpenDidAutoDimiss,//开屏自动消失
    DWCSAdBUOpenRenderSuccess, //渲染成功
    DWCSAdBUOpenRenderFail, //渲染失败
    DWCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    DWCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    DWCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    DWCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    DWCSAdDidPresentFullScreen,//插屏弹出全屏广告
    DWCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    DWCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    DWCSAdPlayerStatusStarted,//开始播放
    DWCSAdPlayerStatusPaused,//用户行为导致暂停
    DWCSAdPlayerStatusStoped,//播放停止
    DWCSAdPlayerStatusError,//播放出错
    DWCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    DWCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    DWCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    DWCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    DWCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    DWCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    DWCSAdRecordImpression, //广告曝光已记录
    DWCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    DWCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    DWCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    DWCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    DWCSAdABUOpenWillPresentFullScreen,
    DWCSAdABUOpenDidShowFailed,
    DWCSAdABUOpenWillDissmissFullScreen,
    DWCSAdABUOpenCountdownToZero,
    
    DWCSAdABUBannerWillPresentFullScreen,
    DWCSAdABUBannerWillDismissFullScreen,
    
    DWCSAdABURewardDidLoad,
    DWCSAdABURewardRenderFail,
    DWCSAdABURewardDidShowFailed,

} DWCSAdEvent;

typedef void (^DWCSAdLoadCompleteBlock)(DWCSAdLoadStatus adLoadStatus);

@class DWCSAdSetupParamsMaker;
@class DWCSAdSetupParams;

typedef DWCSAdSetupParamsMaker *(^DWCSAdStringInit)(NSString *);
typedef DWCSAdSetupParamsMaker *(^DWCSAdBoolInit)(BOOL);
typedef DWCSAdSetupParamsMaker *(^DWCSAdIntegerInit)(NSInteger);
typedef DWCSAdSetupParamsMaker *(^DWCSAdLongInit)(long);
typedef DWCSAdSetupParamsMaker *(^DWCSAdArrayInit)(NSArray *);
typedef DWCSAdSetupParams *(^DWCSAdMakeInit)(void);


@class DWCSAdDataModel;
typedef void (^DWCSAdRequestCompleteBlock)(NSMutableArray<DWCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^DWCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^DWCSAdPreloadCompleteBlock)(DWCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
