//
//  AMACSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "AMACSAdTypedef.h"

@class AMACSAdLoadBase;

@protocol AMACSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol AMACSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)aMAonAdShowed:(AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)aMAonAdClicked:(AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)aMAonAdClosed:(AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)aMAonAdVideoCompletePlaying:(AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)aMAonAdVideoGotReward:(AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload;
-(void)aMAonAdDidPayRevenue:(AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)aMAonAdShowFail:(AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)aMAonAdOtherEvent:(AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload event:(AMACSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
