//
//  AMACSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    AMACSAdLoadSuccess = 1,
    AMACSAdLoadFailure = -1,
    AMACSAdLoadTimeout = -2
} AMACSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    AMACSAdPreloadSuccess = 1,
    //预加载失败
    AMACSAdPreloadFailure = -1,
    //重复加载
    AMACSAdPreloadRepeat = -2,
} AMACSAdPreloadStatus;


typedef enum : NSUInteger {
    
    AMACSAdWillAppear,//即将出现
    AMACSAdDidAppear,//已经出现
    AMACSAdWillDisappear,//即将消失
    AMACSAdDidDisappear,//已经消失
    AMACSAdMuted,//静音广告
    AMACSAdWillLeaveApplication,//将要离开App

    AMACSAdVideoStart,//开始播放 常用于video
    AMACSAdVideoComplete,//播放完成 常用于video
    AMACSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    AMACSAdVideoServerFail,//连接服务器成功，常用于fb video

    AMACSAdNativeDidDownload,//下载完成 常用于fb Native
    AMACSAdNativeFinishClick,//完成点击 常用与fb Native
    
    AMACSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    AMACSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    AMACSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    AMACSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    AMACSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    AMACSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    AMACSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    AMACSAdBUOpenDidAutoDimiss,//开屏自动消失
    AMACSAdBUOpenRenderSuccess, //渲染成功
    AMACSAdBUOpenRenderFail, //渲染失败
    AMACSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    AMACSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    AMACSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    AMACSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    AMACSAdDidPresentFullScreen,//插屏弹出全屏广告
    AMACSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    AMACSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    AMACSAdPlayerStatusStarted,//开始播放
    AMACSAdPlayerStatusPaused,//用户行为导致暂停
    AMACSAdPlayerStatusStoped,//播放停止
    AMACSAdPlayerStatusError,//播放出错
    AMACSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    AMACSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    AMACSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    AMACSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    AMACSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    AMACSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    AMACSAdRecordImpression, //广告曝光已记录
    AMACSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    AMACSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    AMACSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    AMACSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    AMACSAdABUOpenWillPresentFullScreen,
    AMACSAdABUOpenDidShowFailed,
    AMACSAdABUOpenWillDissmissFullScreen,
    AMACSAdABUOpenCountdownToZero,
    
    AMACSAdABUBannerWillPresentFullScreen,
    AMACSAdABUBannerWillDismissFullScreen,
    
    AMACSAdABURewardDidLoad,
    AMACSAdABURewardRenderFail,
    AMACSAdABURewardDidShowFailed,

} AMACSAdEvent;

typedef void (^AMACSAdLoadCompleteBlock)(AMACSAdLoadStatus adLoadStatus);

@class AMACSAdSetupParamsMaker;
@class AMACSAdSetupParams;

typedef AMACSAdSetupParamsMaker *(^AMACSAdStringInit)(NSString *);
typedef AMACSAdSetupParamsMaker *(^AMACSAdBoolInit)(BOOL);
typedef AMACSAdSetupParamsMaker *(^AMACSAdIntegerInit)(NSInteger);
typedef AMACSAdSetupParamsMaker *(^AMACSAdLongInit)(long);
typedef AMACSAdSetupParamsMaker *(^AMACSAdArrayInit)(NSArray *);
typedef AMACSAdSetupParams *(^AMACSAdMakeInit)(void);


@class AMACSAdDataModel;
typedef void (^AMACSAdRequestCompleteBlock)(NSMutableArray<AMACSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^AMACSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^AMACSAdPreloadCompleteBlock)(AMACSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
