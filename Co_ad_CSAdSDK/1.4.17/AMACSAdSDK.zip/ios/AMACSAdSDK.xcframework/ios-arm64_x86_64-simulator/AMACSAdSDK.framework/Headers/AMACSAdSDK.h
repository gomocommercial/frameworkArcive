//
//  AMACSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "AMACSAdLoadBase.h"
#import "AMACSAdDataModel.h"
#import "AMACSAdLoadProtocol.h"
#import "AMACSAdLoadDataProtocol.h"
#import "AMACSAdLoadShowProtocol.h"
#import "AMACSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface AMACSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)aMAsetupByBlock:(void (^ _Nonnull)(AMACSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)aMAloadAd:(NSString *)moduleId delegate:(id<AMACSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)aMAadShowStatistic:(AMACSAdDataModel *)dataModel adload:(nonnull AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)aMAadClickStatistic:(AMACSAdDataModel *)dataModel adload:(nonnull AMACSAdLoadBase<AMACSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)aMAaddCustomFecher:(Class<AMACSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
