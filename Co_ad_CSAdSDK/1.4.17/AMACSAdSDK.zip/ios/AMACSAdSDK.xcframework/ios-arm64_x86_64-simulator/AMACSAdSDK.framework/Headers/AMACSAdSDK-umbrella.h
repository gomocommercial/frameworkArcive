#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "AMACSAdSDK.h"
#import "AMACSAdPreload.h"
#import "AMACSAdLoadDataProtocol.h"
#import "AMACSAdLoadShowProtocol.h"
#import "AMACSAdLoadProtocol.h"
#import "AMACSAdLoadBase.h"
#import "AMACSAdLoadInterstitial.h"
#import "AMACSAdLoadNative.h"
#import "AMACSAdLoadReward.h"
#import "AMACSAdLoadOpen.h"
#import "AMACSAdLoadBanner.h"
#import "AMACSAdManager.h"
#import "AMACSAdSetupParams.h"
#import "AMACSAdSetupParamsMaker.h"
#import "AMACSAdDefine.h"
#import "AMACSAdTypedef.h"
#import "AMACSAdStatistics.h"
#import "AMACSAdDataModel.h"
#import "AMACSAdNetworkTool.h"
#import "AMACSNewStoreLiteRequestTool.h"
#import "NSString+AMACSGenerateHash.h"

FOUNDATION_EXPORT double AMACSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char AMACSAdSDKVersionString[];

