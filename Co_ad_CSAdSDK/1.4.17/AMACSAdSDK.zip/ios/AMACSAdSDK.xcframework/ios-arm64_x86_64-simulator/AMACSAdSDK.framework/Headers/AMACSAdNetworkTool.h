//
//  AMACSAdNetworkTool.h
//  AMACSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "AMACSAdDataModel.h"
#import "AMACSAdTypedef.h"
#import "AMACSNewStoreLiteRequestTool.h"
#import "NSString+AMACSGenerateHash.h"

@interface AMACSAdNetworkTool : NSObject

+ (AMACSAdNetworkTool *)shared;
@property(nonatomic, copy) AMACSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)aMArequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(AMACSAdRequestCompleteBlock)complete;

- (void)aMAsetCDay:(void(^ _Nullable)(bool success))handle;
@end
