//
//  AMACSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define aMAkAdvDataSourceFacebook   2 //FB 广告数据源
#define aMAkAdvDataSourceAdmob      8 //Admob 广告数据源
#define aMAkAdvDataSourceMopub      39//Mopub 广告数据源
#define aMAkAdvDataSourceApplovin   20//applovin 广告数据源

#define aMAkAdvDataSourceGDT        62//广点通 广告数据源
#define aMAkAdvDataSourceBaidu      63//百度 广告数据源
#define aMAkAdvDataSourceBU         64//头条 广告数据源
#define aMAkAdvDataSourceABU         70//头条聚合 广告数据源
#define aMAkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define aMAkAdvDataSourcePangle     74//pangle 广告数据源

#define aMAkOnlineAdvTypeBanner                   1  //banner
#define aMAkOnlineAdvTypeInterstitial             2  //全屏
#define aMAkOnlineAdvTypeNative                   3 //native
#define aMAkOnlineAdvTypeVideo                    4 //视频
#define aMAkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define aMAkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define aMAkOnlineAdvTypeOpen                     8 //开屏
#define aMAkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define aMAkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define aMAkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define aMAkAdServerConfigError  -1 //服务器返回数据不正确
#define aMAkAdLoadConfigFailed  -2 //广告加载失败


#define aMAAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define aMAkCSAdInstallDays @"aMAkCSAdInstallDays"
#define aMAkCSAdModule_key @"aMAkCSAdModule_key_%@"
#define aMAkCSNewAdModule_key @"aMAkCSNewAdModule_key_%@"
#define aMAkCSAdInstallTime @"aMAkCSAdInstallTime"
#define aMAkCSAdInstallHours @"aMAkCSAdInstallHours"
#define aMAkCSAdLastGetServerTime @"aMAkCSAdLastRequestTime"
#define aMAkCSAdloadTime 30

#define aMAkCSLoadAdTimeOutNotification @"aMAKCSLoadAdTimeOutNotification"
#define aMAkCSLoadAdTimeOutNotificationKey @"aMAKCSLoadAdTimeOutKey"

