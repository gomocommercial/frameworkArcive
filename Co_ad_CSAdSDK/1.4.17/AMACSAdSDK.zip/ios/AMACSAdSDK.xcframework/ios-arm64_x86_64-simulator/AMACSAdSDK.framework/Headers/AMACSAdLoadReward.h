//
//  AMACSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "AMACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AMACSAdLoadReward : AMACSAdLoadBase

@end

NS_ASSUME_NONNULL_END
