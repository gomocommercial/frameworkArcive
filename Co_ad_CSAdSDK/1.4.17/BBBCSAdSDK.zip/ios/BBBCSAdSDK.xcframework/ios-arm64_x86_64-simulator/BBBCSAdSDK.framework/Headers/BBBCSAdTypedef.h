//
//  BBBCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    BBBCSAdLoadSuccess = 1,
    BBBCSAdLoadFailure = -1,
    BBBCSAdLoadTimeout = -2
} BBBCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    BBBCSAdPreloadSuccess = 1,
    //预加载失败
    BBBCSAdPreloadFailure = -1,
    //重复加载
    BBBCSAdPreloadRepeat = -2,
} BBBCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    BBBCSAdWillAppear,//即将出现
    BBBCSAdDidAppear,//已经出现
    BBBCSAdWillDisappear,//即将消失
    BBBCSAdDidDisappear,//已经消失
    BBBCSAdMuted,//静音广告
    BBBCSAdWillLeaveApplication,//将要离开App

    BBBCSAdVideoStart,//开始播放 常用于video
    BBBCSAdVideoComplete,//播放完成 常用于video
    BBBCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    BBBCSAdVideoServerFail,//连接服务器成功，常用于fb video

    BBBCSAdNativeDidDownload,//下载完成 常用于fb Native
    BBBCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    BBBCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    BBBCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    BBBCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    BBBCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    BBBCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    BBBCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    BBBCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    BBBCSAdBUOpenDidAutoDimiss,//开屏自动消失
    BBBCSAdBUOpenRenderSuccess, //渲染成功
    BBBCSAdBUOpenRenderFail, //渲染失败
    BBBCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    BBBCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    BBBCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    BBBCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    BBBCSAdDidPresentFullScreen,//插屏弹出全屏广告
    BBBCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    BBBCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    BBBCSAdPlayerStatusStarted,//开始播放
    BBBCSAdPlayerStatusPaused,//用户行为导致暂停
    BBBCSAdPlayerStatusStoped,//播放停止
    BBBCSAdPlayerStatusError,//播放出错
    BBBCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    BBBCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    BBBCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    BBBCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    BBBCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    BBBCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    BBBCSAdRecordImpression, //广告曝光已记录
    BBBCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    BBBCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    BBBCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    BBBCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    BBBCSAdABUOpenWillPresentFullScreen,
    BBBCSAdABUOpenDidShowFailed,
    BBBCSAdABUOpenWillDissmissFullScreen,
    BBBCSAdABUOpenCountdownToZero,
    
    BBBCSAdABUBannerWillPresentFullScreen,
    BBBCSAdABUBannerWillDismissFullScreen,
    
    BBBCSAdABURewardDidLoad,
    BBBCSAdABURewardRenderFail,
    BBBCSAdABURewardDidShowFailed,

} BBBCSAdEvent;

typedef void (^BBBCSAdLoadCompleteBlock)(BBBCSAdLoadStatus adLoadStatus);

@class BBBCSAdSetupParamsMaker;
@class BBBCSAdSetupParams;

typedef BBBCSAdSetupParamsMaker *(^BBBCSAdStringInit)(NSString *);
typedef BBBCSAdSetupParamsMaker *(^BBBCSAdBoolInit)(BOOL);
typedef BBBCSAdSetupParamsMaker *(^BBBCSAdIntegerInit)(NSInteger);
typedef BBBCSAdSetupParamsMaker *(^BBBCSAdLongInit)(long);
typedef BBBCSAdSetupParamsMaker *(^BBBCSAdArrayInit)(NSArray *);
typedef BBBCSAdSetupParams *(^BBBCSAdMakeInit)(void);


@class BBBCSAdDataModel;
typedef void (^BBBCSAdRequestCompleteBlock)(NSMutableArray<BBBCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^BBBCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^BBBCSAdPreloadCompleteBlock)(BBBCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
