//
//  BBBCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "BBBCSAdTypedef.h"

@class BBBCSAdLoadBase;

@protocol BBBCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol BBBCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)bBBonAdShowed:(BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)bBBonAdClicked:(BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)bBBonAdClosed:(BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)bBBonAdVideoCompletePlaying:(BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)bBBonAdVideoGotReward:(BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload;
-(void)bBBonAdDidPayRevenue:(BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)bBBonAdShowFail:(BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)bBBonAdOtherEvent:(BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload event:(BBBCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
