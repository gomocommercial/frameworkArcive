//
//  BBBCSAdNetworkTool.h
//  BBBCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "BBBCSAdDataModel.h"
#import "BBBCSAdTypedef.h"
#import "BBBCSNewStoreLiteRequestTool.h"
#import "NSString+BBBCSGenerateHash.h"

@interface BBBCSAdNetworkTool : NSObject

+ (BBBCSAdNetworkTool *)shared;
@property(nonatomic, copy) BBBCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)bBBrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(BBBCSAdRequestCompleteBlock)complete;

- (void)bBBsetCDay:(void(^ _Nullable)(bool success))handle;
@end
