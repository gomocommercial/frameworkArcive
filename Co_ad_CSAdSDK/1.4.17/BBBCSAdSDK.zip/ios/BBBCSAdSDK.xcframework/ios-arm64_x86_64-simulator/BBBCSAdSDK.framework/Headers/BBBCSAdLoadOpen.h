//
//  BBBCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "BBBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface BBBCSAdLoadOpen : BBBCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
