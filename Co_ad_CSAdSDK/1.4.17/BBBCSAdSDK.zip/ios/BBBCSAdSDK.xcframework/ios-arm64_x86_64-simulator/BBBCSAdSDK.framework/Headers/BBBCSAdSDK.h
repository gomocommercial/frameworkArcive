//
//  BBBCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "BBBCSAdLoadBase.h"
#import "BBBCSAdDataModel.h"
#import "BBBCSAdLoadProtocol.h"
#import "BBBCSAdLoadDataProtocol.h"
#import "BBBCSAdLoadShowProtocol.h"
#import "BBBCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface BBBCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)bBBsetupByBlock:(void (^ _Nonnull)(BBBCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)bBBloadAd:(NSString *)moduleId delegate:(id<BBBCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)bBBadShowStatistic:(BBBCSAdDataModel *)dataModel adload:(nonnull BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)bBBadClickStatistic:(BBBCSAdDataModel *)dataModel adload:(nonnull BBBCSAdLoadBase<BBBCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)bBBaddCustomFecher:(Class<BBBCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
