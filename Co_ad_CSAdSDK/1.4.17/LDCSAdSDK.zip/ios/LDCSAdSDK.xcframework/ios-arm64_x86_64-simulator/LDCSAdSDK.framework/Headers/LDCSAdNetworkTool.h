//
//  LDCSAdNetworkTool.h
//  LDCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "LDCSAdDataModel.h"
#import "LDCSAdTypedef.h"
#import "LDCSNewStoreLiteRequestTool.h"
#import "NSString+LDCSGenerateHash.h"

@interface LDCSAdNetworkTool : NSObject

+ (LDCSAdNetworkTool *)shared;
@property(nonatomic, copy) LDCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)lDrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(LDCSAdRequestCompleteBlock)complete;

- (void)lDsetCDay:(void(^ _Nullable)(bool success))handle;
@end
