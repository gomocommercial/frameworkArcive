//
//  FNCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FNCSAdTypedef.h"

@class FNCSAdLoadBase;

@protocol FNCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FNCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)fNonAdShowed:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)fNonAdClicked:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)fNonAdClosed:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)fNonAdVideoCompletePlaying:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)fNonAdVideoGotReward:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload;
-(void)fNonAdDidPayRevenue:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)fNonAdShowFail:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)fNonAdOtherEvent:(FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload event:(FNCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
