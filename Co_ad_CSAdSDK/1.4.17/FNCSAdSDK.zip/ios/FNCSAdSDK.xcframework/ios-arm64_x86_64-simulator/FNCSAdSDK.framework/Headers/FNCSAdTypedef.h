//
//  FNCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    FNCSAdLoadSuccess = 1,
    FNCSAdLoadFailure = -1,
    FNCSAdLoadTimeout = -2
} FNCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    FNCSAdPreloadSuccess = 1,
    //预加载失败
    FNCSAdPreloadFailure = -1,
    //重复加载
    FNCSAdPreloadRepeat = -2,
} FNCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    FNCSAdWillAppear,//即将出现
    FNCSAdDidAppear,//已经出现
    FNCSAdWillDisappear,//即将消失
    FNCSAdDidDisappear,//已经消失
    FNCSAdMuted,//静音广告
    FNCSAdWillLeaveApplication,//将要离开App

    FNCSAdVideoStart,//开始播放 常用于video
    FNCSAdVideoComplete,//播放完成 常用于video
    FNCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    FNCSAdVideoServerFail,//连接服务器成功，常用于fb video

    FNCSAdNativeDidDownload,//下载完成 常用于fb Native
    FNCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    FNCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    FNCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    FNCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    FNCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    FNCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    FNCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    FNCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    FNCSAdBUOpenDidAutoDimiss,//开屏自动消失
    FNCSAdBUOpenRenderSuccess, //渲染成功
    FNCSAdBUOpenRenderFail, //渲染失败
    FNCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    FNCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    FNCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    FNCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    FNCSAdDidPresentFullScreen,//插屏弹出全屏广告
    FNCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    FNCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    FNCSAdPlayerStatusStarted,//开始播放
    FNCSAdPlayerStatusPaused,//用户行为导致暂停
    FNCSAdPlayerStatusStoped,//播放停止
    FNCSAdPlayerStatusError,//播放出错
    FNCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    FNCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    FNCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    FNCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    FNCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    FNCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    FNCSAdRecordImpression, //广告曝光已记录
    FNCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    FNCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    FNCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    FNCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    FNCSAdABUOpenWillPresentFullScreen,
    FNCSAdABUOpenDidShowFailed,
    FNCSAdABUOpenWillDissmissFullScreen,
    FNCSAdABUOpenCountdownToZero,
    
    FNCSAdABUBannerWillPresentFullScreen,
    FNCSAdABUBannerWillDismissFullScreen,
    
    FNCSAdABURewardDidLoad,
    FNCSAdABURewardRenderFail,
    FNCSAdABURewardDidShowFailed,

} FNCSAdEvent;

typedef void (^FNCSAdLoadCompleteBlock)(FNCSAdLoadStatus adLoadStatus);

@class FNCSAdSetupParamsMaker;
@class FNCSAdSetupParams;

typedef FNCSAdSetupParamsMaker *(^FNCSAdStringInit)(NSString *);
typedef FNCSAdSetupParamsMaker *(^FNCSAdBoolInit)(BOOL);
typedef FNCSAdSetupParamsMaker *(^FNCSAdIntegerInit)(NSInteger);
typedef FNCSAdSetupParamsMaker *(^FNCSAdLongInit)(long);
typedef FNCSAdSetupParamsMaker *(^FNCSAdArrayInit)(NSArray *);
typedef FNCSAdSetupParams *(^FNCSAdMakeInit)(void);


@class FNCSAdDataModel;
typedef void (^FNCSAdRequestCompleteBlock)(NSMutableArray<FNCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^FNCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^FNCSAdPreloadCompleteBlock)(FNCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
