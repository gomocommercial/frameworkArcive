//
//  FNCSAdNetworkTool.h
//  FNCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "FNCSAdDataModel.h"
#import "FNCSAdTypedef.h"
#import "FNCSNewStoreLiteRequestTool.h"
#import "NSString+FNCSGenerateHash.h"

@interface FNCSAdNetworkTool : NSObject

+ (FNCSAdNetworkTool *)shared;
@property(nonatomic, copy) FNCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)fNrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(FNCSAdRequestCompleteBlock)complete;

- (void)fNsetCDay:(void(^ _Nullable)(bool success))handle;
@end
