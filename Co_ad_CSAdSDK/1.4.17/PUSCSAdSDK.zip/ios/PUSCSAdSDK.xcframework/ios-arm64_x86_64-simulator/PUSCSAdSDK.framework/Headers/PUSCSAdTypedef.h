//
//  PUSCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PUSCSAdLoadSuccess = 1,
    PUSCSAdLoadFailure = -1,
    PUSCSAdLoadTimeout = -2
} PUSCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PUSCSAdPreloadSuccess = 1,
    //预加载失败
    PUSCSAdPreloadFailure = -1,
    //重复加载
    PUSCSAdPreloadRepeat = -2,
} PUSCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PUSCSAdWillAppear,//即将出现
    PUSCSAdDidAppear,//已经出现
    PUSCSAdWillDisappear,//即将消失
    PUSCSAdDidDisappear,//已经消失
    PUSCSAdMuted,//静音广告
    PUSCSAdWillLeaveApplication,//将要离开App

    PUSCSAdVideoStart,//开始播放 常用于video
    PUSCSAdVideoComplete,//播放完成 常用于video
    PUSCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PUSCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PUSCSAdNativeDidDownload,//下载完成 常用于fb Native
    PUSCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PUSCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PUSCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PUSCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PUSCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PUSCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PUSCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PUSCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PUSCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PUSCSAdBUOpenRenderSuccess, //渲染成功
    PUSCSAdBUOpenRenderFail, //渲染失败
    PUSCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PUSCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PUSCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PUSCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PUSCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PUSCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PUSCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PUSCSAdPlayerStatusStarted,//开始播放
    PUSCSAdPlayerStatusPaused,//用户行为导致暂停
    PUSCSAdPlayerStatusStoped,//播放停止
    PUSCSAdPlayerStatusError,//播放出错
    PUSCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PUSCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PUSCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PUSCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PUSCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PUSCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PUSCSAdRecordImpression, //广告曝光已记录
    PUSCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PUSCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PUSCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PUSCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PUSCSAdABUOpenWillPresentFullScreen,
    PUSCSAdABUOpenDidShowFailed,
    PUSCSAdABUOpenWillDissmissFullScreen,
    PUSCSAdABUOpenCountdownToZero,
    
    PUSCSAdABUBannerWillPresentFullScreen,
    PUSCSAdABUBannerWillDismissFullScreen,
    
    PUSCSAdABURewardDidLoad,
    PUSCSAdABURewardRenderFail,
    PUSCSAdABURewardDidShowFailed,

} PUSCSAdEvent;

typedef void (^PUSCSAdLoadCompleteBlock)(PUSCSAdLoadStatus adLoadStatus);

@class PUSCSAdSetupParamsMaker;
@class PUSCSAdSetupParams;

typedef PUSCSAdSetupParamsMaker *(^PUSCSAdStringInit)(NSString *);
typedef PUSCSAdSetupParamsMaker *(^PUSCSAdBoolInit)(BOOL);
typedef PUSCSAdSetupParamsMaker *(^PUSCSAdIntegerInit)(NSInteger);
typedef PUSCSAdSetupParamsMaker *(^PUSCSAdLongInit)(long);
typedef PUSCSAdSetupParamsMaker *(^PUSCSAdArrayInit)(NSArray *);
typedef PUSCSAdSetupParams *(^PUSCSAdMakeInit)(void);


@class PUSCSAdDataModel;
typedef void (^PUSCSAdRequestCompleteBlock)(NSMutableArray<PUSCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PUSCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PUSCSAdPreloadCompleteBlock)(PUSCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
