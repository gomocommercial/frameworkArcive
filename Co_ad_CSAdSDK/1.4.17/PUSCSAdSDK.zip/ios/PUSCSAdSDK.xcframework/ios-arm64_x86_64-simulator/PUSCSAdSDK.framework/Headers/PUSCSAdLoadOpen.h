//
//  PUSCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PUSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PUSCSAdLoadOpen : PUSCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
