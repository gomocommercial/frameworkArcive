//
//  PUSCSAdNetworkTool.h
//  PUSCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PUSCSAdDataModel.h"
#import "PUSCSAdTypedef.h"
#import "PUSCSNewStoreLiteRequestTool.h"
#import "NSString+PUSCSGenerateHash.h"

@interface PUSCSAdNetworkTool : NSObject

+ (PUSCSAdNetworkTool *)shared;
@property(nonatomic, copy) PUSCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pUSrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PUSCSAdRequestCompleteBlock)complete;

- (void)pUSsetCDay:(void(^ _Nullable)(bool success))handle;
@end
