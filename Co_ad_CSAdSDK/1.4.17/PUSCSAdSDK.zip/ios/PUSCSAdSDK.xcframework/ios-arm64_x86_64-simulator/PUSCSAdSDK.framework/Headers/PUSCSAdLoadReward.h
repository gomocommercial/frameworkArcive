//
//  PUSCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PUSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PUSCSAdLoadReward : PUSCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
