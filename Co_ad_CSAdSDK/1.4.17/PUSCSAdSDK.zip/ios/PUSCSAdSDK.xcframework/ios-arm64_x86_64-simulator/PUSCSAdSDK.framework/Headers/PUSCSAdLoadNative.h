//
//  PUSCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PUSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PUSCSAdLoadNative : PUSCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
