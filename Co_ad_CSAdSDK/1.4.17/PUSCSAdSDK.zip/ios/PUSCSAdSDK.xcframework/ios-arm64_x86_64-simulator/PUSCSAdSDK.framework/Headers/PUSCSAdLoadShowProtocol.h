//
//  PUSCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PUSCSAdTypedef.h"

@class PUSCSAdLoadBase;

@protocol PUSCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PUSCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pUSonAdShowed:(PUSCSAdLoadBase<PUSCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pUSonAdClicked:(PUSCSAdLoadBase<PUSCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pUSonAdClosed:(PUSCSAdLoadBase<PUSCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pUSonAdVideoCompletePlaying:(PUSCSAdLoadBase<PUSCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pUSonAdVideoGotReward:(PUSCSAdLoadBase<PUSCSAdLoadProtocol> *)adload;
-(void)pUSonAdDidPayRevenue:(PUSCSAdLoadBase<PUSCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)pUSonAdShowFail:(PUSCSAdLoadBase<PUSCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pUSonAdOtherEvent:(PUSCSAdLoadBase<PUSCSAdLoadProtocol> *)adload event:(PUSCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
