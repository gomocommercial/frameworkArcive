//
//  DCCSAdNetworkTool.h
//  DCCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "DCCSAdDataModel.h"
#import "DCCSAdTypedef.h"
#import "DCCSNewStoreLiteRequestTool.h"
#import "NSString+DCCSGenerateHash.h"

@interface DCCSAdNetworkTool : NSObject

+ (DCCSAdNetworkTool *)shared;
@property(nonatomic, copy) DCCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)dCrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(DCCSAdRequestCompleteBlock)complete;

- (void)dCsetCDay:(void(^ _Nullable)(bool success))handle;
@end
