//
//  FurTalesCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "FurTalesCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdLoadOpen : FurTalesCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
