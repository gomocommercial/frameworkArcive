//
//  FurTalesCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define furTaleskAdvDataSourceFacebook   2 //FB 广告数据源
#define furTaleskAdvDataSourceAdmob      8 //Admob 广告数据源
#define furTaleskAdvDataSourceMopub      39//Mopub 广告数据源
#define furTaleskAdvDataSourceApplovin   20//applovin 广告数据源

#define furTaleskAdvDataSourceGDT        62//广点通 广告数据源
#define furTaleskAdvDataSourceBaidu      63//百度 广告数据源
#define furTaleskAdvDataSourceBU         64//头条 广告数据源
#define furTaleskAdvDataSourceABU         70//头条聚合 广告数据源
#define furTaleskAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define furTaleskAdvDataSourcePangle     74//pangle 广告数据源

#define furTaleskOnlineAdvTypeBanner                   1  //banner
#define furTaleskOnlineAdvTypeInterstitial             2  //全屏
#define furTaleskOnlineAdvTypeNative                   3 //native
#define furTaleskOnlineAdvTypeVideo                    4 //视频
#define furTaleskOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define furTaleskOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define furTaleskOnlineAdvTypeOpen                     8 //开屏
#define furTaleskOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define furTaleskOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define furTaleskOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define furTaleskAdServerConfigError  -1 //服务器返回数据不正确
#define furTaleskAdLoadConfigFailed  -2 //广告加载失败


#define furTalesAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define furTaleskCSAdInstallDays @"furTaleskCSAdInstallDays"
#define furTaleskCSAdModule_key @"furTaleskCSAdModule_key_%@"
#define furTaleskCSNewAdModule_key @"furTaleskCSNewAdModule_key_%@"
#define furTaleskCSAdInstallTime @"furTaleskCSAdInstallTime"
#define furTaleskCSAdInstallHours @"furTaleskCSAdInstallHours"
#define furTaleskCSAdLastGetServerTime @"furTaleskCSAdLastRequestTime"
#define furTaleskCSAdloadTime 30

#define furTaleskCSLoadAdTimeOutNotification @"furTalesKCSLoadAdTimeOutNotification"
#define furTaleskCSLoadAdTimeOutNotificationKey @"furTalesKCSLoadAdTimeOutKey"

