//
//  FurTalesCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FurTalesCSAdTypedef.h"

@class FurTalesCSAdLoadBase;

@protocol FurTalesCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FurTalesCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)furTalesonAdShowed:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)furTalesonAdClicked:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)furTalesonAdClosed:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)furTalesonAdVideoCompletePlaying:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)furTalesonAdVideoGotReward:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload;
-(void)furTalesonAdDidPayRevenue:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)furTalesonAdShowFail:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)furTalesonAdOtherEvent:(FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload event:(FurTalesCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
