//
//  FurTalesCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "FurTalesCSAdLoadBase.h"
#import "FurTalesCSAdDataModel.h"
#import "FurTalesCSAdLoadProtocol.h"
#import "FurTalesCSAdLoadDataProtocol.h"
#import "FurTalesCSAdLoadShowProtocol.h"
#import "FurTalesCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)furTalessetupByBlock:(void (^ _Nonnull)(FurTalesCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)furTalesloadAd:(NSString *)moduleId delegate:(id<FurTalesCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)furTalesadShowStatistic:(FurTalesCSAdDataModel *)dataModel adload:(nonnull FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)furTalesadClickStatistic:(FurTalesCSAdDataModel *)dataModel adload:(nonnull FurTalesCSAdLoadBase<FurTalesCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)furTalesaddCustomFecher:(Class<FurTalesCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
