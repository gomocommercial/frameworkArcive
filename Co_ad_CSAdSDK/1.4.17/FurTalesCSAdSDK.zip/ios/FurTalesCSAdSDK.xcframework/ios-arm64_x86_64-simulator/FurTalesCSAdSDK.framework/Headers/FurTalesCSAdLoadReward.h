//
//  FurTalesCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "FurTalesCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdLoadReward : FurTalesCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
