//
//  FurTalesCSAdNetworkTool.h
//  FurTalesCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "FurTalesCSAdDataModel.h"
#import "FurTalesCSAdTypedef.h"
#import "FurTalesCSNewStoreLiteRequestTool.h"
#import "NSString+FurTalesCSGenerateHash.h"

@interface FurTalesCSAdNetworkTool : NSObject

+ (FurTalesCSAdNetworkTool *)shared;
@property(nonatomic, copy) FurTalesCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)furTalesrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(FurTalesCSAdRequestCompleteBlock)complete;

- (void)furTalessetCDay:(void(^ _Nullable)(bool success))handle;
@end
