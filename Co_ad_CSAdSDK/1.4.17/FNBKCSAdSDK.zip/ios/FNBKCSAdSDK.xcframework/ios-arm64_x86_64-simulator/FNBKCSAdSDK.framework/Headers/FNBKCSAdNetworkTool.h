//
//  FNBKCSAdNetworkTool.h
//  FNBKCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "FNBKCSAdDataModel.h"
#import "FNBKCSAdTypedef.h"
#import "FNBKCSNewStoreLiteRequestTool.h"
#import "NSString+FNBKCSGenerateHash.h"

@interface FNBKCSAdNetworkTool : NSObject

+ (FNBKCSAdNetworkTool *)shared;
@property(nonatomic, copy) FNBKCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)fNBKrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(FNBKCSAdRequestCompleteBlock)complete;

- (void)fNBKsetCDay:(void(^ _Nullable)(bool success))handle;
@end
