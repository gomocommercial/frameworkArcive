//
//  FNBKCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "FNBKCSAdLoadBase.h"
#import "FNBKCSAdDataModel.h"
#import "FNBKCSAdLoadProtocol.h"
#import "FNBKCSAdLoadDataProtocol.h"
#import "FNBKCSAdLoadShowProtocol.h"
#import "FNBKCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNBKCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)fNBKsetupByBlock:(void (^ _Nonnull)(FNBKCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)fNBKloadAd:(NSString *)moduleId delegate:(id<FNBKCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)fNBKadShowStatistic:(FNBKCSAdDataModel *)dataModel adload:(nonnull FNBKCSAdLoadBase<FNBKCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)fNBKadClickStatistic:(FNBKCSAdDataModel *)dataModel adload:(nonnull FNBKCSAdLoadBase<FNBKCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)fNBKaddCustomFecher:(Class<FNBKCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
