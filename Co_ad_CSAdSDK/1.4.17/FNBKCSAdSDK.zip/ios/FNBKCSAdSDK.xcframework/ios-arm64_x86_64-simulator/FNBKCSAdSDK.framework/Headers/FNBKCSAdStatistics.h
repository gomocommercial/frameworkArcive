//
//  FNBKCSAdStatistics.h
//  FNBKCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "FNBKCSAdDataModel.h"
#import "FNBKCSAdTypedef.h"
#import "FNBKCSAdLoadBase.h"
@interface FNBKCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)fNBKadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)fNBKadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)fNBKadRewardVideoCompleteStatistic:(FNBKCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)fNBKadShowStatistic:(FNBKCSAdDataModel *)dataModel adload:(nonnull FNBKCSAdLoadBase<FNBKCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)fNBKadClickStatistic:(FNBKCSAdDataModel *)dataModel adload:(nonnull FNBKCSAdLoadBase<FNBKCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)fNBKadUploadRevenueStatistic:(FNBKCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
