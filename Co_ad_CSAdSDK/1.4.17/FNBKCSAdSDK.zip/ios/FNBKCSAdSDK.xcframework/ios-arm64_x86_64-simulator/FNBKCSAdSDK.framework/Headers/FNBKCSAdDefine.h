//
//  FNBKCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define fNBKkAdvDataSourceFacebook   2 //FB 广告数据源
#define fNBKkAdvDataSourceAdmob      8 //Admob 广告数据源
#define fNBKkAdvDataSourceMopub      39//Mopub 广告数据源
#define fNBKkAdvDataSourceApplovin   20//applovin 广告数据源

#define fNBKkAdvDataSourceGDT        62//广点通 广告数据源
#define fNBKkAdvDataSourceBaidu      63//百度 广告数据源
#define fNBKkAdvDataSourceBU         64//头条 广告数据源
#define fNBKkAdvDataSourceABU         70//头条聚合 广告数据源
#define fNBKkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define fNBKkAdvDataSourcePangle     74//pangle 广告数据源

#define fNBKkOnlineAdvTypeBanner                   1  //banner
#define fNBKkOnlineAdvTypeInterstitial             2  //全屏
#define fNBKkOnlineAdvTypeNative                   3 //native
#define fNBKkOnlineAdvTypeVideo                    4 //视频
#define fNBKkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define fNBKkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define fNBKkOnlineAdvTypeOpen                     8 //开屏
#define fNBKkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define fNBKkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define fNBKkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define fNBKkAdServerConfigError  -1 //服务器返回数据不正确
#define fNBKkAdLoadConfigFailed  -2 //广告加载失败


#define fNBKAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define fNBKkCSAdInstallDays @"fNBKkCSAdInstallDays"
#define fNBKkCSAdModule_key @"fNBKkCSAdModule_key_%@"
#define fNBKkCSNewAdModule_key @"fNBKkCSNewAdModule_key_%@"
#define fNBKkCSAdInstallTime @"fNBKkCSAdInstallTime"
#define fNBKkCSAdInstallHours @"fNBKkCSAdInstallHours"
#define fNBKkCSAdLastGetServerTime @"fNBKkCSAdLastRequestTime"
#define fNBKkCSAdloadTime 30

#define fNBKkCSLoadAdTimeOutNotification @"fNBKKCSLoadAdTimeOutNotification"
#define fNBKkCSLoadAdTimeOutNotificationKey @"fNBKKCSLoadAdTimeOutKey"

