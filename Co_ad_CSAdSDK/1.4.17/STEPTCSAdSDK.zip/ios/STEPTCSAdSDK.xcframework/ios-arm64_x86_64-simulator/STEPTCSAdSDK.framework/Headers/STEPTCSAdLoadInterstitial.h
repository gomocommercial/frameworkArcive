//
//  STEPTCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "STEPTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdLoadInterstitial : STEPTCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
