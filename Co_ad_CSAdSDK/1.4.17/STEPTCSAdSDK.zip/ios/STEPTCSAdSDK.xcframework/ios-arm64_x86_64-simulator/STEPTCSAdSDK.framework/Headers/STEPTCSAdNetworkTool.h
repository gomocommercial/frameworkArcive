//
//  STEPTCSAdNetworkTool.h
//  STEPTCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "STEPTCSAdDataModel.h"
#import "STEPTCSAdTypedef.h"
#import "STEPTCSNewStoreLiteRequestTool.h"
#import "NSString+STEPTCSGenerateHash.h"

@interface STEPTCSAdNetworkTool : NSObject

+ (STEPTCSAdNetworkTool *)shared;
@property(nonatomic, copy) STEPTCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sTEPTrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(STEPTCSAdRequestCompleteBlock)complete;

- (void)sTEPTsetCDay:(void(^ _Nullable)(bool success))handle;
@end
