//
//  STEPTCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "STEPTCSAdTypedef.h"

@class STEPTCSAdLoadBase;

@protocol STEPTCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol STEPTCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sTEPTonAdShowed:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sTEPTonAdClicked:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sTEPTonAdClosed:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sTEPTonAdVideoCompletePlaying:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sTEPTonAdVideoGotReward:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload;
-(void)sTEPTonAdDidPayRevenue:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)sTEPTonAdShowFail:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sTEPTonAdOtherEvent:(STEPTCSAdLoadBase<STEPTCSAdLoadProtocol> *)adload event:(STEPTCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
