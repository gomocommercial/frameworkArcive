//
//  MEETAICSAdNetworkTool.h
//  MEETAICSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "MEETAICSAdDataModel.h"
#import "MEETAICSAdTypedef.h"
#import "MEETAICSNewStoreLiteRequestTool.h"
#import "NSString+MEETAICSGenerateHash.h"

@interface MEETAICSAdNetworkTool : NSObject

+ (MEETAICSAdNetworkTool *)shared;
@property(nonatomic, copy) MEETAICSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)mEETAIrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(MEETAICSAdRequestCompleteBlock)complete;

- (void)mEETAIsetCDay:(void(^ _Nullable)(bool success))handle;
@end
