//
//  MEETAICSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MEETAICSAdTypedef.h"

@class MEETAICSAdLoadBase;

@protocol MEETAICSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MEETAICSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mEETAIonAdShowed:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)mEETAIonAdClicked:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mEETAIonAdClosed:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mEETAIonAdVideoCompletePlaying:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)mEETAIonAdVideoGotReward:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload;
-(void)mEETAIonAdDidPayRevenue:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)mEETAIonAdShowFail:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mEETAIonAdOtherEvent:(MEETAICSAdLoadBase<MEETAICSAdLoadProtocol> *)adload event:(MEETAICSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
