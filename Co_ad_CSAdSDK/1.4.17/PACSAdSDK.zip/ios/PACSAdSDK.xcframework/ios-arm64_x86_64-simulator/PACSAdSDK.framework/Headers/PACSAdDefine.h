//
//  PACSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pAkAdvDataSourceFacebook   2 //FB 广告数据源
#define pAkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pAkAdvDataSourceMopub      39//Mopub 广告数据源
#define pAkAdvDataSourceApplovin   20//applovin 广告数据源

#define pAkAdvDataSourceGDT        62//广点通 广告数据源
#define pAkAdvDataSourceBaidu      63//百度 广告数据源
#define pAkAdvDataSourceBU         64//头条 广告数据源
#define pAkAdvDataSourceABU         70//头条聚合 广告数据源
#define pAkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pAkAdvDataSourcePangle     74//pangle 广告数据源

#define pAkOnlineAdvTypeBanner                   1  //banner
#define pAkOnlineAdvTypeInterstitial             2  //全屏
#define pAkOnlineAdvTypeNative                   3 //native
#define pAkOnlineAdvTypeVideo                    4 //视频
#define pAkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pAkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pAkOnlineAdvTypeOpen                     8 //开屏
#define pAkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pAkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pAkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pAkAdServerConfigError  -1 //服务器返回数据不正确
#define pAkAdLoadConfigFailed  -2 //广告加载失败


#define pAAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pAkCSAdInstallDays @"pAkCSAdInstallDays"
#define pAkCSAdModule_key @"pAkCSAdModule_key_%@"
#define pAkCSNewAdModule_key @"pAkCSNewAdModule_key_%@"
#define pAkCSAdInstallTime @"pAkCSAdInstallTime"
#define pAkCSAdInstallHours @"pAkCSAdInstallHours"
#define pAkCSAdLastGetServerTime @"pAkCSAdLastRequestTime"
#define pAkCSAdloadTime 30

#define pAkCSLoadAdTimeOutNotification @"pAKCSLoadAdTimeOutNotification"
#define pAkCSLoadAdTimeOutNotificationKey @"pAKCSLoadAdTimeOutKey"

