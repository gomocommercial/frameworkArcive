//
//  PACSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PACSAdLoadBase.h"
#import "PACSAdDataModel.h"
#import "PACSAdLoadProtocol.h"
#import "PACSAdLoadDataProtocol.h"
#import "PACSAdLoadShowProtocol.h"
#import "PACSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PACSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pAsetupByBlock:(void (^ _Nonnull)(PACSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pAloadAd:(NSString *)moduleId delegate:(id<PACSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pAadShowStatistic:(PACSAdDataModel *)dataModel adload:(nonnull PACSAdLoadBase<PACSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pAadClickStatistic:(PACSAdDataModel *)dataModel adload:(nonnull PACSAdLoadBase<PACSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pAaddCustomFecher:(Class<PACSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
