//
//  PACSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PACSAdTypedef.h"

@class PACSAdLoadBase;

@protocol PACSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PACSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pAonAdShowed:(PACSAdLoadBase<PACSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pAonAdClicked:(PACSAdLoadBase<PACSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pAonAdClosed:(PACSAdLoadBase<PACSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pAonAdVideoCompletePlaying:(PACSAdLoadBase<PACSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pAonAdVideoGotReward:(PACSAdLoadBase<PACSAdLoadProtocol> *)adload;
-(void)pAonAdDidPayRevenue:(PACSAdLoadBase<PACSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)pAonAdShowFail:(PACSAdLoadBase<PACSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pAonAdOtherEvent:(PACSAdLoadBase<PACSAdLoadProtocol> *)adload event:(PACSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
