//
//  PACSAdNetworkTool.h
//  PACSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PACSAdDataModel.h"
#import "PACSAdTypedef.h"
#import "PACSNewStoreLiteRequestTool.h"
#import "NSString+PACSGenerateHash.h"

@interface PACSAdNetworkTool : NSObject

+ (PACSAdNetworkTool *)shared;
@property(nonatomic, copy) PACSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pArequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PACSAdRequestCompleteBlock)complete;

- (void)pAsetCDay:(void(^ _Nullable)(bool success))handle;
@end
