//
//  PACSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PACSAdLoadReward : PACSAdLoadBase

@end

NS_ASSUME_NONNULL_END
