//
//  PACSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PACSAdLoadSuccess = 1,
    PACSAdLoadFailure = -1,
    PACSAdLoadTimeout = -2
} PACSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PACSAdPreloadSuccess = 1,
    //预加载失败
    PACSAdPreloadFailure = -1,
    //重复加载
    PACSAdPreloadRepeat = -2,
} PACSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PACSAdWillAppear,//即将出现
    PACSAdDidAppear,//已经出现
    PACSAdWillDisappear,//即将消失
    PACSAdDidDisappear,//已经消失
    PACSAdMuted,//静音广告
    PACSAdWillLeaveApplication,//将要离开App

    PACSAdVideoStart,//开始播放 常用于video
    PACSAdVideoComplete,//播放完成 常用于video
    PACSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PACSAdVideoServerFail,//连接服务器成功，常用于fb video

    PACSAdNativeDidDownload,//下载完成 常用于fb Native
    PACSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PACSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PACSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PACSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PACSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PACSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PACSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PACSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PACSAdBUOpenDidAutoDimiss,//开屏自动消失
    PACSAdBUOpenRenderSuccess, //渲染成功
    PACSAdBUOpenRenderFail, //渲染失败
    PACSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PACSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PACSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PACSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PACSAdDidPresentFullScreen,//插屏弹出全屏广告
    PACSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PACSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PACSAdPlayerStatusStarted,//开始播放
    PACSAdPlayerStatusPaused,//用户行为导致暂停
    PACSAdPlayerStatusStoped,//播放停止
    PACSAdPlayerStatusError,//播放出错
    PACSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PACSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PACSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PACSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PACSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PACSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PACSAdRecordImpression, //广告曝光已记录
    PACSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PACSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PACSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PACSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PACSAdABUOpenWillPresentFullScreen,
    PACSAdABUOpenDidShowFailed,
    PACSAdABUOpenWillDissmissFullScreen,
    PACSAdABUOpenCountdownToZero,
    
    PACSAdABUBannerWillPresentFullScreen,
    PACSAdABUBannerWillDismissFullScreen,
    
    PACSAdABURewardDidLoad,
    PACSAdABURewardRenderFail,
    PACSAdABURewardDidShowFailed,

} PACSAdEvent;

typedef void (^PACSAdLoadCompleteBlock)(PACSAdLoadStatus adLoadStatus);

@class PACSAdSetupParamsMaker;
@class PACSAdSetupParams;

typedef PACSAdSetupParamsMaker *(^PACSAdStringInit)(NSString *);
typedef PACSAdSetupParamsMaker *(^PACSAdBoolInit)(BOOL);
typedef PACSAdSetupParamsMaker *(^PACSAdIntegerInit)(NSInteger);
typedef PACSAdSetupParamsMaker *(^PACSAdLongInit)(long);
typedef PACSAdSetupParamsMaker *(^PACSAdArrayInit)(NSArray *);
typedef PACSAdSetupParams *(^PACSAdMakeInit)(void);


@class PACSAdDataModel;
typedef void (^PACSAdRequestCompleteBlock)(NSMutableArray<PACSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PACSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PACSAdPreloadCompleteBlock)(PACSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
