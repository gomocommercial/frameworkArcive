//
//  TLCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "TLCSAdTypedef.h"

@class TLCSAdLoadBase;

@protocol TLCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol TLCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)tLonAdShowed:(TLCSAdLoadBase<TLCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)tLonAdClicked:(TLCSAdLoadBase<TLCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)tLonAdClosed:(TLCSAdLoadBase<TLCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)tLonAdVideoCompletePlaying:(TLCSAdLoadBase<TLCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)tLonAdVideoGotReward:(TLCSAdLoadBase<TLCSAdLoadProtocol> *)adload;
-(void)tLonAdDidPayRevenue:(TLCSAdLoadBase<TLCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)tLonAdShowFail:(TLCSAdLoadBase<TLCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)tLonAdOtherEvent:(TLCSAdLoadBase<TLCSAdLoadProtocol> *)adload event:(TLCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
