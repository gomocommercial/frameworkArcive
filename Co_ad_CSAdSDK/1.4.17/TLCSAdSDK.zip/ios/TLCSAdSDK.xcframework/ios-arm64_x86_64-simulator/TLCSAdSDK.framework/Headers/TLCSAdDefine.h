//
//  TLCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tLkAdvDataSourceFacebook   2 //FB 广告数据源
#define tLkAdvDataSourceAdmob      8 //Admob 广告数据源
#define tLkAdvDataSourceMopub      39//Mopub 广告数据源
#define tLkAdvDataSourceApplovin   20//applovin 广告数据源

#define tLkAdvDataSourceGDT        62//广点通 广告数据源
#define tLkAdvDataSourceBaidu      63//百度 广告数据源
#define tLkAdvDataSourceBU         64//头条 广告数据源
#define tLkAdvDataSourceABU         70//头条聚合 广告数据源
#define tLkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define tLkAdvDataSourcePangle     74//pangle 广告数据源

#define tLkOnlineAdvTypeBanner                   1  //banner
#define tLkOnlineAdvTypeInterstitial             2  //全屏
#define tLkOnlineAdvTypeNative                   3 //native
#define tLkOnlineAdvTypeVideo                    4 //视频
#define tLkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define tLkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define tLkOnlineAdvTypeOpen                     8 //开屏
#define tLkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define tLkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define tLkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define tLkAdServerConfigError  -1 //服务器返回数据不正确
#define tLkAdLoadConfigFailed  -2 //广告加载失败


#define tLAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tLkCSAdInstallDays @"tLkCSAdInstallDays"
#define tLkCSAdModule_key @"tLkCSAdModule_key_%@"
#define tLkCSNewAdModule_key @"tLkCSNewAdModule_key_%@"
#define tLkCSAdInstallTime @"tLkCSAdInstallTime"
#define tLkCSAdInstallHours @"tLkCSAdInstallHours"
#define tLkCSAdLastGetServerTime @"tLkCSAdLastRequestTime"
#define tLkCSAdloadTime 30

#define tLkCSLoadAdTimeOutNotification @"tLKCSLoadAdTimeOutNotification"
#define tLkCSLoadAdTimeOutNotificationKey @"tLKCSLoadAdTimeOutKey"

