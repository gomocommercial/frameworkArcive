//
//  TLCSAdNetworkTool.h
//  TLCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "TLCSAdDataModel.h"
#import "TLCSAdTypedef.h"
#import "TLCSNewStoreLiteRequestTool.h"
#import "NSString+TLCSGenerateHash.h"

@interface TLCSAdNetworkTool : NSObject

+ (TLCSAdNetworkTool *)shared;
@property(nonatomic, copy) TLCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)tLrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(TLCSAdRequestCompleteBlock)complete;

- (void)tLsetCDay:(void(^ _Nullable)(bool success))handle;
@end
