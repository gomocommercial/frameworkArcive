//
//  TasteLensCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tasteLenskAdvDataSourceFacebook   2 //FB 广告数据源
#define tasteLenskAdvDataSourceAdmob      8 //Admob 广告数据源
#define tasteLenskAdvDataSourceMopub      39//Mopub 广告数据源
#define tasteLenskAdvDataSourceApplovin   20//applovin 广告数据源

#define tasteLenskAdvDataSourceGDT        62//广点通 广告数据源
#define tasteLenskAdvDataSourceBaidu      63//百度 广告数据源
#define tasteLenskAdvDataSourceBU         64//头条 广告数据源
#define tasteLenskAdvDataSourceABU         70//头条聚合 广告数据源
#define tasteLenskAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define tasteLenskAdvDataSourcePangle     74//pangle 广告数据源

#define tasteLenskOnlineAdvTypeBanner                   1  //banner
#define tasteLenskOnlineAdvTypeInterstitial             2  //全屏
#define tasteLenskOnlineAdvTypeNative                   3 //native
#define tasteLenskOnlineAdvTypeVideo                    4 //视频
#define tasteLenskOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define tasteLenskOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define tasteLenskOnlineAdvTypeOpen                     8 //开屏
#define tasteLenskOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define tasteLenskOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define tasteLenskOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define tasteLenskAdServerConfigError  -1 //服务器返回数据不正确
#define tasteLenskAdLoadConfigFailed  -2 //广告加载失败


#define tasteLensAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tasteLenskCSAdInstallDays @"tasteLenskCSAdInstallDays"
#define tasteLenskCSAdModule_key @"tasteLenskCSAdModule_key_%@"
#define tasteLenskCSNewAdModule_key @"tasteLenskCSNewAdModule_key_%@"
#define tasteLenskCSAdInstallTime @"tasteLenskCSAdInstallTime"
#define tasteLenskCSAdInstallHours @"tasteLenskCSAdInstallHours"
#define tasteLenskCSAdLastGetServerTime @"tasteLenskCSAdLastRequestTime"
#define tasteLenskCSAdloadTime 30

#define tasteLenskCSLoadAdTimeOutNotification @"tasteLensKCSLoadAdTimeOutNotification"
#define tasteLenskCSLoadAdTimeOutNotificationKey @"tasteLensKCSLoadAdTimeOutKey"

