//
//  TasteLensCSAdLoadDataProtocol.h
//  TasteLensCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "TasteLensCSAdTypedef.h"

@class TasteLensCSAdDataModel;
@class TasteLensCSAdLoadBase;

@protocol TasteLensCSAdLoadProtocol;

@protocol TasteLensCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)tasteLensonAdInfoFinish:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)tasteLensonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)tasteLensonAdFail:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
