//
//  TasteLensCSAdNetworkTool.h
//  TasteLensCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "TasteLensCSAdDataModel.h"
#import "TasteLensCSAdTypedef.h"
#import "TasteLensCSNewStoreLiteRequestTool.h"
#import "NSString+TasteLensCSGenerateHash.h"

@interface TasteLensCSAdNetworkTool : NSObject

+ (TasteLensCSAdNetworkTool *)shared;
@property(nonatomic, copy) TasteLensCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)tasteLensrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(TasteLensCSAdRequestCompleteBlock)complete;

- (void)tasteLenssetCDay:(void(^ _Nullable)(bool success))handle;
@end
