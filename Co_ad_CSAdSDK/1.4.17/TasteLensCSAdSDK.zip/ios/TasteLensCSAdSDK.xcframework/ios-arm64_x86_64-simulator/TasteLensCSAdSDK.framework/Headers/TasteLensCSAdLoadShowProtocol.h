//
//  TasteLensCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "TasteLensCSAdTypedef.h"

@class TasteLensCSAdLoadBase;

@protocol TasteLensCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol TasteLensCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)tasteLensonAdShowed:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)tasteLensonAdClicked:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)tasteLensonAdClosed:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)tasteLensonAdVideoCompletePlaying:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)tasteLensonAdVideoGotReward:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload;
-(void)tasteLensonAdDidPayRevenue:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)tasteLensonAdShowFail:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)tasteLensonAdOtherEvent:(TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload event:(TasteLensCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
