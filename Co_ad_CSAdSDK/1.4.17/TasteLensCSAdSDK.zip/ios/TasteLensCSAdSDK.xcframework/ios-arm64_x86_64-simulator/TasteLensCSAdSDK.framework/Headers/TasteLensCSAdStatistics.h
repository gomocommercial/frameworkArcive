//
//  TasteLensCSAdStatistics.h
//  TasteLensCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "TasteLensCSAdDataModel.h"
#import "TasteLensCSAdTypedef.h"
#import "TasteLensCSAdLoadBase.h"
@interface TasteLensCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)tasteLensadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)tasteLensadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)tasteLensadRewardVideoCompleteStatistic:(TasteLensCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)tasteLensadShowStatistic:(TasteLensCSAdDataModel *)dataModel adload:(nonnull TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)tasteLensadClickStatistic:(TasteLensCSAdDataModel *)dataModel adload:(nonnull TasteLensCSAdLoadBase<TasteLensCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)tasteLensadUploadRevenueStatistic:(TasteLensCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
