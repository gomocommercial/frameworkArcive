//
//  TasteLensCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TasteLensCSAdLoadSuccess = 1,
    TasteLensCSAdLoadFailure = -1,
    TasteLensCSAdLoadTimeout = -2
} TasteLensCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TasteLensCSAdPreloadSuccess = 1,
    //预加载失败
    TasteLensCSAdPreloadFailure = -1,
    //重复加载
    TasteLensCSAdPreloadRepeat = -2,
} TasteLensCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TasteLensCSAdWillAppear,//即将出现
    TasteLensCSAdDidAppear,//已经出现
    TasteLensCSAdWillDisappear,//即将消失
    TasteLensCSAdDidDisappear,//已经消失
    TasteLensCSAdMuted,//静音广告
    TasteLensCSAdWillLeaveApplication,//将要离开App

    TasteLensCSAdVideoStart,//开始播放 常用于video
    TasteLensCSAdVideoComplete,//播放完成 常用于video
    TasteLensCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TasteLensCSAdVideoServerFail,//连接服务器成功，常用于fb video

    TasteLensCSAdNativeDidDownload,//下载完成 常用于fb Native
    TasteLensCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TasteLensCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    TasteLensCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    TasteLensCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    TasteLensCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    TasteLensCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    TasteLensCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    TasteLensCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    TasteLensCSAdBUOpenDidAutoDimiss,//开屏自动消失
    TasteLensCSAdBUOpenRenderSuccess, //渲染成功
    TasteLensCSAdBUOpenRenderFail, //渲染失败
    TasteLensCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    TasteLensCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    TasteLensCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    TasteLensCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    TasteLensCSAdDidPresentFullScreen,//插屏弹出全屏广告
    TasteLensCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    TasteLensCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    TasteLensCSAdPlayerStatusStarted,//开始播放
    TasteLensCSAdPlayerStatusPaused,//用户行为导致暂停
    TasteLensCSAdPlayerStatusStoped,//播放停止
    TasteLensCSAdPlayerStatusError,//播放出错
    TasteLensCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    TasteLensCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    TasteLensCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    TasteLensCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    TasteLensCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    TasteLensCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    TasteLensCSAdRecordImpression, //广告曝光已记录
    TasteLensCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    TasteLensCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    TasteLensCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    TasteLensCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    TasteLensCSAdABUOpenWillPresentFullScreen,
    TasteLensCSAdABUOpenDidShowFailed,
    TasteLensCSAdABUOpenWillDissmissFullScreen,
    TasteLensCSAdABUOpenCountdownToZero,
    
    TasteLensCSAdABUBannerWillPresentFullScreen,
    TasteLensCSAdABUBannerWillDismissFullScreen,
    
    TasteLensCSAdABURewardDidLoad,
    TasteLensCSAdABURewardRenderFail,
    TasteLensCSAdABURewardDidShowFailed,

} TasteLensCSAdEvent;

typedef void (^TasteLensCSAdLoadCompleteBlock)(TasteLensCSAdLoadStatus adLoadStatus);

@class TasteLensCSAdSetupParamsMaker;
@class TasteLensCSAdSetupParams;

typedef TasteLensCSAdSetupParamsMaker *(^TasteLensCSAdStringInit)(NSString *);
typedef TasteLensCSAdSetupParamsMaker *(^TasteLensCSAdBoolInit)(BOOL);
typedef TasteLensCSAdSetupParamsMaker *(^TasteLensCSAdIntegerInit)(NSInteger);
typedef TasteLensCSAdSetupParamsMaker *(^TasteLensCSAdLongInit)(long);
typedef TasteLensCSAdSetupParamsMaker *(^TasteLensCSAdArrayInit)(NSArray *);
typedef TasteLensCSAdSetupParams *(^TasteLensCSAdMakeInit)(void);


@class TasteLensCSAdDataModel;
typedef void (^TasteLensCSAdRequestCompleteBlock)(NSMutableArray<TasteLensCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TasteLensCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TasteLensCSAdPreloadCompleteBlock)(TasteLensCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
