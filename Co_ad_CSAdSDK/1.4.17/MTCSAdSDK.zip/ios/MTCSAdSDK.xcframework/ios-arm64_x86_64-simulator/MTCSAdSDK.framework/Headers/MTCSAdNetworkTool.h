//
//  MTCSAdNetworkTool.h
//  MTCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "MTCSAdDataModel.h"
#import "MTCSAdTypedef.h"
#import "MTCSNewStoreLiteRequestTool.h"
#import "NSString+MTCSGenerateHash.h"

@interface MTCSAdNetworkTool : NSObject

+ (MTCSAdNetworkTool *)shared;
@property(nonatomic, copy) MTCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)mTrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(MTCSAdRequestCompleteBlock)complete;

- (void)mTsetCDay:(void(^ _Nullable)(bool success))handle;
@end
