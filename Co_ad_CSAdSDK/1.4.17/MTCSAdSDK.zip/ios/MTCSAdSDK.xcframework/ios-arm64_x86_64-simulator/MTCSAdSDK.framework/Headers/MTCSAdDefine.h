//
//  MTCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define mTkAdvDataSourceFacebook   2 //FB 广告数据源
#define mTkAdvDataSourceAdmob      8 //Admob 广告数据源
#define mTkAdvDataSourceMopub      39//Mopub 广告数据源
#define mTkAdvDataSourceApplovin   20//applovin 广告数据源

#define mTkAdvDataSourceGDT        62//广点通 广告数据源
#define mTkAdvDataSourceBaidu      63//百度 广告数据源
#define mTkAdvDataSourceBU         64//头条 广告数据源
#define mTkAdvDataSourceABU         70//头条聚合 广告数据源
#define mTkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define mTkAdvDataSourcePangle     74//pangle 广告数据源

#define mTkOnlineAdvTypeBanner                   1  //banner
#define mTkOnlineAdvTypeInterstitial             2  //全屏
#define mTkOnlineAdvTypeNative                   3 //native
#define mTkOnlineAdvTypeVideo                    4 //视频
#define mTkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define mTkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define mTkOnlineAdvTypeOpen                     8 //开屏
#define mTkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define mTkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define mTkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define mTkAdServerConfigError  -1 //服务器返回数据不正确
#define mTkAdLoadConfigFailed  -2 //广告加载失败


#define mTAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define mTkCSAdInstallDays @"mTkCSAdInstallDays"
#define mTkCSAdModule_key @"mTkCSAdModule_key_%@"
#define mTkCSNewAdModule_key @"mTkCSNewAdModule_key_%@"
#define mTkCSAdInstallTime @"mTkCSAdInstallTime"
#define mTkCSAdInstallHours @"mTkCSAdInstallHours"
#define mTkCSAdLastGetServerTime @"mTkCSAdLastRequestTime"
#define mTkCSAdloadTime 30

#define mTkCSLoadAdTimeOutNotification @"mTKCSLoadAdTimeOutNotification"
#define mTkCSLoadAdTimeOutNotificationKey @"mTKCSLoadAdTimeOutKey"

