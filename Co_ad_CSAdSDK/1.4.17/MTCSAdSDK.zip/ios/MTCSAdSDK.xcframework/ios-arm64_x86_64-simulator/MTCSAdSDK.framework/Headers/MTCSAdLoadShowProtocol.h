//
//  MTCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MTCSAdTypedef.h"

@class MTCSAdLoadBase;

@protocol MTCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MTCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mTonAdShowed:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)mTonAdClicked:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mTonAdClosed:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mTonAdVideoCompletePlaying:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)mTonAdVideoGotReward:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload;
-(void)mTonAdDidPayRevenue:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)mTonAdShowFail:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mTonAdOtherEvent:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload event:(MTCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
