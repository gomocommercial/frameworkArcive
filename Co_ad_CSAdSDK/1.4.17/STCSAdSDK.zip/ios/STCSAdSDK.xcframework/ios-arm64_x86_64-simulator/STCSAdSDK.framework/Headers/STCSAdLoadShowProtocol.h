//
//  STCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "STCSAdTypedef.h"

@class STCSAdLoadBase;

@protocol STCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol STCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sTonAdShowed:(STCSAdLoadBase<STCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sTonAdClicked:(STCSAdLoadBase<STCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sTonAdClosed:(STCSAdLoadBase<STCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sTonAdVideoCompletePlaying:(STCSAdLoadBase<STCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sTonAdVideoGotReward:(STCSAdLoadBase<STCSAdLoadProtocol> *)adload;
-(void)sTonAdDidPayRevenue:(STCSAdLoadBase<STCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)sTonAdShowFail:(STCSAdLoadBase<STCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sTonAdOtherEvent:(STCSAdLoadBase<STCSAdLoadProtocol> *)adload event:(STCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
