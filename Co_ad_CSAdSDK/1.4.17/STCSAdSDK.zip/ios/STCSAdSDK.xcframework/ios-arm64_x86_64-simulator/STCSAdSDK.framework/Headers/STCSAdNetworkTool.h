//
//  STCSAdNetworkTool.h
//  STCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "STCSAdDataModel.h"
#import "STCSAdTypedef.h"
#import "STCSNewStoreLiteRequestTool.h"
#import "NSString+STCSGenerateHash.h"

@interface STCSAdNetworkTool : NSObject

+ (STCSAdNetworkTool *)shared;
@property(nonatomic, copy) STCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sTrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(STCSAdRequestCompleteBlock)complete;

- (void)sTsetCDay:(void(^ _Nullable)(bool success))handle;
@end
