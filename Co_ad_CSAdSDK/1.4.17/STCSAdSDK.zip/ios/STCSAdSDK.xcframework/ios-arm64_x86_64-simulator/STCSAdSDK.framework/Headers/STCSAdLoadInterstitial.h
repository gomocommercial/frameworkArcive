//
//  STCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "STCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface STCSAdLoadInterstitial : STCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
