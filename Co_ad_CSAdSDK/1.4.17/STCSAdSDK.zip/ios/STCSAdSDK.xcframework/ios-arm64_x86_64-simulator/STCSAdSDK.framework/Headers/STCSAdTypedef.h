//
//  STCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    STCSAdLoadSuccess = 1,
    STCSAdLoadFailure = -1,
    STCSAdLoadTimeout = -2
} STCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    STCSAdPreloadSuccess = 1,
    //预加载失败
    STCSAdPreloadFailure = -1,
    //重复加载
    STCSAdPreloadRepeat = -2,
} STCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    STCSAdWillAppear,//即将出现
    STCSAdDidAppear,//已经出现
    STCSAdWillDisappear,//即将消失
    STCSAdDidDisappear,//已经消失
    STCSAdMuted,//静音广告
    STCSAdWillLeaveApplication,//将要离开App

    STCSAdVideoStart,//开始播放 常用于video
    STCSAdVideoComplete,//播放完成 常用于video
    STCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    STCSAdVideoServerFail,//连接服务器成功，常用于fb video

    STCSAdNativeDidDownload,//下载完成 常用于fb Native
    STCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    STCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    STCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    STCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    STCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    STCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    STCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    STCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    STCSAdBUOpenDidAutoDimiss,//开屏自动消失
    STCSAdBUOpenRenderSuccess, //渲染成功
    STCSAdBUOpenRenderFail, //渲染失败
    STCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    STCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    STCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    STCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    STCSAdDidPresentFullScreen,//插屏弹出全屏广告
    STCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    STCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    STCSAdPlayerStatusStarted,//开始播放
    STCSAdPlayerStatusPaused,//用户行为导致暂停
    STCSAdPlayerStatusStoped,//播放停止
    STCSAdPlayerStatusError,//播放出错
    STCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    STCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    STCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    STCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    STCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    STCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    STCSAdRecordImpression, //广告曝光已记录
    STCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    STCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    STCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    STCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    STCSAdABUOpenWillPresentFullScreen,
    STCSAdABUOpenDidShowFailed,
    STCSAdABUOpenWillDissmissFullScreen,
    STCSAdABUOpenCountdownToZero,
    
    STCSAdABUBannerWillPresentFullScreen,
    STCSAdABUBannerWillDismissFullScreen,
    
    STCSAdABURewardDidLoad,
    STCSAdABURewardRenderFail,
    STCSAdABURewardDidShowFailed,

} STCSAdEvent;

typedef void (^STCSAdLoadCompleteBlock)(STCSAdLoadStatus adLoadStatus);

@class STCSAdSetupParamsMaker;
@class STCSAdSetupParams;

typedef STCSAdSetupParamsMaker *(^STCSAdStringInit)(NSString *);
typedef STCSAdSetupParamsMaker *(^STCSAdBoolInit)(BOOL);
typedef STCSAdSetupParamsMaker *(^STCSAdIntegerInit)(NSInteger);
typedef STCSAdSetupParamsMaker *(^STCSAdLongInit)(long);
typedef STCSAdSetupParamsMaker *(^STCSAdArrayInit)(NSArray *);
typedef STCSAdSetupParams *(^STCSAdMakeInit)(void);


@class STCSAdDataModel;
typedef void (^STCSAdRequestCompleteBlock)(NSMutableArray<STCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^STCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^STCSAdPreloadCompleteBlock)(STCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
