//
//  QRCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define qRkAdvDataSourceFacebook   2 //FB 广告数据源
#define qRkAdvDataSourceAdmob      8 //Admob 广告数据源
#define qRkAdvDataSourceMopub      39//Mopub 广告数据源
#define qRkAdvDataSourceApplovin   20//applovin 广告数据源

#define qRkAdvDataSourceGDT        62//广点通 广告数据源
#define qRkAdvDataSourceBaidu      63//百度 广告数据源
#define qRkAdvDataSourceBU         64//头条 广告数据源


#define qRkOnlineAdvTypeBanner                   1  //banner
#define qRkOnlineAdvTypeInterstitial             2  //全屏
#define qRkOnlineAdvTypeNative                   3 //native
#define qRkOnlineAdvTypeVideo                    4 //视频
#define qRkOnlineAdvTypeMinBanner                5 //banner(300*250)
#define qRkOnlineAdvTypeInterstitialVideo        7 //插屏视频

#define qRkAdServerConfigError  -1 //服务器返回数据不正确
#define qRkAdLoadConfigFailed  -2 //广告加载失败


#define qRAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define qRkCSAdInstallDays @"qRkCSAdInstallDays"
#define qRkCSAdModule_key @"qRkCSAdModule_key_%@"
#define qRkCSAdInstallTime @"qRkCSAdInstallTime"
#define qRkCSAdLastGetServerTime @"qRkCSAdLastRequestTime"
#define qRkCSAdloadTime 30

#define qRkCSLoadAdTimeOutNotification @"qRKCSLoadAdTimeOutNotification"
#define qRkCSLoadAdTimeOutNotificationKey @"qRKCSLoadAdTimeOutKey"

