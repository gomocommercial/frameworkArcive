//
//  QRCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "QRCSAdTypedef.h"

@class QRCSAdLoadBase;

@protocol QRCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol QRCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)qRonAdShowed:(QRCSAdLoadBase<QRCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)qRonAdClicked:(QRCSAdLoadBase<QRCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)qRonAdClosed:(QRCSAdLoadBase<QRCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)qRonAdVideoCompletePlaying:(QRCSAdLoadBase<QRCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)qRonAdShowFail:(QRCSAdLoadBase<QRCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)qRonAdOtherEvent:(QRCSAdLoadBase<QRCSAdLoadProtocol> *)adload event:(QRCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
