//
//  Co_st_CSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "Co_st_CSAdTypedef.h"

@class Co_st_CSAdLoadBase;

@protocol Co_st_CSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol Co_st_CSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)co_st_onAdShowed:(Co_st_CSAdLoadBase<Co_st_CSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)co_st_onAdClicked:(Co_st_CSAdLoadBase<Co_st_CSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)co_st_onAdClosed:(Co_st_CSAdLoadBase<Co_st_CSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)co_st_onAdVideoCompletePlaying:(Co_st_CSAdLoadBase<Co_st_CSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)co_st_onAdShowFail:(Co_st_CSAdLoadBase<Co_st_CSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)co_st_onAdOtherEvent:(Co_st_CSAdLoadBase<Co_st_CSAdLoadProtocol> *)adload event:(Co_st_CSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
