//
//  Co_st_CSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    Co_st_CSAdLoadSuccess = 1,
    Co_st_CSAdLoadFailure = -1,
    Co_st_CSAdLoadTimeout = -2
} Co_st_CSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    Co_st_CSAdPreloadSuccess = 1,
    //预加载失败
    Co_st_CSAdPreloadFailure = -1,
    //重复加载
    Co_st_CSAdPreloadRepeat = -2,
} Co_st_CSAdPreloadStatus;


typedef enum : NSUInteger {
    
    Co_st_CSAdWillAppear,//即将出现
    Co_st_CSAdDidAppear,//已经出现
    Co_st_CSAdWillDisappear,//即将消失
    Co_st_CSAdDidDisappear,//已经消失
    Co_st_CSAdMuted,//静音广告
    Co_st_CSAdWillLeaveApplication,//将要离开App

    Co_st_CSAdVideoStart,//开始播放 常用于video
    Co_st_CSAdVideoComplete,//播放完成 常用于video
    Co_st_CSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    Co_st_CSAdVideoServerFail,//连接服务器成功，常用于fb video

    Co_st_CSAdNativeDidDownload,//下载完成 常用于fb Native
    Co_st_CSAdNativeFinishClick,//完成点击 常用与fb Native
    
    Co_st_CSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    Co_st_CSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    Co_st_CSAdVideoSkip,//跳过播放
    
    //广点通 插屏专用
    Co_st_CSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    Co_st_CSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    Co_st_CSAdDidPresentFullScreen,//插屏弹出全屏广告
    Co_st_CSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    Co_st_CSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    Co_st_CSAdPlayerStatusStarted,//开始播放
    Co_st_CSAdPlayerStatusPaused,//用户行为导致暂停
    Co_st_CSAdPlayerStatusStoped,//播放停止
    Co_st_CSAdPlayerStatusError,//播放出错
    Co_st_CSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    Co_st_CSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    Co_st_CSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    Co_st_CSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    Co_st_CSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    Co_st_CSAdVideoDidLoad//激励视频数据下载成功
} Co_st_CSAdEvent;

typedef void (^Co_st_CSAdLoadCompleteBlock)(Co_st_CSAdLoadStatus adLoadStatus);

@class Co_st_CSAdSetupParamsMaker;
@class Co_st_CSAdSetupParams;

typedef Co_st_CSAdSetupParamsMaker *(^Co_st_CSAdStringInit)(NSString *);
typedef Co_st_CSAdSetupParamsMaker *(^Co_st_CSAdBoolInit)(BOOL);
typedef Co_st_CSAdSetupParamsMaker *(^Co_st_CSAdIntegerInit)(NSInteger);
typedef Co_st_CSAdSetupParamsMaker *(^Co_st_CSAdLongInit)(long);
typedef Co_st_CSAdSetupParamsMaker *(^Co_st_CSAdArrayInit)(NSArray *);
typedef Co_st_CSAdSetupParams *(^Co_st_CSAdMakeInit)(void);


@class Co_st_CSAdDataModel;
typedef void (^Co_st_CSAdRequestCompleteBlock)(NSMutableArray<Co_st_CSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^Co_st_CSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^Co_st_CSAdPreloadCompleteBlock)(Co_st_CSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
