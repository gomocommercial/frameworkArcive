//
//  Co_st_CSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define co_st_kAdvDataSourceFacebook   2 //FB 广告数据源
#define co_st_kAdvDataSourceAdmob      8 //Admob 广告数据源
#define co_st_kAdvDataSourceMopub      39//Mopub 广告数据源
#define co_st_kAdvDataSourceApplovin   20//applovin 广告数据源

#define co_st_kAdvDataSourceGDT        62//广点通 广告数据源
#define co_st_kAdvDataSourceBaidu      63//百度 广告数据源
#define co_st_kAdvDataSourceBU         64//头条 广告数据源


#define co_st_kOnlineAdvTypeBanner                   1  //banner
#define co_st_kOnlineAdvTypeInterstitial             2  //全屏
#define co_st_kOnlineAdvTypeNative                   3 //native
#define co_st_kOnlineAdvTypeVideo                    4 //视频
#define co_st_kOnlineAdvTypeMinBanner                5 //banner(300*250)
#define co_st_kOnlineAdvTypeInterstitialVideo        7 //插屏视频

#define co_st_kAdServerConfigError  -1 //服务器返回数据不正确
#define co_st_kAdLoadConfigFailed  -2 //广告加载失败


#define co_st_AdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define co_st_kCSAdInstallDays @"co_st_kCSAdInstallDays"
#define co_st_kCSAdModule_key @"co_st_kCSAdModule_key_%@"
#define co_st_kCSAdInstallTime @"co_st_kCSAdInstallTime"
#define co_st_kCSAdLastGetServerTime @"co_st_kCSAdLastRequestTime"
#define co_st_kCSAdloadTime 30

#define co_st_kCSLoadAdTimeOutNotification @"co_st_KCSLoadAdTimeOutNotification"
#define co_st_kCSLoadAdTimeOutNotificationKey @"co_st_KCSLoadAdTimeOutKey"

