//
//  MBCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MBCSAdTypedef.h"

@class MBCSAdLoadBase;

@protocol MBCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MBCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mBonAdShowed:(MBCSAdLoadBase<MBCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)mBonAdClicked:(MBCSAdLoadBase<MBCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mBonAdClosed:(MBCSAdLoadBase<MBCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mBonAdVideoCompletePlaying:(MBCSAdLoadBase<MBCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)mBonAdShowFail:(MBCSAdLoadBase<MBCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mBonAdOtherEvent:(MBCSAdLoadBase<MBCSAdLoadProtocol> *)adload event:(MBCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
