//
//  CPCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPCSAdLoadInterstitial : CPCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
