//
//  CPCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "CPCSAdLoadBase.h"
#import "CPCSAdDataModel.h"
#import "CPCSAdLoadProtocol.h"
#import "CPCSAdLoadDataProtocol.h"
#import "CPCSAdLoadShowProtocol.h"
#import "CPCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)cPsetupByBlock:(void (^ _Nonnull)(CPCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)cPloadAd:(NSString *)moduleId delegate:(id<CPCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)cPadShowStatistic:(CPCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)cPadClickStatistic:(CPCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)cPaddCustomFecher:(Class<CPCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
