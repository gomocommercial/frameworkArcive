//
//  SVCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "SVCSAdTypedef.h"

@class SVCSAdLoadBase;

@protocol SVCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol SVCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sVonAdShowed:(SVCSAdLoadBase<SVCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)sVonAdClicked:(SVCSAdLoadBase<SVCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sVonAdClosed:(SVCSAdLoadBase<SVCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sVonAdVideoCompletePlaying:(SVCSAdLoadBase<SVCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)sVonAdShowFail:(SVCSAdLoadBase<SVCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sVonAdOtherEvent:(SVCSAdLoadBase<SVCSAdLoadProtocol> *)adload event:(SVCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
