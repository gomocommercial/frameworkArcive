//
//  QTCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "QTCSAdTypedef.h"

@class QTCSAdLoadBase;

@protocol QTCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol QTCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)qTonAdShowed:(QTCSAdLoadBase<QTCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)qTonAdClicked:(QTCSAdLoadBase<QTCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)qTonAdClosed:(QTCSAdLoadBase<QTCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)qTonAdVideoCompletePlaying:(QTCSAdLoadBase<QTCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)qTonAdShowFail:(QTCSAdLoadBase<QTCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)qTonAdOtherEvent:(QTCSAdLoadBase<QTCSAdLoadProtocol> *)adload event:(QTCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
