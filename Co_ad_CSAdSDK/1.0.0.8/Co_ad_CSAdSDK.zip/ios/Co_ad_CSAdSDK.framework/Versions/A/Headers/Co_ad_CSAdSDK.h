//
//  Co_ad_CSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "Co_ad_CSAdLoadBase.h"
#import "Co_ad_CSAdDataModel.h"
#import "Co_ad_CSAdLoadProtocol.h"
#import "Co_ad_CSAdLoadDataProtocol.h"
#import "Co_ad_CSAdLoadShowProtocol.h"
#import "Co_ad_CSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)co_ad_setupByBlock:(void (^ _Nonnull)(Co_ad_CSAdSetupParamsMaker *maker))block;

/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)co_ad_loadAd:(NSString *)moduleId delegate:(id<Co_ad_CSAdLoadDataProtocol>)delegate;

/**
 展示广告统计
 */
+ (void)co_ad_adShowStatistic:(Co_ad_CSAdDataModel *)dataModel;

/**
 点击广告告统计
 */
+ (void)co_ad_adClickStatistic:(Co_ad_CSAdDataModel *)dataModel;

//重置所有广告代理(当多个地方同时加载广告时，可重置代理，用于确定代理回调位置)
+ (void)co_ad_resetAllDelegate:(id<Co_ad_CSAdLoadDataProtocol>) delegate;


// MARK: - 增加自定义广告源
+ (void)co_ad_addCustomFecher:(Class<Co_ad_CSAdLoadProtocol>)fetcher;
@end

NS_ASSUME_NONNULL_END
