//
//  PIKCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PIKCSAdLoadBase.h"
#import "PIKCSAdDataModel.h"
#import "PIKCSAdLoadProtocol.h"
#import "PIKCSAdLoadDataProtocol.h"
#import "PIKCSAdLoadShowProtocol.h"
#import "PIKCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PIKCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pIKsetupByBlock:(void (^ _Nonnull)(PIKCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pIKloadAd:(NSString *)moduleId delegate:(id<PIKCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pIKadShowStatistic:(PIKCSAdDataModel *)dataModel adload:(nonnull PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pIKadClickStatistic:(PIKCSAdDataModel *)dataModel adload:(nonnull PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pIKaddCustomFecher:(Class<PIKCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
