//
//  PIKCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PIKCSAdTypedef.h"

@class PIKCSAdLoadBase;

@protocol PIKCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PIKCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pIKonAdShowed:(PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pIKonAdClicked:(PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pIKonAdClosed:(PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pIKonAdVideoCompletePlaying:(PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pIKonAdVideoGotReward:(PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload;
-(void)pIKonAdDidPayRevenue:(PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)pIKonAdShowFail:(PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pIKonAdOtherEvent:(PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload event:(PIKCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
