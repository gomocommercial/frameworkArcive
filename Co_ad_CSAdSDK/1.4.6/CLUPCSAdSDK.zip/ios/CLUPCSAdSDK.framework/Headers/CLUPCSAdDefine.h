//
//  CLUPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define cLUPkAdvDataSourceFacebook   2 //FB 广告数据源
#define cLUPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define cLUPkAdvDataSourceMopub      39//Mopub 广告数据源
#define cLUPkAdvDataSourceApplovin   20//applovin 广告数据源

#define cLUPkAdvDataSourceGDT        62//广点通 广告数据源
#define cLUPkAdvDataSourceBaidu      63//百度 广告数据源
#define cLUPkAdvDataSourceBU         64//头条 广告数据源
#define cLUPkAdvDataSourceABU         70//头条聚合 广告数据源
#define cLUPkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define cLUPkAdvDataSourcePangle     74//pangle 广告数据源

#define cLUPkOnlineAdvTypeBanner                   1  //banner
#define cLUPkOnlineAdvTypeInterstitial             2  //全屏
#define cLUPkOnlineAdvTypeNative                   3 //native
#define cLUPkOnlineAdvTypeVideo                    4 //视频
#define cLUPkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define cLUPkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define cLUPkOnlineAdvTypeOpen                     8 //开屏
#define cLUPkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define cLUPkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define cLUPkAdServerConfigError  -1 //服务器返回数据不正确
#define cLUPkAdLoadConfigFailed  -2 //广告加载失败


#define cLUPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define cLUPkCSAdInstallDays @"cLUPkCSAdInstallDays"
#define cLUPkCSAdModule_key @"cLUPkCSAdModule_key_%@"
#define cLUPkCSNewAdModule_key @"cLUPkCSNewAdModule_key_%@"
#define cLUPkCSAdInstallTime @"cLUPkCSAdInstallTime"
#define cLUPkCSAdInstallHours @"cLUPkCSAdInstallHours"
#define cLUPkCSAdLastGetServerTime @"cLUPkCSAdLastRequestTime"
#define cLUPkCSAdloadTime 30

#define cLUPkCSLoadAdTimeOutNotification @"cLUPKCSLoadAdTimeOutNotification"
#define cLUPkCSLoadAdTimeOutNotificationKey @"cLUPKCSLoadAdTimeOutKey"

