//
//  MGCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MGCCSAdTypedef.h"

@class MGCCSAdLoadBase;

@protocol MGCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MGCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mGConAdShowed:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)mGConAdClicked:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mGConAdClosed:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mGConAdVideoCompletePlaying:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)mGConAdVideoGotReward:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload;
-(void)mGConAdDidPayRevenue:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)mGConAdShowFail:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mGConAdOtherEvent:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload event:(MGCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
