//
//  MGCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define mGCkAdvDataSourceFacebook   2 //FB 广告数据源
#define mGCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define mGCkAdvDataSourceMopub      39//Mopub 广告数据源
#define mGCkAdvDataSourceApplovin   20//applovin 广告数据源

#define mGCkAdvDataSourceGDT        62//广点通 广告数据源
#define mGCkAdvDataSourceBaidu      63//百度 广告数据源
#define mGCkAdvDataSourceBU         64//头条 广告数据源
#define mGCkAdvDataSourceABU         70//头条聚合 广告数据源
#define mGCkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define mGCkAdvDataSourcePangle     74//pangle 广告数据源

#define mGCkOnlineAdvTypeBanner                   1  //banner
#define mGCkOnlineAdvTypeInterstitial             2  //全屏
#define mGCkOnlineAdvTypeNative                   3 //native
#define mGCkOnlineAdvTypeVideo                    4 //视频
#define mGCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define mGCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define mGCkOnlineAdvTypeOpen                     8 //开屏
#define mGCkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define mGCkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define mGCkAdServerConfigError  -1 //服务器返回数据不正确
#define mGCkAdLoadConfigFailed  -2 //广告加载失败


#define mGCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define mGCkCSAdInstallDays @"mGCkCSAdInstallDays"
#define mGCkCSAdModule_key @"mGCkCSAdModule_key_%@"
#define mGCkCSNewAdModule_key @"mGCkCSNewAdModule_key_%@"
#define mGCkCSAdInstallTime @"mGCkCSAdInstallTime"
#define mGCkCSAdInstallHours @"mGCkCSAdInstallHours"
#define mGCkCSAdLastGetServerTime @"mGCkCSAdLastRequestTime"
#define mGCkCSAdloadTime 30

#define mGCkCSLoadAdTimeOutNotification @"mGCKCSLoadAdTimeOutNotification"
#define mGCkCSLoadAdTimeOutNotificationKey @"mGCKCSLoadAdTimeOutKey"

