//
//  MGCCSAdLoadDataProtocol.h
//  MGCCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "MGCCSAdTypedef.h"

@class MGCCSAdDataModel;
@class MGCCSAdLoadBase;

@protocol MGCCSAdLoadProtocol;

@protocol MGCCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)mGConAdInfoFinish:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)mGConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)mGConAdFail:(MGCCSAdLoadBase<MGCCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
