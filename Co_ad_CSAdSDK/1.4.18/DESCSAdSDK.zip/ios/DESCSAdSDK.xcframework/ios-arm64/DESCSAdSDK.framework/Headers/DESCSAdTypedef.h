//
//  DESCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    DESCSAdLoadSuccess = 1,
    DESCSAdLoadFailure = -1,
    DESCSAdLoadTimeout = -2
} DESCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    DESCSAdPreloadSuccess = 1,
    //预加载失败
    DESCSAdPreloadFailure = -1,
    //重复加载
    DESCSAdPreloadRepeat = -2,
} DESCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    DESCSAdWillAppear,//即将出现
    DESCSAdDidAppear,//已经出现
    DESCSAdWillDisappear,//即将消失
    DESCSAdDidDisappear,//已经消失
    DESCSAdMuted,//静音广告
    DESCSAdWillLeaveApplication,//将要离开App

    DESCSAdVideoStart,//开始播放 常用于video
    DESCSAdVideoComplete,//播放完成 常用于video
    DESCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    DESCSAdVideoServerFail,//连接服务器成功，常用于fb video

    DESCSAdNativeDidDownload,//下载完成 常用于fb Native
    DESCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    DESCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    DESCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    DESCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    DESCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    DESCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    DESCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    DESCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    DESCSAdBUOpenDidAutoDimiss,//开屏自动消失
    DESCSAdBUOpenRenderSuccess, //渲染成功
    DESCSAdBUOpenRenderFail, //渲染失败
    DESCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    DESCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    DESCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    DESCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    DESCSAdDidPresentFullScreen,//插屏弹出全屏广告
    DESCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    DESCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    DESCSAdPlayerStatusStarted,//开始播放
    DESCSAdPlayerStatusPaused,//用户行为导致暂停
    DESCSAdPlayerStatusStoped,//播放停止
    DESCSAdPlayerStatusError,//播放出错
    DESCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    DESCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    DESCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    DESCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    DESCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    DESCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    DESCSAdRecordImpression, //广告曝光已记录
    DESCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    DESCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    DESCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    DESCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    DESCSAdABUOpenWillPresentFullScreen,
    DESCSAdABUOpenDidShowFailed,
    DESCSAdABUOpenWillDissmissFullScreen,
    DESCSAdABUOpenCountdownToZero,
    
    DESCSAdABUBannerWillPresentFullScreen,
    DESCSAdABUBannerWillDismissFullScreen,
    
    DESCSAdABURewardDidLoad,
    DESCSAdABURewardRenderFail,
    DESCSAdABURewardDidShowFailed,

} DESCSAdEvent;

typedef void (^DESCSAdLoadCompleteBlock)(DESCSAdLoadStatus adLoadStatus);

@class DESCSAdSetupParamsMaker;
@class DESCSAdSetupParams;

typedef DESCSAdSetupParamsMaker *(^DESCSAdStringInit)(NSString *);
typedef DESCSAdSetupParamsMaker *(^DESCSAdBoolInit)(BOOL);
typedef DESCSAdSetupParamsMaker *(^DESCSAdIntegerInit)(NSInteger);
typedef DESCSAdSetupParamsMaker *(^DESCSAdLongInit)(long);
typedef DESCSAdSetupParamsMaker *(^DESCSAdArrayInit)(NSArray *);
typedef DESCSAdSetupParams *(^DESCSAdMakeInit)(void);


@class DESCSAdDataModel;
typedef void (^DESCSAdRequestCompleteBlock)(NSMutableArray<DESCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^DESCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^DESCSAdPreloadCompleteBlock)(DESCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
