//
//  DESCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "DESCSAdLoadBase.h"
#import "DESCSAdDataModel.h"
#import "DESCSAdLoadProtocol.h"
#import "DESCSAdLoadDataProtocol.h"
#import "DESCSAdLoadShowProtocol.h"
#import "DESCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface DESCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)dESsetupByBlock:(void (^ _Nonnull)(DESCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)dESloadAd:(NSString *)moduleId delegate:(id<DESCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)dESadShowStatistic:(DESCSAdDataModel *)dataModel adload:(nonnull DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)dESadClickStatistic:(DESCSAdDataModel *)dataModel adload:(nonnull DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)dESaddCustomFecher:(Class<DESCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
