//
//  DESCSAdNetworkTool.h
//  DESCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "DESCSAdDataModel.h"
#import "DESCSAdTypedef.h"
#import "DESCSNewStoreLiteRequestTool.h"
#import "NSString+DESCSGenerateHash.h"

@interface DESCSAdNetworkTool : NSObject

+ (DESCSAdNetworkTool *)shared;
@property(nonatomic, copy) DESCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)dESrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(DESCSAdRequestCompleteBlock)complete;

- (void)dESsetCDay:(void(^ _Nullable)(bool success))handle;
@end
