//
//  DESCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "DESCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DESCSAdLoadOpen : DESCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
