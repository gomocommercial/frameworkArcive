//
//  DESCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "DESCSAdTypedef.h"

@class DESCSAdLoadBase;

@protocol DESCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol DESCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)dESonAdShowed:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)dESonAdClicked:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)dESonAdClosed:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)dESonAdVideoCompletePlaying:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)dESonAdVideoGotReward:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload;
-(void)dESonAdDidPayRevenue:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)dESonAdDidGetEcpm:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)dESonAdShowFail:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)dESonAdOtherEvent:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload event:(DESCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
