//
//  DESCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "DESCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DESCSAdLoadReward : DESCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
