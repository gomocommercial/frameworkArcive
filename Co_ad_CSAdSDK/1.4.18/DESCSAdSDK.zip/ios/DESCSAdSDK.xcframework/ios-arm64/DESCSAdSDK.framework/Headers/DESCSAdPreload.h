//
//  DESCSAdPreload.h
//  AFNetworking
//
//  Created by Zy on 2019/4/26.
//

#import <Foundation/Foundation.h>
#import "DESCSAdSDK.h"

NS_ASSUME_NONNULL_BEGIN

@interface DESCSAdPreload : NSObject

// MARK: - -------------------预加载接口(对广告实例进行管理 仅限管理一条广告数据，仅支持插屏和激励视频广告)--------------------------

/**
 广告预加载
 
 @param moduleId 模块ID
 @param completion 加载完成回调
 */
+ (void)dESpreload:(NSString *)moduleId completion:(DESCSAdPreloadCompleteBlock _Nullable)completion;


/**
 广告是否已经准备好
 */
+ (BOOL)dESpreloadValid;

/**
 广告展示
 
 @param viewCtrl 控制器
 @param showDelegate 展示代理
 */
+ (void)dESpreloadShow:(UIViewController *)viewCtrl showDelegate:(id<DESCSAdLoadShowProtocol>)showDelegate;

@end

NS_ASSUME_NONNULL_END
