#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "DESCSAdSDK.h"
#import "DESCSAdPreload.h"
#import "DESCSAdLoadDataProtocol.h"
#import "DESCSAdLoadShowProtocol.h"
#import "DESCSAdLoadProtocol.h"
#import "DESCSAdLoadBase.h"
#import "DESCSAdLoadInterstitial.h"
#import "DESCSAdLoadNative.h"
#import "DESCSAdLoadReward.h"
#import "DESCSAdLoadOpen.h"
#import "DESCSAdLoadBanner.h"
#import "DESCSAdManager.h"
#import "DESCSAdSetupParams.h"
#import "DESCSAdSetupParamsMaker.h"
#import "DESCSAdDefine.h"
#import "DESCSAdTypedef.h"
#import "DESCSAdStatistics.h"
#import "DESCSAdDataModel.h"
#import "DESCSAdNetworkTool.h"
#import "DESCSNewStoreLiteRequestTool.h"
#import "NSString+DESCSGenerateHash.h"

FOUNDATION_EXPORT double DESCSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char DESCSAdSDKVersionString[];

