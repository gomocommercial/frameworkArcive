//
//  DESCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define dESkAdvDataSourceFacebook   2 //FB 广告数据源
#define dESkAdvDataSourceAdmob      8 //Admob 广告数据源
#define dESkAdvDataSourceMopub      39//Mopub 广告数据源
#define dESkAdvDataSourceApplovin   20//applovin 广告数据源

#define dESkAdvDataSourceGDT        62//广点通 广告数据源
#define dESkAdvDataSourceBaidu      63//百度 广告数据源
#define dESkAdvDataSourceBU         64//头条 广告数据源
#define dESkAdvDataSourceABU         70//头条聚合 广告数据源
#define dESkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define dESkAdvDataSourcePangle     74//pangle 广告数据源

#define dESkOnlineAdvTypeBanner                   1  //banner
#define dESkOnlineAdvTypeInterstitial             2  //全屏
#define dESkOnlineAdvTypeNative                   3 //native
#define dESkOnlineAdvTypeVideo                    4 //视频
#define dESkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define dESkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define dESkOnlineAdvTypeOpen                     8 //开屏
#define dESkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define dESkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define dESkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define dESkAdServerConfigError  -1 //服务器返回数据不正确
#define dESkAdLoadConfigFailed  -2 //广告加载失败


#define dESAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define dESkCSAdInstallDays @"dESkCSAdInstallDays"
#define dESkCSAdModule_key @"dESkCSAdModule_key_%@"
#define dESkCSNewAdModule_key @"dESkCSNewAdModule_key_%@"
#define dESkCSAdInstallTime @"dESkCSAdInstallTime"
#define dESkCSAdInstallHours @"dESkCSAdInstallHours"
#define dESkCSAdLastGetServerTime @"dESkCSAdLastRequestTime"
#define dESkCSAdloadTime 30

#define dESkCSLoadAdTimeOutNotification @"dESKCSLoadAdTimeOutNotification"
#define dESkCSLoadAdTimeOutNotificationKey @"dESKCSLoadAdTimeOutKey"

