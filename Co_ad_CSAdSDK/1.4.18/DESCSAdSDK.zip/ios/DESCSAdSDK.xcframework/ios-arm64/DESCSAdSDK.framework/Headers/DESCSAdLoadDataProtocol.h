//
//  DESCSAdLoadDataProtocol.h
//  DESCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "DESCSAdTypedef.h"

@class DESCSAdDataModel;
@class DESCSAdLoadBase;

@protocol DESCSAdLoadProtocol;

@protocol DESCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)dESonAdInfoFinish:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)dESonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)dESonAdFail:(DESCSAdLoadBase<DESCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
