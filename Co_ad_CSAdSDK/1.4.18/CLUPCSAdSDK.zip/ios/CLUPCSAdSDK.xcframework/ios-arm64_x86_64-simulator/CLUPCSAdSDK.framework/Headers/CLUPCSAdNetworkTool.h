//
//  CLUPCSAdNetworkTool.h
//  CLUPCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CLUPCSAdDataModel.h"
#import "CLUPCSAdTypedef.h"
#import "CLUPCSNewStoreLiteRequestTool.h"
#import "NSString+CLUPCSGenerateHash.h"

@interface CLUPCSAdNetworkTool : NSObject

+ (CLUPCSAdNetworkTool *)shared;
@property(nonatomic, copy) CLUPCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)cLUPrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CLUPCSAdRequestCompleteBlock)complete;

- (void)cLUPsetCDay:(void(^ _Nullable)(bool success))handle;
@end
