//
//  AWCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "AWCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadNative : AWCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
