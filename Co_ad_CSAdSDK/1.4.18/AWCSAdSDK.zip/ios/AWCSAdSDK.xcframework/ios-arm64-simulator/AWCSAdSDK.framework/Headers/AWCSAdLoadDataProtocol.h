//
//  AWCSAdLoadDataProtocol.h
//  AWCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "AWCSAdTypedef.h"

@class AWCSAdDataModel;
@class AWCSAdLoadBase;

@protocol AWCSAdLoadProtocol;

@protocol AWCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)aWonAdInfoFinish:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)aWonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)aWonAdFail:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
