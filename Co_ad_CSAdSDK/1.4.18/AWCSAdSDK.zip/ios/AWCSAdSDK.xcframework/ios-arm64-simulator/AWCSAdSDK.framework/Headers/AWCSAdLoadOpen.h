//
//  AWCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "AWCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadOpen : AWCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
