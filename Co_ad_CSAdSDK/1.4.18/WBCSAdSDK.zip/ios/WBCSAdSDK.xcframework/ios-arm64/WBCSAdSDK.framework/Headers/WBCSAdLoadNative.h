//
//  WBCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "WBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface WBCSAdLoadNative : WBCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
