//
//  WIOCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "WIOCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface WIOCSAdLoadNative : WIOCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
