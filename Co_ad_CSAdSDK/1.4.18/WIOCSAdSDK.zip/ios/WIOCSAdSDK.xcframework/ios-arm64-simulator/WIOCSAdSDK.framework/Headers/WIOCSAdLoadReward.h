//
//  WIOCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "WIOCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface WIOCSAdLoadReward : WIOCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
