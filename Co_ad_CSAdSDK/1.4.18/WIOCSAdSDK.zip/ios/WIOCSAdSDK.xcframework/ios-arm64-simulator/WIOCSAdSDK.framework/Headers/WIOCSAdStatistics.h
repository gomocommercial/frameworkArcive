//
//  WIOCSAdStatistics.h
//  WIOCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "WIOCSAdDataModel.h"
#import "WIOCSAdTypedef.h"
#import "WIOCSAdLoadBase.h"
@interface WIOCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)wIOadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)wIOadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)wIOadRewardVideoCompleteStatistic:(WIOCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)wIOadShowStatistic:(WIOCSAdDataModel *)dataModel adload:(nonnull WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)wIOadClickStatistic:(WIOCSAdDataModel *)dataModel adload:(nonnull WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)wIOadUploadRevenueStatistic:(WIOCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
