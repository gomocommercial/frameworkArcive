//
//  CURCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "CURCSAdLoadBase.h"
#import "CURCSAdDataModel.h"
#import "CURCSAdLoadProtocol.h"
#import "CURCSAdLoadDataProtocol.h"
#import "CURCSAdLoadShowProtocol.h"
#import "CURCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface CURCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)cURsetupByBlock:(void (^ _Nonnull)(CURCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)cURloadAd:(NSString *)moduleId delegate:(id<CURCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)cURadShowStatistic:(CURCSAdDataModel *)dataModel adload:(nonnull CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)cURadClickStatistic:(CURCSAdDataModel *)dataModel adload:(nonnull CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)cURaddCustomFecher:(Class<CURCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
