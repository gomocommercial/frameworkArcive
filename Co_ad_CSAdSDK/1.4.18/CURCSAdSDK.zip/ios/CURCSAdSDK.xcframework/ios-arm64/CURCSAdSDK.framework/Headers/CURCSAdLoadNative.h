//
//  CURCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CURCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CURCSAdLoadNative : CURCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
