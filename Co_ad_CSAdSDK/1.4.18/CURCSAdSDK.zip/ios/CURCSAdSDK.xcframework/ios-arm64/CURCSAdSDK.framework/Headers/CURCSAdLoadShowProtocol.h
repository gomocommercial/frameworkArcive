//
//  CURCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CURCSAdTypedef.h"

@class CURCSAdLoadBase;

@protocol CURCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CURCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cURonAdShowed:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cURonAdClicked:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cURonAdClosed:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cURonAdVideoCompletePlaying:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)cURonAdVideoGotReward:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload;
-(void)cURonAdDidPayRevenue:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)cURonAdDidGetEcpm:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)cURonAdShowFail:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cURonAdOtherEvent:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload event:(CURCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
