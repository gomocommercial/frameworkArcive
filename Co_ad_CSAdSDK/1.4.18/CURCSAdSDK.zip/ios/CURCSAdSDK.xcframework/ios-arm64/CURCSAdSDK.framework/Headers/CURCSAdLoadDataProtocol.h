//
//  CURCSAdLoadDataProtocol.h
//  CURCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "CURCSAdTypedef.h"

@class CURCSAdDataModel;
@class CURCSAdLoadBase;

@protocol CURCSAdLoadProtocol;

@protocol CURCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)cURonAdInfoFinish:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)cURonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)cURonAdFail:(CURCSAdLoadBase<CURCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
