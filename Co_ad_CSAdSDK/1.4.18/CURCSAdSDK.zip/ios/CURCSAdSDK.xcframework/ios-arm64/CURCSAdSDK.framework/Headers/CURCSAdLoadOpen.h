//
//  CURCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "CURCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CURCSAdLoadOpen : CURCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
