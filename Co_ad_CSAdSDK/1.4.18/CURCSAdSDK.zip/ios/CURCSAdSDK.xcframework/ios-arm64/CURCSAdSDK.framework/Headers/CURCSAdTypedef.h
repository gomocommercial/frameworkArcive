//
//  CURCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CURCSAdLoadSuccess = 1,
    CURCSAdLoadFailure = -1,
    CURCSAdLoadTimeout = -2
} CURCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CURCSAdPreloadSuccess = 1,
    //预加载失败
    CURCSAdPreloadFailure = -1,
    //重复加载
    CURCSAdPreloadRepeat = -2,
} CURCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CURCSAdWillAppear,//即将出现
    CURCSAdDidAppear,//已经出现
    CURCSAdWillDisappear,//即将消失
    CURCSAdDidDisappear,//已经消失
    CURCSAdMuted,//静音广告
    CURCSAdWillLeaveApplication,//将要离开App

    CURCSAdVideoStart,//开始播放 常用于video
    CURCSAdVideoComplete,//播放完成 常用于video
    CURCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CURCSAdVideoServerFail,//连接服务器成功，常用于fb video

    CURCSAdNativeDidDownload,//下载完成 常用于fb Native
    CURCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CURCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CURCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CURCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CURCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CURCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    CURCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CURCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CURCSAdBUOpenDidAutoDimiss,//开屏自动消失
    CURCSAdBUOpenRenderSuccess, //渲染成功
    CURCSAdBUOpenRenderFail, //渲染失败
    CURCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    CURCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CURCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CURCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CURCSAdDidPresentFullScreen,//插屏弹出全屏广告
    CURCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CURCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CURCSAdPlayerStatusStarted,//开始播放
    CURCSAdPlayerStatusPaused,//用户行为导致暂停
    CURCSAdPlayerStatusStoped,//播放停止
    CURCSAdPlayerStatusError,//播放出错
    CURCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CURCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CURCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CURCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CURCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CURCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CURCSAdRecordImpression, //广告曝光已记录
    CURCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CURCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CURCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    CURCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    CURCSAdABUOpenWillPresentFullScreen,
    CURCSAdABUOpenDidShowFailed,
    CURCSAdABUOpenWillDissmissFullScreen,
    CURCSAdABUOpenCountdownToZero,
    
    CURCSAdABUBannerWillPresentFullScreen,
    CURCSAdABUBannerWillDismissFullScreen,
    
    CURCSAdABURewardDidLoad,
    CURCSAdABURewardRenderFail,
    CURCSAdABURewardDidShowFailed,

} CURCSAdEvent;

typedef void (^CURCSAdLoadCompleteBlock)(CURCSAdLoadStatus adLoadStatus);

@class CURCSAdSetupParamsMaker;
@class CURCSAdSetupParams;

typedef CURCSAdSetupParamsMaker *(^CURCSAdStringInit)(NSString *);
typedef CURCSAdSetupParamsMaker *(^CURCSAdBoolInit)(BOOL);
typedef CURCSAdSetupParamsMaker *(^CURCSAdIntegerInit)(NSInteger);
typedef CURCSAdSetupParamsMaker *(^CURCSAdLongInit)(long);
typedef CURCSAdSetupParamsMaker *(^CURCSAdArrayInit)(NSArray *);
typedef CURCSAdSetupParams *(^CURCSAdMakeInit)(void);


@class CURCSAdDataModel;
typedef void (^CURCSAdRequestCompleteBlock)(NSMutableArray<CURCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CURCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CURCSAdPreloadCompleteBlock)(CURCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
