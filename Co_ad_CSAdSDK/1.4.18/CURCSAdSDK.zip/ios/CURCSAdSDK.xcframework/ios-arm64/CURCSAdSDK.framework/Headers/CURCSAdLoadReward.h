//
//  CURCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CURCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CURCSAdLoadReward : CURCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
