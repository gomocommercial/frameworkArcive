//
//  CURCSAdNetworkTool.h
//  CURCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CURCSAdDataModel.h"
#import "CURCSAdTypedef.h"
#import "CURCSNewStoreLiteRequestTool.h"
#import "NSString+CURCSGenerateHash.h"

@interface CURCSAdNetworkTool : NSObject

+ (CURCSAdNetworkTool *)shared;
@property(nonatomic, copy) CURCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)cURrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CURCSAdRequestCompleteBlock)complete;

- (void)cURsetCDay:(void(^ _Nullable)(bool success))handle;
@end
