//
//  CURCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define cURkAdvDataSourceFacebook   2 //FB 广告数据源
#define cURkAdvDataSourceAdmob      8 //Admob 广告数据源
#define cURkAdvDataSourceMopub      39//Mopub 广告数据源
#define cURkAdvDataSourceApplovin   20//applovin 广告数据源

#define cURkAdvDataSourceGDT        62//广点通 广告数据源
#define cURkAdvDataSourceBaidu      63//百度 广告数据源
#define cURkAdvDataSourceBU         64//头条 广告数据源
#define cURkAdvDataSourceABU         70//头条聚合 广告数据源
#define cURkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define cURkAdvDataSourcePangle     74//pangle 广告数据源

#define cURkOnlineAdvTypeBanner                   1  //banner
#define cURkOnlineAdvTypeInterstitial             2  //全屏
#define cURkOnlineAdvTypeNative                   3 //native
#define cURkOnlineAdvTypeVideo                    4 //视频
#define cURkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define cURkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define cURkOnlineAdvTypeOpen                     8 //开屏
#define cURkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define cURkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define cURkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define cURkAdServerConfigError  -1 //服务器返回数据不正确
#define cURkAdLoadConfigFailed  -2 //广告加载失败


#define cURAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define cURkCSAdInstallDays @"cURkCSAdInstallDays"
#define cURkCSAdModule_key @"cURkCSAdModule_key_%@"
#define cURkCSNewAdModule_key @"cURkCSNewAdModule_key_%@"
#define cURkCSAdInstallTime @"cURkCSAdInstallTime"
#define cURkCSAdInstallHours @"cURkCSAdInstallHours"
#define cURkCSAdLastGetServerTime @"cURkCSAdLastRequestTime"
#define cURkCSAdloadTime 30

#define cURkCSLoadAdTimeOutNotification @"cURKCSLoadAdTimeOutNotification"
#define cURkCSLoadAdTimeOutNotificationKey @"cURKCSLoadAdTimeOutKey"

