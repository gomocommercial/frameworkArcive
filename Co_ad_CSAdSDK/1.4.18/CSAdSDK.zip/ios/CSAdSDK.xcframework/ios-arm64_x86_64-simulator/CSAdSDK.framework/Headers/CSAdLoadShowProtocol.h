//
//  CSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CSAdTypedef.h"

@class CSAdLoadBase;

@protocol CSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)onAdShowed:(CSAdLoadBase<CSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)onAdClicked:(CSAdLoadBase<CSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)onAdClosed:(CSAdLoadBase<CSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)onAdVideoCompletePlaying:(CSAdLoadBase<CSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)onAdVideoGotReward:(CSAdLoadBase<CSAdLoadProtocol> *)adload;
-(void)onAdDidPayRevenue:(CSAdLoadBase<CSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)onAdDidGetEcpm:(CSAdLoadBase<CSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)onAdShowFail:(CSAdLoadBase<CSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)onAdOtherEvent:(CSAdLoadBase<CSAdLoadProtocol> *)adload event:(CSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
