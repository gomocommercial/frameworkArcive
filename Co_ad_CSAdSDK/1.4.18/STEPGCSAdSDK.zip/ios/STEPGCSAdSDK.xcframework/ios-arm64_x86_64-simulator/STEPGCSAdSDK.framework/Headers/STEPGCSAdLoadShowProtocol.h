//
//  STEPGCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "STEPGCSAdTypedef.h"

@class STEPGCSAdLoadBase;

@protocol STEPGCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol STEPGCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sTEPGonAdShowed:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sTEPGonAdClicked:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sTEPGonAdClosed:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sTEPGonAdVideoCompletePlaying:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sTEPGonAdVideoGotReward:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload;
-(void)sTEPGonAdDidPayRevenue:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)sTEPGonAdDidGetEcpm:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)sTEPGonAdShowFail:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sTEPGonAdOtherEvent:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload event:(STEPGCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
