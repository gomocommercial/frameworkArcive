//
//  STEPGCSAdLoadDataProtocol.h
//  STEPGCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "STEPGCSAdTypedef.h"

@class STEPGCSAdDataModel;
@class STEPGCSAdLoadBase;

@protocol STEPGCSAdLoadProtocol;

@protocol STEPGCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)sTEPGonAdInfoFinish:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)sTEPGonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)sTEPGonAdFail:(STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
