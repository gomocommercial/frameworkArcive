//
//  STEPGCSAdNetworkTool.h
//  STEPGCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "STEPGCSAdDataModel.h"
#import "STEPGCSAdTypedef.h"
#import "STEPGCSNewStoreLiteRequestTool.h"
#import "NSString+STEPGCSGenerateHash.h"

@interface STEPGCSAdNetworkTool : NSObject

+ (STEPGCSAdNetworkTool *)shared;
@property(nonatomic, copy) STEPGCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sTEPGrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(STEPGCSAdRequestCompleteBlock)complete;

- (void)sTEPGsetCDay:(void(^ _Nullable)(bool success))handle;
@end
