//
//  STEPGCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    STEPGCSAdLoadSuccess = 1,
    STEPGCSAdLoadFailure = -1,
    STEPGCSAdLoadTimeout = -2
} STEPGCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    STEPGCSAdPreloadSuccess = 1,
    //预加载失败
    STEPGCSAdPreloadFailure = -1,
    //重复加载
    STEPGCSAdPreloadRepeat = -2,
} STEPGCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    STEPGCSAdWillAppear,//即将出现
    STEPGCSAdDidAppear,//已经出现
    STEPGCSAdWillDisappear,//即将消失
    STEPGCSAdDidDisappear,//已经消失
    STEPGCSAdMuted,//静音广告
    STEPGCSAdWillLeaveApplication,//将要离开App

    STEPGCSAdVideoStart,//开始播放 常用于video
    STEPGCSAdVideoComplete,//播放完成 常用于video
    STEPGCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    STEPGCSAdVideoServerFail,//连接服务器成功，常用于fb video

    STEPGCSAdNativeDidDownload,//下载完成 常用于fb Native
    STEPGCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    STEPGCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    STEPGCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    STEPGCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    STEPGCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    STEPGCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    STEPGCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    STEPGCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    STEPGCSAdBUOpenDidAutoDimiss,//开屏自动消失
    STEPGCSAdBUOpenRenderSuccess, //渲染成功
    STEPGCSAdBUOpenRenderFail, //渲染失败
    STEPGCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    STEPGCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    STEPGCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    STEPGCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    STEPGCSAdDidPresentFullScreen,//插屏弹出全屏广告
    STEPGCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    STEPGCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    STEPGCSAdPlayerStatusStarted,//开始播放
    STEPGCSAdPlayerStatusPaused,//用户行为导致暂停
    STEPGCSAdPlayerStatusStoped,//播放停止
    STEPGCSAdPlayerStatusError,//播放出错
    STEPGCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    STEPGCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    STEPGCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    STEPGCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    STEPGCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    STEPGCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    STEPGCSAdRecordImpression, //广告曝光已记录
    STEPGCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    STEPGCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    STEPGCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    STEPGCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    STEPGCSAdABUOpenWillPresentFullScreen,
    STEPGCSAdABUOpenDidShowFailed,
    STEPGCSAdABUOpenWillDissmissFullScreen,
    STEPGCSAdABUOpenCountdownToZero,
    
    STEPGCSAdABUBannerWillPresentFullScreen,
    STEPGCSAdABUBannerWillDismissFullScreen,
    
    STEPGCSAdABURewardDidLoad,
    STEPGCSAdABURewardRenderFail,
    STEPGCSAdABURewardDidShowFailed,

} STEPGCSAdEvent;

typedef void (^STEPGCSAdLoadCompleteBlock)(STEPGCSAdLoadStatus adLoadStatus);

@class STEPGCSAdSetupParamsMaker;
@class STEPGCSAdSetupParams;

typedef STEPGCSAdSetupParamsMaker *(^STEPGCSAdStringInit)(NSString *);
typedef STEPGCSAdSetupParamsMaker *(^STEPGCSAdBoolInit)(BOOL);
typedef STEPGCSAdSetupParamsMaker *(^STEPGCSAdIntegerInit)(NSInteger);
typedef STEPGCSAdSetupParamsMaker *(^STEPGCSAdLongInit)(long);
typedef STEPGCSAdSetupParamsMaker *(^STEPGCSAdArrayInit)(NSArray *);
typedef STEPGCSAdSetupParams *(^STEPGCSAdMakeInit)(void);


@class STEPGCSAdDataModel;
typedef void (^STEPGCSAdRequestCompleteBlock)(NSMutableArray<STEPGCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^STEPGCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^STEPGCSAdPreloadCompleteBlock)(STEPGCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
