//
//  STEPGCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "STEPGCSAdLoadBase.h"
#import "STEPGCSAdDataModel.h"
#import "STEPGCSAdLoadProtocol.h"
#import "STEPGCSAdLoadDataProtocol.h"
#import "STEPGCSAdLoadShowProtocol.h"
#import "STEPGCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface STEPGCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)sTEPGsetupByBlock:(void (^ _Nonnull)(STEPGCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)sTEPGloadAd:(NSString *)moduleId delegate:(id<STEPGCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)sTEPGadShowStatistic:(STEPGCSAdDataModel *)dataModel adload:(nonnull STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)sTEPGadClickStatistic:(STEPGCSAdDataModel *)dataModel adload:(nonnull STEPGCSAdLoadBase<STEPGCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)sTEPGaddCustomFecher:(Class<STEPGCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
