//
//  STEPGCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "STEPGCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface STEPGCSAdLoadOpen : STEPGCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
