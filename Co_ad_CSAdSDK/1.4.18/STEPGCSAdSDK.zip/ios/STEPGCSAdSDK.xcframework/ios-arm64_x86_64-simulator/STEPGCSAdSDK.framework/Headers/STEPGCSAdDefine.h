//
//  STEPGCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sTEPGkAdvDataSourceFacebook   2 //FB 广告数据源
#define sTEPGkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sTEPGkAdvDataSourceMopub      39//Mopub 广告数据源
#define sTEPGkAdvDataSourceApplovin   20//applovin 广告数据源

#define sTEPGkAdvDataSourceGDT        62//广点通 广告数据源
#define sTEPGkAdvDataSourceBaidu      63//百度 广告数据源
#define sTEPGkAdvDataSourceBU         64//头条 广告数据源
#define sTEPGkAdvDataSourceABU         70//头条聚合 广告数据源
#define sTEPGkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define sTEPGkAdvDataSourcePangle     74//pangle 广告数据源

#define sTEPGkOnlineAdvTypeBanner                   1  //banner
#define sTEPGkOnlineAdvTypeInterstitial             2  //全屏
#define sTEPGkOnlineAdvTypeNative                   3 //native
#define sTEPGkOnlineAdvTypeVideo                    4 //视频
#define sTEPGkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sTEPGkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sTEPGkOnlineAdvTypeOpen                     8 //开屏
#define sTEPGkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define sTEPGkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define sTEPGkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define sTEPGkAdServerConfigError  -1 //服务器返回数据不正确
#define sTEPGkAdLoadConfigFailed  -2 //广告加载失败


#define sTEPGAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sTEPGkCSAdInstallDays @"sTEPGkCSAdInstallDays"
#define sTEPGkCSAdModule_key @"sTEPGkCSAdModule_key_%@"
#define sTEPGkCSNewAdModule_key @"sTEPGkCSNewAdModule_key_%@"
#define sTEPGkCSAdInstallTime @"sTEPGkCSAdInstallTime"
#define sTEPGkCSAdInstallHours @"sTEPGkCSAdInstallHours"
#define sTEPGkCSAdLastGetServerTime @"sTEPGkCSAdLastRequestTime"
#define sTEPGkCSAdloadTime 30

#define sTEPGkCSLoadAdTimeOutNotification @"sTEPGKCSLoadAdTimeOutNotification"
#define sTEPGkCSLoadAdTimeOutNotificationKey @"sTEPGKCSLoadAdTimeOutKey"

