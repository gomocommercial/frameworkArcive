//
//  PPCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPCSAdLoadNative : PPCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
