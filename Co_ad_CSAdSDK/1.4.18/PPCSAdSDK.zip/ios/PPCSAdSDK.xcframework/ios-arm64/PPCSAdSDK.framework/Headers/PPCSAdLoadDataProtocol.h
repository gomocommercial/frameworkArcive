//
//  PPCSAdLoadDataProtocol.h
//  PPCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PPCSAdTypedef.h"

@class PPCSAdDataModel;
@class PPCSAdLoadBase;

@protocol PPCSAdLoadProtocol;

@protocol PPCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)pPonAdInfoFinish:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)pPonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)pPonAdFail:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
