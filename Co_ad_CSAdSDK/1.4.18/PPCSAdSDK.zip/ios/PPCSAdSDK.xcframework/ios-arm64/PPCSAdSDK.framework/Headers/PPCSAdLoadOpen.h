//
//  PPCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPCSAdLoadOpen : PPCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
