//
//  PPCSAdNetworkTool.h
//  PPCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PPCSAdDataModel.h"
#import "PPCSAdTypedef.h"
#import "PPCSNewStoreLiteRequestTool.h"
#import "NSString+PPCSGenerateHash.h"

@interface PPCSAdNetworkTool : NSObject

+ (PPCSAdNetworkTool *)shared;
@property(nonatomic, copy) PPCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pPrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PPCSAdRequestCompleteBlock)complete;

- (void)pPsetCDay:(void(^ _Nullable)(bool success))handle;
@end
