//
//  PPCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PPCSAdLoadSuccess = 1,
    PPCSAdLoadFailure = -1,
    PPCSAdLoadTimeout = -2
} PPCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PPCSAdPreloadSuccess = 1,
    //预加载失败
    PPCSAdPreloadFailure = -1,
    //重复加载
    PPCSAdPreloadRepeat = -2,
} PPCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PPCSAdWillAppear,//即将出现
    PPCSAdDidAppear,//已经出现
    PPCSAdWillDisappear,//即将消失
    PPCSAdDidDisappear,//已经消失
    PPCSAdMuted,//静音广告
    PPCSAdWillLeaveApplication,//将要离开App

    PPCSAdVideoStart,//开始播放 常用于video
    PPCSAdVideoComplete,//播放完成 常用于video
    PPCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PPCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PPCSAdNativeDidDownload,//下载完成 常用于fb Native
    PPCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PPCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PPCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PPCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PPCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PPCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PPCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PPCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PPCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PPCSAdBUOpenRenderSuccess, //渲染成功
    PPCSAdBUOpenRenderFail, //渲染失败
    PPCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PPCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PPCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PPCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PPCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PPCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PPCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PPCSAdPlayerStatusStarted,//开始播放
    PPCSAdPlayerStatusPaused,//用户行为导致暂停
    PPCSAdPlayerStatusStoped,//播放停止
    PPCSAdPlayerStatusError,//播放出错
    PPCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PPCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PPCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PPCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PPCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PPCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PPCSAdRecordImpression, //广告曝光已记录
    PPCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PPCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PPCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PPCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PPCSAdABUOpenWillPresentFullScreen,
    PPCSAdABUOpenDidShowFailed,
    PPCSAdABUOpenWillDissmissFullScreen,
    PPCSAdABUOpenCountdownToZero,
    
    PPCSAdABUBannerWillPresentFullScreen,
    PPCSAdABUBannerWillDismissFullScreen,
    
    PPCSAdABURewardDidLoad,
    PPCSAdABURewardRenderFail,
    PPCSAdABURewardDidShowFailed,

} PPCSAdEvent;

typedef void (^PPCSAdLoadCompleteBlock)(PPCSAdLoadStatus adLoadStatus);

@class PPCSAdSetupParamsMaker;
@class PPCSAdSetupParams;

typedef PPCSAdSetupParamsMaker *(^PPCSAdStringInit)(NSString *);
typedef PPCSAdSetupParamsMaker *(^PPCSAdBoolInit)(BOOL);
typedef PPCSAdSetupParamsMaker *(^PPCSAdIntegerInit)(NSInteger);
typedef PPCSAdSetupParamsMaker *(^PPCSAdLongInit)(long);
typedef PPCSAdSetupParamsMaker *(^PPCSAdArrayInit)(NSArray *);
typedef PPCSAdSetupParams *(^PPCSAdMakeInit)(void);


@class PPCSAdDataModel;
typedef void (^PPCSAdRequestCompleteBlock)(NSMutableArray<PPCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PPCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PPCSAdPreloadCompleteBlock)(PPCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
