//
//  PPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pPkAdvDataSourceFacebook   2 //FB 广告数据源
#define pPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pPkAdvDataSourceMopub      39//Mopub 广告数据源
#define pPkAdvDataSourceApplovin   20//applovin 广告数据源

#define pPkAdvDataSourceGDT        62//广点通 广告数据源
#define pPkAdvDataSourceBaidu      63//百度 广告数据源
#define pPkAdvDataSourceBU         64//头条 广告数据源
#define pPkAdvDataSourceABU         70//头条聚合 广告数据源
#define pPkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pPkAdvDataSourcePangle     74//pangle 广告数据源

#define pPkOnlineAdvTypeBanner                   1  //banner
#define pPkOnlineAdvTypeInterstitial             2  //全屏
#define pPkOnlineAdvTypeNative                   3 //native
#define pPkOnlineAdvTypeVideo                    4 //视频
#define pPkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pPkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pPkOnlineAdvTypeOpen                     8 //开屏
#define pPkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pPkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pPkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pPkAdServerConfigError  -1 //服务器返回数据不正确
#define pPkAdLoadConfigFailed  -2 //广告加载失败


#define pPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pPkCSAdInstallDays @"pPkCSAdInstallDays"
#define pPkCSAdModule_key @"pPkCSAdModule_key_%@"
#define pPkCSNewAdModule_key @"pPkCSNewAdModule_key_%@"
#define pPkCSAdInstallTime @"pPkCSAdInstallTime"
#define pPkCSAdInstallHours @"pPkCSAdInstallHours"
#define pPkCSAdLastGetServerTime @"pPkCSAdLastRequestTime"
#define pPkCSAdloadTime 30

#define pPkCSLoadAdTimeOutNotification @"pPKCSLoadAdTimeOutNotification"
#define pPkCSLoadAdTimeOutNotificationKey @"pPKCSLoadAdTimeOutKey"

