//
//  MGCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MGCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGCSAdLoadInterstitial : MGCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
