//
//  MGCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    MGCSAdLoadSuccess = 1,
    MGCSAdLoadFailure = -1,
    MGCSAdLoadTimeout = -2
} MGCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    MGCSAdPreloadSuccess = 1,
    //预加载失败
    MGCSAdPreloadFailure = -1,
    //重复加载
    MGCSAdPreloadRepeat = -2,
} MGCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    MGCSAdWillAppear,//即将出现
    MGCSAdDidAppear,//已经出现
    MGCSAdWillDisappear,//即将消失
    MGCSAdDidDisappear,//已经消失
    MGCSAdMuted,//静音广告
    MGCSAdWillLeaveApplication,//将要离开App

    MGCSAdVideoStart,//开始播放 常用于video
    MGCSAdVideoComplete,//播放完成 常用于video
    MGCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    MGCSAdVideoServerFail,//连接服务器成功，常用于fb video

    MGCSAdNativeDidDownload,//下载完成 常用于fb Native
    MGCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    MGCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    MGCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    MGCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    MGCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    MGCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    MGCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    MGCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    MGCSAdBUOpenDidAutoDimiss,//开屏自动消失
    MGCSAdBUOpenRenderSuccess, //渲染成功
    MGCSAdBUOpenRenderFail, //渲染失败
    MGCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    MGCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    MGCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    MGCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    MGCSAdDidPresentFullScreen,//插屏弹出全屏广告
    MGCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    MGCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    MGCSAdPlayerStatusStarted,//开始播放
    MGCSAdPlayerStatusPaused,//用户行为导致暂停
    MGCSAdPlayerStatusStoped,//播放停止
    MGCSAdPlayerStatusError,//播放出错
    MGCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    MGCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    MGCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    MGCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    MGCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    MGCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    MGCSAdRecordImpression, //广告曝光已记录
    MGCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    MGCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    MGCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    MGCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    MGCSAdABUOpenWillPresentFullScreen,
    MGCSAdABUOpenDidShowFailed,
    MGCSAdABUOpenWillDissmissFullScreen,
    MGCSAdABUOpenCountdownToZero,
    
    MGCSAdABUBannerWillPresentFullScreen,
    MGCSAdABUBannerWillDismissFullScreen,
    
    MGCSAdABURewardDidLoad,
    MGCSAdABURewardRenderFail,
    MGCSAdABURewardDidShowFailed,

} MGCSAdEvent;

typedef void (^MGCSAdLoadCompleteBlock)(MGCSAdLoadStatus adLoadStatus);

@class MGCSAdSetupParamsMaker;
@class MGCSAdSetupParams;

typedef MGCSAdSetupParamsMaker *(^MGCSAdStringInit)(NSString *);
typedef MGCSAdSetupParamsMaker *(^MGCSAdBoolInit)(BOOL);
typedef MGCSAdSetupParamsMaker *(^MGCSAdIntegerInit)(NSInteger);
typedef MGCSAdSetupParamsMaker *(^MGCSAdLongInit)(long);
typedef MGCSAdSetupParamsMaker *(^MGCSAdArrayInit)(NSArray *);
typedef MGCSAdSetupParams *(^MGCSAdMakeInit)(void);


@class MGCSAdDataModel;
typedef void (^MGCSAdRequestCompleteBlock)(NSMutableArray<MGCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^MGCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^MGCSAdPreloadCompleteBlock)(MGCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
