//
//  MGCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MGCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGCSAdLoadNative : MGCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
