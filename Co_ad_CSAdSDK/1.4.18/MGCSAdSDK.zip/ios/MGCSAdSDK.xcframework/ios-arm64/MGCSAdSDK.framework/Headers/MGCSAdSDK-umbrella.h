#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MGCSAdSDK.h"
#import "MGCSAdPreload.h"
#import "MGCSAdLoadDataProtocol.h"
#import "MGCSAdLoadShowProtocol.h"
#import "MGCSAdLoadProtocol.h"
#import "MGCSAdLoadBase.h"
#import "MGCSAdLoadInterstitial.h"
#import "MGCSAdLoadNative.h"
#import "MGCSAdLoadReward.h"
#import "MGCSAdLoadOpen.h"
#import "MGCSAdLoadBanner.h"
#import "MGCSAdManager.h"
#import "MGCSAdSetupParams.h"
#import "MGCSAdSetupParamsMaker.h"
#import "MGCSAdDefine.h"
#import "MGCSAdTypedef.h"
#import "MGCSAdStatistics.h"
#import "MGCSAdDataModel.h"
#import "MGCSAdNetworkTool.h"
#import "MGCSNewStoreLiteRequestTool.h"
#import "NSString+MGCSGenerateHash.h"

FOUNDATION_EXPORT double MGCSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char MGCSAdSDKVersionString[];

