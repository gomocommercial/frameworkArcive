//
//  MGCSAdLoadDataProtocol.h
//  MGCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "MGCSAdTypedef.h"

@class MGCSAdDataModel;
@class MGCSAdLoadBase;

@protocol MGCSAdLoadProtocol;

@protocol MGCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)mGonAdInfoFinish:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)mGonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)mGonAdFail:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
