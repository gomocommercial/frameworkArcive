//
//  MGCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "MGCSAdLoadBase.h"
#import "MGCSAdDataModel.h"
#import "MGCSAdLoadProtocol.h"
#import "MGCSAdLoadDataProtocol.h"
#import "MGCSAdLoadShowProtocol.h"
#import "MGCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)mGsetupByBlock:(void (^ _Nonnull)(MGCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)mGloadAd:(NSString *)moduleId delegate:(id<MGCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)mGadShowStatistic:(MGCSAdDataModel *)dataModel adload:(nonnull MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)mGadClickStatistic:(MGCSAdDataModel *)dataModel adload:(nonnull MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)mGaddCustomFecher:(Class<MGCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
