//
//  MGCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "MGCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGCSAdLoadOpen : MGCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
