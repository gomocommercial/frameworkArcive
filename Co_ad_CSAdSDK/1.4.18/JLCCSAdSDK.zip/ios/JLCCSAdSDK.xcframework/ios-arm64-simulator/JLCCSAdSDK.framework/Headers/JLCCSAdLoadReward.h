//
//  JLCCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "JLCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadReward : JLCCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
