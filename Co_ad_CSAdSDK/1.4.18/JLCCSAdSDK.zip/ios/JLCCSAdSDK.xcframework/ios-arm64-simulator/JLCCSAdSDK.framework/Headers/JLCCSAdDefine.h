//
//  JLCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define jLCkAdvDataSourceFacebook   2 //FB 广告数据源
#define jLCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define jLCkAdvDataSourceMopub      39//Mopub 广告数据源
#define jLCkAdvDataSourceApplovin   20//applovin 广告数据源

#define jLCkAdvDataSourceGDT        62//广点通 广告数据源
#define jLCkAdvDataSourceBaidu      63//百度 广告数据源
#define jLCkAdvDataSourceBU         64//头条 广告数据源
#define jLCkAdvDataSourceABU         70//头条聚合 广告数据源
#define jLCkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define jLCkAdvDataSourcePangle     74//pangle 广告数据源

#define jLCkOnlineAdvTypeBanner                   1  //banner
#define jLCkOnlineAdvTypeInterstitial             2  //全屏
#define jLCkOnlineAdvTypeNative                   3 //native
#define jLCkOnlineAdvTypeVideo                    4 //视频
#define jLCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define jLCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define jLCkOnlineAdvTypeOpen                     8 //开屏
#define jLCkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define jLCkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define jLCkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define jLCkAdServerConfigError  -1 //服务器返回数据不正确
#define jLCkAdLoadConfigFailed  -2 //广告加载失败


#define jLCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define jLCkCSAdInstallDays @"jLCkCSAdInstallDays"
#define jLCkCSAdModule_key @"jLCkCSAdModule_key_%@"
#define jLCkCSNewAdModule_key @"jLCkCSNewAdModule_key_%@"
#define jLCkCSAdInstallTime @"jLCkCSAdInstallTime"
#define jLCkCSAdInstallHours @"jLCkCSAdInstallHours"
#define jLCkCSAdLastGetServerTime @"jLCkCSAdLastRequestTime"
#define jLCkCSAdloadTime 30

#define jLCkCSLoadAdTimeOutNotification @"jLCKCSLoadAdTimeOutNotification"
#define jLCkCSLoadAdTimeOutNotificationKey @"jLCKCSLoadAdTimeOutKey"

