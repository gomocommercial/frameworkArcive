//
//  JLCCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "JLCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadOpen : JLCCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
