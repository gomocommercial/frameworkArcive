//
//  JLCCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "JLCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadNative : JLCCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
