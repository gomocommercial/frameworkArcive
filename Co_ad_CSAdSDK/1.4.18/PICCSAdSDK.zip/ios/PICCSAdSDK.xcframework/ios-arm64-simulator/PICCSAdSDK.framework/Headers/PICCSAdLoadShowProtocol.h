//
//  PICCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PICCSAdTypedef.h"

@class PICCSAdLoadBase;

@protocol PICCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PICCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pIConAdShowed:(PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pIConAdClicked:(PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pIConAdClosed:(PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pIConAdVideoCompletePlaying:(PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pIConAdVideoGotReward:(PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload;
-(void)pIConAdDidPayRevenue:(PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)pIConAdDidGetEcpm:(PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)pIConAdShowFail:(PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pIConAdOtherEvent:(PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload event:(PICCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
