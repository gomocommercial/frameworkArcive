//
//  PICCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pICkAdvDataSourceFacebook   2 //FB 广告数据源
#define pICkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pICkAdvDataSourceMopub      39//Mopub 广告数据源
#define pICkAdvDataSourceApplovin   20//applovin 广告数据源

#define pICkAdvDataSourceGDT        62//广点通 广告数据源
#define pICkAdvDataSourceBaidu      63//百度 广告数据源
#define pICkAdvDataSourceBU         64//头条 广告数据源
#define pICkAdvDataSourceABU         70//头条聚合 广告数据源
#define pICkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pICkAdvDataSourcePangle     74//pangle 广告数据源

#define pICkOnlineAdvTypeBanner                   1  //banner
#define pICkOnlineAdvTypeInterstitial             2  //全屏
#define pICkOnlineAdvTypeNative                   3 //native
#define pICkOnlineAdvTypeVideo                    4 //视频
#define pICkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pICkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pICkOnlineAdvTypeOpen                     8 //开屏
#define pICkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pICkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pICkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pICkAdServerConfigError  -1 //服务器返回数据不正确
#define pICkAdLoadConfigFailed  -2 //广告加载失败


#define pICAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pICkCSAdInstallDays @"pICkCSAdInstallDays"
#define pICkCSAdModule_key @"pICkCSAdModule_key_%@"
#define pICkCSNewAdModule_key @"pICkCSNewAdModule_key_%@"
#define pICkCSAdInstallTime @"pICkCSAdInstallTime"
#define pICkCSAdInstallHours @"pICkCSAdInstallHours"
#define pICkCSAdLastGetServerTime @"pICkCSAdLastRequestTime"
#define pICkCSAdloadTime 30

#define pICkCSLoadAdTimeOutNotification @"pICKCSLoadAdTimeOutNotification"
#define pICkCSLoadAdTimeOutNotificationKey @"pICKCSLoadAdTimeOutKey"

