//
//  PICCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PICCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PICCSAdLoadReward : PICCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
