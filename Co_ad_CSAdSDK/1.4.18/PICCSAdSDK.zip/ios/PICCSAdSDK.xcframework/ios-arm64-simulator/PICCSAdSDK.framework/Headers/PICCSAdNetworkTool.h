//
//  PICCSAdNetworkTool.h
//  PICCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PICCSAdDataModel.h"
#import "PICCSAdTypedef.h"
#import "PICCSNewStoreLiteRequestTool.h"
#import "NSString+PICCSGenerateHash.h"

@interface PICCSAdNetworkTool : NSObject

+ (PICCSAdNetworkTool *)shared;
@property(nonatomic, copy) PICCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pICrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PICCSAdRequestCompleteBlock)complete;

- (void)pICsetCDay:(void(^ _Nullable)(bool success))handle;
@end
