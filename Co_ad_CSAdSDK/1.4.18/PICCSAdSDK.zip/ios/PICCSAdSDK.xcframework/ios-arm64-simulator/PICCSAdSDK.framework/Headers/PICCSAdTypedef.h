//
//  PICCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PICCSAdLoadSuccess = 1,
    PICCSAdLoadFailure = -1,
    PICCSAdLoadTimeout = -2
} PICCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PICCSAdPreloadSuccess = 1,
    //预加载失败
    PICCSAdPreloadFailure = -1,
    //重复加载
    PICCSAdPreloadRepeat = -2,
} PICCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PICCSAdWillAppear,//即将出现
    PICCSAdDidAppear,//已经出现
    PICCSAdWillDisappear,//即将消失
    PICCSAdDidDisappear,//已经消失
    PICCSAdMuted,//静音广告
    PICCSAdWillLeaveApplication,//将要离开App

    PICCSAdVideoStart,//开始播放 常用于video
    PICCSAdVideoComplete,//播放完成 常用于video
    PICCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PICCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PICCSAdNativeDidDownload,//下载完成 常用于fb Native
    PICCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PICCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PICCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PICCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PICCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PICCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PICCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PICCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PICCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PICCSAdBUOpenRenderSuccess, //渲染成功
    PICCSAdBUOpenRenderFail, //渲染失败
    PICCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PICCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PICCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PICCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PICCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PICCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PICCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PICCSAdPlayerStatusStarted,//开始播放
    PICCSAdPlayerStatusPaused,//用户行为导致暂停
    PICCSAdPlayerStatusStoped,//播放停止
    PICCSAdPlayerStatusError,//播放出错
    PICCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PICCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PICCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PICCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PICCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PICCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PICCSAdRecordImpression, //广告曝光已记录
    PICCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PICCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PICCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PICCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PICCSAdABUOpenWillPresentFullScreen,
    PICCSAdABUOpenDidShowFailed,
    PICCSAdABUOpenWillDissmissFullScreen,
    PICCSAdABUOpenCountdownToZero,
    
    PICCSAdABUBannerWillPresentFullScreen,
    PICCSAdABUBannerWillDismissFullScreen,
    
    PICCSAdABURewardDidLoad,
    PICCSAdABURewardRenderFail,
    PICCSAdABURewardDidShowFailed,

} PICCSAdEvent;

typedef void (^PICCSAdLoadCompleteBlock)(PICCSAdLoadStatus adLoadStatus);

@class PICCSAdSetupParamsMaker;
@class PICCSAdSetupParams;

typedef PICCSAdSetupParamsMaker *(^PICCSAdStringInit)(NSString *);
typedef PICCSAdSetupParamsMaker *(^PICCSAdBoolInit)(BOOL);
typedef PICCSAdSetupParamsMaker *(^PICCSAdIntegerInit)(NSInteger);
typedef PICCSAdSetupParamsMaker *(^PICCSAdLongInit)(long);
typedef PICCSAdSetupParamsMaker *(^PICCSAdArrayInit)(NSArray *);
typedef PICCSAdSetupParams *(^PICCSAdMakeInit)(void);


@class PICCSAdDataModel;
typedef void (^PICCSAdRequestCompleteBlock)(NSMutableArray<PICCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PICCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PICCSAdPreloadCompleteBlock)(PICCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
