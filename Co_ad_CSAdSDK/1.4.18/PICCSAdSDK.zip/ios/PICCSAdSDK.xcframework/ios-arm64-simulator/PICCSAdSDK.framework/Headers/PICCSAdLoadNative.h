//
//  PICCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PICCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PICCSAdLoadNative : PICCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
