//
//  PICCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PICCSAdLoadBase.h"
#import "PICCSAdDataModel.h"
#import "PICCSAdLoadProtocol.h"
#import "PICCSAdLoadDataProtocol.h"
#import "PICCSAdLoadShowProtocol.h"
#import "PICCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PICCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pICsetupByBlock:(void (^ _Nonnull)(PICCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pICloadAd:(NSString *)moduleId delegate:(id<PICCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pICadShowStatistic:(PICCSAdDataModel *)dataModel adload:(nonnull PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pICadClickStatistic:(PICCSAdDataModel *)dataModel adload:(nonnull PICCSAdLoadBase<PICCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pICaddCustomFecher:(Class<PICCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
