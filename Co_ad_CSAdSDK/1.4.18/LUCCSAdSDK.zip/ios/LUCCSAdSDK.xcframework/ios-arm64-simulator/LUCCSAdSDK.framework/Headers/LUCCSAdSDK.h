//
//  LUCCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "LUCCSAdLoadBase.h"
#import "LUCCSAdDataModel.h"
#import "LUCCSAdLoadProtocol.h"
#import "LUCCSAdLoadDataProtocol.h"
#import "LUCCSAdLoadShowProtocol.h"
#import "LUCCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUCCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)lUCsetupByBlock:(void (^ _Nonnull)(LUCCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)lUCloadAd:(NSString *)moduleId delegate:(id<LUCCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)lUCadShowStatistic:(LUCCSAdDataModel *)dataModel adload:(nonnull LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)lUCadClickStatistic:(LUCCSAdDataModel *)dataModel adload:(nonnull LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)lUCaddCustomFecher:(Class<LUCCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
