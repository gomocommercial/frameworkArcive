//
//  LUCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lUCkAdvDataSourceFacebook   2 //FB 广告数据源
#define lUCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lUCkAdvDataSourceMopub      39//Mopub 广告数据源
#define lUCkAdvDataSourceApplovin   20//applovin 广告数据源

#define lUCkAdvDataSourceGDT        62//广点通 广告数据源
#define lUCkAdvDataSourceBaidu      63//百度 广告数据源
#define lUCkAdvDataSourceBU         64//头条 广告数据源
#define lUCkAdvDataSourceABU         70//头条聚合 广告数据源
#define lUCkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define lUCkAdvDataSourcePangle     74//pangle 广告数据源

#define lUCkOnlineAdvTypeBanner                   1  //banner
#define lUCkOnlineAdvTypeInterstitial             2  //全屏
#define lUCkOnlineAdvTypeNative                   3 //native
#define lUCkOnlineAdvTypeVideo                    4 //视频
#define lUCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define lUCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define lUCkOnlineAdvTypeOpen                     8 //开屏
#define lUCkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define lUCkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define lUCkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define lUCkAdServerConfigError  -1 //服务器返回数据不正确
#define lUCkAdLoadConfigFailed  -2 //广告加载失败


#define lUCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lUCkCSAdInstallDays @"lUCkCSAdInstallDays"
#define lUCkCSAdModule_key @"lUCkCSAdModule_key_%@"
#define lUCkCSNewAdModule_key @"lUCkCSNewAdModule_key_%@"
#define lUCkCSAdInstallTime @"lUCkCSAdInstallTime"
#define lUCkCSAdInstallHours @"lUCkCSAdInstallHours"
#define lUCkCSAdLastGetServerTime @"lUCkCSAdLastRequestTime"
#define lUCkCSAdloadTime 30

#define lUCkCSLoadAdTimeOutNotification @"lUCKCSLoadAdTimeOutNotification"
#define lUCkCSLoadAdTimeOutNotificationKey @"lUCKCSLoadAdTimeOutKey"

