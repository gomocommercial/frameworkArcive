//
//  LUCCSAdStatistics.h
//  LUCCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "LUCCSAdDataModel.h"
#import "LUCCSAdTypedef.h"
#import "LUCCSAdLoadBase.h"
@interface LUCCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)lUCadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)lUCadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)lUCadRewardVideoCompleteStatistic:(LUCCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)lUCadShowStatistic:(LUCCSAdDataModel *)dataModel adload:(nonnull LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)lUCadClickStatistic:(LUCCSAdDataModel *)dataModel adload:(nonnull LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)lUCadUploadRevenueStatistic:(LUCCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
