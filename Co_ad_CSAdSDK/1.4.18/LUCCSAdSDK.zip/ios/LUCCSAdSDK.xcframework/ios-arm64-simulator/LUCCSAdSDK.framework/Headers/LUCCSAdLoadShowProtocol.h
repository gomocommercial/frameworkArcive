//
//  LUCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LUCCSAdTypedef.h"

@class LUCCSAdLoadBase;

@protocol LUCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LUCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lUConAdShowed:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)lUConAdClicked:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lUConAdClosed:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lUConAdVideoCompletePlaying:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)lUConAdVideoGotReward:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;
-(void)lUConAdDidPayRevenue:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)lUConAdDidGetEcpm:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)lUConAdShowFail:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lUConAdOtherEvent:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload event:(LUCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
