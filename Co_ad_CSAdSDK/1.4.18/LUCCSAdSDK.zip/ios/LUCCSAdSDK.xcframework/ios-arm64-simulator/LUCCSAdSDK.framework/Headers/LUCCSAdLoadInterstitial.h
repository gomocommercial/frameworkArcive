//
//  LUCCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LUCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUCCSAdLoadInterstitial : LUCCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
