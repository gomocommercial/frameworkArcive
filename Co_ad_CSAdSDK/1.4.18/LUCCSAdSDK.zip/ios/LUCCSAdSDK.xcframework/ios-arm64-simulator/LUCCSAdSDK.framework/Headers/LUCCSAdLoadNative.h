//
//  LUCCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LUCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUCCSAdLoadNative : LUCCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
