//
//  LUCCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "LUCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUCCSAdLoadOpen : LUCCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
