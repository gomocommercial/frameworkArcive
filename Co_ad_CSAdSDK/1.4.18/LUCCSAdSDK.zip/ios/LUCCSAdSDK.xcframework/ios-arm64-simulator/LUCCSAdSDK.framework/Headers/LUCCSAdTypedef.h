//
//  LUCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    LUCCSAdLoadSuccess = 1,
    LUCCSAdLoadFailure = -1,
    LUCCSAdLoadTimeout = -2
} LUCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    LUCCSAdPreloadSuccess = 1,
    //预加载失败
    LUCCSAdPreloadFailure = -1,
    //重复加载
    LUCCSAdPreloadRepeat = -2,
} LUCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    LUCCSAdWillAppear,//即将出现
    LUCCSAdDidAppear,//已经出现
    LUCCSAdWillDisappear,//即将消失
    LUCCSAdDidDisappear,//已经消失
    LUCCSAdMuted,//静音广告
    LUCCSAdWillLeaveApplication,//将要离开App

    LUCCSAdVideoStart,//开始播放 常用于video
    LUCCSAdVideoComplete,//播放完成 常用于video
    LUCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    LUCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    LUCCSAdNativeDidDownload,//下载完成 常用于fb Native
    LUCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    LUCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    LUCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    LUCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    LUCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    LUCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    LUCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    LUCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    LUCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    LUCCSAdBUOpenRenderSuccess, //渲染成功
    LUCCSAdBUOpenRenderFail, //渲染失败
    LUCCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    LUCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    LUCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    LUCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    LUCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    LUCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    LUCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    LUCCSAdPlayerStatusStarted,//开始播放
    LUCCSAdPlayerStatusPaused,//用户行为导致暂停
    LUCCSAdPlayerStatusStoped,//播放停止
    LUCCSAdPlayerStatusError,//播放出错
    LUCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    LUCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    LUCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    LUCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    LUCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    LUCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    LUCCSAdRecordImpression, //广告曝光已记录
    LUCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    LUCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    LUCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    LUCCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    LUCCSAdABUOpenWillPresentFullScreen,
    LUCCSAdABUOpenDidShowFailed,
    LUCCSAdABUOpenWillDissmissFullScreen,
    LUCCSAdABUOpenCountdownToZero,
    
    LUCCSAdABUBannerWillPresentFullScreen,
    LUCCSAdABUBannerWillDismissFullScreen,
    
    LUCCSAdABURewardDidLoad,
    LUCCSAdABURewardRenderFail,
    LUCCSAdABURewardDidShowFailed,

} LUCCSAdEvent;

typedef void (^LUCCSAdLoadCompleteBlock)(LUCCSAdLoadStatus adLoadStatus);

@class LUCCSAdSetupParamsMaker;
@class LUCCSAdSetupParams;

typedef LUCCSAdSetupParamsMaker *(^LUCCSAdStringInit)(NSString *);
typedef LUCCSAdSetupParamsMaker *(^LUCCSAdBoolInit)(BOOL);
typedef LUCCSAdSetupParamsMaker *(^LUCCSAdIntegerInit)(NSInteger);
typedef LUCCSAdSetupParamsMaker *(^LUCCSAdLongInit)(long);
typedef LUCCSAdSetupParamsMaker *(^LUCCSAdArrayInit)(NSArray *);
typedef LUCCSAdSetupParams *(^LUCCSAdMakeInit)(void);


@class LUCCSAdDataModel;
typedef void (^LUCCSAdRequestCompleteBlock)(NSMutableArray<LUCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^LUCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^LUCCSAdPreloadCompleteBlock)(LUCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
