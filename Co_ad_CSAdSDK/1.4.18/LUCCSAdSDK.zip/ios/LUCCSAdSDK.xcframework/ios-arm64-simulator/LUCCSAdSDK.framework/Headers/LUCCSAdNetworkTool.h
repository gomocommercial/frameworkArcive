//
//  LUCCSAdNetworkTool.h
//  LUCCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "LUCCSAdDataModel.h"
#import "LUCCSAdTypedef.h"
#import "LUCCSNewStoreLiteRequestTool.h"
#import "NSString+LUCCSGenerateHash.h"

@interface LUCCSAdNetworkTool : NSObject

+ (LUCCSAdNetworkTool *)shared;
@property(nonatomic, copy) LUCCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)lUCrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(LUCCSAdRequestCompleteBlock)complete;

- (void)lUCsetCDay:(void(^ _Nullable)(bool success))handle;
@end
