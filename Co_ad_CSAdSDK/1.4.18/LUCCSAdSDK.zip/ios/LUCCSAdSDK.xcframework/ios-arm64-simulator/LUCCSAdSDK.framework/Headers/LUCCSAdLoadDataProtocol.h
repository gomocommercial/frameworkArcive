//
//  LUCCSAdLoadDataProtocol.h
//  LUCCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "LUCCSAdTypedef.h"

@class LUCCSAdDataModel;
@class LUCCSAdLoadBase;

@protocol LUCCSAdLoadProtocol;

@protocol LUCCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)lUConAdInfoFinish:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)lUConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)lUConAdFail:(LUCCSAdLoadBase<LUCCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
