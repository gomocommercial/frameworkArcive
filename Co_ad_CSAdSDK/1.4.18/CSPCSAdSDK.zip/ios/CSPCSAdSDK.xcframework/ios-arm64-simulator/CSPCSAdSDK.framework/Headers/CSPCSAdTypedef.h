//
//  CSPCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CSPCSAdLoadSuccess = 1,
    CSPCSAdLoadFailure = -1,
    CSPCSAdLoadTimeout = -2
} CSPCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CSPCSAdPreloadSuccess = 1,
    //预加载失败
    CSPCSAdPreloadFailure = -1,
    //重复加载
    CSPCSAdPreloadRepeat = -2,
} CSPCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CSPCSAdWillAppear,//即将出现
    CSPCSAdDidAppear,//已经出现
    CSPCSAdWillDisappear,//即将消失
    CSPCSAdDidDisappear,//已经消失
    CSPCSAdMuted,//静音广告
    CSPCSAdWillLeaveApplication,//将要离开App

    CSPCSAdVideoStart,//开始播放 常用于video
    CSPCSAdVideoComplete,//播放完成 常用于video
    CSPCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CSPCSAdVideoServerFail,//连接服务器成功，常用于fb video

    CSPCSAdNativeDidDownload,//下载完成 常用于fb Native
    CSPCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CSPCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CSPCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CSPCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CSPCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CSPCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    CSPCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CSPCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CSPCSAdBUOpenDidAutoDimiss,//开屏自动消失
    CSPCSAdBUOpenRenderSuccess, //渲染成功
    CSPCSAdBUOpenRenderFail, //渲染失败
    CSPCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    CSPCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CSPCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CSPCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CSPCSAdDidPresentFullScreen,//插屏弹出全屏广告
    CSPCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CSPCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CSPCSAdPlayerStatusStarted,//开始播放
    CSPCSAdPlayerStatusPaused,//用户行为导致暂停
    CSPCSAdPlayerStatusStoped,//播放停止
    CSPCSAdPlayerStatusError,//播放出错
    CSPCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CSPCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CSPCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CSPCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CSPCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CSPCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CSPCSAdRecordImpression, //广告曝光已记录
    CSPCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CSPCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CSPCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    CSPCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    CSPCSAdABUOpenWillPresentFullScreen,
    CSPCSAdABUOpenDidShowFailed,
    CSPCSAdABUOpenWillDissmissFullScreen,
    CSPCSAdABUOpenCountdownToZero,
    
    CSPCSAdABUBannerWillPresentFullScreen,
    CSPCSAdABUBannerWillDismissFullScreen,
    
    CSPCSAdABURewardDidLoad,
    CSPCSAdABURewardRenderFail,
    CSPCSAdABURewardDidShowFailed,

} CSPCSAdEvent;

typedef void (^CSPCSAdLoadCompleteBlock)(CSPCSAdLoadStatus adLoadStatus);

@class CSPCSAdSetupParamsMaker;
@class CSPCSAdSetupParams;

typedef CSPCSAdSetupParamsMaker *(^CSPCSAdStringInit)(NSString *);
typedef CSPCSAdSetupParamsMaker *(^CSPCSAdBoolInit)(BOOL);
typedef CSPCSAdSetupParamsMaker *(^CSPCSAdIntegerInit)(NSInteger);
typedef CSPCSAdSetupParamsMaker *(^CSPCSAdLongInit)(long);
typedef CSPCSAdSetupParamsMaker *(^CSPCSAdArrayInit)(NSArray *);
typedef CSPCSAdSetupParams *(^CSPCSAdMakeInit)(void);


@class CSPCSAdDataModel;
typedef void (^CSPCSAdRequestCompleteBlock)(NSMutableArray<CSPCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CSPCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CSPCSAdPreloadCompleteBlock)(CSPCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
