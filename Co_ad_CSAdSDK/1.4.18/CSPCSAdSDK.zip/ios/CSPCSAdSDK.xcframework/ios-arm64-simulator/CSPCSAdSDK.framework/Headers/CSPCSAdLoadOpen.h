//
//  CSPCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "CSPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSPCSAdLoadOpen : CSPCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
