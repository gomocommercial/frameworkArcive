//
//  CSPCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CSPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSPCSAdLoadInterstitial : CSPCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
