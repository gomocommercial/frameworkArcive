//
//  CSPCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "CSPCSAdLoadBase.h"
#import "CSPCSAdDataModel.h"
#import "CSPCSAdLoadProtocol.h"
#import "CSPCSAdLoadDataProtocol.h"
#import "CSPCSAdLoadShowProtocol.h"
#import "CSPCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSPCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)cSPsetupByBlock:(void (^ _Nonnull)(CSPCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)cSPloadAd:(NSString *)moduleId delegate:(id<CSPCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)cSPadShowStatistic:(CSPCSAdDataModel *)dataModel adload:(nonnull CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)cSPadClickStatistic:(CSPCSAdDataModel *)dataModel adload:(nonnull CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)cSPaddCustomFecher:(Class<CSPCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
