//
//  CSPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define cSPkAdvDataSourceFacebook   2 //FB 广告数据源
#define cSPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define cSPkAdvDataSourceMopub      39//Mopub 广告数据源
#define cSPkAdvDataSourceApplovin   20//applovin 广告数据源

#define cSPkAdvDataSourceGDT        62//广点通 广告数据源
#define cSPkAdvDataSourceBaidu      63//百度 广告数据源
#define cSPkAdvDataSourceBU         64//头条 广告数据源
#define cSPkAdvDataSourceABU         70//头条聚合 广告数据源
#define cSPkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define cSPkAdvDataSourcePangle     74//pangle 广告数据源

#define cSPkOnlineAdvTypeBanner                   1  //banner
#define cSPkOnlineAdvTypeInterstitial             2  //全屏
#define cSPkOnlineAdvTypeNative                   3 //native
#define cSPkOnlineAdvTypeVideo                    4 //视频
#define cSPkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define cSPkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define cSPkOnlineAdvTypeOpen                     8 //开屏
#define cSPkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define cSPkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define cSPkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define cSPkAdServerConfigError  -1 //服务器返回数据不正确
#define cSPkAdLoadConfigFailed  -2 //广告加载失败


#define cSPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define cSPkCSAdInstallDays @"cSPkCSAdInstallDays"
#define cSPkCSAdModule_key @"cSPkCSAdModule_key_%@"
#define cSPkCSNewAdModule_key @"cSPkCSNewAdModule_key_%@"
#define cSPkCSAdInstallTime @"cSPkCSAdInstallTime"
#define cSPkCSAdInstallHours @"cSPkCSAdInstallHours"
#define cSPkCSAdLastGetServerTime @"cSPkCSAdLastRequestTime"
#define cSPkCSAdloadTime 30

#define cSPkCSLoadAdTimeOutNotification @"cSPKCSLoadAdTimeOutNotification"
#define cSPkCSLoadAdTimeOutNotificationKey @"cSPKCSLoadAdTimeOutKey"

