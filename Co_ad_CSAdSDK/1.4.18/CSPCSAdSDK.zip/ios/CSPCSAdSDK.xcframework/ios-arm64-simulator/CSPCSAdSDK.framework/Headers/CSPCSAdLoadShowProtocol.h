//
//  CSPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CSPCSAdTypedef.h"

@class CSPCSAdLoadBase;

@protocol CSPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CSPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cSPonAdShowed:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cSPonAdClicked:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cSPonAdClosed:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cSPonAdVideoCompletePlaying:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)cSPonAdVideoGotReward:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload;
-(void)cSPonAdDidPayRevenue:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)cSPonAdDidGetEcpm:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)cSPonAdShowFail:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cSPonAdOtherEvent:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload event:(CSPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
