//
//  CSPCSAdNetworkTool.h
//  CSPCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CSPCSAdDataModel.h"
#import "CSPCSAdTypedef.h"
#import "CSPCSNewStoreLiteRequestTool.h"
#import "NSString+CSPCSGenerateHash.h"

@interface CSPCSAdNetworkTool : NSObject

+ (CSPCSAdNetworkTool *)shared;
@property(nonatomic, copy) CSPCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)cSPrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CSPCSAdRequestCompleteBlock)complete;

- (void)cSPsetCDay:(void(^ _Nullable)(bool success))handle;
@end
