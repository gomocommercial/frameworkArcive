//
//  CSPCSAdLoadDataProtocol.h
//  CSPCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "CSPCSAdTypedef.h"

@class CSPCSAdDataModel;
@class CSPCSAdLoadBase;

@protocol CSPCSAdLoadProtocol;

@protocol CSPCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)cSPonAdInfoFinish:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)cSPonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)cSPonAdFail:(CSPCSAdLoadBase<CSPCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
