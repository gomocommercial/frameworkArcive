//
//  DITCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "DITCSAdLoadBase.h"
#import "DITCSAdDataModel.h"
#import "DITCSAdLoadProtocol.h"
#import "DITCSAdLoadDataProtocol.h"
#import "DITCSAdLoadShowProtocol.h"
#import "DITCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)dITsetupByBlock:(void (^ _Nonnull)(DITCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)dITloadAd:(NSString *)moduleId delegate:(id<DITCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)dITadShowStatistic:(DITCSAdDataModel *)dataModel adload:(nonnull DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)dITadClickStatistic:(DITCSAdDataModel *)dataModel adload:(nonnull DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)dITaddCustomFecher:(Class<DITCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
