//
//  DITCSAdNetworkTool.h
//  DITCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "DITCSAdDataModel.h"
#import "DITCSAdTypedef.h"
#import "DITCSNewStoreLiteRequestTool.h"
#import "NSString+DITCSGenerateHash.h"

@interface DITCSAdNetworkTool : NSObject

+ (DITCSAdNetworkTool *)shared;
@property(nonatomic, copy) DITCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)dITrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(DITCSAdRequestCompleteBlock)complete;

- (void)dITsetCDay:(void(^ _Nullable)(bool success))handle;
@end
