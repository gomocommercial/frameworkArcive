//
//  DITCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "DITCSAdTypedef.h"

@class DITCSAdLoadBase;

@protocol DITCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol DITCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)dITonAdShowed:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)dITonAdClicked:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)dITonAdClosed:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)dITonAdVideoCompletePlaying:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)dITonAdVideoGotReward:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload;
-(void)dITonAdDidPayRevenue:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)dITonAdDidGetEcpm:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)dITonAdShowFail:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)dITonAdOtherEvent:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload event:(DITCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
