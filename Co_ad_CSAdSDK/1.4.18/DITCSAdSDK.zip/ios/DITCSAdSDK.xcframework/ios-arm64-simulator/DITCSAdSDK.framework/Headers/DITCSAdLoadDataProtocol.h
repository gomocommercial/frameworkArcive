//
//  DITCSAdLoadDataProtocol.h
//  DITCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "DITCSAdTypedef.h"

@class DITCSAdDataModel;
@class DITCSAdLoadBase;

@protocol DITCSAdLoadProtocol;

@protocol DITCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)dITonAdInfoFinish:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)dITonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)dITonAdFail:(DITCSAdLoadBase<DITCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
