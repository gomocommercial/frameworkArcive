//
//  DITCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    DITCSAdLoadSuccess = 1,
    DITCSAdLoadFailure = -1,
    DITCSAdLoadTimeout = -2
} DITCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    DITCSAdPreloadSuccess = 1,
    //预加载失败
    DITCSAdPreloadFailure = -1,
    //重复加载
    DITCSAdPreloadRepeat = -2,
} DITCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    DITCSAdWillAppear,//即将出现
    DITCSAdDidAppear,//已经出现
    DITCSAdWillDisappear,//即将消失
    DITCSAdDidDisappear,//已经消失
    DITCSAdMuted,//静音广告
    DITCSAdWillLeaveApplication,//将要离开App

    DITCSAdVideoStart,//开始播放 常用于video
    DITCSAdVideoComplete,//播放完成 常用于video
    DITCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    DITCSAdVideoServerFail,//连接服务器成功，常用于fb video

    DITCSAdNativeDidDownload,//下载完成 常用于fb Native
    DITCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    DITCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    DITCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    DITCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    DITCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    DITCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    DITCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    DITCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    DITCSAdBUOpenDidAutoDimiss,//开屏自动消失
    DITCSAdBUOpenRenderSuccess, //渲染成功
    DITCSAdBUOpenRenderFail, //渲染失败
    DITCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    DITCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    DITCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    DITCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    DITCSAdDidPresentFullScreen,//插屏弹出全屏广告
    DITCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    DITCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    DITCSAdPlayerStatusStarted,//开始播放
    DITCSAdPlayerStatusPaused,//用户行为导致暂停
    DITCSAdPlayerStatusStoped,//播放停止
    DITCSAdPlayerStatusError,//播放出错
    DITCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    DITCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    DITCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    DITCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    DITCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    DITCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    DITCSAdRecordImpression, //广告曝光已记录
    DITCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    DITCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    DITCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    DITCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    DITCSAdABUOpenWillPresentFullScreen,
    DITCSAdABUOpenDidShowFailed,
    DITCSAdABUOpenWillDissmissFullScreen,
    DITCSAdABUOpenCountdownToZero,
    
    DITCSAdABUBannerWillPresentFullScreen,
    DITCSAdABUBannerWillDismissFullScreen,
    
    DITCSAdABURewardDidLoad,
    DITCSAdABURewardRenderFail,
    DITCSAdABURewardDidShowFailed,

} DITCSAdEvent;

typedef void (^DITCSAdLoadCompleteBlock)(DITCSAdLoadStatus adLoadStatus);

@class DITCSAdSetupParamsMaker;
@class DITCSAdSetupParams;

typedef DITCSAdSetupParamsMaker *(^DITCSAdStringInit)(NSString *);
typedef DITCSAdSetupParamsMaker *(^DITCSAdBoolInit)(BOOL);
typedef DITCSAdSetupParamsMaker *(^DITCSAdIntegerInit)(NSInteger);
typedef DITCSAdSetupParamsMaker *(^DITCSAdLongInit)(long);
typedef DITCSAdSetupParamsMaker *(^DITCSAdArrayInit)(NSArray *);
typedef DITCSAdSetupParams *(^DITCSAdMakeInit)(void);


@class DITCSAdDataModel;
typedef void (^DITCSAdRequestCompleteBlock)(NSMutableArray<DITCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^DITCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^DITCSAdPreloadCompleteBlock)(DITCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
