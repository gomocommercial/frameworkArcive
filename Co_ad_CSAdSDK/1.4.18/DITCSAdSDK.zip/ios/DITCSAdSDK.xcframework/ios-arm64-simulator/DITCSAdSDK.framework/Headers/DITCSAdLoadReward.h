//
//  DITCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "DITCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdLoadReward : DITCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
