//
//  DITCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define dITkAdvDataSourceFacebook   2 //FB 广告数据源
#define dITkAdvDataSourceAdmob      8 //Admob 广告数据源
#define dITkAdvDataSourceMopub      39//Mopub 广告数据源
#define dITkAdvDataSourceApplovin   20//applovin 广告数据源

#define dITkAdvDataSourceGDT        62//广点通 广告数据源
#define dITkAdvDataSourceBaidu      63//百度 广告数据源
#define dITkAdvDataSourceBU         64//头条 广告数据源
#define dITkAdvDataSourceABU         70//头条聚合 广告数据源
#define dITkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define dITkAdvDataSourcePangle     74//pangle 广告数据源

#define dITkOnlineAdvTypeBanner                   1  //banner
#define dITkOnlineAdvTypeInterstitial             2  //全屏
#define dITkOnlineAdvTypeNative                   3 //native
#define dITkOnlineAdvTypeVideo                    4 //视频
#define dITkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define dITkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define dITkOnlineAdvTypeOpen                     8 //开屏
#define dITkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define dITkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define dITkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define dITkAdServerConfigError  -1 //服务器返回数据不正确
#define dITkAdLoadConfigFailed  -2 //广告加载失败


#define dITAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define dITkCSAdInstallDays @"dITkCSAdInstallDays"
#define dITkCSAdModule_key @"dITkCSAdModule_key_%@"
#define dITkCSNewAdModule_key @"dITkCSNewAdModule_key_%@"
#define dITkCSAdInstallTime @"dITkCSAdInstallTime"
#define dITkCSAdInstallHours @"dITkCSAdInstallHours"
#define dITkCSAdLastGetServerTime @"dITkCSAdLastRequestTime"
#define dITkCSAdloadTime 30

#define dITkCSLoadAdTimeOutNotification @"dITKCSLoadAdTimeOutNotification"
#define dITkCSLoadAdTimeOutNotificationKey @"dITKCSLoadAdTimeOutKey"

