//
//  CUC_PCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "CUC_PCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadOpen : CUC_PCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
