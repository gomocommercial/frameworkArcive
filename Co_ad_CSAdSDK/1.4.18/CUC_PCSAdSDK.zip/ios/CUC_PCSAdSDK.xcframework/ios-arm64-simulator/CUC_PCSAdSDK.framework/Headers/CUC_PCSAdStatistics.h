//
//  CUC_PCSAdStatistics.h
//  CUC_PCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "CUC_PCSAdDataModel.h"
#import "CUC_PCSAdTypedef.h"
#import "CUC_PCSAdLoadBase.h"
@interface CUC_PCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)cUC_PadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)cUC_PadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)cUC_PadRewardVideoCompleteStatistic:(CUC_PCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)cUC_PadShowStatistic:(CUC_PCSAdDataModel *)dataModel adload:(nonnull CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)cUC_PadClickStatistic:(CUC_PCSAdDataModel *)dataModel adload:(nonnull CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)cUC_PadUploadRevenueStatistic:(CUC_PCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
