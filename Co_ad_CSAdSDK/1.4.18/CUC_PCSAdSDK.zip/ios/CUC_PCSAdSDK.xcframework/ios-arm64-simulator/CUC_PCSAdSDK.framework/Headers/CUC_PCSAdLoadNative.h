//
//  CUC_PCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CUC_PCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadNative : CUC_PCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
