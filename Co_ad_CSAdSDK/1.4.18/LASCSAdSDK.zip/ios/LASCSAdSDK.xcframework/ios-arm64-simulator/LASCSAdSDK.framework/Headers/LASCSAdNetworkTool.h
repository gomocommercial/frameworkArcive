//
//  LASCSAdNetworkTool.h
//  LASCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "LASCSAdDataModel.h"
#import "LASCSAdTypedef.h"
#import "LASCSNewStoreLiteRequestTool.h"
#import "NSString+LASCSGenerateHash.h"

@interface LASCSAdNetworkTool : NSObject

+ (LASCSAdNetworkTool *)shared;
@property(nonatomic, copy) LASCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)lASrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(LASCSAdRequestCompleteBlock)complete;

- (void)lASsetCDay:(void(^ _Nullable)(bool success))handle;
@end
