//
//  LASCSAdLoadDataProtocol.h
//  LASCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "LASCSAdTypedef.h"

@class LASCSAdDataModel;
@class LASCSAdLoadBase;

@protocol LASCSAdLoadProtocol;

@protocol LASCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)lASonAdInfoFinish:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)lASonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)lASonAdFail:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
