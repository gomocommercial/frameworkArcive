//
//  LASCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LASCSAdTypedef.h"

@class LASCSAdLoadBase;

@protocol LASCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LASCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lASonAdShowed:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)lASonAdClicked:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lASonAdClosed:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lASonAdVideoCompletePlaying:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)lASonAdVideoGotReward:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload;
-(void)lASonAdDidPayRevenue:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)lASonAdDidGetEcpm:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)lASonAdShowFail:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lASonAdOtherEvent:(LASCSAdLoadBase<LASCSAdLoadProtocol> *)adload event:(LASCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
