//
//  LASCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    LASCSAdLoadSuccess = 1,
    LASCSAdLoadFailure = -1,
    LASCSAdLoadTimeout = -2
} LASCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    LASCSAdPreloadSuccess = 1,
    //预加载失败
    LASCSAdPreloadFailure = -1,
    //重复加载
    LASCSAdPreloadRepeat = -2,
} LASCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    LASCSAdWillAppear,//即将出现
    LASCSAdDidAppear,//已经出现
    LASCSAdWillDisappear,//即将消失
    LASCSAdDidDisappear,//已经消失
    LASCSAdMuted,//静音广告
    LASCSAdWillLeaveApplication,//将要离开App

    LASCSAdVideoStart,//开始播放 常用于video
    LASCSAdVideoComplete,//播放完成 常用于video
    LASCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    LASCSAdVideoServerFail,//连接服务器成功，常用于fb video

    LASCSAdNativeDidDownload,//下载完成 常用于fb Native
    LASCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    LASCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    LASCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    LASCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    LASCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    LASCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    LASCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    LASCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    LASCSAdBUOpenDidAutoDimiss,//开屏自动消失
    LASCSAdBUOpenRenderSuccess, //渲染成功
    LASCSAdBUOpenRenderFail, //渲染失败
    LASCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    LASCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    LASCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    LASCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    LASCSAdDidPresentFullScreen,//插屏弹出全屏广告
    LASCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    LASCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    LASCSAdPlayerStatusStarted,//开始播放
    LASCSAdPlayerStatusPaused,//用户行为导致暂停
    LASCSAdPlayerStatusStoped,//播放停止
    LASCSAdPlayerStatusError,//播放出错
    LASCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    LASCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    LASCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    LASCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    LASCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    LASCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    LASCSAdRecordImpression, //广告曝光已记录
    LASCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    LASCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    LASCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    LASCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    LASCSAdABUOpenWillPresentFullScreen,
    LASCSAdABUOpenDidShowFailed,
    LASCSAdABUOpenWillDissmissFullScreen,
    LASCSAdABUOpenCountdownToZero,
    
    LASCSAdABUBannerWillPresentFullScreen,
    LASCSAdABUBannerWillDismissFullScreen,
    
    LASCSAdABURewardDidLoad,
    LASCSAdABURewardRenderFail,
    LASCSAdABURewardDidShowFailed,

} LASCSAdEvent;

typedef void (^LASCSAdLoadCompleteBlock)(LASCSAdLoadStatus adLoadStatus);

@class LASCSAdSetupParamsMaker;
@class LASCSAdSetupParams;

typedef LASCSAdSetupParamsMaker *(^LASCSAdStringInit)(NSString *);
typedef LASCSAdSetupParamsMaker *(^LASCSAdBoolInit)(BOOL);
typedef LASCSAdSetupParamsMaker *(^LASCSAdIntegerInit)(NSInteger);
typedef LASCSAdSetupParamsMaker *(^LASCSAdLongInit)(long);
typedef LASCSAdSetupParamsMaker *(^LASCSAdArrayInit)(NSArray *);
typedef LASCSAdSetupParams *(^LASCSAdMakeInit)(void);


@class LASCSAdDataModel;
typedef void (^LASCSAdRequestCompleteBlock)(NSMutableArray<LASCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^LASCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^LASCSAdPreloadCompleteBlock)(LASCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
