//
//  LASCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LASCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdLoadInterstitial : LASCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
