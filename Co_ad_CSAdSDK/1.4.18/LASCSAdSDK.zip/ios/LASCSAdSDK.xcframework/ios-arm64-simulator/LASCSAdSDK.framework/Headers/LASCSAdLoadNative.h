//
//  LASCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LASCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdLoadNative : LASCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
