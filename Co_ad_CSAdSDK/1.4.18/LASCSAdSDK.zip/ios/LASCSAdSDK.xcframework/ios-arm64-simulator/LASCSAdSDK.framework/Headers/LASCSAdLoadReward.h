//
//  LASCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LASCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdLoadReward : LASCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
