//
//  LASCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lASkAdvDataSourceFacebook   2 //FB 广告数据源
#define lASkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lASkAdvDataSourceMopub      39//Mopub 广告数据源
#define lASkAdvDataSourceApplovin   20//applovin 广告数据源

#define lASkAdvDataSourceGDT        62//广点通 广告数据源
#define lASkAdvDataSourceBaidu      63//百度 广告数据源
#define lASkAdvDataSourceBU         64//头条 广告数据源
#define lASkAdvDataSourceABU         70//头条聚合 广告数据源
#define lASkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define lASkAdvDataSourcePangle     74//pangle 广告数据源

#define lASkOnlineAdvTypeBanner                   1  //banner
#define lASkOnlineAdvTypeInterstitial             2  //全屏
#define lASkOnlineAdvTypeNative                   3 //native
#define lASkOnlineAdvTypeVideo                    4 //视频
#define lASkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define lASkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define lASkOnlineAdvTypeOpen                     8 //开屏
#define lASkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define lASkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define lASkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define lASkAdServerConfigError  -1 //服务器返回数据不正确
#define lASkAdLoadConfigFailed  -2 //广告加载失败


#define lASAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lASkCSAdInstallDays @"lASkCSAdInstallDays"
#define lASkCSAdModule_key @"lASkCSAdModule_key_%@"
#define lASkCSNewAdModule_key @"lASkCSNewAdModule_key_%@"
#define lASkCSAdInstallTime @"lASkCSAdInstallTime"
#define lASkCSAdInstallHours @"lASkCSAdInstallHours"
#define lASkCSAdLastGetServerTime @"lASkCSAdLastRequestTime"
#define lASkCSAdloadTime 30

#define lASkCSLoadAdTimeOutNotification @"lASKCSLoadAdTimeOutNotification"
#define lASkCSLoadAdTimeOutNotificationKey @"lASKCSLoadAdTimeOutKey"

