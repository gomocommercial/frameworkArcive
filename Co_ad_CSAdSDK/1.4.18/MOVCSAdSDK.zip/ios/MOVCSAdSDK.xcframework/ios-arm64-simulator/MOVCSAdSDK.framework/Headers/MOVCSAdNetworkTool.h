//
//  MOVCSAdNetworkTool.h
//  MOVCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "MOVCSAdDataModel.h"
#import "MOVCSAdTypedef.h"
#import "MOVCSNewStoreLiteRequestTool.h"
#import "NSString+MOVCSGenerateHash.h"

@interface MOVCSAdNetworkTool : NSObject

+ (MOVCSAdNetworkTool *)shared;
@property(nonatomic, copy) MOVCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)mOVrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(MOVCSAdRequestCompleteBlock)complete;

- (void)mOVsetCDay:(void(^ _Nullable)(bool success))handle;
@end
