//
//  MOVCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "MOVCSAdLoadBase.h"
#import "MOVCSAdDataModel.h"
#import "MOVCSAdLoadProtocol.h"
#import "MOVCSAdLoadDataProtocol.h"
#import "MOVCSAdLoadShowProtocol.h"
#import "MOVCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface MOVCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)mOVsetupByBlock:(void (^ _Nonnull)(MOVCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)mOVloadAd:(NSString *)moduleId delegate:(id<MOVCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)mOVadShowStatistic:(MOVCSAdDataModel *)dataModel adload:(nonnull MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)mOVadClickStatistic:(MOVCSAdDataModel *)dataModel adload:(nonnull MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)mOVaddCustomFecher:(Class<MOVCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
