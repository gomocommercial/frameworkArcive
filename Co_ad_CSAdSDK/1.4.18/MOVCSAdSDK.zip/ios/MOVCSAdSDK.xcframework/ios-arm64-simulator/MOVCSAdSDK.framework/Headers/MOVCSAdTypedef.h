//
//  MOVCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    MOVCSAdLoadSuccess = 1,
    MOVCSAdLoadFailure = -1,
    MOVCSAdLoadTimeout = -2
} MOVCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    MOVCSAdPreloadSuccess = 1,
    //预加载失败
    MOVCSAdPreloadFailure = -1,
    //重复加载
    MOVCSAdPreloadRepeat = -2,
} MOVCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    MOVCSAdWillAppear,//即将出现
    MOVCSAdDidAppear,//已经出现
    MOVCSAdWillDisappear,//即将消失
    MOVCSAdDidDisappear,//已经消失
    MOVCSAdMuted,//静音广告
    MOVCSAdWillLeaveApplication,//将要离开App

    MOVCSAdVideoStart,//开始播放 常用于video
    MOVCSAdVideoComplete,//播放完成 常用于video
    MOVCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    MOVCSAdVideoServerFail,//连接服务器成功，常用于fb video

    MOVCSAdNativeDidDownload,//下载完成 常用于fb Native
    MOVCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    MOVCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    MOVCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    MOVCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    MOVCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    MOVCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    MOVCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    MOVCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    MOVCSAdBUOpenDidAutoDimiss,//开屏自动消失
    MOVCSAdBUOpenRenderSuccess, //渲染成功
    MOVCSAdBUOpenRenderFail, //渲染失败
    MOVCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    MOVCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    MOVCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    MOVCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    MOVCSAdDidPresentFullScreen,//插屏弹出全屏广告
    MOVCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    MOVCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    MOVCSAdPlayerStatusStarted,//开始播放
    MOVCSAdPlayerStatusPaused,//用户行为导致暂停
    MOVCSAdPlayerStatusStoped,//播放停止
    MOVCSAdPlayerStatusError,//播放出错
    MOVCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    MOVCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    MOVCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    MOVCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    MOVCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    MOVCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    MOVCSAdRecordImpression, //广告曝光已记录
    MOVCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    MOVCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    MOVCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    MOVCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    MOVCSAdABUOpenWillPresentFullScreen,
    MOVCSAdABUOpenDidShowFailed,
    MOVCSAdABUOpenWillDissmissFullScreen,
    MOVCSAdABUOpenCountdownToZero,
    
    MOVCSAdABUBannerWillPresentFullScreen,
    MOVCSAdABUBannerWillDismissFullScreen,
    
    MOVCSAdABURewardDidLoad,
    MOVCSAdABURewardRenderFail,
    MOVCSAdABURewardDidShowFailed,

} MOVCSAdEvent;

typedef void (^MOVCSAdLoadCompleteBlock)(MOVCSAdLoadStatus adLoadStatus);

@class MOVCSAdSetupParamsMaker;
@class MOVCSAdSetupParams;

typedef MOVCSAdSetupParamsMaker *(^MOVCSAdStringInit)(NSString *);
typedef MOVCSAdSetupParamsMaker *(^MOVCSAdBoolInit)(BOOL);
typedef MOVCSAdSetupParamsMaker *(^MOVCSAdIntegerInit)(NSInteger);
typedef MOVCSAdSetupParamsMaker *(^MOVCSAdLongInit)(long);
typedef MOVCSAdSetupParamsMaker *(^MOVCSAdArrayInit)(NSArray *);
typedef MOVCSAdSetupParams *(^MOVCSAdMakeInit)(void);


@class MOVCSAdDataModel;
typedef void (^MOVCSAdRequestCompleteBlock)(NSMutableArray<MOVCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^MOVCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^MOVCSAdPreloadCompleteBlock)(MOVCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
