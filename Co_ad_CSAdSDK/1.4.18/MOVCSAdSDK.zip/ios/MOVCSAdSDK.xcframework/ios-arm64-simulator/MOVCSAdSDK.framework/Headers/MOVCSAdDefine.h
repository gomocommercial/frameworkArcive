//
//  MOVCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define mOVkAdvDataSourceFacebook   2 //FB 广告数据源
#define mOVkAdvDataSourceAdmob      8 //Admob 广告数据源
#define mOVkAdvDataSourceMopub      39//Mopub 广告数据源
#define mOVkAdvDataSourceApplovin   20//applovin 广告数据源

#define mOVkAdvDataSourceGDT        62//广点通 广告数据源
#define mOVkAdvDataSourceBaidu      63//百度 广告数据源
#define mOVkAdvDataSourceBU         64//头条 广告数据源
#define mOVkAdvDataSourceABU         70//头条聚合 广告数据源
#define mOVkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define mOVkAdvDataSourcePangle     74//pangle 广告数据源

#define mOVkOnlineAdvTypeBanner                   1  //banner
#define mOVkOnlineAdvTypeInterstitial             2  //全屏
#define mOVkOnlineAdvTypeNative                   3 //native
#define mOVkOnlineAdvTypeVideo                    4 //视频
#define mOVkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define mOVkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define mOVkOnlineAdvTypeOpen                     8 //开屏
#define mOVkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define mOVkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define mOVkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define mOVkAdServerConfigError  -1 //服务器返回数据不正确
#define mOVkAdLoadConfigFailed  -2 //广告加载失败


#define mOVAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define mOVkCSAdInstallDays @"mOVkCSAdInstallDays"
#define mOVkCSAdModule_key @"mOVkCSAdModule_key_%@"
#define mOVkCSNewAdModule_key @"mOVkCSNewAdModule_key_%@"
#define mOVkCSAdInstallTime @"mOVkCSAdInstallTime"
#define mOVkCSAdInstallHours @"mOVkCSAdInstallHours"
#define mOVkCSAdLastGetServerTime @"mOVkCSAdLastRequestTime"
#define mOVkCSAdloadTime 30

#define mOVkCSLoadAdTimeOutNotification @"mOVKCSLoadAdTimeOutNotification"
#define mOVkCSLoadAdTimeOutNotificationKey @"mOVKCSLoadAdTimeOutKey"

