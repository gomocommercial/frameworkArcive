//
//  MOVCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "MOVCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MOVCSAdLoadOpen : MOVCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
