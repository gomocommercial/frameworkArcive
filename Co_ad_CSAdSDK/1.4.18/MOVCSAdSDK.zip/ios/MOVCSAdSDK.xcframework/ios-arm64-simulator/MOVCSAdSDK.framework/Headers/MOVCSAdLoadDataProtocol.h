//
//  MOVCSAdLoadDataProtocol.h
//  MOVCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "MOVCSAdTypedef.h"

@class MOVCSAdDataModel;
@class MOVCSAdLoadBase;

@protocol MOVCSAdLoadProtocol;

@protocol MOVCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)mOVonAdInfoFinish:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)mOVonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)mOVonAdFail:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
