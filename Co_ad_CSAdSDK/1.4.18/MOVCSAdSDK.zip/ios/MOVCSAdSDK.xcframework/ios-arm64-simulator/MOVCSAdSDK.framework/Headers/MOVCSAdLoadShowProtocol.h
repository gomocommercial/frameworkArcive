//
//  MOVCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MOVCSAdTypedef.h"

@class MOVCSAdLoadBase;

@protocol MOVCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MOVCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mOVonAdShowed:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)mOVonAdClicked:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mOVonAdClosed:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mOVonAdVideoCompletePlaying:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)mOVonAdVideoGotReward:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload;
-(void)mOVonAdDidPayRevenue:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)mOVonAdDidGetEcpm:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)mOVonAdShowFail:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mOVonAdOtherEvent:(MOVCSAdLoadBase<MOVCSAdLoadProtocol> *)adload event:(MOVCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
