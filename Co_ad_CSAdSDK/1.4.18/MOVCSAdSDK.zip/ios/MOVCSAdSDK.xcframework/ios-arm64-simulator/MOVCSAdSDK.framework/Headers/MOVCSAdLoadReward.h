//
//  MOVCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MOVCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MOVCSAdLoadReward : MOVCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
