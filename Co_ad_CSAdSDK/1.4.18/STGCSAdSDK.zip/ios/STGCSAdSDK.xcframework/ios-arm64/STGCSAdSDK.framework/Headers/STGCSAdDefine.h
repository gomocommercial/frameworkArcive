//
//  STGCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sTGkAdvDataSourceFacebook   2 //FB 广告数据源
#define sTGkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sTGkAdvDataSourceMopub      39//Mopub 广告数据源
#define sTGkAdvDataSourceApplovin   20//applovin 广告数据源

#define sTGkAdvDataSourceGDT        62//广点通 广告数据源
#define sTGkAdvDataSourceBaidu      63//百度 广告数据源
#define sTGkAdvDataSourceBU         64//头条 广告数据源
#define sTGkAdvDataSourceABU         70//头条聚合 广告数据源
#define sTGkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define sTGkAdvDataSourcePangle     74//pangle 广告数据源

#define sTGkOnlineAdvTypeBanner                   1  //banner
#define sTGkOnlineAdvTypeInterstitial             2  //全屏
#define sTGkOnlineAdvTypeNative                   3 //native
#define sTGkOnlineAdvTypeVideo                    4 //视频
#define sTGkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sTGkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sTGkOnlineAdvTypeOpen                     8 //开屏
#define sTGkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define sTGkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define sTGkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define sTGkAdServerConfigError  -1 //服务器返回数据不正确
#define sTGkAdLoadConfigFailed  -2 //广告加载失败


#define sTGAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sTGkCSAdInstallDays @"sTGkCSAdInstallDays"
#define sTGkCSAdModule_key @"sTGkCSAdModule_key_%@"
#define sTGkCSNewAdModule_key @"sTGkCSNewAdModule_key_%@"
#define sTGkCSAdInstallTime @"sTGkCSAdInstallTime"
#define sTGkCSAdInstallHours @"sTGkCSAdInstallHours"
#define sTGkCSAdLastGetServerTime @"sTGkCSAdLastRequestTime"
#define sTGkCSAdloadTime 30

#define sTGkCSLoadAdTimeOutNotification @"sTGKCSLoadAdTimeOutNotification"
#define sTGkCSLoadAdTimeOutNotificationKey @"sTGKCSLoadAdTimeOutKey"

