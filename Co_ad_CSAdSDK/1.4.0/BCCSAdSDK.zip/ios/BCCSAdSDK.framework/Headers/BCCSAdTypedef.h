//
//  BCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    BCCSAdLoadSuccess = 1,
    BCCSAdLoadFailure = -1,
    BCCSAdLoadTimeout = -2
} BCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    BCCSAdPreloadSuccess = 1,
    //预加载失败
    BCCSAdPreloadFailure = -1,
    //重复加载
    BCCSAdPreloadRepeat = -2,
} BCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    BCCSAdWillAppear,//即将出现
    BCCSAdDidAppear,//已经出现
    BCCSAdWillDisappear,//即将消失
    BCCSAdDidDisappear,//已经消失
    BCCSAdMuted,//静音广告
    BCCSAdWillLeaveApplication,//将要离开App

    BCCSAdVideoStart,//开始播放 常用于video
    BCCSAdVideoComplete,//播放完成 常用于video
    BCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    BCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    BCCSAdNativeDidDownload,//下载完成 常用于fb Native
    BCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    BCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    BCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    BCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    BCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    BCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    BCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    BCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    BCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    BCCSAdBUOpenRenderSuccess, //渲染成功
    BCCSAdBUOpenRenderFail, //渲染失败
    BCCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    BCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    BCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    BCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    BCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    BCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    BCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    BCCSAdPlayerStatusStarted,//开始播放
    BCCSAdPlayerStatusPaused,//用户行为导致暂停
    BCCSAdPlayerStatusStoped,//播放停止
    BCCSAdPlayerStatusError,//播放出错
    BCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    BCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    BCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    BCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    BCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    BCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    BCCSAdRecordImpression, //广告曝光已记录
    BCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    BCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    BCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    BCCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    BCCSAdABUOpenWillPresentFullScreen,
    BCCSAdABUOpenDidShowFailed,
    BCCSAdABUOpenWillDissmissFullScreen,
    BCCSAdABUOpenCountdownToZero,
    
    BCCSAdABUBannerWillPresentFullScreen,
    BCCSAdABUBannerWillDismissFullScreen,
    
    BCCSAdABURewardDidLoad,
    BCCSAdABURewardRenderFail,
    BCCSAdABURewardDidShowFailed,

} BCCSAdEvent;

typedef void (^BCCSAdLoadCompleteBlock)(BCCSAdLoadStatus adLoadStatus);

@class BCCSAdSetupParamsMaker;
@class BCCSAdSetupParams;

typedef BCCSAdSetupParamsMaker *(^BCCSAdStringInit)(NSString *);
typedef BCCSAdSetupParamsMaker *(^BCCSAdBoolInit)(BOOL);
typedef BCCSAdSetupParamsMaker *(^BCCSAdIntegerInit)(NSInteger);
typedef BCCSAdSetupParamsMaker *(^BCCSAdLongInit)(long);
typedef BCCSAdSetupParamsMaker *(^BCCSAdArrayInit)(NSArray *);
typedef BCCSAdSetupParams *(^BCCSAdMakeInit)(void);


@class BCCSAdDataModel;
typedef void (^BCCSAdRequestCompleteBlock)(NSMutableArray<BCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^BCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^BCCSAdPreloadCompleteBlock)(BCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
