//
//  SLCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SLCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadInterstitial : SLCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
