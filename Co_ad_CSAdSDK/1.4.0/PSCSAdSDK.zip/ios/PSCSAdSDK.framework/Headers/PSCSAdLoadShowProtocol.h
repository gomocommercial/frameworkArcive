//
//  PSCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PSCSAdTypedef.h"

@class PSCSAdLoadBase;

@protocol PSCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PSCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pSonAdShowed:(PSCSAdLoadBase<PSCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pSonAdClicked:(PSCSAdLoadBase<PSCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pSonAdClosed:(PSCSAdLoadBase<PSCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pSonAdVideoCompletePlaying:(PSCSAdLoadBase<PSCSAdLoadProtocol> *)adload;
/**
 激励视频获得奖励
 */
-(void)pSonAdVideoGotReward:(PSCSAdLoadBase<PSCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)pSonAdShowFail:(PSCSAdLoadBase<PSCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pSonAdOtherEvent:(PSCSAdLoadBase<PSCSAdLoadProtocol> *)adload event:(PSCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
