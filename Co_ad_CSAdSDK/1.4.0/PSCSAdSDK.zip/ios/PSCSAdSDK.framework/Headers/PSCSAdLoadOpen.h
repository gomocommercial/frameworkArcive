//
//  PSCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSCSAdLoadOpen : PSCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
