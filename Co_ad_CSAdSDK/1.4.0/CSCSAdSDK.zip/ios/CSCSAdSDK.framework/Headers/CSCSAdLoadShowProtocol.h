//
//  CSCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CSCSAdTypedef.h"

@class CSCSAdLoadBase;

@protocol CSCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CSCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cSonAdShowed:(CSCSAdLoadBase<CSCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cSonAdClicked:(CSCSAdLoadBase<CSCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cSonAdClosed:(CSCSAdLoadBase<CSCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cSonAdVideoCompletePlaying:(CSCSAdLoadBase<CSCSAdLoadProtocol> *)adload;
/**
 激励视频获得奖励
 */
-(void)cSonAdVideoGotReward:(CSCSAdLoadBase<CSCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)cSonAdShowFail:(CSCSAdLoadBase<CSCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cSonAdOtherEvent:(CSCSAdLoadBase<CSCSAdLoadProtocol> *)adload event:(CSCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
