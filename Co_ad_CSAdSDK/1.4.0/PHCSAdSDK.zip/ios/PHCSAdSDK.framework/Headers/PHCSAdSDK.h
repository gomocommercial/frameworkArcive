//
//  PHCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PHCSAdLoadBase.h"
#import "PHCSAdDataModel.h"
#import "PHCSAdLoadProtocol.h"
#import "PHCSAdLoadDataProtocol.h"
#import "PHCSAdLoadShowProtocol.h"
#import "PHCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PHCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pHsetupByBlock:(void (^ _Nonnull)(PHCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pHloadAd:(NSString *)moduleId delegate:(id<PHCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pHadShowStatistic:(PHCSAdDataModel *)dataModel adload:(nonnull PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pHadClickStatistic:(PHCSAdDataModel *)dataModel adload:(nonnull PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pHaddCustomFecher:(Class<PHCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
