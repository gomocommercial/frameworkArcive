//
//  PHCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PHCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PHCSAdLoadOpen : PHCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
