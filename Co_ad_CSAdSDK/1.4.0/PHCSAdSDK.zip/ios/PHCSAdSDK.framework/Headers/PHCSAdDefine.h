//
//  PHCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pHkAdvDataSourceFacebook   2 //FB 广告数据源
#define pHkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pHkAdvDataSourceMopub      39//Mopub 广告数据源
#define pHkAdvDataSourceApplovin   20//applovin 广告数据源

#define pHkAdvDataSourceGDT        62//广点通 广告数据源
#define pHkAdvDataSourceBaidu      63//百度 广告数据源
#define pHkAdvDataSourceBU         64//头条 广告数据源
#define pHkAdvDataSourceABU         70//头条聚合 广告数据源
#define pHkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pHkAdvDataSourcePangle     74//pangle 广告数据源

#define pHkOnlineAdvTypeBanner                   1  //banner
#define pHkOnlineAdvTypeInterstitial             2  //全屏
#define pHkOnlineAdvTypeNative                   3 //native
#define pHkOnlineAdvTypeVideo                    4 //视频
#define pHkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pHkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pHkOnlineAdvTypeOpen                     8 //开屏
#define pHkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define pHkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pHkAdServerConfigError  -1 //服务器返回数据不正确
#define pHkAdLoadConfigFailed  -2 //广告加载失败


#define pHAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pHkCSAdInstallDays @"pHkCSAdInstallDays"
#define pHkCSAdModule_key @"pHkCSAdModule_key_%@"
#define pHkCSNewAdModule_key @"pHkCSNewAdModule_key_%@"
#define pHkCSAdInstallTime @"pHkCSAdInstallTime"
#define pHkCSAdInstallHours @"pHkCSAdInstallHours"
#define pHkCSAdLastGetServerTime @"pHkCSAdLastRequestTime"
#define pHkCSAdloadTime 30

#define pHkCSLoadAdTimeOutNotification @"pHKCSLoadAdTimeOutNotification"
#define pHkCSLoadAdTimeOutNotificationKey @"pHKCSLoadAdTimeOutKey"

