//
//  PHCSAdLoadDataProtocol.h
//  PHCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PHCSAdTypedef.h"

@class PHCSAdDataModel;
@class PHCSAdLoadBase;

@protocol PHCSAdLoadProtocol;

@protocol PHCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)pHonAdInfoFinish:(PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)pHonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)pHonAdFail:(PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
