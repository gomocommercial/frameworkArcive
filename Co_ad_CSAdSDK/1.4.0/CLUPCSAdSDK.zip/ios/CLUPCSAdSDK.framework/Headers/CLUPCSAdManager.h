//
//  CLUPCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLUPCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface CLUPCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)cLUPloadAd:(NSString *)moduleId delegate:(id<CLUPCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)cLUPremoveData:(id)obj;

@end

NS_ASSUME_NONNULL_END
