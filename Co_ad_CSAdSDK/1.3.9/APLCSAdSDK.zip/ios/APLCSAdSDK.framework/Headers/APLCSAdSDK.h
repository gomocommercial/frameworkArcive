//
//  APLCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "APLCSAdLoadBase.h"
#import "APLCSAdDataModel.h"
#import "APLCSAdLoadProtocol.h"
#import "APLCSAdLoadDataProtocol.h"
#import "APLCSAdLoadShowProtocol.h"
#import "APLCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface APLCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)aPLsetupByBlock:(void (^ _Nonnull)(APLCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)aPLloadAd:(NSString *)moduleId delegate:(id<APLCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)aPLadShowStatistic:(APLCSAdDataModel *)dataModel adload:(nonnull APLCSAdLoadBase<APLCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)aPLadClickStatistic:(APLCSAdDataModel *)dataModel adload:(nonnull APLCSAdLoadBase<APLCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)aPLaddCustomFecher:(Class<APLCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
