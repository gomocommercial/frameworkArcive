//
//  Co_open_CSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "Co_open_CSAdTypedef.h"

@class Co_open_CSAdLoadBase;

@protocol Co_open_CSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol Co_open_CSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)co_open_onAdShowed:(Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)co_open_onAdClicked:(Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)co_open_onAdClosed:(Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)co_open_onAdVideoCompletePlaying:(Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)co_open_onAdShowFail:(Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)co_open_onAdOtherEvent:(Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload event:(Co_open_CSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
