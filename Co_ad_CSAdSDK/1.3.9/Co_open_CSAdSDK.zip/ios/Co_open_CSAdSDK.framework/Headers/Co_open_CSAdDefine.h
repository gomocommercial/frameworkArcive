//
//  Co_open_CSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define co_open_kAdvDataSourceFacebook   2 //FB 广告数据源
#define co_open_kAdvDataSourceAdmob      8 //Admob 广告数据源
#define co_open_kAdvDataSourceMopub      39//Mopub 广告数据源
#define co_open_kAdvDataSourceApplovin   20//applovin 广告数据源

#define co_open_kAdvDataSourceGDT        62//广点通 广告数据源
#define co_open_kAdvDataSourceBaidu      63//百度 广告数据源
#define co_open_kAdvDataSourceBU         64//头条 广告数据源
#define co_open_kAdvDataSourceABU         70//头条聚合 广告数据源


#define co_open_kOnlineAdvTypeBanner                   1  //banner
#define co_open_kOnlineAdvTypeInterstitial             2  //全屏
#define co_open_kOnlineAdvTypeNative                   3 //native
#define co_open_kOnlineAdvTypeVideo                    4 //视频
#define co_open_kOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define co_open_kOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define co_open_kOnlineAdvTypeOpen                     8 //开屏
#define co_open_kOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define co_open_kAdServerConfigError  -1 //服务器返回数据不正确
#define co_open_kAdLoadConfigFailed  -2 //广告加载失败


#define co_open_AdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define co_open_kCSAdInstallDays @"co_open_kCSAdInstallDays"
#define co_open_kCSAdModule_key @"co_open_kCSAdModule_key_%@"
#define co_open_kCSAdInstallTime @"co_open_kCSAdInstallTime"
#define co_open_kCSAdLastGetServerTime @"co_open_kCSAdLastRequestTime"
#define co_open_kCSAdloadTime 30

#define co_open_kCSLoadAdTimeOutNotification @"co_open_KCSLoadAdTimeOutNotification"
#define co_open_kCSLoadAdTimeOutNotificationKey @"co_open_KCSLoadAdTimeOutKey"

