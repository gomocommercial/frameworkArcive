//
//  Co_open_CSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "Co_open_CSAdLoadBase.h"
#import "Co_open_CSAdDataModel.h"
#import "Co_open_CSAdLoadProtocol.h"
#import "Co_open_CSAdLoadDataProtocol.h"
#import "Co_open_CSAdLoadShowProtocol.h"
#import "Co_open_CSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_open_CSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)co_open_setupByBlock:(void (^ _Nonnull)(Co_open_CSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)co_open_loadAd:(NSString *)moduleId delegate:(id<Co_open_CSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)co_open_adShowStatistic:(Co_open_CSAdDataModel *)dataModel adload:(nonnull Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)co_open_adClickStatistic:(Co_open_CSAdDataModel *)dataModel adload:(nonnull Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)co_open_addCustomFecher:(Class<Co_open_CSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
