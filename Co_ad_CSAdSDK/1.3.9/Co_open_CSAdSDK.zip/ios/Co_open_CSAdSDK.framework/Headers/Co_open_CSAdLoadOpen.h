//
//  Co_open_CSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "Co_open_CSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_open_CSAdLoadOpen : Co_open_CSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
