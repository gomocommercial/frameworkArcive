//
//  Co_open_CSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    Co_open_CSAdLoadSuccess = 1,
    Co_open_CSAdLoadFailure = -1,
    Co_open_CSAdLoadTimeout = -2
} Co_open_CSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    Co_open_CSAdPreloadSuccess = 1,
    //预加载失败
    Co_open_CSAdPreloadFailure = -1,
    //重复加载
    Co_open_CSAdPreloadRepeat = -2,
} Co_open_CSAdPreloadStatus;


typedef enum : NSUInteger {
    
    Co_open_CSAdWillAppear,//即将出现
    Co_open_CSAdDidAppear,//已经出现
    Co_open_CSAdWillDisappear,//即将消失
    Co_open_CSAdDidDisappear,//已经消失
    Co_open_CSAdMuted,//静音广告
    Co_open_CSAdWillLeaveApplication,//将要离开App

    Co_open_CSAdVideoStart,//开始播放 常用于video
    Co_open_CSAdVideoComplete,//播放完成 常用于video
    Co_open_CSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    Co_open_CSAdVideoServerFail,//连接服务器成功，常用于fb video

    Co_open_CSAdNativeDidDownload,//下载完成 常用于fb Native
    Co_open_CSAdNativeFinishClick,//完成点击 常用与fb Native
    
    Co_open_CSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    Co_open_CSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    Co_open_CSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    Co_open_CSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    Co_open_CSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    Co_open_CSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    Co_open_CSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    Co_open_CSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    Co_open_CSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    Co_open_CSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    Co_open_CSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    Co_open_CSAdDidPresentFullScreen,//插屏弹出全屏广告
    Co_open_CSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    Co_open_CSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    Co_open_CSAdPlayerStatusStarted,//开始播放
    Co_open_CSAdPlayerStatusPaused,//用户行为导致暂停
    Co_open_CSAdPlayerStatusStoped,//播放停止
    Co_open_CSAdPlayerStatusError,//播放出错
    Co_open_CSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    Co_open_CSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    Co_open_CSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    Co_open_CSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    Co_open_CSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    Co_open_CSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    Co_open_CSAdRecordImpression, //广告曝光已记录
    Co_open_CSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    Co_open_CSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    Co_open_CSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    Co_open_CSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    Co_open_CSAdABUOpenWillPresentFullScreen,
    Co_open_CSAdABUOpenDidShowFailed,
    Co_open_CSAdABUOpenWillDissmissFullScreen,
    Co_open_CSAdABUOpenCountdownToZero,
    
    Co_open_CSAdABUBannerWillPresentFullScreen,
    Co_open_CSAdABUBannerWillDismissFullScreen,
    
    Co_open_CSAdABURewardDidLoad,
    Co_open_CSAdABURewardRenderFail,
    Co_open_CSAdABURewardDidShowFailed,

} Co_open_CSAdEvent;

typedef void (^Co_open_CSAdLoadCompleteBlock)(Co_open_CSAdLoadStatus adLoadStatus);

@class Co_open_CSAdSetupParamsMaker;
@class Co_open_CSAdSetupParams;

typedef Co_open_CSAdSetupParamsMaker *(^Co_open_CSAdStringInit)(NSString *);
typedef Co_open_CSAdSetupParamsMaker *(^Co_open_CSAdBoolInit)(BOOL);
typedef Co_open_CSAdSetupParamsMaker *(^Co_open_CSAdIntegerInit)(NSInteger);
typedef Co_open_CSAdSetupParamsMaker *(^Co_open_CSAdLongInit)(long);
typedef Co_open_CSAdSetupParamsMaker *(^Co_open_CSAdArrayInit)(NSArray *);
typedef Co_open_CSAdSetupParams *(^Co_open_CSAdMakeInit)(void);


@class Co_open_CSAdDataModel;
typedef void (^Co_open_CSAdRequestCompleteBlock)(NSMutableArray<Co_open_CSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^Co_open_CSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^Co_open_CSAdPreloadCompleteBlock)(Co_open_CSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
