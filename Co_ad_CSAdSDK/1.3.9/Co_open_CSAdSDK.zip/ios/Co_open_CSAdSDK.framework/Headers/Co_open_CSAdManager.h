//
//  Co_open_CSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Co_open_CSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface Co_open_CSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)co_open_loadAd:(NSString *)moduleId delegate:(id<Co_open_CSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)co_open_removeData:(id)obj;

@end

NS_ASSUME_NONNULL_END
