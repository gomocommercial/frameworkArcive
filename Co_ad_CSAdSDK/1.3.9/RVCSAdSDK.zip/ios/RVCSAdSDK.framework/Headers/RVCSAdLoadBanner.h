//
//  RVCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "RVCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface RVCSAdLoadBanner : RVCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
