//
//  RVCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define rVkAdvDataSourceFacebook   2 //FB 广告数据源
#define rVkAdvDataSourceAdmob      8 //Admob 广告数据源
#define rVkAdvDataSourceMopub      39//Mopub 广告数据源
#define rVkAdvDataSourceApplovin   20//applovin 广告数据源

#define rVkAdvDataSourceGDT        62//广点通 广告数据源
#define rVkAdvDataSourceBaidu      63//百度 广告数据源
#define rVkAdvDataSourceBU         64//头条 广告数据源
#define rVkAdvDataSourceABU         70//头条聚合 广告数据源


#define rVkOnlineAdvTypeBanner                   1  //banner
#define rVkOnlineAdvTypeInterstitial             2  //全屏
#define rVkOnlineAdvTypeNative                   3 //native
#define rVkOnlineAdvTypeVideo                    4 //视频
#define rVkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define rVkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define rVkOnlineAdvTypeOpen                     8 //开屏
#define rVkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define rVkAdServerConfigError  -1 //服务器返回数据不正确
#define rVkAdLoadConfigFailed  -2 //广告加载失败


#define rVAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define rVkCSAdInstallDays @"rVkCSAdInstallDays"
#define rVkCSAdModule_key @"rVkCSAdModule_key_%@"
#define rVkCSAdInstallTime @"rVkCSAdInstallTime"
#define rVkCSAdLastGetServerTime @"rVkCSAdLastRequestTime"
#define rVkCSAdloadTime 30

#define rVkCSLoadAdTimeOutNotification @"rVKCSLoadAdTimeOutNotification"
#define rVkCSLoadAdTimeOutNotificationKey @"rVKCSLoadAdTimeOutKey"

