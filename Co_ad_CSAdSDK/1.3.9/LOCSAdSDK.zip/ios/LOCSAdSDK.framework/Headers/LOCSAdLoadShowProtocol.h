//
//  LOCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LOCSAdTypedef.h"

@class LOCSAdLoadBase;

@protocol LOCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LOCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lOonAdShowed:(LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)lOonAdClicked:(LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lOonAdClosed:(LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lOonAdVideoCompletePlaying:(LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)lOonAdShowFail:(LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lOonAdOtherEvent:(LOCSAdLoadBase<LOCSAdLoadProtocol> *)adload event:(LOCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
