//
//  LOCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "LOCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdLoadBanner : LOCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
