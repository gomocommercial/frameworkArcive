//
//  LDCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "LDCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LDCSAdLoadBanner : LDCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
