//
//  LDCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lDkAdvDataSourceFacebook   2 //FB 广告数据源
#define lDkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lDkAdvDataSourceMopub      39//Mopub 广告数据源
#define lDkAdvDataSourceApplovin   20//applovin 广告数据源

#define lDkAdvDataSourceGDT        62//广点通 广告数据源
#define lDkAdvDataSourceBaidu      63//百度 广告数据源
#define lDkAdvDataSourceBU         64//头条 广告数据源
#define lDkAdvDataSourceABU         70//头条聚合 广告数据源


#define lDkOnlineAdvTypeBanner                   1  //banner
#define lDkOnlineAdvTypeInterstitial             2  //全屏
#define lDkOnlineAdvTypeNative                   3 //native
#define lDkOnlineAdvTypeVideo                    4 //视频
#define lDkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define lDkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define lDkOnlineAdvTypeOpen                     8 //开屏
#define lDkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define lDkAdServerConfigError  -1 //服务器返回数据不正确
#define lDkAdLoadConfigFailed  -2 //广告加载失败


#define lDAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lDkCSAdInstallDays @"lDkCSAdInstallDays"
#define lDkCSAdModule_key @"lDkCSAdModule_key_%@"
#define lDkCSAdInstallTime @"lDkCSAdInstallTime"
#define lDkCSAdLastGetServerTime @"lDkCSAdLastRequestTime"
#define lDkCSAdloadTime 30

#define lDkCSLoadAdTimeOutNotification @"lDKCSLoadAdTimeOutNotification"
#define lDkCSLoadAdTimeOutNotificationKey @"lDKCSLoadAdTimeOutKey"

