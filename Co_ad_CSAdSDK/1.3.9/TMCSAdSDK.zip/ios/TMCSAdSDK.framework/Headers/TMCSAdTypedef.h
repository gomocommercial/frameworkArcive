//
//  TMCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TMCSAdLoadSuccess = 1,
    TMCSAdLoadFailure = -1,
    TMCSAdLoadTimeout = -2
} TMCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TMCSAdPreloadSuccess = 1,
    //预加载失败
    TMCSAdPreloadFailure = -1,
    //重复加载
    TMCSAdPreloadRepeat = -2,
} TMCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TMCSAdWillAppear,//即将出现
    TMCSAdDidAppear,//已经出现
    TMCSAdWillDisappear,//即将消失
    TMCSAdDidDisappear,//已经消失
    TMCSAdMuted,//静音广告
    TMCSAdWillLeaveApplication,//将要离开App

    TMCSAdVideoStart,//开始播放 常用于video
    TMCSAdVideoComplete,//播放完成 常用于video
    TMCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TMCSAdVideoServerFail,//连接服务器成功，常用于fb video

    TMCSAdNativeDidDownload,//下载完成 常用于fb Native
    TMCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TMCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    TMCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    TMCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    TMCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    TMCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    TMCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    TMCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    TMCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    TMCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    TMCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    TMCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    TMCSAdDidPresentFullScreen,//插屏弹出全屏广告
    TMCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    TMCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    TMCSAdPlayerStatusStarted,//开始播放
    TMCSAdPlayerStatusPaused,//用户行为导致暂停
    TMCSAdPlayerStatusStoped,//播放停止
    TMCSAdPlayerStatusError,//播放出错
    TMCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    TMCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    TMCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    TMCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    TMCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    TMCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    TMCSAdRecordImpression, //广告曝光已记录
    TMCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    TMCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    TMCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    TMCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    TMCSAdABUOpenWillPresentFullScreen,
    TMCSAdABUOpenDidShowFailed,
    TMCSAdABUOpenWillDissmissFullScreen,
    TMCSAdABUOpenCountdownToZero,
    
    TMCSAdABUBannerWillPresentFullScreen,
    TMCSAdABUBannerWillDismissFullScreen,
    
    TMCSAdABURewardDidLoad,
    TMCSAdABURewardRenderFail,
    TMCSAdABURewardDidShowFailed,

} TMCSAdEvent;

typedef void (^TMCSAdLoadCompleteBlock)(TMCSAdLoadStatus adLoadStatus);

@class TMCSAdSetupParamsMaker;
@class TMCSAdSetupParams;

typedef TMCSAdSetupParamsMaker *(^TMCSAdStringInit)(NSString *);
typedef TMCSAdSetupParamsMaker *(^TMCSAdBoolInit)(BOOL);
typedef TMCSAdSetupParamsMaker *(^TMCSAdIntegerInit)(NSInteger);
typedef TMCSAdSetupParamsMaker *(^TMCSAdLongInit)(long);
typedef TMCSAdSetupParamsMaker *(^TMCSAdArrayInit)(NSArray *);
typedef TMCSAdSetupParams *(^TMCSAdMakeInit)(void);


@class TMCSAdDataModel;
typedef void (^TMCSAdRequestCompleteBlock)(NSMutableArray<TMCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TMCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TMCSAdPreloadCompleteBlock)(TMCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
