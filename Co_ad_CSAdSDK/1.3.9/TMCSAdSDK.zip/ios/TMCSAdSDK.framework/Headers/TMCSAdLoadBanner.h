//
//  TMCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "TMCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMCSAdLoadBanner : TMCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
