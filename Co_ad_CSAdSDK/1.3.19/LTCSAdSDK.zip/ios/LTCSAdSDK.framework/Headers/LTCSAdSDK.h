//
//  LTCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "LTCSAdLoadBase.h"
#import "LTCSAdDataModel.h"
#import "LTCSAdLoadProtocol.h"
#import "LTCSAdLoadDataProtocol.h"
#import "LTCSAdLoadShowProtocol.h"
#import "LTCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface LTCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)lTsetupByBlock:(void (^ _Nonnull)(LTCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)lTloadAd:(NSString *)moduleId delegate:(id<LTCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)lTadShowStatistic:(LTCSAdDataModel *)dataModel adload:(nonnull LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)lTadClickStatistic:(LTCSAdDataModel *)dataModel adload:(nonnull LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)lTaddCustomFecher:(Class<LTCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
