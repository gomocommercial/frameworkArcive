//
//  LTCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    LTCSAdLoadSuccess = 1,
    LTCSAdLoadFailure = -1,
    LTCSAdLoadTimeout = -2
} LTCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    LTCSAdPreloadSuccess = 1,
    //预加载失败
    LTCSAdPreloadFailure = -1,
    //重复加载
    LTCSAdPreloadRepeat = -2,
} LTCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    LTCSAdWillAppear,//即将出现
    LTCSAdDidAppear,//已经出现
    LTCSAdWillDisappear,//即将消失
    LTCSAdDidDisappear,//已经消失
    LTCSAdMuted,//静音广告
    LTCSAdWillLeaveApplication,//将要离开App

    LTCSAdVideoStart,//开始播放 常用于video
    LTCSAdVideoComplete,//播放完成 常用于video
    LTCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    LTCSAdVideoServerFail,//连接服务器成功，常用于fb video

    LTCSAdNativeDidDownload,//下载完成 常用于fb Native
    LTCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    LTCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    LTCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    LTCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    LTCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    LTCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    LTCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    LTCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    LTCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    LTCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    LTCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    LTCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    LTCSAdDidPresentFullScreen,//插屏弹出全屏广告
    LTCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    LTCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    LTCSAdPlayerStatusStarted,//开始播放
    LTCSAdPlayerStatusPaused,//用户行为导致暂停
    LTCSAdPlayerStatusStoped,//播放停止
    LTCSAdPlayerStatusError,//播放出错
    LTCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    LTCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    LTCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    LTCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    LTCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    LTCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    LTCSAdRecordImpression, //广告曝光已记录
    LTCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    LTCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    LTCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    LTCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    LTCSAdABUOpenWillPresentFullScreen,
    LTCSAdABUOpenDidShowFailed,
    LTCSAdABUOpenWillDissmissFullScreen,
    LTCSAdABUOpenCountdownToZero,
    
    LTCSAdABUBannerWillPresentFullScreen,
    LTCSAdABUBannerWillDismissFullScreen,
    
    LTCSAdABURewardDidLoad,
    LTCSAdABURewardRenderFail,
    LTCSAdABURewardDidShowFailed,

} LTCSAdEvent;

typedef void (^LTCSAdLoadCompleteBlock)(LTCSAdLoadStatus adLoadStatus);

@class LTCSAdSetupParamsMaker;
@class LTCSAdSetupParams;

typedef LTCSAdSetupParamsMaker *(^LTCSAdStringInit)(NSString *);
typedef LTCSAdSetupParamsMaker *(^LTCSAdBoolInit)(BOOL);
typedef LTCSAdSetupParamsMaker *(^LTCSAdIntegerInit)(NSInteger);
typedef LTCSAdSetupParamsMaker *(^LTCSAdLongInit)(long);
typedef LTCSAdSetupParamsMaker *(^LTCSAdArrayInit)(NSArray *);
typedef LTCSAdSetupParams *(^LTCSAdMakeInit)(void);


@class LTCSAdDataModel;
typedef void (^LTCSAdRequestCompleteBlock)(NSMutableArray<LTCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^LTCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^LTCSAdPreloadCompleteBlock)(LTCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
