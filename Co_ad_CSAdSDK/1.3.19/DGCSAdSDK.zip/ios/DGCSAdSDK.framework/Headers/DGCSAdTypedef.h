//
//  DGCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    DGCSAdLoadSuccess = 1,
    DGCSAdLoadFailure = -1,
    DGCSAdLoadTimeout = -2
} DGCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    DGCSAdPreloadSuccess = 1,
    //预加载失败
    DGCSAdPreloadFailure = -1,
    //重复加载
    DGCSAdPreloadRepeat = -2,
} DGCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    DGCSAdWillAppear,//即将出现
    DGCSAdDidAppear,//已经出现
    DGCSAdWillDisappear,//即将消失
    DGCSAdDidDisappear,//已经消失
    DGCSAdMuted,//静音广告
    DGCSAdWillLeaveApplication,//将要离开App

    DGCSAdVideoStart,//开始播放 常用于video
    DGCSAdVideoComplete,//播放完成 常用于video
    DGCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    DGCSAdVideoServerFail,//连接服务器成功，常用于fb video

    DGCSAdNativeDidDownload,//下载完成 常用于fb Native
    DGCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    DGCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    DGCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    DGCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    DGCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    DGCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    DGCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    DGCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    DGCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    DGCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    DGCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    DGCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    DGCSAdDidPresentFullScreen,//插屏弹出全屏广告
    DGCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    DGCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    DGCSAdPlayerStatusStarted,//开始播放
    DGCSAdPlayerStatusPaused,//用户行为导致暂停
    DGCSAdPlayerStatusStoped,//播放停止
    DGCSAdPlayerStatusError,//播放出错
    DGCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    DGCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    DGCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    DGCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    DGCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    DGCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    DGCSAdRecordImpression, //广告曝光已记录
    DGCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    DGCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    DGCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    DGCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    DGCSAdABUOpenWillPresentFullScreen,
    DGCSAdABUOpenDidShowFailed,
    DGCSAdABUOpenWillDissmissFullScreen,
    DGCSAdABUOpenCountdownToZero,
    
    DGCSAdABUBannerWillPresentFullScreen,
    DGCSAdABUBannerWillDismissFullScreen,
    
    DGCSAdABURewardDidLoad,
    DGCSAdABURewardRenderFail,
    DGCSAdABURewardDidShowFailed,

} DGCSAdEvent;

typedef void (^DGCSAdLoadCompleteBlock)(DGCSAdLoadStatus adLoadStatus);

@class DGCSAdSetupParamsMaker;
@class DGCSAdSetupParams;

typedef DGCSAdSetupParamsMaker *(^DGCSAdStringInit)(NSString *);
typedef DGCSAdSetupParamsMaker *(^DGCSAdBoolInit)(BOOL);
typedef DGCSAdSetupParamsMaker *(^DGCSAdIntegerInit)(NSInteger);
typedef DGCSAdSetupParamsMaker *(^DGCSAdLongInit)(long);
typedef DGCSAdSetupParamsMaker *(^DGCSAdArrayInit)(NSArray *);
typedef DGCSAdSetupParams *(^DGCSAdMakeInit)(void);


@class DGCSAdDataModel;
typedef void (^DGCSAdRequestCompleteBlock)(NSMutableArray<DGCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^DGCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^DGCSAdPreloadCompleteBlock)(DGCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
