//
//  DGCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define dGkAdvDataSourceFacebook   2 //FB 广告数据源
#define dGkAdvDataSourceAdmob      8 //Admob 广告数据源
#define dGkAdvDataSourceMopub      39//Mopub 广告数据源
#define dGkAdvDataSourceApplovin   20//applovin 广告数据源

#define dGkAdvDataSourceGDT        62//广点通 广告数据源
#define dGkAdvDataSourceBaidu      63//百度 广告数据源
#define dGkAdvDataSourceBU         64//头条 广告数据源
#define dGkAdvDataSourceABU         70//头条聚合 广告数据源
#define dGkAdvDataSourceBUGlobal   73//海外头条 广告数据源

#define dGkOnlineAdvTypeBanner                   1  //banner
#define dGkOnlineAdvTypeInterstitial             2  //全屏
#define dGkOnlineAdvTypeNative                   3 //native
#define dGkOnlineAdvTypeVideo                    4 //视频
#define dGkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define dGkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define dGkOnlineAdvTypeOpen                     8 //开屏
#define dGkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define dGkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define dGkAdServerConfigError  -1 //服务器返回数据不正确
#define dGkAdLoadConfigFailed  -2 //广告加载失败


#define dGAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define dGkCSAdInstallDays @"dGkCSAdInstallDays"
#define dGkCSAdModule_key @"dGkCSAdModule_key_%@"
#define dGkCSNewAdModule_key @"dGkCSNewAdModule_key_%@"
#define dGkCSAdInstallTime @"dGkCSAdInstallTime"
#define dGkCSAdInstallHours @"dGkCSAdInstallHours"
#define dGkCSAdLastGetServerTime @"dGkCSAdLastRequestTime"
#define dGkCSAdloadTime 30

#define dGkCSLoadAdTimeOutNotification @"dGKCSLoadAdTimeOutNotification"
#define dGkCSLoadAdTimeOutNotificationKey @"dGKCSLoadAdTimeOutKey"

