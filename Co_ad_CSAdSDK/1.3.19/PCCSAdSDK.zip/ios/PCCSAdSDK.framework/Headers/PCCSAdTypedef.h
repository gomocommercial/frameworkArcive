//
//  PCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PCCSAdLoadSuccess = 1,
    PCCSAdLoadFailure = -1,
    PCCSAdLoadTimeout = -2
} PCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PCCSAdPreloadSuccess = 1,
    //预加载失败
    PCCSAdPreloadFailure = -1,
    //重复加载
    PCCSAdPreloadRepeat = -2,
} PCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PCCSAdWillAppear,//即将出现
    PCCSAdDidAppear,//已经出现
    PCCSAdWillDisappear,//即将消失
    PCCSAdDidDisappear,//已经消失
    PCCSAdMuted,//静音广告
    PCCSAdWillLeaveApplication,//将要离开App

    PCCSAdVideoStart,//开始播放 常用于video
    PCCSAdVideoComplete,//播放完成 常用于video
    PCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PCCSAdNativeDidDownload,//下载完成 常用于fb Native
    PCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    PCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PCCSAdPlayerStatusStarted,//开始播放
    PCCSAdPlayerStatusPaused,//用户行为导致暂停
    PCCSAdPlayerStatusStoped,//播放停止
    PCCSAdPlayerStatusError,//播放出错
    PCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PCCSAdRecordImpression, //广告曝光已记录
    PCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PCCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PCCSAdABUOpenWillPresentFullScreen,
    PCCSAdABUOpenDidShowFailed,
    PCCSAdABUOpenWillDissmissFullScreen,
    PCCSAdABUOpenCountdownToZero,
    
    PCCSAdABUBannerWillPresentFullScreen,
    PCCSAdABUBannerWillDismissFullScreen,
    
    PCCSAdABURewardDidLoad,
    PCCSAdABURewardRenderFail,
    PCCSAdABURewardDidShowFailed,

} PCCSAdEvent;

typedef void (^PCCSAdLoadCompleteBlock)(PCCSAdLoadStatus adLoadStatus);

@class PCCSAdSetupParamsMaker;
@class PCCSAdSetupParams;

typedef PCCSAdSetupParamsMaker *(^PCCSAdStringInit)(NSString *);
typedef PCCSAdSetupParamsMaker *(^PCCSAdBoolInit)(BOOL);
typedef PCCSAdSetupParamsMaker *(^PCCSAdIntegerInit)(NSInteger);
typedef PCCSAdSetupParamsMaker *(^PCCSAdLongInit)(long);
typedef PCCSAdSetupParamsMaker *(^PCCSAdArrayInit)(NSArray *);
typedef PCCSAdSetupParams *(^PCCSAdMakeInit)(void);


@class PCCSAdDataModel;
typedef void (^PCCSAdRequestCompleteBlock)(NSMutableArray<PCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PCCSAdPreloadCompleteBlock)(PCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
