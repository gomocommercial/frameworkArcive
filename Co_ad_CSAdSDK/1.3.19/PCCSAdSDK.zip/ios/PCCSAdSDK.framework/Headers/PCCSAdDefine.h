//
//  PCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pCkAdvDataSourceFacebook   2 //FB 广告数据源
#define pCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pCkAdvDataSourceMopub      39//Mopub 广告数据源
#define pCkAdvDataSourceApplovin   20//applovin 广告数据源

#define pCkAdvDataSourceGDT        62//广点通 广告数据源
#define pCkAdvDataSourceBaidu      63//百度 广告数据源
#define pCkAdvDataSourceBU         64//头条 广告数据源
#define pCkAdvDataSourceABU         70//头条聚合 广告数据源
#define pCkAdvDataSourceBUGlobal   73//海外头条 广告数据源

#define pCkOnlineAdvTypeBanner                   1  //banner
#define pCkOnlineAdvTypeInterstitial             2  //全屏
#define pCkOnlineAdvTypeNative                   3 //native
#define pCkOnlineAdvTypeVideo                    4 //视频
#define pCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pCkOnlineAdvTypeOpen                     8 //开屏
#define pCkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define pCkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pCkAdServerConfigError  -1 //服务器返回数据不正确
#define pCkAdLoadConfigFailed  -2 //广告加载失败


#define pCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pCkCSAdInstallDays @"pCkCSAdInstallDays"
#define pCkCSAdModule_key @"pCkCSAdModule_key_%@"
#define pCkCSNewAdModule_key @"pCkCSNewAdModule_key_%@"
#define pCkCSAdInstallTime @"pCkCSAdInstallTime"
#define pCkCSAdInstallHours @"pCkCSAdInstallHours"
#define pCkCSAdLastGetServerTime @"pCkCSAdLastRequestTime"
#define pCkCSAdloadTime 30

#define pCkCSLoadAdTimeOutNotification @"pCKCSLoadAdTimeOutNotification"
#define pCkCSLoadAdTimeOutNotificationKey @"pCKCSLoadAdTimeOutKey"

