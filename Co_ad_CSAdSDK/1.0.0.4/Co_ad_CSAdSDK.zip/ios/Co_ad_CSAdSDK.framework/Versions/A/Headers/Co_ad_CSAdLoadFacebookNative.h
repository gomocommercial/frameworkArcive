//
//  Co_ad_CSAdLoadFacebookNative.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import "Co_ad_CSAdLoadNative.h"
#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import "Co_ad_CSAdLoadProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdLoadFacebookNative : Co_ad_CSAdLoadNative<Co_ad_CSAdLoadProtocol,FBNativeAdDelegate>

@property(strong, nonatomic) FBNativeAd *ad;

@end

NS_ASSUME_NONNULL_END
