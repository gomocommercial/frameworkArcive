//
//  ZKCSAdLoadDataProtocol.h
//  ZKCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "ZKCSAdTypedef.h"

@class ZKCSAdDataModel;
@class ZKCSAdLoadBase;

@protocol ZKCSAdLoadProtocol;

@protocol ZKCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)zKonAdInfoFinish:(ZKCSAdLoadBase<ZKCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)zKonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)zKonAdFail:(ZKCSAdLoadBase<ZKCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
