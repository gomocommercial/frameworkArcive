//
//  ZKCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    ZKCSAdLoadSuccess = 1,
    ZKCSAdLoadFailure = -1,
    ZKCSAdLoadTimeout = -2
} ZKCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    ZKCSAdPreloadSuccess = 1,
    //预加载失败
    ZKCSAdPreloadFailure = -1,
    //重复加载
    ZKCSAdPreloadRepeat = -2,
} ZKCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    ZKCSAdWillAppear,//即将出现
    ZKCSAdDidAppear,//已经出现
    ZKCSAdWillDisappear,//即将消失
    ZKCSAdDidDisappear,//已经消失
    ZKCSAdMuted,//静音广告
    ZKCSAdWillLeaveApplication,//将要离开App

    ZKCSAdVideoStart,//开始播放 常用于video
    ZKCSAdVideoComplete,//播放完成 常用于video
    ZKCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    ZKCSAdVideoServerFail,//连接服务器成功，常用于fb video

    ZKCSAdNativeDidDownload,//下载完成 常用于fb Native
    ZKCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    ZKCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    ZKCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    ZKCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    ZKCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    ZKCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    ZKCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    ZKCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    ZKCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    ZKCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    ZKCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    ZKCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    ZKCSAdDidPresentFullScreen,//插屏弹出全屏广告
    ZKCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    ZKCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    ZKCSAdPlayerStatusStarted,//开始播放
    ZKCSAdPlayerStatusPaused,//用户行为导致暂停
    ZKCSAdPlayerStatusStoped,//播放停止
    ZKCSAdPlayerStatusError,//播放出错
    ZKCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    ZKCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    ZKCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    ZKCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    ZKCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    ZKCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    ZKCSAdRecordImpression, //广告曝光已记录
    ZKCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    ZKCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    ZKCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开

} ZKCSAdEvent;

typedef void (^ZKCSAdLoadCompleteBlock)(ZKCSAdLoadStatus adLoadStatus);

@class ZKCSAdSetupParamsMaker;
@class ZKCSAdSetupParams;

typedef ZKCSAdSetupParamsMaker *(^ZKCSAdStringInit)(NSString *);
typedef ZKCSAdSetupParamsMaker *(^ZKCSAdBoolInit)(BOOL);
typedef ZKCSAdSetupParamsMaker *(^ZKCSAdIntegerInit)(NSInteger);
typedef ZKCSAdSetupParamsMaker *(^ZKCSAdLongInit)(long);
typedef ZKCSAdSetupParamsMaker *(^ZKCSAdArrayInit)(NSArray *);
typedef ZKCSAdSetupParams *(^ZKCSAdMakeInit)(void);


@class ZKCSAdDataModel;
typedef void (^ZKCSAdRequestCompleteBlock)(NSMutableArray<ZKCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^ZKCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^ZKCSAdPreloadCompleteBlock)(ZKCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
