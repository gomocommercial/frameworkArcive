//
//  ZKCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define zKkAdvDataSourceFacebook   2 //FB 广告数据源
#define zKkAdvDataSourceAdmob      8 //Admob 广告数据源
#define zKkAdvDataSourceMopub      39//Mopub 广告数据源
#define zKkAdvDataSourceApplovin   20//applovin 广告数据源

#define zKkAdvDataSourceGDT        62//广点通 广告数据源
#define zKkAdvDataSourceBaidu      63//百度 广告数据源
#define zKkAdvDataSourceBU         64//头条 广告数据源


#define zKkOnlineAdvTypeBanner                   1  //banner
#define zKkOnlineAdvTypeInterstitial             2  //全屏
#define zKkOnlineAdvTypeNative                   3 //native
#define zKkOnlineAdvTypeVideo                    4 //视频
#define zKkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define zKkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define zKkOnlineAdvTypeOpen                     8 //开屏
#define zKkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define zKkAdServerConfigError  -1 //服务器返回数据不正确
#define zKkAdLoadConfigFailed  -2 //广告加载失败


#define zKAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define zKkCSAdInstallDays @"zKkCSAdInstallDays"
#define zKkCSAdModule_key @"zKkCSAdModule_key_%@"
#define zKkCSAdInstallTime @"zKkCSAdInstallTime"
#define zKkCSAdLastGetServerTime @"zKkCSAdLastRequestTime"
#define zKkCSAdloadTime 30

#define zKkCSLoadAdTimeOutNotification @"zKKCSLoadAdTimeOutNotification"
#define zKkCSLoadAdTimeOutNotificationKey @"zKKCSLoadAdTimeOutKey"

