//
//  ZKCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "ZKCSAdTypedef.h"

@class ZKCSAdLoadBase;

@protocol ZKCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol ZKCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)zKonAdShowed:(ZKCSAdLoadBase<ZKCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)zKonAdClicked:(ZKCSAdLoadBase<ZKCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)zKonAdClosed:(ZKCSAdLoadBase<ZKCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)zKonAdVideoCompletePlaying:(ZKCSAdLoadBase<ZKCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)zKonAdShowFail:(ZKCSAdLoadBase<ZKCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)zKonAdOtherEvent:(ZKCSAdLoadBase<ZKCSAdLoadProtocol> *)adload event:(ZKCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
