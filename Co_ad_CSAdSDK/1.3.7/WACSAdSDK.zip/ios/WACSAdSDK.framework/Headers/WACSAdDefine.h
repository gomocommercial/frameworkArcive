//
//  WACSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define wAkAdvDataSourceFacebook   2 //FB 广告数据源
#define wAkAdvDataSourceAdmob      8 //Admob 广告数据源
#define wAkAdvDataSourceMopub      39//Mopub 广告数据源
#define wAkAdvDataSourceApplovin   20//applovin 广告数据源

#define wAkAdvDataSourceGDT        62//广点通 广告数据源
#define wAkAdvDataSourceBaidu      63//百度 广告数据源
#define wAkAdvDataSourceBU         64//头条 广告数据源


#define wAkOnlineAdvTypeBanner                   1  //banner
#define wAkOnlineAdvTypeInterstitial             2  //全屏
#define wAkOnlineAdvTypeNative                   3 //native
#define wAkOnlineAdvTypeVideo                    4 //视频
#define wAkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define wAkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define wAkOnlineAdvTypeOpen                     8 //开屏
#define wAkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define wAkAdServerConfigError  -1 //服务器返回数据不正确
#define wAkAdLoadConfigFailed  -2 //广告加载失败


#define wAAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define wAkCSAdInstallDays @"wAkCSAdInstallDays"
#define wAkCSAdModule_key @"wAkCSAdModule_key_%@"
#define wAkCSAdInstallTime @"wAkCSAdInstallTime"
#define wAkCSAdLastGetServerTime @"wAkCSAdLastRequestTime"
#define wAkCSAdloadTime 30

#define wAkCSLoadAdTimeOutNotification @"wAKCSLoadAdTimeOutNotification"
#define wAkCSLoadAdTimeOutNotificationKey @"wAKCSLoadAdTimeOutKey"

