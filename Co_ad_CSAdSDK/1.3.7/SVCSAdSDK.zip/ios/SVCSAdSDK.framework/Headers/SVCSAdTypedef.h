//
//  SVCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    SVCSAdLoadSuccess = 1,
    SVCSAdLoadFailure = -1,
    SVCSAdLoadTimeout = -2
} SVCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    SVCSAdPreloadSuccess = 1,
    //预加载失败
    SVCSAdPreloadFailure = -1,
    //重复加载
    SVCSAdPreloadRepeat = -2,
} SVCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    SVCSAdWillAppear,//即将出现
    SVCSAdDidAppear,//已经出现
    SVCSAdWillDisappear,//即将消失
    SVCSAdDidDisappear,//已经消失
    SVCSAdMuted,//静音广告
    SVCSAdWillLeaveApplication,//将要离开App

    SVCSAdVideoStart,//开始播放 常用于video
    SVCSAdVideoComplete,//播放完成 常用于video
    SVCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    SVCSAdVideoServerFail,//连接服务器成功，常用于fb video

    SVCSAdNativeDidDownload,//下载完成 常用于fb Native
    SVCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    SVCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    SVCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    SVCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    SVCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    SVCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    SVCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    SVCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    SVCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    SVCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    SVCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    SVCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    SVCSAdDidPresentFullScreen,//插屏弹出全屏广告
    SVCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    SVCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    SVCSAdPlayerStatusStarted,//开始播放
    SVCSAdPlayerStatusPaused,//用户行为导致暂停
    SVCSAdPlayerStatusStoped,//播放停止
    SVCSAdPlayerStatusError,//播放出错
    SVCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    SVCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    SVCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    SVCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    SVCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    SVCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    SVCSAdRecordImpression, //广告曝光已记录
    SVCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    SVCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    SVCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开

} SVCSAdEvent;

typedef void (^SVCSAdLoadCompleteBlock)(SVCSAdLoadStatus adLoadStatus);

@class SVCSAdSetupParamsMaker;
@class SVCSAdSetupParams;

typedef SVCSAdSetupParamsMaker *(^SVCSAdStringInit)(NSString *);
typedef SVCSAdSetupParamsMaker *(^SVCSAdBoolInit)(BOOL);
typedef SVCSAdSetupParamsMaker *(^SVCSAdIntegerInit)(NSInteger);
typedef SVCSAdSetupParamsMaker *(^SVCSAdLongInit)(long);
typedef SVCSAdSetupParamsMaker *(^SVCSAdArrayInit)(NSArray *);
typedef SVCSAdSetupParams *(^SVCSAdMakeInit)(void);


@class SVCSAdDataModel;
typedef void (^SVCSAdRequestCompleteBlock)(NSMutableArray<SVCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^SVCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^SVCSAdPreloadCompleteBlock)(SVCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
