//
//  SVCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "SVCSAdLoadBase.h"
#import "SVCSAdDataModel.h"
#import "SVCSAdLoadProtocol.h"
#import "SVCSAdLoadDataProtocol.h"
#import "SVCSAdLoadShowProtocol.h"
#import "SVCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface SVCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)sVsetupByBlock:(void (^ _Nonnull)(SVCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)sVloadAd:(NSString *)moduleId delegate:(id<SVCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)sVadShowStatistic:(SVCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)sVadClickStatistic:(SVCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)sVaddCustomFecher:(Class<SVCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
