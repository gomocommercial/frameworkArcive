//
//  DCCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "DCCSAdLoadBase.h"
#import "DCCSAdDataModel.h"
#import "DCCSAdLoadProtocol.h"
#import "DCCSAdLoadDataProtocol.h"
#import "DCCSAdLoadShowProtocol.h"
#import "DCCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)dCsetupByBlock:(void (^ _Nonnull)(DCCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)dCloadAd:(NSString *)moduleId delegate:(id<DCCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)dCadShowStatistic:(DCCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)dCadClickStatistic:(DCCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)dCaddCustomFecher:(Class<DCCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
