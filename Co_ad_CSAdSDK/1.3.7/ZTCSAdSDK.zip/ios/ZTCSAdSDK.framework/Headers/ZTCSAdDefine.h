//
//  ZTCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define zTkAdvDataSourceFacebook   2 //FB 广告数据源
#define zTkAdvDataSourceAdmob      8 //Admob 广告数据源
#define zTkAdvDataSourceMopub      39//Mopub 广告数据源
#define zTkAdvDataSourceApplovin   20//applovin 广告数据源

#define zTkAdvDataSourceGDT        62//广点通 广告数据源
#define zTkAdvDataSourceBaidu      63//百度 广告数据源
#define zTkAdvDataSourceBU         64//头条 广告数据源


#define zTkOnlineAdvTypeBanner                   1  //banner
#define zTkOnlineAdvTypeInterstitial             2  //全屏
#define zTkOnlineAdvTypeNative                   3 //native
#define zTkOnlineAdvTypeVideo                    4 //视频
#define zTkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define zTkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define zTkOnlineAdvTypeOpen                     8 //开屏
#define zTkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define zTkAdServerConfigError  -1 //服务器返回数据不正确
#define zTkAdLoadConfigFailed  -2 //广告加载失败


#define zTAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define zTkCSAdInstallDays @"zTkCSAdInstallDays"
#define zTkCSAdModule_key @"zTkCSAdModule_key_%@"
#define zTkCSAdInstallTime @"zTkCSAdInstallTime"
#define zTkCSAdLastGetServerTime @"zTkCSAdLastRequestTime"
#define zTkCSAdloadTime 30

#define zTkCSLoadAdTimeOutNotification @"zTKCSLoadAdTimeOutNotification"
#define zTkCSLoadAdTimeOutNotificationKey @"zTKCSLoadAdTimeOutKey"

