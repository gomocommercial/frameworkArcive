//
//  ZTCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "ZTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZTCSAdLoadBanner : ZTCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
