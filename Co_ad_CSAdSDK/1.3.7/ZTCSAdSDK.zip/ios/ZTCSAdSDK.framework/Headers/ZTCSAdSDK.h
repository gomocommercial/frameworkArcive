//
//  ZTCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "ZTCSAdLoadBase.h"
#import "ZTCSAdDataModel.h"
#import "ZTCSAdLoadProtocol.h"
#import "ZTCSAdLoadDataProtocol.h"
#import "ZTCSAdLoadShowProtocol.h"
#import "ZTCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZTCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)zTsetupByBlock:(void (^ _Nonnull)(ZTCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)zTloadAd:(NSString *)moduleId delegate:(id<ZTCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)zTadShowStatistic:(ZTCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)zTadClickStatistic:(ZTCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)zTaddCustomFecher:(Class<ZTCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
