//
//  ZTCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "ZTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZTCSAdLoadInterstitial : ZTCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
