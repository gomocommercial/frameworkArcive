//
//  Co_open_CSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "Co_open_CSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_open_CSAdLoadInterstitial : Co_open_CSAdLoadBase


@end

NS_ASSUME_NONNULL_END
