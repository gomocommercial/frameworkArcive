//
//  Co_open_CSAdLoadDataProtocol.h
//  Co_open_CSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "Co_open_CSAdTypedef.h"

@class Co_open_CSAdDataModel;
@class Co_open_CSAdLoadBase;

@protocol Co_open_CSAdLoadProtocol;

@protocol Co_open_CSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)co_open_onAdInfoFinish:(Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)co_open_onLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)co_open_onAdFail:(Co_open_CSAdLoadBase<Co_open_CSAdLoadProtocol> *)adload error:(NSError *)error;
@end
