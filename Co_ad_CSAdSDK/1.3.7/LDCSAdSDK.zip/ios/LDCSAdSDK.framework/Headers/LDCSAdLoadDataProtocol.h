//
//  LDCSAdLoadDataProtocol.h
//  LDCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "LDCSAdTypedef.h"

@class LDCSAdDataModel;
@class LDCSAdLoadBase;

@protocol LDCSAdLoadProtocol;

@protocol LDCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)lDonAdInfoFinish:(LDCSAdLoadBase<LDCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)lDonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)lDonAdFail:(LDCSAdLoadBase<LDCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
