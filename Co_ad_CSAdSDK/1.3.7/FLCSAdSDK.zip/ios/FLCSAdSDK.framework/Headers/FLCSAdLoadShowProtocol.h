//
//  FLCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FLCSAdTypedef.h"

@class FLCSAdLoadBase;

@protocol FLCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FLCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)fLonAdShowed:(FLCSAdLoadBase<FLCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)fLonAdClicked:(FLCSAdLoadBase<FLCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)fLonAdClosed:(FLCSAdLoadBase<FLCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)fLonAdVideoCompletePlaying:(FLCSAdLoadBase<FLCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)fLonAdShowFail:(FLCSAdLoadBase<FLCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)fLonAdOtherEvent:(FLCSAdLoadBase<FLCSAdLoadProtocol> *)adload event:(FLCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
