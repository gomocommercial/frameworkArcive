//
//  FLCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "FLCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FLCSAdLoadBanner : FLCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
