//
//  FaceVCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "FaceVCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FaceVCSAdLoadBanner : FaceVCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
