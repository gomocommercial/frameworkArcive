//
//  TESTIOSCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    TESTIOSCSAdLoadSuccess = 1,
    TESTIOSCSAdLoadFailure = -1,
    TESTIOSCSAdLoadTimeout = -2
} TESTIOSCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    TESTIOSCSAdPreloadSuccess = 1,
    //预加载失败
    TESTIOSCSAdPreloadFailure = -1,
    //重复加载
    TESTIOSCSAdPreloadRepeat = -2,
} TESTIOSCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    TESTIOSCSAdWillAppear,//即将出现
    TESTIOSCSAdDidAppear,//已经出现
    TESTIOSCSAdWillDisappear,//即将消失
    TESTIOSCSAdDidDisappear,//已经消失
    TESTIOSCSAdMuted,//静音广告
    TESTIOSCSAdWillLeaveApplication,//将要离开App

    TESTIOSCSAdVideoStart,//开始播放 常用于video
    TESTIOSCSAdVideoComplete,//播放完成 常用于video
    TESTIOSCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    TESTIOSCSAdVideoServerFail,//连接服务器成功，常用于fb video

    TESTIOSCSAdNativeDidDownload,//下载完成 常用于fb Native
    TESTIOSCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    TESTIOSCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    TESTIOSCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    TESTIOSCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    TESTIOSCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    TESTIOSCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    TESTIOSCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    TESTIOSCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    TESTIOSCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    TESTIOSCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    TESTIOSCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    TESTIOSCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    TESTIOSCSAdDidPresentFullScreen,//插屏弹出全屏广告
    TESTIOSCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    TESTIOSCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    TESTIOSCSAdPlayerStatusStarted,//开始播放
    TESTIOSCSAdPlayerStatusPaused,//用户行为导致暂停
    TESTIOSCSAdPlayerStatusStoped,//播放停止
    TESTIOSCSAdPlayerStatusError,//播放出错
    TESTIOSCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    TESTIOSCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    TESTIOSCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    TESTIOSCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    TESTIOSCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    TESTIOSCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    TESTIOSCSAdRecordImpression, //广告曝光已记录
    TESTIOSCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    TESTIOSCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    TESTIOSCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开

} TESTIOSCSAdEvent;

typedef void (^TESTIOSCSAdLoadCompleteBlock)(TESTIOSCSAdLoadStatus adLoadStatus);

@class TESTIOSCSAdSetupParamsMaker;
@class TESTIOSCSAdSetupParams;

typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdStringInit)(NSString *);
typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdBoolInit)(BOOL);
typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdIntegerInit)(NSInteger);
typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdLongInit)(long);
typedef TESTIOSCSAdSetupParamsMaker *(^TESTIOSCSAdArrayInit)(NSArray *);
typedef TESTIOSCSAdSetupParams *(^TESTIOSCSAdMakeInit)(void);


@class TESTIOSCSAdDataModel;
typedef void (^TESTIOSCSAdRequestCompleteBlock)(NSMutableArray<TESTIOSCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^TESTIOSCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^TESTIOSCSAdPreloadCompleteBlock)(TESTIOSCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
