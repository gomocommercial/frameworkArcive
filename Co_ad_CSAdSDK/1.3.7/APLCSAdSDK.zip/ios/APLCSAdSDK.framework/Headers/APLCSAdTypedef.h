//
//  APLCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    APLCSAdLoadSuccess = 1,
    APLCSAdLoadFailure = -1,
    APLCSAdLoadTimeout = -2
} APLCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    APLCSAdPreloadSuccess = 1,
    //预加载失败
    APLCSAdPreloadFailure = -1,
    //重复加载
    APLCSAdPreloadRepeat = -2,
} APLCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    APLCSAdWillAppear,//即将出现
    APLCSAdDidAppear,//已经出现
    APLCSAdWillDisappear,//即将消失
    APLCSAdDidDisappear,//已经消失
    APLCSAdMuted,//静音广告
    APLCSAdWillLeaveApplication,//将要离开App

    APLCSAdVideoStart,//开始播放 常用于video
    APLCSAdVideoComplete,//播放完成 常用于video
    APLCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    APLCSAdVideoServerFail,//连接服务器成功，常用于fb video

    APLCSAdNativeDidDownload,//下载完成 常用于fb Native
    APLCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    APLCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    APLCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    APLCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    APLCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    APLCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    APLCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    APLCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    APLCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    APLCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    APLCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    APLCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    APLCSAdDidPresentFullScreen,//插屏弹出全屏广告
    APLCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    APLCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    APLCSAdPlayerStatusStarted,//开始播放
    APLCSAdPlayerStatusPaused,//用户行为导致暂停
    APLCSAdPlayerStatusStoped,//播放停止
    APLCSAdPlayerStatusError,//播放出错
    APLCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    APLCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    APLCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    APLCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    APLCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    APLCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    APLCSAdRecordImpression, //广告曝光已记录
    APLCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    APLCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    APLCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开

} APLCSAdEvent;

typedef void (^APLCSAdLoadCompleteBlock)(APLCSAdLoadStatus adLoadStatus);

@class APLCSAdSetupParamsMaker;
@class APLCSAdSetupParams;

typedef APLCSAdSetupParamsMaker *(^APLCSAdStringInit)(NSString *);
typedef APLCSAdSetupParamsMaker *(^APLCSAdBoolInit)(BOOL);
typedef APLCSAdSetupParamsMaker *(^APLCSAdIntegerInit)(NSInteger);
typedef APLCSAdSetupParamsMaker *(^APLCSAdLongInit)(long);
typedef APLCSAdSetupParamsMaker *(^APLCSAdArrayInit)(NSArray *);
typedef APLCSAdSetupParams *(^APLCSAdMakeInit)(void);


@class APLCSAdDataModel;
typedef void (^APLCSAdRequestCompleteBlock)(NSMutableArray<APLCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^APLCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^APLCSAdPreloadCompleteBlock)(APLCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
