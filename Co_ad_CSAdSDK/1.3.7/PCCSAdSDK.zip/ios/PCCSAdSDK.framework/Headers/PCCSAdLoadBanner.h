//
//  PCCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCCSAdLoadBanner : PCCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
