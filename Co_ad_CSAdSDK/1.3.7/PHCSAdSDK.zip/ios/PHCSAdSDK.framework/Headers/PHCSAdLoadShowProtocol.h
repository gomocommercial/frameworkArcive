//
//  PHCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PHCSAdTypedef.h"

@class PHCSAdLoadBase;

@protocol PHCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PHCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pHonAdShowed:(PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pHonAdClicked:(PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pHonAdClosed:(PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pHonAdVideoCompletePlaying:(PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)pHonAdShowFail:(PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pHonAdOtherEvent:(PHCSAdLoadBase<PHCSAdLoadProtocol> *)adload event:(PHCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
