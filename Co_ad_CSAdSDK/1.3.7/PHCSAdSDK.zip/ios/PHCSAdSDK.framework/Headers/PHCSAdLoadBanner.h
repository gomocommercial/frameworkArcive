//
//  PHCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PHCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PHCSAdLoadBanner : PHCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
