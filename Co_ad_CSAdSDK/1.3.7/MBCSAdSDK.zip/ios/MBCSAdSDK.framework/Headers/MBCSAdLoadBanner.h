//
//  MBCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "MBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MBCSAdLoadBanner : MBCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
