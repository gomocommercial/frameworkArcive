//
//  WPCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "WPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface WPCSAdLoadOpen : WPCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
