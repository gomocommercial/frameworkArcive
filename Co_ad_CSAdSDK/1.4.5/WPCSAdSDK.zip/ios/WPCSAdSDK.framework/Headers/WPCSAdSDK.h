//
//  WPCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "WPCSAdLoadBase.h"
#import "WPCSAdDataModel.h"
#import "WPCSAdLoadProtocol.h"
#import "WPCSAdLoadDataProtocol.h"
#import "WPCSAdLoadShowProtocol.h"
#import "WPCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface WPCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)wPsetupByBlock:(void (^ _Nonnull)(WPCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)wPloadAd:(NSString *)moduleId delegate:(id<WPCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)wPadShowStatistic:(WPCSAdDataModel *)dataModel adload:(nonnull WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)wPadClickStatistic:(WPCSAdDataModel *)dataModel adload:(nonnull WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)wPaddCustomFecher:(Class<WPCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
