//
//  LTCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lTCkAdvDataSourceFacebook   2 //FB 广告数据源
#define lTCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lTCkAdvDataSourceMopub      39//Mopub 广告数据源
#define lTCkAdvDataSourceApplovin   20//applovin 广告数据源

#define lTCkAdvDataSourceGDT        62//广点通 广告数据源
#define lTCkAdvDataSourceBaidu      63//百度 广告数据源
#define lTCkAdvDataSourceBU         64//头条 广告数据源
#define lTCkAdvDataSourceABU         70//头条聚合 广告数据源
#define lTCkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define lTCkAdvDataSourcePangle     74//pangle 广告数据源

#define lTCkOnlineAdvTypeBanner                   1  //banner
#define lTCkOnlineAdvTypeInterstitial             2  //全屏
#define lTCkOnlineAdvTypeNative                   3 //native
#define lTCkOnlineAdvTypeVideo                    4 //视频
#define lTCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define lTCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define lTCkOnlineAdvTypeOpen                     8 //开屏
#define lTCkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define lTCkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define lTCkAdServerConfigError  -1 //服务器返回数据不正确
#define lTCkAdLoadConfigFailed  -2 //广告加载失败


#define lTCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lTCkCSAdInstallDays @"lTCkCSAdInstallDays"
#define lTCkCSAdModule_key @"lTCkCSAdModule_key_%@"
#define lTCkCSNewAdModule_key @"lTCkCSNewAdModule_key_%@"
#define lTCkCSAdInstallTime @"lTCkCSAdInstallTime"
#define lTCkCSAdInstallHours @"lTCkCSAdInstallHours"
#define lTCkCSAdLastGetServerTime @"lTCkCSAdLastRequestTime"
#define lTCkCSAdloadTime 30

#define lTCkCSLoadAdTimeOutNotification @"lTCKCSLoadAdTimeOutNotification"
#define lTCkCSLoadAdTimeOutNotificationKey @"lTCKCSLoadAdTimeOutKey"

