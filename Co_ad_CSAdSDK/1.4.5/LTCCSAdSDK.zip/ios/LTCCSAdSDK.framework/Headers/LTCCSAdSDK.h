//
//  LTCCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "LTCCSAdLoadBase.h"
#import "LTCCSAdDataModel.h"
#import "LTCCSAdLoadProtocol.h"
#import "LTCCSAdLoadDataProtocol.h"
#import "LTCCSAdLoadShowProtocol.h"
#import "LTCCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface LTCCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)lTCsetupByBlock:(void (^ _Nonnull)(LTCCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)lTCloadAd:(NSString *)moduleId delegate:(id<LTCCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)lTCadShowStatistic:(LTCCSAdDataModel *)dataModel adload:(nonnull LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)lTCadClickStatistic:(LTCCSAdDataModel *)dataModel adload:(nonnull LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)lTCaddCustomFecher:(Class<LTCCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
