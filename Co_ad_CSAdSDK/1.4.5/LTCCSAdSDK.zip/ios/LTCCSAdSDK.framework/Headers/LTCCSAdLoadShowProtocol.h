//
//  LTCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LTCCSAdTypedef.h"

@class LTCCSAdLoadBase;

@protocol LTCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LTCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lTConAdShowed:(LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)lTConAdClicked:(LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lTConAdClosed:(LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lTConAdVideoCompletePlaying:(LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)lTConAdVideoGotReward:(LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload;
-(void)lTConAdDidPayRevenue:(LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)lTConAdShowFail:(LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lTConAdOtherEvent:(LTCCSAdLoadBase<LTCCSAdLoadProtocol> *)adload event:(LTCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
