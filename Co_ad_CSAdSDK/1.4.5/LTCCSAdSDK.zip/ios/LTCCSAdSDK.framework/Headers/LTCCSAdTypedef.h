//
//  LTCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    LTCCSAdLoadSuccess = 1,
    LTCCSAdLoadFailure = -1,
    LTCCSAdLoadTimeout = -2
} LTCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    LTCCSAdPreloadSuccess = 1,
    //预加载失败
    LTCCSAdPreloadFailure = -1,
    //重复加载
    LTCCSAdPreloadRepeat = -2,
} LTCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    LTCCSAdWillAppear,//即将出现
    LTCCSAdDidAppear,//已经出现
    LTCCSAdWillDisappear,//即将消失
    LTCCSAdDidDisappear,//已经消失
    LTCCSAdMuted,//静音广告
    LTCCSAdWillLeaveApplication,//将要离开App

    LTCCSAdVideoStart,//开始播放 常用于video
    LTCCSAdVideoComplete,//播放完成 常用于video
    LTCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    LTCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    LTCCSAdNativeDidDownload,//下载完成 常用于fb Native
    LTCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    LTCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    LTCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    LTCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    LTCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    LTCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    LTCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    LTCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    LTCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    LTCCSAdBUOpenRenderSuccess, //渲染成功
    LTCCSAdBUOpenRenderFail, //渲染失败
    LTCCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    LTCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    LTCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    LTCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    LTCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    LTCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    LTCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    LTCCSAdPlayerStatusStarted,//开始播放
    LTCCSAdPlayerStatusPaused,//用户行为导致暂停
    LTCCSAdPlayerStatusStoped,//播放停止
    LTCCSAdPlayerStatusError,//播放出错
    LTCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    LTCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    LTCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    LTCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    LTCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    LTCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    LTCCSAdRecordImpression, //广告曝光已记录
    LTCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    LTCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    LTCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    LTCCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    LTCCSAdABUOpenWillPresentFullScreen,
    LTCCSAdABUOpenDidShowFailed,
    LTCCSAdABUOpenWillDissmissFullScreen,
    LTCCSAdABUOpenCountdownToZero,
    
    LTCCSAdABUBannerWillPresentFullScreen,
    LTCCSAdABUBannerWillDismissFullScreen,
    
    LTCCSAdABURewardDidLoad,
    LTCCSAdABURewardRenderFail,
    LTCCSAdABURewardDidShowFailed,

} LTCCSAdEvent;

typedef void (^LTCCSAdLoadCompleteBlock)(LTCCSAdLoadStatus adLoadStatus);

@class LTCCSAdSetupParamsMaker;
@class LTCCSAdSetupParams;

typedef LTCCSAdSetupParamsMaker *(^LTCCSAdStringInit)(NSString *);
typedef LTCCSAdSetupParamsMaker *(^LTCCSAdBoolInit)(BOOL);
typedef LTCCSAdSetupParamsMaker *(^LTCCSAdIntegerInit)(NSInteger);
typedef LTCCSAdSetupParamsMaker *(^LTCCSAdLongInit)(long);
typedef LTCCSAdSetupParamsMaker *(^LTCCSAdArrayInit)(NSArray *);
typedef LTCCSAdSetupParams *(^LTCCSAdMakeInit)(void);


@class LTCCSAdDataModel;
typedef void (^LTCCSAdRequestCompleteBlock)(NSMutableArray<LTCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^LTCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^LTCCSAdPreloadCompleteBlock)(LTCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
