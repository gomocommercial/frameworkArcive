//
//  LTCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lTkAdvDataSourceFacebook   2 //FB 广告数据源
#define lTkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lTkAdvDataSourceMopub      39//Mopub 广告数据源
#define lTkAdvDataSourceApplovin   20//applovin 广告数据源

#define lTkAdvDataSourceGDT        62//广点通 广告数据源
#define lTkAdvDataSourceBaidu      63//百度 广告数据源
#define lTkAdvDataSourceBU         64//头条 广告数据源
#define lTkAdvDataSourceABU         70//头条聚合 广告数据源
#define lTkAdvDataSourceBUGlobal   73//海外头条 广告数据源

#define lTkOnlineAdvTypeBanner                   1  //banner
#define lTkOnlineAdvTypeInterstitial             2  //全屏
#define lTkOnlineAdvTypeNative                   3 //native
#define lTkOnlineAdvTypeVideo                    4 //视频
#define lTkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define lTkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define lTkOnlineAdvTypeOpen                     8 //开屏
#define lTkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define lTkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define lTkAdServerConfigError  -1 //服务器返回数据不正确
#define lTkAdLoadConfigFailed  -2 //广告加载失败


#define lTAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lTkCSAdInstallDays @"lTkCSAdInstallDays"
#define lTkCSAdModule_key @"lTkCSAdModule_key_%@"
#define lTkCSNewAdModule_key @"lTkCSNewAdModule_key_%@"
#define lTkCSAdInstallTime @"lTkCSAdInstallTime"
#define lTkCSAdInstallHours @"lTkCSAdInstallHours"
#define lTkCSAdLastGetServerTime @"lTkCSAdLastRequestTime"
#define lTkCSAdloadTime 30

#define lTkCSLoadAdTimeOutNotification @"lTKCSLoadAdTimeOutNotification"
#define lTkCSLoadAdTimeOutNotificationKey @"lTKCSLoadAdTimeOutKey"

