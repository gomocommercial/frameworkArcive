//
//  VECSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "VECSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface VECSAdLoadInterstitial : VECSAdLoadBase


@end

NS_ASSUME_NONNULL_END
