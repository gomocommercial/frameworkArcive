//
//  VECSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "VECSAdTypedef.h"

@class VECSAdLoadBase;

@protocol VECSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol VECSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)vEonAdShowed:(VECSAdLoadBase<VECSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)vEonAdClicked:(VECSAdLoadBase<VECSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)vEonAdClosed:(VECSAdLoadBase<VECSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)vEonAdVideoCompletePlaying:(VECSAdLoadBase<VECSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)vEonAdShowFail:(VECSAdLoadBase<VECSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)vEonAdOtherEvent:(VECSAdLoadBase<VECSAdLoadProtocol> *)adload event:(VECSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
