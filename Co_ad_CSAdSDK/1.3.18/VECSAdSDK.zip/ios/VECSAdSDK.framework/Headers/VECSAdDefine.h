//
//  VECSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define vEkAdvDataSourceFacebook   2 //FB 广告数据源
#define vEkAdvDataSourceAdmob      8 //Admob 广告数据源
#define vEkAdvDataSourceMopub      39//Mopub 广告数据源
#define vEkAdvDataSourceApplovin   20//applovin 广告数据源

#define vEkAdvDataSourceGDT        62//广点通 广告数据源
#define vEkAdvDataSourceBaidu      63//百度 广告数据源
#define vEkAdvDataSourceBU         64//头条 广告数据源
#define vEkAdvDataSourceABU         70//头条聚合 广告数据源
#define vEkAdvDataSourceBUGlobal   73//海外头条 广告数据源

#define vEkOnlineAdvTypeBanner                   1  //banner
#define vEkOnlineAdvTypeInterstitial             2  //全屏
#define vEkOnlineAdvTypeNative                   3 //native
#define vEkOnlineAdvTypeVideo                    4 //视频
#define vEkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define vEkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define vEkOnlineAdvTypeOpen                     8 //开屏
#define vEkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define vEkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define vEkAdServerConfigError  -1 //服务器返回数据不正确
#define vEkAdLoadConfigFailed  -2 //广告加载失败


#define vEAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define vEkCSAdInstallDays @"vEkCSAdInstallDays"
#define vEkCSAdModule_key @"vEkCSAdModule_key_%@"
#define vEkCSNewAdModule_key @"vEkCSNewAdModule_key_%@"
#define vEkCSAdInstallTime @"vEkCSAdInstallTime"
#define vEkCSAdInstallHours @"vEkCSAdInstallHours"
#define vEkCSAdLastGetServerTime @"vEkCSAdLastRequestTime"
#define vEkCSAdloadTime 30

#define vEkCSLoadAdTimeOutNotification @"vEKCSLoadAdTimeOutNotification"
#define vEkCSLoadAdTimeOutNotificationKey @"vEKCSLoadAdTimeOutKey"

