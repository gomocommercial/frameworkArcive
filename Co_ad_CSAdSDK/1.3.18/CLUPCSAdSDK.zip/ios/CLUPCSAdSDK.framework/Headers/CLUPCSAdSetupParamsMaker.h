//
//  CLUPCSAdSetupParamsMaker.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLUPCSAdSetupParams.h"
#import "CLUPCSAdTypedef.h"

NS_ASSUME_NONNULL_BEGIN

@class CLUPCSAdSetupParamsMaker;

@interface CLUPCSAdSetupParamsMaker : NSObject

// MARK: - 必填
/**
 产品ID
 */
@property (assign, nonatomic, readonly) CLUPCSAdIntegerInit cid;

/**
 真实渠道号（app发布渠道）
 */
@property (assign, nonatomic, readonly) CLUPCSAdIntegerInit channel;

/**
 数据渠道（产品数据渠道）
 */
@property (assign, nonatomic, readonly) CLUPCSAdIntegerInit dataChannel;

/**
 是否使用新的广告接口服务
 useNewStoreLite为true时，Appid,apiKey，apiSecret，desKey和appid必须配置
 AVAILABLE(1.3.16)
 */@property (assign, nonatomic, readonly) CLUPCSAdBoolInit useNewStoreLite;


// MARK: - 选填

/**
 是否开启log默认不开启:false
 */
@property (assign, nonatomic, readonly) CLUPCSAdBoolInit debugLog;

/**
 客户端版本号(默认获取build号)
 */
@property (assign, nonatomic, readonly) CLUPCSAdIntegerInit cversion;

/**
 是否为测试服默认开启:true
 */
@property (assign, nonatomic, readonly) CLUPCSAdBoolInit isTest;

/**
 des长度默认:8 * 1024
 */
@property (assign, nonatomic, readonly) CLUPCSAdLongInit desBytesCount;

/**
 用户来源类型，一般从买量SDK获取
 */
@property (assign, nonatomic, readonly) CLUPCSAdStringInit userFrom;

/**
 用户买量渠道：选填 如：fb；一般从买量SDK获取
 */
@property (assign, nonatomic, readonly) CLUPCSAdStringInit buyChannel;

/**
 是否为升级用户 选填，0.未知(此时服务器会认为是升级用户) 1.是升级用户 2.不是升级用户
 */
@property (assign, nonatomic, readonly) CLUPCSAdIntegerInit upgrade;

/**
 //入口ID SDK默认设置1 ： 1 主包 2 主题  3 主题商城 4 广告widget 101.自定义-1
 */
@property (assign, nonatomic, readonly) CLUPCSAdIntegerInit entranceId;



/**
 选填：如果项目有特定的用户id则必填，没有则不填
 */
@property (assign, nonatomic, readonly) CLUPCSAdStringInit uid;

/**
 缓存时间：默认4小时
 */
@property (assign, nonatomic, readonly) CLUPCSAdIntegerInit cacheTime;

/**
 测试设备列表（identifier）
 */
@property (assign, nonatomic, readonly) CLUPCSAdArrayInit testDevices;

/**
 是否使用iP发起请求
 */
@property (assign, nonatomic, readonly) CLUPCSAdBoolInit useIP;

/**
 * 构建CSAdSetupParams对象
 */
@property (strong, nonatomic, readonly) CLUPCSAdMakeInit make;
/**
 选填:加密秘钥(SDK已配置，可重新设置)
 */
@property (assign, nonatomic, readonly) CLUPCSAdStringInit desKey;


/**
 appId，useNewStoreLite为true时必填
 */
@property (nonatomic,assign,readonly) CLUPCSAdStringInit appId;
/**
 apiKey，useNewStoreLite为true时必填
 */
@property (nonatomic,assign,readonly) CLUPCSAdStringInit apiKey;
/**
 apiSecret，useNewStoreLite为true时必填
 */
@property (nonatomic,assign,readonly) CLUPCSAdStringInit apiSecret;
@end

NS_ASSUME_NONNULL_END
