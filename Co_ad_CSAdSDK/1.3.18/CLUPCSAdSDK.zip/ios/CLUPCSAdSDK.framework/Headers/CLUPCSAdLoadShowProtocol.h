//
//  CLUPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CLUPCSAdTypedef.h"

@class CLUPCSAdLoadBase;

@protocol CLUPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CLUPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cLUPonAdShowed:(CLUPCSAdLoadBase<CLUPCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cLUPonAdClicked:(CLUPCSAdLoadBase<CLUPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cLUPonAdClosed:(CLUPCSAdLoadBase<CLUPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cLUPonAdVideoCompletePlaying:(CLUPCSAdLoadBase<CLUPCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)cLUPonAdShowFail:(CLUPCSAdLoadBase<CLUPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cLUPonAdOtherEvent:(CLUPCSAdLoadBase<CLUPCSAdLoadProtocol> *)adload event:(CLUPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
