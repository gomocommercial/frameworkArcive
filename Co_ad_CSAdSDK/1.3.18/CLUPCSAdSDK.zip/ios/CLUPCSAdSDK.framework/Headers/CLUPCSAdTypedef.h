//
//  CLUPCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CLUPCSAdLoadSuccess = 1,
    CLUPCSAdLoadFailure = -1,
    CLUPCSAdLoadTimeout = -2
} CLUPCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CLUPCSAdPreloadSuccess = 1,
    //预加载失败
    CLUPCSAdPreloadFailure = -1,
    //重复加载
    CLUPCSAdPreloadRepeat = -2,
} CLUPCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CLUPCSAdWillAppear,//即将出现
    CLUPCSAdDidAppear,//已经出现
    CLUPCSAdWillDisappear,//即将消失
    CLUPCSAdDidDisappear,//已经消失
    CLUPCSAdMuted,//静音广告
    CLUPCSAdWillLeaveApplication,//将要离开App

    CLUPCSAdVideoStart,//开始播放 常用于video
    CLUPCSAdVideoComplete,//播放完成 常用于video
    CLUPCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CLUPCSAdVideoServerFail,//连接服务器成功，常用于fb video

    CLUPCSAdNativeDidDownload,//下载完成 常用于fb Native
    CLUPCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CLUPCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CLUPCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CLUPCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CLUPCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CLUPCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    CLUPCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CLUPCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CLUPCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    CLUPCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CLUPCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CLUPCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CLUPCSAdDidPresentFullScreen,//插屏弹出全屏广告
    CLUPCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CLUPCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CLUPCSAdPlayerStatusStarted,//开始播放
    CLUPCSAdPlayerStatusPaused,//用户行为导致暂停
    CLUPCSAdPlayerStatusStoped,//播放停止
    CLUPCSAdPlayerStatusError,//播放出错
    CLUPCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CLUPCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CLUPCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CLUPCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CLUPCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CLUPCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CLUPCSAdRecordImpression, //广告曝光已记录
    CLUPCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CLUPCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CLUPCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    CLUPCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    CLUPCSAdABUOpenWillPresentFullScreen,
    CLUPCSAdABUOpenDidShowFailed,
    CLUPCSAdABUOpenWillDissmissFullScreen,
    CLUPCSAdABUOpenCountdownToZero,
    
    CLUPCSAdABUBannerWillPresentFullScreen,
    CLUPCSAdABUBannerWillDismissFullScreen,
    
    CLUPCSAdABURewardDidLoad,
    CLUPCSAdABURewardRenderFail,
    CLUPCSAdABURewardDidShowFailed,

} CLUPCSAdEvent;

typedef void (^CLUPCSAdLoadCompleteBlock)(CLUPCSAdLoadStatus adLoadStatus);

@class CLUPCSAdSetupParamsMaker;
@class CLUPCSAdSetupParams;

typedef CLUPCSAdSetupParamsMaker *(^CLUPCSAdStringInit)(NSString *);
typedef CLUPCSAdSetupParamsMaker *(^CLUPCSAdBoolInit)(BOOL);
typedef CLUPCSAdSetupParamsMaker *(^CLUPCSAdIntegerInit)(NSInteger);
typedef CLUPCSAdSetupParamsMaker *(^CLUPCSAdLongInit)(long);
typedef CLUPCSAdSetupParamsMaker *(^CLUPCSAdArrayInit)(NSArray *);
typedef CLUPCSAdSetupParams *(^CLUPCSAdMakeInit)(void);


@class CLUPCSAdDataModel;
typedef void (^CLUPCSAdRequestCompleteBlock)(NSMutableArray<CLUPCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CLUPCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CLUPCSAdPreloadCompleteBlock)(CLUPCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
