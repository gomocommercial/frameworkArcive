//
//  FaceVCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FaceVCSAdTypedef.h"

@class FaceVCSAdLoadBase;

@protocol FaceVCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FaceVCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)faceVonAdShowed:(FaceVCSAdLoadBase<FaceVCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)faceVonAdClicked:(FaceVCSAdLoadBase<FaceVCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)faceVonAdClosed:(FaceVCSAdLoadBase<FaceVCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)faceVonAdVideoCompletePlaying:(FaceVCSAdLoadBase<FaceVCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)faceVonAdShowFail:(FaceVCSAdLoadBase<FaceVCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)faceVonAdOtherEvent:(FaceVCSAdLoadBase<FaceVCSAdLoadProtocol> *)adload event:(FaceVCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
