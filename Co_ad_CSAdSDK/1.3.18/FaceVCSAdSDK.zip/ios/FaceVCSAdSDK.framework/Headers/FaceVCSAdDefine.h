//
//  FaceVCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define faceVkAdvDataSourceFacebook   2 //FB 广告数据源
#define faceVkAdvDataSourceAdmob      8 //Admob 广告数据源
#define faceVkAdvDataSourceMopub      39//Mopub 广告数据源
#define faceVkAdvDataSourceApplovin   20//applovin 广告数据源

#define faceVkAdvDataSourceGDT        62//广点通 广告数据源
#define faceVkAdvDataSourceBaidu      63//百度 广告数据源
#define faceVkAdvDataSourceBU         64//头条 广告数据源
#define faceVkAdvDataSourceABU         70//头条聚合 广告数据源
#define faceVkAdvDataSourceBUGlobal   73//海外头条 广告数据源

#define faceVkOnlineAdvTypeBanner                   1  //banner
#define faceVkOnlineAdvTypeInterstitial             2  //全屏
#define faceVkOnlineAdvTypeNative                   3 //native
#define faceVkOnlineAdvTypeVideo                    4 //视频
#define faceVkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define faceVkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define faceVkOnlineAdvTypeOpen                     8 //开屏
#define faceVkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define faceVkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define faceVkAdServerConfigError  -1 //服务器返回数据不正确
#define faceVkAdLoadConfigFailed  -2 //广告加载失败


#define faceVAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define faceVkCSAdInstallDays @"faceVkCSAdInstallDays"
#define faceVkCSAdModule_key @"faceVkCSAdModule_key_%@"
#define faceVkCSNewAdModule_key @"faceVkCSNewAdModule_key_%@"
#define faceVkCSAdInstallTime @"faceVkCSAdInstallTime"
#define faceVkCSAdInstallHours @"faceVkCSAdInstallHours"
#define faceVkCSAdLastGetServerTime @"faceVkCSAdLastRequestTime"
#define faceVkCSAdloadTime 30

#define faceVkCSLoadAdTimeOutNotification @"faceVKCSLoadAdTimeOutNotification"
#define faceVkCSLoadAdTimeOutNotificationKey @"faceVKCSLoadAdTimeOutKey"

