//
//  QTCSAdSetupParams.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QTCSAdSetupParams : NSObject

// MARK: - 必填
/**
 产品ID
 */
@property (nonatomic, assign) NSInteger cid;

/**
 真实渠道号（app发布渠道）
 */
@property (nonatomic, assign) NSInteger channel;

/**
 数据渠道（产品数据渠道）
 */
@property (nonatomic, assign) NSInteger dataChannel;

/**
 是否使用新的广告接口服务
 useNewStoreLite为true时，Appid,apiKey，apiSecret，desKey和appid必须配置
 AVAILABLE(1.3.16)
 */
@property (assign, nonatomic) BOOL useNewStoreLite;

// MARK: - 选填

/**
 客户端版本号(默认获取build号)
 */
@property (nonatomic, assign) NSInteger cversion;

/**
 是否开启log默认不开启
 */
@property (nonatomic, assign) BOOL debugLog;

/**
 是否为测试服默认开启
 */
@property (nonatomic, assign) BOOL isTest;

/**
 des长度默认8k
 */
@property (nonatomic, assign) long desBytesCount;

/**
 用户来源类型，一般从买量SDK获取
 */
@property (nonatomic, copy) NSString *userFrom;

/**
 用户买量渠道：选填 如：fb；一般从买量SDK获取
 */
@property (nonatomic, copy) NSString *buyChannel;

/**
 产品安装天数,用于判断新老用户（SDK内部计算,当本地时间不正确时会通过网络获取 需要刷新时调用 CSAdNetworkTool setCDay:）
 */
@property (nonatomic, assign,readonly) NSInteger cDay;

/**
 是否为升级用户 选填:0.未知(此时服务器会认为是升级用户) 1.是升级用户 2.不是升级用户
 */
@property (nonatomic, assign) NSInteger upgrade;

/**
//入口ID SDK默认设置1 ： 1 主包 2 主题  3 主题商城 4 广告widget 101.自定义-1
 */
@property (nonatomic, assign) NSInteger entranceId;

/**
 缓存时间：默认4小时
 */
@property (nonatomic, assign) NSInteger cacheTime;


/**
 选填：如果项目有特定的用户id则必填，没有则不填
 */
@property (nonatomic, copy) NSString *uid;


/**
 测试设备列表（identifier）
 */
@property (nonatomic, strong) NSArray *testDevices;

/**
是否使用iP发起请求
*/
@property (nonatomic, assign) BOOL useIP;

/**
 选填:加密秘钥(SDK已配置，可重新设置),useNewStoreLite为true时必填
 */
@property (nonatomic, copy) NSString *desKey;

/**
 appId，useNewStoreLite为true时必填
 */
@property (nonatomic,copy) NSString *appId;
/**
 apiKey，useNewStoreLite为true时必填
 */
@property (nonatomic,copy) NSString *apiKey;
/**
 apiSecret，useNewStoreLite为true时必填
 */
@property (nonatomic,copy) NSString *apiSecret;

- (void)qTcheckParams;
@end
