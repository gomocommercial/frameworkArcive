//
//  QTCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define qTkAdvDataSourceFacebook   2 //FB 广告数据源
#define qTkAdvDataSourceAdmob      8 //Admob 广告数据源
#define qTkAdvDataSourceMopub      39//Mopub 广告数据源
#define qTkAdvDataSourceApplovin   20//applovin 广告数据源

#define qTkAdvDataSourceGDT        62//广点通 广告数据源
#define qTkAdvDataSourceBaidu      63//百度 广告数据源
#define qTkAdvDataSourceBU         64//头条 广告数据源
#define qTkAdvDataSourceABU         70//头条聚合 广告数据源
#define qTkAdvDataSourceBUGlobal   73//海外头条 广告数据源

#define qTkOnlineAdvTypeBanner                   1  //banner
#define qTkOnlineAdvTypeInterstitial             2  //全屏
#define qTkOnlineAdvTypeNative                   3 //native
#define qTkOnlineAdvTypeVideo                    4 //视频
#define qTkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define qTkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define qTkOnlineAdvTypeOpen                     8 //开屏
#define qTkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define qTkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define qTkAdServerConfigError  -1 //服务器返回数据不正确
#define qTkAdLoadConfigFailed  -2 //广告加载失败


#define qTAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define qTkCSAdInstallDays @"qTkCSAdInstallDays"
#define qTkCSAdModule_key @"qTkCSAdModule_key_%@"
#define qTkCSNewAdModule_key @"qTkCSNewAdModule_key_%@"
#define qTkCSAdInstallTime @"qTkCSAdInstallTime"
#define qTkCSAdInstallHours @"qTkCSAdInstallHours"
#define qTkCSAdLastGetServerTime @"qTkCSAdLastRequestTime"
#define qTkCSAdloadTime 30

#define qTkCSLoadAdTimeOutNotification @"qTKCSLoadAdTimeOutNotification"
#define qTkCSLoadAdTimeOutNotificationKey @"qTKCSLoadAdTimeOutKey"

