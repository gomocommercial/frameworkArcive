//
//  WOCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "WOCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface WOCSAdLoadReward : WOCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
