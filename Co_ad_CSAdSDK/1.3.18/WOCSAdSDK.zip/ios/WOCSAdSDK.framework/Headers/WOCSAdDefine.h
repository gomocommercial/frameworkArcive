//
//  WOCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define wOkAdvDataSourceFacebook   2 //FB 广告数据源
#define wOkAdvDataSourceAdmob      8 //Admob 广告数据源
#define wOkAdvDataSourceMopub      39//Mopub 广告数据源
#define wOkAdvDataSourceApplovin   20//applovin 广告数据源

#define wOkAdvDataSourceGDT        62//广点通 广告数据源
#define wOkAdvDataSourceBaidu      63//百度 广告数据源
#define wOkAdvDataSourceBU         64//头条 广告数据源
#define wOkAdvDataSourceABU         70//头条聚合 广告数据源
#define wOkAdvDataSourceBUGlobal   73//海外头条 广告数据源

#define wOkOnlineAdvTypeBanner                   1  //banner
#define wOkOnlineAdvTypeInterstitial             2  //全屏
#define wOkOnlineAdvTypeNative                   3 //native
#define wOkOnlineAdvTypeVideo                    4 //视频
#define wOkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define wOkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define wOkOnlineAdvTypeOpen                     8 //开屏
#define wOkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define wOkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define wOkAdServerConfigError  -1 //服务器返回数据不正确
#define wOkAdLoadConfigFailed  -2 //广告加载失败


#define wOAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define wOkCSAdInstallDays @"wOkCSAdInstallDays"
#define wOkCSAdModule_key @"wOkCSAdModule_key_%@"
#define wOkCSNewAdModule_key @"wOkCSNewAdModule_key_%@"
#define wOkCSAdInstallTime @"wOkCSAdInstallTime"
#define wOkCSAdInstallHours @"wOkCSAdInstallHours"
#define wOkCSAdLastGetServerTime @"wOkCSAdLastRequestTime"
#define wOkCSAdloadTime 30

#define wOkCSLoadAdTimeOutNotification @"wOKCSLoadAdTimeOutNotification"
#define wOkCSLoadAdTimeOutNotificationKey @"wOKCSLoadAdTimeOutKey"

