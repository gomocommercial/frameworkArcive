//
//  DPCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "DPCSAdLoadBase.h"
#import "DPCSAdDataModel.h"
#import "DPCSAdLoadProtocol.h"
#import "DPCSAdLoadDataProtocol.h"
#import "DPCSAdLoadShowProtocol.h"
#import "DPCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface DPCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)dPsetupByBlock:(void (^ _Nonnull)(DPCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)dPloadAd:(NSString *)moduleId delegate:(id<DPCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)dPadShowStatistic:(DPCSAdDataModel *)dataModel adload:(nonnull DPCSAdLoadBase<DPCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)dPadClickStatistic:(DPCSAdDataModel *)dataModel adload:(nonnull DPCSAdLoadBase<DPCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)dPaddCustomFecher:(Class<DPCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
