//
//  DPCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "DPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DPCSAdLoadOpen : DPCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
