//
//  DPCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "DPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DPCSAdLoadNative : DPCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
