//
//  DPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define dPkAdvDataSourceFacebook   2 //FB 广告数据源
#define dPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define dPkAdvDataSourceMopub      39//Mopub 广告数据源
#define dPkAdvDataSourceApplovin   20//applovin 广告数据源

#define dPkAdvDataSourceGDT        62//广点通 广告数据源
#define dPkAdvDataSourceBaidu      63//百度 广告数据源
#define dPkAdvDataSourceBU         64//头条 广告数据源
#define dPkAdvDataSourceABU         70//头条聚合 广告数据源
#define dPkAdvDataSourceBUGlobal   73//海外头条 广告数据源

#define dPkOnlineAdvTypeBanner                   1  //banner
#define dPkOnlineAdvTypeInterstitial             2  //全屏
#define dPkOnlineAdvTypeNative                   3 //native
#define dPkOnlineAdvTypeVideo                    4 //视频
#define dPkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define dPkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define dPkOnlineAdvTypeOpen                     8 //开屏
#define dPkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define dPkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define dPkAdServerConfigError  -1 //服务器返回数据不正确
#define dPkAdLoadConfigFailed  -2 //广告加载失败


#define dPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define dPkCSAdInstallDays @"dPkCSAdInstallDays"
#define dPkCSAdModule_key @"dPkCSAdModule_key_%@"
#define dPkCSNewAdModule_key @"dPkCSNewAdModule_key_%@"
#define dPkCSAdInstallTime @"dPkCSAdInstallTime"
#define dPkCSAdInstallHours @"dPkCSAdInstallHours"
#define dPkCSAdLastGetServerTime @"dPkCSAdLastRequestTime"
#define dPkCSAdloadTime 30

#define dPkCSLoadAdTimeOutNotification @"dPKCSLoadAdTimeOutNotification"
#define dPkCSLoadAdTimeOutNotificationKey @"dPKCSLoadAdTimeOutKey"

