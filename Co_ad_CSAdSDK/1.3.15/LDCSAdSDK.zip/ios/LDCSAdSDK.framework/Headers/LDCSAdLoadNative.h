//
//  LDCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LDCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LDCSAdLoadNative : LDCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
