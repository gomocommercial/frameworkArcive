//
//  QRCSAdLoadDataProtocol.h
//  QRCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "QRCSAdTypedef.h"

@class QRCSAdDataModel;
@class QRCSAdLoadBase;

@protocol QRCSAdLoadProtocol;

@protocol QRCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)qRonAdInfoFinish:(QRCSAdLoadBase<QRCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)qRonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)qRonAdFail:(QRCSAdLoadBase<QRCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
