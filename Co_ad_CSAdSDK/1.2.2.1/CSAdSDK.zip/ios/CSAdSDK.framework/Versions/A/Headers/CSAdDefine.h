//
//  CSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define kAdvDataSourceFacebook   2 //FB 广告数据源
#define kAdvDataSourceAdmob      8 //Admob 广告数据源
#define kAdvDataSourceMopub      39//Mopub 广告数据源
#define kAdvDataSourceApplovin   20//applovin 广告数据源

#define kAdvDataSourceGDT        62//广点通 广告数据源
#define kAdvDataSourceBaidu      63//百度 广告数据源
#define kAdvDataSourceBU         64//头条 广告数据源


#define kOnlineAdvTypeBanner                   1  //banner
#define kOnlineAdvTypeInterstitial             2  //全屏
#define kOnlineAdvTypeNative                   3 //native
#define kOnlineAdvTypeVideo                    4 //视频
#define kOnlineAdvTypeMinBanner                5 //banner(300*250)
#define kOnlineAdvTypeInterstitialVideo        7 //插屏视频

#define kAdServerConfigError  -1 //服务器返回数据不正确
#define kAdLoadConfigFailed  -2 //广告加载失败


#define AdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define kCSAdInstallDays @"kCSAdInstallDays"
#define kCSAdModule_key @"kCSAdModule_key_%@"
#define kCSAdInstallTime @"kCSAdInstallTime"
#define kCSAdLastGetServerTime @"kCSAdLastRequestTime"
#define kCSAdloadTime 30

#define kCSLoadAdTimeOutNotification @"KCSLoadAdTimeOutNotification"
#define kCSLoadAdTimeOutNotificationKey @"KCSLoadAdTimeOutKey"

