//
//  FLCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define fLkAdvDataSourceFacebook   2 //FB 广告数据源
#define fLkAdvDataSourceAdmob      8 //Admob 广告数据源
#define fLkAdvDataSourceMopub      39//Mopub 广告数据源
#define fLkAdvDataSourceApplovin   20//applovin 广告数据源

#define fLkAdvDataSourceGDT        62//广点通 广告数据源
#define fLkAdvDataSourceBaidu      63//百度 广告数据源
#define fLkAdvDataSourceBU         64//头条 广告数据源


#define fLkOnlineAdvTypeBanner                   1  //banner
#define fLkOnlineAdvTypeInterstitial             2  //全屏
#define fLkOnlineAdvTypeNative                   3 //native
#define fLkOnlineAdvTypeVideo                    4 //视频
#define fLkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define fLkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define fLkOnlineAdvTypeOpen                     8 //开屏

#define fLkAdServerConfigError  -1 //服务器返回数据不正确
#define fLkAdLoadConfigFailed  -2 //广告加载失败


#define fLAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define fLkCSAdInstallDays @"fLkCSAdInstallDays"
#define fLkCSAdModule_key @"fLkCSAdModule_key_%@"
#define fLkCSAdInstallTime @"fLkCSAdInstallTime"
#define fLkCSAdLastGetServerTime @"fLkCSAdLastRequestTime"
#define fLkCSAdloadTime 30

#define fLkCSLoadAdTimeOutNotification @"fLKCSLoadAdTimeOutNotification"
#define fLkCSLoadAdTimeOutNotificationKey @"fLKCSLoadAdTimeOutKey"

