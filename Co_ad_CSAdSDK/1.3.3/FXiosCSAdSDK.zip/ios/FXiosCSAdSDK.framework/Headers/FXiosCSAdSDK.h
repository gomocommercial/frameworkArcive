//
//  FXiosCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "FXiosCSAdLoadBase.h"
#import "FXiosCSAdDataModel.h"
#import "FXiosCSAdLoadProtocol.h"
#import "FXiosCSAdLoadDataProtocol.h"
#import "FXiosCSAdLoadShowProtocol.h"
#import "FXiosCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface FXiosCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)fXiossetupByBlock:(void (^ _Nonnull)(FXiosCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)fXiosloadAd:(NSString *)moduleId delegate:(id<FXiosCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)fXiosadShowStatistic:(FXiosCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)fXiosadClickStatistic:(FXiosCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)fXiosaddCustomFecher:(Class<FXiosCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
