//
//  FXiosCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define fXioskAdvDataSourceFacebook   2 //FB 广告数据源
#define fXioskAdvDataSourceAdmob      8 //Admob 广告数据源
#define fXioskAdvDataSourceMopub      39//Mopub 广告数据源
#define fXioskAdvDataSourceApplovin   20//applovin 广告数据源

#define fXioskAdvDataSourceGDT        62//广点通 广告数据源
#define fXioskAdvDataSourceBaidu      63//百度 广告数据源
#define fXioskAdvDataSourceBU         64//头条 广告数据源


#define fXioskOnlineAdvTypeBanner                   1  //banner
#define fXioskOnlineAdvTypeInterstitial             2  //全屏
#define fXioskOnlineAdvTypeNative                   3 //native
#define fXioskOnlineAdvTypeVideo                    4 //视频
#define fXioskOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define fXioskOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define fXioskOnlineAdvTypeOpen                     8 //开屏

#define fXioskAdServerConfigError  -1 //服务器返回数据不正确
#define fXioskAdLoadConfigFailed  -2 //广告加载失败


#define fXiosAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define fXioskCSAdInstallDays @"fXioskCSAdInstallDays"
#define fXioskCSAdModule_key @"fXioskCSAdModule_key_%@"
#define fXioskCSAdInstallTime @"fXioskCSAdInstallTime"
#define fXioskCSAdLastGetServerTime @"fXioskCSAdLastRequestTime"
#define fXioskCSAdloadTime 30

#define fXioskCSLoadAdTimeOutNotification @"fXiosKCSLoadAdTimeOutNotification"
#define fXioskCSLoadAdTimeOutNotificationKey @"fXiosKCSLoadAdTimeOutKey"

