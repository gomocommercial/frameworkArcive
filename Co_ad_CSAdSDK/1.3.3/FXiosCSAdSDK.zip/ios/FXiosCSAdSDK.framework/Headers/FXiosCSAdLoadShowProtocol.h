//
//  FXiosCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FXiosCSAdTypedef.h"

@class FXiosCSAdLoadBase;

@protocol FXiosCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FXiosCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)fXiosonAdShowed:(FXiosCSAdLoadBase<FXiosCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)fXiosonAdClicked:(FXiosCSAdLoadBase<FXiosCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)fXiosonAdClosed:(FXiosCSAdLoadBase<FXiosCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)fXiosonAdVideoCompletePlaying:(FXiosCSAdLoadBase<FXiosCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)fXiosonAdShowFail:(FXiosCSAdLoadBase<FXiosCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)fXiosonAdOtherEvent:(FXiosCSAdLoadBase<FXiosCSAdLoadProtocol> *)adload event:(FXiosCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
