//
//  CSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CSAdLoadSuccess = 1,
    CSAdLoadFailure = -1,
    CSAdLoadTimeout = -2
} CSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CSAdPreloadSuccess = 1,
    //预加载失败
    CSAdPreloadFailure = -1,
    //重复加载
    CSAdPreloadRepeat = -2,
} CSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CSAdWillAppear,//即将出现
    CSAdDidAppear,//已经出现
    CSAdWillDisappear,//即将消失
    CSAdDidDisappear,//已经消失
    CSAdMuted,//静音广告
    CSAdWillLeaveApplication,//将要离开App

    CSAdVideoStart,//开始播放 常用于video
    CSAdVideoComplete,//播放完成 常用于video
    CSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CSAdVideoServerFail,//连接服务器成功，常用于fb video

    CSAdNativeDidDownload,//下载完成 常用于fb Native
    CSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    CSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CSAdDidPresentFullScreen,//插屏弹出全屏广告
    CSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CSAdPlayerStatusStarted,//开始播放
    CSAdPlayerStatusPaused,//用户行为导致暂停
    CSAdPlayerStatusStoped,//播放停止
    CSAdPlayerStatusError,//播放出错
    CSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CSAdRecordImpression, //广告曝光已记录
    CSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开

} CSAdEvent;

typedef void (^CSAdLoadCompleteBlock)(CSAdLoadStatus adLoadStatus);

@class CSAdSetupParamsMaker;
@class CSAdSetupParams;

typedef CSAdSetupParamsMaker *(^CSAdStringInit)(NSString *);
typedef CSAdSetupParamsMaker *(^CSAdBoolInit)(BOOL);
typedef CSAdSetupParamsMaker *(^CSAdIntegerInit)(NSInteger);
typedef CSAdSetupParamsMaker *(^CSAdLongInit)(long);
typedef CSAdSetupParamsMaker *(^CSAdArrayInit)(NSArray *);
typedef CSAdSetupParams *(^CSAdMakeInit)(void);


@class CSAdDataModel;
typedef void (^CSAdRequestCompleteBlock)(NSMutableArray<CSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CSAdPreloadCompleteBlock)(CSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
