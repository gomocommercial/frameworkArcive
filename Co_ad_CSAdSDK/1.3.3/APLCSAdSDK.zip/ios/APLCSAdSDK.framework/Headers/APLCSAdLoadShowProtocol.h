//
//  APLCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "APLCSAdTypedef.h"

@class APLCSAdLoadBase;

@protocol APLCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol APLCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)aPLonAdShowed:(APLCSAdLoadBase<APLCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)aPLonAdClicked:(APLCSAdLoadBase<APLCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)aPLonAdClosed:(APLCSAdLoadBase<APLCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)aPLonAdVideoCompletePlaying:(APLCSAdLoadBase<APLCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)aPLonAdShowFail:(APLCSAdLoadBase<APLCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)aPLonAdOtherEvent:(APLCSAdLoadBase<APLCSAdLoadProtocol> *)adload event:(APLCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
