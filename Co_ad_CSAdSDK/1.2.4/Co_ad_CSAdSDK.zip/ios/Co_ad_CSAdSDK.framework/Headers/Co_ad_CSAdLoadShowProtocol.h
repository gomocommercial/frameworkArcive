//
//  Co_ad_CSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "Co_ad_CSAdTypedef.h"

@class Co_ad_CSAdLoadBase;

@protocol Co_ad_CSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol Co_ad_CSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)co_ad_onAdShowed:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)co_ad_onAdClicked:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)co_ad_onAdClosed:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)co_ad_onAdVideoCompletePlaying:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)co_ad_onAdShowFail:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)co_ad_onAdOtherEvent:(Co_ad_CSAdLoadBase<Co_ad_CSAdLoadProtocol> *)adload event:(Co_ad_CSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
