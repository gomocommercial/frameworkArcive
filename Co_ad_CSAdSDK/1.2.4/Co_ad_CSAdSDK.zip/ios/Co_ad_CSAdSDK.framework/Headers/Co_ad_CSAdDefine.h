//
//  Co_ad_CSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define co_ad_kAdvDataSourceFacebook   2 //FB 广告数据源
#define co_ad_kAdvDataSourceAdmob      8 //Admob 广告数据源
#define co_ad_kAdvDataSourceMopub      39//Mopub 广告数据源
#define co_ad_kAdvDataSourceApplovin   20//applovin 广告数据源

#define co_ad_kAdvDataSourceGDT        62//广点通 广告数据源
#define co_ad_kAdvDataSourceBaidu      63//百度 广告数据源
#define co_ad_kAdvDataSourceBU         64//头条 广告数据源


#define co_ad_kOnlineAdvTypeBanner                   1  //banner
#define co_ad_kOnlineAdvTypeInterstitial             2  //全屏
#define co_ad_kOnlineAdvTypeNative                   3 //native
#define co_ad_kOnlineAdvTypeVideo                    4 //视频
#define co_ad_kOnlineAdvTypeMinBanner                5 //banner(300*250)
#define co_ad_kOnlineAdvTypeInterstitialVideo        7 //插屏视频

#define co_ad_kAdServerConfigError  -1 //服务器返回数据不正确
#define co_ad_kAdLoadConfigFailed  -2 //广告加载失败


#define co_ad_AdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define co_ad_kCSAdInstallDays @"co_ad_kCSAdInstallDays"
#define co_ad_kCSAdModule_key @"co_ad_kCSAdModule_key_%@"
#define co_ad_kCSAdInstallTime @"co_ad_kCSAdInstallTime"
#define co_ad_kCSAdLastGetServerTime @"co_ad_kCSAdLastRequestTime"
#define co_ad_kCSAdloadTime 30

#define co_ad_kCSLoadAdTimeOutNotification @"co_ad_KCSLoadAdTimeOutNotification"
#define co_ad_kCSLoadAdTimeOutNotificationKey @"co_ad_KCSLoadAdTimeOutKey"

