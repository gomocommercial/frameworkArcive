//
//  PSECSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PSECSAdLoadSuccess = 1,
    PSECSAdLoadFailure = -1,
    PSECSAdLoadTimeout = -2
} PSECSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PSECSAdPreloadSuccess = 1,
    //预加载失败
    PSECSAdPreloadFailure = -1,
    //重复加载
    PSECSAdPreloadRepeat = -2,
} PSECSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PSECSAdWillAppear,//即将出现
    PSECSAdDidAppear,//已经出现
    PSECSAdWillDisappear,//即将消失
    PSECSAdDidDisappear,//已经消失
    PSECSAdMuted,//静音广告
    PSECSAdWillLeaveApplication,//将要离开App

    PSECSAdVideoStart,//开始播放 常用于video
    PSECSAdVideoComplete,//播放完成 常用于video
    PSECSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PSECSAdVideoServerFail,//连接服务器成功，常用于fb video

    PSECSAdNativeDidDownload,//下载完成 常用于fb Native
    PSECSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PSECSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PSECSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PSECSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PSECSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PSECSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PSECSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PSECSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PSECSAdBUOpenDidAutoDimiss,//开屏自动消失
    PSECSAdBUOpenRenderSuccess, //渲染成功
    PSECSAdBUOpenRenderFail, //渲染失败
    PSECSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PSECSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PSECSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PSECSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PSECSAdDidPresentFullScreen,//插屏弹出全屏广告
    PSECSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PSECSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PSECSAdPlayerStatusStarted,//开始播放
    PSECSAdPlayerStatusPaused,//用户行为导致暂停
    PSECSAdPlayerStatusStoped,//播放停止
    PSECSAdPlayerStatusError,//播放出错
    PSECSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PSECSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PSECSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PSECSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PSECSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PSECSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PSECSAdRecordImpression, //广告曝光已记录
    PSECSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PSECSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PSECSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PSECSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PSECSAdABUOpenWillPresentFullScreen,
    PSECSAdABUOpenDidShowFailed,
    PSECSAdABUOpenWillDissmissFullScreen,
    PSECSAdABUOpenCountdownToZero,
    
    PSECSAdABUBannerWillPresentFullScreen,
    PSECSAdABUBannerWillDismissFullScreen,
    
    PSECSAdABURewardDidLoad,
    PSECSAdABURewardRenderFail,
    PSECSAdABURewardDidShowFailed,

} PSECSAdEvent;

typedef void (^PSECSAdLoadCompleteBlock)(PSECSAdLoadStatus adLoadStatus);

@class PSECSAdSetupParamsMaker;
@class PSECSAdSetupParams;

typedef PSECSAdSetupParamsMaker *(^PSECSAdStringInit)(NSString *);
typedef PSECSAdSetupParamsMaker *(^PSECSAdBoolInit)(BOOL);
typedef PSECSAdSetupParamsMaker *(^PSECSAdIntegerInit)(NSInteger);
typedef PSECSAdSetupParamsMaker *(^PSECSAdLongInit)(long);
typedef PSECSAdSetupParamsMaker *(^PSECSAdArrayInit)(NSArray *);
typedef PSECSAdSetupParams *(^PSECSAdMakeInit)(void);


@class PSECSAdDataModel;
typedef void (^PSECSAdRequestCompleteBlock)(NSMutableArray<PSECSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PSECSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PSECSAdPreloadCompleteBlock)(PSECSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
