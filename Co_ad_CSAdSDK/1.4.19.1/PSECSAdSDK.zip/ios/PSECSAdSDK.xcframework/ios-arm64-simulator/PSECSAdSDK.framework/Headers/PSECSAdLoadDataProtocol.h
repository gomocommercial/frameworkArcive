//
//  PSECSAdLoadDataProtocol.h
//  PSECSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PSECSAdTypedef.h"

@class PSECSAdDataModel;
@class PSECSAdLoadBase;

@protocol PSECSAdLoadProtocol;

@protocol PSECSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)pSEonAdInfoFinish:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)pSEonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)pSEonAdFail:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload error:(NSError *)error;
@end
