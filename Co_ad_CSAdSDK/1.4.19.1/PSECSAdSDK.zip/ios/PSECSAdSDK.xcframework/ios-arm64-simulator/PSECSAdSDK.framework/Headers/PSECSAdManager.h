//
//  PSECSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PSECSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)pSEloadAd:(NSString *)moduleId delegate:(id<PSECSAdLoadDataProtocol>)delegate;

- (void)pSEloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<PSECSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)pSEremoveData:(id)obj;
- (NSDictionary *)getDevicesInfo;

@end

NS_ASSUME_NONNULL_END
