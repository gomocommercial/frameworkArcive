//
//  PSECSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pSEkAdvDataSourceFacebook   2 //FB 广告数据源
#define pSEkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pSEkAdvDataSourceMopub      39//Mopub 广告数据源
#define pSEkAdvDataSourceApplovin   20//applovin 广告数据源

#define pSEkAdvDataSourceGDT        62//广点通 广告数据源
#define pSEkAdvDataSourceBaidu      63//百度 广告数据源
#define pSEkAdvDataSourceBU         64//头条 广告数据源
#define pSEkAdvDataSourceABU         70//头条聚合 广告数据源
#define pSEkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pSEkAdvDataSourcePangle     74//pangle 广告数据源
#define pSEkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define pSEkOnlineAdvTypeBanner                   1  //banner
#define pSEkOnlineAdvTypeInterstitial             2  //全屏
#define pSEkOnlineAdvTypeNative                   3 //native
#define pSEkOnlineAdvTypeVideo                    4 //视频
#define pSEkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pSEkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pSEkOnlineAdvTypeOpen                     8 //开屏
#define pSEkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pSEkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pSEkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pSEkAdServerConfigError  -1 //服务器返回数据不正确
#define pSEkAdLoadConfigFailed  -2 //广告加载失败


#define pSEAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pSEkCSAdInstallDays @"pSEkCSAdInstallDays"
#define pSEkCSAdModule_key @"pSEkCSAdModule_key_%@"
#define pSEkCSNewAdModule_key @"pSEkCSNewAdModule_key_%@"
#define pSEkCSAdInstallTime @"pSEkCSAdInstallTime"
#define pSEkCSAdInstallHours @"pSEkCSAdInstallHours"
#define pSEkCSAdLastGetServerTime @"pSEkCSAdLastRequestTime"
#define pSEkCSAdloadTime 30

#define pSEkCSLoadAdTimeOutNotification @"pSEKCSLoadAdTimeOutNotification"
#define pSEkCSLoadAdTimeOutNotificationKey @"pSEKCSLoadAdTimeOutKey"

