//
//  PSECSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PSECSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdLoadInterstitial : PSECSAdLoadBase


@end

NS_ASSUME_NONNULL_END
