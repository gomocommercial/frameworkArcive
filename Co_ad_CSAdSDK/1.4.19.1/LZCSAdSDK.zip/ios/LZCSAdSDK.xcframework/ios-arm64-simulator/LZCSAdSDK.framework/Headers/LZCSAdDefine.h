//
//  LZCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define lZkAdvDataSourceFacebook   2 //FB 广告数据源
#define lZkAdvDataSourceAdmob      8 //Admob 广告数据源
#define lZkAdvDataSourceMopub      39//Mopub 广告数据源
#define lZkAdvDataSourceApplovin   20//applovin 广告数据源

#define lZkAdvDataSourceGDT        62//广点通 广告数据源
#define lZkAdvDataSourceBaidu      63//百度 广告数据源
#define lZkAdvDataSourceBU         64//头条 广告数据源
#define lZkAdvDataSourceABU         70//头条聚合 广告数据源
#define lZkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define lZkAdvDataSourcePangle     74//pangle 广告数据源
#define lZkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define lZkOnlineAdvTypeBanner                   1  //banner
#define lZkOnlineAdvTypeInterstitial             2  //全屏
#define lZkOnlineAdvTypeNative                   3 //native
#define lZkOnlineAdvTypeVideo                    4 //视频
#define lZkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define lZkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define lZkOnlineAdvTypeOpen                     8 //开屏
#define lZkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define lZkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define lZkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define lZkAdServerConfigError  -1 //服务器返回数据不正确
#define lZkAdLoadConfigFailed  -2 //广告加载失败


#define lZAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define lZkCSAdInstallDays @"lZkCSAdInstallDays"
#define lZkCSAdModule_key @"lZkCSAdModule_key_%@"
#define lZkCSNewAdModule_key @"lZkCSNewAdModule_key_%@"
#define lZkCSAdInstallTime @"lZkCSAdInstallTime"
#define lZkCSAdInstallHours @"lZkCSAdInstallHours"
#define lZkCSAdLastGetServerTime @"lZkCSAdLastRequestTime"
#define lZkCSAdloadTime 30

#define lZkCSLoadAdTimeOutNotification @"lZKCSLoadAdTimeOutNotification"
#define lZkCSLoadAdTimeOutNotificationKey @"lZKCSLoadAdTimeOutKey"

