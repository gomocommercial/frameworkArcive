//
//  LZCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LZCSAdTypedef.h"

@class LZCSAdLoadBase;

@protocol LZCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LZCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lZonAdShowed:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)lZonAdClicked:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lZonAdClosed:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lZonAdVideoCompletePlaying:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)lZonAdVideoGotReward:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload;
-(void)lZonAdDidPayRevenue:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)lZonAdDidGetEcpm:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)lZonAdShowFail:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lZonAdOtherEvent:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload event:(LZCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
