//
//  LZCSAdNetworkTool.h
//  LZCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "LZCSAdDataModel.h"
#import "LZCSAdTypedef.h"
#import "LZCSNewStoreLiteRequestTool.h"
#import "NSString+LZCSGenerateHash.h"

@interface LZCSAdNetworkTool : NSObject

+ (LZCSAdNetworkTool *)shared;
@property(nonatomic, copy) LZCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)lZrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(LZCSAdRequestCompleteBlock)complete;

- (void)lZsetCDay:(void(^ _Nullable)(bool success))handle;
@end
