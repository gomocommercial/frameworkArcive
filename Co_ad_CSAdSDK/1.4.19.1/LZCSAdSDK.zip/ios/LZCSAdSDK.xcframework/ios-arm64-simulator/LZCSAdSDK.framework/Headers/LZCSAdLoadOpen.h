//
//  LZCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "LZCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZCSAdLoadOpen : LZCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
