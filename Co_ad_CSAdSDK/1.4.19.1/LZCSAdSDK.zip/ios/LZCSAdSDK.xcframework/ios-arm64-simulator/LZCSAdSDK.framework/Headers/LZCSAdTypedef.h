//
//  LZCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    LZCSAdLoadSuccess = 1,
    LZCSAdLoadFailure = -1,
    LZCSAdLoadTimeout = -2
} LZCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    LZCSAdPreloadSuccess = 1,
    //预加载失败
    LZCSAdPreloadFailure = -1,
    //重复加载
    LZCSAdPreloadRepeat = -2,
} LZCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    LZCSAdWillAppear,//即将出现
    LZCSAdDidAppear,//已经出现
    LZCSAdWillDisappear,//即将消失
    LZCSAdDidDisappear,//已经消失
    LZCSAdMuted,//静音广告
    LZCSAdWillLeaveApplication,//将要离开App

    LZCSAdVideoStart,//开始播放 常用于video
    LZCSAdVideoComplete,//播放完成 常用于video
    LZCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    LZCSAdVideoServerFail,//连接服务器成功，常用于fb video

    LZCSAdNativeDidDownload,//下载完成 常用于fb Native
    LZCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    LZCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    LZCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    LZCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    LZCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    LZCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    LZCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    LZCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    LZCSAdBUOpenDidAutoDimiss,//开屏自动消失
    LZCSAdBUOpenRenderSuccess, //渲染成功
    LZCSAdBUOpenRenderFail, //渲染失败
    LZCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    LZCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    LZCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    LZCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    LZCSAdDidPresentFullScreen,//插屏弹出全屏广告
    LZCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    LZCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    LZCSAdPlayerStatusStarted,//开始播放
    LZCSAdPlayerStatusPaused,//用户行为导致暂停
    LZCSAdPlayerStatusStoped,//播放停止
    LZCSAdPlayerStatusError,//播放出错
    LZCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    LZCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    LZCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    LZCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    LZCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    LZCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    LZCSAdRecordImpression, //广告曝光已记录
    LZCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    LZCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    LZCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    LZCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    LZCSAdABUOpenWillPresentFullScreen,
    LZCSAdABUOpenDidShowFailed,
    LZCSAdABUOpenWillDissmissFullScreen,
    LZCSAdABUOpenCountdownToZero,
    
    LZCSAdABUBannerWillPresentFullScreen,
    LZCSAdABUBannerWillDismissFullScreen,
    
    LZCSAdABURewardDidLoad,
    LZCSAdABURewardRenderFail,
    LZCSAdABURewardDidShowFailed,

} LZCSAdEvent;

typedef void (^LZCSAdLoadCompleteBlock)(LZCSAdLoadStatus adLoadStatus);

@class LZCSAdSetupParamsMaker;
@class LZCSAdSetupParams;

typedef LZCSAdSetupParamsMaker *(^LZCSAdStringInit)(NSString *);
typedef LZCSAdSetupParamsMaker *(^LZCSAdBoolInit)(BOOL);
typedef LZCSAdSetupParamsMaker *(^LZCSAdIntegerInit)(NSInteger);
typedef LZCSAdSetupParamsMaker *(^LZCSAdLongInit)(long);
typedef LZCSAdSetupParamsMaker *(^LZCSAdArrayInit)(NSArray *);
typedef LZCSAdSetupParams *(^LZCSAdMakeInit)(void);


@class LZCSAdDataModel;
typedef void (^LZCSAdRequestCompleteBlock)(NSMutableArray<LZCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^LZCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^LZCSAdPreloadCompleteBlock)(LZCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
