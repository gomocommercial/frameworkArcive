//
//  LZCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "LZCSAdLoadBase.h"
#import "LZCSAdDataModel.h"
#import "LZCSAdLoadProtocol.h"
#import "LZCSAdLoadDataProtocol.h"
#import "LZCSAdLoadShowProtocol.h"
#import "LZCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)lZsetupByBlock:(void (^ _Nonnull)(LZCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)lZloadAd:(NSString *)moduleId delegate:(id<LZCSAdLoadDataProtocol>)delegate;

+ (void)lZloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<LZCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)lZadShowStatistic:(LZCSAdDataModel *)dataModel adload:(nonnull LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)lZadClickStatistic:(LZCSAdDataModel *)dataModel adload:(nonnull LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)lZaddCustomFecher:(Class<LZCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
