//
//  LZCSAdLoadDataProtocol.h
//  LZCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "LZCSAdTypedef.h"

@class LZCSAdDataModel;
@class LZCSAdLoadBase;

@protocol LZCSAdLoadProtocol;

@protocol LZCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)lZonAdInfoFinish:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)lZonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)lZonAdFail:(LZCSAdLoadBase<LZCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
