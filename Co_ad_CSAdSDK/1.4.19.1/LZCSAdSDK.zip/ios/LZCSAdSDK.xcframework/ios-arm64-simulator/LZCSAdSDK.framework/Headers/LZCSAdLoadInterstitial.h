//
//  LZCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LZCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZCSAdLoadInterstitial : LZCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
