//
//  DCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "DCCSAdTypedef.h"

@class DCCSAdLoadBase;

@protocol DCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol DCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)dConAdShowed:(DCCSAdLoadBase<DCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)dConAdClicked:(DCCSAdLoadBase<DCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)dConAdClosed:(DCCSAdLoadBase<DCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)dConAdVideoCompletePlaying:(DCCSAdLoadBase<DCCSAdLoadProtocol> *)adload;
/**
 激励视频获得奖励
 */
-(void)dConAdVideoGotReward:(DCCSAdLoadBase<DCCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)dConAdShowFail:(DCCSAdLoadBase<DCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)dConAdOtherEvent:(DCCSAdLoadBase<DCCSAdLoadProtocol> *)adload event:(DCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
