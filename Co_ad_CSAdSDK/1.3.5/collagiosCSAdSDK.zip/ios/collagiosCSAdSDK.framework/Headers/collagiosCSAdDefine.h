//
//  collagiosCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define collagioskAdvDataSourceFacebook   2 //FB 广告数据源
#define collagioskAdvDataSourceAdmob      8 //Admob 广告数据源
#define collagioskAdvDataSourceMopub      39//Mopub 广告数据源
#define collagioskAdvDataSourceApplovin   20//applovin 广告数据源

#define collagioskAdvDataSourceGDT        62//广点通 广告数据源
#define collagioskAdvDataSourceBaidu      63//百度 广告数据源
#define collagioskAdvDataSourceBU         64//头条 广告数据源


#define collagioskOnlineAdvTypeBanner                   1  //banner
#define collagioskOnlineAdvTypeInterstitial             2  //全屏
#define collagioskOnlineAdvTypeNative                   3 //native
#define collagioskOnlineAdvTypeVideo                    4 //视频
#define collagioskOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define collagioskOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define collagioskOnlineAdvTypeOpen                     8 //开屏

#define collagioskAdServerConfigError  -1 //服务器返回数据不正确
#define collagioskAdLoadConfigFailed  -2 //广告加载失败


#define collagiosAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define collagioskCSAdInstallDays @"collagioskCSAdInstallDays"
#define collagioskCSAdModule_key @"collagioskCSAdModule_key_%@"
#define collagioskCSAdInstallTime @"collagioskCSAdInstallTime"
#define collagioskCSAdLastGetServerTime @"collagioskCSAdLastRequestTime"
#define collagioskCSAdloadTime 30

#define collagioskCSLoadAdTimeOutNotification @"collagiosKCSLoadAdTimeOutNotification"
#define collagioskCSLoadAdTimeOutNotificationKey @"collagiosKCSLoadAdTimeOutKey"

