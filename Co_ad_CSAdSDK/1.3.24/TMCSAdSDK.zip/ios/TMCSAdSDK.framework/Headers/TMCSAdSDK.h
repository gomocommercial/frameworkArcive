//
//  TMCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "TMCSAdLoadBase.h"
#import "TMCSAdDataModel.h"
#import "TMCSAdLoadProtocol.h"
#import "TMCSAdLoadDataProtocol.h"
#import "TMCSAdLoadShowProtocol.h"
#import "TMCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)tMsetupByBlock:(void (^ _Nonnull)(TMCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)tMloadAd:(NSString *)moduleId delegate:(id<TMCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)tMadShowStatistic:(TMCSAdDataModel *)dataModel adload:(nonnull TMCSAdLoadBase<TMCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)tMadClickStatistic:(TMCSAdDataModel *)dataModel adload:(nonnull TMCSAdLoadBase<TMCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)tMaddCustomFecher:(Class<TMCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
