//
//  TMCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tMkAdvDataSourceFacebook   2 //FB 广告数据源
#define tMkAdvDataSourceAdmob      8 //Admob 广告数据源
#define tMkAdvDataSourceMopub      39//Mopub 广告数据源
#define tMkAdvDataSourceApplovin   20//applovin 广告数据源

#define tMkAdvDataSourceGDT        62//广点通 广告数据源
#define tMkAdvDataSourceBaidu      63//百度 广告数据源
#define tMkAdvDataSourceBU         64//头条 广告数据源
#define tMkAdvDataSourceABU         70//头条聚合 广告数据源
#define tMkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define tMkAdvDataSourcePangle     74//pangle 广告数据源

#define tMkOnlineAdvTypeBanner                   1  //banner
#define tMkOnlineAdvTypeInterstitial             2  //全屏
#define tMkOnlineAdvTypeNative                   3 //native
#define tMkOnlineAdvTypeVideo                    4 //视频
#define tMkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define tMkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define tMkOnlineAdvTypeOpen                     8 //开屏
#define tMkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define tMkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define tMkAdServerConfigError  -1 //服务器返回数据不正确
#define tMkAdLoadConfigFailed  -2 //广告加载失败


#define tMAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tMkCSAdInstallDays @"tMkCSAdInstallDays"
#define tMkCSAdModule_key @"tMkCSAdModule_key_%@"
#define tMkCSNewAdModule_key @"tMkCSNewAdModule_key_%@"
#define tMkCSAdInstallTime @"tMkCSAdInstallTime"
#define tMkCSAdInstallHours @"tMkCSAdInstallHours"
#define tMkCSAdLastGetServerTime @"tMkCSAdLastRequestTime"
#define tMkCSAdloadTime 30

#define tMkCSLoadAdTimeOutNotification @"tMKCSLoadAdTimeOutNotification"
#define tMkCSLoadAdTimeOutNotificationKey @"tMKCSLoadAdTimeOutKey"

