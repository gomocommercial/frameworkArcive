//
//  SWCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SWCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SWCSAdLoadNative : SWCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
