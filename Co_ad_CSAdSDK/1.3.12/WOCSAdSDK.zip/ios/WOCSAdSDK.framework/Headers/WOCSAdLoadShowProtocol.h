//
//  WOCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "WOCSAdTypedef.h"

@class WOCSAdLoadBase;

@protocol WOCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol WOCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)wOonAdShowed:(WOCSAdLoadBase<WOCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)wOonAdClicked:(WOCSAdLoadBase<WOCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)wOonAdClosed:(WOCSAdLoadBase<WOCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)wOonAdVideoCompletePlaying:(WOCSAdLoadBase<WOCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)wOonAdShowFail:(WOCSAdLoadBase<WOCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)wOonAdOtherEvent:(WOCSAdLoadBase<WOCSAdLoadProtocol> *)adload event:(WOCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
