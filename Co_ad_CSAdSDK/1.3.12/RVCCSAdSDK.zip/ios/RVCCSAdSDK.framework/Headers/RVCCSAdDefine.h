//
//  RVCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define rVCkAdvDataSourceFacebook   2 //FB 广告数据源
#define rVCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define rVCkAdvDataSourceMopub      39//Mopub 广告数据源
#define rVCkAdvDataSourceApplovin   20//applovin 广告数据源

#define rVCkAdvDataSourceGDT        62//广点通 广告数据源
#define rVCkAdvDataSourceBaidu      63//百度 广告数据源
#define rVCkAdvDataSourceBU         64//头条 广告数据源
#define rVCkAdvDataSourceABU         70//头条聚合 广告数据源


#define rVCkOnlineAdvTypeBanner                   1  //banner
#define rVCkOnlineAdvTypeInterstitial             2  //全屏
#define rVCkOnlineAdvTypeNative                   3 //native
#define rVCkOnlineAdvTypeVideo                    4 //视频
#define rVCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define rVCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define rVCkOnlineAdvTypeOpen                     8 //开屏
#define rVCkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define rVCkAdServerConfigError  -1 //服务器返回数据不正确
#define rVCkAdLoadConfigFailed  -2 //广告加载失败


#define rVCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define rVCkCSAdInstallDays @"rVCkCSAdInstallDays"
#define rVCkCSAdModule_key @"rVCkCSAdModule_key_%@"
#define rVCkCSAdInstallTime @"rVCkCSAdInstallTime"
#define rVCkCSAdLastGetServerTime @"rVCkCSAdLastRequestTime"
#define rVCkCSAdloadTime 30

#define rVCkCSLoadAdTimeOutNotification @"rVCKCSLoadAdTimeOutNotification"
#define rVCkCSLoadAdTimeOutNotificationKey @"rVCKCSLoadAdTimeOutKey"

