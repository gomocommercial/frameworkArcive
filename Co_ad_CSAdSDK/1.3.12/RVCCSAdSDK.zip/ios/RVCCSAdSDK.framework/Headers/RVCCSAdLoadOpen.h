//
//  RVCCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "RVCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface RVCCSAdLoadOpen : RVCCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
