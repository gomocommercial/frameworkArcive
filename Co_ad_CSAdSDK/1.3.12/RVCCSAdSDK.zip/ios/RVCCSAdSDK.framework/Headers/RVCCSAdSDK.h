//
//  RVCCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "RVCCSAdLoadBase.h"
#import "RVCCSAdDataModel.h"
#import "RVCCSAdLoadProtocol.h"
#import "RVCCSAdLoadDataProtocol.h"
#import "RVCCSAdLoadShowProtocol.h"
#import "RVCCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface RVCCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)rVCsetupByBlock:(void (^ _Nonnull)(RVCCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)rVCloadAd:(NSString *)moduleId delegate:(id<RVCCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)rVCadShowStatistic:(RVCCSAdDataModel *)dataModel adload:(nonnull RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)rVCadClickStatistic:(RVCCSAdDataModel *)dataModel adload:(nonnull RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)rVCaddCustomFecher:(Class<RVCCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
