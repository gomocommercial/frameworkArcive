//
//  RVCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "RVCCSAdTypedef.h"

@class RVCCSAdLoadBase;

@protocol RVCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol RVCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)rVConAdShowed:(RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)rVConAdClicked:(RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)rVConAdClosed:(RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)rVConAdVideoCompletePlaying:(RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)rVConAdShowFail:(RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)rVConAdOtherEvent:(RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload event:(RVCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
