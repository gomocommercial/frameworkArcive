//
//  RVCCSAdLoadDataProtocol.h
//  RVCCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "RVCCSAdTypedef.h"

@class RVCCSAdDataModel;
@class RVCCSAdLoadBase;

@protocol RVCCSAdLoadProtocol;

@protocol RVCCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)rVConAdInfoFinish:(RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)rVConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)rVConAdFail:(RVCCSAdLoadBase<RVCCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
