//
//  RVCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    RVCCSAdLoadSuccess = 1,
    RVCCSAdLoadFailure = -1,
    RVCCSAdLoadTimeout = -2
} RVCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    RVCCSAdPreloadSuccess = 1,
    //预加载失败
    RVCCSAdPreloadFailure = -1,
    //重复加载
    RVCCSAdPreloadRepeat = -2,
} RVCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    RVCCSAdWillAppear,//即将出现
    RVCCSAdDidAppear,//已经出现
    RVCCSAdWillDisappear,//即将消失
    RVCCSAdDidDisappear,//已经消失
    RVCCSAdMuted,//静音广告
    RVCCSAdWillLeaveApplication,//将要离开App

    RVCCSAdVideoStart,//开始播放 常用于video
    RVCCSAdVideoComplete,//播放完成 常用于video
    RVCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    RVCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    RVCCSAdNativeDidDownload,//下载完成 常用于fb Native
    RVCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    RVCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    RVCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    RVCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    RVCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    RVCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    RVCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    RVCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    RVCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    RVCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    RVCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    RVCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    RVCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    RVCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    RVCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    RVCCSAdPlayerStatusStarted,//开始播放
    RVCCSAdPlayerStatusPaused,//用户行为导致暂停
    RVCCSAdPlayerStatusStoped,//播放停止
    RVCCSAdPlayerStatusError,//播放出错
    RVCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    RVCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    RVCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    RVCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    RVCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    RVCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    RVCCSAdRecordImpression, //广告曝光已记录
    RVCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    RVCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    RVCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    RVCCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    RVCCSAdABUOpenWillPresentFullScreen,
    RVCCSAdABUOpenDidShowFailed,
    RVCCSAdABUOpenWillDissmissFullScreen,
    RVCCSAdABUOpenCountdownToZero,
    
    RVCCSAdABUBannerWillPresentFullScreen,
    RVCCSAdABUBannerWillDismissFullScreen,
    
    RVCCSAdABURewardDidLoad,
    RVCCSAdABURewardRenderFail,
    RVCCSAdABURewardDidShowFailed,

} RVCCSAdEvent;

typedef void (^RVCCSAdLoadCompleteBlock)(RVCCSAdLoadStatus adLoadStatus);

@class RVCCSAdSetupParamsMaker;
@class RVCCSAdSetupParams;

typedef RVCCSAdSetupParamsMaker *(^RVCCSAdStringInit)(NSString *);
typedef RVCCSAdSetupParamsMaker *(^RVCCSAdBoolInit)(BOOL);
typedef RVCCSAdSetupParamsMaker *(^RVCCSAdIntegerInit)(NSInteger);
typedef RVCCSAdSetupParamsMaker *(^RVCCSAdLongInit)(long);
typedef RVCCSAdSetupParamsMaker *(^RVCCSAdArrayInit)(NSArray *);
typedef RVCCSAdSetupParams *(^RVCCSAdMakeInit)(void);


@class RVCCSAdDataModel;
typedef void (^RVCCSAdRequestCompleteBlock)(NSMutableArray<RVCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^RVCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^RVCCSAdPreloadCompleteBlock)(RVCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
