//
//  PCCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCCSAdLoadInterstitial : PCCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
