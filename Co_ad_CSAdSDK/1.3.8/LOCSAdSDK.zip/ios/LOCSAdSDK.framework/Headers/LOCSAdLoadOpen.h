//
//  LOCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "LOCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdLoadOpen : LOCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
