//
//  LOCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    LOCSAdLoadSuccess = 1,
    LOCSAdLoadFailure = -1,
    LOCSAdLoadTimeout = -2
} LOCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    LOCSAdPreloadSuccess = 1,
    //预加载失败
    LOCSAdPreloadFailure = -1,
    //重复加载
    LOCSAdPreloadRepeat = -2,
} LOCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    LOCSAdWillAppear,//即将出现
    LOCSAdDidAppear,//已经出现
    LOCSAdWillDisappear,//即将消失
    LOCSAdDidDisappear,//已经消失
    LOCSAdMuted,//静音广告
    LOCSAdWillLeaveApplication,//将要离开App

    LOCSAdVideoStart,//开始播放 常用于video
    LOCSAdVideoComplete,//播放完成 常用于video
    LOCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    LOCSAdVideoServerFail,//连接服务器成功，常用于fb video

    LOCSAdNativeDidDownload,//下载完成 常用于fb Native
    LOCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    LOCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    LOCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    LOCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    LOCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    LOCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    LOCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    LOCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    LOCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    LOCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    LOCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    LOCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    LOCSAdDidPresentFullScreen,//插屏弹出全屏广告
    LOCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    LOCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    LOCSAdPlayerStatusStarted,//开始播放
    LOCSAdPlayerStatusPaused,//用户行为导致暂停
    LOCSAdPlayerStatusStoped,//播放停止
    LOCSAdPlayerStatusError,//播放出错
    LOCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    LOCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    LOCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    LOCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    LOCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    LOCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    LOCSAdRecordImpression, //广告曝光已记录
    LOCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    LOCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    LOCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    LOCSAdDidDownloadVideo,//视频下载完成

} LOCSAdEvent;

typedef void (^LOCSAdLoadCompleteBlock)(LOCSAdLoadStatus adLoadStatus);

@class LOCSAdSetupParamsMaker;
@class LOCSAdSetupParams;

typedef LOCSAdSetupParamsMaker *(^LOCSAdStringInit)(NSString *);
typedef LOCSAdSetupParamsMaker *(^LOCSAdBoolInit)(BOOL);
typedef LOCSAdSetupParamsMaker *(^LOCSAdIntegerInit)(NSInteger);
typedef LOCSAdSetupParamsMaker *(^LOCSAdLongInit)(long);
typedef LOCSAdSetupParamsMaker *(^LOCSAdArrayInit)(NSArray *);
typedef LOCSAdSetupParams *(^LOCSAdMakeInit)(void);


@class LOCSAdDataModel;
typedef void (^LOCSAdRequestCompleteBlock)(NSMutableArray<LOCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^LOCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^LOCSAdPreloadCompleteBlock)(LOCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
