//
//  LOCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "LOCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdLoadInterstitial : LOCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
