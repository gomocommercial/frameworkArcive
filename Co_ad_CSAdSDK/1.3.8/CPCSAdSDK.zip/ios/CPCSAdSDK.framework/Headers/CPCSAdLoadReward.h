//
//  CPCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPCSAdLoadReward : CPCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
