//
//  CPCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CPCSAdLoadSuccess = 1,
    CPCSAdLoadFailure = -1,
    CPCSAdLoadTimeout = -2
} CPCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CPCSAdPreloadSuccess = 1,
    //预加载失败
    CPCSAdPreloadFailure = -1,
    //重复加载
    CPCSAdPreloadRepeat = -2,
} CPCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CPCSAdWillAppear,//即将出现
    CPCSAdDidAppear,//已经出现
    CPCSAdWillDisappear,//即将消失
    CPCSAdDidDisappear,//已经消失
    CPCSAdMuted,//静音广告
    CPCSAdWillLeaveApplication,//将要离开App

    CPCSAdVideoStart,//开始播放 常用于video
    CPCSAdVideoComplete,//播放完成 常用于video
    CPCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CPCSAdVideoServerFail,//连接服务器成功，常用于fb video

    CPCSAdNativeDidDownload,//下载完成 常用于fb Native
    CPCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CPCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CPCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CPCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CPCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CPCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    CPCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CPCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CPCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    CPCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CPCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CPCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CPCSAdDidPresentFullScreen,//插屏弹出全屏广告
    CPCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CPCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CPCSAdPlayerStatusStarted,//开始播放
    CPCSAdPlayerStatusPaused,//用户行为导致暂停
    CPCSAdPlayerStatusStoped,//播放停止
    CPCSAdPlayerStatusError,//播放出错
    CPCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CPCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CPCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CPCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CPCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CPCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CPCSAdRecordImpression, //广告曝光已记录
    CPCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CPCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CPCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    CPCSAdDidDownloadVideo,//视频下载完成

} CPCSAdEvent;

typedef void (^CPCSAdLoadCompleteBlock)(CPCSAdLoadStatus adLoadStatus);

@class CPCSAdSetupParamsMaker;
@class CPCSAdSetupParams;

typedef CPCSAdSetupParamsMaker *(^CPCSAdStringInit)(NSString *);
typedef CPCSAdSetupParamsMaker *(^CPCSAdBoolInit)(BOOL);
typedef CPCSAdSetupParamsMaker *(^CPCSAdIntegerInit)(NSInteger);
typedef CPCSAdSetupParamsMaker *(^CPCSAdLongInit)(long);
typedef CPCSAdSetupParamsMaker *(^CPCSAdArrayInit)(NSArray *);
typedef CPCSAdSetupParams *(^CPCSAdMakeInit)(void);


@class CPCSAdDataModel;
typedef void (^CPCSAdRequestCompleteBlock)(NSMutableArray<CPCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CPCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CPCSAdPreloadCompleteBlock)(CPCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
