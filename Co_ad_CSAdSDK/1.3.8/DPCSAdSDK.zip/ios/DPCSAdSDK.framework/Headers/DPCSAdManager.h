//
//  DPCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DPCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface DPCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)dPloadAd:(NSString *)moduleId delegate:(id<DPCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)dPremoveData:(id)obj;

@end

NS_ASSUME_NONNULL_END
