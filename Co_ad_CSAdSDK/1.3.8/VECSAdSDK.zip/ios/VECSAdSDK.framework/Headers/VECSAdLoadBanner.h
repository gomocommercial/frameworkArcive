//
//  VECSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "VECSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface VECSAdLoadBanner : VECSAdLoadBase

@end

NS_ASSUME_NONNULL_END
