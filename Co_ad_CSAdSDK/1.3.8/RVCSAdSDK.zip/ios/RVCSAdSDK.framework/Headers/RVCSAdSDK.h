//
//  RVCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "RVCSAdLoadBase.h"
#import "RVCSAdDataModel.h"
#import "RVCSAdLoadProtocol.h"
#import "RVCSAdLoadDataProtocol.h"
#import "RVCSAdLoadShowProtocol.h"
#import "RVCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface RVCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)rVsetupByBlock:(void (^ _Nonnull)(RVCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)rVloadAd:(NSString *)moduleId delegate:(id<RVCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)rVadShowStatistic:(RVCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)rVadClickStatistic:(RVCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)rVaddCustomFecher:(Class<RVCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
