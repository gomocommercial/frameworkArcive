//
//  SKCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "SKCSAdTypedef.h"

@class SKCSAdLoadBase;

@protocol SKCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol SKCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sKonAdShowed:(SKCSAdLoadBase<SKCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sKonAdClicked:(SKCSAdLoadBase<SKCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sKonAdClosed:(SKCSAdLoadBase<SKCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sKonAdVideoCompletePlaying:(SKCSAdLoadBase<SKCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)sKonAdShowFail:(SKCSAdLoadBase<SKCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sKonAdOtherEvent:(SKCSAdLoadBase<SKCSAdLoadProtocol> *)adload event:(SKCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
