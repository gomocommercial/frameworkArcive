//
//  SKCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SKCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SKCSAdLoadNative : SKCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
