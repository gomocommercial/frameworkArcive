//
//  SKCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sKkAdvDataSourceFacebook   2 //FB 广告数据源
#define sKkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sKkAdvDataSourceMopub      39//Mopub 广告数据源
#define sKkAdvDataSourceApplovin   20//applovin 广告数据源

#define sKkAdvDataSourceGDT        62//广点通 广告数据源
#define sKkAdvDataSourceBaidu      63//百度 广告数据源
#define sKkAdvDataSourceBU         64//头条 广告数据源


#define sKkOnlineAdvTypeBanner                   1  //banner
#define sKkOnlineAdvTypeInterstitial             2  //全屏
#define sKkOnlineAdvTypeNative                   3 //native
#define sKkOnlineAdvTypeVideo                    4 //视频
#define sKkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sKkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sKkOnlineAdvTypeOpen                     8 //开屏
#define sKkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define sKkAdServerConfigError  -1 //服务器返回数据不正确
#define sKkAdLoadConfigFailed  -2 //广告加载失败


#define sKAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sKkCSAdInstallDays @"sKkCSAdInstallDays"
#define sKkCSAdModule_key @"sKkCSAdModule_key_%@"
#define sKkCSAdInstallTime @"sKkCSAdInstallTime"
#define sKkCSAdLastGetServerTime @"sKkCSAdLastRequestTime"
#define sKkCSAdloadTime 30

#define sKkCSLoadAdTimeOutNotification @"sKKCSLoadAdTimeOutNotification"
#define sKkCSLoadAdTimeOutNotificationKey @"sKKCSLoadAdTimeOutKey"

