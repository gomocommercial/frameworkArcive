//
//  DCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    DCCSAdLoadSuccess = 1,
    DCCSAdLoadFailure = -1,
    DCCSAdLoadTimeout = -2
} DCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    DCCSAdPreloadSuccess = 1,
    //预加载失败
    DCCSAdPreloadFailure = -1,
    //重复加载
    DCCSAdPreloadRepeat = -2,
} DCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    DCCSAdWillAppear,//即将出现
    DCCSAdDidAppear,//已经出现
    DCCSAdWillDisappear,//即将消失
    DCCSAdDidDisappear,//已经消失
    DCCSAdMuted,//静音广告
    DCCSAdWillLeaveApplication,//将要离开App

    DCCSAdVideoStart,//开始播放 常用于video
    DCCSAdVideoComplete,//播放完成 常用于video
    DCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    DCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    DCCSAdNativeDidDownload,//下载完成 常用于fb Native
    DCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    DCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    DCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    DCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    DCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    DCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    DCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    DCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    DCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    DCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    DCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    DCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    DCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    DCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    DCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    DCCSAdPlayerStatusStarted,//开始播放
    DCCSAdPlayerStatusPaused,//用户行为导致暂停
    DCCSAdPlayerStatusStoped,//播放停止
    DCCSAdPlayerStatusError,//播放出错
    DCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    DCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    DCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    DCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    DCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    DCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    DCCSAdRecordImpression, //广告曝光已记录
    DCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    DCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    DCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    DCCSAdDidDownloadVideo,//视频下载完成

} DCCSAdEvent;

typedef void (^DCCSAdLoadCompleteBlock)(DCCSAdLoadStatus adLoadStatus);

@class DCCSAdSetupParamsMaker;
@class DCCSAdSetupParams;

typedef DCCSAdSetupParamsMaker *(^DCCSAdStringInit)(NSString *);
typedef DCCSAdSetupParamsMaker *(^DCCSAdBoolInit)(BOOL);
typedef DCCSAdSetupParamsMaker *(^DCCSAdIntegerInit)(NSInteger);
typedef DCCSAdSetupParamsMaker *(^DCCSAdLongInit)(long);
typedef DCCSAdSetupParamsMaker *(^DCCSAdArrayInit)(NSArray *);
typedef DCCSAdSetupParams *(^DCCSAdMakeInit)(void);


@class DCCSAdDataModel;
typedef void (^DCCSAdRequestCompleteBlock)(NSMutableArray<DCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^DCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^DCCSAdPreloadCompleteBlock)(DCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
