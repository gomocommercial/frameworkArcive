//
//  PHCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PHCSAdLoadSuccess = 1,
    PHCSAdLoadFailure = -1,
    PHCSAdLoadTimeout = -2
} PHCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PHCSAdPreloadSuccess = 1,
    //预加载失败
    PHCSAdPreloadFailure = -1,
    //重复加载
    PHCSAdPreloadRepeat = -2,
} PHCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PHCSAdWillAppear,//即将出现
    PHCSAdDidAppear,//已经出现
    PHCSAdWillDisappear,//即将消失
    PHCSAdDidDisappear,//已经消失
    PHCSAdMuted,//静音广告
    PHCSAdWillLeaveApplication,//将要离开App

    PHCSAdVideoStart,//开始播放 常用于video
    PHCSAdVideoComplete,//播放完成 常用于video
    PHCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PHCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PHCSAdNativeDidDownload,//下载完成 常用于fb Native
    PHCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PHCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PHCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PHCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PHCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PHCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PHCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PHCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PHCSAdBUOpenDidAutoDimiss,//开屏自动消失
    
    //穿山甲 Banner专用
    PHCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PHCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PHCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PHCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PHCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PHCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PHCSAdPlayerStatusStarted,//开始播放
    PHCSAdPlayerStatusPaused,//用户行为导致暂停
    PHCSAdPlayerStatusStoped,//播放停止
    PHCSAdPlayerStatusError,//播放出错
    PHCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PHCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PHCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PHCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PHCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PHCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PHCSAdRecordImpression, //广告曝光已记录
    PHCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PHCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PHCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PHCSAdDidDownloadVideo,//视频下载完成

} PHCSAdEvent;

typedef void (^PHCSAdLoadCompleteBlock)(PHCSAdLoadStatus adLoadStatus);

@class PHCSAdSetupParamsMaker;
@class PHCSAdSetupParams;

typedef PHCSAdSetupParamsMaker *(^PHCSAdStringInit)(NSString *);
typedef PHCSAdSetupParamsMaker *(^PHCSAdBoolInit)(BOOL);
typedef PHCSAdSetupParamsMaker *(^PHCSAdIntegerInit)(NSInteger);
typedef PHCSAdSetupParamsMaker *(^PHCSAdLongInit)(long);
typedef PHCSAdSetupParamsMaker *(^PHCSAdArrayInit)(NSArray *);
typedef PHCSAdSetupParams *(^PHCSAdMakeInit)(void);


@class PHCSAdDataModel;
typedef void (^PHCSAdRequestCompleteBlock)(NSMutableArray<PHCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PHCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PHCSAdPreloadCompleteBlock)(PHCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
