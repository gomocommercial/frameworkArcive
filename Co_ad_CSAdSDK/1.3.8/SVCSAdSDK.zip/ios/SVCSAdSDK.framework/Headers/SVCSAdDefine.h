//
//  SVCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sVkAdvDataSourceFacebook   2 //FB 广告数据源
#define sVkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sVkAdvDataSourceMopub      39//Mopub 广告数据源
#define sVkAdvDataSourceApplovin   20//applovin 广告数据源

#define sVkAdvDataSourceGDT        62//广点通 广告数据源
#define sVkAdvDataSourceBaidu      63//百度 广告数据源
#define sVkAdvDataSourceBU         64//头条 广告数据源


#define sVkOnlineAdvTypeBanner                   1  //banner
#define sVkOnlineAdvTypeInterstitial             2  //全屏
#define sVkOnlineAdvTypeNative                   3 //native
#define sVkOnlineAdvTypeVideo                    4 //视频
#define sVkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sVkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sVkOnlineAdvTypeOpen                     8 //开屏
#define sVkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define sVkAdServerConfigError  -1 //服务器返回数据不正确
#define sVkAdLoadConfigFailed  -2 //广告加载失败


#define sVAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sVkCSAdInstallDays @"sVkCSAdInstallDays"
#define sVkCSAdModule_key @"sVkCSAdModule_key_%@"
#define sVkCSAdInstallTime @"sVkCSAdInstallTime"
#define sVkCSAdLastGetServerTime @"sVkCSAdLastRequestTime"
#define sVkCSAdloadTime 30

#define sVkCSLoadAdTimeOutNotification @"sVKCSLoadAdTimeOutNotification"
#define sVkCSLoadAdTimeOutNotificationKey @"sVKCSLoadAdTimeOutKey"

