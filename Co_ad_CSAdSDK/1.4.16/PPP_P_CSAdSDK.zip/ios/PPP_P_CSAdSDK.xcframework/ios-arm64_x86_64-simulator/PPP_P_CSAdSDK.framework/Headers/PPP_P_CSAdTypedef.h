//
//  PPP_P_CSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PPP_P_CSAdLoadSuccess = 1,
    PPP_P_CSAdLoadFailure = -1,
    PPP_P_CSAdLoadTimeout = -2
} PPP_P_CSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PPP_P_CSAdPreloadSuccess = 1,
    //预加载失败
    PPP_P_CSAdPreloadFailure = -1,
    //重复加载
    PPP_P_CSAdPreloadRepeat = -2,
} PPP_P_CSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PPP_P_CSAdWillAppear,//即将出现
    PPP_P_CSAdDidAppear,//已经出现
    PPP_P_CSAdWillDisappear,//即将消失
    PPP_P_CSAdDidDisappear,//已经消失
    PPP_P_CSAdMuted,//静音广告
    PPP_P_CSAdWillLeaveApplication,//将要离开App

    PPP_P_CSAdVideoStart,//开始播放 常用于video
    PPP_P_CSAdVideoComplete,//播放完成 常用于video
    PPP_P_CSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PPP_P_CSAdVideoServerFail,//连接服务器成功，常用于fb video

    PPP_P_CSAdNativeDidDownload,//下载完成 常用于fb Native
    PPP_P_CSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PPP_P_CSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PPP_P_CSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PPP_P_CSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PPP_P_CSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PPP_P_CSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PPP_P_CSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PPP_P_CSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PPP_P_CSAdBUOpenDidAutoDimiss,//开屏自动消失
    PPP_P_CSAdBUOpenRenderSuccess, //渲染成功
    PPP_P_CSAdBUOpenRenderFail, //渲染失败
    PPP_P_CSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PPP_P_CSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PPP_P_CSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PPP_P_CSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PPP_P_CSAdDidPresentFullScreen,//插屏弹出全屏广告
    PPP_P_CSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PPP_P_CSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PPP_P_CSAdPlayerStatusStarted,//开始播放
    PPP_P_CSAdPlayerStatusPaused,//用户行为导致暂停
    PPP_P_CSAdPlayerStatusStoped,//播放停止
    PPP_P_CSAdPlayerStatusError,//播放出错
    PPP_P_CSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PPP_P_CSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PPP_P_CSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PPP_P_CSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PPP_P_CSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PPP_P_CSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PPP_P_CSAdRecordImpression, //广告曝光已记录
    PPP_P_CSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PPP_P_CSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PPP_P_CSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PPP_P_CSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PPP_P_CSAdABUOpenWillPresentFullScreen,
    PPP_P_CSAdABUOpenDidShowFailed,
    PPP_P_CSAdABUOpenWillDissmissFullScreen,
    PPP_P_CSAdABUOpenCountdownToZero,
    
    PPP_P_CSAdABUBannerWillPresentFullScreen,
    PPP_P_CSAdABUBannerWillDismissFullScreen,
    
    PPP_P_CSAdABURewardDidLoad,
    PPP_P_CSAdABURewardRenderFail,
    PPP_P_CSAdABURewardDidShowFailed,

} PPP_P_CSAdEvent;

typedef void (^PPP_P_CSAdLoadCompleteBlock)(PPP_P_CSAdLoadStatus adLoadStatus);

@class PPP_P_CSAdSetupParamsMaker;
@class PPP_P_CSAdSetupParams;

typedef PPP_P_CSAdSetupParamsMaker *(^PPP_P_CSAdStringInit)(NSString *);
typedef PPP_P_CSAdSetupParamsMaker *(^PPP_P_CSAdBoolInit)(BOOL);
typedef PPP_P_CSAdSetupParamsMaker *(^PPP_P_CSAdIntegerInit)(NSInteger);
typedef PPP_P_CSAdSetupParamsMaker *(^PPP_P_CSAdLongInit)(long);
typedef PPP_P_CSAdSetupParamsMaker *(^PPP_P_CSAdArrayInit)(NSArray *);
typedef PPP_P_CSAdSetupParams *(^PPP_P_CSAdMakeInit)(void);


@class PPP_P_CSAdDataModel;
typedef void (^PPP_P_CSAdRequestCompleteBlock)(NSMutableArray<PPP_P_CSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PPP_P_CSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PPP_P_CSAdPreloadCompleteBlock)(PPP_P_CSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
