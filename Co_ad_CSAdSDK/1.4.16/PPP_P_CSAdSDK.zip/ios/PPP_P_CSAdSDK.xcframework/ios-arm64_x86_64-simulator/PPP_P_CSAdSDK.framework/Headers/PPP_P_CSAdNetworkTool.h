//
//  PPP_P_CSAdNetworkTool.h
//  PPP_P_CSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PPP_P_CSAdDataModel.h"
#import "PPP_P_CSAdTypedef.h"
#import "PPP_P_CSNewStoreLiteRequestTool.h"
#import "NSString+PPP_P_CSGenerateHash.h"

@interface PPP_P_CSAdNetworkTool : NSObject

+ (PPP_P_CSAdNetworkTool *)shared;
@property(nonatomic, copy) PPP_P_CSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pPP_P_requestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PPP_P_CSAdRequestCompleteBlock)complete;

- (void)pPP_P_setCDay:(void(^ _Nullable)(bool success))handle;
@end
