//
//  PPP_P_CSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "PPP_P_CSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSAdLoadOpen : PPP_P_CSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
