//
//  PPP_P_CSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pPP_P_kAdvDataSourceFacebook   2 //FB 广告数据源
#define pPP_P_kAdvDataSourceAdmob      8 //Admob 广告数据源
#define pPP_P_kAdvDataSourceMopub      39//Mopub 广告数据源
#define pPP_P_kAdvDataSourceApplovin   20//applovin 广告数据源

#define pPP_P_kAdvDataSourceGDT        62//广点通 广告数据源
#define pPP_P_kAdvDataSourceBaidu      63//百度 广告数据源
#define pPP_P_kAdvDataSourceBU         64//头条 广告数据源
#define pPP_P_kAdvDataSourceABU         70//头条聚合 广告数据源
#define pPP_P_kAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pPP_P_kAdvDataSourcePangle     74//pangle 广告数据源

#define pPP_P_kOnlineAdvTypeBanner                   1  //banner
#define pPP_P_kOnlineAdvTypeInterstitial             2  //全屏
#define pPP_P_kOnlineAdvTypeNative                   3 //native
#define pPP_P_kOnlineAdvTypeVideo                    4 //视频
#define pPP_P_kOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pPP_P_kOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pPP_P_kOnlineAdvTypeOpen                     8 //开屏
#define pPP_P_kOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pPP_P_kOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pPP_P_kOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pPP_P_kAdServerConfigError  -1 //服务器返回数据不正确
#define pPP_P_kAdLoadConfigFailed  -2 //广告加载失败


#define pPP_P_AdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pPP_P_kCSAdInstallDays @"pPP_P_kCSAdInstallDays"
#define pPP_P_kCSAdModule_key @"pPP_P_kCSAdModule_key_%@"
#define pPP_P_kCSNewAdModule_key @"pPP_P_kCSNewAdModule_key_%@"
#define pPP_P_kCSAdInstallTime @"pPP_P_kCSAdInstallTime"
#define pPP_P_kCSAdInstallHours @"pPP_P_kCSAdInstallHours"
#define pPP_P_kCSAdLastGetServerTime @"pPP_P_kCSAdLastRequestTime"
#define pPP_P_kCSAdloadTime 30

#define pPP_P_kCSLoadAdTimeOutNotification @"pPP_P_KCSLoadAdTimeOutNotification"
#define pPP_P_kCSLoadAdTimeOutNotificationKey @"pPP_P_KCSLoadAdTimeOutKey"

