//
//  PPP_P_CSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PPP_P_CSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSAdLoadNative : PPP_P_CSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
