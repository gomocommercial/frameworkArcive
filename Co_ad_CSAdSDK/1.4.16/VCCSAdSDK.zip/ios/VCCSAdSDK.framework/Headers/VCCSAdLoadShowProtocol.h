//
//  VCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "VCCSAdTypedef.h"

@class VCCSAdLoadBase;

@protocol VCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol VCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)vConAdShowed:(VCCSAdLoadBase<VCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)vConAdClicked:(VCCSAdLoadBase<VCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)vConAdClosed:(VCCSAdLoadBase<VCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)vConAdVideoCompletePlaying:(VCCSAdLoadBase<VCCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)vConAdVideoGotReward:(VCCSAdLoadBase<VCCSAdLoadProtocol> *)adload;
-(void)vConAdDidPayRevenue:(VCCSAdLoadBase<VCCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)vConAdShowFail:(VCCSAdLoadBase<VCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)vConAdOtherEvent:(VCCSAdLoadBase<VCCSAdLoadProtocol> *)adload event:(VCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
