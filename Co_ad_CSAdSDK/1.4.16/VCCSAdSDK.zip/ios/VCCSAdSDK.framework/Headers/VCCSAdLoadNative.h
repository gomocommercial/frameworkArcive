//
//  VCCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "VCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface VCCSAdLoadNative : VCCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
