//
//  VCCSAdNetworkTool.h
//  VCCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "VCCSAdDataModel.h"
#import "VCCSAdTypedef.h"
#import "VCCSNewStoreLiteRequestTool.h"
#import "NSString+VCCSGenerateHash.h"

@interface VCCSAdNetworkTool : NSObject

+ (VCCSAdNetworkTool *)shared;
@property(nonatomic, copy) VCCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)vCrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(VCCSAdRequestCompleteBlock)complete;

- (void)vCsetCDay:(void(^ _Nullable)(bool success))handle;
@end
