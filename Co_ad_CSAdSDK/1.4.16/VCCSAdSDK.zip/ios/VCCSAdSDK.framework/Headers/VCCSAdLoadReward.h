//
//  VCCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "VCCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface VCCSAdLoadReward : VCCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
