//
//  SSACSAdNetworkTool.h
//  SSACSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "SSACSAdDataModel.h"
#import "SSACSAdTypedef.h"
#import "SSACSNewStoreLiteRequestTool.h"
#import "NSString+SSACSGenerateHash.h"

@interface SSACSAdNetworkTool : NSObject

+ (SSACSAdNetworkTool *)shared;
@property(nonatomic, copy) SSACSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sSArequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(SSACSAdRequestCompleteBlock)complete;

- (void)sSAsetCDay:(void(^ _Nullable)(bool success))handle;
@end
