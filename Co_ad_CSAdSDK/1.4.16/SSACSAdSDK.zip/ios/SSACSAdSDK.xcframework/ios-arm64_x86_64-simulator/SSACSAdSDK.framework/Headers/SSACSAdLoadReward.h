//
//  SSACSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SSACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SSACSAdLoadReward : SSACSAdLoadBase

@end

NS_ASSUME_NONNULL_END
