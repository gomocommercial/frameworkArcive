//
//  SSACSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "SSACSAdTypedef.h"

@class SSACSAdLoadBase;

@protocol SSACSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol SSACSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sSAonAdShowed:(SSACSAdLoadBase<SSACSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sSAonAdClicked:(SSACSAdLoadBase<SSACSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sSAonAdClosed:(SSACSAdLoadBase<SSACSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sSAonAdVideoCompletePlaying:(SSACSAdLoadBase<SSACSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sSAonAdVideoGotReward:(SSACSAdLoadBase<SSACSAdLoadProtocol> *)adload;
-(void)sSAonAdDidPayRevenue:(SSACSAdLoadBase<SSACSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)sSAonAdShowFail:(SSACSAdLoadBase<SSACSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sSAonAdOtherEvent:(SSACSAdLoadBase<SSACSAdLoadProtocol> *)adload event:(SSACSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
