//
//  SSACSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sSAkAdvDataSourceFacebook   2 //FB 广告数据源
#define sSAkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sSAkAdvDataSourceMopub      39//Mopub 广告数据源
#define sSAkAdvDataSourceApplovin   20//applovin 广告数据源

#define sSAkAdvDataSourceGDT        62//广点通 广告数据源
#define sSAkAdvDataSourceBaidu      63//百度 广告数据源
#define sSAkAdvDataSourceBU         64//头条 广告数据源
#define sSAkAdvDataSourceABU         70//头条聚合 广告数据源
#define sSAkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define sSAkAdvDataSourcePangle     74//pangle 广告数据源

#define sSAkOnlineAdvTypeBanner                   1  //banner
#define sSAkOnlineAdvTypeInterstitial             2  //全屏
#define sSAkOnlineAdvTypeNative                   3 //native
#define sSAkOnlineAdvTypeVideo                    4 //视频
#define sSAkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sSAkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sSAkOnlineAdvTypeOpen                     8 //开屏
#define sSAkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define sSAkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define sSAkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define sSAkAdServerConfigError  -1 //服务器返回数据不正确
#define sSAkAdLoadConfigFailed  -2 //广告加载失败


#define sSAAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sSAkCSAdInstallDays @"sSAkCSAdInstallDays"
#define sSAkCSAdModule_key @"sSAkCSAdModule_key_%@"
#define sSAkCSNewAdModule_key @"sSAkCSNewAdModule_key_%@"
#define sSAkCSAdInstallTime @"sSAkCSAdInstallTime"
#define sSAkCSAdInstallHours @"sSAkCSAdInstallHours"
#define sSAkCSAdLastGetServerTime @"sSAkCSAdLastRequestTime"
#define sSAkCSAdloadTime 30

#define sSAkCSLoadAdTimeOutNotification @"sSAKCSLoadAdTimeOutNotification"
#define sSAkCSLoadAdTimeOutNotificationKey @"sSAKCSLoadAdTimeOutKey"

