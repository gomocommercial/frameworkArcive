//
//  SSACSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    SSACSAdLoadSuccess = 1,
    SSACSAdLoadFailure = -1,
    SSACSAdLoadTimeout = -2
} SSACSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    SSACSAdPreloadSuccess = 1,
    //预加载失败
    SSACSAdPreloadFailure = -1,
    //重复加载
    SSACSAdPreloadRepeat = -2,
} SSACSAdPreloadStatus;


typedef enum : NSUInteger {
    
    SSACSAdWillAppear,//即将出现
    SSACSAdDidAppear,//已经出现
    SSACSAdWillDisappear,//即将消失
    SSACSAdDidDisappear,//已经消失
    SSACSAdMuted,//静音广告
    SSACSAdWillLeaveApplication,//将要离开App

    SSACSAdVideoStart,//开始播放 常用于video
    SSACSAdVideoComplete,//播放完成 常用于video
    SSACSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    SSACSAdVideoServerFail,//连接服务器成功，常用于fb video

    SSACSAdNativeDidDownload,//下载完成 常用于fb Native
    SSACSAdNativeFinishClick,//完成点击 常用与fb Native
    
    SSACSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    SSACSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    SSACSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    SSACSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    SSACSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    SSACSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    SSACSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    SSACSAdBUOpenDidAutoDimiss,//开屏自动消失
    SSACSAdBUOpenRenderSuccess, //渲染成功
    SSACSAdBUOpenRenderFail, //渲染失败
    SSACSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    SSACSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    SSACSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    SSACSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    SSACSAdDidPresentFullScreen,//插屏弹出全屏广告
    SSACSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    SSACSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    SSACSAdPlayerStatusStarted,//开始播放
    SSACSAdPlayerStatusPaused,//用户行为导致暂停
    SSACSAdPlayerStatusStoped,//播放停止
    SSACSAdPlayerStatusError,//播放出错
    SSACSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    SSACSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    SSACSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    SSACSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    SSACSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    SSACSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    SSACSAdRecordImpression, //广告曝光已记录
    SSACSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    SSACSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    SSACSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    SSACSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    SSACSAdABUOpenWillPresentFullScreen,
    SSACSAdABUOpenDidShowFailed,
    SSACSAdABUOpenWillDissmissFullScreen,
    SSACSAdABUOpenCountdownToZero,
    
    SSACSAdABUBannerWillPresentFullScreen,
    SSACSAdABUBannerWillDismissFullScreen,
    
    SSACSAdABURewardDidLoad,
    SSACSAdABURewardRenderFail,
    SSACSAdABURewardDidShowFailed,

} SSACSAdEvent;

typedef void (^SSACSAdLoadCompleteBlock)(SSACSAdLoadStatus adLoadStatus);

@class SSACSAdSetupParamsMaker;
@class SSACSAdSetupParams;

typedef SSACSAdSetupParamsMaker *(^SSACSAdStringInit)(NSString *);
typedef SSACSAdSetupParamsMaker *(^SSACSAdBoolInit)(BOOL);
typedef SSACSAdSetupParamsMaker *(^SSACSAdIntegerInit)(NSInteger);
typedef SSACSAdSetupParamsMaker *(^SSACSAdLongInit)(long);
typedef SSACSAdSetupParamsMaker *(^SSACSAdArrayInit)(NSArray *);
typedef SSACSAdSetupParams *(^SSACSAdMakeInit)(void);


@class SSACSAdDataModel;
typedef void (^SSACSAdRequestCompleteBlock)(NSMutableArray<SSACSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^SSACSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^SSACSAdPreloadCompleteBlock)(SSACSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
