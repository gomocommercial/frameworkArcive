//
//  PFCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PFCSAdTypedef.h"

@class PFCSAdLoadBase;

@protocol PFCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PFCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pFonAdShowed:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pFonAdClicked:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pFonAdClosed:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pFonAdVideoCompletePlaying:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pFonAdVideoGotReward:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload;
-(void)pFonAdDidPayRevenue:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)pFonAdShowFail:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pFonAdOtherEvent:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload event:(PFCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
