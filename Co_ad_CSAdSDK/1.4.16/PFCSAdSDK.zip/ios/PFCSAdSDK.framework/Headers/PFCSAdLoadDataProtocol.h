//
//  PFCSAdLoadDataProtocol.h
//  PFCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "PFCSAdTypedef.h"

@class PFCSAdDataModel;
@class PFCSAdLoadBase;

@protocol PFCSAdLoadProtocol;

@protocol PFCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)pFonAdInfoFinish:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)pFonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)pFonAdFail:(PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
