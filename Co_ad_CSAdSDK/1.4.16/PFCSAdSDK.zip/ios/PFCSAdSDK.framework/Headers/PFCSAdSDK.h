//
//  PFCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PFCSAdLoadBase.h"
#import "PFCSAdDataModel.h"
#import "PFCSAdLoadProtocol.h"
#import "PFCSAdLoadDataProtocol.h"
#import "PFCSAdLoadShowProtocol.h"
#import "PFCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PFCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pFsetupByBlock:(void (^ _Nonnull)(PFCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pFloadAd:(NSString *)moduleId delegate:(id<PFCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pFadShowStatistic:(PFCSAdDataModel *)dataModel adload:(nonnull PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pFadClickStatistic:(PFCSAdDataModel *)dataModel adload:(nonnull PFCSAdLoadBase<PFCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pFaddCustomFecher:(Class<PFCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
