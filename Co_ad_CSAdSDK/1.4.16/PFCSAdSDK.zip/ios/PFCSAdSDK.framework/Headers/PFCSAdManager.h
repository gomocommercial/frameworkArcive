//
//  PFCSAdManager.h
//  AdDemo
//
//  Created by Zy on 2019/3/13.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PFCSAdLoadDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface PFCSAdManager : NSObject

@property (nonatomic, strong) NSMutableArray *loadDatas;

+ (instancetype)sharedInstance;

//开始加载广告配置
- (void)pFloadAd:(NSString *)moduleId delegate:(id<PFCSAdLoadDataProtocol>)delegate;

//删除广告实体数据(SDK自动管理无需调用)
- (void)pFremoveData:(id)obj;
- (NSDictionary *)getDevicesInfo;

@end

NS_ASSUME_NONNULL_END
