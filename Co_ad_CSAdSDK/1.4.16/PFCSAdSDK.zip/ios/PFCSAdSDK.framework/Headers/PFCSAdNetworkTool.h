//
//  PFCSAdNetworkTool.h
//  PFCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PFCSAdDataModel.h"
#import "PFCSAdTypedef.h"
#import "PFCSNewStoreLiteRequestTool.h"
#import "NSString+PFCSGenerateHash.h"

@interface PFCSAdNetworkTool : NSObject

+ (PFCSAdNetworkTool *)shared;
@property(nonatomic, copy) PFCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pFrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PFCSAdRequestCompleteBlock)complete;

- (void)pFsetCDay:(void(^ _Nullable)(bool success))handle;
@end
