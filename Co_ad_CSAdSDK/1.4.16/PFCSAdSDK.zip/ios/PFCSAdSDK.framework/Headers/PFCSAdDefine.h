//
//  PFCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pFkAdvDataSourceFacebook   2 //FB 广告数据源
#define pFkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pFkAdvDataSourceMopub      39//Mopub 广告数据源
#define pFkAdvDataSourceApplovin   20//applovin 广告数据源

#define pFkAdvDataSourceGDT        62//广点通 广告数据源
#define pFkAdvDataSourceBaidu      63//百度 广告数据源
#define pFkAdvDataSourceBU         64//头条 广告数据源
#define pFkAdvDataSourceABU         70//头条聚合 广告数据源
#define pFkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pFkAdvDataSourcePangle     74//pangle 广告数据源

#define pFkOnlineAdvTypeBanner                   1  //banner
#define pFkOnlineAdvTypeInterstitial             2  //全屏
#define pFkOnlineAdvTypeNative                   3 //native
#define pFkOnlineAdvTypeVideo                    4 //视频
#define pFkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pFkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pFkOnlineAdvTypeOpen                     8 //开屏
#define pFkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pFkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pFkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pFkAdServerConfigError  -1 //服务器返回数据不正确
#define pFkAdLoadConfigFailed  -2 //广告加载失败


#define pFAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pFkCSAdInstallDays @"pFkCSAdInstallDays"
#define pFkCSAdModule_key @"pFkCSAdModule_key_%@"
#define pFkCSNewAdModule_key @"pFkCSNewAdModule_key_%@"
#define pFkCSAdInstallTime @"pFkCSAdInstallTime"
#define pFkCSAdInstallHours @"pFkCSAdInstallHours"
#define pFkCSAdLastGetServerTime @"pFkCSAdLastRequestTime"
#define pFkCSAdloadTime 30

#define pFkCSLoadAdTimeOutNotification @"pFKCSLoadAdTimeOutNotification"
#define pFkCSLoadAdTimeOutNotificationKey @"pFKCSLoadAdTimeOutKey"

