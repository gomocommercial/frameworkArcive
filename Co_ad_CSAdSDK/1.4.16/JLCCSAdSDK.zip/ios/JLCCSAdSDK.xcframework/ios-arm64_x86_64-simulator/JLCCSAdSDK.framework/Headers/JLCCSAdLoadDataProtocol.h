//
//  JLCCSAdLoadDataProtocol.h
//  JLCCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "JLCCSAdTypedef.h"

@class JLCCSAdDataModel;
@class JLCCSAdLoadBase;

@protocol JLCCSAdLoadProtocol;

@protocol JLCCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)jLConAdInfoFinish:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)jLConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)jLConAdFail:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
