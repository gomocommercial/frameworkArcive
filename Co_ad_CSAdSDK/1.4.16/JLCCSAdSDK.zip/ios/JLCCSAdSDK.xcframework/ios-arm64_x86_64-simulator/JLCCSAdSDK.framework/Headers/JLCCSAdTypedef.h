//
//  JLCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    JLCCSAdLoadSuccess = 1,
    JLCCSAdLoadFailure = -1,
    JLCCSAdLoadTimeout = -2
} JLCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    JLCCSAdPreloadSuccess = 1,
    //预加载失败
    JLCCSAdPreloadFailure = -1,
    //重复加载
    JLCCSAdPreloadRepeat = -2,
} JLCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    JLCCSAdWillAppear,//即将出现
    JLCCSAdDidAppear,//已经出现
    JLCCSAdWillDisappear,//即将消失
    JLCCSAdDidDisappear,//已经消失
    JLCCSAdMuted,//静音广告
    JLCCSAdWillLeaveApplication,//将要离开App

    JLCCSAdVideoStart,//开始播放 常用于video
    JLCCSAdVideoComplete,//播放完成 常用于video
    JLCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    JLCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    JLCCSAdNativeDidDownload,//下载完成 常用于fb Native
    JLCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    JLCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    JLCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    JLCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    JLCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    JLCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    JLCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    JLCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    JLCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    JLCCSAdBUOpenRenderSuccess, //渲染成功
    JLCCSAdBUOpenRenderFail, //渲染失败
    JLCCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    JLCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    JLCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    JLCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    JLCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    JLCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    JLCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    JLCCSAdPlayerStatusStarted,//开始播放
    JLCCSAdPlayerStatusPaused,//用户行为导致暂停
    JLCCSAdPlayerStatusStoped,//播放停止
    JLCCSAdPlayerStatusError,//播放出错
    JLCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    JLCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    JLCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    JLCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    JLCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    JLCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    JLCCSAdRecordImpression, //广告曝光已记录
    JLCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    JLCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    JLCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    JLCCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    JLCCSAdABUOpenWillPresentFullScreen,
    JLCCSAdABUOpenDidShowFailed,
    JLCCSAdABUOpenWillDissmissFullScreen,
    JLCCSAdABUOpenCountdownToZero,
    
    JLCCSAdABUBannerWillPresentFullScreen,
    JLCCSAdABUBannerWillDismissFullScreen,
    
    JLCCSAdABURewardDidLoad,
    JLCCSAdABURewardRenderFail,
    JLCCSAdABURewardDidShowFailed,

} JLCCSAdEvent;

typedef void (^JLCCSAdLoadCompleteBlock)(JLCCSAdLoadStatus adLoadStatus);

@class JLCCSAdSetupParamsMaker;
@class JLCCSAdSetupParams;

typedef JLCCSAdSetupParamsMaker *(^JLCCSAdStringInit)(NSString *);
typedef JLCCSAdSetupParamsMaker *(^JLCCSAdBoolInit)(BOOL);
typedef JLCCSAdSetupParamsMaker *(^JLCCSAdIntegerInit)(NSInteger);
typedef JLCCSAdSetupParamsMaker *(^JLCCSAdLongInit)(long);
typedef JLCCSAdSetupParamsMaker *(^JLCCSAdArrayInit)(NSArray *);
typedef JLCCSAdSetupParams *(^JLCCSAdMakeInit)(void);


@class JLCCSAdDataModel;
typedef void (^JLCCSAdRequestCompleteBlock)(NSMutableArray<JLCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^JLCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^JLCCSAdPreloadCompleteBlock)(JLCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
