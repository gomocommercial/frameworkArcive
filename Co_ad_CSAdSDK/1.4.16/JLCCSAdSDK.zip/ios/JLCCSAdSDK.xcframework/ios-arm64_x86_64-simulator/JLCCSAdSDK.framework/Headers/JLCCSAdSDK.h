//
//  JLCCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "JLCCSAdLoadBase.h"
#import "JLCCSAdDataModel.h"
#import "JLCCSAdLoadProtocol.h"
#import "JLCCSAdLoadDataProtocol.h"
#import "JLCCSAdLoadShowProtocol.h"
#import "JLCCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)jLCsetupByBlock:(void (^ _Nonnull)(JLCCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)jLCloadAd:(NSString *)moduleId delegate:(id<JLCCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)jLCadShowStatistic:(JLCCSAdDataModel *)dataModel adload:(nonnull JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)jLCadClickStatistic:(JLCCSAdDataModel *)dataModel adload:(nonnull JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)jLCaddCustomFecher:(Class<JLCCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
