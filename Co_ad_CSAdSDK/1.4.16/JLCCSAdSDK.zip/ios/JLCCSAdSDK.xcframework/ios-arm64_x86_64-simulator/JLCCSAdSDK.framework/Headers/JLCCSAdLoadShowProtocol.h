//
//  JLCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "JLCCSAdTypedef.h"

@class JLCCSAdLoadBase;

@protocol JLCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol JLCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)jLConAdShowed:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)jLConAdClicked:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)jLConAdClosed:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)jLConAdVideoCompletePlaying:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)jLConAdVideoGotReward:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload;
-(void)jLConAdDidPayRevenue:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)jLConAdShowFail:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)jLConAdOtherEvent:(JLCCSAdLoadBase<JLCCSAdLoadProtocol> *)adload event:(JLCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
