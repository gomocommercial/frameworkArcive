//
//  JLCCSAdNetworkTool.h
//  JLCCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "JLCCSAdDataModel.h"
#import "JLCCSAdTypedef.h"
#import "JLCCSNewStoreLiteRequestTool.h"
#import "NSString+JLCCSGenerateHash.h"

@interface JLCCSAdNetworkTool : NSObject

+ (JLCCSAdNetworkTool *)shared;
@property(nonatomic, copy) JLCCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)jLCrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(JLCCSAdRequestCompleteBlock)complete;

- (void)jLCsetCDay:(void(^ _Nullable)(bool success))handle;
@end
