//
//  SMCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "SMCSAdTypedef.h"

@class SMCSAdLoadBase;

@protocol SMCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol SMCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sMonAdShowed:(SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sMonAdClicked:(SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sMonAdClosed:(SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sMonAdVideoCompletePlaying:(SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sMonAdVideoGotReward:(SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload;
-(void)sMonAdDidPayRevenue:(SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)sMonAdShowFail:(SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sMonAdOtherEvent:(SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload event:(SMCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
