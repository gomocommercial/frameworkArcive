//
//  SMCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sMkAdvDataSourceFacebook   2 //FB 广告数据源
#define sMkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sMkAdvDataSourceMopub      39//Mopub 广告数据源
#define sMkAdvDataSourceApplovin   20//applovin 广告数据源

#define sMkAdvDataSourceGDT        62//广点通 广告数据源
#define sMkAdvDataSourceBaidu      63//百度 广告数据源
#define sMkAdvDataSourceBU         64//头条 广告数据源
#define sMkAdvDataSourceABU         70//头条聚合 广告数据源
#define sMkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define sMkAdvDataSourcePangle     74//pangle 广告数据源

#define sMkOnlineAdvTypeBanner                   1  //banner
#define sMkOnlineAdvTypeInterstitial             2  //全屏
#define sMkOnlineAdvTypeNative                   3 //native
#define sMkOnlineAdvTypeVideo                    4 //视频
#define sMkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sMkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sMkOnlineAdvTypeOpen                     8 //开屏
#define sMkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define sMkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define sMkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define sMkAdServerConfigError  -1 //服务器返回数据不正确
#define sMkAdLoadConfigFailed  -2 //广告加载失败


#define sMAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sMkCSAdInstallDays @"sMkCSAdInstallDays"
#define sMkCSAdModule_key @"sMkCSAdModule_key_%@"
#define sMkCSNewAdModule_key @"sMkCSNewAdModule_key_%@"
#define sMkCSAdInstallTime @"sMkCSAdInstallTime"
#define sMkCSAdInstallHours @"sMkCSAdInstallHours"
#define sMkCSAdLastGetServerTime @"sMkCSAdLastRequestTime"
#define sMkCSAdloadTime 30

#define sMkCSLoadAdTimeOutNotification @"sMKCSLoadAdTimeOutNotification"
#define sMkCSLoadAdTimeOutNotificationKey @"sMKCSLoadAdTimeOutKey"

