//
//  MACUCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "MACUCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface MACUCSAdLoadReward : MACUCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
