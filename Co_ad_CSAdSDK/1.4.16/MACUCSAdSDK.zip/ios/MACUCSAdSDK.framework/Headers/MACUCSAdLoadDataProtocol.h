//
//  MACUCSAdLoadDataProtocol.h
//  MACUCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "MACUCSAdTypedef.h"

@class MACUCSAdDataModel;
@class MACUCSAdLoadBase;

@protocol MACUCSAdLoadProtocol;

@protocol MACUCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)mACUonAdInfoFinish:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)mACUonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)mACUonAdFail:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
