//
//  MACUCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "MACUCSAdLoadBase.h"
#import "MACUCSAdDataModel.h"
#import "MACUCSAdLoadProtocol.h"
#import "MACUCSAdLoadDataProtocol.h"
#import "MACUCSAdLoadShowProtocol.h"
#import "MACUCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface MACUCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)mACUsetupByBlock:(void (^ _Nonnull)(MACUCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)mACUloadAd:(NSString *)moduleId delegate:(id<MACUCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)mACUadShowStatistic:(MACUCSAdDataModel *)dataModel adload:(nonnull MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)mACUadClickStatistic:(MACUCSAdDataModel *)dataModel adload:(nonnull MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)mACUaddCustomFecher:(Class<MACUCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
