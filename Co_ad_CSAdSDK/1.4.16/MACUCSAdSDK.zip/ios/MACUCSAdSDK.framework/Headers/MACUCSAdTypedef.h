//
//  MACUCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    MACUCSAdLoadSuccess = 1,
    MACUCSAdLoadFailure = -1,
    MACUCSAdLoadTimeout = -2
} MACUCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    MACUCSAdPreloadSuccess = 1,
    //预加载失败
    MACUCSAdPreloadFailure = -1,
    //重复加载
    MACUCSAdPreloadRepeat = -2,
} MACUCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    MACUCSAdWillAppear,//即将出现
    MACUCSAdDidAppear,//已经出现
    MACUCSAdWillDisappear,//即将消失
    MACUCSAdDidDisappear,//已经消失
    MACUCSAdMuted,//静音广告
    MACUCSAdWillLeaveApplication,//将要离开App

    MACUCSAdVideoStart,//开始播放 常用于video
    MACUCSAdVideoComplete,//播放完成 常用于video
    MACUCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    MACUCSAdVideoServerFail,//连接服务器成功，常用于fb video

    MACUCSAdNativeDidDownload,//下载完成 常用于fb Native
    MACUCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    MACUCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    MACUCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    MACUCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    MACUCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    MACUCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    MACUCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    MACUCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    MACUCSAdBUOpenDidAutoDimiss,//开屏自动消失
    MACUCSAdBUOpenRenderSuccess, //渲染成功
    MACUCSAdBUOpenRenderFail, //渲染失败
    MACUCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    MACUCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    MACUCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    MACUCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    MACUCSAdDidPresentFullScreen,//插屏弹出全屏广告
    MACUCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    MACUCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    MACUCSAdPlayerStatusStarted,//开始播放
    MACUCSAdPlayerStatusPaused,//用户行为导致暂停
    MACUCSAdPlayerStatusStoped,//播放停止
    MACUCSAdPlayerStatusError,//播放出错
    MACUCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    MACUCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    MACUCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    MACUCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    MACUCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    MACUCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    MACUCSAdRecordImpression, //广告曝光已记录
    MACUCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    MACUCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    MACUCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    MACUCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    MACUCSAdABUOpenWillPresentFullScreen,
    MACUCSAdABUOpenDidShowFailed,
    MACUCSAdABUOpenWillDissmissFullScreen,
    MACUCSAdABUOpenCountdownToZero,
    
    MACUCSAdABUBannerWillPresentFullScreen,
    MACUCSAdABUBannerWillDismissFullScreen,
    
    MACUCSAdABURewardDidLoad,
    MACUCSAdABURewardRenderFail,
    MACUCSAdABURewardDidShowFailed,

} MACUCSAdEvent;

typedef void (^MACUCSAdLoadCompleteBlock)(MACUCSAdLoadStatus adLoadStatus);

@class MACUCSAdSetupParamsMaker;
@class MACUCSAdSetupParams;

typedef MACUCSAdSetupParamsMaker *(^MACUCSAdStringInit)(NSString *);
typedef MACUCSAdSetupParamsMaker *(^MACUCSAdBoolInit)(BOOL);
typedef MACUCSAdSetupParamsMaker *(^MACUCSAdIntegerInit)(NSInteger);
typedef MACUCSAdSetupParamsMaker *(^MACUCSAdLongInit)(long);
typedef MACUCSAdSetupParamsMaker *(^MACUCSAdArrayInit)(NSArray *);
typedef MACUCSAdSetupParams *(^MACUCSAdMakeInit)(void);


@class MACUCSAdDataModel;
typedef void (^MACUCSAdRequestCompleteBlock)(NSMutableArray<MACUCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^MACUCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^MACUCSAdPreloadCompleteBlock)(MACUCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
