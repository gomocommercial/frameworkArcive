//
//  MACUCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MACUCSAdTypedef.h"

@class MACUCSAdLoadBase;

@protocol MACUCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MACUCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mACUonAdShowed:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)mACUonAdClicked:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mACUonAdClosed:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mACUonAdVideoCompletePlaying:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)mACUonAdVideoGotReward:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload;
-(void)mACUonAdDidPayRevenue:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)mACUonAdShowFail:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mACUonAdOtherEvent:(MACUCSAdLoadBase<MACUCSAdLoadProtocol> *)adload event:(MACUCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
