//
//  MACUCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define mACUkAdvDataSourceFacebook   2 //FB 广告数据源
#define mACUkAdvDataSourceAdmob      8 //Admob 广告数据源
#define mACUkAdvDataSourceMopub      39//Mopub 广告数据源
#define mACUkAdvDataSourceApplovin   20//applovin 广告数据源

#define mACUkAdvDataSourceGDT        62//广点通 广告数据源
#define mACUkAdvDataSourceBaidu      63//百度 广告数据源
#define mACUkAdvDataSourceBU         64//头条 广告数据源
#define mACUkAdvDataSourceABU         70//头条聚合 广告数据源
#define mACUkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define mACUkAdvDataSourcePangle     74//pangle 广告数据源

#define mACUkOnlineAdvTypeBanner                   1  //banner
#define mACUkOnlineAdvTypeInterstitial             2  //全屏
#define mACUkOnlineAdvTypeNative                   3 //native
#define mACUkOnlineAdvTypeVideo                    4 //视频
#define mACUkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define mACUkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define mACUkOnlineAdvTypeOpen                     8 //开屏
#define mACUkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define mACUkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define mACUkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define mACUkAdServerConfigError  -1 //服务器返回数据不正确
#define mACUkAdLoadConfigFailed  -2 //广告加载失败


#define mACUAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define mACUkCSAdInstallDays @"mACUkCSAdInstallDays"
#define mACUkCSAdModule_key @"mACUkCSAdModule_key_%@"
#define mACUkCSNewAdModule_key @"mACUkCSNewAdModule_key_%@"
#define mACUkCSAdInstallTime @"mACUkCSAdInstallTime"
#define mACUkCSAdInstallHours @"mACUkCSAdInstallHours"
#define mACUkCSAdLastGetServerTime @"mACUkCSAdLastRequestTime"
#define mACUkCSAdloadTime 30

#define mACUkCSLoadAdTimeOutNotification @"mACUKCSLoadAdTimeOutNotification"
#define mACUkCSLoadAdTimeOutNotificationKey @"mACUKCSLoadAdTimeOutKey"

