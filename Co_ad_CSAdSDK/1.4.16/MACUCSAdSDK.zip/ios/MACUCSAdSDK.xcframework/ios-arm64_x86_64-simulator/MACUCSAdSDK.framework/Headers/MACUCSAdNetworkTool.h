//
//  MACUCSAdNetworkTool.h
//  MACUCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "MACUCSAdDataModel.h"
#import "MACUCSAdTypedef.h"
#import "MACUCSNewStoreLiteRequestTool.h"
#import "NSString+MACUCSGenerateHash.h"

@interface MACUCSAdNetworkTool : NSObject

+ (MACUCSAdNetworkTool *)shared;
@property(nonatomic, copy) MACUCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)mACUrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(MACUCSAdRequestCompleteBlock)complete;

- (void)mACUsetCDay:(void(^ _Nullable)(bool success))handle;
@end
