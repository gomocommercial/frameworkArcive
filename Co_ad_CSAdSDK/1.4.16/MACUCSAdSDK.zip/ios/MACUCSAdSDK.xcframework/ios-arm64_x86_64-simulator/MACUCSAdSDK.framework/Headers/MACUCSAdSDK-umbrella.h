#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MACUCSAdSDK.h"
#import "MACUCSAdPreload.h"
#import "MACUCSAdLoadDataProtocol.h"
#import "MACUCSAdLoadShowProtocol.h"
#import "MACUCSAdLoadProtocol.h"
#import "MACUCSAdLoadBase.h"
#import "MACUCSAdLoadInterstitial.h"
#import "MACUCSAdLoadNative.h"
#import "MACUCSAdLoadReward.h"
#import "MACUCSAdLoadOpen.h"
#import "MACUCSAdLoadBanner.h"
#import "MACUCSAdManager.h"
#import "MACUCSAdSetupParams.h"
#import "MACUCSAdSetupParamsMaker.h"
#import "MACUCSAdDefine.h"
#import "MACUCSAdTypedef.h"
#import "MACUCSAdStatistics.h"
#import "MACUCSAdDataModel.h"
#import "MACUCSAdNetworkTool.h"
#import "MACUCSNewStoreLiteRequestTool.h"
#import "NSString+MACUCSGenerateHash.h"

FOUNDATION_EXPORT double MACUCSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char MACUCSAdSDKVersionString[];

