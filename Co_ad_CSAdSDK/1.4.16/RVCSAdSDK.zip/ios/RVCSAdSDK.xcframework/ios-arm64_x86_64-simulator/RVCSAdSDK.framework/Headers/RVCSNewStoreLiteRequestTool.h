//
//  RVCSNewStoreLiteRequestTool.h
//  AFNetworking
//
//  Created by zhangxin on 2022/4/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RVCSNewStoreLiteRequestTool : NSObject
+ (NSString *)signatureWithAccesskey:(NSString *)accesskey methodName:(NSString *)methodName requestUrl:(NSURL *)url payload:(NSDictionary *)payload;
+ (NSMutableDictionary *)getDevice;
+ (NSString *)convertToJsonStr:(NSDictionary *)dict;
@end

NS_ASSUME_NONNULL_END
