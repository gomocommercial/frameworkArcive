//
//  RVCSAdNetworkTool.h
//  RVCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "RVCSAdDataModel.h"
#import "RVCSAdTypedef.h"
#import "RVCSNewStoreLiteRequestTool.h"
#import "NSString+RVCSGenerateHash.h"

@interface RVCSAdNetworkTool : NSObject

+ (RVCSAdNetworkTool *)shared;
@property(nonatomic, copy) RVCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)rVrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(RVCSAdRequestCompleteBlock)complete;

- (void)rVsetCDay:(void(^ _Nullable)(bool success))handle;
@end
