//
//  OFCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "OFCSAdTypedef.h"

@class OFCSAdLoadBase;

@protocol OFCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol OFCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)oFonAdShowed:(OFCSAdLoadBase<OFCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)oFonAdClicked:(OFCSAdLoadBase<OFCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)oFonAdClosed:(OFCSAdLoadBase<OFCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)oFonAdVideoCompletePlaying:(OFCSAdLoadBase<OFCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)oFonAdVideoGotReward:(OFCSAdLoadBase<OFCSAdLoadProtocol> *)adload;
-(void)oFonAdDidPayRevenue:(OFCSAdLoadBase<OFCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)oFonAdShowFail:(OFCSAdLoadBase<OFCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)oFonAdOtherEvent:(OFCSAdLoadBase<OFCSAdLoadProtocol> *)adload event:(OFCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
