//
//  OFCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "OFCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface OFCSAdLoadReward : OFCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
