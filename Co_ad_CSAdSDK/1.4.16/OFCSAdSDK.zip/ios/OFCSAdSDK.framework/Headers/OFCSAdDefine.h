//
//  OFCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define oFkAdvDataSourceFacebook   2 //FB 广告数据源
#define oFkAdvDataSourceAdmob      8 //Admob 广告数据源
#define oFkAdvDataSourceMopub      39//Mopub 广告数据源
#define oFkAdvDataSourceApplovin   20//applovin 广告数据源

#define oFkAdvDataSourceGDT        62//广点通 广告数据源
#define oFkAdvDataSourceBaidu      63//百度 广告数据源
#define oFkAdvDataSourceBU         64//头条 广告数据源
#define oFkAdvDataSourceABU         70//头条聚合 广告数据源
#define oFkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define oFkAdvDataSourcePangle     74//pangle 广告数据源

#define oFkOnlineAdvTypeBanner                   1  //banner
#define oFkOnlineAdvTypeInterstitial             2  //全屏
#define oFkOnlineAdvTypeNative                   3 //native
#define oFkOnlineAdvTypeVideo                    4 //视频
#define oFkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define oFkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define oFkOnlineAdvTypeOpen                     8 //开屏
#define oFkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define oFkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define oFkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define oFkAdServerConfigError  -1 //服务器返回数据不正确
#define oFkAdLoadConfigFailed  -2 //广告加载失败


#define oFAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define oFkCSAdInstallDays @"oFkCSAdInstallDays"
#define oFkCSAdModule_key @"oFkCSAdModule_key_%@"
#define oFkCSNewAdModule_key @"oFkCSNewAdModule_key_%@"
#define oFkCSAdInstallTime @"oFkCSAdInstallTime"
#define oFkCSAdInstallHours @"oFkCSAdInstallHours"
#define oFkCSAdLastGetServerTime @"oFkCSAdLastRequestTime"
#define oFkCSAdloadTime 30

#define oFkCSLoadAdTimeOutNotification @"oFKCSLoadAdTimeOutNotification"
#define oFkCSLoadAdTimeOutNotificationKey @"oFKCSLoadAdTimeOutKey"

