//
//  OFCSAdNetworkTool.h
//  OFCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "OFCSAdDataModel.h"
#import "OFCSAdTypedef.h"
#import "OFCSNewStoreLiteRequestTool.h"
#import "NSString+OFCSGenerateHash.h"

@interface OFCSAdNetworkTool : NSObject

+ (OFCSAdNetworkTool *)shared;
@property(nonatomic, copy) OFCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)oFrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(OFCSAdRequestCompleteBlock)complete;

- (void)oFsetCDay:(void(^ _Nullable)(bool success))handle;
@end
