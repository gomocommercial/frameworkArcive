//
//  SBCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    SBCSAdLoadSuccess = 1,
    SBCSAdLoadFailure = -1,
    SBCSAdLoadTimeout = -2
} SBCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    SBCSAdPreloadSuccess = 1,
    //预加载失败
    SBCSAdPreloadFailure = -1,
    //重复加载
    SBCSAdPreloadRepeat = -2,
} SBCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    SBCSAdWillAppear,//即将出现
    SBCSAdDidAppear,//已经出现
    SBCSAdWillDisappear,//即将消失
    SBCSAdDidDisappear,//已经消失
    SBCSAdMuted,//静音广告
    SBCSAdWillLeaveApplication,//将要离开App

    SBCSAdVideoStart,//开始播放 常用于video
    SBCSAdVideoComplete,//播放完成 常用于video
    SBCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    SBCSAdVideoServerFail,//连接服务器成功，常用于fb video

    SBCSAdNativeDidDownload,//下载完成 常用于fb Native
    SBCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    SBCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    SBCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    SBCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    SBCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    SBCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    SBCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    SBCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    SBCSAdBUOpenDidAutoDimiss,//开屏自动消失
    SBCSAdBUOpenRenderSuccess, //渲染成功
    SBCSAdBUOpenRenderFail, //渲染失败
    SBCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    SBCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    SBCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    SBCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    SBCSAdDidPresentFullScreen,//插屏弹出全屏广告
    SBCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    SBCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    SBCSAdPlayerStatusStarted,//开始播放
    SBCSAdPlayerStatusPaused,//用户行为导致暂停
    SBCSAdPlayerStatusStoped,//播放停止
    SBCSAdPlayerStatusError,//播放出错
    SBCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    SBCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    SBCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    SBCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    SBCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    SBCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    SBCSAdRecordImpression, //广告曝光已记录
    SBCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    SBCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    SBCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    SBCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    SBCSAdABUOpenWillPresentFullScreen,
    SBCSAdABUOpenDidShowFailed,
    SBCSAdABUOpenWillDissmissFullScreen,
    SBCSAdABUOpenCountdownToZero,
    
    SBCSAdABUBannerWillPresentFullScreen,
    SBCSAdABUBannerWillDismissFullScreen,
    
    SBCSAdABURewardDidLoad,
    SBCSAdABURewardRenderFail,
    SBCSAdABURewardDidShowFailed,

} SBCSAdEvent;

typedef void (^SBCSAdLoadCompleteBlock)(SBCSAdLoadStatus adLoadStatus);

@class SBCSAdSetupParamsMaker;
@class SBCSAdSetupParams;

typedef SBCSAdSetupParamsMaker *(^SBCSAdStringInit)(NSString *);
typedef SBCSAdSetupParamsMaker *(^SBCSAdBoolInit)(BOOL);
typedef SBCSAdSetupParamsMaker *(^SBCSAdIntegerInit)(NSInteger);
typedef SBCSAdSetupParamsMaker *(^SBCSAdLongInit)(long);
typedef SBCSAdSetupParamsMaker *(^SBCSAdArrayInit)(NSArray *);
typedef SBCSAdSetupParams *(^SBCSAdMakeInit)(void);


@class SBCSAdDataModel;
typedef void (^SBCSAdRequestCompleteBlock)(NSMutableArray<SBCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^SBCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^SBCSAdPreloadCompleteBlock)(SBCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
