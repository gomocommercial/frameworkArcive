//
//  SBCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sBkAdvDataSourceFacebook   2 //FB 广告数据源
#define sBkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sBkAdvDataSourceMopub      39//Mopub 广告数据源
#define sBkAdvDataSourceApplovin   20//applovin 广告数据源

#define sBkAdvDataSourceGDT        62//广点通 广告数据源
#define sBkAdvDataSourceBaidu      63//百度 广告数据源
#define sBkAdvDataSourceBU         64//头条 广告数据源
#define sBkAdvDataSourceABU         70//头条聚合 广告数据源
#define sBkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define sBkAdvDataSourcePangle     74//pangle 广告数据源

#define sBkOnlineAdvTypeBanner                   1  //banner
#define sBkOnlineAdvTypeInterstitial             2  //全屏
#define sBkOnlineAdvTypeNative                   3 //native
#define sBkOnlineAdvTypeVideo                    4 //视频
#define sBkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sBkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sBkOnlineAdvTypeOpen                     8 //开屏
#define sBkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define sBkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define sBkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define sBkAdServerConfigError  -1 //服务器返回数据不正确
#define sBkAdLoadConfigFailed  -2 //广告加载失败


#define sBAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sBkCSAdInstallDays @"sBkCSAdInstallDays"
#define sBkCSAdModule_key @"sBkCSAdModule_key_%@"
#define sBkCSNewAdModule_key @"sBkCSNewAdModule_key_%@"
#define sBkCSAdInstallTime @"sBkCSAdInstallTime"
#define sBkCSAdInstallHours @"sBkCSAdInstallHours"
#define sBkCSAdLastGetServerTime @"sBkCSAdLastRequestTime"
#define sBkCSAdloadTime 30

#define sBkCSLoadAdTimeOutNotification @"sBKCSLoadAdTimeOutNotification"
#define sBkCSLoadAdTimeOutNotificationKey @"sBKCSLoadAdTimeOutKey"

