//
//  SBCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBCSAdLoadReward : SBCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
