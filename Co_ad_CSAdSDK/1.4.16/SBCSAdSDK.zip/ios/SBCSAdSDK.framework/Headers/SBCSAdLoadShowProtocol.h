//
//  SBCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "SBCSAdTypedef.h"

@class SBCSAdLoadBase;

@protocol SBCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol SBCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sBonAdShowed:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sBonAdClicked:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sBonAdClosed:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sBonAdVideoCompletePlaying:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sBonAdVideoGotReward:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload;
-(void)sBonAdDidPayRevenue:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)sBonAdShowFail:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sBonAdOtherEvent:(SBCSAdLoadBase<SBCSAdLoadProtocol> *)adload event:(SBCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
