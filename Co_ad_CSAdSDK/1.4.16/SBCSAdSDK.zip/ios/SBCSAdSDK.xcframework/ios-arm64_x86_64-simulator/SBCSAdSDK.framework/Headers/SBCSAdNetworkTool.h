//
//  SBCSAdNetworkTool.h
//  SBCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "SBCSAdDataModel.h"
#import "SBCSAdTypedef.h"
#import "SBCSNewStoreLiteRequestTool.h"
#import "NSString+SBCSGenerateHash.h"

@interface SBCSAdNetworkTool : NSObject

+ (SBCSAdNetworkTool *)shared;
@property(nonatomic, copy) SBCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sBrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(SBCSAdRequestCompleteBlock)complete;

- (void)sBsetCDay:(void(^ _Nullable)(bool success))handle;
@end
