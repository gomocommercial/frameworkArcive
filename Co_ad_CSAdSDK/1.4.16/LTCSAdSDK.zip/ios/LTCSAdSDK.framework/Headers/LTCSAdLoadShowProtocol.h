//
//  LTCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "LTCSAdTypedef.h"

@class LTCSAdLoadBase;

@protocol LTCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol LTCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)lTonAdShowed:(LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)lTonAdClicked:(LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)lTonAdClosed:(LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)lTonAdVideoCompletePlaying:(LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)lTonAdVideoGotReward:(LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload;
-(void)lTonAdDidPayRevenue:(LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)lTonAdShowFail:(LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)lTonAdOtherEvent:(LTCSAdLoadBase<LTCSAdLoadProtocol> *)adload event:(LTCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
