//
//  LTCSAdNetworkTool.h
//  LTCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "LTCSAdDataModel.h"
#import "LTCSAdTypedef.h"
#import "LTCSNewStoreLiteRequestTool.h"
#import "NSString+LTCSGenerateHash.h"

@interface LTCSAdNetworkTool : NSObject

+ (LTCSAdNetworkTool *)shared;
@property(nonatomic, copy) LTCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)lTrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(LTCSAdRequestCompleteBlock)complete;

- (void)lTsetCDay:(void(^ _Nullable)(bool success))handle;
@end
