//
//  PHCSAdNetworkTool.h
//  PHCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PHCSAdDataModel.h"
#import "PHCSAdTypedef.h"
#import "PHCSNewStoreLiteRequestTool.h"
#import "NSString+PHCSGenerateHash.h"

@interface PHCSAdNetworkTool : NSObject

+ (PHCSAdNetworkTool *)shared;
@property(nonatomic, copy) PHCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pHrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PHCSAdRequestCompleteBlock)complete;

- (void)pHsetCDay:(void(^ _Nullable)(bool success))handle;
@end
