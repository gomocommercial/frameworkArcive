//
//  FSLPCSAdNetworkTool.h
//  FSLPCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "FSLPCSAdDataModel.h"
#import "FSLPCSAdTypedef.h"
#import "FSLPCSNewStoreLiteRequestTool.h"
#import "NSString+FSLPCSGenerateHash.h"

@interface FSLPCSAdNetworkTool : NSObject

+ (FSLPCSAdNetworkTool *)shared;
@property(nonatomic, copy) FSLPCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)fSLPrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(FSLPCSAdRequestCompleteBlock)complete;

- (void)fSLPsetCDay:(void(^ _Nullable)(bool success))handle;
@end
