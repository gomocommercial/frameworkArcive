//
//  FSLPCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "FSLPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadReward : FSLPCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
