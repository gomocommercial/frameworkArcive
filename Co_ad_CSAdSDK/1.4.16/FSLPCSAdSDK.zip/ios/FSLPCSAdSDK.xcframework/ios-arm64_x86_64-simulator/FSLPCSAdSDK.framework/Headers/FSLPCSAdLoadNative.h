//
//  FSLPCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "FSLPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadNative : FSLPCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
