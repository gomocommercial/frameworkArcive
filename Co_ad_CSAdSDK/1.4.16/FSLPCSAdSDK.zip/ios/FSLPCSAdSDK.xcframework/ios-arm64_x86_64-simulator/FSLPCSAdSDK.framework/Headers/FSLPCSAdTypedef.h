//
//  FSLPCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    FSLPCSAdLoadSuccess = 1,
    FSLPCSAdLoadFailure = -1,
    FSLPCSAdLoadTimeout = -2
} FSLPCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    FSLPCSAdPreloadSuccess = 1,
    //预加载失败
    FSLPCSAdPreloadFailure = -1,
    //重复加载
    FSLPCSAdPreloadRepeat = -2,
} FSLPCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    FSLPCSAdWillAppear,//即将出现
    FSLPCSAdDidAppear,//已经出现
    FSLPCSAdWillDisappear,//即将消失
    FSLPCSAdDidDisappear,//已经消失
    FSLPCSAdMuted,//静音广告
    FSLPCSAdWillLeaveApplication,//将要离开App

    FSLPCSAdVideoStart,//开始播放 常用于video
    FSLPCSAdVideoComplete,//播放完成 常用于video
    FSLPCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    FSLPCSAdVideoServerFail,//连接服务器成功，常用于fb video

    FSLPCSAdNativeDidDownload,//下载完成 常用于fb Native
    FSLPCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    FSLPCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    FSLPCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    FSLPCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    FSLPCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    FSLPCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    FSLPCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    FSLPCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    FSLPCSAdBUOpenDidAutoDimiss,//开屏自动消失
    FSLPCSAdBUOpenRenderSuccess, //渲染成功
    FSLPCSAdBUOpenRenderFail, //渲染失败
    FSLPCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    FSLPCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    FSLPCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    FSLPCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    FSLPCSAdDidPresentFullScreen,//插屏弹出全屏广告
    FSLPCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    FSLPCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    FSLPCSAdPlayerStatusStarted,//开始播放
    FSLPCSAdPlayerStatusPaused,//用户行为导致暂停
    FSLPCSAdPlayerStatusStoped,//播放停止
    FSLPCSAdPlayerStatusError,//播放出错
    FSLPCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    FSLPCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    FSLPCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    FSLPCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    FSLPCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    FSLPCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    FSLPCSAdRecordImpression, //广告曝光已记录
    FSLPCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    FSLPCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    FSLPCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    FSLPCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    FSLPCSAdABUOpenWillPresentFullScreen,
    FSLPCSAdABUOpenDidShowFailed,
    FSLPCSAdABUOpenWillDissmissFullScreen,
    FSLPCSAdABUOpenCountdownToZero,
    
    FSLPCSAdABUBannerWillPresentFullScreen,
    FSLPCSAdABUBannerWillDismissFullScreen,
    
    FSLPCSAdABURewardDidLoad,
    FSLPCSAdABURewardRenderFail,
    FSLPCSAdABURewardDidShowFailed,

} FSLPCSAdEvent;

typedef void (^FSLPCSAdLoadCompleteBlock)(FSLPCSAdLoadStatus adLoadStatus);

@class FSLPCSAdSetupParamsMaker;
@class FSLPCSAdSetupParams;

typedef FSLPCSAdSetupParamsMaker *(^FSLPCSAdStringInit)(NSString *);
typedef FSLPCSAdSetupParamsMaker *(^FSLPCSAdBoolInit)(BOOL);
typedef FSLPCSAdSetupParamsMaker *(^FSLPCSAdIntegerInit)(NSInteger);
typedef FSLPCSAdSetupParamsMaker *(^FSLPCSAdLongInit)(long);
typedef FSLPCSAdSetupParamsMaker *(^FSLPCSAdArrayInit)(NSArray *);
typedef FSLPCSAdSetupParams *(^FSLPCSAdMakeInit)(void);


@class FSLPCSAdDataModel;
typedef void (^FSLPCSAdRequestCompleteBlock)(NSMutableArray<FSLPCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^FSLPCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^FSLPCSAdPreloadCompleteBlock)(FSLPCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
