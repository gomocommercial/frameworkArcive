//
//  FSLPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FSLPCSAdTypedef.h"

@class FSLPCSAdLoadBase;

@protocol FSLPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FSLPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)fSLPonAdShowed:(FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)fSLPonAdClicked:(FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)fSLPonAdClosed:(FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)fSLPonAdVideoCompletePlaying:(FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)fSLPonAdVideoGotReward:(FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload;
-(void)fSLPonAdDidPayRevenue:(FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)fSLPonAdShowFail:(FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)fSLPonAdOtherEvent:(FSLPCSAdLoadBase<FSLPCSAdLoadProtocol> *)adload event:(FSLPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
