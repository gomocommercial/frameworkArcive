//
//  WPSCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "WPSCSAdTypedef.h"

@class WPSCSAdLoadBase;

@protocol WPSCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol WPSCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)wPSonAdShowed:(WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)wPSonAdClicked:(WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)wPSonAdClosed:(WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)wPSonAdVideoCompletePlaying:(WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)wPSonAdVideoGotReward:(WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload;
-(void)wPSonAdDidPayRevenue:(WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)wPSonAdShowFail:(WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)wPSonAdOtherEvent:(WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload event:(WPSCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
