//
//  WPSCSAdNetworkTool.h
//  WPSCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "WPSCSAdDataModel.h"
#import "WPSCSAdTypedef.h"
#import "WPSCSNewStoreLiteRequestTool.h"
#import "NSString+WPSCSGenerateHash.h"

@interface WPSCSAdNetworkTool : NSObject

+ (WPSCSAdNetworkTool *)shared;
@property(nonatomic, copy) WPSCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)wPSrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(WPSCSAdRequestCompleteBlock)complete;

- (void)wPSsetCDay:(void(^ _Nullable)(bool success))handle;
@end
