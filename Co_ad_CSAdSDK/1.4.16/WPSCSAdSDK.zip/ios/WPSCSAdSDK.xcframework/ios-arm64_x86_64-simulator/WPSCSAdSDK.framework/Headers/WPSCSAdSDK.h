//
//  WPSCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "WPSCSAdLoadBase.h"
#import "WPSCSAdDataModel.h"
#import "WPSCSAdLoadProtocol.h"
#import "WPSCSAdLoadDataProtocol.h"
#import "WPSCSAdLoadShowProtocol.h"
#import "WPSCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface WPSCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)wPSsetupByBlock:(void (^ _Nonnull)(WPSCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)wPSloadAd:(NSString *)moduleId delegate:(id<WPSCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)wPSadShowStatistic:(WPSCSAdDataModel *)dataModel adload:(nonnull WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)wPSadClickStatistic:(WPSCSAdDataModel *)dataModel adload:(nonnull WPSCSAdLoadBase<WPSCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)wPSaddCustomFecher:(Class<WPSCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
