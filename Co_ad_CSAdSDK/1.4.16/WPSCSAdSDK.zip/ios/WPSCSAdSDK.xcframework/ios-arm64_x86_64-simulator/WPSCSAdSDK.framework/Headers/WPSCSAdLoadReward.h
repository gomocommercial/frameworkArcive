//
//  WPSCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "WPSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface WPSCSAdLoadReward : WPSCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
