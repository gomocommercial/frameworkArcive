//
//  FRCSAdNetworkTool.h
//  FRCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "FRCSAdDataModel.h"
#import "FRCSAdTypedef.h"
#import "FRCSNewStoreLiteRequestTool.h"
#import "NSString+FRCSGenerateHash.h"

@interface FRCSAdNetworkTool : NSObject

+ (FRCSAdNetworkTool *)shared;
@property(nonatomic, copy) FRCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)fRrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(FRCSAdRequestCompleteBlock)complete;

- (void)fRsetCDay:(void(^ _Nullable)(bool success))handle;
@end
