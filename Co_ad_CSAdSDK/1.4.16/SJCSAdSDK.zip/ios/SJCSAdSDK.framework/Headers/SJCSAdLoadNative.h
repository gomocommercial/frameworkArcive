//
//  SJCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SJCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SJCSAdLoadNative : SJCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
