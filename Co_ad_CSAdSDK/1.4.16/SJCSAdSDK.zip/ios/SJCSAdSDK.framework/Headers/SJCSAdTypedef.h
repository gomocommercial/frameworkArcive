//
//  SJCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    SJCSAdLoadSuccess = 1,
    SJCSAdLoadFailure = -1,
    SJCSAdLoadTimeout = -2
} SJCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    SJCSAdPreloadSuccess = 1,
    //预加载失败
    SJCSAdPreloadFailure = -1,
    //重复加载
    SJCSAdPreloadRepeat = -2,
} SJCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    SJCSAdWillAppear,//即将出现
    SJCSAdDidAppear,//已经出现
    SJCSAdWillDisappear,//即将消失
    SJCSAdDidDisappear,//已经消失
    SJCSAdMuted,//静音广告
    SJCSAdWillLeaveApplication,//将要离开App

    SJCSAdVideoStart,//开始播放 常用于video
    SJCSAdVideoComplete,//播放完成 常用于video
    SJCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    SJCSAdVideoServerFail,//连接服务器成功，常用于fb video

    SJCSAdNativeDidDownload,//下载完成 常用于fb Native
    SJCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    SJCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    SJCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    SJCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    SJCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    SJCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    SJCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    SJCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    SJCSAdBUOpenDidAutoDimiss,//开屏自动消失
    SJCSAdBUOpenRenderSuccess, //渲染成功
    SJCSAdBUOpenRenderFail, //渲染失败
    SJCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    SJCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    SJCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    SJCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    SJCSAdDidPresentFullScreen,//插屏弹出全屏广告
    SJCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    SJCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    SJCSAdPlayerStatusStarted,//开始播放
    SJCSAdPlayerStatusPaused,//用户行为导致暂停
    SJCSAdPlayerStatusStoped,//播放停止
    SJCSAdPlayerStatusError,//播放出错
    SJCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    SJCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    SJCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    SJCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    SJCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    SJCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    SJCSAdRecordImpression, //广告曝光已记录
    SJCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    SJCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    SJCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    SJCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    SJCSAdABUOpenWillPresentFullScreen,
    SJCSAdABUOpenDidShowFailed,
    SJCSAdABUOpenWillDissmissFullScreen,
    SJCSAdABUOpenCountdownToZero,
    
    SJCSAdABUBannerWillPresentFullScreen,
    SJCSAdABUBannerWillDismissFullScreen,
    
    SJCSAdABURewardDidLoad,
    SJCSAdABURewardRenderFail,
    SJCSAdABURewardDidShowFailed,

} SJCSAdEvent;

typedef void (^SJCSAdLoadCompleteBlock)(SJCSAdLoadStatus adLoadStatus);

@class SJCSAdSetupParamsMaker;
@class SJCSAdSetupParams;

typedef SJCSAdSetupParamsMaker *(^SJCSAdStringInit)(NSString *);
typedef SJCSAdSetupParamsMaker *(^SJCSAdBoolInit)(BOOL);
typedef SJCSAdSetupParamsMaker *(^SJCSAdIntegerInit)(NSInteger);
typedef SJCSAdSetupParamsMaker *(^SJCSAdLongInit)(long);
typedef SJCSAdSetupParamsMaker *(^SJCSAdArrayInit)(NSArray *);
typedef SJCSAdSetupParams *(^SJCSAdMakeInit)(void);


@class SJCSAdDataModel;
typedef void (^SJCSAdRequestCompleteBlock)(NSMutableArray<SJCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^SJCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^SJCSAdPreloadCompleteBlock)(SJCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
