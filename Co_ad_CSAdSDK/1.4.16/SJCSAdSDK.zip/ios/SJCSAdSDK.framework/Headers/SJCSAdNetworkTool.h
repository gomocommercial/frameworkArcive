//
//  SJCSAdNetworkTool.h
//  SJCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "SJCSAdDataModel.h"
#import "SJCSAdTypedef.h"
#import "SJCSNewStoreLiteRequestTool.h"
#import "NSString+SJCSGenerateHash.h"

@interface SJCSAdNetworkTool : NSObject

+ (SJCSAdNetworkTool *)shared;
@property(nonatomic, copy) SJCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sJrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(SJCSAdRequestCompleteBlock)complete;

- (void)sJsetCDay:(void(^ _Nullable)(bool success))handle;
@end
