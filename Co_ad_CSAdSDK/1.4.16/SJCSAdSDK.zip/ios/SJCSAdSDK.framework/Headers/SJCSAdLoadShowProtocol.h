//
//  SJCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "SJCSAdTypedef.h"

@class SJCSAdLoadBase;

@protocol SJCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol SJCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sJonAdShowed:(SJCSAdLoadBase<SJCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sJonAdClicked:(SJCSAdLoadBase<SJCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sJonAdClosed:(SJCSAdLoadBase<SJCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sJonAdVideoCompletePlaying:(SJCSAdLoadBase<SJCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sJonAdVideoGotReward:(SJCSAdLoadBase<SJCSAdLoadProtocol> *)adload;
-(void)sJonAdDidPayRevenue:(SJCSAdLoadBase<SJCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)sJonAdShowFail:(SJCSAdLoadBase<SJCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sJonAdOtherEvent:(SJCSAdLoadBase<SJCSAdLoadProtocol> *)adload event:(SJCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
