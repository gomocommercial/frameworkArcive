//
//  WPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "WPCSAdTypedef.h"

@class WPCSAdLoadBase;

@protocol WPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol WPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)wPonAdShowed:(WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)wPonAdClicked:(WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)wPonAdClosed:(WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)wPonAdVideoCompletePlaying:(WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)wPonAdVideoGotReward:(WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload;
-(void)wPonAdDidPayRevenue:(WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)wPonAdShowFail:(WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)wPonAdOtherEvent:(WPCSAdLoadBase<WPCSAdLoadProtocol> *)adload event:(WPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
