//
//  WPCSAdNetworkTool.h
//  WPCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "WPCSAdDataModel.h"
#import "WPCSAdTypedef.h"
#import "WPCSNewStoreLiteRequestTool.h"
#import "NSString+WPCSGenerateHash.h"

@interface WPCSAdNetworkTool : NSObject

+ (WPCSAdNetworkTool *)shared;
@property(nonatomic, copy) WPCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)wPrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(WPCSAdRequestCompleteBlock)complete;

- (void)wPsetCDay:(void(^ _Nullable)(bool success))handle;
@end
