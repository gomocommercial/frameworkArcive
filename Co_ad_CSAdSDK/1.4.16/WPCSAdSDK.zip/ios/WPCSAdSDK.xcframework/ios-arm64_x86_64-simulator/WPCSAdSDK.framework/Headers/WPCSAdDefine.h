//
//  WPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define wPkAdvDataSourceFacebook   2 //FB 广告数据源
#define wPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define wPkAdvDataSourceMopub      39//Mopub 广告数据源
#define wPkAdvDataSourceApplovin   20//applovin 广告数据源

#define wPkAdvDataSourceGDT        62//广点通 广告数据源
#define wPkAdvDataSourceBaidu      63//百度 广告数据源
#define wPkAdvDataSourceBU         64//头条 广告数据源
#define wPkAdvDataSourceABU         70//头条聚合 广告数据源
#define wPkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define wPkAdvDataSourcePangle     74//pangle 广告数据源

#define wPkOnlineAdvTypeBanner                   1  //banner
#define wPkOnlineAdvTypeInterstitial             2  //全屏
#define wPkOnlineAdvTypeNative                   3 //native
#define wPkOnlineAdvTypeVideo                    4 //视频
#define wPkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define wPkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define wPkOnlineAdvTypeOpen                     8 //开屏
#define wPkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define wPkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define wPkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define wPkAdServerConfigError  -1 //服务器返回数据不正确
#define wPkAdLoadConfigFailed  -2 //广告加载失败


#define wPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define wPkCSAdInstallDays @"wPkCSAdInstallDays"
#define wPkCSAdModule_key @"wPkCSAdModule_key_%@"
#define wPkCSNewAdModule_key @"wPkCSNewAdModule_key_%@"
#define wPkCSAdInstallTime @"wPkCSAdInstallTime"
#define wPkCSAdInstallHours @"wPkCSAdInstallHours"
#define wPkCSAdLastGetServerTime @"wPkCSAdLastRequestTime"
#define wPkCSAdloadTime 30

#define wPkCSLoadAdTimeOutNotification @"wPKCSLoadAdTimeOutNotification"
#define wPkCSLoadAdTimeOutNotificationKey @"wPKCSLoadAdTimeOutKey"

