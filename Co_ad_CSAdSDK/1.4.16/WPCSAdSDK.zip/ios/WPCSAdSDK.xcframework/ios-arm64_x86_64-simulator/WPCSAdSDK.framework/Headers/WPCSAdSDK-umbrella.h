#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WPCSAdSDK.h"
#import "WPCSAdPreload.h"
#import "WPCSAdLoadDataProtocol.h"
#import "WPCSAdLoadShowProtocol.h"
#import "WPCSAdLoadProtocol.h"
#import "WPCSAdLoadBase.h"
#import "WPCSAdLoadInterstitial.h"
#import "WPCSAdLoadNative.h"
#import "WPCSAdLoadReward.h"
#import "WPCSAdLoadOpen.h"
#import "WPCSAdLoadBanner.h"
#import "WPCSAdManager.h"
#import "WPCSAdSetupParams.h"
#import "WPCSAdSetupParamsMaker.h"
#import "WPCSAdDefine.h"
#import "WPCSAdTypedef.h"
#import "WPCSAdStatistics.h"
#import "WPCSAdDataModel.h"
#import "WPCSAdNetworkTool.h"
#import "WPCSNewStoreLiteRequestTool.h"
#import "NSString+WPCSGenerateHash.h"

FOUNDATION_EXPORT double WPCSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char WPCSAdSDKVersionString[];

