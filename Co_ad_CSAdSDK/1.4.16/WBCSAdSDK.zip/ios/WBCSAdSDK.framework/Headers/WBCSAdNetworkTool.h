//
//  WBCSAdNetworkTool.h
//  WBCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "WBCSAdDataModel.h"
#import "WBCSAdTypedef.h"
#import "WBCSNewStoreLiteRequestTool.h"
#import "NSString+WBCSGenerateHash.h"

@interface WBCSAdNetworkTool : NSObject

+ (WBCSAdNetworkTool *)shared;
@property(nonatomic, copy) WBCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)wBrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(WBCSAdRequestCompleteBlock)complete;

- (void)wBsetCDay:(void(^ _Nullable)(bool success))handle;
@end
