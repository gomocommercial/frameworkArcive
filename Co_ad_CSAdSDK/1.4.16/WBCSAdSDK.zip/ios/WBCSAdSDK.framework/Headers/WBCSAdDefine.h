//
//  WBCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define wBkAdvDataSourceFacebook   2 //FB 广告数据源
#define wBkAdvDataSourceAdmob      8 //Admob 广告数据源
#define wBkAdvDataSourceMopub      39//Mopub 广告数据源
#define wBkAdvDataSourceApplovin   20//applovin 广告数据源

#define wBkAdvDataSourceGDT        62//广点通 广告数据源
#define wBkAdvDataSourceBaidu      63//百度 广告数据源
#define wBkAdvDataSourceBU         64//头条 广告数据源
#define wBkAdvDataSourceABU         70//头条聚合 广告数据源
#define wBkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define wBkAdvDataSourcePangle     74//pangle 广告数据源

#define wBkOnlineAdvTypeBanner                   1  //banner
#define wBkOnlineAdvTypeInterstitial             2  //全屏
#define wBkOnlineAdvTypeNative                   3 //native
#define wBkOnlineAdvTypeVideo                    4 //视频
#define wBkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define wBkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define wBkOnlineAdvTypeOpen                     8 //开屏
#define wBkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define wBkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define wBkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define wBkAdServerConfigError  -1 //服务器返回数据不正确
#define wBkAdLoadConfigFailed  -2 //广告加载失败


#define wBAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define wBkCSAdInstallDays @"wBkCSAdInstallDays"
#define wBkCSAdModule_key @"wBkCSAdModule_key_%@"
#define wBkCSNewAdModule_key @"wBkCSNewAdModule_key_%@"
#define wBkCSAdInstallTime @"wBkCSAdInstallTime"
#define wBkCSAdInstallHours @"wBkCSAdInstallHours"
#define wBkCSAdLastGetServerTime @"wBkCSAdLastRequestTime"
#define wBkCSAdloadTime 30

#define wBkCSLoadAdTimeOutNotification @"wBKCSLoadAdTimeOutNotification"
#define wBkCSLoadAdTimeOutNotificationKey @"wBKCSLoadAdTimeOutKey"

