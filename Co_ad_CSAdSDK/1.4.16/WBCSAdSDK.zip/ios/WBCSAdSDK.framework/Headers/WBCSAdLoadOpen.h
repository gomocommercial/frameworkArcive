//
//  WBCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "WBCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface WBCSAdLoadOpen : WBCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
