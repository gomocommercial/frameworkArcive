//
//  WBCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "WBCSAdTypedef.h"

@class WBCSAdLoadBase;

@protocol WBCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol WBCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)wBonAdShowed:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)wBonAdClicked:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)wBonAdClosed:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)wBonAdVideoCompletePlaying:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)wBonAdVideoGotReward:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload;
-(void)wBonAdDidPayRevenue:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)wBonAdShowFail:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)wBonAdOtherEvent:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload event:(WBCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
