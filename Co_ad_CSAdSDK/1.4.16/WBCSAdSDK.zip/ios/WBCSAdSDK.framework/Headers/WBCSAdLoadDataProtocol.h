//
//  WBCSAdLoadDataProtocol.h
//  WBCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "WBCSAdTypedef.h"

@class WBCSAdDataModel;
@class WBCSAdLoadBase;

@protocol WBCSAdLoadProtocol;

@protocol WBCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)wBonAdInfoFinish:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)wBonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)wBonAdFail:(WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
