//
//  WBCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "WBCSAdLoadBase.h"
#import "WBCSAdDataModel.h"
#import "WBCSAdLoadProtocol.h"
#import "WBCSAdLoadDataProtocol.h"
#import "WBCSAdLoadShowProtocol.h"
#import "WBCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface WBCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)wBsetupByBlock:(void (^ _Nonnull)(WBCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)wBloadAd:(NSString *)moduleId delegate:(id<WBCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)wBadShowStatistic:(WBCSAdDataModel *)dataModel adload:(nonnull WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)wBadClickStatistic:(WBCSAdDataModel *)dataModel adload:(nonnull WBCSAdLoadBase<WBCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)wBaddCustomFecher:(Class<WBCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
