//
//  WBCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    WBCSAdLoadSuccess = 1,
    WBCSAdLoadFailure = -1,
    WBCSAdLoadTimeout = -2
} WBCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    WBCSAdPreloadSuccess = 1,
    //预加载失败
    WBCSAdPreloadFailure = -1,
    //重复加载
    WBCSAdPreloadRepeat = -2,
} WBCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    WBCSAdWillAppear,//即将出现
    WBCSAdDidAppear,//已经出现
    WBCSAdWillDisappear,//即将消失
    WBCSAdDidDisappear,//已经消失
    WBCSAdMuted,//静音广告
    WBCSAdWillLeaveApplication,//将要离开App

    WBCSAdVideoStart,//开始播放 常用于video
    WBCSAdVideoComplete,//播放完成 常用于video
    WBCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    WBCSAdVideoServerFail,//连接服务器成功，常用于fb video

    WBCSAdNativeDidDownload,//下载完成 常用于fb Native
    WBCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    WBCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    WBCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    WBCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    WBCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    WBCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    WBCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    WBCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    WBCSAdBUOpenDidAutoDimiss,//开屏自动消失
    WBCSAdBUOpenRenderSuccess, //渲染成功
    WBCSAdBUOpenRenderFail, //渲染失败
    WBCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    WBCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    WBCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    WBCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    WBCSAdDidPresentFullScreen,//插屏弹出全屏广告
    WBCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    WBCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    WBCSAdPlayerStatusStarted,//开始播放
    WBCSAdPlayerStatusPaused,//用户行为导致暂停
    WBCSAdPlayerStatusStoped,//播放停止
    WBCSAdPlayerStatusError,//播放出错
    WBCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    WBCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    WBCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    WBCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    WBCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    WBCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    WBCSAdRecordImpression, //广告曝光已记录
    WBCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    WBCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    WBCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    WBCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    WBCSAdABUOpenWillPresentFullScreen,
    WBCSAdABUOpenDidShowFailed,
    WBCSAdABUOpenWillDissmissFullScreen,
    WBCSAdABUOpenCountdownToZero,
    
    WBCSAdABUBannerWillPresentFullScreen,
    WBCSAdABUBannerWillDismissFullScreen,
    
    WBCSAdABURewardDidLoad,
    WBCSAdABURewardRenderFail,
    WBCSAdABURewardDidShowFailed,

} WBCSAdEvent;

typedef void (^WBCSAdLoadCompleteBlock)(WBCSAdLoadStatus adLoadStatus);

@class WBCSAdSetupParamsMaker;
@class WBCSAdSetupParams;

typedef WBCSAdSetupParamsMaker *(^WBCSAdStringInit)(NSString *);
typedef WBCSAdSetupParamsMaker *(^WBCSAdBoolInit)(BOOL);
typedef WBCSAdSetupParamsMaker *(^WBCSAdIntegerInit)(NSInteger);
typedef WBCSAdSetupParamsMaker *(^WBCSAdLongInit)(long);
typedef WBCSAdSetupParamsMaker *(^WBCSAdArrayInit)(NSArray *);
typedef WBCSAdSetupParams *(^WBCSAdMakeInit)(void);


@class WBCSAdDataModel;
typedef void (^WBCSAdRequestCompleteBlock)(NSMutableArray<WBCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^WBCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^WBCSAdPreloadCompleteBlock)(WBCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
