//
//  LOCSAdNetworkTool.h
//  LOCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "LOCSAdDataModel.h"
#import "LOCSAdTypedef.h"
#import "LOCSNewStoreLiteRequestTool.h"
#import "NSString+LOCSGenerateHash.h"

@interface LOCSAdNetworkTool : NSObject

+ (LOCSAdNetworkTool *)shared;
@property(nonatomic, copy) LOCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)lOrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(LOCSAdRequestCompleteBlock)complete;

- (void)lOsetCDay:(void(^ _Nullable)(bool success))handle;
@end
