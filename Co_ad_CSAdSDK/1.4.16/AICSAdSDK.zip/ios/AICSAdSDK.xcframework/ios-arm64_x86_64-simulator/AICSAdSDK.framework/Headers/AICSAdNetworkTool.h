//
//  AICSAdNetworkTool.h
//  AICSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "AICSAdDataModel.h"
#import "AICSAdTypedef.h"
#import "AICSNewStoreLiteRequestTool.h"
#import "NSString+AICSGenerateHash.h"

@interface AICSAdNetworkTool : NSObject

+ (AICSAdNetworkTool *)shared;
@property(nonatomic, copy) AICSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)aIrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(AICSAdRequestCompleteBlock)complete;

- (void)aIsetCDay:(void(^ _Nullable)(bool success))handle;
@end
