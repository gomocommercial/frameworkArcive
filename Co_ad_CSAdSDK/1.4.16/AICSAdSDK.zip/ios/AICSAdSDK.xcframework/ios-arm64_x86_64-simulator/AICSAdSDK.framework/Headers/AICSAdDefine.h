//
//  AICSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define aIkAdvDataSourceFacebook   2 //FB 广告数据源
#define aIkAdvDataSourceAdmob      8 //Admob 广告数据源
#define aIkAdvDataSourceMopub      39//Mopub 广告数据源
#define aIkAdvDataSourceApplovin   20//applovin 广告数据源

#define aIkAdvDataSourceGDT        62//广点通 广告数据源
#define aIkAdvDataSourceBaidu      63//百度 广告数据源
#define aIkAdvDataSourceBU         64//头条 广告数据源
#define aIkAdvDataSourceABU         70//头条聚合 广告数据源
#define aIkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define aIkAdvDataSourcePangle     74//pangle 广告数据源

#define aIkOnlineAdvTypeBanner                   1  //banner
#define aIkOnlineAdvTypeInterstitial             2  //全屏
#define aIkOnlineAdvTypeNative                   3 //native
#define aIkOnlineAdvTypeVideo                    4 //视频
#define aIkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define aIkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define aIkOnlineAdvTypeOpen                     8 //开屏
#define aIkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define aIkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define aIkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define aIkAdServerConfigError  -1 //服务器返回数据不正确
#define aIkAdLoadConfigFailed  -2 //广告加载失败


#define aIAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define aIkCSAdInstallDays @"aIkCSAdInstallDays"
#define aIkCSAdModule_key @"aIkCSAdModule_key_%@"
#define aIkCSNewAdModule_key @"aIkCSNewAdModule_key_%@"
#define aIkCSAdInstallTime @"aIkCSAdInstallTime"
#define aIkCSAdInstallHours @"aIkCSAdInstallHours"
#define aIkCSAdLastGetServerTime @"aIkCSAdLastRequestTime"
#define aIkCSAdloadTime 30

#define aIkCSLoadAdTimeOutNotification @"aIKCSLoadAdTimeOutNotification"
#define aIkCSLoadAdTimeOutNotificationKey @"aIKCSLoadAdTimeOutKey"

