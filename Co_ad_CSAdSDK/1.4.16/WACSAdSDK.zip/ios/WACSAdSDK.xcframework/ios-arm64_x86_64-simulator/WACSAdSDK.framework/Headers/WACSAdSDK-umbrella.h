#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WACSAdSDK.h"
#import "WACSAdPreload.h"
#import "WACSAdLoadDataProtocol.h"
#import "WACSAdLoadShowProtocol.h"
#import "WACSAdLoadProtocol.h"
#import "WACSAdLoadBase.h"
#import "WACSAdLoadInterstitial.h"
#import "WACSAdLoadNative.h"
#import "WACSAdLoadReward.h"
#import "WACSAdLoadOpen.h"
#import "WACSAdLoadBanner.h"
#import "WACSAdManager.h"
#import "WACSAdSetupParams.h"
#import "WACSAdSetupParamsMaker.h"
#import "WACSAdDefine.h"
#import "WACSAdTypedef.h"
#import "WACSAdStatistics.h"
#import "WACSAdDataModel.h"
#import "WACSAdNetworkTool.h"
#import "WACSNewStoreLiteRequestTool.h"
#import "NSString+WACSGenerateHash.h"

FOUNDATION_EXPORT double WACSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char WACSAdSDKVersionString[];

