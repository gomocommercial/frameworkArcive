//
//  WACSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    WACSAdLoadSuccess = 1,
    WACSAdLoadFailure = -1,
    WACSAdLoadTimeout = -2
} WACSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    WACSAdPreloadSuccess = 1,
    //预加载失败
    WACSAdPreloadFailure = -1,
    //重复加载
    WACSAdPreloadRepeat = -2,
} WACSAdPreloadStatus;


typedef enum : NSUInteger {
    
    WACSAdWillAppear,//即将出现
    WACSAdDidAppear,//已经出现
    WACSAdWillDisappear,//即将消失
    WACSAdDidDisappear,//已经消失
    WACSAdMuted,//静音广告
    WACSAdWillLeaveApplication,//将要离开App

    WACSAdVideoStart,//开始播放 常用于video
    WACSAdVideoComplete,//播放完成 常用于video
    WACSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    WACSAdVideoServerFail,//连接服务器成功，常用于fb video

    WACSAdNativeDidDownload,//下载完成 常用于fb Native
    WACSAdNativeFinishClick,//完成点击 常用与fb Native
    
    WACSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    WACSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    WACSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    WACSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    WACSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    WACSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    WACSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    WACSAdBUOpenDidAutoDimiss,//开屏自动消失
    WACSAdBUOpenRenderSuccess, //渲染成功
    WACSAdBUOpenRenderFail, //渲染失败
    WACSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    WACSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    WACSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    WACSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    WACSAdDidPresentFullScreen,//插屏弹出全屏广告
    WACSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    WACSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    WACSAdPlayerStatusStarted,//开始播放
    WACSAdPlayerStatusPaused,//用户行为导致暂停
    WACSAdPlayerStatusStoped,//播放停止
    WACSAdPlayerStatusError,//播放出错
    WACSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    WACSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    WACSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    WACSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    WACSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    WACSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    WACSAdRecordImpression, //广告曝光已记录
    WACSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    WACSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    WACSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    WACSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    WACSAdABUOpenWillPresentFullScreen,
    WACSAdABUOpenDidShowFailed,
    WACSAdABUOpenWillDissmissFullScreen,
    WACSAdABUOpenCountdownToZero,
    
    WACSAdABUBannerWillPresentFullScreen,
    WACSAdABUBannerWillDismissFullScreen,
    
    WACSAdABURewardDidLoad,
    WACSAdABURewardRenderFail,
    WACSAdABURewardDidShowFailed,

} WACSAdEvent;

typedef void (^WACSAdLoadCompleteBlock)(WACSAdLoadStatus adLoadStatus);

@class WACSAdSetupParamsMaker;
@class WACSAdSetupParams;

typedef WACSAdSetupParamsMaker *(^WACSAdStringInit)(NSString *);
typedef WACSAdSetupParamsMaker *(^WACSAdBoolInit)(BOOL);
typedef WACSAdSetupParamsMaker *(^WACSAdIntegerInit)(NSInteger);
typedef WACSAdSetupParamsMaker *(^WACSAdLongInit)(long);
typedef WACSAdSetupParamsMaker *(^WACSAdArrayInit)(NSArray *);
typedef WACSAdSetupParams *(^WACSAdMakeInit)(void);


@class WACSAdDataModel;
typedef void (^WACSAdRequestCompleteBlock)(NSMutableArray<WACSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^WACSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^WACSAdPreloadCompleteBlock)(WACSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
