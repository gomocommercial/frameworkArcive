//
//  WACSAdStatistics.h
//  WACSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "WACSAdDataModel.h"
#import "WACSAdTypedef.h"
#import "WACSAdLoadBase.h"
@interface WACSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)wAadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)wAadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)wAadRewardVideoCompleteStatistic:(WACSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)wAadShowStatistic:(WACSAdDataModel *)dataModel adload:(nonnull WACSAdLoadBase<WACSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)wAadClickStatistic:(WACSAdDataModel *)dataModel adload:(nonnull WACSAdLoadBase<WACSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)wAadUploadRevenueStatistic:(WACSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
