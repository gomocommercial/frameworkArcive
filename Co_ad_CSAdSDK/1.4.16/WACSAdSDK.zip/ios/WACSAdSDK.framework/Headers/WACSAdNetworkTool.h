//
//  WACSAdNetworkTool.h
//  WACSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "WACSAdDataModel.h"
#import "WACSAdTypedef.h"
#import "WACSNewStoreLiteRequestTool.h"
#import "NSString+WACSGenerateHash.h"

@interface WACSAdNetworkTool : NSObject

+ (WACSAdNetworkTool *)shared;
@property(nonatomic, copy) WACSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)wArequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(WACSAdRequestCompleteBlock)complete;

- (void)wAsetCDay:(void(^ _Nullable)(bool success))handle;
@end
