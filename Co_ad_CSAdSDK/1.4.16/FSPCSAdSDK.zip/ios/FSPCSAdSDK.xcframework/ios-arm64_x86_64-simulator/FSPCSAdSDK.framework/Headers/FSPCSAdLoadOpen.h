//
//  FSPCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "FSPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSPCSAdLoadOpen : FSPCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
