//
//  FSPCSAdLoadDataProtocol.h
//  FSPCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "FSPCSAdTypedef.h"

@class FSPCSAdDataModel;
@class FSPCSAdLoadBase;

@protocol FSPCSAdLoadProtocol;

@protocol FSPCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)fSPonAdInfoFinish:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)fSPonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)fSPonAdFail:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
