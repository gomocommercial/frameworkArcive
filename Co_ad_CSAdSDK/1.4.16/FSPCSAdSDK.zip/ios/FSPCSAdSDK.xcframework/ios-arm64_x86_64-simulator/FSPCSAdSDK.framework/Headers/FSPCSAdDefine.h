//
//  FSPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define fSPkAdvDataSourceFacebook   2 //FB 广告数据源
#define fSPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define fSPkAdvDataSourceMopub      39//Mopub 广告数据源
#define fSPkAdvDataSourceApplovin   20//applovin 广告数据源

#define fSPkAdvDataSourceGDT        62//广点通 广告数据源
#define fSPkAdvDataSourceBaidu      63//百度 广告数据源
#define fSPkAdvDataSourceBU         64//头条 广告数据源
#define fSPkAdvDataSourceABU         70//头条聚合 广告数据源
#define fSPkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define fSPkAdvDataSourcePangle     74//pangle 广告数据源

#define fSPkOnlineAdvTypeBanner                   1  //banner
#define fSPkOnlineAdvTypeInterstitial             2  //全屏
#define fSPkOnlineAdvTypeNative                   3 //native
#define fSPkOnlineAdvTypeVideo                    4 //视频
#define fSPkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define fSPkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define fSPkOnlineAdvTypeOpen                     8 //开屏
#define fSPkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define fSPkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define fSPkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define fSPkAdServerConfigError  -1 //服务器返回数据不正确
#define fSPkAdLoadConfigFailed  -2 //广告加载失败


#define fSPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define fSPkCSAdInstallDays @"fSPkCSAdInstallDays"
#define fSPkCSAdModule_key @"fSPkCSAdModule_key_%@"
#define fSPkCSNewAdModule_key @"fSPkCSNewAdModule_key_%@"
#define fSPkCSAdInstallTime @"fSPkCSAdInstallTime"
#define fSPkCSAdInstallHours @"fSPkCSAdInstallHours"
#define fSPkCSAdLastGetServerTime @"fSPkCSAdLastRequestTime"
#define fSPkCSAdloadTime 30

#define fSPkCSLoadAdTimeOutNotification @"fSPKCSLoadAdTimeOutNotification"
#define fSPkCSLoadAdTimeOutNotificationKey @"fSPKCSLoadAdTimeOutKey"

