//
//  FSPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FSPCSAdTypedef.h"

@class FSPCSAdLoadBase;

@protocol FSPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FSPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)fSPonAdShowed:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)fSPonAdClicked:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)fSPonAdClosed:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)fSPonAdVideoCompletePlaying:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)fSPonAdVideoGotReward:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload;
-(void)fSPonAdDidPayRevenue:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)fSPonAdShowFail:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)fSPonAdOtherEvent:(FSPCSAdLoadBase<FSPCSAdLoadProtocol> *)adload event:(FSPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
