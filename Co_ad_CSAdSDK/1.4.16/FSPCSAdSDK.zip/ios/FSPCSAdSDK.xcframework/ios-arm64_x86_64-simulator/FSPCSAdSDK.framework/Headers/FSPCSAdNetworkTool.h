//
//  FSPCSAdNetworkTool.h
//  FSPCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "FSPCSAdDataModel.h"
#import "FSPCSAdTypedef.h"
#import "FSPCSNewStoreLiteRequestTool.h"
#import "NSString+FSPCSGenerateHash.h"

@interface FSPCSAdNetworkTool : NSObject

+ (FSPCSAdNetworkTool *)shared;
@property(nonatomic, copy) FSPCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)fSPrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(FSPCSAdRequestCompleteBlock)complete;

- (void)fSPsetCDay:(void(^ _Nullable)(bool success))handle;
@end
