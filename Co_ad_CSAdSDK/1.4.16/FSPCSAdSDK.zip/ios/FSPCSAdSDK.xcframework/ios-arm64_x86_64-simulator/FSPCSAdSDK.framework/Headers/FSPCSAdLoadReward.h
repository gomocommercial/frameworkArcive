//
//  FSPCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "FSPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSPCSAdLoadReward : FSPCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
