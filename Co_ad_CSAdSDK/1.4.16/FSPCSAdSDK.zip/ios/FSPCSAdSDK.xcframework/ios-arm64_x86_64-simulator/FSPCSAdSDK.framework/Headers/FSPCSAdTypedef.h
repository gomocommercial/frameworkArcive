//
//  FSPCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    FSPCSAdLoadSuccess = 1,
    FSPCSAdLoadFailure = -1,
    FSPCSAdLoadTimeout = -2
} FSPCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    FSPCSAdPreloadSuccess = 1,
    //预加载失败
    FSPCSAdPreloadFailure = -1,
    //重复加载
    FSPCSAdPreloadRepeat = -2,
} FSPCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    FSPCSAdWillAppear,//即将出现
    FSPCSAdDidAppear,//已经出现
    FSPCSAdWillDisappear,//即将消失
    FSPCSAdDidDisappear,//已经消失
    FSPCSAdMuted,//静音广告
    FSPCSAdWillLeaveApplication,//将要离开App

    FSPCSAdVideoStart,//开始播放 常用于video
    FSPCSAdVideoComplete,//播放完成 常用于video
    FSPCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    FSPCSAdVideoServerFail,//连接服务器成功，常用于fb video

    FSPCSAdNativeDidDownload,//下载完成 常用于fb Native
    FSPCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    FSPCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    FSPCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    FSPCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    FSPCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    FSPCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    FSPCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    FSPCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    FSPCSAdBUOpenDidAutoDimiss,//开屏自动消失
    FSPCSAdBUOpenRenderSuccess, //渲染成功
    FSPCSAdBUOpenRenderFail, //渲染失败
    FSPCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    FSPCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    FSPCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    FSPCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    FSPCSAdDidPresentFullScreen,//插屏弹出全屏广告
    FSPCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    FSPCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    FSPCSAdPlayerStatusStarted,//开始播放
    FSPCSAdPlayerStatusPaused,//用户行为导致暂停
    FSPCSAdPlayerStatusStoped,//播放停止
    FSPCSAdPlayerStatusError,//播放出错
    FSPCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    FSPCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    FSPCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    FSPCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    FSPCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    FSPCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    FSPCSAdRecordImpression, //广告曝光已记录
    FSPCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    FSPCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    FSPCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    FSPCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    FSPCSAdABUOpenWillPresentFullScreen,
    FSPCSAdABUOpenDidShowFailed,
    FSPCSAdABUOpenWillDissmissFullScreen,
    FSPCSAdABUOpenCountdownToZero,
    
    FSPCSAdABUBannerWillPresentFullScreen,
    FSPCSAdABUBannerWillDismissFullScreen,
    
    FSPCSAdABURewardDidLoad,
    FSPCSAdABURewardRenderFail,
    FSPCSAdABURewardDidShowFailed,

} FSPCSAdEvent;

typedef void (^FSPCSAdLoadCompleteBlock)(FSPCSAdLoadStatus adLoadStatus);

@class FSPCSAdSetupParamsMaker;
@class FSPCSAdSetupParams;

typedef FSPCSAdSetupParamsMaker *(^FSPCSAdStringInit)(NSString *);
typedef FSPCSAdSetupParamsMaker *(^FSPCSAdBoolInit)(BOOL);
typedef FSPCSAdSetupParamsMaker *(^FSPCSAdIntegerInit)(NSInteger);
typedef FSPCSAdSetupParamsMaker *(^FSPCSAdLongInit)(long);
typedef FSPCSAdSetupParamsMaker *(^FSPCSAdArrayInit)(NSArray *);
typedef FSPCSAdSetupParams *(^FSPCSAdMakeInit)(void);


@class FSPCSAdDataModel;
typedef void (^FSPCSAdRequestCompleteBlock)(NSMutableArray<FSPCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^FSPCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^FSPCSAdPreloadCompleteBlock)(FSPCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
