//
//  PSECSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PSECSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdLoadNative : PSECSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
