//
//  PSECSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PSECSAdLoadBase.h"
#import "PSECSAdDataModel.h"
#import "PSECSAdLoadProtocol.h"
#import "PSECSAdLoadDataProtocol.h"
#import "PSECSAdLoadShowProtocol.h"
#import "PSECSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pSEsetupByBlock:(void (^ _Nonnull)(PSECSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pSEloadAd:(NSString *)moduleId delegate:(id<PSECSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pSEadShowStatistic:(PSECSAdDataModel *)dataModel adload:(nonnull PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pSEadClickStatistic:(PSECSAdDataModel *)dataModel adload:(nonnull PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pSEaddCustomFecher:(Class<PSECSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
