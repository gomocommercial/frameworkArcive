//
//  PSECSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PSECSAdTypedef.h"

@class PSECSAdLoadBase;

@protocol PSECSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PSECSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pSEonAdShowed:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pSEonAdClicked:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pSEonAdClosed:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pSEonAdVideoCompletePlaying:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pSEonAdVideoGotReward:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload;
-(void)pSEonAdDidPayRevenue:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)pSEonAdShowFail:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pSEonAdOtherEvent:(PSECSAdLoadBase<PSECSAdLoadProtocol> *)adload event:(PSECSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
