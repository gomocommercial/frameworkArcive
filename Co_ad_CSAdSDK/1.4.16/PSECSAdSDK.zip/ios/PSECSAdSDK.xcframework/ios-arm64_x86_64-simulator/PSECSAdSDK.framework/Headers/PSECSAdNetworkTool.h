//
//  PSECSAdNetworkTool.h
//  PSECSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PSECSAdDataModel.h"
#import "PSECSAdTypedef.h"
#import "PSECSNewStoreLiteRequestTool.h"
#import "NSString+PSECSGenerateHash.h"

@interface PSECSAdNetworkTool : NSObject

+ (PSECSAdNetworkTool *)shared;
@property(nonatomic, copy) PSECSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pSErequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PSECSAdRequestCompleteBlock)complete;

- (void)pSEsetCDay:(void(^ _Nullable)(bool success))handle;
@end
