//
//  PTCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PTCSAdLoadBase.h"
#import "PTCSAdDataModel.h"
#import "PTCSAdLoadProtocol.h"
#import "PTCSAdLoadDataProtocol.h"
#import "PTCSAdLoadShowProtocol.h"
#import "PTCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PTCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pTsetupByBlock:(void (^ _Nonnull)(PTCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pTloadAd:(NSString *)moduleId delegate:(id<PTCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pTadShowStatistic:(PTCSAdDataModel *)dataModel adload:(nonnull PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pTadClickStatistic:(PTCSAdDataModel *)dataModel adload:(nonnull PTCSAdLoadBase<PTCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pTaddCustomFecher:(Class<PTCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
