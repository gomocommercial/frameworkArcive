//
//  PTCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PTCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PTCSAdLoadNative : PTCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
