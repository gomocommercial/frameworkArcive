//
//  PTCSAdNetworkTool.h
//  PTCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PTCSAdDataModel.h"
#import "PTCSAdTypedef.h"
#import "PTCSNewStoreLiteRequestTool.h"
#import "NSString+PTCSGenerateHash.h"

@interface PTCSAdNetworkTool : NSObject

+ (PTCSAdNetworkTool *)shared;
@property(nonatomic, copy) PTCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pTrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PTCSAdRequestCompleteBlock)complete;

- (void)pTsetCDay:(void(^ _Nullable)(bool success))handle;
@end
