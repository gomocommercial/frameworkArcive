//
//  JMSCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define jMSkAdvDataSourceFacebook   2 //FB 广告数据源
#define jMSkAdvDataSourceAdmob      8 //Admob 广告数据源
#define jMSkAdvDataSourceMopub      39//Mopub 广告数据源
#define jMSkAdvDataSourceApplovin   20//applovin 广告数据源

#define jMSkAdvDataSourceGDT        62//广点通 广告数据源
#define jMSkAdvDataSourceBaidu      63//百度 广告数据源
#define jMSkAdvDataSourceBU         64//头条 广告数据源
#define jMSkAdvDataSourceABU         70//头条聚合 广告数据源
#define jMSkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define jMSkAdvDataSourcePangle     74//pangle 广告数据源

#define jMSkOnlineAdvTypeBanner                   1  //banner
#define jMSkOnlineAdvTypeInterstitial             2  //全屏
#define jMSkOnlineAdvTypeNative                   3 //native
#define jMSkOnlineAdvTypeVideo                    4 //视频
#define jMSkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define jMSkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define jMSkOnlineAdvTypeOpen                     8 //开屏
#define jMSkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define jMSkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define jMSkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define jMSkAdServerConfigError  -1 //服务器返回数据不正确
#define jMSkAdLoadConfigFailed  -2 //广告加载失败


#define jMSAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define jMSkCSAdInstallDays @"jMSkCSAdInstallDays"
#define jMSkCSAdModule_key @"jMSkCSAdModule_key_%@"
#define jMSkCSNewAdModule_key @"jMSkCSNewAdModule_key_%@"
#define jMSkCSAdInstallTime @"jMSkCSAdInstallTime"
#define jMSkCSAdInstallHours @"jMSkCSAdInstallHours"
#define jMSkCSAdLastGetServerTime @"jMSkCSAdLastRequestTime"
#define jMSkCSAdloadTime 30

#define jMSkCSLoadAdTimeOutNotification @"jMSKCSLoadAdTimeOutNotification"
#define jMSkCSLoadAdTimeOutNotificationKey @"jMSKCSLoadAdTimeOutKey"

