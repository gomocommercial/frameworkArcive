//
//  JMSCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "JMSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface JMSCSAdLoadOpen : JMSCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
