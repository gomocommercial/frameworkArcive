//
//  JMSCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "JMSCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface JMSCSAdLoadNative : JMSCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
