//
//  JMSCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "JMSCSAdLoadBase.h"
#import "JMSCSAdDataModel.h"
#import "JMSCSAdLoadProtocol.h"
#import "JMSCSAdLoadDataProtocol.h"
#import "JMSCSAdLoadShowProtocol.h"
#import "JMSCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface JMSCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)jMSsetupByBlock:(void (^ _Nonnull)(JMSCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)jMSloadAd:(NSString *)moduleId delegate:(id<JMSCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)jMSadShowStatistic:(JMSCSAdDataModel *)dataModel adload:(nonnull JMSCSAdLoadBase<JMSCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)jMSadClickStatistic:(JMSCSAdDataModel *)dataModel adload:(nonnull JMSCSAdLoadBase<JMSCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)jMSaddCustomFecher:(Class<JMSCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
