//
//  JMSCSAdNetworkTool.h
//  JMSCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "JMSCSAdDataModel.h"
#import "JMSCSAdTypedef.h"
#import "JMSCSNewStoreLiteRequestTool.h"
#import "NSString+JMSCSGenerateHash.h"

@interface JMSCSAdNetworkTool : NSObject

+ (JMSCSAdNetworkTool *)shared;
@property(nonatomic, copy) JMSCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)jMSrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(JMSCSAdRequestCompleteBlock)complete;

- (void)jMSsetCDay:(void(^ _Nullable)(bool success))handle;
@end
