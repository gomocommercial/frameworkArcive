//
//  MGCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MGCSAdTypedef.h"

@class MGCSAdLoadBase;

@protocol MGCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MGCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mGonAdShowed:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)mGonAdClicked:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mGonAdClosed:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mGonAdVideoCompletePlaying:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)mGonAdVideoGotReward:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload;
-(void)mGonAdDidPayRevenue:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)mGonAdShowFail:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mGonAdOtherEvent:(MGCSAdLoadBase<MGCSAdLoadProtocol> *)adload event:(MGCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
