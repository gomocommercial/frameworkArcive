//
//  MGCSAdNetworkTool.h
//  MGCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "MGCSAdDataModel.h"
#import "MGCSAdTypedef.h"
#import "MGCSNewStoreLiteRequestTool.h"
#import "NSString+MGCSGenerateHash.h"

@interface MGCSAdNetworkTool : NSObject

+ (MGCSAdNetworkTool *)shared;
@property(nonatomic, copy) MGCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)mGrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(MGCSAdRequestCompleteBlock)complete;

- (void)mGsetCDay:(void(^ _Nullable)(bool success))handle;
@end
