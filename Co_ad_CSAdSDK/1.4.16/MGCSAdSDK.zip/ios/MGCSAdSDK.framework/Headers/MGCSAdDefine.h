//
//  MGCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define mGkAdvDataSourceFacebook   2 //FB 广告数据源
#define mGkAdvDataSourceAdmob      8 //Admob 广告数据源
#define mGkAdvDataSourceMopub      39//Mopub 广告数据源
#define mGkAdvDataSourceApplovin   20//applovin 广告数据源

#define mGkAdvDataSourceGDT        62//广点通 广告数据源
#define mGkAdvDataSourceBaidu      63//百度 广告数据源
#define mGkAdvDataSourceBU         64//头条 广告数据源
#define mGkAdvDataSourceABU         70//头条聚合 广告数据源
#define mGkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define mGkAdvDataSourcePangle     74//pangle 广告数据源

#define mGkOnlineAdvTypeBanner                   1  //banner
#define mGkOnlineAdvTypeInterstitial             2  //全屏
#define mGkOnlineAdvTypeNative                   3 //native
#define mGkOnlineAdvTypeVideo                    4 //视频
#define mGkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define mGkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define mGkOnlineAdvTypeOpen                     8 //开屏
#define mGkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define mGkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define mGkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define mGkAdServerConfigError  -1 //服务器返回数据不正确
#define mGkAdLoadConfigFailed  -2 //广告加载失败


#define mGAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define mGkCSAdInstallDays @"mGkCSAdInstallDays"
#define mGkCSAdModule_key @"mGkCSAdModule_key_%@"
#define mGkCSNewAdModule_key @"mGkCSNewAdModule_key_%@"
#define mGkCSAdInstallTime @"mGkCSAdInstallTime"
#define mGkCSAdInstallHours @"mGkCSAdInstallHours"
#define mGkCSAdLastGetServerTime @"mGkCSAdLastRequestTime"
#define mGkCSAdloadTime 30

#define mGkCSLoadAdTimeOutNotification @"mGKCSLoadAdTimeOutNotification"
#define mGkCSLoadAdTimeOutNotificationKey @"mGKCSLoadAdTimeOutKey"

