//
//  EATCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    EATCSAdLoadSuccess = 1,
    EATCSAdLoadFailure = -1,
    EATCSAdLoadTimeout = -2
} EATCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    EATCSAdPreloadSuccess = 1,
    //预加载失败
    EATCSAdPreloadFailure = -1,
    //重复加载
    EATCSAdPreloadRepeat = -2,
} EATCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    EATCSAdWillAppear,//即将出现
    EATCSAdDidAppear,//已经出现
    EATCSAdWillDisappear,//即将消失
    EATCSAdDidDisappear,//已经消失
    EATCSAdMuted,//静音广告
    EATCSAdWillLeaveApplication,//将要离开App

    EATCSAdVideoStart,//开始播放 常用于video
    EATCSAdVideoComplete,//播放完成 常用于video
    EATCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    EATCSAdVideoServerFail,//连接服务器成功，常用于fb video

    EATCSAdNativeDidDownload,//下载完成 常用于fb Native
    EATCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    EATCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    EATCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    EATCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    EATCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    EATCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    EATCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    EATCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    EATCSAdBUOpenDidAutoDimiss,//开屏自动消失
    EATCSAdBUOpenRenderSuccess, //渲染成功
    EATCSAdBUOpenRenderFail, //渲染失败
    EATCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    EATCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    EATCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    EATCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    EATCSAdDidPresentFullScreen,//插屏弹出全屏广告
    EATCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    EATCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    EATCSAdPlayerStatusStarted,//开始播放
    EATCSAdPlayerStatusPaused,//用户行为导致暂停
    EATCSAdPlayerStatusStoped,//播放停止
    EATCSAdPlayerStatusError,//播放出错
    EATCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    EATCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    EATCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    EATCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    EATCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    EATCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    EATCSAdRecordImpression, //广告曝光已记录
    EATCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    EATCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    EATCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    EATCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    EATCSAdABUOpenWillPresentFullScreen,
    EATCSAdABUOpenDidShowFailed,
    EATCSAdABUOpenWillDissmissFullScreen,
    EATCSAdABUOpenCountdownToZero,
    
    EATCSAdABUBannerWillPresentFullScreen,
    EATCSAdABUBannerWillDismissFullScreen,
    
    EATCSAdABURewardDidLoad,
    EATCSAdABURewardRenderFail,
    EATCSAdABURewardDidShowFailed,

} EATCSAdEvent;

typedef void (^EATCSAdLoadCompleteBlock)(EATCSAdLoadStatus adLoadStatus);

@class EATCSAdSetupParamsMaker;
@class EATCSAdSetupParams;

typedef EATCSAdSetupParamsMaker *(^EATCSAdStringInit)(NSString *);
typedef EATCSAdSetupParamsMaker *(^EATCSAdBoolInit)(BOOL);
typedef EATCSAdSetupParamsMaker *(^EATCSAdIntegerInit)(NSInteger);
typedef EATCSAdSetupParamsMaker *(^EATCSAdLongInit)(long);
typedef EATCSAdSetupParamsMaker *(^EATCSAdArrayInit)(NSArray *);
typedef EATCSAdSetupParams *(^EATCSAdMakeInit)(void);


@class EATCSAdDataModel;
typedef void (^EATCSAdRequestCompleteBlock)(NSMutableArray<EATCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^EATCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^EATCSAdPreloadCompleteBlock)(EATCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
