//
//  EATCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define eATkAdvDataSourceFacebook   2 //FB 广告数据源
#define eATkAdvDataSourceAdmob      8 //Admob 广告数据源
#define eATkAdvDataSourceMopub      39//Mopub 广告数据源
#define eATkAdvDataSourceApplovin   20//applovin 广告数据源

#define eATkAdvDataSourceGDT        62//广点通 广告数据源
#define eATkAdvDataSourceBaidu      63//百度 广告数据源
#define eATkAdvDataSourceBU         64//头条 广告数据源
#define eATkAdvDataSourceABU         70//头条聚合 广告数据源
#define eATkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define eATkAdvDataSourcePangle     74//pangle 广告数据源

#define eATkOnlineAdvTypeBanner                   1  //banner
#define eATkOnlineAdvTypeInterstitial             2  //全屏
#define eATkOnlineAdvTypeNative                   3 //native
#define eATkOnlineAdvTypeVideo                    4 //视频
#define eATkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define eATkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define eATkOnlineAdvTypeOpen                     8 //开屏
#define eATkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define eATkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define eATkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define eATkAdServerConfigError  -1 //服务器返回数据不正确
#define eATkAdLoadConfigFailed  -2 //广告加载失败


#define eATAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define eATkCSAdInstallDays @"eATkCSAdInstallDays"
#define eATkCSAdModule_key @"eATkCSAdModule_key_%@"
#define eATkCSNewAdModule_key @"eATkCSNewAdModule_key_%@"
#define eATkCSAdInstallTime @"eATkCSAdInstallTime"
#define eATkCSAdInstallHours @"eATkCSAdInstallHours"
#define eATkCSAdLastGetServerTime @"eATkCSAdLastRequestTime"
#define eATkCSAdloadTime 30

#define eATkCSLoadAdTimeOutNotification @"eATKCSLoadAdTimeOutNotification"
#define eATkCSLoadAdTimeOutNotificationKey @"eATKCSLoadAdTimeOutKey"

