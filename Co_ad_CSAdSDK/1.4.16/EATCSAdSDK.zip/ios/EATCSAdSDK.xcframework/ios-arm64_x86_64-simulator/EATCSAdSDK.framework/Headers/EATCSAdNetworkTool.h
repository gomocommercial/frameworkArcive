//
//  EATCSAdNetworkTool.h
//  EATCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "EATCSAdDataModel.h"
#import "EATCSAdTypedef.h"
#import "EATCSNewStoreLiteRequestTool.h"
#import "NSString+EATCSGenerateHash.h"

@interface EATCSAdNetworkTool : NSObject

+ (EATCSAdNetworkTool *)shared;
@property(nonatomic, copy) EATCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)eATrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(EATCSAdRequestCompleteBlock)complete;

- (void)eATsetCDay:(void(^ _Nullable)(bool success))handle;
@end
