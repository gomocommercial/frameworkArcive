//
//  EATCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "EATCSAdTypedef.h"

@class EATCSAdLoadBase;

@protocol EATCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol EATCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)eATonAdShowed:(EATCSAdLoadBase<EATCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)eATonAdClicked:(EATCSAdLoadBase<EATCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)eATonAdClosed:(EATCSAdLoadBase<EATCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)eATonAdVideoCompletePlaying:(EATCSAdLoadBase<EATCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)eATonAdVideoGotReward:(EATCSAdLoadBase<EATCSAdLoadProtocol> *)adload;
-(void)eATonAdDidPayRevenue:(EATCSAdLoadBase<EATCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)eATonAdShowFail:(EATCSAdLoadBase<EATCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)eATonAdOtherEvent:(EATCSAdLoadBase<EATCSAdLoadProtocol> *)adload event:(EATCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
