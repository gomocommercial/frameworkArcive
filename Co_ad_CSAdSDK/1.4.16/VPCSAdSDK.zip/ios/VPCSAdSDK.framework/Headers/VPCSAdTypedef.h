//
//  VPCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    VPCSAdLoadSuccess = 1,
    VPCSAdLoadFailure = -1,
    VPCSAdLoadTimeout = -2
} VPCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    VPCSAdPreloadSuccess = 1,
    //预加载失败
    VPCSAdPreloadFailure = -1,
    //重复加载
    VPCSAdPreloadRepeat = -2,
} VPCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    VPCSAdWillAppear,//即将出现
    VPCSAdDidAppear,//已经出现
    VPCSAdWillDisappear,//即将消失
    VPCSAdDidDisappear,//已经消失
    VPCSAdMuted,//静音广告
    VPCSAdWillLeaveApplication,//将要离开App

    VPCSAdVideoStart,//开始播放 常用于video
    VPCSAdVideoComplete,//播放完成 常用于video
    VPCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    VPCSAdVideoServerFail,//连接服务器成功，常用于fb video

    VPCSAdNativeDidDownload,//下载完成 常用于fb Native
    VPCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    VPCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    VPCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    VPCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    VPCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    VPCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    VPCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    VPCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    VPCSAdBUOpenDidAutoDimiss,//开屏自动消失
    VPCSAdBUOpenRenderSuccess, //渲染成功
    VPCSAdBUOpenRenderFail, //渲染失败
    VPCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    VPCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    VPCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    VPCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    VPCSAdDidPresentFullScreen,//插屏弹出全屏广告
    VPCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    VPCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    VPCSAdPlayerStatusStarted,//开始播放
    VPCSAdPlayerStatusPaused,//用户行为导致暂停
    VPCSAdPlayerStatusStoped,//播放停止
    VPCSAdPlayerStatusError,//播放出错
    VPCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    VPCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    VPCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    VPCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    VPCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    VPCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    VPCSAdRecordImpression, //广告曝光已记录
    VPCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    VPCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    VPCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    VPCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    VPCSAdABUOpenWillPresentFullScreen,
    VPCSAdABUOpenDidShowFailed,
    VPCSAdABUOpenWillDissmissFullScreen,
    VPCSAdABUOpenCountdownToZero,
    
    VPCSAdABUBannerWillPresentFullScreen,
    VPCSAdABUBannerWillDismissFullScreen,
    
    VPCSAdABURewardDidLoad,
    VPCSAdABURewardRenderFail,
    VPCSAdABURewardDidShowFailed,

} VPCSAdEvent;

typedef void (^VPCSAdLoadCompleteBlock)(VPCSAdLoadStatus adLoadStatus);

@class VPCSAdSetupParamsMaker;
@class VPCSAdSetupParams;

typedef VPCSAdSetupParamsMaker *(^VPCSAdStringInit)(NSString *);
typedef VPCSAdSetupParamsMaker *(^VPCSAdBoolInit)(BOOL);
typedef VPCSAdSetupParamsMaker *(^VPCSAdIntegerInit)(NSInteger);
typedef VPCSAdSetupParamsMaker *(^VPCSAdLongInit)(long);
typedef VPCSAdSetupParamsMaker *(^VPCSAdArrayInit)(NSArray *);
typedef VPCSAdSetupParams *(^VPCSAdMakeInit)(void);


@class VPCSAdDataModel;
typedef void (^VPCSAdRequestCompleteBlock)(NSMutableArray<VPCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^VPCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^VPCSAdPreloadCompleteBlock)(VPCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
