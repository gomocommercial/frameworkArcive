//
//  VPCSAdLoadDataProtocol.h
//  VPCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "VPCSAdTypedef.h"

@class VPCSAdDataModel;
@class VPCSAdLoadBase;

@protocol VPCSAdLoadProtocol;

@protocol VPCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)vPonAdInfoFinish:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)vPonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)vPonAdFail:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
