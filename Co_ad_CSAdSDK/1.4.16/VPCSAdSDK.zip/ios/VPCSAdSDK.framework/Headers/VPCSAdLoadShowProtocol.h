//
//  VPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "VPCSAdTypedef.h"

@class VPCSAdLoadBase;

@protocol VPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol VPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)vPonAdShowed:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)vPonAdClicked:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)vPonAdClosed:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)vPonAdVideoCompletePlaying:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)vPonAdVideoGotReward:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload;
-(void)vPonAdDidPayRevenue:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)vPonAdShowFail:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)vPonAdOtherEvent:(VPCSAdLoadBase<VPCSAdLoadProtocol> *)adload event:(VPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
