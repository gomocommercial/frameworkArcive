//
//  VPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define vPkAdvDataSourceFacebook   2 //FB 广告数据源
#define vPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define vPkAdvDataSourceMopub      39//Mopub 广告数据源
#define vPkAdvDataSourceApplovin   20//applovin 广告数据源

#define vPkAdvDataSourceGDT        62//广点通 广告数据源
#define vPkAdvDataSourceBaidu      63//百度 广告数据源
#define vPkAdvDataSourceBU         64//头条 广告数据源
#define vPkAdvDataSourceABU         70//头条聚合 广告数据源
#define vPkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define vPkAdvDataSourcePangle     74//pangle 广告数据源

#define vPkOnlineAdvTypeBanner                   1  //banner
#define vPkOnlineAdvTypeInterstitial             2  //全屏
#define vPkOnlineAdvTypeNative                   3 //native
#define vPkOnlineAdvTypeVideo                    4 //视频
#define vPkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define vPkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define vPkOnlineAdvTypeOpen                     8 //开屏
#define vPkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define vPkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define vPkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define vPkAdServerConfigError  -1 //服务器返回数据不正确
#define vPkAdLoadConfigFailed  -2 //广告加载失败


#define vPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define vPkCSAdInstallDays @"vPkCSAdInstallDays"
#define vPkCSAdModule_key @"vPkCSAdModule_key_%@"
#define vPkCSNewAdModule_key @"vPkCSNewAdModule_key_%@"
#define vPkCSAdInstallTime @"vPkCSAdInstallTime"
#define vPkCSAdInstallHours @"vPkCSAdInstallHours"
#define vPkCSAdLastGetServerTime @"vPkCSAdLastRequestTime"
#define vPkCSAdloadTime 30

#define vPkCSLoadAdTimeOutNotification @"vPKCSLoadAdTimeOutNotification"
#define vPkCSLoadAdTimeOutNotificationKey @"vPKCSLoadAdTimeOutKey"

