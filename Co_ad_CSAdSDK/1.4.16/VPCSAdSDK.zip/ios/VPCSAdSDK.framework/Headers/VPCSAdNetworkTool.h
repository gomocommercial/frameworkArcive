//
//  VPCSAdNetworkTool.h
//  VPCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "VPCSAdDataModel.h"
#import "VPCSAdTypedef.h"
#import "VPCSNewStoreLiteRequestTool.h"
#import "NSString+VPCSGenerateHash.h"

@interface VPCSAdNetworkTool : NSObject

+ (VPCSAdNetworkTool *)shared;
@property(nonatomic, copy) VPCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)vPrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(VPCSAdRequestCompleteBlock)complete;

- (void)vPsetCDay:(void(^ _Nullable)(bool success))handle;
@end
