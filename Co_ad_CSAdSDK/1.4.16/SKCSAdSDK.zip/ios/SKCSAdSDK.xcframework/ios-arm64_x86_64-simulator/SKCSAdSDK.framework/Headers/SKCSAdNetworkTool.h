//
//  SKCSAdNetworkTool.h
//  SKCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "SKCSAdDataModel.h"
#import "SKCSAdTypedef.h"
#import "SKCSNewStoreLiteRequestTool.h"
#import "NSString+SKCSGenerateHash.h"

@interface SKCSAdNetworkTool : NSObject

+ (SKCSAdNetworkTool *)shared;
@property(nonatomic, copy) SKCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sKrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(SKCSAdRequestCompleteBlock)complete;

- (void)sKsetCDay:(void(^ _Nullable)(bool success))handle;
@end
