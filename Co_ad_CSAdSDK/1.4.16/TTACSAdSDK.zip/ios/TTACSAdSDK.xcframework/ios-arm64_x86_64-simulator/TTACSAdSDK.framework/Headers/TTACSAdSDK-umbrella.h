#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TTACSAdSDK.h"
#import "TTACSAdPreload.h"
#import "TTACSAdLoadDataProtocol.h"
#import "TTACSAdLoadShowProtocol.h"
#import "TTACSAdLoadProtocol.h"
#import "TTACSAdLoadBase.h"
#import "TTACSAdLoadInterstitial.h"
#import "TTACSAdLoadNative.h"
#import "TTACSAdLoadReward.h"
#import "TTACSAdLoadOpen.h"
#import "TTACSAdLoadBanner.h"
#import "TTACSAdManager.h"
#import "TTACSAdSetupParams.h"
#import "TTACSAdSetupParamsMaker.h"
#import "TTACSAdDefine.h"
#import "TTACSAdTypedef.h"
#import "TTACSAdStatistics.h"
#import "TTACSAdDataModel.h"
#import "TTACSAdNetworkTool.h"
#import "TTACSNewStoreLiteRequestTool.h"
#import "NSString+TTACSGenerateHash.h"

FOUNDATION_EXPORT double TTACSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char TTACSAdSDKVersionString[];

