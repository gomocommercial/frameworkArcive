//
//  TTACSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TTACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdLoadReward : TTACSAdLoadBase

@end

NS_ASSUME_NONNULL_END
