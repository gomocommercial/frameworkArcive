//
//  TTACSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "TTACSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdLoadNative : TTACSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
