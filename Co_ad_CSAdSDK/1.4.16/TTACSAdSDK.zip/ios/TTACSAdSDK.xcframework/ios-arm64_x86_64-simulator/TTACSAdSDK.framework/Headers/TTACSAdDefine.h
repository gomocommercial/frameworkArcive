//
//  TTACSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define tTAkAdvDataSourceFacebook   2 //FB 广告数据源
#define tTAkAdvDataSourceAdmob      8 //Admob 广告数据源
#define tTAkAdvDataSourceMopub      39//Mopub 广告数据源
#define tTAkAdvDataSourceApplovin   20//applovin 广告数据源

#define tTAkAdvDataSourceGDT        62//广点通 广告数据源
#define tTAkAdvDataSourceBaidu      63//百度 广告数据源
#define tTAkAdvDataSourceBU         64//头条 广告数据源
#define tTAkAdvDataSourceABU         70//头条聚合 广告数据源
#define tTAkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define tTAkAdvDataSourcePangle     74//pangle 广告数据源

#define tTAkOnlineAdvTypeBanner                   1  //banner
#define tTAkOnlineAdvTypeInterstitial             2  //全屏
#define tTAkOnlineAdvTypeNative                   3 //native
#define tTAkOnlineAdvTypeVideo                    4 //视频
#define tTAkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define tTAkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define tTAkOnlineAdvTypeOpen                     8 //开屏
#define tTAkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define tTAkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define tTAkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define tTAkAdServerConfigError  -1 //服务器返回数据不正确
#define tTAkAdLoadConfigFailed  -2 //广告加载失败


#define tTAAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define tTAkCSAdInstallDays @"tTAkCSAdInstallDays"
#define tTAkCSAdModule_key @"tTAkCSAdModule_key_%@"
#define tTAkCSNewAdModule_key @"tTAkCSNewAdModule_key_%@"
#define tTAkCSAdInstallTime @"tTAkCSAdInstallTime"
#define tTAkCSAdInstallHours @"tTAkCSAdInstallHours"
#define tTAkCSAdLastGetServerTime @"tTAkCSAdLastRequestTime"
#define tTAkCSAdloadTime 30

#define tTAkCSLoadAdTimeOutNotification @"tTAKCSLoadAdTimeOutNotification"
#define tTAkCSLoadAdTimeOutNotificationKey @"tTAKCSLoadAdTimeOutKey"

