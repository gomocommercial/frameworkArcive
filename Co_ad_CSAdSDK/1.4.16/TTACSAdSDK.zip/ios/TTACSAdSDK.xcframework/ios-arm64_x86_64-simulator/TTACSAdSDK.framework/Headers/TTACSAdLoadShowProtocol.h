//
//  TTACSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "TTACSAdTypedef.h"

@class TTACSAdLoadBase;

@protocol TTACSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol TTACSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)tTAonAdShowed:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)tTAonAdClicked:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)tTAonAdClosed:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)tTAonAdVideoCompletePlaying:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)tTAonAdVideoGotReward:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload;
-(void)tTAonAdDidPayRevenue:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)tTAonAdShowFail:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)tTAonAdOtherEvent:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload event:(TTACSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
