//
//  TTACSAdLoadDataProtocol.h
//  TTACSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "TTACSAdTypedef.h"

@class TTACSAdDataModel;
@class TTACSAdLoadBase;

@protocol TTACSAdLoadProtocol;

@protocol TTACSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)tTAonAdInfoFinish:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)tTAonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)tTAonAdFail:(TTACSAdLoadBase<TTACSAdLoadProtocol> *)adload error:(NSError *)error;
@end
