//
//  TTACSAdNetworkTool.h
//  TTACSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "TTACSAdDataModel.h"
#import "TTACSAdTypedef.h"
#import "TTACSNewStoreLiteRequestTool.h"
#import "NSString+TTACSGenerateHash.h"

@interface TTACSAdNetworkTool : NSObject

+ (TTACSAdNetworkTool *)shared;
@property(nonatomic, copy) TTACSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)tTArequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(TTACSAdRequestCompleteBlock)complete;

- (void)tTAsetCDay:(void(^ _Nullable)(bool success))handle;
@end
