//
//  WIOCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "WIOCSAdLoadBase.h"
#import "WIOCSAdDataModel.h"
#import "WIOCSAdLoadProtocol.h"
#import "WIOCSAdLoadDataProtocol.h"
#import "WIOCSAdLoadShowProtocol.h"
#import "WIOCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface WIOCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)wIOsetupByBlock:(void (^ _Nonnull)(WIOCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)wIOloadAd:(NSString *)moduleId delegate:(id<WIOCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)wIOadShowStatistic:(WIOCSAdDataModel *)dataModel adload:(nonnull WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)wIOadClickStatistic:(WIOCSAdDataModel *)dataModel adload:(nonnull WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)wIOaddCustomFecher:(Class<WIOCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
