//
//  WIOCSAdNetworkTool.h
//  WIOCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "WIOCSAdDataModel.h"
#import "WIOCSAdTypedef.h"
#import "WIOCSNewStoreLiteRequestTool.h"
#import "NSString+WIOCSGenerateHash.h"

@interface WIOCSAdNetworkTool : NSObject

+ (WIOCSAdNetworkTool *)shared;
@property(nonatomic, copy) WIOCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)wIOrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(WIOCSAdRequestCompleteBlock)complete;

- (void)wIOsetCDay:(void(^ _Nullable)(bool success))handle;
@end
