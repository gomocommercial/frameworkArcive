//
//  WIOCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    WIOCSAdLoadSuccess = 1,
    WIOCSAdLoadFailure = -1,
    WIOCSAdLoadTimeout = -2
} WIOCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    WIOCSAdPreloadSuccess = 1,
    //预加载失败
    WIOCSAdPreloadFailure = -1,
    //重复加载
    WIOCSAdPreloadRepeat = -2,
} WIOCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    WIOCSAdWillAppear,//即将出现
    WIOCSAdDidAppear,//已经出现
    WIOCSAdWillDisappear,//即将消失
    WIOCSAdDidDisappear,//已经消失
    WIOCSAdMuted,//静音广告
    WIOCSAdWillLeaveApplication,//将要离开App

    WIOCSAdVideoStart,//开始播放 常用于video
    WIOCSAdVideoComplete,//播放完成 常用于video
    WIOCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    WIOCSAdVideoServerFail,//连接服务器成功，常用于fb video

    WIOCSAdNativeDidDownload,//下载完成 常用于fb Native
    WIOCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    WIOCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    WIOCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    WIOCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    WIOCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    WIOCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    WIOCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    WIOCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    WIOCSAdBUOpenDidAutoDimiss,//开屏自动消失
    WIOCSAdBUOpenRenderSuccess, //渲染成功
    WIOCSAdBUOpenRenderFail, //渲染失败
    WIOCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    WIOCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    WIOCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    WIOCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    WIOCSAdDidPresentFullScreen,//插屏弹出全屏广告
    WIOCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    WIOCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    WIOCSAdPlayerStatusStarted,//开始播放
    WIOCSAdPlayerStatusPaused,//用户行为导致暂停
    WIOCSAdPlayerStatusStoped,//播放停止
    WIOCSAdPlayerStatusError,//播放出错
    WIOCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    WIOCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    WIOCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    WIOCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    WIOCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    WIOCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    WIOCSAdRecordImpression, //广告曝光已记录
    WIOCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    WIOCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    WIOCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    WIOCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    WIOCSAdABUOpenWillPresentFullScreen,
    WIOCSAdABUOpenDidShowFailed,
    WIOCSAdABUOpenWillDissmissFullScreen,
    WIOCSAdABUOpenCountdownToZero,
    
    WIOCSAdABUBannerWillPresentFullScreen,
    WIOCSAdABUBannerWillDismissFullScreen,
    
    WIOCSAdABURewardDidLoad,
    WIOCSAdABURewardRenderFail,
    WIOCSAdABURewardDidShowFailed,

} WIOCSAdEvent;

typedef void (^WIOCSAdLoadCompleteBlock)(WIOCSAdLoadStatus adLoadStatus);

@class WIOCSAdSetupParamsMaker;
@class WIOCSAdSetupParams;

typedef WIOCSAdSetupParamsMaker *(^WIOCSAdStringInit)(NSString *);
typedef WIOCSAdSetupParamsMaker *(^WIOCSAdBoolInit)(BOOL);
typedef WIOCSAdSetupParamsMaker *(^WIOCSAdIntegerInit)(NSInteger);
typedef WIOCSAdSetupParamsMaker *(^WIOCSAdLongInit)(long);
typedef WIOCSAdSetupParamsMaker *(^WIOCSAdArrayInit)(NSArray *);
typedef WIOCSAdSetupParams *(^WIOCSAdMakeInit)(void);


@class WIOCSAdDataModel;
typedef void (^WIOCSAdRequestCompleteBlock)(NSMutableArray<WIOCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^WIOCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^WIOCSAdPreloadCompleteBlock)(WIOCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
