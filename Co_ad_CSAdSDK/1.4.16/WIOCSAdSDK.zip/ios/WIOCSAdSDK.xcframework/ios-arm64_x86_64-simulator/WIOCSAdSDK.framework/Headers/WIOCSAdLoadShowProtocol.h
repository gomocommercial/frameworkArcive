//
//  WIOCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "WIOCSAdTypedef.h"

@class WIOCSAdLoadBase;

@protocol WIOCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol WIOCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)wIOonAdShowed:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)wIOonAdClicked:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)wIOonAdClosed:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)wIOonAdVideoCompletePlaying:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)wIOonAdVideoGotReward:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;
-(void)wIOonAdDidPayRevenue:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)wIOonAdShowFail:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)wIOonAdOtherEvent:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload event:(WIOCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
