//
//  WIOCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define wIOkAdvDataSourceFacebook   2 //FB 广告数据源
#define wIOkAdvDataSourceAdmob      8 //Admob 广告数据源
#define wIOkAdvDataSourceMopub      39//Mopub 广告数据源
#define wIOkAdvDataSourceApplovin   20//applovin 广告数据源

#define wIOkAdvDataSourceGDT        62//广点通 广告数据源
#define wIOkAdvDataSourceBaidu      63//百度 广告数据源
#define wIOkAdvDataSourceBU         64//头条 广告数据源
#define wIOkAdvDataSourceABU         70//头条聚合 广告数据源
#define wIOkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define wIOkAdvDataSourcePangle     74//pangle 广告数据源

#define wIOkOnlineAdvTypeBanner                   1  //banner
#define wIOkOnlineAdvTypeInterstitial             2  //全屏
#define wIOkOnlineAdvTypeNative                   3 //native
#define wIOkOnlineAdvTypeVideo                    4 //视频
#define wIOkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define wIOkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define wIOkOnlineAdvTypeOpen                     8 //开屏
#define wIOkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define wIOkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define wIOkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define wIOkAdServerConfigError  -1 //服务器返回数据不正确
#define wIOkAdLoadConfigFailed  -2 //广告加载失败


#define wIOAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define wIOkCSAdInstallDays @"wIOkCSAdInstallDays"
#define wIOkCSAdModule_key @"wIOkCSAdModule_key_%@"
#define wIOkCSNewAdModule_key @"wIOkCSNewAdModule_key_%@"
#define wIOkCSAdInstallTime @"wIOkCSAdInstallTime"
#define wIOkCSAdInstallHours @"wIOkCSAdInstallHours"
#define wIOkCSAdLastGetServerTime @"wIOkCSAdLastRequestTime"
#define wIOkCSAdloadTime 30

#define wIOkCSLoadAdTimeOutNotification @"wIOKCSLoadAdTimeOutNotification"
#define wIOkCSLoadAdTimeOutNotificationKey @"wIOKCSLoadAdTimeOutKey"

