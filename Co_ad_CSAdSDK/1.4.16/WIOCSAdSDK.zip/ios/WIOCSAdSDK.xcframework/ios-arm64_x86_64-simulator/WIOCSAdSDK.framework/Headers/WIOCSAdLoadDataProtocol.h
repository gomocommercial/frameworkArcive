//
//  WIOCSAdLoadDataProtocol.h
//  WIOCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "WIOCSAdTypedef.h"

@class WIOCSAdDataModel;
@class WIOCSAdLoadBase;

@protocol WIOCSAdLoadProtocol;

@protocol WIOCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)wIOonAdInfoFinish:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)wIOonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)wIOonAdFail:(WIOCSAdLoadBase<WIOCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
