//
//  FNCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "FNCSAdLoadBase.h"
#import "FNCSAdDataModel.h"
#import "FNCSAdLoadProtocol.h"
#import "FNCSAdLoadDataProtocol.h"
#import "FNCSAdLoadShowProtocol.h"
#import "FNCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)fNsetupByBlock:(void (^ _Nonnull)(FNCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)fNloadAd:(NSString *)moduleId delegate:(id<FNCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)fNadShowStatistic:(FNCSAdDataModel *)dataModel adload:(nonnull FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)fNadClickStatistic:(FNCSAdDataModel *)dataModel adload:(nonnull FNCSAdLoadBase<FNCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)fNaddCustomFecher:(Class<FNCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
