//
//  MBCSAdNetworkTool.h
//  MBCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "MBCSAdDataModel.h"
#import "MBCSAdTypedef.h"
#import "MBCSNewStoreLiteRequestTool.h"
#import "NSString+MBCSGenerateHash.h"

@interface MBCSAdNetworkTool : NSObject

+ (MBCSAdNetworkTool *)shared;
@property(nonatomic, copy) MBCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)mBrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(MBCSAdRequestCompleteBlock)complete;

- (void)mBsetCDay:(void(^ _Nullable)(bool success))handle;
@end
