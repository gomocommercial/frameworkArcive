//
//  MLCCSAdNetworkTool.h
//  MLCCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "MLCCSAdDataModel.h"
#import "MLCCSAdTypedef.h"
#import "MLCCSNewStoreLiteRequestTool.h"
#import "NSString+MLCCSGenerateHash.h"

@interface MLCCSAdNetworkTool : NSObject

+ (MLCCSAdNetworkTool *)shared;
@property(nonatomic, copy) MLCCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)mLCrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(MLCCSAdRequestCompleteBlock)complete;

- (void)mLCsetCDay:(void(^ _Nullable)(bool success))handle;
@end
