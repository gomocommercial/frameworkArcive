//
//  MLCCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "MLCCSAdLoadBase.h"
#import "MLCCSAdDataModel.h"
#import "MLCCSAdLoadProtocol.h"
#import "MLCCSAdLoadDataProtocol.h"
#import "MLCCSAdLoadShowProtocol.h"
#import "MLCCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface MLCCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)mLCsetupByBlock:(void (^ _Nonnull)(MLCCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)mLCloadAd:(NSString *)moduleId delegate:(id<MLCCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)mLCadShowStatistic:(MLCCSAdDataModel *)dataModel adload:(nonnull MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)mLCadClickStatistic:(MLCCSAdDataModel *)dataModel adload:(nonnull MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)mLCaddCustomFecher:(Class<MLCCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
