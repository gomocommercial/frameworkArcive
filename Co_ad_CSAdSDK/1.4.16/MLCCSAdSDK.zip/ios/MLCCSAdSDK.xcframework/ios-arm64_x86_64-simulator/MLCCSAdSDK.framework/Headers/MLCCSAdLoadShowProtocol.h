//
//  MLCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "MLCCSAdTypedef.h"

@class MLCCSAdLoadBase;

@protocol MLCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol MLCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)mLConAdShowed:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)mLConAdClicked:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)mLConAdClosed:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)mLConAdVideoCompletePlaying:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)mLConAdVideoGotReward:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload;
-(void)mLConAdDidPayRevenue:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)mLConAdShowFail:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)mLConAdOtherEvent:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload event:(MLCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
