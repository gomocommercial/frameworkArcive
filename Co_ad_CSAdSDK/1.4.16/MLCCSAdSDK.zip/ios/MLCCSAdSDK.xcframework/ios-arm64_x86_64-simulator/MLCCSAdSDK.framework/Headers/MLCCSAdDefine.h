//
//  MLCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define mLCkAdvDataSourceFacebook   2 //FB 广告数据源
#define mLCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define mLCkAdvDataSourceMopub      39//Mopub 广告数据源
#define mLCkAdvDataSourceApplovin   20//applovin 广告数据源

#define mLCkAdvDataSourceGDT        62//广点通 广告数据源
#define mLCkAdvDataSourceBaidu      63//百度 广告数据源
#define mLCkAdvDataSourceBU         64//头条 广告数据源
#define mLCkAdvDataSourceABU         70//头条聚合 广告数据源
#define mLCkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define mLCkAdvDataSourcePangle     74//pangle 广告数据源

#define mLCkOnlineAdvTypeBanner                   1  //banner
#define mLCkOnlineAdvTypeInterstitial             2  //全屏
#define mLCkOnlineAdvTypeNative                   3 //native
#define mLCkOnlineAdvTypeVideo                    4 //视频
#define mLCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define mLCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define mLCkOnlineAdvTypeOpen                     8 //开屏
#define mLCkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define mLCkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define mLCkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define mLCkAdServerConfigError  -1 //服务器返回数据不正确
#define mLCkAdLoadConfigFailed  -2 //广告加载失败


#define mLCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define mLCkCSAdInstallDays @"mLCkCSAdInstallDays"
#define mLCkCSAdModule_key @"mLCkCSAdModule_key_%@"
#define mLCkCSNewAdModule_key @"mLCkCSNewAdModule_key_%@"
#define mLCkCSAdInstallTime @"mLCkCSAdInstallTime"
#define mLCkCSAdInstallHours @"mLCkCSAdInstallHours"
#define mLCkCSAdLastGetServerTime @"mLCkCSAdLastRequestTime"
#define mLCkCSAdloadTime 30

#define mLCkCSLoadAdTimeOutNotification @"mLCKCSLoadAdTimeOutNotification"
#define mLCkCSLoadAdTimeOutNotificationKey @"mLCKCSLoadAdTimeOutKey"

