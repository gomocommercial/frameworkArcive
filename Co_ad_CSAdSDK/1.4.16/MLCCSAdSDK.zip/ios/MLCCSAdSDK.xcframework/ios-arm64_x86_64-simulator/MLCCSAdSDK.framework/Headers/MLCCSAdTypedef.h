//
//  MLCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    MLCCSAdLoadSuccess = 1,
    MLCCSAdLoadFailure = -1,
    MLCCSAdLoadTimeout = -2
} MLCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    MLCCSAdPreloadSuccess = 1,
    //预加载失败
    MLCCSAdPreloadFailure = -1,
    //重复加载
    MLCCSAdPreloadRepeat = -2,
} MLCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    MLCCSAdWillAppear,//即将出现
    MLCCSAdDidAppear,//已经出现
    MLCCSAdWillDisappear,//即将消失
    MLCCSAdDidDisappear,//已经消失
    MLCCSAdMuted,//静音广告
    MLCCSAdWillLeaveApplication,//将要离开App

    MLCCSAdVideoStart,//开始播放 常用于video
    MLCCSAdVideoComplete,//播放完成 常用于video
    MLCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    MLCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    MLCCSAdNativeDidDownload,//下载完成 常用于fb Native
    MLCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    MLCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    MLCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    MLCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    MLCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    MLCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    MLCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    MLCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    MLCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    MLCCSAdBUOpenRenderSuccess, //渲染成功
    MLCCSAdBUOpenRenderFail, //渲染失败
    MLCCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    MLCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    MLCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    MLCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    MLCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    MLCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    MLCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    MLCCSAdPlayerStatusStarted,//开始播放
    MLCCSAdPlayerStatusPaused,//用户行为导致暂停
    MLCCSAdPlayerStatusStoped,//播放停止
    MLCCSAdPlayerStatusError,//播放出错
    MLCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    MLCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    MLCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    MLCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    MLCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    MLCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    MLCCSAdRecordImpression, //广告曝光已记录
    MLCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    MLCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    MLCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    MLCCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    MLCCSAdABUOpenWillPresentFullScreen,
    MLCCSAdABUOpenDidShowFailed,
    MLCCSAdABUOpenWillDissmissFullScreen,
    MLCCSAdABUOpenCountdownToZero,
    
    MLCCSAdABUBannerWillPresentFullScreen,
    MLCCSAdABUBannerWillDismissFullScreen,
    
    MLCCSAdABURewardDidLoad,
    MLCCSAdABURewardRenderFail,
    MLCCSAdABURewardDidShowFailed,

} MLCCSAdEvent;

typedef void (^MLCCSAdLoadCompleteBlock)(MLCCSAdLoadStatus adLoadStatus);

@class MLCCSAdSetupParamsMaker;
@class MLCCSAdSetupParams;

typedef MLCCSAdSetupParamsMaker *(^MLCCSAdStringInit)(NSString *);
typedef MLCCSAdSetupParamsMaker *(^MLCCSAdBoolInit)(BOOL);
typedef MLCCSAdSetupParamsMaker *(^MLCCSAdIntegerInit)(NSInteger);
typedef MLCCSAdSetupParamsMaker *(^MLCCSAdLongInit)(long);
typedef MLCCSAdSetupParamsMaker *(^MLCCSAdArrayInit)(NSArray *);
typedef MLCCSAdSetupParams *(^MLCCSAdMakeInit)(void);


@class MLCCSAdDataModel;
typedef void (^MLCCSAdRequestCompleteBlock)(NSMutableArray<MLCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^MLCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^MLCCSAdPreloadCompleteBlock)(MLCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
