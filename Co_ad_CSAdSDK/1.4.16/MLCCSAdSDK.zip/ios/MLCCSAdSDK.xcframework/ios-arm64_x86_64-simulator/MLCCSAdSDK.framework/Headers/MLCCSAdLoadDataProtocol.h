//
//  MLCCSAdLoadDataProtocol.h
//  MLCCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "MLCCSAdTypedef.h"

@class MLCCSAdDataModel;
@class MLCCSAdLoadBase;

@protocol MLCCSAdLoadProtocol;

@protocol MLCCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)mLConAdInfoFinish:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)mLConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)mLConAdFail:(MLCCSAdLoadBase<MLCCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
