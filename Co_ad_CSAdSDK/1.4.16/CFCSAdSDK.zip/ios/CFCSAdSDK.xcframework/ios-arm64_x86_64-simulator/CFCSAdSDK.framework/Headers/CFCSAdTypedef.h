//
//  CFCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CFCSAdLoadSuccess = 1,
    CFCSAdLoadFailure = -1,
    CFCSAdLoadTimeout = -2
} CFCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CFCSAdPreloadSuccess = 1,
    //预加载失败
    CFCSAdPreloadFailure = -1,
    //重复加载
    CFCSAdPreloadRepeat = -2,
} CFCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CFCSAdWillAppear,//即将出现
    CFCSAdDidAppear,//已经出现
    CFCSAdWillDisappear,//即将消失
    CFCSAdDidDisappear,//已经消失
    CFCSAdMuted,//静音广告
    CFCSAdWillLeaveApplication,//将要离开App

    CFCSAdVideoStart,//开始播放 常用于video
    CFCSAdVideoComplete,//播放完成 常用于video
    CFCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CFCSAdVideoServerFail,//连接服务器成功，常用于fb video

    CFCSAdNativeDidDownload,//下载完成 常用于fb Native
    CFCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CFCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CFCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CFCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CFCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CFCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    CFCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CFCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CFCSAdBUOpenDidAutoDimiss,//开屏自动消失
    CFCSAdBUOpenRenderSuccess, //渲染成功
    CFCSAdBUOpenRenderFail, //渲染失败
    CFCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    CFCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CFCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CFCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CFCSAdDidPresentFullScreen,//插屏弹出全屏广告
    CFCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CFCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CFCSAdPlayerStatusStarted,//开始播放
    CFCSAdPlayerStatusPaused,//用户行为导致暂停
    CFCSAdPlayerStatusStoped,//播放停止
    CFCSAdPlayerStatusError,//播放出错
    CFCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CFCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CFCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CFCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CFCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CFCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CFCSAdRecordImpression, //广告曝光已记录
    CFCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CFCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CFCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    CFCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    CFCSAdABUOpenWillPresentFullScreen,
    CFCSAdABUOpenDidShowFailed,
    CFCSAdABUOpenWillDissmissFullScreen,
    CFCSAdABUOpenCountdownToZero,
    
    CFCSAdABUBannerWillPresentFullScreen,
    CFCSAdABUBannerWillDismissFullScreen,
    
    CFCSAdABURewardDidLoad,
    CFCSAdABURewardRenderFail,
    CFCSAdABURewardDidShowFailed,

} CFCSAdEvent;

typedef void (^CFCSAdLoadCompleteBlock)(CFCSAdLoadStatus adLoadStatus);

@class CFCSAdSetupParamsMaker;
@class CFCSAdSetupParams;

typedef CFCSAdSetupParamsMaker *(^CFCSAdStringInit)(NSString *);
typedef CFCSAdSetupParamsMaker *(^CFCSAdBoolInit)(BOOL);
typedef CFCSAdSetupParamsMaker *(^CFCSAdIntegerInit)(NSInteger);
typedef CFCSAdSetupParamsMaker *(^CFCSAdLongInit)(long);
typedef CFCSAdSetupParamsMaker *(^CFCSAdArrayInit)(NSArray *);
typedef CFCSAdSetupParams *(^CFCSAdMakeInit)(void);


@class CFCSAdDataModel;
typedef void (^CFCSAdRequestCompleteBlock)(NSMutableArray<CFCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CFCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CFCSAdPreloadCompleteBlock)(CFCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
