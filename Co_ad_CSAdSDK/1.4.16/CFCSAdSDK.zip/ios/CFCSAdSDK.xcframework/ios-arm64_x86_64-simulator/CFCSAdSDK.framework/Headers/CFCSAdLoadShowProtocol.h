//
//  CFCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CFCSAdTypedef.h"

@class CFCSAdLoadBase;

@protocol CFCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CFCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cFonAdShowed:(CFCSAdLoadBase<CFCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cFonAdClicked:(CFCSAdLoadBase<CFCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cFonAdClosed:(CFCSAdLoadBase<CFCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cFonAdVideoCompletePlaying:(CFCSAdLoadBase<CFCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)cFonAdVideoGotReward:(CFCSAdLoadBase<CFCSAdLoadProtocol> *)adload;
-(void)cFonAdDidPayRevenue:(CFCSAdLoadBase<CFCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)cFonAdShowFail:(CFCSAdLoadBase<CFCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cFonAdOtherEvent:(CFCSAdLoadBase<CFCSAdLoadProtocol> *)adload event:(CFCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
