//
//  CFCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CFCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCSAdLoadNative : CFCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
