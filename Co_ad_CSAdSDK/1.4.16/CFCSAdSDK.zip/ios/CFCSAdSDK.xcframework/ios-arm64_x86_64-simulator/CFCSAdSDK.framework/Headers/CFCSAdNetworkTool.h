//
//  CFCSAdNetworkTool.h
//  CFCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CFCSAdDataModel.h"
#import "CFCSAdTypedef.h"
#import "CFCSNewStoreLiteRequestTool.h"
#import "NSString+CFCSGenerateHash.h"

@interface CFCSAdNetworkTool : NSObject

+ (CFCSAdNetworkTool *)shared;
@property(nonatomic, copy) CFCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)cFrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CFCSAdRequestCompleteBlock)complete;

- (void)cFsetCDay:(void(^ _Nullable)(bool success))handle;
@end
