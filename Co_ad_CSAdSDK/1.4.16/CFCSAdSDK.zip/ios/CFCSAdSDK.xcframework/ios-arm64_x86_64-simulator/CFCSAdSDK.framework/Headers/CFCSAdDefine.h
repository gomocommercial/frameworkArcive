//
//  CFCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define cFkAdvDataSourceFacebook   2 //FB 广告数据源
#define cFkAdvDataSourceAdmob      8 //Admob 广告数据源
#define cFkAdvDataSourceMopub      39//Mopub 广告数据源
#define cFkAdvDataSourceApplovin   20//applovin 广告数据源

#define cFkAdvDataSourceGDT        62//广点通 广告数据源
#define cFkAdvDataSourceBaidu      63//百度 广告数据源
#define cFkAdvDataSourceBU         64//头条 广告数据源
#define cFkAdvDataSourceABU         70//头条聚合 广告数据源
#define cFkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define cFkAdvDataSourcePangle     74//pangle 广告数据源

#define cFkOnlineAdvTypeBanner                   1  //banner
#define cFkOnlineAdvTypeInterstitial             2  //全屏
#define cFkOnlineAdvTypeNative                   3 //native
#define cFkOnlineAdvTypeVideo                    4 //视频
#define cFkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define cFkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define cFkOnlineAdvTypeOpen                     8 //开屏
#define cFkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define cFkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define cFkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define cFkAdServerConfigError  -1 //服务器返回数据不正确
#define cFkAdLoadConfigFailed  -2 //广告加载失败


#define cFAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define cFkCSAdInstallDays @"cFkCSAdInstallDays"
#define cFkCSAdModule_key @"cFkCSAdModule_key_%@"
#define cFkCSNewAdModule_key @"cFkCSNewAdModule_key_%@"
#define cFkCSAdInstallTime @"cFkCSAdInstallTime"
#define cFkCSAdInstallHours @"cFkCSAdInstallHours"
#define cFkCSAdLastGetServerTime @"cFkCSAdLastRequestTime"
#define cFkCSAdloadTime 30

#define cFkCSLoadAdTimeOutNotification @"cFKCSLoadAdTimeOutNotification"
#define cFkCSLoadAdTimeOutNotificationKey @"cFKCSLoadAdTimeOutKey"

