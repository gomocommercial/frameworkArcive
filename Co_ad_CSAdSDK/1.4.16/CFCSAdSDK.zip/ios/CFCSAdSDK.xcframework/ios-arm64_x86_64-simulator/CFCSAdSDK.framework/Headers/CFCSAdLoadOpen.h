//
//  CFCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "CFCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCSAdLoadOpen : CFCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
