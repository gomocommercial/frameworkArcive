//
//  DCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define dCkAdvDataSourceFacebook   2 //FB 广告数据源
#define dCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define dCkAdvDataSourceMopub      39//Mopub 广告数据源
#define dCkAdvDataSourceApplovin   20//applovin 广告数据源

#define dCkAdvDataSourceGDT        62//广点通 广告数据源
#define dCkAdvDataSourceBaidu      63//百度 广告数据源
#define dCkAdvDataSourceBU         64//头条 广告数据源
#define dCkAdvDataSourceABU         70//头条聚合 广告数据源
#define dCkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define dCkAdvDataSourcePangle     74//pangle 广告数据源

#define dCkOnlineAdvTypeBanner                   1  //banner
#define dCkOnlineAdvTypeInterstitial             2  //全屏
#define dCkOnlineAdvTypeNative                   3 //native
#define dCkOnlineAdvTypeVideo                    4 //视频
#define dCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define dCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define dCkOnlineAdvTypeOpen                     8 //开屏
#define dCkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define dCkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define dCkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define dCkAdServerConfigError  -1 //服务器返回数据不正确
#define dCkAdLoadConfigFailed  -2 //广告加载失败


#define dCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define dCkCSAdInstallDays @"dCkCSAdInstallDays"
#define dCkCSAdModule_key @"dCkCSAdModule_key_%@"
#define dCkCSNewAdModule_key @"dCkCSNewAdModule_key_%@"
#define dCkCSAdInstallTime @"dCkCSAdInstallTime"
#define dCkCSAdInstallHours @"dCkCSAdInstallHours"
#define dCkCSAdLastGetServerTime @"dCkCSAdLastRequestTime"
#define dCkCSAdloadTime 30

#define dCkCSLoadAdTimeOutNotification @"dCKCSLoadAdTimeOutNotification"
#define dCkCSLoadAdTimeOutNotificationKey @"dCKCSLoadAdTimeOutKey"

