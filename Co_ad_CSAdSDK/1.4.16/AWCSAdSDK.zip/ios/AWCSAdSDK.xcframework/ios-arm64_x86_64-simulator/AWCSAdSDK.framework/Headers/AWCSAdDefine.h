//
//  AWCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define aWkAdvDataSourceFacebook   2 //FB 广告数据源
#define aWkAdvDataSourceAdmob      8 //Admob 广告数据源
#define aWkAdvDataSourceMopub      39//Mopub 广告数据源
#define aWkAdvDataSourceApplovin   20//applovin 广告数据源

#define aWkAdvDataSourceGDT        62//广点通 广告数据源
#define aWkAdvDataSourceBaidu      63//百度 广告数据源
#define aWkAdvDataSourceBU         64//头条 广告数据源
#define aWkAdvDataSourceABU         70//头条聚合 广告数据源
#define aWkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define aWkAdvDataSourcePangle     74//pangle 广告数据源

#define aWkOnlineAdvTypeBanner                   1  //banner
#define aWkOnlineAdvTypeInterstitial             2  //全屏
#define aWkOnlineAdvTypeNative                   3 //native
#define aWkOnlineAdvTypeVideo                    4 //视频
#define aWkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define aWkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define aWkOnlineAdvTypeOpen                     8 //开屏
#define aWkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define aWkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define aWkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define aWkAdServerConfigError  -1 //服务器返回数据不正确
#define aWkAdLoadConfigFailed  -2 //广告加载失败


#define aWAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define aWkCSAdInstallDays @"aWkCSAdInstallDays"
#define aWkCSAdModule_key @"aWkCSAdModule_key_%@"
#define aWkCSNewAdModule_key @"aWkCSNewAdModule_key_%@"
#define aWkCSAdInstallTime @"aWkCSAdInstallTime"
#define aWkCSAdInstallHours @"aWkCSAdInstallHours"
#define aWkCSAdLastGetServerTime @"aWkCSAdLastRequestTime"
#define aWkCSAdloadTime 30

#define aWkCSLoadAdTimeOutNotification @"aWKCSLoadAdTimeOutNotification"
#define aWkCSLoadAdTimeOutNotificationKey @"aWKCSLoadAdTimeOutKey"

