//
//  AWCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "AWCSAdTypedef.h"

@class AWCSAdLoadBase;

@protocol AWCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol AWCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)aWonAdShowed:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)aWonAdClicked:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)aWonAdClosed:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)aWonAdVideoCompletePlaying:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)aWonAdVideoGotReward:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload;
-(void)aWonAdDidPayRevenue:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)aWonAdShowFail:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)aWonAdOtherEvent:(AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload event:(AWCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
