//
//  AWCSAdNetworkTool.h
//  AWCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "AWCSAdDataModel.h"
#import "AWCSAdTypedef.h"
#import "AWCSNewStoreLiteRequestTool.h"
#import "NSString+AWCSGenerateHash.h"

@interface AWCSAdNetworkTool : NSObject

+ (AWCSAdNetworkTool *)shared;
@property(nonatomic, copy) AWCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)aWrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(AWCSAdRequestCompleteBlock)complete;

- (void)aWsetCDay:(void(^ _Nullable)(bool success))handle;
@end
