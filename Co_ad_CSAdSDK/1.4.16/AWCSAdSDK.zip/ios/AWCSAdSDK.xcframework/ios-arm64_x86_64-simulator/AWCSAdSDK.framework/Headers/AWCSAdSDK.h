//
//  AWCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "AWCSAdLoadBase.h"
#import "AWCSAdDataModel.h"
#import "AWCSAdLoadProtocol.h"
#import "AWCSAdLoadDataProtocol.h"
#import "AWCSAdLoadShowProtocol.h"
#import "AWCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)aWsetupByBlock:(void (^ _Nonnull)(AWCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)aWloadAd:(NSString *)moduleId delegate:(id<AWCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)aWadShowStatistic:(AWCSAdDataModel *)dataModel adload:(nonnull AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)aWadClickStatistic:(AWCSAdDataModel *)dataModel adload:(nonnull AWCSAdLoadBase<AWCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)aWaddCustomFecher:(Class<AWCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
