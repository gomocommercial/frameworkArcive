//
//  AWCSAdLoadReward.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "AWCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadReward : AWCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
