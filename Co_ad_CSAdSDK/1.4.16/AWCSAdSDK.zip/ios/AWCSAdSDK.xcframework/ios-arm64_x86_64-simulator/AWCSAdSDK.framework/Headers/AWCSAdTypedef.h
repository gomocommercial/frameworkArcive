//
//  AWCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    AWCSAdLoadSuccess = 1,
    AWCSAdLoadFailure = -1,
    AWCSAdLoadTimeout = -2
} AWCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    AWCSAdPreloadSuccess = 1,
    //预加载失败
    AWCSAdPreloadFailure = -1,
    //重复加载
    AWCSAdPreloadRepeat = -2,
} AWCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    AWCSAdWillAppear,//即将出现
    AWCSAdDidAppear,//已经出现
    AWCSAdWillDisappear,//即将消失
    AWCSAdDidDisappear,//已经消失
    AWCSAdMuted,//静音广告
    AWCSAdWillLeaveApplication,//将要离开App

    AWCSAdVideoStart,//开始播放 常用于video
    AWCSAdVideoComplete,//播放完成 常用于video
    AWCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    AWCSAdVideoServerFail,//连接服务器成功，常用于fb video

    AWCSAdNativeDidDownload,//下载完成 常用于fb Native
    AWCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    AWCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    AWCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    AWCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    AWCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    AWCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    AWCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    AWCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    AWCSAdBUOpenDidAutoDimiss,//开屏自动消失
    AWCSAdBUOpenRenderSuccess, //渲染成功
    AWCSAdBUOpenRenderFail, //渲染失败
    AWCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    AWCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    AWCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    AWCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    AWCSAdDidPresentFullScreen,//插屏弹出全屏广告
    AWCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    AWCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    AWCSAdPlayerStatusStarted,//开始播放
    AWCSAdPlayerStatusPaused,//用户行为导致暂停
    AWCSAdPlayerStatusStoped,//播放停止
    AWCSAdPlayerStatusError,//播放出错
    AWCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    AWCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    AWCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    AWCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    AWCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    AWCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    AWCSAdRecordImpression, //广告曝光已记录
    AWCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    AWCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    AWCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    AWCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    AWCSAdABUOpenWillPresentFullScreen,
    AWCSAdABUOpenDidShowFailed,
    AWCSAdABUOpenWillDissmissFullScreen,
    AWCSAdABUOpenCountdownToZero,
    
    AWCSAdABUBannerWillPresentFullScreen,
    AWCSAdABUBannerWillDismissFullScreen,
    
    AWCSAdABURewardDidLoad,
    AWCSAdABURewardRenderFail,
    AWCSAdABURewardDidShowFailed,

} AWCSAdEvent;

typedef void (^AWCSAdLoadCompleteBlock)(AWCSAdLoadStatus adLoadStatus);

@class AWCSAdSetupParamsMaker;
@class AWCSAdSetupParams;

typedef AWCSAdSetupParamsMaker *(^AWCSAdStringInit)(NSString *);
typedef AWCSAdSetupParamsMaker *(^AWCSAdBoolInit)(BOOL);
typedef AWCSAdSetupParamsMaker *(^AWCSAdIntegerInit)(NSInteger);
typedef AWCSAdSetupParamsMaker *(^AWCSAdLongInit)(long);
typedef AWCSAdSetupParamsMaker *(^AWCSAdArrayInit)(NSArray *);
typedef AWCSAdSetupParams *(^AWCSAdMakeInit)(void);


@class AWCSAdDataModel;
typedef void (^AWCSAdRequestCompleteBlock)(NSMutableArray<AWCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^AWCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^AWCSAdPreloadCompleteBlock)(AWCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
