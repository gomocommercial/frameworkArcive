//
//  PPP_PCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PPP_PCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PCSAdLoadNative : PPP_PCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
