//
//  PPP_PCSAdNetworkTool.h
//  PPP_PCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PPP_PCSAdDataModel.h"
#import "PPP_PCSAdTypedef.h"
#import "PPP_PCSNewStoreLiteRequestTool.h"
#import "NSString+PPP_PCSGenerateHash.h"

@interface PPP_PCSAdNetworkTool : NSObject

+ (PPP_PCSAdNetworkTool *)shared;
@property(nonatomic, copy) PPP_PCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pPP_PrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PPP_PCSAdRequestCompleteBlock)complete;

- (void)pPP_PsetCDay:(void(^ _Nullable)(bool success))handle;
@end
