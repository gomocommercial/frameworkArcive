//
//  PPP_PCSAdStatistics.h
//  PPP_PCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "PPP_PCSAdDataModel.h"
#import "PPP_PCSAdTypedef.h"
#import "PPP_PCSAdLoadBase.h"
@interface PPP_PCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)pPP_PadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)pPP_PadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)pPP_PadRewardVideoCompleteStatistic:(PPP_PCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)pPP_PadShowStatistic:(PPP_PCSAdDataModel *)dataModel adload:(nonnull PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)pPP_PadClickStatistic:(PPP_PCSAdDataModel *)dataModel adload:(nonnull PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)pPP_PadUploadRevenueStatistic:(PPP_PCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
