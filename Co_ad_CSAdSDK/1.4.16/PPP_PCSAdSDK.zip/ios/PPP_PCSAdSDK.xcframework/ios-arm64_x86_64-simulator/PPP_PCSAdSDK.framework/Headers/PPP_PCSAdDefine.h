//
//  PPP_PCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define pPP_PkAdvDataSourceFacebook   2 //FB 广告数据源
#define pPP_PkAdvDataSourceAdmob      8 //Admob 广告数据源
#define pPP_PkAdvDataSourceMopub      39//Mopub 广告数据源
#define pPP_PkAdvDataSourceApplovin   20//applovin 广告数据源

#define pPP_PkAdvDataSourceGDT        62//广点通 广告数据源
#define pPP_PkAdvDataSourceBaidu      63//百度 广告数据源
#define pPP_PkAdvDataSourceBU         64//头条 广告数据源
#define pPP_PkAdvDataSourceABU         70//头条聚合 广告数据源
#define pPP_PkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define pPP_PkAdvDataSourcePangle     74//pangle 广告数据源

#define pPP_PkOnlineAdvTypeBanner                   1  //banner
#define pPP_PkOnlineAdvTypeInterstitial             2  //全屏
#define pPP_PkOnlineAdvTypeNative                   3 //native
#define pPP_PkOnlineAdvTypeVideo                    4 //视频
#define pPP_PkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define pPP_PkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define pPP_PkOnlineAdvTypeOpen                     8 //开屏
#define pPP_PkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define pPP_PkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define pPP_PkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define pPP_PkAdServerConfigError  -1 //服务器返回数据不正确
#define pPP_PkAdLoadConfigFailed  -2 //广告加载失败


#define pPP_PAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define pPP_PkCSAdInstallDays @"pPP_PkCSAdInstallDays"
#define pPP_PkCSAdModule_key @"pPP_PkCSAdModule_key_%@"
#define pPP_PkCSNewAdModule_key @"pPP_PkCSNewAdModule_key_%@"
#define pPP_PkCSAdInstallTime @"pPP_PkCSAdInstallTime"
#define pPP_PkCSAdInstallHours @"pPP_PkCSAdInstallHours"
#define pPP_PkCSAdLastGetServerTime @"pPP_PkCSAdLastRequestTime"
#define pPP_PkCSAdloadTime 30

#define pPP_PkCSLoadAdTimeOutNotification @"pPP_PKCSLoadAdTimeOutNotification"
#define pPP_PkCSLoadAdTimeOutNotificationKey @"pPP_PKCSLoadAdTimeOutKey"

