//
//  PPP_PCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PPP_PCSAdLoadSuccess = 1,
    PPP_PCSAdLoadFailure = -1,
    PPP_PCSAdLoadTimeout = -2
} PPP_PCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PPP_PCSAdPreloadSuccess = 1,
    //预加载失败
    PPP_PCSAdPreloadFailure = -1,
    //重复加载
    PPP_PCSAdPreloadRepeat = -2,
} PPP_PCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PPP_PCSAdWillAppear,//即将出现
    PPP_PCSAdDidAppear,//已经出现
    PPP_PCSAdWillDisappear,//即将消失
    PPP_PCSAdDidDisappear,//已经消失
    PPP_PCSAdMuted,//静音广告
    PPP_PCSAdWillLeaveApplication,//将要离开App

    PPP_PCSAdVideoStart,//开始播放 常用于video
    PPP_PCSAdVideoComplete,//播放完成 常用于video
    PPP_PCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PPP_PCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PPP_PCSAdNativeDidDownload,//下载完成 常用于fb Native
    PPP_PCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PPP_PCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PPP_PCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PPP_PCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PPP_PCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PPP_PCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PPP_PCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PPP_PCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PPP_PCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PPP_PCSAdBUOpenRenderSuccess, //渲染成功
    PPP_PCSAdBUOpenRenderFail, //渲染失败
    PPP_PCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PPP_PCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PPP_PCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PPP_PCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PPP_PCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PPP_PCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PPP_PCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PPP_PCSAdPlayerStatusStarted,//开始播放
    PPP_PCSAdPlayerStatusPaused,//用户行为导致暂停
    PPP_PCSAdPlayerStatusStoped,//播放停止
    PPP_PCSAdPlayerStatusError,//播放出错
    PPP_PCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PPP_PCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PPP_PCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PPP_PCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PPP_PCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PPP_PCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PPP_PCSAdRecordImpression, //广告曝光已记录
    PPP_PCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PPP_PCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PPP_PCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PPP_PCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PPP_PCSAdABUOpenWillPresentFullScreen,
    PPP_PCSAdABUOpenDidShowFailed,
    PPP_PCSAdABUOpenWillDissmissFullScreen,
    PPP_PCSAdABUOpenCountdownToZero,
    
    PPP_PCSAdABUBannerWillPresentFullScreen,
    PPP_PCSAdABUBannerWillDismissFullScreen,
    
    PPP_PCSAdABURewardDidLoad,
    PPP_PCSAdABURewardRenderFail,
    PPP_PCSAdABURewardDidShowFailed,

} PPP_PCSAdEvent;

typedef void (^PPP_PCSAdLoadCompleteBlock)(PPP_PCSAdLoadStatus adLoadStatus);

@class PPP_PCSAdSetupParamsMaker;
@class PPP_PCSAdSetupParams;

typedef PPP_PCSAdSetupParamsMaker *(^PPP_PCSAdStringInit)(NSString *);
typedef PPP_PCSAdSetupParamsMaker *(^PPP_PCSAdBoolInit)(BOOL);
typedef PPP_PCSAdSetupParamsMaker *(^PPP_PCSAdIntegerInit)(NSInteger);
typedef PPP_PCSAdSetupParamsMaker *(^PPP_PCSAdLongInit)(long);
typedef PPP_PCSAdSetupParamsMaker *(^PPP_PCSAdArrayInit)(NSArray *);
typedef PPP_PCSAdSetupParams *(^PPP_PCSAdMakeInit)(void);


@class PPP_PCSAdDataModel;
typedef void (^PPP_PCSAdRequestCompleteBlock)(NSMutableArray<PPP_PCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PPP_PCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PPP_PCSAdPreloadCompleteBlock)(PPP_PCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
