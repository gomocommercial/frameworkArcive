//
//  PPP_PCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PPP_PCSAdTypedef.h"

@class PPP_PCSAdLoadBase;

@protocol PPP_PCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PPP_PCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pPP_PonAdShowed:(PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pPP_PonAdClicked:(PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pPP_PonAdClosed:(PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pPP_PonAdVideoCompletePlaying:(PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pPP_PonAdVideoGotReward:(PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload;
-(void)pPP_PonAdDidPayRevenue:(PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)pPP_PonAdShowFail:(PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pPP_PonAdOtherEvent:(PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload event:(PPP_PCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
