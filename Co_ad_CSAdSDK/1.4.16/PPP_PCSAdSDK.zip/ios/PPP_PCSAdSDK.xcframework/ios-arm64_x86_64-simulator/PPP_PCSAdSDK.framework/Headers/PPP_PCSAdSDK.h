//
//  PPP_PCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PPP_PCSAdLoadBase.h"
#import "PPP_PCSAdDataModel.h"
#import "PPP_PCSAdLoadProtocol.h"
#import "PPP_PCSAdLoadDataProtocol.h"
#import "PPP_PCSAdLoadShowProtocol.h"
#import "PPP_PCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pPP_PsetupByBlock:(void (^ _Nonnull)(PPP_PCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pPP_PloadAd:(NSString *)moduleId delegate:(id<PPP_PCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pPP_PadShowStatistic:(PPP_PCSAdDataModel *)dataModel adload:(nonnull PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pPP_PadClickStatistic:(PPP_PCSAdDataModel *)dataModel adload:(nonnull PPP_PCSAdLoadBase<PPP_PCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pPP_PaddCustomFecher:(Class<PPP_PCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
