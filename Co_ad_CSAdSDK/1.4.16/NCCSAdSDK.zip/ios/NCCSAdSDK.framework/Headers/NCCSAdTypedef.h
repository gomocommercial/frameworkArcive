//
//  NCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    NCCSAdLoadSuccess = 1,
    NCCSAdLoadFailure = -1,
    NCCSAdLoadTimeout = -2
} NCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    NCCSAdPreloadSuccess = 1,
    //预加载失败
    NCCSAdPreloadFailure = -1,
    //重复加载
    NCCSAdPreloadRepeat = -2,
} NCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    NCCSAdWillAppear,//即将出现
    NCCSAdDidAppear,//已经出现
    NCCSAdWillDisappear,//即将消失
    NCCSAdDidDisappear,//已经消失
    NCCSAdMuted,//静音广告
    NCCSAdWillLeaveApplication,//将要离开App

    NCCSAdVideoStart,//开始播放 常用于video
    NCCSAdVideoComplete,//播放完成 常用于video
    NCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    NCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    NCCSAdNativeDidDownload,//下载完成 常用于fb Native
    NCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    NCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    NCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    NCCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    NCCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    NCCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    NCCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    NCCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    NCCSAdBUOpenDidAutoDimiss,//开屏自动消失
    NCCSAdBUOpenRenderSuccess, //渲染成功
    NCCSAdBUOpenRenderFail, //渲染失败
    NCCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    NCCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    NCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    NCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    NCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    NCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    NCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    NCCSAdPlayerStatusStarted,//开始播放
    NCCSAdPlayerStatusPaused,//用户行为导致暂停
    NCCSAdPlayerStatusStoped,//播放停止
    NCCSAdPlayerStatusError,//播放出错
    NCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    NCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    NCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    NCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    NCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    NCCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    NCCSAdRecordImpression, //广告曝光已记录
    NCCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    NCCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    NCCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    NCCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    NCCSAdABUOpenWillPresentFullScreen,
    NCCSAdABUOpenDidShowFailed,
    NCCSAdABUOpenWillDissmissFullScreen,
    NCCSAdABUOpenCountdownToZero,
    
    NCCSAdABUBannerWillPresentFullScreen,
    NCCSAdABUBannerWillDismissFullScreen,
    
    NCCSAdABURewardDidLoad,
    NCCSAdABURewardRenderFail,
    NCCSAdABURewardDidShowFailed,

} NCCSAdEvent;

typedef void (^NCCSAdLoadCompleteBlock)(NCCSAdLoadStatus adLoadStatus);

@class NCCSAdSetupParamsMaker;
@class NCCSAdSetupParams;

typedef NCCSAdSetupParamsMaker *(^NCCSAdStringInit)(NSString *);
typedef NCCSAdSetupParamsMaker *(^NCCSAdBoolInit)(BOOL);
typedef NCCSAdSetupParamsMaker *(^NCCSAdIntegerInit)(NSInteger);
typedef NCCSAdSetupParamsMaker *(^NCCSAdLongInit)(long);
typedef NCCSAdSetupParamsMaker *(^NCCSAdArrayInit)(NSArray *);
typedef NCCSAdSetupParams *(^NCCSAdMakeInit)(void);


@class NCCSAdDataModel;
typedef void (^NCCSAdRequestCompleteBlock)(NSMutableArray<NCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^NCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^NCCSAdPreloadCompleteBlock)(NCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
