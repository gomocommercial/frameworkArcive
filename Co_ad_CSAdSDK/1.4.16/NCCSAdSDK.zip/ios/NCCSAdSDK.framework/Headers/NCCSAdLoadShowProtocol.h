//
//  NCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "NCCSAdTypedef.h"

@class NCCSAdLoadBase;

@protocol NCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol NCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)nConAdShowed:(NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)nConAdClicked:(NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)nConAdClosed:(NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)nConAdVideoCompletePlaying:(NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)nConAdVideoGotReward:(NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload;
-(void)nConAdDidPayRevenue:(NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)nConAdShowFail:(NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)nConAdOtherEvent:(NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload event:(NCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
