//
//  NCCSAdNetworkTool.h
//  NCCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "NCCSAdDataModel.h"
#import "NCCSAdTypedef.h"
#import "NCCSNewStoreLiteRequestTool.h"
#import "NSString+NCCSGenerateHash.h"

@interface NCCSAdNetworkTool : NSObject

+ (NCCSAdNetworkTool *)shared;
@property(nonatomic, copy) NCCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)nCrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(NCCSAdRequestCompleteBlock)complete;

- (void)nCsetCDay:(void(^ _Nullable)(bool success))handle;
@end
