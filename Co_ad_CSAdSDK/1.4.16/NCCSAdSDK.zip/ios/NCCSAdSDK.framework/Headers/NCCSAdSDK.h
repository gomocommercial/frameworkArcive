//
//  NCCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "NCCSAdLoadBase.h"
#import "NCCSAdDataModel.h"
#import "NCCSAdLoadProtocol.h"
#import "NCCSAdLoadDataProtocol.h"
#import "NCCSAdLoadShowProtocol.h"
#import "NCCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface NCCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)nCsetupByBlock:(void (^ _Nonnull)(NCCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)nCloadAd:(NSString *)moduleId delegate:(id<NCCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)nCadShowStatistic:(NCCSAdDataModel *)dataModel adload:(nonnull NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)nCadClickStatistic:(NCCSAdDataModel *)dataModel adload:(nonnull NCCSAdLoadBase<NCCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)nCaddCustomFecher:(Class<NCCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
