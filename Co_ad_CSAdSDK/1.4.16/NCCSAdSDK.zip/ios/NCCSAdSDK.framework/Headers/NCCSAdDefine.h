//
//  NCCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define nCkAdvDataSourceFacebook   2 //FB 广告数据源
#define nCkAdvDataSourceAdmob      8 //Admob 广告数据源
#define nCkAdvDataSourceMopub      39//Mopub 广告数据源
#define nCkAdvDataSourceApplovin   20//applovin 广告数据源

#define nCkAdvDataSourceGDT        62//广点通 广告数据源
#define nCkAdvDataSourceBaidu      63//百度 广告数据源
#define nCkAdvDataSourceBU         64//头条 广告数据源
#define nCkAdvDataSourceABU         70//头条聚合 广告数据源
#define nCkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define nCkAdvDataSourcePangle     74//pangle 广告数据源

#define nCkOnlineAdvTypeBanner                   1  //banner
#define nCkOnlineAdvTypeInterstitial             2  //全屏
#define nCkOnlineAdvTypeNative                   3 //native
#define nCkOnlineAdvTypeVideo                    4 //视频
#define nCkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define nCkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define nCkOnlineAdvTypeOpen                     8 //开屏
#define nCkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define nCkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define nCkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define nCkAdServerConfigError  -1 //服务器返回数据不正确
#define nCkAdLoadConfigFailed  -2 //广告加载失败


#define nCAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define nCkCSAdInstallDays @"nCkCSAdInstallDays"
#define nCkCSAdModule_key @"nCkCSAdModule_key_%@"
#define nCkCSNewAdModule_key @"nCkCSNewAdModule_key_%@"
#define nCkCSAdInstallTime @"nCkCSAdInstallTime"
#define nCkCSAdInstallHours @"nCkCSAdInstallHours"
#define nCkCSAdLastGetServerTime @"nCkCSAdLastRequestTime"
#define nCkCSAdloadTime 30

#define nCkCSLoadAdTimeOutNotification @"nCKCSLoadAdTimeOutNotification"
#define nCkCSLoadAdTimeOutNotificationKey @"nCKCSLoadAdTimeOutKey"

