//
//  CSCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "CSCSAdLoadBase.h"
#import "CSCSAdDataModel.h"
#import "CSCSAdLoadProtocol.h"
#import "CSCSAdLoadDataProtocol.h"
#import "CSCSAdLoadShowProtocol.h"
#import "CSCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)cSsetupByBlock:(void (^ _Nonnull)(CSCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)cSloadAd:(NSString *)moduleId delegate:(id<CSCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)cSadShowStatistic:(CSCSAdDataModel *)dataModel adload:(nonnull CSCSAdLoadBase<CSCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)cSadClickStatistic:(CSCSAdDataModel *)dataModel adload:(nonnull CSCSAdLoadBase<CSCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)cSaddCustomFecher:(Class<CSCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
