//
//  CSCSAdNetworkTool.h
//  CSCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CSCSAdDataModel.h"
#import "CSCSAdTypedef.h"
#import "CSCSNewStoreLiteRequestTool.h"
#import "NSString+CSCSGenerateHash.h"

@interface CSCSAdNetworkTool : NSObject

+ (CSCSAdNetworkTool *)shared;
@property(nonatomic, copy) CSCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)cSrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CSCSAdRequestCompleteBlock)complete;

- (void)cSsetCDay:(void(^ _Nullable)(bool success))handle;
@end
