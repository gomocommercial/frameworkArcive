//
//  CSCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define cSkAdvDataSourceFacebook   2 //FB 广告数据源
#define cSkAdvDataSourceAdmob      8 //Admob 广告数据源
#define cSkAdvDataSourceMopub      39//Mopub 广告数据源
#define cSkAdvDataSourceApplovin   20//applovin 广告数据源

#define cSkAdvDataSourceGDT        62//广点通 广告数据源
#define cSkAdvDataSourceBaidu      63//百度 广告数据源
#define cSkAdvDataSourceBU         64//头条 广告数据源
#define cSkAdvDataSourceABU         70//头条聚合 广告数据源
#define cSkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define cSkAdvDataSourcePangle     74//pangle 广告数据源

#define cSkOnlineAdvTypeBanner                   1  //banner
#define cSkOnlineAdvTypeInterstitial             2  //全屏
#define cSkOnlineAdvTypeNative                   3 //native
#define cSkOnlineAdvTypeVideo                    4 //视频
#define cSkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define cSkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define cSkOnlineAdvTypeOpen                     8 //开屏
#define cSkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define cSkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define cSkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define cSkAdServerConfigError  -1 //服务器返回数据不正确
#define cSkAdLoadConfigFailed  -2 //广告加载失败


#define cSAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define cSkCSAdInstallDays @"cSkCSAdInstallDays"
#define cSkCSAdModule_key @"cSkCSAdModule_key_%@"
#define cSkCSNewAdModule_key @"cSkCSNewAdModule_key_%@"
#define cSkCSAdInstallTime @"cSkCSAdInstallTime"
#define cSkCSAdInstallHours @"cSkCSAdInstallHours"
#define cSkCSAdLastGetServerTime @"cSkCSAdLastRequestTime"
#define cSkCSAdloadTime 30

#define cSkCSLoadAdTimeOutNotification @"cSKCSLoadAdTimeOutNotification"
#define cSkCSLoadAdTimeOutNotificationKey @"cSKCSLoadAdTimeOutKey"

