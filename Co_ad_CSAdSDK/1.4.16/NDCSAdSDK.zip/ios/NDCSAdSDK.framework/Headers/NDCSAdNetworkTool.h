//
//  NDCSAdNetworkTool.h
//  NDCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "NDCSAdDataModel.h"
#import "NDCSAdTypedef.h"
#import "NDCSNewStoreLiteRequestTool.h"
#import "NSString+NDCSGenerateHash.h"

@interface NDCSAdNetworkTool : NSObject

+ (NDCSAdNetworkTool *)shared;
@property(nonatomic, copy) NDCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)nDrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(NDCSAdRequestCompleteBlock)complete;

- (void)nDsetCDay:(void(^ _Nullable)(bool success))handle;
@end
