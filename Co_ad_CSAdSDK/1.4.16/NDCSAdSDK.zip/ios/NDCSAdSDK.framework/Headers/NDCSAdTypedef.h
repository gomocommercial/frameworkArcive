//
//  NDCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    NDCSAdLoadSuccess = 1,
    NDCSAdLoadFailure = -1,
    NDCSAdLoadTimeout = -2
} NDCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    NDCSAdPreloadSuccess = 1,
    //预加载失败
    NDCSAdPreloadFailure = -1,
    //重复加载
    NDCSAdPreloadRepeat = -2,
} NDCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    NDCSAdWillAppear,//即将出现
    NDCSAdDidAppear,//已经出现
    NDCSAdWillDisappear,//即将消失
    NDCSAdDidDisappear,//已经消失
    NDCSAdMuted,//静音广告
    NDCSAdWillLeaveApplication,//将要离开App

    NDCSAdVideoStart,//开始播放 常用于video
    NDCSAdVideoComplete,//播放完成 常用于video
    NDCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    NDCSAdVideoServerFail,//连接服务器成功，常用于fb video

    NDCSAdNativeDidDownload,//下载完成 常用于fb Native
    NDCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    NDCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    NDCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    NDCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    NDCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    NDCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    NDCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    NDCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    NDCSAdBUOpenDidAutoDimiss,//开屏自动消失
    NDCSAdBUOpenRenderSuccess, //渲染成功
    NDCSAdBUOpenRenderFail, //渲染失败
    NDCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    NDCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    NDCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    NDCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    NDCSAdDidPresentFullScreen,//插屏弹出全屏广告
    NDCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    NDCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    NDCSAdPlayerStatusStarted,//开始播放
    NDCSAdPlayerStatusPaused,//用户行为导致暂停
    NDCSAdPlayerStatusStoped,//播放停止
    NDCSAdPlayerStatusError,//播放出错
    NDCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    NDCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    NDCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    NDCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    NDCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    NDCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    NDCSAdRecordImpression, //广告曝光已记录
    NDCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    NDCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    NDCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    NDCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    NDCSAdABUOpenWillPresentFullScreen,
    NDCSAdABUOpenDidShowFailed,
    NDCSAdABUOpenWillDissmissFullScreen,
    NDCSAdABUOpenCountdownToZero,
    
    NDCSAdABUBannerWillPresentFullScreen,
    NDCSAdABUBannerWillDismissFullScreen,
    
    NDCSAdABURewardDidLoad,
    NDCSAdABURewardRenderFail,
    NDCSAdABURewardDidShowFailed,

} NDCSAdEvent;

typedef void (^NDCSAdLoadCompleteBlock)(NDCSAdLoadStatus adLoadStatus);

@class NDCSAdSetupParamsMaker;
@class NDCSAdSetupParams;

typedef NDCSAdSetupParamsMaker *(^NDCSAdStringInit)(NSString *);
typedef NDCSAdSetupParamsMaker *(^NDCSAdBoolInit)(BOOL);
typedef NDCSAdSetupParamsMaker *(^NDCSAdIntegerInit)(NSInteger);
typedef NDCSAdSetupParamsMaker *(^NDCSAdLongInit)(long);
typedef NDCSAdSetupParamsMaker *(^NDCSAdArrayInit)(NSArray *);
typedef NDCSAdSetupParams *(^NDCSAdMakeInit)(void);


@class NDCSAdDataModel;
typedef void (^NDCSAdRequestCompleteBlock)(NSMutableArray<NDCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^NDCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^NDCSAdPreloadCompleteBlock)(NDCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
