//
//  CSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define kAdvDataSourceFacebook   2 //FB 广告数据源
#define kAdvDataSourceAdmob      8 //Admob 广告数据源
#define kAdvDataSourceMopub      39//Mopub 广告数据源
#define kAdvDataSourceApplovin   20//applovin 广告数据源

#define kAdvDataSourceGDT        62//广点通 广告数据源
#define kAdvDataSourceBaidu      63//百度 广告数据源
#define kAdvDataSourceBU         64//头条 广告数据源
#define kAdvDataSourceABU         70//头条聚合 广告数据源
#define kAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define kAdvDataSourcePangle     74//pangle 广告数据源

#define kOnlineAdvTypeBanner                   1  //banner
#define kOnlineAdvTypeInterstitial             2  //全屏
#define kOnlineAdvTypeNative                   3 //native
#define kOnlineAdvTypeVideo                    4 //视频
#define kOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define kOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define kOnlineAdvTypeOpen                     8 //开屏
#define kOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define kOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define kOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define kAdServerConfigError  -1 //服务器返回数据不正确
#define kAdLoadConfigFailed  -2 //广告加载失败


#define AdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define kCSAdInstallDays @"kCSAdInstallDays"
#define kCSAdModule_key @"kCSAdModule_key_%@"
#define kCSNewAdModule_key @"kCSNewAdModule_key_%@"
#define kCSAdInstallTime @"kCSAdInstallTime"
#define kCSAdInstallHours @"kCSAdInstallHours"
#define kCSAdLastGetServerTime @"kCSAdLastRequestTime"
#define kCSAdloadTime 30

#define kCSLoadAdTimeOutNotification @"KCSLoadAdTimeOutNotification"
#define kCSLoadAdTimeOutNotificationKey @"KCSLoadAdTimeOutKey"

