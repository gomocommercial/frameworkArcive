//
//  CSAdNetworkTool.h
//  CSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CSAdDataModel.h"
#import "CSAdTypedef.h"
#import "CSNewStoreLiteRequestTool.h"
#import "NSString+CSGenerateHash.h"

@interface CSAdNetworkTool : NSObject

+ (CSAdNetworkTool *)shared;
@property(nonatomic, copy) CSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)requestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CSAdRequestCompleteBlock)complete;

- (void)setCDay:(void(^ _Nullable)(bool success))handle;
@end
