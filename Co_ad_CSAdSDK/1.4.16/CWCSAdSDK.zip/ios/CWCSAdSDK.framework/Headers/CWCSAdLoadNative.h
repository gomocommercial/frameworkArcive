//
//  CWCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CWCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CWCSAdLoadNative : CWCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
