//
//  CWCSAdNetworkTool.h
//  CWCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CWCSAdDataModel.h"
#import "CWCSAdTypedef.h"
#import "CWCSNewStoreLiteRequestTool.h"
#import "NSString+CWCSGenerateHash.h"

@interface CWCSAdNetworkTool : NSObject

+ (CWCSAdNetworkTool *)shared;
@property(nonatomic, copy) CWCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)cWrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CWCSAdRequestCompleteBlock)complete;

- (void)cWsetCDay:(void(^ _Nullable)(bool success))handle;
@end
