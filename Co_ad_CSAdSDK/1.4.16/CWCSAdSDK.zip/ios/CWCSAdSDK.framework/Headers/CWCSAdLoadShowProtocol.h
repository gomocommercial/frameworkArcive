//
//  CWCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CWCSAdTypedef.h"

@class CWCSAdLoadBase;

@protocol CWCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CWCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cWonAdShowed:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cWonAdClicked:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cWonAdClosed:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cWonAdVideoCompletePlaying:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)cWonAdVideoGotReward:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload;
-(void)cWonAdDidPayRevenue:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)cWonAdShowFail:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cWonAdOtherEvent:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload event:(CWCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
