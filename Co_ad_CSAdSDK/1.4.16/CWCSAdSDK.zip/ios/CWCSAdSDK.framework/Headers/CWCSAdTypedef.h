//
//  CWCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    CWCSAdLoadSuccess = 1,
    CWCSAdLoadFailure = -1,
    CWCSAdLoadTimeout = -2
} CWCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    CWCSAdPreloadSuccess = 1,
    //预加载失败
    CWCSAdPreloadFailure = -1,
    //重复加载
    CWCSAdPreloadRepeat = -2,
} CWCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    CWCSAdWillAppear,//即将出现
    CWCSAdDidAppear,//已经出现
    CWCSAdWillDisappear,//即将消失
    CWCSAdDidDisappear,//已经消失
    CWCSAdMuted,//静音广告
    CWCSAdWillLeaveApplication,//将要离开App

    CWCSAdVideoStart,//开始播放 常用于video
    CWCSAdVideoComplete,//播放完成 常用于video
    CWCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    CWCSAdVideoServerFail,//连接服务器成功，常用于fb video

    CWCSAdNativeDidDownload,//下载完成 常用于fb Native
    CWCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    CWCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    CWCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    CWCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    CWCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    CWCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    CWCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    CWCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    CWCSAdBUOpenDidAutoDimiss,//开屏自动消失
    CWCSAdBUOpenRenderSuccess, //渲染成功
    CWCSAdBUOpenRenderFail, //渲染失败
    CWCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    CWCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    CWCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    CWCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    CWCSAdDidPresentFullScreen,//插屏弹出全屏广告
    CWCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    CWCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    CWCSAdPlayerStatusStarted,//开始播放
    CWCSAdPlayerStatusPaused,//用户行为导致暂停
    CWCSAdPlayerStatusStoped,//播放停止
    CWCSAdPlayerStatusError,//播放出错
    CWCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    CWCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    CWCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    CWCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    CWCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    CWCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    CWCSAdRecordImpression, //广告曝光已记录
    CWCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    CWCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    CWCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    CWCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    CWCSAdABUOpenWillPresentFullScreen,
    CWCSAdABUOpenDidShowFailed,
    CWCSAdABUOpenWillDissmissFullScreen,
    CWCSAdABUOpenCountdownToZero,
    
    CWCSAdABUBannerWillPresentFullScreen,
    CWCSAdABUBannerWillDismissFullScreen,
    
    CWCSAdABURewardDidLoad,
    CWCSAdABURewardRenderFail,
    CWCSAdABURewardDidShowFailed,

} CWCSAdEvent;

typedef void (^CWCSAdLoadCompleteBlock)(CWCSAdLoadStatus adLoadStatus);

@class CWCSAdSetupParamsMaker;
@class CWCSAdSetupParams;

typedef CWCSAdSetupParamsMaker *(^CWCSAdStringInit)(NSString *);
typedef CWCSAdSetupParamsMaker *(^CWCSAdBoolInit)(BOOL);
typedef CWCSAdSetupParamsMaker *(^CWCSAdIntegerInit)(NSInteger);
typedef CWCSAdSetupParamsMaker *(^CWCSAdLongInit)(long);
typedef CWCSAdSetupParamsMaker *(^CWCSAdArrayInit)(NSArray *);
typedef CWCSAdSetupParams *(^CWCSAdMakeInit)(void);


@class CWCSAdDataModel;
typedef void (^CWCSAdRequestCompleteBlock)(NSMutableArray<CWCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^CWCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^CWCSAdPreloadCompleteBlock)(CWCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
