//
//  CWCSAdLoadDataProtocol.h
//  CWCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "CWCSAdTypedef.h"

@class CWCSAdDataModel;
@class CWCSAdLoadBase;

@protocol CWCSAdLoadProtocol;

@protocol CWCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)cWonAdInfoFinish:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)cWonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)cWonAdFail:(CWCSAdLoadBase<CWCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
