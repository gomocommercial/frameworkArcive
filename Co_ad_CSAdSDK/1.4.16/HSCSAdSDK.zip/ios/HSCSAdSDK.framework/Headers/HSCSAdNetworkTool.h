//
//  HSCSAdNetworkTool.h
//  HSCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "HSCSAdDataModel.h"
#import "HSCSAdTypedef.h"
#import "HSCSNewStoreLiteRequestTool.h"
#import "NSString+HSCSGenerateHash.h"

@interface HSCSAdNetworkTool : NSObject

+ (HSCSAdNetworkTool *)shared;
@property(nonatomic, copy) HSCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)hSrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(HSCSAdRequestCompleteBlock)complete;

- (void)hSsetCDay:(void(^ _Nullable)(bool success))handle;
@end
