//
//  HSCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    HSCSAdLoadSuccess = 1,
    HSCSAdLoadFailure = -1,
    HSCSAdLoadTimeout = -2
} HSCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    HSCSAdPreloadSuccess = 1,
    //预加载失败
    HSCSAdPreloadFailure = -1,
    //重复加载
    HSCSAdPreloadRepeat = -2,
} HSCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    HSCSAdWillAppear,//即将出现
    HSCSAdDidAppear,//已经出现
    HSCSAdWillDisappear,//即将消失
    HSCSAdDidDisappear,//已经消失
    HSCSAdMuted,//静音广告
    HSCSAdWillLeaveApplication,//将要离开App

    HSCSAdVideoStart,//开始播放 常用于video
    HSCSAdVideoComplete,//播放完成 常用于video
    HSCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    HSCSAdVideoServerFail,//连接服务器成功，常用于fb video

    HSCSAdNativeDidDownload,//下载完成 常用于fb Native
    HSCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    HSCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    HSCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    HSCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    HSCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    HSCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    HSCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    HSCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    HSCSAdBUOpenDidAutoDimiss,//开屏自动消失
    HSCSAdBUOpenRenderSuccess, //渲染成功
    HSCSAdBUOpenRenderFail, //渲染失败
    HSCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    HSCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    HSCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    HSCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    HSCSAdDidPresentFullScreen,//插屏弹出全屏广告
    HSCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    HSCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    HSCSAdPlayerStatusStarted,//开始播放
    HSCSAdPlayerStatusPaused,//用户行为导致暂停
    HSCSAdPlayerStatusStoped,//播放停止
    HSCSAdPlayerStatusError,//播放出错
    HSCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    HSCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    HSCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    HSCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    HSCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    HSCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    HSCSAdRecordImpression, //广告曝光已记录
    HSCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    HSCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    HSCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    HSCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    HSCSAdABUOpenWillPresentFullScreen,
    HSCSAdABUOpenDidShowFailed,
    HSCSAdABUOpenWillDissmissFullScreen,
    HSCSAdABUOpenCountdownToZero,
    
    HSCSAdABUBannerWillPresentFullScreen,
    HSCSAdABUBannerWillDismissFullScreen,
    
    HSCSAdABURewardDidLoad,
    HSCSAdABURewardRenderFail,
    HSCSAdABURewardDidShowFailed,

} HSCSAdEvent;

typedef void (^HSCSAdLoadCompleteBlock)(HSCSAdLoadStatus adLoadStatus);

@class HSCSAdSetupParamsMaker;
@class HSCSAdSetupParams;

typedef HSCSAdSetupParamsMaker *(^HSCSAdStringInit)(NSString *);
typedef HSCSAdSetupParamsMaker *(^HSCSAdBoolInit)(BOOL);
typedef HSCSAdSetupParamsMaker *(^HSCSAdIntegerInit)(NSInteger);
typedef HSCSAdSetupParamsMaker *(^HSCSAdLongInit)(long);
typedef HSCSAdSetupParamsMaker *(^HSCSAdArrayInit)(NSArray *);
typedef HSCSAdSetupParams *(^HSCSAdMakeInit)(void);


@class HSCSAdDataModel;
typedef void (^HSCSAdRequestCompleteBlock)(NSMutableArray<HSCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^HSCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^HSCSAdPreloadCompleteBlock)(HSCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
