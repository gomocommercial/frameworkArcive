//
//  HSCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "HSCSAdLoadBase.h"
#import "HSCSAdDataModel.h"
#import "HSCSAdLoadProtocol.h"
#import "HSCSAdLoadDataProtocol.h"
#import "HSCSAdLoadShowProtocol.h"
#import "HSCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface HSCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)hSsetupByBlock:(void (^ _Nonnull)(HSCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)hSloadAd:(NSString *)moduleId delegate:(id<HSCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)hSadShowStatistic:(HSCSAdDataModel *)dataModel adload:(nonnull HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)hSadClickStatistic:(HSCSAdDataModel *)dataModel adload:(nonnull HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)hSaddCustomFecher:(Class<HSCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
