//
//  HSCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "HSCSAdTypedef.h"

@class HSCSAdLoadBase;

@protocol HSCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol HSCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)hSonAdShowed:(HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)hSonAdClicked:(HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)hSonAdClosed:(HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)hSonAdVideoCompletePlaying:(HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)hSonAdVideoGotReward:(HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload;
-(void)hSonAdDidPayRevenue:(HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)hSonAdShowFail:(HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)hSonAdOtherEvent:(HSCSAdLoadBase<HSCSAdLoadProtocol> *)adload event:(HSCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
