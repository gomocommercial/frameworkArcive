//
//  CUC_PCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CUC_PCSAdTypedef.h"

@class CUC_PCSAdLoadBase;

@protocol CUC_PCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CUC_PCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cUC_PonAdShowed:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cUC_PonAdClicked:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cUC_PonAdClosed:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cUC_PonAdVideoCompletePlaying:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)cUC_PonAdVideoGotReward:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;
-(void)cUC_PonAdDidPayRevenue:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)cUC_PonAdShowFail:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cUC_PonAdOtherEvent:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload event:(CUC_PCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
