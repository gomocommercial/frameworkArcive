//
//  CUC_PCSAdNetworkTool.h
//  CUC_PCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "CUC_PCSAdDataModel.h"
#import "CUC_PCSAdTypedef.h"
#import "CUC_PCSNewStoreLiteRequestTool.h"
#import "NSString+CUC_PCSGenerateHash.h"

@interface CUC_PCSAdNetworkTool : NSObject

+ (CUC_PCSAdNetworkTool *)shared;
@property(nonatomic, copy) CUC_PCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)cUC_PrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(CUC_PCSAdRequestCompleteBlock)complete;

- (void)cUC_PsetCDay:(void(^ _Nullable)(bool success))handle;
@end
