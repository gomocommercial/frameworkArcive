//
//  CUC_PCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "CUC_PCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadInterstitial : CUC_PCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
