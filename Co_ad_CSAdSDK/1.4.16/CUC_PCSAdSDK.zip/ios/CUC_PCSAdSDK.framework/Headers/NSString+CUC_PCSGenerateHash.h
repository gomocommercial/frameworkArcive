//
//  NSString+CUC_PCSGenerateHash.h
//  AFNetworking
//
//  Created by zhangxin on 2022/4/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (CUC_PCSGenerateHash)
- (NSString *)hmacSHA256StrAndBase64WithKey:(NSString *)key;
- (NSString *)UrlSafeStr;
- (NSString *)reverseSafeUrlString;
@end

NS_ASSUME_NONNULL_END
