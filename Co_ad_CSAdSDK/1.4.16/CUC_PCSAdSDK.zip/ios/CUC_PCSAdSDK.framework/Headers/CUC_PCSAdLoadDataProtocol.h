//
//  CUC_PCSAdLoadDataProtocol.h
//  CUC_PCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "CUC_PCSAdTypedef.h"

@class CUC_PCSAdDataModel;
@class CUC_PCSAdLoadBase;

@protocol CUC_PCSAdLoadProtocol;

@protocol CUC_PCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)cUC_PonAdInfoFinish:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)cUC_PonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)cUC_PonAdFail:(CUC_PCSAdLoadBase<CUC_PCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
