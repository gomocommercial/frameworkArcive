//
//  MTCSAdLoadDataProtocol.h
//  MTCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "MTCSAdTypedef.h"

@class MTCSAdDataModel;
@class MTCSAdLoadBase;

@protocol MTCSAdLoadProtocol;

@protocol MTCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)mTonAdInfoFinish:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)mTonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)mTonAdFail:(MTCSAdLoadBase<MTCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
