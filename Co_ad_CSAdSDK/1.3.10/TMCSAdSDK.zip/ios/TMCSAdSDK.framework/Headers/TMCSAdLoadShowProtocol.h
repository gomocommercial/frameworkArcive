//
//  TMCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "TMCSAdTypedef.h"

@class TMCSAdLoadBase;

@protocol TMCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol TMCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)tMonAdShowed:(TMCSAdLoadBase<TMCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)tMonAdClicked:(TMCSAdLoadBase<TMCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)tMonAdClosed:(TMCSAdLoadBase<TMCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)tMonAdVideoCompletePlaying:(TMCSAdLoadBase<TMCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)tMonAdShowFail:(TMCSAdLoadBase<TMCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)tMonAdOtherEvent:(TMCSAdLoadBase<TMCSAdLoadProtocol> *)adload event:(TMCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
