//
//  CPCSAdStatistics.h
//  CPCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "CPCSAdDataModel.h"
#import "CPCSAdTypedef.h"
#import "CPCSAdLoadBase.h"
@interface CPCSAdStatistics : NSObject
+ (instancetype)sharedInstance;

/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)cPadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)cPadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)cPadRewardVideoCompleteStatistic:(CPCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)cPadShowStatistic:(CPCSAdDataModel *)dataModel adload:(nonnull CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)cPadClickStatistic:(CPCSAdDataModel *)dataModel adload:(nonnull CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload;

@end
