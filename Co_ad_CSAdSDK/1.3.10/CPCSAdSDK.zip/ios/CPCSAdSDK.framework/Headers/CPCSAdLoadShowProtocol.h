//
//  CPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "CPCSAdTypedef.h"

@class CPCSAdLoadBase;

@protocol CPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol CPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)cPonAdShowed:(CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)cPonAdClicked:(CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)cPonAdClosed:(CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)cPonAdVideoCompletePlaying:(CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)cPonAdShowFail:(CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)cPonAdOtherEvent:(CPCSAdLoadBase<CPCSAdLoadProtocol> *)adload event:(CPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
