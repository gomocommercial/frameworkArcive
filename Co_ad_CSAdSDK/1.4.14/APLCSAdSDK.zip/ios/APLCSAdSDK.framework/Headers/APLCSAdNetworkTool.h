//
//  APLCSAdNetworkTool.h
//  APLCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "APLCSAdDataModel.h"
#import "APLCSAdTypedef.h"
#import "APLCSNewStoreLiteRequestTool.h"
#import "NSString+APLCSGenerateHash.h"

@interface APLCSAdNetworkTool : NSObject

+ (APLCSAdNetworkTool *)shared;
@property(nonatomic, copy) APLCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)aPLrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(APLCSAdRequestCompleteBlock)complete;

- (void)aPLsetCDay:(void(^ _Nullable)(bool success))handle;
@end
