//
//  TESTIOSCSAdNetworkTool.h
//  TESTIOSCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "TESTIOSCSAdDataModel.h"
#import "TESTIOSCSAdTypedef.h"
#import "TESTIOSCSNewStoreLiteRequestTool.h"
#import "NSString+TESTIOSCSGenerateHash.h"

@interface TESTIOSCSAdNetworkTool : NSObject

+ (TESTIOSCSAdNetworkTool *)shared;
@property(nonatomic, copy) TESTIOSCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)tESTIOSrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(TESTIOSCSAdRequestCompleteBlock)complete;

- (void)tESTIOSsetCDay:(void(^ _Nullable)(bool success))handle;
@end
