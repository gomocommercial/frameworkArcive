//
//  DPCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "DPCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DPCSAdLoadBanner : DPCSAdLoadBase

@end

NS_ASSUME_NONNULL_END
