//
//  SCCSAdLoadDataProtocol.h
//  SCCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "SCCSAdTypedef.h"

@class SCCSAdDataModel;
@class SCCSAdLoadBase;

@protocol SCCSAdLoadProtocol;

@protocol SCCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)sConAdInfoFinish:(SCCSAdLoadBase<SCCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)sConLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)sConAdFail:(SCCSAdLoadBase<SCCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
