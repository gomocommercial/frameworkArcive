//
//  SCCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    SCCSAdLoadSuccess = 1,
    SCCSAdLoadFailure = -1,
    SCCSAdLoadTimeout = -2
} SCCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    SCCSAdPreloadSuccess = 1,
    //预加载失败
    SCCSAdPreloadFailure = -1,
    //重复加载
    SCCSAdPreloadRepeat = -2,
} SCCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    SCCSAdWillAppear,//即将出现
    SCCSAdDidAppear,//已经出现
    SCCSAdWillDisappear,//即将消失
    SCCSAdDidDisappear,//已经消失
    SCCSAdMuted,//静音广告
    SCCSAdWillLeaveApplication,//将要离开App

    SCCSAdVideoStart,//开始播放 常用于video
    SCCSAdVideoComplete,//播放完成 常用于video
    SCCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    SCCSAdVideoServerFail,//连接服务器成功，常用于fb video

    SCCSAdNativeDidDownload,//下载完成 常用于fb Native
    SCCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    SCCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    SCCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    SCCSAdVideoSkip,//跳过播放
    
    //广点通 插屏专用
    SCCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    SCCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    SCCSAdDidPresentFullScreen,//插屏弹出全屏广告
    SCCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    SCCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    SCCSAdPlayerStatusStarted,//开始播放
    SCCSAdPlayerStatusPaused,//用户行为导致暂停
    SCCSAdPlayerStatusStoped,//播放停止
    SCCSAdPlayerStatusError,//播放出错
    SCCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    SCCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    SCCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    SCCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    SCCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    SCCSAdVideoDidLoad//激励视频数据下载成功
} SCCSAdEvent;

typedef void (^SCCSAdLoadCompleteBlock)(SCCSAdLoadStatus adLoadStatus);

@class SCCSAdSetupParamsMaker;
@class SCCSAdSetupParams;

typedef SCCSAdSetupParamsMaker *(^SCCSAdStringInit)(NSString *);
typedef SCCSAdSetupParamsMaker *(^SCCSAdBoolInit)(BOOL);
typedef SCCSAdSetupParamsMaker *(^SCCSAdIntegerInit)(NSInteger);
typedef SCCSAdSetupParamsMaker *(^SCCSAdLongInit)(long);
typedef SCCSAdSetupParamsMaker *(^SCCSAdArrayInit)(NSArray *);
typedef SCCSAdSetupParams *(^SCCSAdMakeInit)(void);


@class SCCSAdDataModel;
typedef void (^SCCSAdRequestCompleteBlock)(NSMutableArray<SCCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^SCCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^SCCSAdPreloadCompleteBlock)(SCCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
