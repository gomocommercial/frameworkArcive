//
//  SCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "SCCSAdTypedef.h"

@class SCCSAdLoadBase;

@protocol SCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol SCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sConAdShowed:(SCCSAdLoadBase<SCCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)sConAdClicked:(SCCSAdLoadBase<SCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sConAdClosed:(SCCSAdLoadBase<SCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sConAdVideoCompletePlaying:(SCCSAdLoadBase<SCCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)sConAdShowFail:(SCCSAdLoadBase<SCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sConAdOtherEvent:(SCCSAdLoadBase<SCCSAdLoadProtocol> *)adload event:(SCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
