//
//  PCCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PCCSAdTypedef.h"

@class PCCSAdLoadBase;

@protocol PCCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PCCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pConAdShowed:(PCCSAdLoadBase<PCCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)pConAdClicked:(PCCSAdLoadBase<PCCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pConAdClosed:(PCCSAdLoadBase<PCCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pConAdVideoCompletePlaying:(PCCSAdLoadBase<PCCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)pConAdShowFail:(PCCSAdLoadBase<PCCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pConAdOtherEvent:(PCCSAdLoadBase<PCCSAdLoadProtocol> *)adload event:(PCCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
