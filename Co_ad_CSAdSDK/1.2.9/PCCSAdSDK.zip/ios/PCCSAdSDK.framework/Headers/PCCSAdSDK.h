//
//  PCCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PCCSAdLoadBase.h"
#import "PCCSAdDataModel.h"
#import "PCCSAdLoadProtocol.h"
#import "PCCSAdLoadDataProtocol.h"
#import "PCCSAdLoadShowProtocol.h"
#import "PCCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pCsetupByBlock:(void (^ _Nonnull)(PCCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pCloadAd:(NSString *)moduleId delegate:(id<PCCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pCadShowStatistic:(PCCSAdDataModel *)dataModel;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pCadClickStatistic:(PCCSAdDataModel *)dataModel;


// MARK: - 增加自定义广告源
+ (void)pCaddCustomFecher:(Class<PCCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
