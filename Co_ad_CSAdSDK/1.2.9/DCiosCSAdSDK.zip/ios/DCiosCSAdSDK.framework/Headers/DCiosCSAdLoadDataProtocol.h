//
//  DCiosCSAdLoadDataProtocol.h
//  DCiosCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "DCiosCSAdTypedef.h"

@class DCiosCSAdDataModel;
@class DCiosCSAdLoadBase;

@protocol DCiosCSAdLoadProtocol;

@protocol DCiosCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)dCiosonAdInfoFinish:(DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)dCiosonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败
 */
- (void)dCiosonAdFail:(DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
