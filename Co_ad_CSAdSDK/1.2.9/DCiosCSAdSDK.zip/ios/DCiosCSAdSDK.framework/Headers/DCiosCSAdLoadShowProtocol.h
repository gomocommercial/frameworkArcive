//
//  DCiosCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "DCiosCSAdTypedef.h"

@class DCiosCSAdLoadBase;

@protocol DCiosCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol DCiosCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)dCiosonAdShowed:(DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)dCiosonAdClicked:(DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)dCiosonAdClosed:(DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)dCiosonAdVideoCompletePlaying:(DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)dCiosonAdShowFail:(DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)dCiosonAdOtherEvent:(DCiosCSAdLoadBase<DCiosCSAdLoadProtocol> *)adload event:(DCiosCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
