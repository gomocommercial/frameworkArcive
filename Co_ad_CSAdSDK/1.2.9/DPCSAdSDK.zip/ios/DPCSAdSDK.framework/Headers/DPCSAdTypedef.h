//
//  DPCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    DPCSAdLoadSuccess = 1,
    DPCSAdLoadFailure = -1,
    DPCSAdLoadTimeout = -2
} DPCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    DPCSAdPreloadSuccess = 1,
    //预加载失败
    DPCSAdPreloadFailure = -1,
    //重复加载
    DPCSAdPreloadRepeat = -2,
} DPCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    DPCSAdWillAppear,//即将出现
    DPCSAdDidAppear,//已经出现
    DPCSAdWillDisappear,//即将消失
    DPCSAdDidDisappear,//已经消失
    DPCSAdMuted,//静音广告
    DPCSAdWillLeaveApplication,//将要离开App

    DPCSAdVideoStart,//开始播放 常用于video
    DPCSAdVideoComplete,//播放完成 常用于video
    DPCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    DPCSAdVideoServerFail,//连接服务器成功，常用于fb video

    DPCSAdNativeDidDownload,//下载完成 常用于fb Native
    DPCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    DPCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    DPCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    DPCSAdVideoSkip,//跳过播放
    
    //广点通 插屏专用
    DPCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    DPCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    DPCSAdDidPresentFullScreen,//插屏弹出全屏广告
    DPCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    DPCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    DPCSAdPlayerStatusStarted,//开始播放
    DPCSAdPlayerStatusPaused,//用户行为导致暂停
    DPCSAdPlayerStatusStoped,//播放停止
    DPCSAdPlayerStatusError,//播放出错
    DPCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    DPCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    DPCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    DPCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    DPCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    DPCSAdVideoDidLoad//激励视频数据下载成功
} DPCSAdEvent;

typedef void (^DPCSAdLoadCompleteBlock)(DPCSAdLoadStatus adLoadStatus);

@class DPCSAdSetupParamsMaker;
@class DPCSAdSetupParams;

typedef DPCSAdSetupParamsMaker *(^DPCSAdStringInit)(NSString *);
typedef DPCSAdSetupParamsMaker *(^DPCSAdBoolInit)(BOOL);
typedef DPCSAdSetupParamsMaker *(^DPCSAdIntegerInit)(NSInteger);
typedef DPCSAdSetupParamsMaker *(^DPCSAdLongInit)(long);
typedef DPCSAdSetupParamsMaker *(^DPCSAdArrayInit)(NSArray *);
typedef DPCSAdSetupParams *(^DPCSAdMakeInit)(void);


@class DPCSAdDataModel;
typedef void (^DPCSAdRequestCompleteBlock)(NSMutableArray<DPCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^DPCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^DPCSAdPreloadCompleteBlock)(DPCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
