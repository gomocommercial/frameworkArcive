//
//  DPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "DPCSAdTypedef.h"

@class DPCSAdLoadBase;

@protocol DPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol DPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)dPonAdShowed:(DPCSAdLoadBase<DPCSAdLoadProtocol> *)adload;


/**
 点击广告
 */
- (void)dPonAdClicked:(DPCSAdLoadBase<DPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)dPonAdClosed:(DPCSAdLoadBase<DPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)dPonAdVideoCompletePlaying:(DPCSAdLoadBase<DPCSAdLoadProtocol> *)adload;

/**
 加载失败
 */
- (void)dPonAdShowFail:(DPCSAdLoadBase<DPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)dPonAdOtherEvent:(DPCSAdLoadBase<DPCSAdLoadProtocol> *)adload event:(DPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
