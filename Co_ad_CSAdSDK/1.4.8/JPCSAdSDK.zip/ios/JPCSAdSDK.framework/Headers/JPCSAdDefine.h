//
//  JPCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define jPkAdvDataSourceFacebook   2 //FB 广告数据源
#define jPkAdvDataSourceAdmob      8 //Admob 广告数据源
#define jPkAdvDataSourceMopub      39//Mopub 广告数据源
#define jPkAdvDataSourceApplovin   20//applovin 广告数据源

#define jPkAdvDataSourceGDT        62//广点通 广告数据源
#define jPkAdvDataSourceBaidu      63//百度 广告数据源
#define jPkAdvDataSourceBU         64//头条 广告数据源
#define jPkAdvDataSourceABU         70//头条聚合 广告数据源
#define jPkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define jPkAdvDataSourcePangle     74//pangle 广告数据源

#define jPkOnlineAdvTypeBanner                   1  //banner
#define jPkOnlineAdvTypeInterstitial             2  //全屏
#define jPkOnlineAdvTypeNative                   3 //native
#define jPkOnlineAdvTypeVideo                    4 //视频
#define jPkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define jPkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define jPkOnlineAdvTypeOpen                     8 //开屏
#define jPkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define jPkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define jPkAdServerConfigError  -1 //服务器返回数据不正确
#define jPkAdLoadConfigFailed  -2 //广告加载失败


#define jPAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define jPkCSAdInstallDays @"jPkCSAdInstallDays"
#define jPkCSAdModule_key @"jPkCSAdModule_key_%@"
#define jPkCSNewAdModule_key @"jPkCSNewAdModule_key_%@"
#define jPkCSAdInstallTime @"jPkCSAdInstallTime"
#define jPkCSAdInstallHours @"jPkCSAdInstallHours"
#define jPkCSAdLastGetServerTime @"jPkCSAdLastRequestTime"
#define jPkCSAdloadTime 30

#define jPkCSLoadAdTimeOutNotification @"jPKCSLoadAdTimeOutNotification"
#define jPkCSLoadAdTimeOutNotificationKey @"jPKCSLoadAdTimeOutKey"

