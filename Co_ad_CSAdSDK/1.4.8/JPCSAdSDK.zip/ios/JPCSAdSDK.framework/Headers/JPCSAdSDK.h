//
//  JPCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "JPCSAdLoadBase.h"
#import "JPCSAdDataModel.h"
#import "JPCSAdLoadProtocol.h"
#import "JPCSAdLoadDataProtocol.h"
#import "JPCSAdLoadShowProtocol.h"
#import "JPCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)jPsetupByBlock:(void (^ _Nonnull)(JPCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)jPloadAd:(NSString *)moduleId delegate:(id<JPCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)jPadShowStatistic:(JPCSAdDataModel *)dataModel adload:(nonnull JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)jPadClickStatistic:(JPCSAdDataModel *)dataModel adload:(nonnull JPCSAdLoadBase<JPCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)jPaddCustomFecher:(Class<JPCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
