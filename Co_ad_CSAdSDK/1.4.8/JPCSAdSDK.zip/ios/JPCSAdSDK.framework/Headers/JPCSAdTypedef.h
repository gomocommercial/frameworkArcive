//
//  JPCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    JPCSAdLoadSuccess = 1,
    JPCSAdLoadFailure = -1,
    JPCSAdLoadTimeout = -2
} JPCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    JPCSAdPreloadSuccess = 1,
    //预加载失败
    JPCSAdPreloadFailure = -1,
    //重复加载
    JPCSAdPreloadRepeat = -2,
} JPCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    JPCSAdWillAppear,//即将出现
    JPCSAdDidAppear,//已经出现
    JPCSAdWillDisappear,//即将消失
    JPCSAdDidDisappear,//已经消失
    JPCSAdMuted,//静音广告
    JPCSAdWillLeaveApplication,//将要离开App

    JPCSAdVideoStart,//开始播放 常用于video
    JPCSAdVideoComplete,//播放完成 常用于video
    JPCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    JPCSAdVideoServerFail,//连接服务器成功，常用于fb video

    JPCSAdNativeDidDownload,//下载完成 常用于fb Native
    JPCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    JPCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    JPCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    JPCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    JPCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    JPCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    JPCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    JPCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    JPCSAdBUOpenDidAutoDimiss,//开屏自动消失
    JPCSAdBUOpenRenderSuccess, //渲染成功
    JPCSAdBUOpenRenderFail, //渲染失败
    JPCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    JPCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    JPCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    JPCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    JPCSAdDidPresentFullScreen,//插屏弹出全屏广告
    JPCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    JPCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    JPCSAdPlayerStatusStarted,//开始播放
    JPCSAdPlayerStatusPaused,//用户行为导致暂停
    JPCSAdPlayerStatusStoped,//播放停止
    JPCSAdPlayerStatusError,//播放出错
    JPCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    JPCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    JPCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    JPCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    JPCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    JPCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    JPCSAdRecordImpression, //广告曝光已记录
    JPCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    JPCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    JPCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    JPCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    JPCSAdABUOpenWillPresentFullScreen,
    JPCSAdABUOpenDidShowFailed,
    JPCSAdABUOpenWillDissmissFullScreen,
    JPCSAdABUOpenCountdownToZero,
    
    JPCSAdABUBannerWillPresentFullScreen,
    JPCSAdABUBannerWillDismissFullScreen,
    
    JPCSAdABURewardDidLoad,
    JPCSAdABURewardRenderFail,
    JPCSAdABURewardDidShowFailed,

} JPCSAdEvent;

typedef void (^JPCSAdLoadCompleteBlock)(JPCSAdLoadStatus adLoadStatus);

@class JPCSAdSetupParamsMaker;
@class JPCSAdSetupParams;

typedef JPCSAdSetupParamsMaker *(^JPCSAdStringInit)(NSString *);
typedef JPCSAdSetupParamsMaker *(^JPCSAdBoolInit)(BOOL);
typedef JPCSAdSetupParamsMaker *(^JPCSAdIntegerInit)(NSInteger);
typedef JPCSAdSetupParamsMaker *(^JPCSAdLongInit)(long);
typedef JPCSAdSetupParamsMaker *(^JPCSAdArrayInit)(NSArray *);
typedef JPCSAdSetupParams *(^JPCSAdMakeInit)(void);


@class JPCSAdDataModel;
typedef void (^JPCSAdRequestCompleteBlock)(NSMutableArray<JPCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^JPCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^JPCSAdPreloadCompleteBlock)(JPCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
