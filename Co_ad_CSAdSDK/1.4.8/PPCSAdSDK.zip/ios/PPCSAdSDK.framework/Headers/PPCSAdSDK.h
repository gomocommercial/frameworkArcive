//
//  PPCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "PPCSAdLoadBase.h"
#import "PPCSAdDataModel.h"
#import "PPCSAdLoadProtocol.h"
#import "PPCSAdLoadDataProtocol.h"
#import "PPCSAdLoadShowProtocol.h"
#import "PPCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)pPsetupByBlock:(void (^ _Nonnull)(PPCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)pPloadAd:(NSString *)moduleId delegate:(id<PPCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)pPadShowStatistic:(PPCSAdDataModel *)dataModel adload:(nonnull PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)pPadClickStatistic:(PPCSAdDataModel *)dataModel adload:(nonnull PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)pPaddCustomFecher:(Class<PPCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
