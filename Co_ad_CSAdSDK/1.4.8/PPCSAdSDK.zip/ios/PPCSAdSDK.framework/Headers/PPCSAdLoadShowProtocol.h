//
//  PPCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "PPCSAdTypedef.h"

@class PPCSAdLoadBase;

@protocol PPCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol PPCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)pPonAdShowed:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)pPonAdClicked:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)pPonAdClosed:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)pPonAdVideoCompletePlaying:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)pPonAdVideoGotReward:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload;
-(void)pPonAdDidPayRevenue:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)pPonAdShowFail:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)pPonAdOtherEvent:(PPCSAdLoadBase<PPCSAdLoadProtocol> *)adload event:(PPCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
