//
//  SMCSAdStatistics.h
//  SMCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "SMCSAdDataModel.h"
#import "SMCSAdTypedef.h"
#import "SMCSAdLoadBase.h"
@interface SMCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)sMadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)sMadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)sMadRewardVideoCompleteStatistic:(SMCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)sMadShowStatistic:(SMCSAdDataModel *)dataModel adload:(nonnull SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)sMadClickStatistic:(SMCSAdDataModel *)dataModel adload:(nonnull SMCSAdLoadBase<SMCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)sMadUploadRevenueStatistic:(SMCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
