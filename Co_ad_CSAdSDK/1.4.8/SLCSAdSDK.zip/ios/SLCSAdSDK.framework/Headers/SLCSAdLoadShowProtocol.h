//
//  SLCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "SLCSAdTypedef.h"

@class SLCSAdLoadBase;

@protocol SLCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol SLCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sLonAdShowed:(SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sLonAdClicked:(SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sLonAdClosed:(SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sLonAdVideoCompletePlaying:(SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sLonAdVideoGotReward:(SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload;
-(void)sLonAdDidPayRevenue:(SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload ad: (id )ad;
/**
 展示失败
 */
- (void)sLonAdShowFail:(SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sLonAdOtherEvent:(SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload event:(SLCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
