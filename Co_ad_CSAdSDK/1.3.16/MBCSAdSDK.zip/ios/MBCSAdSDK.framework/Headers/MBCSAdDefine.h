//
//  MBCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define mBkAdvDataSourceFacebook   2 //FB 广告数据源
#define mBkAdvDataSourceAdmob      8 //Admob 广告数据源
#define mBkAdvDataSourceMopub      39//Mopub 广告数据源
#define mBkAdvDataSourceApplovin   20//applovin 广告数据源

#define mBkAdvDataSourceGDT        62//广点通 广告数据源
#define mBkAdvDataSourceBaidu      63//百度 广告数据源
#define mBkAdvDataSourceBU         64//头条 广告数据源
#define mBkAdvDataSourceABU         70//头条聚合 广告数据源


#define mBkOnlineAdvTypeBanner                   1  //banner
#define mBkOnlineAdvTypeInterstitial             2  //全屏
#define mBkOnlineAdvTypeNative                   3 //native
#define mBkOnlineAdvTypeVideo                    4 //视频
#define mBkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define mBkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define mBkOnlineAdvTypeOpen                     8 //开屏
#define mBkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流

#define mBkAdServerConfigError  -1 //服务器返回数据不正确
#define mBkAdLoadConfigFailed  -2 //广告加载失败


#define mBAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define mBkCSAdInstallDays @"mBkCSAdInstallDays"
#define mBkCSAdModule_key @"mBkCSAdModule_key_%@"
#define mBkCSNewAdModule_key @"mBkCSNewAdModule_key_%@"
#define mBkCSAdInstallTime @"mBkCSAdInstallTime"
#define mBkCSAdInstallHours @"mBkCSAdInstallHours"
#define mBkCSAdLastGetServerTime @"mBkCSAdLastRequestTime"
#define mBkCSAdloadTime 30

#define mBkCSLoadAdTimeOutNotification @"mBKCSLoadAdTimeOutNotification"
#define mBkCSLoadAdTimeOutNotificationKey @"mBKCSLoadAdTimeOutKey"

