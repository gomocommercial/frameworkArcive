//
//  SMCSAdNetworkTool.h
//  SMCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "SMCSAdDataModel.h"
#import "SMCSAdTypedef.h"
#import "SMCSNewStoreLiteRequestTool.h"
#import "NSString+SMCSGenerateHash.h"

@interface SMCSAdNetworkTool : NSObject

+ (SMCSAdNetworkTool *)shared;
@property(nonatomic, copy) SMCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sMrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(SMCSAdRequestCompleteBlock)complete;

- (void)sMsetCDay:(void(^ _Nullable)(bool success))handle;
@end
