//
//  FaceVCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "FaceVCSAdLoadBase.h"
#import "FaceVCSAdDataModel.h"
#import "FaceVCSAdLoadProtocol.h"
#import "FaceVCSAdLoadDataProtocol.h"
#import "FaceVCSAdLoadShowProtocol.h"
#import "FaceVCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface FaceVCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)faceVsetupByBlock:(void (^ _Nonnull)(FaceVCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)faceVloadAd:(NSString *)moduleId delegate:(id<FaceVCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)faceVadShowStatistic:(FaceVCSAdDataModel *)dataModel adload:(nonnull FaceVCSAdLoadBase<FaceVCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)faceVadClickStatistic:(FaceVCSAdDataModel *)dataModel adload:(nonnull FaceVCSAdLoadBase<FaceVCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)faceVaddCustomFecher:(Class<FaceVCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
