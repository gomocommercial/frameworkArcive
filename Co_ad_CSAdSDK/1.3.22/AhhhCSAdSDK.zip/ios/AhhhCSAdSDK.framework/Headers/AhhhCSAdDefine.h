//
//  AhhhCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define ahhhkAdvDataSourceFacebook   2 //FB 广告数据源
#define ahhhkAdvDataSourceAdmob      8 //Admob 广告数据源
#define ahhhkAdvDataSourceMopub      39//Mopub 广告数据源
#define ahhhkAdvDataSourceApplovin   20//applovin 广告数据源

#define ahhhkAdvDataSourceGDT        62//广点通 广告数据源
#define ahhhkAdvDataSourceBaidu      63//百度 广告数据源
#define ahhhkAdvDataSourceBU         64//头条 广告数据源
#define ahhhkAdvDataSourceABU         70//头条聚合 广告数据源
#define ahhhkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define ahhhkAdvDataSourcePangle     74//pangle 广告数据源

#define ahhhkOnlineAdvTypeBanner                   1  //banner
#define ahhhkOnlineAdvTypeInterstitial             2  //全屏
#define ahhhkOnlineAdvTypeNative                   3 //native
#define ahhhkOnlineAdvTypeVideo                    4 //视频
#define ahhhkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define ahhhkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define ahhhkOnlineAdvTypeOpen                     8 //开屏
#define ahhhkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define ahhhkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define ahhhkAdServerConfigError  -1 //服务器返回数据不正确
#define ahhhkAdLoadConfigFailed  -2 //广告加载失败


#define ahhhAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define ahhhkCSAdInstallDays @"ahhhkCSAdInstallDays"
#define ahhhkCSAdModule_key @"ahhhkCSAdModule_key_%@"
#define ahhhkCSNewAdModule_key @"ahhhkCSNewAdModule_key_%@"
#define ahhhkCSAdInstallTime @"ahhhkCSAdInstallTime"
#define ahhhkCSAdInstallHours @"ahhhkCSAdInstallHours"
#define ahhhkCSAdLastGetServerTime @"ahhhkCSAdLastRequestTime"
#define ahhhkCSAdloadTime 30

#define ahhhkCSLoadAdTimeOutNotification @"ahhhKCSLoadAdTimeOutNotification"
#define ahhhkCSLoadAdTimeOutNotificationKey @"ahhhKCSLoadAdTimeOutKey"

