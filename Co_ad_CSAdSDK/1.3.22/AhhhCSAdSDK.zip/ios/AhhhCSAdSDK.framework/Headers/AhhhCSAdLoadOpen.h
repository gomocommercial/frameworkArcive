//
//  AhhhCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "AhhhCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadOpen : AhhhCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
