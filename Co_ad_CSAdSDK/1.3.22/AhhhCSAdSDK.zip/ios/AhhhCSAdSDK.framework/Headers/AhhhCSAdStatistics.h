//
//  AhhhCSAdStatistics.h
//  AhhhCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "AhhhCSAdDataModel.h"
#import "AhhhCSAdTypedef.h"
#import "AhhhCSAdLoadBase.h"
@interface AhhhCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)ahhhadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)ahhhadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)ahhhadRewardVideoCompleteStatistic:(AhhhCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)ahhhadShowStatistic:(AhhhCSAdDataModel *)dataModel adload:(nonnull AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)ahhhadClickStatistic:(AhhhCSAdDataModel *)dataModel adload:(nonnull AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)ahhhadUploadRevenueStatistic:(AhhhCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
