//
//  AhhhCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    AhhhCSAdLoadSuccess = 1,
    AhhhCSAdLoadFailure = -1,
    AhhhCSAdLoadTimeout = -2
} AhhhCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    AhhhCSAdPreloadSuccess = 1,
    //预加载失败
    AhhhCSAdPreloadFailure = -1,
    //重复加载
    AhhhCSAdPreloadRepeat = -2,
} AhhhCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    AhhhCSAdWillAppear,//即将出现
    AhhhCSAdDidAppear,//已经出现
    AhhhCSAdWillDisappear,//即将消失
    AhhhCSAdDidDisappear,//已经消失
    AhhhCSAdMuted,//静音广告
    AhhhCSAdWillLeaveApplication,//将要离开App

    AhhhCSAdVideoStart,//开始播放 常用于video
    AhhhCSAdVideoComplete,//播放完成 常用于video
    AhhhCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    AhhhCSAdVideoServerFail,//连接服务器成功，常用于fb video

    AhhhCSAdNativeDidDownload,//下载完成 常用于fb Native
    AhhhCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    AhhhCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    AhhhCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    AhhhCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    AhhhCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    AhhhCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    AhhhCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    AhhhCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    AhhhCSAdBUOpenDidAutoDimiss,//开屏自动消失
    AhhhCSAdBUOpenRenderSuccess, //渲染成功
    AhhhCSAdBUOpenRenderFail, //渲染失败
    AhhhCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    AhhhCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    AhhhCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    AhhhCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    AhhhCSAdDidPresentFullScreen,//插屏弹出全屏广告
    AhhhCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    AhhhCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    AhhhCSAdPlayerStatusStarted,//开始播放
    AhhhCSAdPlayerStatusPaused,//用户行为导致暂停
    AhhhCSAdPlayerStatusStoped,//播放停止
    AhhhCSAdPlayerStatusError,//播放出错
    AhhhCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    AhhhCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    AhhhCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    AhhhCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    AhhhCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    AhhhCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    AhhhCSAdRecordImpression, //广告曝光已记录
    AhhhCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    AhhhCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    AhhhCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    AhhhCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    AhhhCSAdABUOpenWillPresentFullScreen,
    AhhhCSAdABUOpenDidShowFailed,
    AhhhCSAdABUOpenWillDissmissFullScreen,
    AhhhCSAdABUOpenCountdownToZero,
    
    AhhhCSAdABUBannerWillPresentFullScreen,
    AhhhCSAdABUBannerWillDismissFullScreen,
    
    AhhhCSAdABURewardDidLoad,
    AhhhCSAdABURewardRenderFail,
    AhhhCSAdABURewardDidShowFailed,

} AhhhCSAdEvent;

typedef void (^AhhhCSAdLoadCompleteBlock)(AhhhCSAdLoadStatus adLoadStatus);

@class AhhhCSAdSetupParamsMaker;
@class AhhhCSAdSetupParams;

typedef AhhhCSAdSetupParamsMaker *(^AhhhCSAdStringInit)(NSString *);
typedef AhhhCSAdSetupParamsMaker *(^AhhhCSAdBoolInit)(BOOL);
typedef AhhhCSAdSetupParamsMaker *(^AhhhCSAdIntegerInit)(NSInteger);
typedef AhhhCSAdSetupParamsMaker *(^AhhhCSAdLongInit)(long);
typedef AhhhCSAdSetupParamsMaker *(^AhhhCSAdArrayInit)(NSArray *);
typedef AhhhCSAdSetupParams *(^AhhhCSAdMakeInit)(void);


@class AhhhCSAdDataModel;
typedef void (^AhhhCSAdRequestCompleteBlock)(NSMutableArray<AhhhCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^AhhhCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^AhhhCSAdPreloadCompleteBlock)(AhhhCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
