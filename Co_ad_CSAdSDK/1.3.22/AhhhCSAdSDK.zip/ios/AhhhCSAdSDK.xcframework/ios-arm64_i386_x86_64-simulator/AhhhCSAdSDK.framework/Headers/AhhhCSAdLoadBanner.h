//
//  AhhhCSAdLoadBanner.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "AhhhCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadBanner : AhhhCSAdLoadBase

//开始刷新(若广告源支持)
- (void)stopRefresh;

//停止刷新(若广告源支持)
- (void)startRefresh;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
