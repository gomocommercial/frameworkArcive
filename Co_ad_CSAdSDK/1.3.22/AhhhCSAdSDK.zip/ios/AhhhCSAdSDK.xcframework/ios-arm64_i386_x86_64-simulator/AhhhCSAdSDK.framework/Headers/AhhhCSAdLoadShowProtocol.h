//
//  AhhhCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "AhhhCSAdTypedef.h"

@class AhhhCSAdLoadBase;

@protocol AhhhCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol AhhhCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)ahhhonAdShowed:(AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)ahhhonAdClicked:(AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)ahhhonAdClosed:(AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)ahhhonAdVideoCompletePlaying:(AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)ahhhonAdShowFail:(AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)ahhhonAdOtherEvent:(AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload event:(AhhhCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
