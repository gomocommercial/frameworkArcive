//
//  AhhhCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "AhhhCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadNative : AhhhCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
