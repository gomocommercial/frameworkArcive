//
//  AhhhCSAdLoadDataProtocol.h
//  AhhhCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "AhhhCSAdTypedef.h"

@class AhhhCSAdDataModel;
@class AhhhCSAdLoadBase;

@protocol AhhhCSAdLoadProtocol;

@protocol AhhhCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)ahhhonAdInfoFinish:(AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)ahhhonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)ahhhonAdFail:(AhhhCSAdLoadBase<AhhhCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
