//
//  FRCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "FRCSAdLoadBase.h"
#import "FRCSAdDataModel.h"
#import "FRCSAdLoadProtocol.h"
#import "FRCSAdLoadDataProtocol.h"
#import "FRCSAdLoadShowProtocol.h"
#import "FRCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface FRCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)fRsetupByBlock:(void (^ _Nonnull)(FRCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)fRloadAd:(NSString *)moduleId delegate:(id<FRCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)fRadShowStatistic:(FRCSAdDataModel *)dataModel adload:(nonnull FRCSAdLoadBase<FRCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)fRadClickStatistic:(FRCSAdDataModel *)dataModel adload:(nonnull FRCSAdLoadBase<FRCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)fRaddCustomFecher:(Class<FRCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
