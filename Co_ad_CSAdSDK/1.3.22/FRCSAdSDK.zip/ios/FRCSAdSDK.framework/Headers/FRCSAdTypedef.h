//
//  FRCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    FRCSAdLoadSuccess = 1,
    FRCSAdLoadFailure = -1,
    FRCSAdLoadTimeout = -2
} FRCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    FRCSAdPreloadSuccess = 1,
    //预加载失败
    FRCSAdPreloadFailure = -1,
    //重复加载
    FRCSAdPreloadRepeat = -2,
} FRCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    FRCSAdWillAppear,//即将出现
    FRCSAdDidAppear,//已经出现
    FRCSAdWillDisappear,//即将消失
    FRCSAdDidDisappear,//已经消失
    FRCSAdMuted,//静音广告
    FRCSAdWillLeaveApplication,//将要离开App

    FRCSAdVideoStart,//开始播放 常用于video
    FRCSAdVideoComplete,//播放完成 常用于video
    FRCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    FRCSAdVideoServerFail,//连接服务器成功，常用于fb video

    FRCSAdNativeDidDownload,//下载完成 常用于fb Native
    FRCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    FRCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    FRCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    FRCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    FRCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    FRCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    FRCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    FRCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    FRCSAdBUOpenDidAutoDimiss,//开屏自动消失
    FRCSAdBUOpenRenderSuccess, //渲染成功
    FRCSAdBUOpenRenderFail, //渲染失败
    FRCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    FRCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    FRCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    FRCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    FRCSAdDidPresentFullScreen,//插屏弹出全屏广告
    FRCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    FRCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    FRCSAdPlayerStatusStarted,//开始播放
    FRCSAdPlayerStatusPaused,//用户行为导致暂停
    FRCSAdPlayerStatusStoped,//播放停止
    FRCSAdPlayerStatusError,//播放出错
    FRCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    FRCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    FRCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    FRCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    FRCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    FRCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    FRCSAdRecordImpression, //广告曝光已记录
    FRCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    FRCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    FRCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    FRCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    FRCSAdABUOpenWillPresentFullScreen,
    FRCSAdABUOpenDidShowFailed,
    FRCSAdABUOpenWillDissmissFullScreen,
    FRCSAdABUOpenCountdownToZero,
    
    FRCSAdABUBannerWillPresentFullScreen,
    FRCSAdABUBannerWillDismissFullScreen,
    
    FRCSAdABURewardDidLoad,
    FRCSAdABURewardRenderFail,
    FRCSAdABURewardDidShowFailed,

} FRCSAdEvent;

typedef void (^FRCSAdLoadCompleteBlock)(FRCSAdLoadStatus adLoadStatus);

@class FRCSAdSetupParamsMaker;
@class FRCSAdSetupParams;

typedef FRCSAdSetupParamsMaker *(^FRCSAdStringInit)(NSString *);
typedef FRCSAdSetupParamsMaker *(^FRCSAdBoolInit)(BOOL);
typedef FRCSAdSetupParamsMaker *(^FRCSAdIntegerInit)(NSInteger);
typedef FRCSAdSetupParamsMaker *(^FRCSAdLongInit)(long);
typedef FRCSAdSetupParamsMaker *(^FRCSAdArrayInit)(NSArray *);
typedef FRCSAdSetupParams *(^FRCSAdMakeInit)(void);


@class FRCSAdDataModel;
typedef void (^FRCSAdRequestCompleteBlock)(NSMutableArray<FRCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^FRCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^FRCSAdPreloadCompleteBlock)(FRCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
