//
//  FRCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "FRCSAdTypedef.h"

@class FRCSAdLoadBase;

@protocol FRCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol FRCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)fRonAdShowed:(FRCSAdLoadBase<FRCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)fRonAdClicked:(FRCSAdLoadBase<FRCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)fRonAdClosed:(FRCSAdLoadBase<FRCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)fRonAdVideoCompletePlaying:(FRCSAdLoadBase<FRCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)fRonAdShowFail:(FRCSAdLoadBase<FRCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)fRonAdOtherEvent:(FRCSAdLoadBase<FRCSAdLoadProtocol> *)adload event:(FRCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
