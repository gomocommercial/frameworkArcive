//
//  HOCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "HOCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface HOCSAdLoadOpen : HOCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
