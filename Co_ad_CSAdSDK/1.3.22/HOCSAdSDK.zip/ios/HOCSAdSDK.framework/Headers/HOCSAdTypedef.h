//
//  HOCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    HOCSAdLoadSuccess = 1,
    HOCSAdLoadFailure = -1,
    HOCSAdLoadTimeout = -2
} HOCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    HOCSAdPreloadSuccess = 1,
    //预加载失败
    HOCSAdPreloadFailure = -1,
    //重复加载
    HOCSAdPreloadRepeat = -2,
} HOCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    HOCSAdWillAppear,//即将出现
    HOCSAdDidAppear,//已经出现
    HOCSAdWillDisappear,//即将消失
    HOCSAdDidDisappear,//已经消失
    HOCSAdMuted,//静音广告
    HOCSAdWillLeaveApplication,//将要离开App

    HOCSAdVideoStart,//开始播放 常用于video
    HOCSAdVideoComplete,//播放完成 常用于video
    HOCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    HOCSAdVideoServerFail,//连接服务器成功，常用于fb video

    HOCSAdNativeDidDownload,//下载完成 常用于fb Native
    HOCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    HOCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    HOCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    HOCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    HOCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    HOCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    HOCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    HOCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    HOCSAdBUOpenDidAutoDimiss,//开屏自动消失
    HOCSAdBUOpenRenderSuccess, //渲染成功
    HOCSAdBUOpenRenderFail, //渲染失败
    HOCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    HOCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    HOCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    HOCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    HOCSAdDidPresentFullScreen,//插屏弹出全屏广告
    HOCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    HOCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    HOCSAdPlayerStatusStarted,//开始播放
    HOCSAdPlayerStatusPaused,//用户行为导致暂停
    HOCSAdPlayerStatusStoped,//播放停止
    HOCSAdPlayerStatusError,//播放出错
    HOCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    HOCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    HOCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    HOCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    HOCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    HOCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    HOCSAdRecordImpression, //广告曝光已记录
    HOCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    HOCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    HOCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    HOCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    HOCSAdABUOpenWillPresentFullScreen,
    HOCSAdABUOpenDidShowFailed,
    HOCSAdABUOpenWillDissmissFullScreen,
    HOCSAdABUOpenCountdownToZero,
    
    HOCSAdABUBannerWillPresentFullScreen,
    HOCSAdABUBannerWillDismissFullScreen,
    
    HOCSAdABURewardDidLoad,
    HOCSAdABURewardRenderFail,
    HOCSAdABURewardDidShowFailed,

} HOCSAdEvent;

typedef void (^HOCSAdLoadCompleteBlock)(HOCSAdLoadStatus adLoadStatus);

@class HOCSAdSetupParamsMaker;
@class HOCSAdSetupParams;

typedef HOCSAdSetupParamsMaker *(^HOCSAdStringInit)(NSString *);
typedef HOCSAdSetupParamsMaker *(^HOCSAdBoolInit)(BOOL);
typedef HOCSAdSetupParamsMaker *(^HOCSAdIntegerInit)(NSInteger);
typedef HOCSAdSetupParamsMaker *(^HOCSAdLongInit)(long);
typedef HOCSAdSetupParamsMaker *(^HOCSAdArrayInit)(NSArray *);
typedef HOCSAdSetupParams *(^HOCSAdMakeInit)(void);


@class HOCSAdDataModel;
typedef void (^HOCSAdRequestCompleteBlock)(NSMutableArray<HOCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^HOCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^HOCSAdPreloadCompleteBlock)(HOCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
