//
//  HOCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "HOCSAdTypedef.h"

@class HOCSAdLoadBase;

@protocol HOCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol HOCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)hOonAdShowed:(HOCSAdLoadBase<HOCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)hOonAdClicked:(HOCSAdLoadBase<HOCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)hOonAdClosed:(HOCSAdLoadBase<HOCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)hOonAdVideoCompletePlaying:(HOCSAdLoadBase<HOCSAdLoadProtocol> *)adload;

/**
 展示失败
 */
- (void)hOonAdShowFail:(HOCSAdLoadBase<HOCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)hOonAdOtherEvent:(HOCSAdLoadBase<HOCSAdLoadProtocol> *)adload event:(HOCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
