//
//  SLCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "SLCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadOpen : SLCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
