//
//  SLCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SLCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadNative : SLCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
