//
//  SLCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "SLCSAdLoadBase.h"
#import "SLCSAdDataModel.h"
#import "SLCSAdLoadProtocol.h"
#import "SLCSAdLoadDataProtocol.h"
#import "SLCSAdLoadShowProtocol.h"
#import "SLCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)sLsetupByBlock:(void (^ _Nonnull)(SLCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)sLloadAd:(NSString *)moduleId delegate:(id<SLCSAdLoadDataProtocol>)delegate;

/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)sLadShowStatistic:(SLCSAdDataModel *)dataModel adload:(nonnull SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)sLadClickStatistic:(SLCSAdDataModel *)dataModel adload:(nonnull SLCSAdLoadBase<SLCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)sLaddCustomFecher:(Class<SLCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
