//
//  FRCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define fRkAdvDataSourceFacebook   2 //FB 广告数据源
#define fRkAdvDataSourceAdmob      8 //Admob 广告数据源
#define fRkAdvDataSourceMopub      39//Mopub 广告数据源
#define fRkAdvDataSourceApplovin   20//applovin 广告数据源

#define fRkAdvDataSourceGDT        62//广点通 广告数据源
#define fRkAdvDataSourceBaidu      63//百度 广告数据源
#define fRkAdvDataSourceBU         64//头条 广告数据源
#define fRkAdvDataSourceABU         70//头条聚合 广告数据源
#define fRkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define fRkAdvDataSourcePangle     74//pangle 广告数据源

#define fRkOnlineAdvTypeBanner                   1  //banner
#define fRkOnlineAdvTypeInterstitial             2  //全屏
#define fRkOnlineAdvTypeNative                   3 //native
#define fRkOnlineAdvTypeVideo                    4 //视频
#define fRkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define fRkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define fRkOnlineAdvTypeOpen                     8 //开屏
#define fRkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define fRkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define fRkAdServerConfigError  -1 //服务器返回数据不正确
#define fRkAdLoadConfigFailed  -2 //广告加载失败


#define fRAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define fRkCSAdInstallDays @"fRkCSAdInstallDays"
#define fRkCSAdModule_key @"fRkCSAdModule_key_%@"
#define fRkCSNewAdModule_key @"fRkCSNewAdModule_key_%@"
#define fRkCSAdInstallTime @"fRkCSAdInstallTime"
#define fRkCSAdInstallHours @"fRkCSAdInstallHours"
#define fRkCSAdLastGetServerTime @"fRkCSAdLastRequestTime"
#define fRkCSAdloadTime 30

#define fRkCSLoadAdTimeOutNotification @"fRKCSLoadAdTimeOutNotification"
#define fRkCSLoadAdTimeOutNotificationKey @"fRKCSLoadAdTimeOutKey"

