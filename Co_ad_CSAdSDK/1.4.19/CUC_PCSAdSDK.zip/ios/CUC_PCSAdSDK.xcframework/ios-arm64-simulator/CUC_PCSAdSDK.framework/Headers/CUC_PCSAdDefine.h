//
//  CUC_PCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define cUC_PkAdvDataSourceFacebook   2 //FB 广告数据源
#define cUC_PkAdvDataSourceAdmob      8 //Admob 广告数据源
#define cUC_PkAdvDataSourceMopub      39//Mopub 广告数据源
#define cUC_PkAdvDataSourceApplovin   20//applovin 广告数据源

#define cUC_PkAdvDataSourceGDT        62//广点通 广告数据源
#define cUC_PkAdvDataSourceBaidu      63//百度 广告数据源
#define cUC_PkAdvDataSourceBU         64//头条 广告数据源
#define cUC_PkAdvDataSourceABU         70//头条聚合 广告数据源
#define cUC_PkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define cUC_PkAdvDataSourcePangle     74//pangle 广告数据源
#define cUC_PkAdvDataSourceHyperbidTools  79//Hyperbid Tools 广告数据源

#define cUC_PkOnlineAdvTypeBanner                   1  //banner
#define cUC_PkOnlineAdvTypeInterstitial             2  //全屏
#define cUC_PkOnlineAdvTypeNative                   3 //native
#define cUC_PkOnlineAdvTypeVideo                    4 //视频
#define cUC_PkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define cUC_PkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define cUC_PkOnlineAdvTypeOpen                     8 //开屏
#define cUC_PkOnlineAdvTypeBUNativeExpress          10 //穿山甲模板信息流
#define cUC_PkOnlineAdvTypeBuInteAllScreenVideo     13 //穿山甲插全屏（穿山甲聚合）
#define cUC_PkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define cUC_PkAdServerConfigError  -1 //服务器返回数据不正确
#define cUC_PkAdLoadConfigFailed  -2 //广告加载失败


#define cUC_PAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define cUC_PkCSAdInstallDays @"cUC_PkCSAdInstallDays"
#define cUC_PkCSAdModule_key @"cUC_PkCSAdModule_key_%@"
#define cUC_PkCSNewAdModule_key @"cUC_PkCSNewAdModule_key_%@"
#define cUC_PkCSAdInstallTime @"cUC_PkCSAdInstallTime"
#define cUC_PkCSAdInstallHours @"cUC_PkCSAdInstallHours"
#define cUC_PkCSAdLastGetServerTime @"cUC_PkCSAdLastRequestTime"
#define cUC_PkCSAdloadTime 30

#define cUC_PkCSLoadAdTimeOutNotification @"cUC_PKCSLoadAdTimeOutNotification"
#define cUC_PkCSLoadAdTimeOutNotificationKey @"cUC_PKCSLoadAdTimeOutKey"

