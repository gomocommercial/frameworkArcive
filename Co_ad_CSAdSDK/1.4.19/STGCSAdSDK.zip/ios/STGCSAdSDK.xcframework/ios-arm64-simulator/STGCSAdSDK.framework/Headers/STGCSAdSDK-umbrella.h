#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "STGCSAdSDK.h"
#import "STGCSAdPreload.h"
#import "STGCSAdLoadDataProtocol.h"
#import "STGCSAdLoadShowProtocol.h"
#import "STGCSAdLoadProtocol.h"
#import "STGCSAdLoadBase.h"
#import "STGCSAdLoadInterstitial.h"
#import "STGCSAdLoadNative.h"
#import "STGCSAdLoadReward.h"
#import "STGCSAdLoadOpen.h"
#import "STGCSAdLoadBanner.h"
#import "STGCSAdManager.h"
#import "STGCSAdSetupParams.h"
#import "STGCSAdSetupParamsMaker.h"
#import "STGCSAdDefine.h"
#import "STGCSAdTypedef.h"
#import "STGCSAdStatistics.h"
#import "STGCSAdDataModel.h"
#import "STGCSAdNetworkTool.h"
#import "STGCSNewStoreLiteRequestTool.h"
#import "NSString+STGCSGenerateHash.h"

FOUNDATION_EXPORT double STGCSAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char STGCSAdSDKVersionString[];

