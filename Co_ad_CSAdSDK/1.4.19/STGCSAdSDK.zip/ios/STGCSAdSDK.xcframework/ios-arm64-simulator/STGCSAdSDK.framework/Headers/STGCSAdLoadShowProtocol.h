//
//  STGCSAdLoadShowProtocol.h
//  AFNetworking
//
//  Created by Zy on 2019/4/8.
//

#import <Foundation/Foundation.h>
#import "STGCSAdTypedef.h"

@class STGCSAdLoadBase;

@protocol STGCSAdLoadProtocol;

NS_ASSUME_NONNULL_BEGIN

@protocol STGCSAdLoadShowProtocol <NSObject>


/**
 开始展示广告
 */
- (void)sTGonAdShowed:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload;


/**
 点击广告(开屏广告未使用此代理)
 */
- (void)sTGonAdClicked:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload;


/**
 关闭广告(Native广告未使用此代理)
 */
- (void)sTGonAdClosed:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload;



@optional

/**
 激励视频计费代理
 */
-(void)sTGonAdVideoCompletePlaying:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload;
/**
 获得奖励
 */
//-(void)sTGonAdVideoGotReward:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload;
-(void)sTGonAdDidPayRevenue:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload ad: (id )ad;



/// 获得广告价值回调
/// - Parameters:
///   - adload: 广告数据
-(void)sTGonAdDidGetEcpm:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload;
/**
 展示失败
 */
- (void)sTGonAdShowFail:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload error:(NSError *)error;

/**
 广告其他事件
 */
- (void)sTGonAdOtherEvent:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload event:(STGCSAdEvent)event;


@end

NS_ASSUME_NONNULL_END
