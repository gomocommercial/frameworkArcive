//
//  STGCSAdLoadNative.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "STGCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadNative : STGCSAdLoadBase

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
