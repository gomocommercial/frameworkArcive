//
//  STGCSAdLoadOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import "STGCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadOpen : STGCSAdLoadBase

- (BOOL)isValidFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
