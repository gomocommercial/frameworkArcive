//
//  STGCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    STGCSAdLoadSuccess = 1,
    STGCSAdLoadFailure = -1,
    STGCSAdLoadTimeout = -2
} STGCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    STGCSAdPreloadSuccess = 1,
    //预加载失败
    STGCSAdPreloadFailure = -1,
    //重复加载
    STGCSAdPreloadRepeat = -2,
} STGCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    STGCSAdWillAppear,//即将出现
    STGCSAdDidAppear,//已经出现
    STGCSAdWillDisappear,//即将消失
    STGCSAdDidDisappear,//已经消失
    STGCSAdMuted,//静音广告
    STGCSAdWillLeaveApplication,//将要离开App

    STGCSAdVideoStart,//开始播放 常用于video
    STGCSAdVideoComplete,//播放完成 常用于video
    STGCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    STGCSAdVideoServerFail,//连接服务器成功，常用于fb video

    STGCSAdNativeDidDownload,//下载完成 常用于fb Native
    STGCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    STGCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    STGCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    STGCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    STGCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    STGCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    STGCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    STGCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    STGCSAdBUOpenDidAutoDimiss,//开屏自动消失
    STGCSAdBUOpenRenderSuccess, //渲染成功
    STGCSAdBUOpenRenderFail, //渲染失败
    STGCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    STGCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    STGCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    STGCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    STGCSAdDidPresentFullScreen,//插屏弹出全屏广告
    STGCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    STGCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    STGCSAdPlayerStatusStarted,//开始播放
    STGCSAdPlayerStatusPaused,//用户行为导致暂停
    STGCSAdPlayerStatusStoped,//播放停止
    STGCSAdPlayerStatusError,//播放出错
    STGCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    STGCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    STGCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    STGCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    STGCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    STGCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    STGCSAdRecordImpression, //广告曝光已记录
    STGCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    STGCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    STGCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    STGCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    STGCSAdABUOpenWillPresentFullScreen,
    STGCSAdABUOpenDidShowFailed,
    STGCSAdABUOpenWillDissmissFullScreen,
    STGCSAdABUOpenCountdownToZero,
    
    STGCSAdABUBannerWillPresentFullScreen,
    STGCSAdABUBannerWillDismissFullScreen,
    
    STGCSAdABURewardDidLoad,
    STGCSAdABURewardRenderFail,
    STGCSAdABURewardDidShowFailed,

} STGCSAdEvent;

typedef void (^STGCSAdLoadCompleteBlock)(STGCSAdLoadStatus adLoadStatus);

@class STGCSAdSetupParamsMaker;
@class STGCSAdSetupParams;

typedef STGCSAdSetupParamsMaker *(^STGCSAdStringInit)(NSString *);
typedef STGCSAdSetupParamsMaker *(^STGCSAdBoolInit)(BOOL);
typedef STGCSAdSetupParamsMaker *(^STGCSAdIntegerInit)(NSInteger);
typedef STGCSAdSetupParamsMaker *(^STGCSAdLongInit)(long);
typedef STGCSAdSetupParamsMaker *(^STGCSAdArrayInit)(NSArray *);
typedef STGCSAdSetupParams *(^STGCSAdMakeInit)(void);


@class STGCSAdDataModel;
typedef void (^STGCSAdRequestCompleteBlock)(NSMutableArray<STGCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^STGCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^STGCSAdPreloadCompleteBlock)(STGCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
