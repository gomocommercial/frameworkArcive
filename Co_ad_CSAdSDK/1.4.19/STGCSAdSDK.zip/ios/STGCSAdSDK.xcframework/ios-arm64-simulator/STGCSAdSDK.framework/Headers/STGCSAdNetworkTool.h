//
//  STGCSAdNetworkTool.h
//  STGCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "STGCSAdDataModel.h"
#import "STGCSAdTypedef.h"
#import "STGCSNewStoreLiteRequestTool.h"
#import "NSString+STGCSGenerateHash.h"

@interface STGCSAdNetworkTool : NSObject

+ (STGCSAdNetworkTool *)shared;
@property(nonatomic, copy) STGCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sTGrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(STGCSAdRequestCompleteBlock)complete;

- (void)sTGsetCDay:(void(^ _Nullable)(bool success))handle;
@end
