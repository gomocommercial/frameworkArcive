//
//  STGCSAdSDK.h
//  AFNetworking
//
//  Created by Zy on 2019/3/20.
//

#import <Foundation/Foundation.h>
#import "STGCSAdLoadBase.h"
#import "STGCSAdDataModel.h"
#import "STGCSAdLoadProtocol.h"
#import "STGCSAdLoadDataProtocol.h"
#import "STGCSAdLoadShowProtocol.h"
#import "STGCSAdSetupParamsMaker.h"

NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdSDK : NSObject

/**
 SDK配置

 @param block SDK配置bolck
 */
+ (void)sTGsetupByBlock:(void (^ _Nonnull)(STGCSAdSetupParamsMaker *maker))block;

// MARK: - ---------------------------常规接口（不做广告实例管理）----------------------------------
/**
 加载广告

 @param moduleId 模块ID
 @param delegate 广告回调代理
 */
+ (void)sTGloadAd:(NSString *)moduleId delegate:(id<STGCSAdLoadDataProtocol>)delegate;

+ (void)sTGloadAd:(NSString *)moduleId extraInfo:(NSDictionary *)extraInfo delegate:(id<STGCSAdLoadDataProtocol>)delegate;
/**
 展示广告统计(使用预加载展示无需打此统计)
 */
+ (void)sTGadShowStatistic:(STGCSAdDataModel *)dataModel adload:(nonnull STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload;

/**
 点击广告告统计(使用预加载展示无需打此统计)
 */
+ (void)sTGadClickStatistic:(STGCSAdDataModel *)dataModel adload:(nonnull STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload;


// MARK: - 增加自定义广告源
+ (void)sTGaddCustomFecher:(Class<STGCSAdLoadProtocol>)fetcher;


@end

NS_ASSUME_NONNULL_END
