//
//  STGCSAdLoadDataProtocol.h
//  STGCSAdSDK
//
//  Created by Zy on 2018/7/17.
//

#import <Foundation/Foundation.h>
#import "STGCSAdTypedef.h"

@class STGCSAdDataModel;
@class STGCSAdLoadBase;

@protocol STGCSAdLoadProtocol;

@protocol STGCSAdLoadDataProtocol <NSObject>

@required
// MARK: - 所有广告源通用协议

/**
 加载广告数据完成
 */

- (void)sTGonAdInfoFinish:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload;

/**
 加载广告数据失败
 */
- (void)sTGonLoadAdConfigFail:(NSString *)moduleId error:(NSError *)error;

@optional
/**
 加载失败(被加载失败一个广告将调用一次)
 */
- (void)sTGonAdFail:(STGCSAdLoadBase<STGCSAdLoadProtocol> *)adload error:(NSError *)error;
@end
