//
//  PIKCSAdStatistics.h
//  PIKCSAdSDK
//
//  Created by Zy on 2018/7/13.
//

#import <Foundation/Foundation.h>
#import "PIKCSAdDataModel.h"
#import "PIKCSAdTypedef.h"
#import "PIKCSAdLoadBase.h"
@interface PIKCSAdStatistics : NSObject
+ (instancetype)sharedInstance;


/**
   广告配置请求结果广告统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)pIKadRequsetStatistic:(NSString *)statisticsObject
         associationObject:(NSString *)associationObject
                       tab:(NSString *)tab
                    remark:(NSString *)remark
                  position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;

/**
   广告请求结果统计
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param tab Tab分类
 @param remark 备注
 @param position 位置
 @param adId 广告Id
 */
-(void)pIKadRequestResultStatistic:(NSString *)statisticsObject
               associationObject:(NSString *)associationObject
                             tab:(NSString *)tab
                          remark:(NSString *)remark
                        position:(NSString *)position entrance:(NSString *)entrance adId:(NSString *)adId;


/**
 激励视频广告获得奖励统计
 */
-(void)pIKadRewardVideoCompleteStatistic:(PIKCSAdDataModel *)dataModel;

/**
   展示广告统计(客户端调用)
 */
- (void)pIKadShowStatistic:(PIKCSAdDataModel *)dataModel adload:(nonnull PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload;

/**
   点击广告告统计(客户端调用)
 */
- (void)pIKadClickStatistic:(PIKCSAdDataModel *)dataModel adload:(nonnull PIKCSAdLoadBase<PIKCSAdLoadProtocol> *)adload;

/**
   上传收入统计
 */
-(void)pIKadUploadRevenueStatistic:(PIKCSAdDataModel *)dataModel revenue:(NSString *)revenue nextCodeId:(NSString *)nextCodeId;
@end
