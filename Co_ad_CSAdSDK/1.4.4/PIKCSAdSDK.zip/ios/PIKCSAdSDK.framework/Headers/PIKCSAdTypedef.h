//
//  PIKCSAdTypedef.h
//  Pods
//
//  Created by Zy on 2019/3/20.
//

typedef enum : NSInteger {
    PIKCSAdLoadSuccess = 1,
    PIKCSAdLoadFailure = -1,
    PIKCSAdLoadTimeout = -2
} PIKCSAdLoadStatus;

typedef enum : NSInteger {
    //预加载成功
    PIKCSAdPreloadSuccess = 1,
    //预加载失败
    PIKCSAdPreloadFailure = -1,
    //重复加载
    PIKCSAdPreloadRepeat = -2,
} PIKCSAdPreloadStatus;


typedef enum : NSUInteger {
    
    PIKCSAdWillAppear,//即将出现
    PIKCSAdDidAppear,//已经出现
    PIKCSAdWillDisappear,//即将消失
    PIKCSAdDidDisappear,//已经消失
    PIKCSAdMuted,//静音广告
    PIKCSAdWillLeaveApplication,//将要离开App

    PIKCSAdVideoStart,//开始播放 常用于video
    PIKCSAdVideoComplete,//播放完成 常用于video
    PIKCSAdVideoServerSuccess,//连接服务器成功，常用于fb video
    PIKCSAdVideoServerFail,//连接服务器成功，常用于fb video

    PIKCSAdNativeDidDownload,//下载完成 常用于fb Native
    PIKCSAdNativeFinishClick,//完成点击 常用与fb Native
    
    PIKCSAdDidExpire, //已到期 常用于mopub interstitial 和 rewardVideo
    PIKCSAdVideoPlayFailed,//播放失败 常用于穿山甲rewardVideo 和全屏视频
    PIKCSAdVideoSkip,//跳过播放
    
    //穿山甲 SDK渲染开屏专用
    PIKCSAdBUOpenWillClose,//SDK渲染开屏广告即将关闭回调
    PIKCSAdBUOpenWillOpenOtherVC,//广告点击即将跳转到其他控制器
    PIKCSAdBUOpenCloseOtherVC,//广告跳转到其他控制器时，该控制器被关闭时调用
    PIKCSAdBUOpenCountdownToZero,//倒计时为0时会触发此回调
    PIKCSAdBUOpenDidAutoDimiss,//开屏自动消失
    PIKCSAdBUOpenRenderSuccess, //渲染成功
    PIKCSAdBUOpenRenderFail, //渲染失败
    PIKCSAdBUOpenWillShow, //即将显示
    //穿山甲 Banner专用
    PIKCSAdBUBannerCloseOtherVC, //
    
    //广点通 插屏专用
    PIKCSAdWillExposure,//插屏广告曝光(广点通激励视频也适用)
    PIKCSAdWillPresentFullScreen,//插屏即将弹出全屏广告
    PIKCSAdDidPresentFullScreen,//插屏弹出全屏广告
    PIKCSAdWillDismissFullScreen,//插屏全屏广告页将要关闭
    PIKCSAdDidDismissFullScreen,//插屏全屏广告页被关闭
    PIKCSAdPlayerStatusStarted,//开始播放
    PIKCSAdPlayerStatusPaused,//用户行为导致暂停
    PIKCSAdPlayerStatusStoped,//播放停止
    PIKCSAdPlayerStatusError,//播放出错
    PIKCSAdWillPresentVideoVC,//插屏 视频广告详情页将要展示
    PIKCSAdDidPresentVideoVC,//插屏 视频广告详情页已经展示
    PIKCSAdWillDismissVideoVC,//插屏 视频广告详情页将要消失
    PIKCSAdDidDismissVideoVC,//插屏 视频广告详情页已经消失
    //广点通 激励视频专用
    PIKCSAdDidRewardEffective,//激励视频广告播放达到激励条件，以此回调作为奖励依据
    PIKCSAdVideoDidLoad,//激励视频数据下载成功
    
    //admob banner
    PIKCSAdRecordImpression, //广告曝光已记录
    PIKCSAdBannerWillPresentScreen, //Banner广告将展示全屏视图
    PIKCSAdBannerWillDismissScreen, //Banner广告将从全屏视图离开
    PIKCSAdBannerDidDismissScreen, //Banner广告已从全屏视图离开
    
    //穿山甲插屏视频
    PIKCSAdDidDownloadVideo,//视频下载完成
    
    //穿山甲聚合
    PIKCSAdABUOpenWillPresentFullScreen,
    PIKCSAdABUOpenDidShowFailed,
    PIKCSAdABUOpenWillDissmissFullScreen,
    PIKCSAdABUOpenCountdownToZero,
    
    PIKCSAdABUBannerWillPresentFullScreen,
    PIKCSAdABUBannerWillDismissFullScreen,
    
    PIKCSAdABURewardDidLoad,
    PIKCSAdABURewardRenderFail,
    PIKCSAdABURewardDidShowFailed,

} PIKCSAdEvent;

typedef void (^PIKCSAdLoadCompleteBlock)(PIKCSAdLoadStatus adLoadStatus);

@class PIKCSAdSetupParamsMaker;
@class PIKCSAdSetupParams;

typedef PIKCSAdSetupParamsMaker *(^PIKCSAdStringInit)(NSString *);
typedef PIKCSAdSetupParamsMaker *(^PIKCSAdBoolInit)(BOOL);
typedef PIKCSAdSetupParamsMaker *(^PIKCSAdIntegerInit)(NSInteger);
typedef PIKCSAdSetupParamsMaker *(^PIKCSAdLongInit)(long);
typedef PIKCSAdSetupParamsMaker *(^PIKCSAdArrayInit)(NSArray *);
typedef PIKCSAdSetupParams *(^PIKCSAdMakeInit)(void);


@class PIKCSAdDataModel;
typedef void (^PIKCSAdRequestCompleteBlock)(NSMutableArray<PIKCSAdDataModel *> *dataItemBeanModels, NSString *moduleId);

typedef void (^PIKCSAdTimeRequestCompleteBlock)(NSTimeInterval timeInterval);

typedef void (^PIKCSAdPreloadCompleteBlock)(PIKCSAdPreloadStatus adLoadStatus,NSError * _Nullable error);

static dispatch_once_t mopubOnceToken;

static NSString *AD_REQUEST_SUCCESS = @"1";
static NSString *AD_REQUEST_FAILURE = @"-1";
static NSString *AD_REQUEST_TIMEOUT = @"-2";
