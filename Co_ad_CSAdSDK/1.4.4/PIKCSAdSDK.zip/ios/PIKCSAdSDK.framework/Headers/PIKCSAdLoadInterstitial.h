//
//  PIKCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "PIKCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PIKCSAdLoadInterstitial : PIKCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
