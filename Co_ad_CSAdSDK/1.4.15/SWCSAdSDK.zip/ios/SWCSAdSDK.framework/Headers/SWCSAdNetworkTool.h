//
//  SWCSAdNetworkTool.h
//  SWCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "SWCSAdDataModel.h"
#import "SWCSAdTypedef.h"
#import "SWCSNewStoreLiteRequestTool.h"
#import "NSString+SWCSGenerateHash.h"

@interface SWCSAdNetworkTool : NSObject

+ (SWCSAdNetworkTool *)shared;
@property(nonatomic, copy) SWCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)sWrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(SWCSAdRequestCompleteBlock)complete;

- (void)sWsetCDay:(void(^ _Nullable)(bool success))handle;
@end
