//
//  SMCSAdLoadInterstitial.h
//  AFNetworking
//
//  Created by Zy on 2019/3/21.
//

#import "SMCSAdLoadBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface SMCSAdLoadInterstitial : SMCSAdLoadBase


@end

NS_ASSUME_NONNULL_END
