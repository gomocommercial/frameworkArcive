//
//  PIKCSAdNetworkTool.h
//  PIKCSAdSDK
//
//  Created by  dengnengwei on 2018/7/12.
//

#import <Foundation/Foundation.h>
#import "PIKCSAdDataModel.h"
#import "PIKCSAdTypedef.h"
#import "PIKCSNewStoreLiteRequestTool.h"
#import "NSString+PIKCSGenerateHash.h"

@interface PIKCSAdNetworkTool : NSObject

+ (PIKCSAdNetworkTool *)shared;
@property(nonatomic, copy) PIKCSAdRequestCompleteBlock csAdRequestCompleteBlock;
@property(nonatomic, assign) NSTimeInterval lastGetServerTime;
- (void)pIKrequestAdWithPhead:(NSDictionary *)phead moduleId:(NSString *)moduleId pkgnames:(NSString *)pkgnames filterpkgnames:(NSString *)filterpkgnames tags:(NSString *)tags complete:(PIKCSAdRequestCompleteBlock)complete;

- (void)pIKsetCDay:(void(^ _Nullable)(bool success))handle;
@end
