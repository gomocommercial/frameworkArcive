//
//  SLCSAdDefine.h
//  AdDemo
//
//  Created by Zy on 2019/3/14.
//  Copyright © 2019 Zy. All rights reserved.
//


#define sLkAdvDataSourceFacebook   2 //FB 广告数据源
#define sLkAdvDataSourceAdmob      8 //Admob 广告数据源
#define sLkAdvDataSourceMopub      39//Mopub 广告数据源
#define sLkAdvDataSourceApplovin   20//applovin 广告数据源

#define sLkAdvDataSourceGDT        62//广点通 广告数据源
#define sLkAdvDataSourceBaidu      63//百度 广告数据源
#define sLkAdvDataSourceBU         64//头条 广告数据源
#define sLkAdvDataSourceABU         70//头条聚合 广告数据源
#define sLkAdvDataSourceBUGlobal   73//海外头条 广告数据源
#define sLkAdvDataSourcePangle     74//pangle 广告数据源

#define sLkOnlineAdvTypeBanner                   1  //banner
#define sLkOnlineAdvTypeInterstitial             2  //全屏
#define sLkOnlineAdvTypeNative                   3 //native
#define sLkOnlineAdvTypeVideo                    4 //视频
#define sLkOnlineAdvTypeMinBanner                5 //banner(300*250未使用）
#define sLkOnlineAdvTypeInterstitialVideo        7 //插屏视频
#define sLkOnlineAdvTypeOpen                     8 //开屏
#define sLkOnlineAdvTypeBUNativeExpress                     10 //穿山甲模板信息流
#define sLkOnlineAdvTypeRewardInterstitial       14 // admob插页式激励广告

#define sLkAdServerConfigError  -1 //服务器返回数据不正确
#define sLkAdLoadConfigFailed  -2 //广告加载失败


#define sLAdLog(fmt, ...) NSLog((@"GM_AD_LOG: " fmt), ##__VA_ARGS__);

#define sLkCSAdInstallDays @"sLkCSAdInstallDays"
#define sLkCSAdModule_key @"sLkCSAdModule_key_%@"
#define sLkCSNewAdModule_key @"sLkCSNewAdModule_key_%@"
#define sLkCSAdInstallTime @"sLkCSAdInstallTime"
#define sLkCSAdInstallHours @"sLkCSAdInstallHours"
#define sLkCSAdLastGetServerTime @"sLkCSAdLastRequestTime"
#define sLkCSAdloadTime 30

#define sLkCSLoadAdTimeOutNotification @"sLKCSLoadAdTimeOutNotification"
#define sLkCSLoadAdTimeOutNotificationKey @"sLKCSLoadAdTimeOutKey"

