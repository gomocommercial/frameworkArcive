//
//  CSDAHUDTool.h
//  CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSDAHUDTool : NSObject

/* loading的提示 */
+ (void)showLoadingView:(UIView *_Nullable)view;
+ (void)hideLoadingView:(UIView *_Nullable)view;

+ (void)showLoadingViewWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable)view;

/* 文字提示的toast */
+ (void)showHUDWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable) view;
+ (void)showHUDWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable) view afterDelay:(CGFloat)delayTime;

/* 底部显示的toast */
+ (void)showBottomHUDWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable)view;
+ (void)showBottomHUDWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable)view afterDelay:(CGFloat)delayTime;

@end

NS_ASSUME_NONNULL_END
