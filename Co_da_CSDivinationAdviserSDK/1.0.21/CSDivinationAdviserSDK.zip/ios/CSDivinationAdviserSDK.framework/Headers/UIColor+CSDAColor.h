//
//  UIColor+CSDAColor.h
//  CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (CSDAColor)

@property (nonatomic, assign, readonly) CGFloat red;
@property (nonatomic, assign, readonly) CGFloat green;
@property (nonatomic, assign, readonly) CGFloat blue;
@property (nonatomic, assign, readonly) CGFloat alpha;


+ (UIColor *)CSDAColorWithHexString:(NSString *)colorStr;

+ (UIColor *)CSDAColorWithHexString:(NSString *)color alpha:(CGFloat)alpha;

+ (UIColor *)interpolationColorFrom:(UIColor *)fromColor to:(UIColor *)toColor percent:(CGFloat)percent;
//生成渐变色的图片
+(UIImage*) captureView:(UIView *)captureView rect:(CGRect)viewRect startColor:(UIColor *)startColor endColor:(UIColor *)endColor;
@end

NS_ASSUME_NONNULL_END
