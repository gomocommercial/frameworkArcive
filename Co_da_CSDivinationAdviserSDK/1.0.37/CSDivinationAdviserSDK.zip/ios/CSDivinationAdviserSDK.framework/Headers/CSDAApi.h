//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CSDAPaymentAndPicProtocol.h"
@class CSDAInitParams;
@class CSDATeacherModel;
@class CSDATeacherTypeModel;
@class CSDAUserInfoModel;

extern NSString *const CO_DA_START_VOICE_VIDEO_CHAT_NOTIFICATION;
extern NSString *const CO_DA_CLOSE_VOICE_VIDEO_CHAT_NOTIFICATION;

NS_ASSUME_NONNULL_BEGIN

@interface CSDAApi : NSObject

/*********************************SDK初始化及配置*****************************************/
/**
* 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
* 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
* 推荐debug包，默认打开log配置，方便排查问题。
* @param params 初始化参数，appId,baseUrl,desKey,apiKey,signatureKey,funid必填，其它选填。
*/
+ (void)setup:(CSDAInitParams *)params delegate:(id<CSDAPaymentAndPicProtocol>)delegate;

// 初始化
+ (instancetype)apiConfig;

@property (nonatomic,strong,readonly) NSString * _Nullable userId;
@property (nonatomic,strong,readonly) NSURL * _Nullable avatorUrl;
@property (nonatomic,strong,readonly) NSString * _Nullable nickName;
@property (nonatomic,strong,readonly) NSString * _Nullable accessToken;
@property (nonatomic,strong,readonly) NSString * _Nullable userTopic; //token
@property (nonatomic,assign,readonly) float balance;//余额
@property (nonatomic,assign,readonly) NSString *sdkVersion;//sdk版本
// 客户端告诉占卜sdk用户身份，可以随时赋值，是否是买量用户
@property (nonatomic, assign) BOOL isAdvancedUser;
/**
* 客户端告诉占卜sdk用户token是否需要验证，默认是校验的
*/
@property (nonatomic, assign) BOOL isNotNeedCheckToken;
+ (BOOL)isLogin;

#pragma mark - 设置数据
- (void)setUpClientUserModel:(CSDAUserInfoModel *)userInfoModel;

#pragma mark - 获取数据
// 获取老师分类列表
- (void)getAdvisorTypeArrWithCompletion:(void (^ _Nullable )(NSError * _Nullable error,NSArray <CSDATeacherTypeModel *>* _Nullable teacherTypeArr))completion;

// 获取老师推荐列表
- (void)getMainAdvisorsWithCompletion:(void (^ _Nullable )(NSError * _Nullable error,NSArray <CSDATeacherModel *>* _Nullable teacherModelArr))completion;

//充值上账支持订阅充值/内购充值,上账成功后会自动刷新UI(对于订阅充值tranId为苹果订单号,内购为预订单单号)
//重复上账或订单过期或上账类型错误返回成功403/407/406
- (void)rechargeWithProductId:(NSString *)productId tran_id:(NSString *)tran_id receipt:(NSString *)receipt Completion:(void (^ _Nullable )(NSError * _Nullable error,float blance))completion;

// 获取商品配置
- (void)getProductIdArrWithComplete:(void(^ _Nullable)(NSError * _Nullable error,NSArray <NSString *>* _Nullable productIdArr))complete;

// 游客账号自动登录，这个方法可以调用的前提是账号登录在占卜sdk内部实现
// 不在客户端实现，而且客户端在初始化的时候有传入loginId
+ (void)autoLoginVisitorWithComplete:(void(^ _Nullable)(NSError * _Nullable error))complete;

// 成功error传nil
- (void)checkPayReceiptWithError:(NSError * _Nullable)error productId:(NSString *)productId;


#pragma mark - 展示控制器
/**
 跳转到老师详情页面
 @param entranceStr 客户端入口（选传，统计用，客户端自己定义）
 @param teacherModel 老师模型(必传)
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)canShowAdvisorDetailControllerWithFromEntranceStr:(NSString *)entranceStr teacherModel:(CSDATeacherModel *)teacherModel fromVc:(UINavigationController *)navController;

/**
 跳转到订单记录页面
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)canShowRechargeRecordControllerWithNavController:(UINavigationController *)navController;


/**
 跳转到充值界面
 @param positionStr 从 1:个人中心；2:个人详情页来
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)canShowRechargeControllerWithPositionStr:(NSString *)positionStr NavController:(UINavigationController *)navController;


/**
 跳转到倾诉界面
 @param teacherModel  老师模型
 @param navController 导航控制器
 @param entranceStr   客户端入口（选传，统计用，客户端自己定义）
 @return 判断是否有登录
*/
+(BOOL)canShowConsultControllerWithTeacherModel:(CSDATeacherModel *)teacherModel fromEntranceStr:(NSString *)entranceStr  NavController:(UINavigationController *)navController;


/**
 跳转到倾诉界面给pro报告页使用
 @param teacherModel  老师模型
 @param isSamePro  是否是同一个pro报告
 @param hasCheckProReport 之前是否有展示过pro弹窗
 @param checkReportBlock  给客户端的pro报告点击事件的回调
 @param checkReportShowBlock  给客户端的pro报告弹窗展示的回调
 @param navController 导航控制器
 @param entranceStr   客户端入口（选传，统计用，客户端自己定义）
 @return 判断是否有登录
*/
+(BOOL)canShowConsultControllerWithTeacherModel:(CSDATeacherModel *)teacherModel fromEntranceStr:(NSString *)entranceStr isSamePro:(BOOL)isSamePro
    hasCheckProReport:(BOOL)hasCheckProReport checkReport:(void(^)(CSDATeacherModel *teacherModel))checkReportBlock checkReportShowBlock:(void(^)(void))checkReportShowBlock NavController:(UINavigationController *)navController;


/**
 跳转到倾诉界面给变老报告页使用
 @param teacherModel  老师模型
 @param navController 导航控制器
 @param entranceStr   客户端入口（选传，统计用，客户端自己定义）
 @return 判断是否有登录
*/
+(BOOL)canShowConsultControllerForAgeReportWithTeacherModel:(CSDATeacherModel *)teacherModel fromEntranceStr:(NSString *)entranceStr NavController:(UINavigationController *)navController;


/**
 推送跳转到倾诉界面
 @param consultId  推送过来的倾诉id
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)canShowConsultControllerWithConsultId:(NSInteger)consultId NavController:(UINavigationController *)navController;

/**
 获取当前老师倾诉列表以及订单控制器
 @return 控制器
*/
+ (UIViewController *)getAdvisorAndOrderController;


/**
 用户是否曾经进入过咨询对话页
 @return 控制器
*/
+ (BOOL)userHasEnterConsultVc;

@end
NS_ASSUME_NONNULL_END
