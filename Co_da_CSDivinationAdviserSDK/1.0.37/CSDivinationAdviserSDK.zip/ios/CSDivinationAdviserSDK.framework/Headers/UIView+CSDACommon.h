//
//  UIView+CSDACommon.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>
@class CSDALoadingView;

NS_ASSUME_NONNULL_BEGIN

@interface UIView (CSDACommon)

- (UIViewController *)currentController;

- (void)addClickBlock:(void (^)(NSInteger tag))block;

- (void)hideLoading;
- (void)showLoading;

@end

NS_ASSUME_NONNULL_END
