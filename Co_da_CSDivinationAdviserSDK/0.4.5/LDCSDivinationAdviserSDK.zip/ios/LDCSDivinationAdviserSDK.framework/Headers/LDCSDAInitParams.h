//
//  LDCSDAInitParams.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LDCSDAInitParams : NSObject

/**
 * 应用AppId(请在Apple store connect 后台查看)，必传。
 */
@property (strong, nonatomic) NSString *appId;

/**
 * 网络请求链接baseUrl，必传。
 */
@property (strong, nonatomic) NSString *baseUrl;

/**
 * 加密解密desKey，必传。
 */
@property (strong, nonatomic) NSString *desKey;

/**
 * apiKey，必传。
 */
@property (strong, nonatomic) NSString *apiKey;

/**
 * 签名key，必传。
 */
@property (strong, nonatomic) NSString *signatureKey;


/**
 * 用于生成用户账号的loginId，由客户端维护，必传。
 */
@property (strong, nonatomic) NSString *loginId;

/**
 * 用于统计用的产品id，19协议的业务id，必传。
 */
@property (strong, nonatomic) NSString *funId;

/**
 * 设置是否输出日志。默认NO，不输出。
 */
@property (assign, nonatomic) BOOL enableLog;

/**
 * 设置是否开启订阅充值。默认NO，不开启。
 */
@property (assign, nonatomic) BOOL subcribeRecharge;


/**
 * 设置是否开启订阅价格控制。默认YES，开启。
 * 控制下发的订阅金额大于咨询价格
 */
@property (assign, nonatomic) BOOL subcribePriceControl;

- (BOOL)lDcheckValid;

@end

NS_ASSUME_NONNULL_END
