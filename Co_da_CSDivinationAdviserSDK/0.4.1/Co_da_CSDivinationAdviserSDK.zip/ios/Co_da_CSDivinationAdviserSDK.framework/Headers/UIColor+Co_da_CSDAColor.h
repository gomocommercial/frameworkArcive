//
//  UIColor+Co_da_CSDAColor.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (Co_da_CSDAColor)

@property (nonatomic, assign, readonly) CGFloat co_da_red;
@property (nonatomic, assign, readonly) CGFloat co_da_green;
@property (nonatomic, assign, readonly) CGFloat co_da_blue;
@property (nonatomic, assign, readonly) CGFloat co_da_alpha;


+ (UIColor *)co_da_CSDAColorWithHexString:(NSString *)colorStr;

+ (UIColor *)co_da_CSDAColorWithHexString:(NSString *)color alpha:(CGFloat)alpha;

+ (UIColor *)co_da_interpolationColorFrom:(UIColor *)fromColor to:(UIColor *)toColor percent:(CGFloat)percent;
//生成渐变色的图片
+(UIImage*) captureView:(UIView *)captureView rect:(CGRect)viewRect startColor:(UIColor *)startColor endColor:(UIColor *)endColor;
@end

NS_ASSUME_NONNULL_END
