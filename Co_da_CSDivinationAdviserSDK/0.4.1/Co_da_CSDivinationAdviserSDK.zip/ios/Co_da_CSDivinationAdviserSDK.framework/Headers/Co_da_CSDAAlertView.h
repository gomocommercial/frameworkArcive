//
//  Co_da_CSDAAlertView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, Co_da_AlertViewButtonType) {
    Co_da_AlertViewButtonTypeDefault,
    Co_da_AlertViewButtonTypeBold,
};

typedef void (^Co_da_TouchUpInsideBlock)(void);

@interface Co_da_CSDAAlertView : UIView

- (instancetype)initWithTitle:(NSString *)title message:(NSObject *)message;

- (void)addButton:(NSString *)title type:(Co_da_AlertViewButtonType)type actionBlock:(Co_da_TouchUpInsideBlock)block;

- (void)show;

@end

NS_ASSUME_NONNULL_END
