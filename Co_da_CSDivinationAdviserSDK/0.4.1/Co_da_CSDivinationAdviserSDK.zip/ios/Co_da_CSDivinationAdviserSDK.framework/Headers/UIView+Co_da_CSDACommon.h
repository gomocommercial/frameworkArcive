//
//  UIView+Co_da_CSDACommon.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>
@class Co_da_CSDALoadingView;

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Co_da_CSDACommon)

- (UIViewController *)co_da_currentController;

- (void)co_da_addClickBlock:(void (^)(NSInteger tag))block;

- (void)co_da_hideLoading;
- (void)co_da_showLoading;

@end

NS_ASSUME_NONNULL_END
