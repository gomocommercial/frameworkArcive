//
//  UIView+Co_da_CSDAErrorView.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Co_da_CSDAErrorView)

-(void)co_da_showNetworkErrorViewNeedLoading:(BOOL)needLoading WithRefreshBlock:(void(^)(void))needRefreshBlock;
-(void)co_da_showNoContentViewWithMsg:(NSString *)errorMsg NeedLoading:(BOOL)needLoading refreshBlock:(void(^)(void))needRefreshBlock;
- (void)co_da_hideNetworkErrorViewOrNoContentView;

@end

NS_ASSUME_NONNULL_END
