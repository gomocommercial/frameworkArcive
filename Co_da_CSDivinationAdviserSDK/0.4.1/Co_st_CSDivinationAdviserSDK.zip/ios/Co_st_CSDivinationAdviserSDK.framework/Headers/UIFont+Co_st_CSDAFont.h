//
//  UIFont+Co_st_CSDAFont.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIFont (Co_st_CSDAFont)

+ (UIFont *)co_st_sfProBoldWithSize:(CGFloat)size;

+ (UIFont *)co_st_sfProLightWithSize:(CGFloat)size;

+ (UIFont *)co_st_sfProLightItalicWithSize:(CGFloat)size;

+ (UIFont *)co_st_sfProMediumWithSize:(CGFloat)size;

+ (UIFont *)co_st_sfProRegularWithSize:(CGFloat)size;

+ (UIFont *)co_st_sfProSemiboldWithSize:(CGFloat)size;

+ (UIFont *)co_st_halatSemiBoldWithSize:(CGFloat)size;

+ (UIFont *)co_st_halatBoldWithSize:(CGFloat)size;

+ (UIFont *)co_st_halatMediumWithSize:(CGFloat)size;

+ (UIFont *)co_st_sfProHeavyWithSize:(CGFloat)size;

+ (UIFont *)co_st_sfCompactBoldFont:(CGFloat)size;

+ (UIFont *)co_st_sfCompactDisplayFont:(CGFloat)size;

+ (UIFont *)co_st_sfCompactSemiBoldFont:(CGFloat)size;
 
@end

NS_ASSUME_NONNULL_END
