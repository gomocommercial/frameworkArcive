//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Co_st_CSDAPaymentAndPicProtocol.h"
@class Co_st_CSDAInitParams;
@class Co_st_CSDATeacherModel;
@class Co_st_CSDATeacherTypeModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAApi : NSObject

/*********************************SDK初始化及配置*****************************************/
/**
* 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
* 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
* 推荐debug包，默认打开log配置，方便排查问题。
* @param params 初始化参数，appId,baseUrl,desKey,apiKey,signatureKey必填，其它选填。
*/
+ (void)co_st_setup:(Co_st_CSDAInitParams *)params delegate:(id<Co_st_CSDAPaymentAndPicProtocol>)delegate;

// 初始化
+ (instancetype)co_st_apiConfig;

@property (nonatomic,strong,readonly) NSString *co_st_userId;
@property (nonatomic,strong,readonly) NSURL *co_st_avatorUrl;
@property (nonatomic,strong,readonly) NSString *co_st_nickName;
@property (nonatomic,strong,readonly) NSString *co_st_accessToken;
@property (nonatomic,strong,readonly) NSString *co_st_userTopic; //token
@property (nonatomic,assign,readonly) float co_st_balance;//余额

+ (BOOL)isLogin;

#pragma mark - 获取数据
// 获取老师分类列表
- (void)co_st_getAdvisorTypeArrWithCompletion:(void (^)(NSError *error,NSArray <Co_st_CSDATeacherTypeModel *>*teacherTypeArr))completion;

// 获取老师推荐列表
- (void)co_st_getMainAdvisorsWithCompletion:(void (^)(NSError *error,NSArray <Co_st_CSDATeacherModel *>*teacherModelArr))completion;

//充值上账支持订阅充值/内购充值,上账成功后会自动刷新UI(对于订阅充值tranId为苹果订单号,内购为预订单单号,        //重复上账或订单过期或上账类型错误返回成功403/407/406)
- (void)co_st_rechargeWithProductId:(NSString *)productId tran_id:(NSString *)tran_id receipt:(NSString *)receipt Completion:(void (^)(NSError *error,float blance))completion;

// 获取商品配置
- (void)co_st_getProductIdArrWithComplete:(void(^ _Nullable)(NSError * _Nullable error,NSArray <NSString *>*productIdArr))complete;

// 游客账号自动登录
+ (void)co_st_autoLoginVisitorWithComplete:(void(^ _Nullable)(NSError * _Nullable error))complete;

// 验单失败
- (void)co_st_checkPayReceiptFail:(NSError *)error;

// 滑动到老师指定分类列表
- (void)co_st_scrollViewToTeacherTypeWithTypeId:(NSInteger)typeId;

#pragma mark - 展示控制器
/**
 跳转到老师详情页面
 @param positionStr 1：首页；2：咨询对话框；3：报告页；4：其他页面返回展示(统计用，必传)
 @param teacherModel 老师模型(必传)
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)co_st_canShowAdvisorDetailControllerWithPositionStr:(NSString *)positionStr teacherModel:(Co_st_CSDATeacherModel *)teacherModel fromVc:(UINavigationController *)navController;

/**
 跳转到订单记录页面
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)co_st_canShowRechargeRecordControllerWithNavController:(UINavigationController *)navController;


/**
 跳转到充值界面
 @param positionStr 从 1:个人中心；2:个人详情页 来
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)co_st_canShowRechargeControllerWithPositionStr:(NSString *)positionStr NavController:(UINavigationController *)navController;


/**
 跳转到咨询界面
 @param teacherModel  老师模型
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)co_st_canShowConsultControllerWithTeacherModel:(Co_st_CSDATeacherModel *)teacherModel NavController:(UINavigationController *)navController;


/**
 推送跳转到咨询界面
 @param consultId  推送过来的咨询id
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)co_st_canShowConsultControllerWithConsultId:(NSInteger)consultId NavController:(UINavigationController *)navController;

/**
 获取当前老师咨询列表以及订单控制器
 @return 控制器
*/
+ (UIViewController *)co_st_getAdvisorAndOrderController;


@end
NS_ASSUME_NONNULL_END
