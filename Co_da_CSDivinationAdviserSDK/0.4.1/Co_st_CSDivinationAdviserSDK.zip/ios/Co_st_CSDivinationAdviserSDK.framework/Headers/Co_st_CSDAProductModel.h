//
//  Co_st_CSDAProductModel.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAProductModel : NSObject
// string    商品编码
@property (nonatomic,strong) NSString *product_code;
// bigDecimal    支付价格（单位：美元）
@property (nonatomic,assign) float price;
// int    商品类型 1.内购 2.订阅
@property (nonatomic,assign) NSInteger product_type;
// int    充值类型 1.充值余额 2.免费咨询
@property (nonatomic,assign) NSInteger recharge_type;
// bigDecimal    充值金额
@property (nonatomic,assign) float price_real;
// int    节省百分比，如：30：即表示节省30%
@property (nonatomic,assign) NSInteger save;

@end

NS_ASSUME_NONNULL_END


