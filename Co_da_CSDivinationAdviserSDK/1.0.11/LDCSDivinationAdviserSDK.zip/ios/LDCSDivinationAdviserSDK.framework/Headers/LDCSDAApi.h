//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LDCSDAPaymentAndPicProtocol.h"
@class LDCSDAInitParams;
@class LDCSDATeacherModel;
@class LDCSDATeacherTypeModel;

NS_ASSUME_NONNULL_BEGIN

@interface LDCSDAApi : NSObject

/*********************************SDK初始化及配置*****************************************/
/**
* 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
* 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
* 推荐debug包，默认打开log配置，方便排查问题。
* @param params 初始化参数，appId,baseUrl,desKey,apiKey,signatureKey,funid必填，其它选填。
*/
+ (void)lDsetup:(LDCSDAInitParams *)params delegate:(id<LDCSDAPaymentAndPicProtocol>)delegate;

// 初始化
+ (instancetype)lDapiConfig;

@property (nonatomic,strong,readonly) NSString * _Nullable lDuserId;
@property (nonatomic,strong,readonly) NSURL * _Nullable lDavatorUrl;
@property (nonatomic,strong,readonly) NSString * _Nullable lDnickName;
@property (nonatomic,strong,readonly) NSString * _Nullable lDaccessToken;
@property (nonatomic,strong,readonly) NSString * _Nullable lDuserTopic; //token
@property (nonatomic,assign,readonly) float lDbalance;//余额
@property (nonatomic,assign,readonly) NSString *sdkVersion;//sdk版本
// 客户端告诉占卜sdk用户身份，可以随时赋值
@property (nonatomic, assign) BOOL isAdvancedUser;
+ (BOOL)isLogin;

#pragma mark - 获取数据
// 获取老师分类列表
- (void)lDgetAdvisorTypeArrWithCompletion:(void (^ _Nullable )(NSError * _Nullable error,NSArray <LDCSDATeacherTypeModel *>* _Nullable teacherTypeArr))completion;

// 获取老师推荐列表
- (void)lDgetMainAdvisorsWithCompletion:(void (^ _Nullable )(NSError * _Nullable error,NSArray <LDCSDATeacherModel *>* _Nullable teacherModelArr))completion;

//充值上账支持订阅充值/内购充值,上账成功后会自动刷新UI(对于订阅充值tranId为苹果订单号,内购为预订单单号)
//重复上账或订单过期或上账类型错误返回成功403/407/406
- (void)lDrechargeWithProductId:(NSString *)productId tran_id:(NSString *)tran_id receipt:(NSString *)receipt Completion:(void (^ _Nullable )(NSError * _Nullable error,float blance))completion;

// 获取商品配置
- (void)lDgetProductIdArrWithComplete:(void(^ _Nullable)(NSError * _Nullable error,NSArray <NSString *>* _Nullable productIdArr))complete;

// 游客账号自动登录
+ (void)lDautoLoginVisitorWithComplete:(void(^ _Nullable)(NSError * _Nullable error))complete;

// 成功error传nil
- (void)lDcheckPayReceiptWithError:(NSError * _Nullable)error productId:(NSString *)productId;

// 滑动到老师指定分类列表
- (void)lDscrollViewToTeacherTypeWithTypeId:(NSInteger)typeId;

#pragma mark - 展示控制器
/**
 跳转到老师详情页面
 @param entranceStr 客户端入口（选传，统计用，客户端自己定义）
 @param teacherModel 老师模型(必传)
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)lDcanShowAdvisorDetailControllerWithFromEntranceStr:(NSString *)entranceStr teacherModel:(LDCSDATeacherModel *)teacherModel fromVc:(UINavigationController *)navController;

/**
 跳转到订单记录页面
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)lDcanShowRechargeRecordControllerWithNavController:(UINavigationController *)navController;


/**
 跳转到充值界面
 @param positionStr 从 1:个人中心；2:个人详情页来
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)lDcanShowRechargeControllerWithPositionStr:(NSString *)positionStr NavController:(UINavigationController *)navController;


/**
 跳转到倾诉界面
 @param teacherModel  老师模型
 @param navController 导航控制器
 @param entranceStr   客户端入口（选传，统计用，客户端自己定义）
 @return 判断是否有登录
*/
+(BOOL)lDcanShowConsultControllerWithTeacherModel:(LDCSDATeacherModel *)teacherModel fromEntranceStr:(NSString *)entranceStr  NavController:(UINavigationController *)navController;


/**
 推送跳转到倾诉界面
 @param consultId  推送过来的倾诉id
 @param navController 导航控制器
 @return 判断是否有登录
*/
+(BOOL)lDcanShowConsultControllerWithConsultId:(NSInteger)consultId NavController:(UINavigationController *)navController;

/**
 获取当前老师倾诉列表以及订单控制器
 @return 控制器
*/
+ (UIViewController *)lDgetAdvisorAndOrderController;


@end
NS_ASSUME_NONNULL_END
