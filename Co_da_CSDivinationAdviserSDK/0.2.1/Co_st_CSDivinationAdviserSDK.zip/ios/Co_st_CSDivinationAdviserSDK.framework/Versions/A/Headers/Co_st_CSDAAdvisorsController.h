//
//  Co_st_CSDAAdvisorsController.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import "Co_st_CSDABaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAAdvisorsController : Co_st_CSDABaseViewController

@end

NS_ASSUME_NONNULL_END
