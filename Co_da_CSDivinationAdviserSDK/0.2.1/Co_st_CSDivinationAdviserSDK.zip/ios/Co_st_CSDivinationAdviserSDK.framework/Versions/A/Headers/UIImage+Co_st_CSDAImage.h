//
//  UIImage+Co_st_CSDAImage.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (Co_st_CSDAImage)

+ (UIImage *)co_st_daImageWithName:(NSString *)name;

+ (UIImage *)co_st_horizontalGradientStartColor:(UIColor *)startColor endColor:(UIColor *)endColor size:(CGSize)size;

+ (UIImage *)co_st_verticalGradientStartColor:(UIColor *)startColor endColor:(UIColor *)endColor size:(CGSize)size;

// 压缩图片到指定大小(单位KB)
+ (NSData *)co_st_resetSizeOfImageData:(UIImage *)sourceImage maxSize:(NSInteger)maxSize;

/**
 *  用color生成image
 *
 *  @param color 颜色
 */
+ (UIImage *)co_st_imageWithColor:(UIColor *)color;

+ (UIImage *)co_st_imageWithColor:(UIColor *)color size:(CGSize)size;

/**
*   按大小缩放
*/
- (UIImage *)co_st_imageScaledToSize:(CGSize)size;

/**
*   最小缩放
*/
- (UIImage *)co_st_imageScaledToFitSize:(CGSize)size;

/**
*   最大缩放
*/
- (UIImage *)co_st_imageScaledToFillSize:(CGSize)size;


@end

NS_ASSUME_NONNULL_END
