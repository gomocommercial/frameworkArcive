//
//  Co_st_CSDADeviceInfoTool.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDADeviceInfoTool : NSObject

+ (NSString *)co_st_accountId;

+ (NSString *)co_st_aid;

+ (NSString *)co_st_country;

+ (NSString *)co_st_language;

+ (NSString *)co_st_versionCode;

+ (NSString *)co_st_versionName;

+ (NSNumber *)co_st_channel;

+ (NSString *)co_st_bundleid;

+ (NSString *)co_st_systemVersion;

+ (NSString *)co_st_getPhoneModel;

+ (BOOL)co_st_isDebugMode;


@end

NS_ASSUME_NONNULL_END
