//
//  Co_st_CSDAConsultController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import "Co_st_CSDABaseViewController.h"
@class Co_st_CSDATeacherModel;
@class Co_st_CSDAOrderListModel;
@class Co_st_CSDAConsultModel;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_st_ConsultFromType) {
    Co_st_ConsultFromType_Submit,
    Co_st_ConsultFromType_Order,
    Co_st_ConsultFromType_Remote,
    Co_st_ConsultFromType_More
};


@interface Co_st_CSDAConsultController : Co_st_CSDABaseViewController

@property (nonatomic,assign) Co_st_ConsultFromType fromType;

// 从订单列表那边过来
@property (nonatomic,strong) Co_st_CSDAOrderListModel *orderModel;
// 从上传咨询订单中过来
@property (nonatomic,strong) Co_st_CSDAConsultModel *consultModel;
// 从通知过来
@property (nonatomic,assign) NSInteger consult_id;

//提交、咨询订单
@property (nonatomic,strong) Co_st_CSDATeacherModel *teacherModel;

//订单钱数
@property (nonatomic,assign) float priceAmount;

@end

NS_ASSUME_NONNULL_END
