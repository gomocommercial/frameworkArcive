//
//  Co_st_CSDADefines.h
//  Pods
//
//  Created by Zy on 2019/9/18.
//

#import "NSString+Co_st_CSDAString.h"
#import "UIImage+Co_st_CSDAImage.h"
#import "Co_st_CSDAConfig.h"


#ifndef Co_st_CSDADefines_h
#define Co_st_CSDADefines_h

#define Co_st_CSDAString(key) [NSString co_st_localizedStringForKey:(key)]
#define Co_st_CSDAImage(name) [UIImage co_st_daImageWithName:(name)]
#define Co_st_CSDAIsSmallScreen ([UIScreen mainScreen].bounds.size.width < 375)

#define Co_st_CSDAColorHex(str) [UIColor co_st_CSDAColorWithHexString:str]
#define Co_st_CSDAColorHexWithAlpha(color, a) [UIColor co_st_CSDAColorWithHexString:color alpha:a]

#define Co_st_CSDA_SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define Co_st_CSDA_SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define Co_st_CSDA_dp(x) (Co_st_CSDAIsSmallScreen ?  (x) / 375.0f * Co_st_CSDA_SCREEN_WIDTH : x)
#define Co_st_CSDA_px(x) (Co_st_CSDAIsSmallScreen ?  (x) / 375.0f * Co_st_CSDA_SCREEN_WIDTH / 2 : x / 2)
#define Co_st_CSDA_WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

//判断是否为iPad
#define Co_st_CSDA_IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define Co_st_CSDA_IsiPhoneXAll ([UIScreen mainScreen].bounds.size.height >= 812.0f && !(Co_st_CSDA_IS_IPAD))

#define Co_st_CSDABarAndNavBarHeight ((Co_st_CSDA_IsiPhoneXAll)? (44 + 44): (20 + 44))
#define Co_st_CSDASafeBottomHeight ((Co_st_CSDA_IsiPhoneXAll)? (34): (0))
#define Co_st_CSDAStatusBarHeight ((Co_st_CSDA_IsiPhoneXAll)? (44): (22))

#define Co_st_RandomColor   [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1.0]

#define Co_st_log(fmt, ...) {\
    if ([Co_st_CSDAConfig co_st_config].isEnableLog) {\
        NSLog((@"[Co_st_CSDivinationAdviserSDK]%s," "[lineNum:%d]" fmt) , __FUNCTION__, __LINE__, ##__VA_ARGS__);\
    } else {}\
}


#endif /* Co_st_CSDADefines_h */
