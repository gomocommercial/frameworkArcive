//
//  Co_st_CSDAConsultDetailCell.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const Co_st_ConsultDetailCell_Normal;
extern NSString *const Co_st_ConsultDetailCell_ChangeHeight;

@interface Co_st_CSDAConsultDetailCell : UITableViewCell

@property (nonatomic,strong) NSString *co_st_TitleStr;
@property (nonatomic,strong) NSString *co_st_ContentStr;
@property (nonatomic,strong) NSString *co_st_BottomStr;
@property (nonatomic,assign) BOOL needHideLine;

@end

NS_ASSUME_NONNULL_END
