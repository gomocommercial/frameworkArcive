//
//  Co_st_CSDAChatHelper.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/24.
//

#import <Foundation/Foundation.h>
@class Co_st_CSDAConsultChatModel;
@class Co_st_CSDAConsultReplyModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAChatHelper : NSObject

//老师招呼语
+ (Co_st_CSDAConsultChatModel *)getAdvisorSalutationChat:(Co_st_CSDAConsultReplyModel *)model;

//老师招呼视频
+ (Co_st_CSDAConsultChatModel *)getAdvisorSalutationVideoChat:(Co_st_CSDAConsultReplyModel *)model;

//热点问题
+ (Co_st_CSDAConsultChatModel *)getHotQuestionsChat;

//补全问题
+ (Co_st_CSDAConsultChatModel *)getFillMessageChat:(Co_st_CSDAConsultReplyModel *)model;

//历史问题
+ (Co_st_CSDAConsultChatModel *)getHistoryQuestionsChat:(Co_st_CSDAConsultReplyModel *)model;

//老师视频回复
+ (Co_st_CSDAConsultChatModel *)getAdivisorVideoChat:(Co_st_CSDAConsultReplyModel *)model;

//老师回复
+ (Co_st_CSDAConsultChatModel *)getAdivisorReplyMessageChat:(Co_st_CSDAConsultReplyModel *)model;

//老师自定义信息回复
+ (Co_st_CSDAConsultChatModel *)getAdivisorMessageChat:(Co_st_CSDAConsultReplyModel *)model Chat:(NSString *)chatStr;

//用户信息回复
+ (Co_st_CSDAConsultChatModel *)getCustomMessageChat:(NSString *)chatStr;

@end

NS_ASSUME_NONNULL_END
