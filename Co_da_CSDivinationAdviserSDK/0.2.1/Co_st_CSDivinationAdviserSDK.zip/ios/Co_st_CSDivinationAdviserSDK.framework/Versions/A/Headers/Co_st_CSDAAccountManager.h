//
//  Co_st_CSDAAccountManager.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/29.
//

#import <Foundation/Foundation.h>
@class Co_st_CSDAUser;
NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAAccountManager : NSObject

+ (instancetype)shareManager;

@property (nonatomic,strong) Co_st_CSDAUser *co_st_user;

// APP启动时自动登录
+ (void)co_st_AutoLoginWhenAppStart;

// 是否已经登录
+ (BOOL)isLogin;

// 是否有足够的余额
+ (BOOL)hasEnoughBalance:(float)balance;

// 更新账户余额
- (void)co_st_updateBalance;

// 更新账户余额
+ (void)refreshBalanceCompletion:(void(^)(float balance,BOOL success))completion;

// APP自动登录
+ (void)autoLoginVisitorWithComplete:(void(^ _Nullable)(NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
