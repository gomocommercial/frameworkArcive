//
//  Co_pay_CSDAOrderListView.h
//  Co_pay_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_pay_CSDAOrderType) {
    Co_pay_CSDAOrderType_Unpaid = 1,
    Co_pay_CSDAOrderType_WaitingReply,
    Co_pay_CSDAOrderType_Finished,
    Co_pay_CSDAOrderType_Refunded,
};

@interface Co_pay_CSDAOrderListView : UIView

@property (nonatomic,assign) Co_pay_CSDAOrderType orderType;

@end

NS_ASSUME_NONNULL_END

