//
//  Co_pay_CSDANavigationBar.h
//  Co_pay_CSDivinationAdviserSDK-Co_pay_CSDA
//
//  Created by 邝路平 on 2019/9/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDANavigationBar : UIView

@property (nonatomic, strong) UIView *co_pay_LeftBarButtonItem;
@property (nonatomic, strong) UIView *co_pay_RightBarButtonItem;
@property (nonatomic, strong) UIView *co_pay_TitleView;

@end

NS_ASSUME_NONNULL_END
