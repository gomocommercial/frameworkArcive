//
//  Co_pay_CSDAProductModel.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAProductModel : NSObject

@property (nonatomic,strong) NSString *product_code;
@property (nonatomic,assign) float price;

@end

NS_ASSUME_NONNULL_END
