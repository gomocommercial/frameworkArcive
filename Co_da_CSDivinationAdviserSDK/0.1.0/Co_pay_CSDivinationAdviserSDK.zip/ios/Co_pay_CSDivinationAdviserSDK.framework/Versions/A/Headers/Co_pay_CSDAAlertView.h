//
//  Co_pay_CSDAAlertView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, Co_pay_AlertViewButtonType) {
    Co_pay_AlertViewButtonTypeDefault,
    Co_pay_AlertViewButtonTypeBold,
};

typedef void (^Co_pay_TouchUpInsideBlock)(void);

@interface Co_pay_CSDAAlertView : UIView

- (instancetype)initWithTitle:(NSString *)title message:(NSObject *)message;

- (void)addButton:(NSString *)title type:(Co_pay_AlertViewButtonType)type actionBlock:(Co_pay_TouchUpInsideBlock)block;

- (void)show;

@end

NS_ASSUME_NONNULL_END
