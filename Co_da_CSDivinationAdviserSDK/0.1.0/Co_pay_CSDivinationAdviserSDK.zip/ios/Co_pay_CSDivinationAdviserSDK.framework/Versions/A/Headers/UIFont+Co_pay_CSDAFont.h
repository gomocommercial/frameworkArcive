//
//  UIFont+Co_pay_CSDAFont.h
//  Co_pay_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIFont (Co_pay_CSDAFont)

+ (UIFont *)co_pay_sfProBoldWithSize:(CGFloat)size;

+ (UIFont *)co_pay_sfProLightWithSize:(CGFloat)size;

+ (UIFont *)co_pay_sfProLightItalicWithSize:(CGFloat)size;

+ (UIFont *)co_pay_sfProMediumWithSize:(CGFloat)size;

+ (UIFont *)co_pay_sfProRegularWithSize:(CGFloat)size;

+ (UIFont *)co_pay_sfProSemiboldWithSize:(CGFloat)size;

+ (UIFont *)co_pay_halatSemiBoldWithSize:(CGFloat)size;

+ (UIFont *)co_pay_halatBoldWithSize:(CGFloat)size;

+ (UIFont *)co_pay_halatMediumWithSize:(CGFloat)size;

+ (UIFont *)co_pay_sfProHeavyWithSize:(CGFloat)size;

@end

NS_ASSUME_NONNULL_END
