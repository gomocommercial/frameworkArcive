//
//  Co_pay_CSDAConsultCell.h
//  Co_pay_CSDivinationAdviserSDK-Co_pay_CSDA
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
#import "Co_pay_CSDAConsultChatModel.h"
#import "Co_pay_CSDAConsultFillMessageCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAConsultCell : UITableViewCell

@property (nonatomic,strong) Co_pay_CSDAConsultChatModel *chatModel;
@property (nonatomic,copy) void(^highlightActionBlock)(Co_pay_CSDAConsultCell *cell);
@property (nonatomic,copy) void(^startLoadingBlock)(Co_pay_CSDAConsultCell *cell);
@property (nonatomic,copy) void(^failImageActionBlock)(Co_pay_CSDAConsultCell *cell);
@property (nonatomic,copy) void(^avatarActionBlock)(Co_pay_CSDAConsultCell *cell);

@end

NS_ASSUME_NONNULL_END
