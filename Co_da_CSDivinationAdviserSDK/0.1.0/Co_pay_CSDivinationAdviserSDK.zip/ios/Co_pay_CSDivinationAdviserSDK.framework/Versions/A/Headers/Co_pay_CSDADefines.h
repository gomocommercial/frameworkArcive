//
//  Co_pay_CSDADefines.h
//  Pods
//
//  Created by Zy on 2019/9/18.
//

#import "NSString+Co_pay_CSDAString.h"
#import "UIImage+Co_pay_CSDAImage.h"
#import "Co_pay_CSDAConfig.h"


#ifndef Co_pay_CSDADefines_h
#define Co_pay_CSDADefines_h

#define Co_pay_CSDAString(key) [NSString co_pay_localizedStringForKey:(key)]
#define Co_pay_CSDAImage(name) [UIImage co_pay_daImageWithName:(name)]
#define Co_pay_CSDAIsSmallScreen ([UIScreen mainScreen].bounds.size.width < 375)

#define Co_pay_CSDAColorHex(str) [UIColor co_pay_CSDAColorWithHexString:str]
#define Co_pay_CSDAColorHexWithAlpha(color, a) [UIColor co_pay_CSDAColorWithHexString:color alpha:a]

#define Co_pay_CSDA_SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define Co_pay_CSDA_SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define Co_pay_CSDA_dp(x) (Co_pay_CSDAIsSmallScreen ?  (x) / 375.0f * Co_pay_CSDA_SCREEN_WIDTH : x)
#define Co_pay_CSDA_px(x) (Co_pay_CSDAIsSmallScreen ?  (x) / 375.0f * Co_pay_CSDA_SCREEN_WIDTH / 2 : x / 2)
#define Co_pay_CSDA_WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

//判断是否为iPad
#define Co_pay_CSDA_IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define Co_pay_CSDA_IsiPhoneXAll ([UIScreen mainScreen].bounds.size.height >= 812.0f && !(Co_pay_CSDA_IS_IPAD))

#define Co_pay_CSDABarAndNavBarHeight ((Co_pay_CSDA_IsiPhoneXAll)? (44 + 44): (20 + 44))
#define Co_pay_CSDASafeBottomHeight ((Co_pay_CSDA_IsiPhoneXAll)? (34): (0))
#define Co_pay_CSDAStatusBarHeight ((Co_pay_CSDA_IsiPhoneXAll)? (44): (22))

#define Co_pay_RandomColor   [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1.0]

#define Co_pay_log(fmt, ...) {\
    if ([Co_pay_CSDAConfig co_pay_config].isEnableLog) {\
        NSLog((@"[Co_pay_CSDivinationAdviserSDK]%s," "[lineNum:%d]" fmt) , __FUNCTION__, __LINE__, ##__VA_ARGS__);\
    } else {}\
}


#endif /* Co_pay_CSDADefines_h */
