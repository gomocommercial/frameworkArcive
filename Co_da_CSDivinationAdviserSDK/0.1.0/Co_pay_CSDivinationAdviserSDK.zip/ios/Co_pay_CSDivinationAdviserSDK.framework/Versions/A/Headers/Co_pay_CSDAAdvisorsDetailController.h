//
//  Co_pay_CSDAAdvisorsDetailController.h
//  Co_pay_CSDivinationAdviserSDK-Co_pay_CSDA
//
//  Created by 邝路平 on 2019/9/27.
//

#import "Co_pay_CSDABaseViewController.h"
@class Co_pay_CSDATeacherModel;
NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAAdvisorsDetailController : Co_pay_CSDABaseViewController

@property (nonatomic,strong) Co_pay_CSDATeacherModel *teacherModel;

@end

NS_ASSUME_NONNULL_END
