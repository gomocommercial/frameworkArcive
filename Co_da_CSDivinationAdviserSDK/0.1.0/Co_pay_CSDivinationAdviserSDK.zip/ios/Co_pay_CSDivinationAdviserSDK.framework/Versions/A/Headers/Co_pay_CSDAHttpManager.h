//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Co_pay_CSDivinationAdviserSDK/Co_pay_CSDAHeader.h>

typedef void(^co_pay_completeBlock)( NSDictionary * _Nullable result);
typedef void(^co_pay_completeWithErrorBlock)(NSDictionary * _Nullable result, NSError * _Nullable error);

@interface Co_pay_CSDAHttpManager : NSObject

+ (instancetype _Nullable )co_pay_shareManager;


- (void)co_pay_requestDivinationWithMethod:(NSString *)method
                                      url:(NSString *)urlStr
                                   params:(NSDictionary *)params moreQueryDic:(NSDictionary*)moreQueryDic timeoutInterval:(NSTimeInterval)timeoutInterval complete:(co_pay_completeWithErrorBlock)complete;


#pragma mark ---网络变化监听---
/**
 开始网络监听
 */
+ (void)co_pay_startMonitoringNetworkChangeBlock:(void(^ _Nullable)(AFNetworkReachabilityStatus status))block;

/**
 关闭网络监听
 */
+ (void)co_pay_stopMonitoring;

+ (NSString *_Nullable)networkType;

@end
