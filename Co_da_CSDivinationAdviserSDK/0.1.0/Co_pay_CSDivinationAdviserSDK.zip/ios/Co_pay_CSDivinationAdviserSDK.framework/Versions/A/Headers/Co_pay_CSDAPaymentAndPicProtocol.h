//
//  Co_pay_CSDAPaymentAndPicProtocol.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/30.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol Co_pay_CSDAPaymentAndPicProtocol <NSObject>

// 支付
-(void)co_pay_paymentDidPayWithProductId:(NSString *)productId;

// 图片上传
-(void)co_pay_pictureDidUploadWithImage:(UIImage *)image Completion:(void(^)(BOOL isSuccess,NSString *imageUrl))completion;


@end

NS_ASSUME_NONNULL_END
