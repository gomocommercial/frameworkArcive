//
//  Co_pay_CSDASubmitHeaderView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDASubmitHeaderView : UIView

@property (nonatomic,strong) NSString *co_pay_NameStr;
@property (nonatomic,strong) NSString *co_pay_AvatorUrl;


@end

NS_ASSUME_NONNULL_END
