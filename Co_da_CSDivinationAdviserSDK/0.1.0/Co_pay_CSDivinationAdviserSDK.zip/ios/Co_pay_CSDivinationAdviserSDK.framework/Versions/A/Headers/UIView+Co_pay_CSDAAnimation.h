//
//  UIView+Co_pay_CSDAAnimation.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Co_pay_CSDAAnimation)

- (void)co_pay_loadingAnimation;
- (void)co_pay_stopLoadingAnimation;

@end

NS_ASSUME_NONNULL_END
