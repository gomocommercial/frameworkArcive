//
//  Co_pay_CSDABaseViewController.h
//  Co_pay_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>
@class Co_pay_CSDANavigationBar;
NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDABaseViewController : UIViewController

@property (nonatomic, strong, readonly) Co_pay_CSDANavigationBar *co_pay_navigationBar;

- (UIView *)co_pay_createBackgroundImageView;

- (void)co_pay_leftBtnDidClcik;

@end

NS_ASSUME_NONNULL_END
