//
//  Co_pay_CSDABrowserTransitionManager.h
//  Co_pay_CSDivinationAdviserSDK-Co_pay_CSDA
//
//  Created by 邝路平 on 2019/10/27.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Co_pay_CSDABrowserController.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDABrowserTransitionManager : NSObject<UIViewControllerAnimatedTransitioning>

@property (nonatomic,weak) Co_pay_CSDABrowserController *browserVc;


@end

NS_ASSUME_NONNULL_END
