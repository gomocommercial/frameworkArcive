//
//  Co_pay_CSDAAdvisorsCell.h
//  Co_pay_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class Co_pay_CSDATeacherModel;

@interface Co_pay_CSDAAdvisorsCell : UITableViewCell

@property (nonatomic, strong) UIView *lineView;
@property (nonatomic,strong) Co_pay_CSDATeacherModel *teacherModel;
@property (nonatomic,copy) void(^chatBlock)(Co_pay_CSDATeacherModel *teacherModel);

+ (CGFloat)cellHeight;

@end

NS_ASSUME_NONNULL_END
