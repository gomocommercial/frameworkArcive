//
//  Co_pay_CSDAInputItemView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

static NSInteger const Co_pay_InputItemViewWordLimit = 200;

@interface Co_pay_CSDAInputItemView : UIView

@property (nonatomic,strong) NSString *co_pay_TitleStr;
@property (nonatomic,strong) NSString *co_pay_TfPlaceHolderStr;
@property (nonatomic,strong,readonly) UITextField *co_pay_textTf;
@property (nonatomic,assign) BOOL co_pay_NeedWordLimit;

@property (nonatomic,copy) void(^co_pay_TfEndEditingBlock)(NSString *tfStr);

@end

NS_ASSUME_NONNULL_END
