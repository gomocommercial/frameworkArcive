//
//  Co_pay_CSDAConsultController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import "Co_pay_CSDABaseViewController.h"
@class Co_pay_CSDATeacherModel;
@class Co_pay_CSDAOrderListModel;
@class Co_pay_CSDAConsultModel;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_pay_ConsultFromType) {
    Co_pay_ConsultFromType_Submit,
    Co_pay_ConsultFromType_Order,
    Co_pay_ConsultFromType_Remote,
    Co_pay_ConsultFromType_More
};


@interface Co_pay_CSDAConsultController : Co_pay_CSDABaseViewController

@property (nonatomic,assign) Co_pay_ConsultFromType fromType;

// 从订单列表那边过来
@property (nonatomic,strong) Co_pay_CSDAOrderListModel *orderModel;
// 从上传咨询订单中过来
@property (nonatomic,strong) Co_pay_CSDAConsultModel *consultModel;
// 从通知过来
@property (nonatomic,assign) NSInteger consult_id;

//提交、咨询订单
@property (nonatomic,strong) Co_pay_CSDATeacherModel *teacherModel;

@end

NS_ASSUME_NONNULL_END
