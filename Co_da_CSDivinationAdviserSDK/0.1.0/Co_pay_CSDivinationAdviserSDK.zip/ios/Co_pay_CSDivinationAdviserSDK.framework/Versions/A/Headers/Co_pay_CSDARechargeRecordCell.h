//
//  Co_pay_CSDARechargeRecordCell.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/23.
//

#import <UIKit/UIKit.h>

@class Co_pay_CSDAConsumeRecordModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDARechargeRecordCell : UITableViewCell

+ (CGFloat)cellHeight;

@property (nonatomic,strong) Co_pay_CSDAConsumeRecordModel *co_pay_RecordModel;

@end

NS_ASSUME_NONNULL_END
