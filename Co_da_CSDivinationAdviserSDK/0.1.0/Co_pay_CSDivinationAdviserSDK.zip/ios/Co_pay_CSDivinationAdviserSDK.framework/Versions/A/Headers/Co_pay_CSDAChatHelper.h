//
//  Co_pay_CSDAChatHelper.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/24.
//

#import <Foundation/Foundation.h>
@class Co_pay_CSDAConsultChatModel;
@class Co_pay_CSDAConsultReplyModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAChatHelper : NSObject

//老师招呼语
+ (Co_pay_CSDAConsultChatModel *)getAdvisorSalutationChat:(Co_pay_CSDAConsultReplyModel *)model;

//老师招呼视频
+ (Co_pay_CSDAConsultChatModel *)getAdvisorSalutationVideoChat:(Co_pay_CSDAConsultReplyModel *)model;

//热点问题
+ (Co_pay_CSDAConsultChatModel *)getHotQuestionsChat;

//补全问题
+ (Co_pay_CSDAConsultChatModel *)getFillMessageChat:(Co_pay_CSDAConsultReplyModel *)model;

//历史问题
+ (Co_pay_CSDAConsultChatModel *)getHistoryQuestionsChat:(Co_pay_CSDAConsultReplyModel *)model;

//老师视频回复
+ (Co_pay_CSDAConsultChatModel *)getAdivisorVideoChat:(Co_pay_CSDAConsultReplyModel *)model;

//老师回复
+ (Co_pay_CSDAConsultChatModel *)getAdivisorReplyMessageChat:(Co_pay_CSDAConsultReplyModel *)model;

//老师自定义信息回复
+ (Co_pay_CSDAConsultChatModel *)getAdivisorMessageChat:(Co_pay_CSDAConsultReplyModel *)model Chat:(NSString *)chatStr;

//用户信息回复
+ (Co_pay_CSDAConsultChatModel *)getCustomMessageChat:(NSString *)chatStr;

@end

NS_ASSUME_NONNULL_END
