//
//  NSBundle+Co_pay_CSGiftBundle.h
//  Co_pay_CSGiftSDK
//
//  Created by qiaoming on 2019/3/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (Co_pay_CSDABundle)

//返回资源文件的bundle
+(NSBundle *)co_pay_getDABundlePath;

//读取资源文件的多语言文案
+ (NSString *)co_pay_localizedStringForKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
