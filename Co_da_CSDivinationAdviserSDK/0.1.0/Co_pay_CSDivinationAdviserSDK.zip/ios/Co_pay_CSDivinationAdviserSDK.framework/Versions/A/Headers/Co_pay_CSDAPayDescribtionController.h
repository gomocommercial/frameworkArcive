//
//  Co_pay_CSDAPayDescribtionController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/24.
//

#import "Co_pay_CSDABaseViewController.h"
@class Co_pay_CSDATeacherModel;
@class Co_pay_CSDAConsultModel;
@class Co_pay_CSDAOrderListModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAPayDescribtionController : Co_pay_CSDABaseViewController

@property (nonatomic,assign) BOOL isFromOrder;

@property (nonatomic,strong) Co_pay_CSDATeacherModel *teacherModel;
@property (nonatomic,strong) Co_pay_CSDAConsultModel *consultModel;
@property (nonatomic,strong) NSString *order_code;

@property (nonatomic,strong) Co_pay_CSDAOrderListModel *orderModel;



@end

NS_ASSUME_NONNULL_END
