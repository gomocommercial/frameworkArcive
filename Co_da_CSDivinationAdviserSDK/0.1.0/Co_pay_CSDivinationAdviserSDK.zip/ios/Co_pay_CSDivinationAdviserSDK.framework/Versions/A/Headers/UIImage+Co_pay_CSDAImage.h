//
//  UIImage+Co_pay_CSDAImage.h
//  Co_pay_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (Co_pay_CSDAImage)

+ (UIImage *)co_pay_daImageWithName:(NSString *)name;

+ (UIImage *)co_pay_horizontalGradientStartColor:(UIColor *)startColor endColor:(UIColor *)endColor size:(CGSize)size;

+ (UIImage *)co_pay_verticalGradientStartColor:(UIColor *)startColor endColor:(UIColor *)endColor size:(CGSize)size;

// 压缩图片到指定大小(单位KB)
+ (NSData *)co_pay_resetSizeOfImageData:(UIImage *)sourceImage maxSize:(NSInteger)maxSize;

/**
 *  用color生成image
 *
 *  @param color 颜色
 */
+ (UIImage *)co_pay_imageWithColor:(UIColor *)color;

+ (UIImage *)co_pay_imageWithColor:(UIColor *)color size:(CGSize)size;

/**
*   按大小缩放
*/
- (UIImage *)co_pay_imageScaledToSize:(CGSize)size;

/**
*   最小缩放
*/
- (UIImage *)co_pay_imageScaledToFitSize:(CGSize)size;

/**
*   最大缩放
*/
- (UIImage *)co_pay_imageScaledToFillSize:(CGSize)size;


@end

NS_ASSUME_NONNULL_END
