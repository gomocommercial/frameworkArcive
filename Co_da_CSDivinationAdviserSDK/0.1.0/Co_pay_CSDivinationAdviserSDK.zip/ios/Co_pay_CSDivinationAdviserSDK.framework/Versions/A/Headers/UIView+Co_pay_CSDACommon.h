//
//  UIView+Co_pay_CSDACommon.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>
@class Co_pay_CSDALoadingView;

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Co_pay_CSDACommon)

- (UIViewController *)co_pay_currentController;

- (void)co_pay_addClickBlock:(void (^)(NSInteger tag))block;

- (void)co_pay_hideLoading;
- (void)co_pay_showLoading;

@end

NS_ASSUME_NONNULL_END
