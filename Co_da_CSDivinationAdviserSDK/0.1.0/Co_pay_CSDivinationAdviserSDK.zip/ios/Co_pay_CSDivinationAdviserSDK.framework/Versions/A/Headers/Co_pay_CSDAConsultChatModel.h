//
//  Co_pay_CSDAConsultChatModel.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_pay_ConsultChatMsgType) {
    Co_pay_ConsultChatMsgType_Text,
    Co_pay_ConsultChatMsgType_Video,
    Co_pay_ConsultChatMsgType_Image,
    Co_pay_ConsultChatMsgType_Hot,
    Co_pay_ConsultChatMsgType_FillMessage,
    Co_pay_ConsultChatMsgType_History,
    Co_pay_ConsultChatMsgType_CheckInfomation,
    Co_pay_ConsultChatMsgType_CheckBalance,

};

typedef NS_ENUM(NSInteger, Co_pay_ConsultChatSendType) {
    Co_pay_ConsultChatSendType_Sending,
    Co_pay_ConsultChatSendType_Failed,
    Co_pay_ConsultChatSendType_Done
};


extern NSString *const Co_pay_ConsultCell_Mine;
extern NSString *const Co_pay_ConsultCell_Teacher;
extern NSString *const Co_pay_ConsultCell_Mine_Image;
extern NSString *const Co_pay_ConsultCell_Teacher_Image;
extern NSString *const Co_pay_ConsultCell_Hot;
extern NSString *const Co_pay_ConsultCell_FillMessage;

extern BOOL co_pay_messageCanAction;
extern CGFloat const Co_pay_ConsultCellWidthMul;

@interface Co_pay_CSDAConsultChatModel : NSObject

@property (nonatomic,strong) NSString *createTime;
@property (nonatomic,assign) BOOL isFromMine;
@property (nonatomic,strong) NSString *avatorImageUrl;
@property (nonatomic,strong) NSString *contentStr;
@property (nonatomic,strong) NSString *videoUrl;
@property (nonatomic,strong) NSString *imageUrl;
@property (nonatomic,assign) Co_pay_ConsultChatMsgType chatType;
@property (nonatomic,assign) Co_pay_ConsultChatSendType sendType;

@property (nonatomic,strong) NSString *cellIdentifier;

@property (nonatomic,strong) UIImage *coverImage;
@property (nonatomic, strong) NSArray<NSString*> *hotMessages;

@end

NS_ASSUME_NONNULL_END
