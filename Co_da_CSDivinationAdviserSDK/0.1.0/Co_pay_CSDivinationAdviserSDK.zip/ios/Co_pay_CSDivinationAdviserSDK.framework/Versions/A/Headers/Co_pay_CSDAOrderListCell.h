//
//  Co_pay_CSDAOrderListCell.h
//  Co_pay_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class Co_pay_CSDAOrderListModel;

@interface Co_pay_CSDAOrderListCell : UITableViewCell

@property (nonatomic,strong) Co_pay_CSDAOrderListModel *orderListModel;

@property (nonatomic,copy) void(^payBlock)(Co_pay_CSDAOrderListModel *orderListModel);

- (BOOL)canResetModelListWithTimeOffset:(NSInteger)offset;

+ (CGFloat)cellHeight;

+ (NSString *)CountDownTimeWithInterval:(NSInteger)interval;

@end

NS_ASSUME_NONNULL_END
