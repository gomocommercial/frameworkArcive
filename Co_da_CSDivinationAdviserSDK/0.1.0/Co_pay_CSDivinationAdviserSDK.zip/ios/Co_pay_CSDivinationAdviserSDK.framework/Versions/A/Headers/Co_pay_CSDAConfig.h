//
//  Co_pay_CSDAConfig.h
//  Co_pay_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <Foundation/Foundation.h>
#import "Co_pay_CSDAPaymentAndPicProtocol.h"
@class Co_pay_CSDAProductModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAConfig : NSObject

+ (instancetype)co_pay_config;

@property (nonatomic, assign,getter=isEnableLog) BOOL enableLog;
@property (nonatomic, assign,getter=isTestMode) BOOL testMode;


@property (assign, nonatomic, readonly) NSInteger sdkVersionCode;
@property (strong, nonatomic, readonly) NSString *sdkVersionName;
@property (nonatomic,strong) NSArray <Co_pay_CSDAProductModel *>*productIdArr;

@property (nonatomic,weak) id<Co_pay_CSDAPaymentAndPicProtocol>delegate;

@property (nonatomic,copy) void(^rechargeBlock)(NSError * error,float balance);

/**
 * 是否sdk升级用户
 */
@property (assign, nonatomic) BOOL isSdkUpgrade;

/**
 * 应用appId
 */
@property (strong, nonatomic) NSString *appId;

/**
 * 网络请求链接baseUrl
 */
@property (strong, nonatomic) NSString *baseUrl;

/**
 * 加密解密desKey
 */
@property (strong, nonatomic) NSString *desKey;

/**
 * apiKey
 */
@property (strong, nonatomic) NSString *apiKey;

/**
 * 签名key，必传。
 */
@property (strong, nonatomic) NSString *signatureKey;



@end

NS_ASSUME_NONNULL_END
