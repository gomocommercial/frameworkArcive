//
//  Co_pay_CSDAPickerViewController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import "Co_pay_CSDABaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_pay_DatePickerViewType) {
    Co_pay_DatePickerViewTypeDate,
    Co_pay_DatePickerViewTypeGender,
};

@interface Co_pay_CSDAPickerViewController : Co_pay_CSDABaseViewController

@property (nonatomic,assign,readonly) CGFloat contentH;

@property (nonatomic, copy) void(^cancelBlock)(void);

@property (nonatomic, copy) void(^didSelectedBlock)(NSString *dateStr);

- (instancetype)initWithType:(Co_pay_DatePickerViewType)type;

- (void)show;

@end

NS_ASSUME_NONNULL_END
