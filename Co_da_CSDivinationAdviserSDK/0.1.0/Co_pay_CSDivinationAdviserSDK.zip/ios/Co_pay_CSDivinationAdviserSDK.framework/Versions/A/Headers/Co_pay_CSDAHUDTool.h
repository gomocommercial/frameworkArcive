//
//  Co_pay_CSDAHUDTool.h
//  Co_pay_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAHUDTool : NSObject

/* loading的提示 */
+ (void)co_pay_showLoadingView:(UIView *_Nullable)view;
+ (void)co_pay_hideLoadingView:(UIView *_Nullable)view;

+ (void)co_pay_showLoadingViewWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable)view;

/* 文字提示的toast */
+ (void)co_pay_showHUDWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable) view;
+ (void)co_pay_showHUDWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable) view afterDelay:(CGFloat)delayTime;

/* 底部显示的toast */
+ (void)co_pay_showBottomHUDWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable)view;
+ (void)co_pay_showBottomHUDWithMessage:(NSString *_Nullable)message view:(UIView *_Nullable)view afterDelay:(CGFloat)delayTime;

@end

NS_ASSUME_NONNULL_END
