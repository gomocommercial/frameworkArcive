//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Co_pay_CSDAModel : NSObject


@end
