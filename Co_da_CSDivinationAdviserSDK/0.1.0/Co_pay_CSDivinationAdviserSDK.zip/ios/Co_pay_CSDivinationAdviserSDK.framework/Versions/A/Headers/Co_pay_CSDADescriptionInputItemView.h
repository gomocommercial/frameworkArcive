//
//  Co_pay_CSDADescriptionInputItemView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>
#import "Co_pay_CSDAPlaceHolderTextView.h"

NS_ASSUME_NONNULL_BEGIN

static NSInteger const co_pay_descriptionWordLimit = 2000;

@interface Co_pay_CSDADescriptionInputItemView : UIView

@property (nonatomic,strong) NSString *co_pay_TitleStr;
@property (nonatomic,strong) UILabel *co_pay_NumLb;
@property (nonatomic,strong) UILabel *co_pay_DescriptionLb;
@property (nonatomic,strong) NSString *co_pay_TfPlaceHolderStr;
@property (nonatomic,strong,readonly) Co_pay_CSDAPlaceHolderTextView *co_pay_textView;
@property (nonatomic,copy) void(^tVEndEditingBlock)(NSString *tVStr);
@property (nonatomic,copy) void(^tVTextChangeBlock)(NSString *tVStr);

@property (nonatomic,assign) BOOL co_pay_NeedWordLimit;

@property (nonatomic,assign) CGFloat co_pay_MinHeight;

@end

NS_ASSUME_NONNULL_END
