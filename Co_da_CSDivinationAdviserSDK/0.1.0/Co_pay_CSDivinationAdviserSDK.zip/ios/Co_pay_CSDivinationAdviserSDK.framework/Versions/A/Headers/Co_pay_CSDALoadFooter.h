//
//  Co_pay_CSDALoadFooter.h
//  Co_pay_CSDivinationAdviserSDK-Co_pay_CSDA
//
//  Created by 邝路平 on 2019/10/28.
//

#import "MJRefreshAutoFooter.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDALoadFooter : MJRefreshAutoFooter

- (void)setStateText:(NSString *)stateText;
- (void)hideLoading;
- (void)endRefreshing;

@end

NS_ASSUME_NONNULL_END
