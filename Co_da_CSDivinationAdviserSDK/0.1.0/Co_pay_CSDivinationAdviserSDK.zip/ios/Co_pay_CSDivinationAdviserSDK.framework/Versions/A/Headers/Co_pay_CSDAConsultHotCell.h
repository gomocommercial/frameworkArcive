//
//  Co_pay_CSDAConsultHotCell.h
//  Co_pay_CSDivinationAdviserSDK-Co_pay_CSDA
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
@class Co_pay_CSDAConsultChatModel;
NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAConsultHotCell : UITableViewCell

@property (nonatomic,strong) Co_pay_CSDAConsultChatModel *chatModel;
@property (nonatomic,copy) void(^checkHotMessageBlock)(NSString * message);

@end

NS_ASSUME_NONNULL_END
