//
//  Co_pay_CSDAStatistics.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAStatistics : NSObject

+ (Co_pay_CSDAStatistics *(^)(NSString *))co_pay_operation;

- (Co_pay_CSDAStatistics *(^)(NSString *))co_pay_statisticsObj;

- (Co_pay_CSDAStatistics *(^)(NSString *))co_pay_associationObj;

- (Co_pay_CSDAStatistics *(^)(NSString *))co_pay_enter;

- (Co_pay_CSDAStatistics *(^)(NSString *))co_pay_tab;

- (Co_pay_CSDAStatistics *(^)(NSString *))co_pay_remark;

- (Co_pay_CSDAStatistics *(^)(NSString *))co_pay_position;

- (Co_pay_CSDAStatistics *(^)(NSInteger))co_pay_orderType;

- (Co_pay_CSDAStatistics *(^)(NSString *))co_pay_orderId;

- (Co_pay_CSDAStatistics *(^)(NSString *))co_pay_resultCode;

- (void)co_pay_upload104f000;

- (void)co_pay_upload104c000;

- (void)co_pay_upload104t000;

- (void)co_pay_upload59Statistics;

@end

NS_ASSUME_NONNULL_END
