//
//  Co_pay_CSDATeacherDetailCell.h
//  Co_pay_CSDivinationAdviserSDK-Co_pay_CSDA
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDATeacherDetailCell : UITableViewCell

@property (nonatomic, strong ,readonly) UIView *co_pay_typesBgView;
@property (nonatomic,copy) NSString *co_pay_ImageName;
@property (nonatomic,copy) NSString *co_pay_TitleStr;

@end

NS_ASSUME_NONNULL_END
