//
//  Co_pay_CSDADeviceInfoTool.h
//  Co_pay_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDADeviceInfoTool : NSObject

+ (NSString *)co_pay_accountId;

+ (NSString *)co_pay_aid;

+ (NSString *)co_pay_country;

+ (NSString *)co_pay_language;

+ (NSString *)co_pay_versionCode;

+ (NSString *)co_pay_versionName;

+ (NSNumber *)co_pay_channel;

+ (NSString *)co_pay_bundleid;

+ (NSString *)co_pay_systemVersion;

+ (NSString *)co_pay_getPhoneModel;

+ (BOOL)co_pay_isDebugMode;


@end

NS_ASSUME_NONNULL_END
