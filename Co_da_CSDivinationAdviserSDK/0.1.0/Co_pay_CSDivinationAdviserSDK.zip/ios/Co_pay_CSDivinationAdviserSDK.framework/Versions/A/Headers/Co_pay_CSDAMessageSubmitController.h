//
//  Co_pay_CSDAMessageSubmitController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import "Co_pay_CSDABaseViewController.h"
@class Co_pay_CSDATeacherModel;
@class Co_pay_CSDAConsultModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_pay_CSDAMessageSubmitController : Co_pay_CSDABaseViewController

@property (nonatomic,strong) Co_pay_CSDATeacherModel *co_pay_teacherModel;
@property (nonatomic, copy) NSString *questionTitle;
@property (nonatomic, copy) void(^paySuccess)(Co_pay_CSDAConsultModel *model);

@end

NS_ASSUME_NONNULL_END
