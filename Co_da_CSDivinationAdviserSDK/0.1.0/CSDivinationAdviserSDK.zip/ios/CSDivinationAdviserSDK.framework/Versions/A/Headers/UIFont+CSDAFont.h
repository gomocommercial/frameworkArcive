//
//  UIFont+CSDAFont.h
//  CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIFont (CSDAFont)

+ (UIFont *)sfProBoldWithSize:(CGFloat)size;

+ (UIFont *)sfProLightWithSize:(CGFloat)size;

+ (UIFont *)sfProLightItalicWithSize:(CGFloat)size;

+ (UIFont *)sfProMediumWithSize:(CGFloat)size;

+ (UIFont *)sfProRegularWithSize:(CGFloat)size;

+ (UIFont *)sfProSemiboldWithSize:(CGFloat)size;

+ (UIFont *)halatSemiBoldWithSize:(CGFloat)size;

+ (UIFont *)halatBoldWithSize:(CGFloat)size;

+ (UIFont *)halatMediumWithSize:(CGFloat)size;

+ (UIFont *)sfProHeavyWithSize:(CGFloat)size;

@end

NS_ASSUME_NONNULL_END
