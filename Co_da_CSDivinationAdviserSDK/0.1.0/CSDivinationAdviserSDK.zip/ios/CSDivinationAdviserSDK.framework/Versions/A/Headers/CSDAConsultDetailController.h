//
//  CSDAConsultDetailController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/25.
//

#import "CSDABaseViewController.h"
@class CSDAConsultDetailHeaderView;
@class CSDAOrderListModel;

NS_ASSUME_NONNULL_BEGIN

@interface CSDAConsultDetailController : CSDABaseViewController

@property (nonatomic,strong) CSDAOrderListModel *orderModel;
@property (nonatomic, assign) NSInteger consult_id;

@end


@interface CSDAConsultDetailHeaderView : UIView

@property (nonatomic,strong) CSDAOrderListModel *orderModel;

+ (CGFloat)headerHeight;

@end

NS_ASSUME_NONNULL_END
