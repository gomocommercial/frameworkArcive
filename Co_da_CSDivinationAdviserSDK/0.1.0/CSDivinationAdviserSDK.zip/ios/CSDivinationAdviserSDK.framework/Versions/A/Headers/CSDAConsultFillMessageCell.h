//
//  CSDAConsultFillMessageCell.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
@class CSDAConsultChatModel;

NS_ASSUME_NONNULL_BEGIN


@interface CSDAConsultFillMessageCell : UITableViewCell

@property (nonatomic,strong) CSDAConsultChatModel *chatModel;

@property (nonatomic,copy) void(^fillMessageBlock)(CSDAConsultFillMessageCell * cell);

@property (nonatomic,copy) void(^avatarActionBlock)(CSDAConsultFillMessageCell *cell);

- (void)setBtnEnable:(BOOL)enable;

@end

NS_ASSUME_NONNULL_END
