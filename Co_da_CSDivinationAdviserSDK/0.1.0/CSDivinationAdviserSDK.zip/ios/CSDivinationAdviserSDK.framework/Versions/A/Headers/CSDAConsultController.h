//
//  CSDAConsultController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import "CSDABaseViewController.h"
@class CSDATeacherModel;
@class CSDAOrderListModel;
@class CSDAConsultModel;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, ConsultFromType) {
    ConsultFromType_Submit,
    ConsultFromType_Order,
    ConsultFromType_Remote,
    ConsultFromType_More
};


@interface CSDAConsultController : CSDABaseViewController

@property (nonatomic,assign) ConsultFromType fromType;

// 从订单列表那边过来
@property (nonatomic,strong) CSDAOrderListModel *orderModel;
// 从上传咨询订单中过来
@property (nonatomic,strong) CSDAConsultModel *consultModel;
// 从通知过来
@property (nonatomic,assign) NSInteger consult_id;

//提交、咨询订单
@property (nonatomic,strong) CSDATeacherModel *teacherModel;

@end

NS_ASSUME_NONNULL_END
