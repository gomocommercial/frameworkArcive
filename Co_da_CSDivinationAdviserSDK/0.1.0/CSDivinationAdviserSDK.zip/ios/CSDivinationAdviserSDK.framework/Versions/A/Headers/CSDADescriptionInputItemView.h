//
//  CSDADescriptionInputItemView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>
#import "CSDAPlaceHolderTextView.h"

NS_ASSUME_NONNULL_BEGIN

static NSInteger const descriptionWordLimit = 2000;

@interface CSDADescriptionInputItemView : UIView

@property (nonatomic,strong) NSString *TitleStr;
@property (nonatomic,strong) UILabel *NumLb;
@property (nonatomic,strong) UILabel *DescriptionLb;
@property (nonatomic,strong) NSString *TfPlaceHolderStr;
@property (nonatomic,strong,readonly) CSDAPlaceHolderTextView *textView;
@property (nonatomic,copy) void(^tVEndEditingBlock)(NSString *tVStr);
@property (nonatomic,copy) void(^tVTextChangeBlock)(NSString *tVStr);

@property (nonatomic,assign) BOOL NeedWordLimit;

@property (nonatomic,assign) CGFloat MinHeight;

@end

NS_ASSUME_NONNULL_END
