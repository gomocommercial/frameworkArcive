//
//  CSDADataLoadManager.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^FailureBlock)(NSError * error);
typedef void (^SuccessBlock)(id handleResult);

@interface CSDADataLoadManager : NSObject

+(instancetype)shareManager;

// 首页老师列表
-(void)mainAdvisorsWithSuccess:(SuccessBlock)successBlock failure:(FailureBlock)failureBlock;

// 查询老师信息详情
- (void)selectAdvisorDetail:(NSString *)advisorCode
             successBlock:(SuccessBlock)successBlock
             failureBlock:(FailureBlock)failureBlock;

// 获取用户订单信息
- (void)userOrderList:(long)startId
                 size:(NSInteger)size
           orderState:(NSInteger)orderState
               userId:(NSString * )userId
       successBlock:(SuccessBlock)successBlock
       failureBlock:(FailureBlock)failureBlock;

// 查询咨询订单
-(void)getConsultOrder:(NSString * )consult_id
        successBlock:(SuccessBlock)successBlock
        failureBlock:(FailureBlock)failureBlock;

// 获取账户余额
- (void)getBalanceWithAccountId:(NSString *)accountId
                        Success:(SuccessBlock)successBlock
                        failure:(FailureBlock)failureBlock;

// 获取充值商品
- (void)getrechargeProductSuccess:(SuccessBlock)successBlock
                          failure:(FailureBlock)failureBlock;

// 商品充值
- (void)balanceRechargeWithProductCode:(NSString *)productCode
                         WithAccountId:(NSString *)accountId
                                tranId:(NSString *)tran_id
                               Success:(SuccessBlock)successBlock
                               failure:(FailureBlock)failureBlock;

// 余额使用明细
- (void)getBalanceDetailWithParam:(NSDictionary *)params
                     moreQueryDic:(NSDictionary *)queryDic
                          Success:(SuccessBlock)successBlock
                          failure:(FailureBlock)failureBlock;

// 余额消费
- (void)consumptionWithUserId:(NSString *)userId
                    orderCode:(NSString *)orderCode
                  description:(NSString *)description
               successBlock:(SuccessBlock)successBlock
               failureBlock:(FailureBlock)failureBlock;

// 生成订单
- (void)generateOrderWithParams:(NSDictionary *)params
                 successBlock:(SuccessBlock)successBlock
                 failureBlock:(FailureBlock)failureBlock;

// 上传咨询表单
- (void)uploadConsultationWithParams:(NSDictionary *)params
                      successBlock:(SuccessBlock)successBlock
                      failureBlock:(FailureBlock)failureBlock;

// 咨询分类列表
- (void)advisorTypeWithsuccessBlock:(SuccessBlock)successBlock
                       failureBlock:(FailureBlock)failureBlock;

// 按咨询类型归类的老师列表
- (void)advisorClassifyListWithsuccessBlock:(SuccessBlock)successBlock
                               failureBlock:(FailureBlock)failureBlock;

// 查询老师回复
- (void)selectAdvisorReplyWithConsultId:(NSInteger)consultId
                         successBlock:(SuccessBlock)successBlock
                         failureBlock:(FailureBlock)failureBlock;

// 测试老师回复
-(void)teacherCallOrder_code:(NSString *)order_code consult_id:(NSString *)consult_id successBlock:(SuccessBlock)successBlock
              failureBlock:(FailureBlock)failureBlock;


//获取老师短介绍
- (void)advisorIntroductionWithAdvisorCode:(NSString *)advisorCode
                            successBlock:(SuccessBlock)successBlock
                            failureBlock:(FailureBlock)failureBlock;


@end

NS_ASSUME_NONNULL_END
