//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSDivinationAdviserSDK/CSDAHeader.h>

typedef void(^completeBlock)( NSDictionary * _Nullable result);
typedef void(^completeWithErrorBlock)(NSDictionary * _Nullable result, NSError * _Nullable error);

@interface CSDAHttpManager : NSObject

+ (instancetype _Nullable )shareManager;


- (void)requestDivinationWithMethod:(NSString *)method
                                      url:(NSString *)urlStr
                                   params:(NSDictionary *)params moreQueryDic:(NSDictionary*)moreQueryDic timeoutInterval:(NSTimeInterval)timeoutInterval complete:(completeWithErrorBlock)complete;


#pragma mark ---网络变化监听---
/**
 开始网络监听
 */
+ (void)startMonitoringNetworkChangeBlock:(void(^ _Nullable)(AFNetworkReachabilityStatus status))block;

/**
 关闭网络监听
 */
+ (void)stopMonitoring;

+ (NSString *_Nullable)networkType;

@end
