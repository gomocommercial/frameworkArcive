//
//  CSDAConsultDetailCell.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const ConsultDetailCell_Normal;
extern NSString *const ConsultDetailCell_ChangeHeight;

@interface CSDAConsultDetailCell : UITableViewCell

@property (nonatomic,strong) NSString *TitleStr;
@property (nonatomic,strong) NSString *ContentStr;
@property (nonatomic,strong) NSString *BottomStr;
@property (nonatomic,assign) BOOL needHideLine;

@end

NS_ASSUME_NONNULL_END
