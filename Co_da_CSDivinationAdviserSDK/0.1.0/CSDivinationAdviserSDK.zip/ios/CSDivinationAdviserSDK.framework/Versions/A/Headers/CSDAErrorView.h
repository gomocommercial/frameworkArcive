//
//  CSDAErrorView.h
//  CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, CSDAErrorType) {
    CSDAErrorType_NoNetwork,  // 无网络
    CSDAErrorType_NoContent,  // 无内容
};

@interface CSDAErrorView : UIView

@property (nonatomic, copy) void(^refreshClickBlock)(void);
@property (nonatomic,assign) CSDAErrorType errorType;

@end

NS_ASSUME_NONNULL_END
