//
//  CSDAConsultHotCell.h
//  CSDivinationAdviserSDK-CSDA
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
@class CSDAConsultChatModel;
NS_ASSUME_NONNULL_BEGIN

@interface CSDAConsultHotCell : UITableViewCell

@property (nonatomic,strong) CSDAConsultChatModel *chatModel;
@property (nonatomic,copy) void(^checkHotMessageBlock)(NSString * message);

@end

NS_ASSUME_NONNULL_END
