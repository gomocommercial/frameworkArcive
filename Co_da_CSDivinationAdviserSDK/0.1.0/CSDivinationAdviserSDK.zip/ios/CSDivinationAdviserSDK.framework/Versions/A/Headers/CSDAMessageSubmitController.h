//
//  CSDAMessageSubmitController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import "CSDABaseViewController.h"
@class CSDATeacherModel;
@class CSDAConsultModel;

NS_ASSUME_NONNULL_BEGIN

@interface CSDAMessageSubmitController : CSDABaseViewController

@property (nonatomic,strong) CSDATeacherModel *teacherModel;
@property (nonatomic, copy) NSString *questionTitle;
@property (nonatomic, copy) void(^paySuccess)(CSDAConsultModel *model);

@end

NS_ASSUME_NONNULL_END
