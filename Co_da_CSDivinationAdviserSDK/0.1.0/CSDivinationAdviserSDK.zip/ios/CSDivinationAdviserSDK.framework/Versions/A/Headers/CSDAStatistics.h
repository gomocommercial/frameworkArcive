//
//  CSDAStatistics.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSDAStatistics : NSObject

+ (CSDAStatistics *(^)(NSString *))operation;

- (CSDAStatistics *(^)(NSString *))statisticsObj;

- (CSDAStatistics *(^)(NSString *))associationObj;

- (CSDAStatistics *(^)(NSString *))enter;

- (CSDAStatistics *(^)(NSString *))tab;

- (CSDAStatistics *(^)(NSString *))remark;

- (CSDAStatistics *(^)(NSString *))position;

- (CSDAStatistics *(^)(NSInteger))orderType;

- (CSDAStatistics *(^)(NSString *))orderId;

- (CSDAStatistics *(^)(NSString *))resultCode;

- (void)upload104f000;

- (void)upload104c000;

- (void)upload104t000;

- (void)upload59Statistics;

@end

NS_ASSUME_NONNULL_END
