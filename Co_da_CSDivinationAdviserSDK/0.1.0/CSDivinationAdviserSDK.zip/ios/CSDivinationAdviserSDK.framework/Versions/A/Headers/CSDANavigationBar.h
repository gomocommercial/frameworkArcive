//
//  CSDANavigationBar.h
//  CSDivinationAdviserSDK-CSDA
//
//  Created by 邝路平 on 2019/9/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSDANavigationBar : UIView

@property (nonatomic, strong) UIView *LeftBarButtonItem;
@property (nonatomic, strong) UIView *RightBarButtonItem;
@property (nonatomic, strong) UIView *TitleView;

@end

NS_ASSUME_NONNULL_END
