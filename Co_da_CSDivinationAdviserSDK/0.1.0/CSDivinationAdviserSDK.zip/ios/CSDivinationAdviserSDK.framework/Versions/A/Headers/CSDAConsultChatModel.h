//
//  CSDAConsultChatModel.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, ConsultChatMsgType) {
    ConsultChatMsgType_Text,
    ConsultChatMsgType_Video,
    ConsultChatMsgType_Image,
    ConsultChatMsgType_Hot,
    ConsultChatMsgType_FillMessage,
    ConsultChatMsgType_History,
    ConsultChatMsgType_CheckInfomation,
    ConsultChatMsgType_CheckBalance,

};

typedef NS_ENUM(NSInteger, ConsultChatSendType) {
    ConsultChatSendType_Sending,
    ConsultChatSendType_Failed,
    ConsultChatSendType_Done
};


extern NSString *const ConsultCell_Mine;
extern NSString *const ConsultCell_Teacher;
extern NSString *const ConsultCell_Mine_Image;
extern NSString *const ConsultCell_Teacher_Image;
extern NSString *const ConsultCell_Hot;
extern NSString *const ConsultCell_FillMessage;

extern BOOL messageCanAction;
extern CGFloat const ConsultCellWidthMul;

@interface CSDAConsultChatModel : NSObject

@property (nonatomic,strong) NSString *createTime;
@property (nonatomic,assign) BOOL isFromMine;
@property (nonatomic,strong) NSString *avatorImageUrl;
@property (nonatomic,strong) NSString *contentStr;
@property (nonatomic,strong) NSString *videoUrl;
@property (nonatomic,strong) NSString *imageUrl;
@property (nonatomic,assign) ConsultChatMsgType chatType;
@property (nonatomic,assign) ConsultChatSendType sendType;

@property (nonatomic,strong) NSString *cellIdentifier;

@property (nonatomic,strong) UIImage *coverImage;
@property (nonatomic, strong) NSArray<NSString*> *hotMessages;

@end

NS_ASSUME_NONNULL_END
