//
//  CSDATeacherDetailCell.h
//  CSDivinationAdviserSDK-CSDA
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSDATeacherDetailCell : UITableViewCell

@property (nonatomic, strong ,readonly) UIView *typesBgView;
@property (nonatomic,copy) NSString *ImageName;
@property (nonatomic,copy) NSString *TitleStr;

@end

NS_ASSUME_NONNULL_END
