//
//  CSDABrowserUtil.h
//  CSDivinationAdviserSDK-CSDA
//
//  Created by 邝路平 on 2019/10/27.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class CSDABrowserController;

NS_ASSUME_NONNULL_BEGIN

@interface CSDABrowserUtil : NSObject

+ (UIWindow *)mainWindow;

+ (UIViewController *)topController;



@end

NS_ASSUME_NONNULL_END
