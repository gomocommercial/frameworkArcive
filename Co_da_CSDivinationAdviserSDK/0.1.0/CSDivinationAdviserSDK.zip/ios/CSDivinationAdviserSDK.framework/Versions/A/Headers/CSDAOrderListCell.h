//
//  CSDAOrderListCell.h
//  CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CSDAOrderListModel;

@interface CSDAOrderListCell : UITableViewCell

@property (nonatomic,strong) CSDAOrderListModel *orderListModel;

@property (nonatomic,copy) void(^payBlock)(CSDAOrderListModel *orderListModel);

- (BOOL)canResetModelListWithTimeOffset:(NSInteger)offset;

+ (CGFloat)cellHeight;

+ (NSString *)CountDownTimeWithInterval:(NSInteger)interval;

@end

NS_ASSUME_NONNULL_END
