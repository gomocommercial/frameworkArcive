//
//  CSDAInputItemView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

static NSInteger const InputItemViewWordLimit = 200;

@interface CSDAInputItemView : UIView

@property (nonatomic,strong) NSString *TitleStr;
@property (nonatomic,strong) NSString *TfPlaceHolderStr;
@property (nonatomic,strong,readonly) UITextField *textTf;
@property (nonatomic,assign) BOOL NeedWordLimit;

@property (nonatomic,copy) void(^TfEndEditingBlock)(NSString *tfStr);

@end

NS_ASSUME_NONNULL_END
