//
//  CSDAConsultCell.h
//  CSDivinationAdviserSDK-CSDA
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
#import "CSDAConsultChatModel.h"
#import "CSDAConsultFillMessageCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSDAConsultCell : UITableViewCell

@property (nonatomic,strong) CSDAConsultChatModel *chatModel;
@property (nonatomic,copy) void(^highlightActionBlock)(CSDAConsultCell *cell);
@property (nonatomic,copy) void(^startLoadingBlock)(CSDAConsultCell *cell);
@property (nonatomic,copy) void(^failImageActionBlock)(CSDAConsultCell *cell);
@property (nonatomic,copy) void(^avatarActionBlock)(CSDAConsultCell *cell);

@end

NS_ASSUME_NONNULL_END
