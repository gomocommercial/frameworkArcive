//
//  CSDABrowserTransitionManager.h
//  CSDivinationAdviserSDK-CSDA
//
//  Created by 邝路平 on 2019/10/27.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CSDABrowserController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSDABrowserTransitionManager : NSObject<UIViewControllerAnimatedTransitioning>

@property (nonatomic,weak) CSDABrowserController *browserVc;


@end

NS_ASSUME_NONNULL_END
