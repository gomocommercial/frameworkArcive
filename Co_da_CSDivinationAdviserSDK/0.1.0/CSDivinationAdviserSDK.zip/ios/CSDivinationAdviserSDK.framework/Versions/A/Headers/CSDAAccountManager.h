//
//  CSDAAccountManager.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/29.
//

#import <Foundation/Foundation.h>
@class CSDAUser;
NS_ASSUME_NONNULL_BEGIN

@interface CSDAAccountManager : NSObject

+ (instancetype)shareManager;

@property (nonatomic,strong) CSDAUser *user;

// APP启动时自动登录
+ (void)AutoLoginWhenAppStart;

// 是否已经登录
+ (BOOL)isLogin;

// 是否有足够的余额
+ (BOOL)hasEnoughBalance;

// 更新账户余额
- (void)updateBalance;

// 更新账户余额
+ (void)refreshBalanceCompletion:(void(^)(float balance,BOOL success))completion;

// APP自动登录
+ (void)autoLoginVisitorWithComplete:(void(^ _Nullable)(NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
