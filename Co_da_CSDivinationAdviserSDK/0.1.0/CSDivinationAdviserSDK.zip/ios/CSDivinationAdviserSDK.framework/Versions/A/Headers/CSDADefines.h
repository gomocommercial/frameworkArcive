//
//  CSDADefines.h
//  Pods
//
//  Created by Zy on 2019/9/18.
//

#import "NSString+CSDAString.h"
#import "UIImage+CSDAImage.h"
#import "CSDAConfig.h"


#ifndef CSDADefines_h
#define CSDADefines_h

#define CSDAString(key) [NSString localizedStringForKey:(key)]
#define CSDAImage(name) [UIImage daImageWithName:(name)]
#define CSDAIsSmallScreen ([UIScreen mainScreen].bounds.size.width < 375)

#define CSDAColorHex(str) [UIColor CSDAColorWithHexString:str]
#define CSDAColorHexWithAlpha(color, a) [UIColor CSDAColorWithHexString:color alpha:a]

#define CSDA_SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define CSDA_SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define CSDA_dp(x) (CSDAIsSmallScreen ?  (x) / 375.0f * CSDA_SCREEN_WIDTH : x)
#define CSDA_px(x) (CSDAIsSmallScreen ?  (x) / 375.0f * CSDA_SCREEN_WIDTH / 2 : x / 2)
#define CSDA_WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

//判断是否为iPad
#define CSDA_IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define CSDA_IsiPhoneXAll ([UIScreen mainScreen].bounds.size.height >= 812.0f && !(CSDA_IS_IPAD))

#define CSDABarAndNavBarHeight ((CSDA_IsiPhoneXAll)? (44 + 44): (20 + 44))
#define CSDASafeBottomHeight ((CSDA_IsiPhoneXAll)? (34): (0))
#define CSDAStatusBarHeight ((CSDA_IsiPhoneXAll)? (44): (22))

#define RandomColor   [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1.0]

#define log(fmt, ...) {\
    if ([CSDAConfig config].isEnableLog) {\
        NSLog((@"[CSDivinationAdviserSDK]%s," "[lineNum:%d]" fmt) , __FUNCTION__, __LINE__, ##__VA_ARGS__);\
    } else {}\
}


#endif /* CSDADefines_h */
