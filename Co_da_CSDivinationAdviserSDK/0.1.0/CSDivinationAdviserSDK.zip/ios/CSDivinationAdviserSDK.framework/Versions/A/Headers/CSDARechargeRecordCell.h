//
//  CSDARechargeRecordCell.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/23.
//

#import <UIKit/UIKit.h>

@class CSDAConsumeRecordModel;

NS_ASSUME_NONNULL_BEGIN

@interface CSDARechargeRecordCell : UITableViewCell

+ (CGFloat)cellHeight;

@property (nonatomic,strong) CSDAConsumeRecordModel *RecordModel;

@end

NS_ASSUME_NONNULL_END
