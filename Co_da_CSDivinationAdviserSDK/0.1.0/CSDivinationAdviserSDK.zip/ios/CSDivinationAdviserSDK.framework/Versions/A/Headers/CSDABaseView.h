//
//  CSDABaseView.h
//  Pods-CSDivinationAdviserSDK_Example
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSDABaseView : UIView

@end

NS_ASSUME_NONNULL_END
