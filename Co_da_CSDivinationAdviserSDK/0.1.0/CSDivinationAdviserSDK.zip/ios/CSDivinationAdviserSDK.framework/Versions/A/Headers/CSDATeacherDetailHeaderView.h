//
//  CSDATeacherDetailHeaderView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>
@class CSDATeacherModel;
NS_ASSUME_NONNULL_BEGIN

@interface CSDATeacherDetailHeaderView : UIView

@property (nonatomic,strong) CSDATeacherModel *teacherModel;

+ (CGFloat)headerHeight;

@end

NS_ASSUME_NONNULL_END
