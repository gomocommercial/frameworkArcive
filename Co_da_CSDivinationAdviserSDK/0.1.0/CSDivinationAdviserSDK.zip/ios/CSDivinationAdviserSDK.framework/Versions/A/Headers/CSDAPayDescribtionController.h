//
//  CSDAPayDescribtionController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/24.
//

#import "CSDABaseViewController.h"
@class CSDATeacherModel;
@class CSDAConsultModel;
@class CSDAOrderListModel;

NS_ASSUME_NONNULL_BEGIN

@interface CSDAPayDescribtionController : CSDABaseViewController

@property (nonatomic,assign) BOOL isFromOrder;

@property (nonatomic,strong) CSDATeacherModel *teacherModel;
@property (nonatomic,strong) CSDAConsultModel *consultModel;
@property (nonatomic,strong) NSString *order_code;

@property (nonatomic,strong) CSDAOrderListModel *orderModel;



@end

NS_ASSUME_NONNULL_END
