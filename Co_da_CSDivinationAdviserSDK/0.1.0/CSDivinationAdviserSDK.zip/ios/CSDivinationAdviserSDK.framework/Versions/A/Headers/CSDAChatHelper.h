//
//  CSDAChatHelper.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/24.
//

#import <Foundation/Foundation.h>
@class CSDAConsultChatModel;
@class CSDAConsultReplyModel;

NS_ASSUME_NONNULL_BEGIN

@interface CSDAChatHelper : NSObject

//老师招呼语
+ (CSDAConsultChatModel *)getAdvisorSalutationChat:(CSDAConsultReplyModel *)model;

//老师招呼视频
+ (CSDAConsultChatModel *)getAdvisorSalutationVideoChat:(CSDAConsultReplyModel *)model;

//热点问题
+ (CSDAConsultChatModel *)getHotQuestionsChat;

//补全问题
+ (CSDAConsultChatModel *)getFillMessageChat:(CSDAConsultReplyModel *)model;

//历史问题
+ (CSDAConsultChatModel *)getHistoryQuestionsChat:(CSDAConsultReplyModel *)model;

//老师视频回复
+ (CSDAConsultChatModel *)getAdivisorVideoChat:(CSDAConsultReplyModel *)model;

//老师回复
+ (CSDAConsultChatModel *)getAdivisorReplyMessageChat:(CSDAConsultReplyModel *)model;

//老师自定义信息回复
+ (CSDAConsultChatModel *)getAdivisorMessageChat:(CSDAConsultReplyModel *)model Chat:(NSString *)chatStr;

//用户信息回复
+ (CSDAConsultChatModel *)getCustomMessageChat:(NSString *)chatStr;

@end

NS_ASSUME_NONNULL_END
