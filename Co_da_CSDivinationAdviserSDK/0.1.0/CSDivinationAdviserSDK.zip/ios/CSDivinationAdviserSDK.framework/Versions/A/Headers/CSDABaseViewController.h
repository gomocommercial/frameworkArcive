//
//  CSDABaseViewController.h
//  CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>
@class CSDANavigationBar;
NS_ASSUME_NONNULL_BEGIN

@interface CSDABaseViewController : UIViewController

@property (nonatomic, strong, readonly) CSDANavigationBar *navigationBar;

- (UIView *)createBackgroundImageView;

- (void)leftBtnDidClcik;

@end

NS_ASSUME_NONNULL_END
