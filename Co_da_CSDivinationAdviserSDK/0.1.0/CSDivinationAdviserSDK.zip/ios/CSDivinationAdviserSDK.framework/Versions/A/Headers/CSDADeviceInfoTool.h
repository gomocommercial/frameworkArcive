//
//  CSDADeviceInfoTool.h
//  CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSDADeviceInfoTool : NSObject

+ (NSString *)accountId;

+ (NSString *)aid;

+ (NSString *)country;

+ (NSString *)language;

+ (NSString *)versionCode;

+ (NSString *)versionName;

+ (NSNumber *)channel;

+ (NSString *)bundleid;

+ (NSString *)systemVersion;

+ (NSString *)getPhoneModel;

+ (BOOL)isDebugMode;


@end

NS_ASSUME_NONNULL_END
