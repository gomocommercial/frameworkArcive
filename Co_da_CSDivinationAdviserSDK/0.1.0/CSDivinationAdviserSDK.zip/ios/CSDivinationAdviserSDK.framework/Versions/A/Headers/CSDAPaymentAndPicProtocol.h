//
//  CSDAPaymentAndPicProtocol.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/30.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol CSDAPaymentAndPicProtocol <NSObject>

// 支付
-(void)paymentDidPayWithProductId:(NSString *)productId;

// 图片上传
-(void)pictureDidUploadWithImage:(UIImage *)image Completion:(void(^)(BOOL isSuccess,NSString *imageUrl))completion;


@end

NS_ASSUME_NONNULL_END
