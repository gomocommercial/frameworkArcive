//
//  CSDAAdvisorsDetailController.h
//  CSDivinationAdviserSDK-CSDA
//
//  Created by 邝路平 on 2019/9/27.
//

#import "CSDABaseViewController.h"
@class CSDATeacherModel;
NS_ASSUME_NONNULL_BEGIN

@interface CSDAAdvisorsDetailController : CSDABaseViewController

@property (nonatomic,strong) CSDATeacherModel *teacherModel;

@end

NS_ASSUME_NONNULL_END
