//
//  CSDASubmitHeaderView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSDASubmitHeaderView : UIView

@property (nonatomic,strong) NSString *NameStr;
@property (nonatomic,strong) NSString *AvatorUrl;


@end

NS_ASSUME_NONNULL_END
