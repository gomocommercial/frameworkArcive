//
//  Co_da_CSDAOrderListView.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_da_CSDAOrderType) {
    Co_da_CSDAOrderType_Unpaid = 1,
    Co_da_CSDAOrderType_WaitingReply,
    Co_da_CSDAOrderType_Finished,
    Co_da_CSDAOrderType_Refunded,
};

@interface Co_da_CSDAOrderListView : UIView

@property (nonatomic,assign) Co_da_CSDAOrderType orderType;

@end

NS_ASSUME_NONNULL_END

