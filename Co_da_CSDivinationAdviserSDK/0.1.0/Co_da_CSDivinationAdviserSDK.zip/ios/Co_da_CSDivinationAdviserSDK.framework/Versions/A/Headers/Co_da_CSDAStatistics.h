//
//  Co_da_CSDAStatistics.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAStatistics : NSObject

+ (Co_da_CSDAStatistics *(^)(NSString *))co_da_operation;

- (Co_da_CSDAStatistics *(^)(NSString *))co_da_statisticsObj;

- (Co_da_CSDAStatistics *(^)(NSString *))co_da_associationObj;

- (Co_da_CSDAStatistics *(^)(NSString *))co_da_enter;

- (Co_da_CSDAStatistics *(^)(NSString *))co_da_tab;

- (Co_da_CSDAStatistics *(^)(NSString *))co_da_remark;

- (Co_da_CSDAStatistics *(^)(NSString *))co_da_position;

- (Co_da_CSDAStatistics *(^)(NSInteger))co_da_orderType;

- (Co_da_CSDAStatistics *(^)(NSString *))co_da_orderId;

- (Co_da_CSDAStatistics *(^)(NSString *))co_da_resultCode;

- (void)co_da_upload104f000;

- (void)co_da_upload104c000;

- (void)co_da_upload104t000;

- (void)co_da_upload59Statistics;

@end

NS_ASSUME_NONNULL_END
