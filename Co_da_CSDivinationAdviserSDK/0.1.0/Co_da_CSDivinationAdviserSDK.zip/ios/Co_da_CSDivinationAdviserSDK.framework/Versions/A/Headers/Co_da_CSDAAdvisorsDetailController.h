//
//  Co_da_CSDAAdvisorsDetailController.h
//  Co_da_CSDivinationAdviserSDK-Co_da_CSDA
//
//  Created by 邝路平 on 2019/9/27.
//

#import "Co_da_CSDABaseViewController.h"
@class Co_da_CSDATeacherModel;
NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAAdvisorsDetailController : Co_da_CSDABaseViewController

@property (nonatomic,strong) Co_da_CSDATeacherModel *teacherModel;

@end

NS_ASSUME_NONNULL_END
