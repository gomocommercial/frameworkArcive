//
//  Co_da_CSDADescriptionInputItemView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>
#import "Co_da_CSDAPlaceHolderTextView.h"

NS_ASSUME_NONNULL_BEGIN

static NSInteger const co_da_descriptionWordLimit = 2000;

@interface Co_da_CSDADescriptionInputItemView : UIView

@property (nonatomic,strong) NSString *co_da_TitleStr;
@property (nonatomic,strong) UILabel *co_da_NumLb;
@property (nonatomic,strong) UILabel *co_da_DescriptionLb;
@property (nonatomic,strong) NSString *co_da_TfPlaceHolderStr;
@property (nonatomic,strong,readonly) Co_da_CSDAPlaceHolderTextView *co_da_textView;
@property (nonatomic,copy) void(^tVEndEditingBlock)(NSString *tVStr);
@property (nonatomic,copy) void(^tVTextChangeBlock)(NSString *tVStr);

@property (nonatomic,assign) BOOL co_da_NeedWordLimit;

@property (nonatomic,assign) CGFloat co_da_MinHeight;

@end

NS_ASSUME_NONNULL_END
