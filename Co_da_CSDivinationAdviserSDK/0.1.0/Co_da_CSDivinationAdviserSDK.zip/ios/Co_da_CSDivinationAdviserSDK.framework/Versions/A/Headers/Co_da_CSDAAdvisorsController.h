//
//  Co_da_CSDAAdvisorsController.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import "Co_da_CSDABaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAAdvisorsController : Co_da_CSDABaseViewController

@end

NS_ASSUME_NONNULL_END
