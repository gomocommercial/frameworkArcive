//
//  Co_da_CSDADeviceInfoTool.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDADeviceInfoTool : NSObject

+ (NSString *)co_da_accountId;

+ (NSString *)co_da_aid;

+ (NSString *)co_da_country;

+ (NSString *)co_da_language;

+ (NSString *)co_da_versionCode;

+ (NSString *)co_da_versionName;

+ (NSNumber *)co_da_channel;

+ (NSString *)co_da_bundleid;

+ (NSString *)co_da_systemVersion;

+ (NSString *)co_da_getPhoneModel;

+ (BOOL)co_da_isDebugMode;


@end

NS_ASSUME_NONNULL_END
