//
//  Co_da_CSDAInputItemView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

static NSInteger const Co_da_InputItemViewWordLimit = 200;

@interface Co_da_CSDAInputItemView : UIView

@property (nonatomic,strong) NSString *co_da_titleStr;
@property (nonatomic,strong) NSString *co_da_tfPlaceHolderStr;
@property (nonatomic,strong,readonly) UITextField *co_da_textTf;
@property (nonatomic,assign) BOOL co_da_needWordLimit;

@property (nonatomic,copy) void(^co_da_tfEndEditingBlock)(NSString *tfStr);

@end

NS_ASSUME_NONNULL_END
