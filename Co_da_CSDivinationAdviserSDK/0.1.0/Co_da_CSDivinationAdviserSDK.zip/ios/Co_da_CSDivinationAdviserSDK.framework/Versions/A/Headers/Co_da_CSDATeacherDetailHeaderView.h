//
//  Co_da_CSDATeacherDetailHeaderView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>
@class Co_da_CSDATeacherModel;
NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDATeacherDetailHeaderView : UIView

@property (nonatomic,strong) Co_da_CSDATeacherModel *teacherModel;

+ (CGFloat)headerHeight;

@end

NS_ASSUME_NONNULL_END
