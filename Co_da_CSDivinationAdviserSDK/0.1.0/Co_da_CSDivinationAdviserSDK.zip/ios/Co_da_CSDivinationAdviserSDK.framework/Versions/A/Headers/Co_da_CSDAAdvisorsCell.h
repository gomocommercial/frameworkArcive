//
//  Co_da_CSDAAdvisorsCell.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class Co_da_CSDATeacherModel;

@interface Co_da_CSDAAdvisorsCell : UITableViewCell

@property (nonatomic, strong) UIView *lineView;
@property (nonatomic,strong) Co_da_CSDATeacherModel *teacherModel;
@property (nonatomic,copy) void(^chatBlock)(Co_da_CSDATeacherModel *teacherModel);

+ (CGFloat)cellHeight;

@end

NS_ASSUME_NONNULL_END
