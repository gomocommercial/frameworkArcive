//
//  Co_da_CSDAConsultDetailController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/25.
//

#import "Co_da_CSDABaseViewController.h"
@class Co_da_CSDAConsultDetailHeaderView;
@class Co_da_CSDAOrderListModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAConsultDetailController : Co_da_CSDABaseViewController

@property (nonatomic,strong) Co_da_CSDAOrderListModel *orderModel;
@property (nonatomic, assign) NSInteger consult_id;

@end


@interface Co_da_CSDAConsultDetailHeaderView : UIView

@property (nonatomic,strong) Co_da_CSDAOrderListModel *orderModel;

+ (CGFloat)co_da_headerHeight;

@end

NS_ASSUME_NONNULL_END
