//
//  UIButton+Co_da_CSDABlock.h
//  Co_da_CSDivinationAdviserSDK-Co_da_CSDA
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (Co_da_CSDABlock)

- (void)co_da_addHandleBlock:(void (^)(NSInteger tag))block;

@end

NS_ASSUME_NONNULL_END
