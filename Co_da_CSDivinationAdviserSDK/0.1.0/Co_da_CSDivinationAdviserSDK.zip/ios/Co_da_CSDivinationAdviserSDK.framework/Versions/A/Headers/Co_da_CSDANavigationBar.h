//
//  Co_da_CSDANavigationBar.h
//  Co_da_CSDivinationAdviserSDK-Co_da_CSDA
//
//  Created by 邝路平 on 2019/9/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDANavigationBar : UIView

@property (nonatomic, strong) UIView *co_da_leftBarButtonItem;
@property (nonatomic, strong) UIView *co_da_rightBarButtonItem;
@property (nonatomic, strong) UIView *co_da_titleView;

@end

NS_ASSUME_NONNULL_END
