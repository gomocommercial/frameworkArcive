//
//  Co_da_CSDAConsultChatModel.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_da_ConsultChatMsgType) {
    Co_da_ConsultChatMsgType_Text,
    Co_da_ConsultChatMsgType_Video,
    Co_da_ConsultChatMsgType_Image,
    Co_da_ConsultChatMsgType_Hot,
    Co_da_ConsultChatMsgType_FillMessage,
    Co_da_ConsultChatMsgType_History,
    Co_da_ConsultChatMsgType_CheckInfomation,
    Co_da_ConsultChatMsgType_CheckBalance,

};

typedef NS_ENUM(NSInteger, Co_da_ConsultChatSendType) {
    Co_da_ConsultChatSendType_Sending,
    Co_da_ConsultChatSendType_Failed,
    Co_da_ConsultChatSendType_Done
};


extern NSString *const Co_da_ConsultCell_Mine;
extern NSString *const Co_da_ConsultCell_Teacher;
extern NSString *const Co_da_ConsultCell_Mine_Image;
extern NSString *const Co_da_ConsultCell_Teacher_Image;
extern NSString *const Co_da_ConsultCell_Hot;
extern NSString *const Co_da_ConsultCell_FillMessage;

extern BOOL co_da_messageCanAction;
extern CGFloat const Co_da_ConsultCellWidthMul;

@interface Co_da_CSDAConsultChatModel : NSObject

@property (nonatomic,strong) NSString *createTime;
@property (nonatomic,assign) BOOL isFromMine;
@property (nonatomic,strong) NSString *avatorImageUrl;
@property (nonatomic,strong) NSString *contentStr;
@property (nonatomic,strong) NSString *videoUrl;
@property (nonatomic,strong) NSString *imageUrl;
@property (nonatomic,assign) Co_da_ConsultChatMsgType chatType;
@property (nonatomic,assign) Co_da_ConsultChatSendType sendType;

@property (nonatomic,strong) NSString *cellIdentifier;

@property (nonatomic,strong) UIImage *coverImage;
@property (nonatomic, strong) NSArray<NSString*> *hotMessages;

@end

NS_ASSUME_NONNULL_END
