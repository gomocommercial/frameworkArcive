//
//  Co_da_CSDAConsultFillMessageCell.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
@class Co_da_CSDAConsultChatModel;

NS_ASSUME_NONNULL_BEGIN


@interface Co_da_CSDAConsultFillMessageCell : UITableViewCell

@property (nonatomic,strong) Co_da_CSDAConsultChatModel *chatModel;

@property (nonatomic,copy) void(^fillMessageBlock)(Co_da_CSDAConsultFillMessageCell * cell);

@property (nonatomic,copy) void(^avatarActionBlock)(Co_da_CSDAConsultFillMessageCell *cell);

- (void)setBtnEnable:(BOOL)enable;

@end

NS_ASSUME_NONNULL_END
