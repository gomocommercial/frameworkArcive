//
//  Co_da_CSDADefines.h
//  Pods
//
//  Created by Zy on 2019/9/18.
//

#import "NSString+Co_da_CSDAString.h"
#import "UIImage+Co_da_CSDAImage.h"
#import "Co_da_CSDAConfig.h"


#ifndef Co_da_CSDADefines_h
#define Co_da_CSDADefines_h

#define Co_da_CSDAString(key) [NSString co_da_localizedStringForKey:(key)]
#define Co_da_CSDAImage(name) [UIImage co_da_daImageWithName:(name)]
#define Co_da_CSDAIsSmallScreen ([UIScreen mainScreen].bounds.size.width < 375)

#define Co_da_CSDAColorHex(str) [UIColor co_da_CSDAColorWithHexString:str]
#define Co_da_CSDAColorHexWithAlpha(color, a) [UIColor co_da_CSDAColorWithHexString:color alpha:a]

#define Co_da_CSDA_SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define Co_da_CSDA_SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define Co_da_CSDA_dp(x) (Co_da_CSDAIsSmallScreen ?  (x) / 375.0f * Co_da_CSDA_SCREEN_WIDTH : x)
#define Co_da_CSDA_px(x) (Co_da_CSDAIsSmallScreen ?  (x) / 375.0f * Co_da_CSDA_SCREEN_WIDTH / 2 : x / 2)
#define Co_da_CSDA_WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

//判断是否为iPad
#define Co_da_CSDA_IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define Co_da_CSDA_IsiPhoneXAll ([UIScreen mainScreen].bounds.size.height >= 812.0f && !(Co_da_CSDA_IS_IPAD))

#define Co_da_CSDABarAndNavBarHeight ((Co_da_CSDA_IsiPhoneXAll)? (44 + 44): (20 + 44))
#define Co_da_CSDASafeBottomHeight ((Co_da_CSDA_IsiPhoneXAll)? (34): (0))
#define Co_da_CSDAStatusBarHeight ((Co_da_CSDA_IsiPhoneXAll)? (44): (22))

#define Co_da_RandomColor   [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1.0]

#define Co_da_log(fmt, ...) {\
    if ([Co_da_CSDAConfig co_da_config].isEnableLog) {\
        NSLog((@"[Co_da_CSDivinationAdviserSDK]%s," "[lineNum:%d]" fmt) , __FUNCTION__, __LINE__, ##__VA_ARGS__);\
    } else {}\
}


#endif /* Co_da_CSDADefines_h */
