//
//  Co_da_CSDAConsultHotCell.h
//  Co_da_CSDivinationAdviserSDK-Co_da_CSDA
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
@class Co_da_CSDAConsultChatModel;
NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAConsultHotCell : UITableViewCell

@property (nonatomic,strong) Co_da_CSDAConsultChatModel *chatModel;
@property (nonatomic,copy) void(^checkHotMessageBlock)(NSString * message);

@end

NS_ASSUME_NONNULL_END
