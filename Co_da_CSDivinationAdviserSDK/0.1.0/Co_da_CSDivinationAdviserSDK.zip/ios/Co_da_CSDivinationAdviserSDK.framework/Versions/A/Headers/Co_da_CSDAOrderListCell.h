//
//  Co_da_CSDAOrderListCell.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class Co_da_CSDAOrderListModel;

@interface Co_da_CSDAOrderListCell : UITableViewCell

@property (nonatomic,strong) Co_da_CSDAOrderListModel *orderListModel;

@property (nonatomic,copy) void(^payBlock)(Co_da_CSDAOrderListModel *orderListModel);

- (BOOL)canResetModelListWithTimeOffset:(NSInteger)offset;

+ (CGFloat)cellHeight;

+ (NSString *)CountDownTimeWithInterval:(NSInteger)interval;

@end

NS_ASSUME_NONNULL_END
