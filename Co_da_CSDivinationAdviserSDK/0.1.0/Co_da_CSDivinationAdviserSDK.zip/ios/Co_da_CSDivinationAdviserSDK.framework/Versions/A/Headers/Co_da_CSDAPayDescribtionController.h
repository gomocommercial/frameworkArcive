//
//  Co_da_CSDAPayDescribtionController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/24.
//

#import "Co_da_CSDABaseViewController.h"
@class Co_da_CSDATeacherModel;
@class Co_da_CSDAConsultModel;
@class Co_da_CSDAOrderListModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAPayDescribtionController : Co_da_CSDABaseViewController

@property (nonatomic,assign) BOOL isFromOrder;

@property (nonatomic,strong) Co_da_CSDATeacherModel *teacherModel;
@property (nonatomic,strong) Co_da_CSDAConsultModel *consultModel;
@property (nonatomic,strong) NSString *order_code;

@property (nonatomic,strong) Co_da_CSDAOrderListModel *orderModel;



@end

NS_ASSUME_NONNULL_END
