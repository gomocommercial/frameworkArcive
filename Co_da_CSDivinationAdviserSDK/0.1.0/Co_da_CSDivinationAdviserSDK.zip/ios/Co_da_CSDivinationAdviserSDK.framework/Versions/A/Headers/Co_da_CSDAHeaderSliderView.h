//
//  Co_da_CSDAHeaderSliderView.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAHeaderSliderView : UIView

@property (nonatomic,copy) void(^sliderTagBlock)(NSInteger index);

@property (nonatomic,assign) CGFloat progress;

+ (CGFloat)headerHeight;

@end

NS_ASSUME_NONNULL_END
