//
//  Co_da_CSDAConsultDetailCell.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const Co_da_ConsultDetailCell_Normal;
extern NSString *const Co_da_ConsultDetailCell_ChangeHeight;

@interface Co_da_CSDAConsultDetailCell : UITableViewCell

@property (nonatomic,strong) NSString *co_da_titleStr;
@property (nonatomic,strong) NSString *co_da_contentStr;
@property (nonatomic,strong) NSString *co_da_bottomStr;
@property (nonatomic,assign) BOOL needHideLine;

@end

NS_ASSUME_NONNULL_END
