//
//  Co_da_CSDAConsultDetailCell.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const Co_da_ConsultDetailCell_Normal;
extern NSString *const Co_da_ConsultDetailCell_ChangeHeight;

@interface Co_da_CSDAConsultDetailCell : UITableViewCell

@property (nonatomic,strong) NSString *co_da_TitleStr;
@property (nonatomic,strong) NSString *co_da_ContentStr;
@property (nonatomic,strong) NSString *co_da_BottomStr;
@property (nonatomic,assign) BOOL needHideLine;

@end

NS_ASSUME_NONNULL_END
