//
//  Co_da_CSDAMessageSubmitController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import "Co_da_CSDABaseViewController.h"
@class Co_da_CSDATeacherModel;
@class Co_da_CSDAConsultModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAMessageSubmitController : Co_da_CSDABaseViewController

@property (nonatomic,strong) Co_da_CSDATeacherModel *co_da_teacherModel;
@property (nonatomic, copy) NSString *questionTitle;
@property (nonatomic, copy) void(^paySuccess)(Co_da_CSDAConsultModel *model);

@end

NS_ASSUME_NONNULL_END
