//
//  UIView+Co_da_CSDAErrorView.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Co_da_CSDAErrorView)

- (void)co_da_showNetworkErrorViewWithRefreshBlock:(void(^)(void))refreshBlock;
- (void)co_da_showNoContentViewWithRefreshBlock:(void(^)(void))refreshBlock;
- (void)co_da_hideNetworkErrorViewOrNoContentView;

@end

NS_ASSUME_NONNULL_END
