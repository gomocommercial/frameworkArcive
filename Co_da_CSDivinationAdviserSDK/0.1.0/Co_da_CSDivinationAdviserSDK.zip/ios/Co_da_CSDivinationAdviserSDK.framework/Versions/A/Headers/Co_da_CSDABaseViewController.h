//
//  Co_da_CSDABaseViewController.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>
@class Co_da_CSDANavigationBar;
NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDABaseViewController : UIViewController

@property (nonatomic, strong, readonly) Co_da_CSDANavigationBar *co_da_navigationBar;

- (UIView *)co_da_createBackgroundImageView;

- (void)co_da_leftBtnDidClcik;

@end

NS_ASSUME_NONNULL_END
