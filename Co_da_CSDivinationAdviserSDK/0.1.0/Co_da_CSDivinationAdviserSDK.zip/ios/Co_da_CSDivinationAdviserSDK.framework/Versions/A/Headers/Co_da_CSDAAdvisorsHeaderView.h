//
//  Co_da_CSDAAdvisorsHeaderView.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAAdvisorsHeaderView : UIView

@property (nonatomic, strong ,readonly) UILabel *titleLb;
@property (nonatomic, strong, readonly) UIView *lineV;

+ (CGFloat)headerHeight;

@end

NS_ASSUME_NONNULL_END
