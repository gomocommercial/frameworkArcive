//
//  NSString+Co_da_CSDAString.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Co_da_CSDAString)

+ (NSString *)co_da_localizedStringForKey:(NSString *)key;

- (NSString *)co_da_hmacSHA256StrAndBase64WithKey:(NSString *)key;

- (NSString *)co_da_urlSafeStr;

+ (NSData*)co_da_safeUrlBase64Decode:(NSString*)safeUrlbase64Str;


/**
 字符串加密
 
 @param key 秘钥
 @param keyNeedBase64 秘钥是否需要base64编码
 @return 结果
 */
- (NSData *)co_da_encryptUseDES2WithKey:(NSString *)key keyBase64:(BOOL)keyNeedBase64;

/**
 des解密
 
 @param cipherData 解密数据
 @param key 秘钥
 @param keyNeedBase64 s秘钥是否需要base64编码
 @return 结果
 */
+ (NSString *)co_da_decryptUseDES:(NSData *)cipherData key:(NSString *)key keyNeedBase64:(BOOL)keyNeedBase64 urlPath:(NSString *)urlPath;


- (NSMutableAttributedString *)attributedStrWithLineHeight:(CGFloat)lineHeight;

@end

NS_ASSUME_NONNULL_END
