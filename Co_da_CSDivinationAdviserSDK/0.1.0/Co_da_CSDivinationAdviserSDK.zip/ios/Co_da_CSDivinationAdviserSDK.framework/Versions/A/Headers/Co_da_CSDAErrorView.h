//
//  Co_da_CSDAErrorView.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_da_CSDAErrorType) {
    Co_da_CSDAErrorType_NoNetwork,  // 无网络
    Co_da_CSDAErrorType_NoContent,  // 无内容
};

@interface Co_da_CSDAErrorView : UIView

@property (nonatomic, copy) void(^co_da_refreshClickBlock)(void);
@property (nonatomic,assign) Co_da_CSDAErrorType errorType;

@end

NS_ASSUME_NONNULL_END
