//
//  NSBundle+Co_da_CSGiftBundle.h
//  Co_da_CSGiftSDK
//
//  Created by qiaoming on 2019/3/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (Co_da_CSDABundle)

//返回资源文件的bundle
+(NSBundle *)co_da_getDABundlePath;

//读取资源文件的多语言文案
+ (NSString *)co_da_localizedStringForKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
