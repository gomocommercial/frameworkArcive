//
//  Co_da_CSDAGenderView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAGenderView : UIView

@property (nonatomic,strong,readonly) NSString *co_da_genderStr;

@property (nonatomic,assign,readonly) NSInteger co_da_genderIndex;

@property (nonatomic,copy) void(^selectGenderBlock)(NSString *genderStr);

@property (nonatomic,assign,readonly) BOOL co_da_hasEdit;

@end

NS_ASSUME_NONNULL_END
