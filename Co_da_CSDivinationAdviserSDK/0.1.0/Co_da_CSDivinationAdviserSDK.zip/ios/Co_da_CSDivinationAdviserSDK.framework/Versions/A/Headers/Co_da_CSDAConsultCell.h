//
//  Co_da_CSDAConsultCell.h
//  Co_da_CSDivinationAdviserSDK-Co_da_CSDA
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
#import "Co_da_CSDAConsultChatModel.h"
#import "Co_da_CSDAConsultFillMessageCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_CSDAConsultCell : UITableViewCell

@property (nonatomic,strong) Co_da_CSDAConsultChatModel *chatModel;
@property (nonatomic,copy) void(^highlightActionBlock)(Co_da_CSDAConsultCell *cell);
@property (nonatomic,copy) void(^startLoadingBlock)(Co_da_CSDAConsultCell *cell);
@property (nonatomic,copy) void(^failImageActionBlock)(Co_da_CSDAConsultCell *cell);
@property (nonatomic,copy) void(^avatarActionBlock)(Co_da_CSDAConsultCell *cell);

@end

NS_ASSUME_NONNULL_END
