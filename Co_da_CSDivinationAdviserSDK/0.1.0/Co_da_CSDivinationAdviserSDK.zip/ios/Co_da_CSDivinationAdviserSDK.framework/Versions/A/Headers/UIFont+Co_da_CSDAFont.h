//
//  UIFont+Co_da_CSDAFont.h
//  Co_da_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIFont (Co_da_CSDAFont)

+ (UIFont *)co_da_sfProBoldWithSize:(CGFloat)size;

+ (UIFont *)co_da_sfProLightWithSize:(CGFloat)size;

+ (UIFont *)co_da_sfProLightItalicWithSize:(CGFloat)size;

+ (UIFont *)co_da_sfProMediumWithSize:(CGFloat)size;

+ (UIFont *)co_da_sfProRegularWithSize:(CGFloat)size;

+ (UIFont *)co_da_sfProSemiboldWithSize:(CGFloat)size;

+ (UIFont *)co_da_halatSemiBoldWithSize:(CGFloat)size;

+ (UIFont *)co_da_halatBoldWithSize:(CGFloat)size;

+ (UIFont *)co_da_halatMediumWithSize:(CGFloat)size;

+ (UIFont *)co_da_sfProHeavyWithSize:(CGFloat)size;

@end

NS_ASSUME_NONNULL_END
