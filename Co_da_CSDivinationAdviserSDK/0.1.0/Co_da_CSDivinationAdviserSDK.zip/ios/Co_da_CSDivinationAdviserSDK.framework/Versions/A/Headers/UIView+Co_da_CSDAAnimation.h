//
//  UIView+Co_da_CSDAAnimation.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Co_da_CSDAAnimation)

- (void)co_da_loadingAnimation;
- (void)co_da_stopLoadingAnimation;

@end

NS_ASSUME_NONNULL_END
