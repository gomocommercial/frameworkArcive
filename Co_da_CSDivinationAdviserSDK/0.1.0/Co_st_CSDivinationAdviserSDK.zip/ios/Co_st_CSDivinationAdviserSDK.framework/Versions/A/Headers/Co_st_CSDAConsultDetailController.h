//
//  Co_st_CSDAConsultDetailController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/25.
//

#import "Co_st_CSDABaseViewController.h"
@class Co_st_CSDAConsultDetailHeaderView;
@class Co_st_CSDAOrderListModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAConsultDetailController : Co_st_CSDABaseViewController

@property (nonatomic,strong) Co_st_CSDAOrderListModel *orderModel;
@property (nonatomic, assign) NSInteger consult_id;

@end


@interface Co_st_CSDAConsultDetailHeaderView : UIView

@property (nonatomic,strong) Co_st_CSDAOrderListModel *orderModel;

+ (CGFloat)co_st_headerHeight;

@end

NS_ASSUME_NONNULL_END
