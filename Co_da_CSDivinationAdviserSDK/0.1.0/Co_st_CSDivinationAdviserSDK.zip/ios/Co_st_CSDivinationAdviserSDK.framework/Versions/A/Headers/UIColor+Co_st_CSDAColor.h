//
//  UIColor+Co_st_CSDAColor.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (Co_st_CSDAColor)

@property (nonatomic, assign, readonly) CGFloat co_st_red;
@property (nonatomic, assign, readonly) CGFloat co_st_green;
@property (nonatomic, assign, readonly) CGFloat co_st_blue;
@property (nonatomic, assign, readonly) CGFloat co_st_alpha;


+ (UIColor *)co_st_CSDAColorWithHexString:(NSString *)colorStr;

+ (UIColor *)co_st_CSDAColorWithHexString:(NSString *)color alpha:(CGFloat)alpha;

+ (UIColor *)co_st_interpolationColorFrom:(UIColor *)fromColor to:(UIColor *)toColor percent:(CGFloat)percent;

@end

NS_ASSUME_NONNULL_END
