//
//  Co_st_CSDATeacherDetailCell.h
//  Co_st_CSDivinationAdviserSDK-Co_st_CSDA
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDATeacherDetailCell : UITableViewCell

@property (nonatomic, strong ,readonly) UIView *co_st_typesBgView;
@property (nonatomic,copy) NSString *co_st_ImageName;
@property (nonatomic,copy) NSString *co_st_TitleStr;

@end

NS_ASSUME_NONNULL_END
