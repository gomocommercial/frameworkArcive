//
//  Co_st_CSDAAdvisorsCell.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class Co_st_CSDATeacherModel;

@interface Co_st_CSDAAdvisorsCell : UITableViewCell

@property (nonatomic, strong) UIView *lineView;
@property (nonatomic,strong) Co_st_CSDATeacherModel *teacherModel;
@property (nonatomic,copy) void(^chatBlock)(Co_st_CSDATeacherModel *teacherModel);

+ (CGFloat)cellHeight;

@end

NS_ASSUME_NONNULL_END
