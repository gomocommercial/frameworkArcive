//
//  Co_st_CSDAConstant.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// notification
extern NSString *const CO_DA_VISITOR_LOGIN_SUCCESS_NOTIFICATION;
extern NSString *const CO_DA_UPDATE_BALANCE_NOTIFICATION;
extern NSString *const CO_DA_UPDATE_ORDER_NOTIFICATION;


NS_ASSUME_NONNULL_END
