//
//  Co_st_CSDADescriptionInputItemView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>
#import "Co_st_CSDAPlaceHolderTextView.h"

NS_ASSUME_NONNULL_BEGIN

static NSInteger const co_st_descriptionWordLimit = 2000;

@interface Co_st_CSDADescriptionInputItemView : UIView

@property (nonatomic,strong) NSString *co_st_TitleStr;
@property (nonatomic,strong) UILabel *co_st_NumLb;
@property (nonatomic,strong) UILabel *co_st_DescriptionLb;
@property (nonatomic,strong) NSString *co_st_TfPlaceHolderStr;
@property (nonatomic,strong,readonly) Co_st_CSDAPlaceHolderTextView *co_st_textView;
@property (nonatomic,copy) void(^tVEndEditingBlock)(NSString *tVStr);
@property (nonatomic,copy) void(^tVTextChangeBlock)(NSString *tVStr);

@property (nonatomic,assign) BOOL co_st_NeedWordLimit;

@property (nonatomic,assign) CGFloat co_st_MinHeight;

@end

NS_ASSUME_NONNULL_END
