//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Co_st_CSDAPaymentAndPicProtocol.h"
@class Co_st_CSDAInitParams;

@interface Co_st_CSDAApi : NSObject

/*********************************SDK初始化及配置*****************************************/
/**
* 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
* 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
* 推荐debug包，默认打开log配置，方便排查问题。
* @param params 初始化参数，appId,baseUrl,desKey必填，其它选填。
*/
+ (void)co_st_setup:(Co_st_CSDAInitParams *)params delegate:(id<Co_st_CSDAPaymentAndPicProtocol>)delegate;

// 初始化
+ (instancetype)co_st_apiConfig;

@property (nonatomic,strong,readonly) NSString *co_st_userId;
@property (nonatomic,strong,readonly) NSURL *co_st_avatorUrl;
@property (nonatomic,strong,readonly) NSString *co_st_nickName;
@property (nonatomic,strong,readonly) NSString *co_st_accessToken;    //token
@property (nonatomic,assign,readonly) float co_st_balance;//余额

+ (BOOL)isLogin;

// 充值上账
- (void)co_st_rechargeWithProductId:(NSString *)productId tran_id:(NSString *)tran_id Completion:(void (^)(NSError *error,float blance))completion;

// 游客账号自动登录
+ (void)co_st_autoLoginVisitorWithComplete:(void(^ _Nullable)(NSError * _Nullable error))complete;

// 验单失败
- (void)co_st_checkPayReceiptFail:(NSError *)error;

@end
