//
//  Co_st_CSDAAdvisorsDetailController.h
//  Co_st_CSDivinationAdviserSDK-Co_st_CSDA
//
//  Created by 邝路平 on 2019/9/27.
//

#import "Co_st_CSDABaseViewController.h"
@class Co_st_CSDATeacherModel;
NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAAdvisorsDetailController : Co_st_CSDABaseViewController

@property (nonatomic,strong) Co_st_CSDATeacherModel *teacherModel;

@end

NS_ASSUME_NONNULL_END
