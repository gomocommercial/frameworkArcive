//
//  Co_st_CSDAStatistics.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAStatistics : NSObject

+ (Co_st_CSDAStatistics *(^)(NSString *))co_st_operation;

- (Co_st_CSDAStatistics *(^)(NSString *))co_st_statisticsObj;

- (Co_st_CSDAStatistics *(^)(NSString *))co_st_associationObj;

- (Co_st_CSDAStatistics *(^)(NSString *))co_st_enter;

- (Co_st_CSDAStatistics *(^)(NSString *))co_st_tab;

- (Co_st_CSDAStatistics *(^)(NSString *))co_st_remark;

- (Co_st_CSDAStatistics *(^)(NSString *))co_st_position;

- (Co_st_CSDAStatistics *(^)(NSInteger))co_st_orderType;

- (Co_st_CSDAStatistics *(^)(NSString *))co_st_orderId;

- (Co_st_CSDAStatistics *(^)(NSString *))co_st_resultCode;

- (void)co_st_upload104f000;

- (void)co_st_upload104c000;

- (void)co_st_upload104t000;

- (void)co_st_upload59Statistics;

@end

NS_ASSUME_NONNULL_END
