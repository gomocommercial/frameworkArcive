//
//  NSBundle+Co_st_CSGiftBundle.h
//  Co_st_CSGiftSDK
//
//  Created by qiaoming on 2019/3/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (Co_st_CSDABundle)

//返回资源文件的bundle
+(NSBundle *)co_st_getDABundlePath;

//读取资源文件的多语言文案
+ (NSString *)co_st_localizedStringForKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
