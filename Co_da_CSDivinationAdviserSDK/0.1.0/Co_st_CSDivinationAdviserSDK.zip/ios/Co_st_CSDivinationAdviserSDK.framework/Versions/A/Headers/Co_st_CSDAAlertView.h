//
//  Co_st_CSDAAlertView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, Co_st_AlertViewButtonType) {
    Co_st_AlertViewButtonTypeDefault,
    Co_st_AlertViewButtonTypeBold,
};

typedef void (^Co_st_TouchUpInsideBlock)(void);

@interface Co_st_CSDAAlertView : UIView

- (instancetype)initWithTitle:(NSString *)title message:(NSObject *)message;

- (void)addButton:(NSString *)title type:(Co_st_AlertViewButtonType)type actionBlock:(Co_st_TouchUpInsideBlock)block;

- (void)show;

@end

NS_ASSUME_NONNULL_END
