//
//  Co_st_CSDAInputItemView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

static NSInteger const Co_st_InputItemViewWordLimit = 200;

@interface Co_st_CSDAInputItemView : UIView

@property (nonatomic,strong) NSString *co_st_TitleStr;
@property (nonatomic,strong) NSString *co_st_TfPlaceHolderStr;
@property (nonatomic,strong,readonly) UITextField *co_st_textTf;
@property (nonatomic,assign) BOOL co_st_NeedWordLimit;

@property (nonatomic,copy) void(^co_st_TfEndEditingBlock)(NSString *tfStr);

@end

NS_ASSUME_NONNULL_END
