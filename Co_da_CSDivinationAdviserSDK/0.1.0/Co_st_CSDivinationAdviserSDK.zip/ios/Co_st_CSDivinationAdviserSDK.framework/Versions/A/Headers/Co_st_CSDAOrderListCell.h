//
//  Co_st_CSDAOrderListCell.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class Co_st_CSDAOrderListModel;

@interface Co_st_CSDAOrderListCell : UITableViewCell

@property (nonatomic,strong) Co_st_CSDAOrderListModel *orderListModel;

@property (nonatomic,copy) void(^payBlock)(Co_st_CSDAOrderListModel *orderListModel);

- (BOOL)canResetModelListWithTimeOffset:(NSInteger)offset;

+ (CGFloat)cellHeight;

+ (NSString *)CountDownTimeWithInterval:(NSInteger)interval;

@end

NS_ASSUME_NONNULL_END
