//
//  Co_st_CSDAOrderListView.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_st_CSDAOrderType) {
    Co_st_CSDAOrderType_Unpaid = 1,
    Co_st_CSDAOrderType_WaitingReply,
    Co_st_CSDAOrderType_Finished,
    Co_st_CSDAOrderType_Refunded,
};

@interface Co_st_CSDAOrderListView : UIView

@property (nonatomic,assign) Co_st_CSDAOrderType orderType;

@end

NS_ASSUME_NONNULL_END

