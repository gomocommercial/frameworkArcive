//
//  Co_st_CSDAMessageSubmitController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import "Co_st_CSDABaseViewController.h"
@class Co_st_CSDATeacherModel;
@class Co_st_CSDAConsultModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAMessageSubmitController : Co_st_CSDABaseViewController

@property (nonatomic,strong) Co_st_CSDATeacherModel *co_st_teacherModel;
@property (nonatomic, copy) NSString *questionTitle;
@property (nonatomic, copy) void(^paySuccess)(Co_st_CSDAConsultModel *model);

@end

NS_ASSUME_NONNULL_END
