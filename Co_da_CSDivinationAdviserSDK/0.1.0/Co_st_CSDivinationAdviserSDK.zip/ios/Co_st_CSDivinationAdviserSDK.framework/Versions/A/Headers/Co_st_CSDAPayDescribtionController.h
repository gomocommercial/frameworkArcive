//
//  Co_st_CSDAPayDescribtionController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/24.
//

#import "Co_st_CSDABaseViewController.h"
@class Co_st_CSDATeacherModel;
@class Co_st_CSDAConsultModel;
@class Co_st_CSDAOrderListModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAPayDescribtionController : Co_st_CSDABaseViewController

@property (nonatomic,assign) BOOL isFromOrder;

@property (nonatomic,strong) Co_st_CSDATeacherModel *teacherModel;
@property (nonatomic,strong) Co_st_CSDAConsultModel *consultModel;
@property (nonatomic,strong) NSString *order_code;

@property (nonatomic,strong) Co_st_CSDAOrderListModel *orderModel;



@end

NS_ASSUME_NONNULL_END
