//
//  Co_st_CSDADataLoadManager.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^co_st_FailureBlock)(NSError * error);
typedef void (^co_st_SuccessBlock)(id handleResult);

@interface Co_st_CSDADataLoadManager : NSObject

+(instancetype)shareManager;

// 首页老师列表
-(void)co_st_mainAdvisorsWithSuccess:(co_st_SuccessBlock)successBlock failure:(co_st_FailureBlock)failureBlock;

// 查询老师信息详情
- (void)co_st_selectAdvisorDetail:(NSString *)advisorCode
             successBlock:(co_st_SuccessBlock)successBlock
             failureBlock:(co_st_FailureBlock)failureBlock;

// 获取用户订单信息
- (void)co_st_userOrderList:(long)startId
                 size:(NSInteger)size
           orderState:(NSInteger)orderState
               userId:(NSString * )userId
       successBlock:(co_st_SuccessBlock)successBlock
       failureBlock:(co_st_FailureBlock)failureBlock;

// 查询咨询订单
-(void)co_st_co_st_getConsultOrder:(NSString * )consult_id
        successBlock:(co_st_SuccessBlock)successBlock
        failureBlock:(co_st_FailureBlock)failureBlock;

// 获取账户余额
- (void)co_st_getBalanceWithAccountId:(NSString *)accountId
                        Success:(co_st_SuccessBlock)successBlock
                        failure:(co_st_FailureBlock)failureBlock;

// 获取充值商品
- (void)co_st_getrechargeProductSuccess:(co_st_SuccessBlock)successBlock
                          failure:(co_st_FailureBlock)failureBlock;

// 商品充值
- (void)co_st_balanceRechargeWithProductCode:(NSString *)productCode
                         WithAccountId:(NSString *)accountId
                                tranId:(NSString *)tran_id
                               Success:(co_st_SuccessBlock)successBlock
                               failure:(co_st_FailureBlock)failureBlock;

// 余额使用明细
- (void)co_st_getBalanceDetailWithParam:(NSDictionary *)params
                     moreQueryDic:(NSDictionary *)queryDic
                          Success:(co_st_SuccessBlock)successBlock
                          failure:(co_st_FailureBlock)failureBlock;

// 余额消费
- (void)co_st_consumptionWithUserId:(NSString *)userId
                    orderCode:(NSString *)orderCode
                  description:(NSString *)description
               successBlock:(co_st_SuccessBlock)successBlock
               failureBlock:(co_st_FailureBlock)failureBlock;

// 生成订单
- (void)co_st_generateOrderWithParams:(NSDictionary *)params
                 successBlock:(co_st_SuccessBlock)successBlock
                 failureBlock:(co_st_FailureBlock)failureBlock;

// 上传咨询表单
- (void)co_st_uploadConsultationWithParams:(NSDictionary *)params
                      successBlock:(co_st_SuccessBlock)successBlock
                      failureBlock:(co_st_FailureBlock)failureBlock;

// 咨询分类列表
- (void)co_st_advisorTypeWithsuccessBlock:(co_st_SuccessBlock)successBlock
                       failureBlock:(co_st_FailureBlock)failureBlock;

// 按咨询类型归类的老师列表
- (void)co_st_advisorClassifyListWithsuccessBlock:(co_st_SuccessBlock)successBlock
                               failureBlock:(co_st_FailureBlock)failureBlock;

// 查询老师回复
- (void)co_st_selectAdvisorReplyWithConsultId:(NSInteger)consultId
                         successBlock:(co_st_SuccessBlock)successBlock
                         failureBlock:(co_st_FailureBlock)failureBlock;

// 测试老师回复
-(void)co_st_teacherCallOrder_code:(NSString *)order_code consult_id:(NSString *)consult_id successBlock:(co_st_SuccessBlock)successBlock
              failureBlock:(co_st_FailureBlock)failureBlock;


//获取老师短介绍
- (void)co_st_advisorIntroductionWithAdvisorCode:(NSString *)advisorCode
                            successBlock:(co_st_SuccessBlock)successBlock
                            failureBlock:(co_st_FailureBlock)failureBlock;


@end

NS_ASSUME_NONNULL_END
