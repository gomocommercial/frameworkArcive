//
//  Co_st_CSDATeacherDetailStatusView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/11/4.
//

#import <UIKit/UIKit.h>
@class Co_st_CSDATeacherModel;

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDATeacherDetailStatusView : UIView

@property (nonatomic,strong) Co_st_CSDATeacherModel *teacherModel;

+ (CGFloat)headerHeight;

@end

NS_ASSUME_NONNULL_END
