//
//  Co_st_CSDAConsultFillMessageCell.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
@class Co_st_CSDAConsultChatModel;

NS_ASSUME_NONNULL_BEGIN


@interface Co_st_CSDAConsultFillMessageCell : UITableViewCell

@property (nonatomic,strong) Co_st_CSDAConsultChatModel *chatModel;

@property (nonatomic,copy) void(^fillMessageBlock)(Co_st_CSDAConsultFillMessageCell * cell);

@property (nonatomic,copy) void(^avatarActionBlock)(Co_st_CSDAConsultFillMessageCell *cell);

- (void)setBtnEnable:(BOOL)enable;

@end

NS_ASSUME_NONNULL_END
