//
//  Co_st_CSDAConsultChatModel.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_st_ConsultChatMsgType) {
    Co_st_ConsultChatMsgType_Text,
    Co_st_ConsultChatMsgType_Video,
    Co_st_ConsultChatMsgType_Image,
    Co_st_ConsultChatMsgType_Hot,
    Co_st_ConsultChatMsgType_FillMessage,
    Co_st_ConsultChatMsgType_History,
    Co_st_ConsultChatMsgType_CheckInfomation,
    Co_st_ConsultChatMsgType_CheckBalance,

};

typedef NS_ENUM(NSInteger, Co_st_ConsultChatSendType) {
    Co_st_ConsultChatSendType_Sending,
    Co_st_ConsultChatSendType_Failed,
    Co_st_ConsultChatSendType_Done
};


extern NSString *const Co_st_ConsultCell_Mine;
extern NSString *const Co_st_ConsultCell_Teacher;
extern NSString *const Co_st_ConsultCell_Mine_Image;
extern NSString *const Co_st_ConsultCell_Teacher_Image;
extern NSString *const Co_st_ConsultCell_Hot;
extern NSString *const Co_st_ConsultCell_FillMessage;

extern BOOL co_st_messageCanAction;
extern CGFloat const Co_st_ConsultCellWidthMul;

@interface Co_st_CSDAConsultChatModel : NSObject

@property (nonatomic,strong) NSString *createTime;
@property (nonatomic,assign) BOOL isFromMine;
@property (nonatomic,strong) NSString *avatorImageUrl;
@property (nonatomic,strong) NSString *contentStr;
@property (nonatomic,strong) NSString *videoUrl;
@property (nonatomic,strong) NSString *imageUrl;
@property (nonatomic,assign) Co_st_ConsultChatMsgType chatType;
@property (nonatomic,assign) Co_st_ConsultChatSendType sendType;

@property (nonatomic,strong) NSString *cellIdentifier;

@property (nonatomic,strong) UIImage *coverImage;
@property (nonatomic, strong) NSArray<NSString*> *hotMessages;

@end

NS_ASSUME_NONNULL_END
