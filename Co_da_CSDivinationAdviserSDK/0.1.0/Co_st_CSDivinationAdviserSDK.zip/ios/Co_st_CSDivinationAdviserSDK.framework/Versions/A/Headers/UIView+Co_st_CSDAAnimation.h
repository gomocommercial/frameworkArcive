//
//  UIView+Co_st_CSDAAnimation.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Co_st_CSDAAnimation)

- (void)co_st_loadingAnimation;
- (void)co_st_stopLoadingAnimation;

@end

NS_ASSUME_NONNULL_END
