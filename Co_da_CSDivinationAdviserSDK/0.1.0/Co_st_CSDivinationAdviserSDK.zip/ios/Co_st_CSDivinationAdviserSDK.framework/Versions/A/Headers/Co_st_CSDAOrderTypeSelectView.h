//
//  Co_st_CSDAOrderTypeSelectView.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAOrderTypeSelectView : UIView

@property (nonatomic,copy) void(^selectBlock)(NSInteger index);

- (void)setSelectIndex:(NSInteger)selectIndex;

+ (CGFloat)headerHeight;

@end

NS_ASSUME_NONNULL_END
