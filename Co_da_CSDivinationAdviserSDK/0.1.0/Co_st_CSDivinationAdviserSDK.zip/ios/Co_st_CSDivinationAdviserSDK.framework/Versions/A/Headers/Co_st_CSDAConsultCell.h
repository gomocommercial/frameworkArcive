//
//  Co_st_CSDAConsultCell.h
//  Co_st_CSDivinationAdviserSDK-Co_st_CSDA
//
//  Created by 邝路平 on 2019/10/23.
//

#import <UIKit/UIKit.h>
#import "Co_st_CSDAConsultChatModel.h"
#import "Co_st_CSDAConsultFillMessageCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAConsultCell : UITableViewCell

@property (nonatomic,strong) Co_st_CSDAConsultChatModel *chatModel;
@property (nonatomic,copy) void(^highlightActionBlock)(Co_st_CSDAConsultCell *cell);
@property (nonatomic,copy) void(^startLoadingBlock)(Co_st_CSDAConsultCell *cell);
@property (nonatomic,copy) void(^failImageActionBlock)(Co_st_CSDAConsultCell *cell);
@property (nonatomic,copy) void(^avatarActionBlock)(Co_st_CSDAConsultCell *cell);

@end

NS_ASSUME_NONNULL_END
