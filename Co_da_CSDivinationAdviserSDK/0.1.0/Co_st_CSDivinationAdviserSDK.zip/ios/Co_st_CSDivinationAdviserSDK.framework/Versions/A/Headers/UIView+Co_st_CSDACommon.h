//
//  UIView+Co_st_CSDACommon.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>
@class Co_st_CSDALoadingView;

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Co_st_CSDACommon)

- (UIViewController *)co_st_currentController;

- (void)co_st_addClickBlock:(void (^)(NSInteger tag))block;

- (void)co_st_hideLoading;
- (void)co_st_showLoading;

@end

NS_ASSUME_NONNULL_END
