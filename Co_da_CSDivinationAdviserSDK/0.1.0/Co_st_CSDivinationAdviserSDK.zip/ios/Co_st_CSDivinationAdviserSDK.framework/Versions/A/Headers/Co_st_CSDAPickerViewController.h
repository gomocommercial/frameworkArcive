//
//  Co_st_CSDAPickerViewController.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import "Co_st_CSDABaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_st_DatePickerViewType) {
    Co_st_DatePickerViewTypeDate,
    Co_st_DatePickerViewTypeGender,
};

@interface Co_st_CSDAPickerViewController : Co_st_CSDABaseViewController

@property (nonatomic,assign,readonly) CGFloat contentH;

@property (nonatomic, copy) void(^cancelBlock)(void);

@property (nonatomic, copy) void(^didSelectedBlock)(NSString *dateStr);

- (instancetype)initWithType:(Co_st_DatePickerViewType)type;

- (void)show;

@end

NS_ASSUME_NONNULL_END
