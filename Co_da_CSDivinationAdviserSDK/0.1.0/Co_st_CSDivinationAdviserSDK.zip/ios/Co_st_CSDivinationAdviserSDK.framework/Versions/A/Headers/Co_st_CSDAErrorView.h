//
//  Co_st_CSDAErrorView.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, Co_st_CSDAErrorType) {
    Co_st_CSDAErrorType_NoNetwork,  // 无网络
    Co_st_CSDAErrorType_NoContent,  // 无内容
};

@interface Co_st_CSDAErrorView : UIView

@property (nonatomic, copy) void(^co_st_refreshClickBlock)(void);
@property (nonatomic,assign) Co_st_CSDAErrorType errorType;

@end

NS_ASSUME_NONNULL_END
