//
//  Co_st_CSDABaseViewController.h
//  Co_st_CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>
@class Co_st_CSDANavigationBar;
NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDABaseViewController : UIViewController

@property (nonatomic, strong, readonly) Co_st_CSDANavigationBar *co_st_navigationBar;

- (UIView *)co_st_createBackgroundImageView;

- (void)co_st_leftBtnDidClcik;

@end

NS_ASSUME_NONNULL_END
