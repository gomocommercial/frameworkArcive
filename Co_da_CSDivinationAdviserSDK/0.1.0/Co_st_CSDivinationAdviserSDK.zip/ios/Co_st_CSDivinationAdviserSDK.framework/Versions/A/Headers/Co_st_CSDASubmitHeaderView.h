//
//  Co_st_CSDASubmitHeaderView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDASubmitHeaderView : UIView

@property (nonatomic,strong) NSString *co_st_NameStr;
@property (nonatomic,strong) NSString *co_st_AvatorUrl;


@end

NS_ASSUME_NONNULL_END
