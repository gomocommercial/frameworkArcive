//
//  Co_st_CSDAGenderView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_CSDAGenderView : UIView

@property (nonatomic,strong,readonly) NSString *co_st_genderStr;

@property (nonatomic,assign,readonly) NSInteger co_st_genderIndex;

@property (nonatomic,copy) void(^selectGenderBlock)(NSString *genderStr);

@property (nonatomic,assign,readonly) BOOL co_st_hasEdit;

@end

NS_ASSUME_NONNULL_END
