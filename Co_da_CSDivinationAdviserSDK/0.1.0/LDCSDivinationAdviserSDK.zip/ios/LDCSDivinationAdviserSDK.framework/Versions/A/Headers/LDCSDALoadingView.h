//
//  LDCSDALoadingView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LDCSDALoadingView : UIView

+ (instancetype)lDloadingViewWithImage:(UIImage *)image titleStr:(NSString *)titleStr;

@end

NS_ASSUME_NONNULL_END
