//
//  CSDAUserInfoModel.h
//  AFNetworking
//
//  Created by 邝路平 on 2020/5/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSDAUserInfoModel : NSObject

@property (nonatomic,copy) NSString *userID;
@property (nonatomic,copy) NSString *nickname;//昵称
@property (nonatomic,copy) NSURL *avatar;//头像
@property (nonatomic,copy) NSString *accessToken;//token
@property (nonatomic,copy) NSString *userType;

@end

NS_ASSUME_NONNULL_END
