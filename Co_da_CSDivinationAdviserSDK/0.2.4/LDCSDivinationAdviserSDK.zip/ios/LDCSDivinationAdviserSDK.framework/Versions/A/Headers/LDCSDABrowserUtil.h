//
//  LDCSDABrowserUtil.h
//  LDCSDivinationAdviserSDK-LDCSDA
//
//  Created by 邝路平 on 2019/10/27.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class LDCSDABrowserController;

NS_ASSUME_NONNULL_BEGIN

@interface LDCSDABrowserUtil : NSObject

+ (UIWindow *)mainWindow;

+ (UIViewController *)topController;



@end

NS_ASSUME_NONNULL_END
