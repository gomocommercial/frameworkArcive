//
//  UIView+LDCSDAAnimation.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/27.
//


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (LDCSDAAnimation)

- (void)lDloadingAnimation;
- (void)lDstopLoadingAnimation;

@end

NS_ASSUME_NONNULL_END
