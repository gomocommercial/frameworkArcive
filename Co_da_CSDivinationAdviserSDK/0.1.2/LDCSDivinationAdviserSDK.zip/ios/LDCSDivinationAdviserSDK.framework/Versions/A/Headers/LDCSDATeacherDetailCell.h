//
//  LDCSDATeacherDetailCell.h
//  LDCSDivinationAdviserSDK-LDCSDA
//
//  Created by 邝路平 on 2019/9/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LDCSDATeacherDetailCell : UITableViewCell

@property (nonatomic, strong ,readonly) UIView *lDtypesBgView;
@property (nonatomic,copy) NSString *lDImageName;
@property (nonatomic,copy) NSString *lDTitleStr;

@end

NS_ASSUME_NONNULL_END
