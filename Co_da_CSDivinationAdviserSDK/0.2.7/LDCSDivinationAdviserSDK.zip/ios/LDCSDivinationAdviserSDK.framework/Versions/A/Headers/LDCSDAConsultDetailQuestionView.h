//
//  LDCSDAConsultDetailQuestionView.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/11/5.
//

#import <UIKit/UIKit.h>
@class LDCSDAOrderListModel;

NS_ASSUME_NONNULL_BEGIN

@interface LDCSDAConsultDetailQuestionView : UIView

@property (nonatomic,strong) LDCSDAOrderListModel *orderModel;

@end

NS_ASSUME_NONNULL_END
