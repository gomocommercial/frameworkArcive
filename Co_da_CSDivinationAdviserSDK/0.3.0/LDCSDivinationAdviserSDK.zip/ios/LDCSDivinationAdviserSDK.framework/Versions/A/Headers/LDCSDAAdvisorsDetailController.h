//
//  LDCSDAAdvisorsDetailController.h
//  LDCSDivinationAdviserSDK-LDCSDA
//
//  Created by 邝路平 on 2019/9/27.
//

#import "LDCSDABaseViewController.h"
@class LDCSDATeacherModel;
NS_ASSUME_NONNULL_BEGIN

@interface LDCSDAAdvisorsDetailController : LDCSDABaseViewController

@property (nonatomic,strong) LDCSDATeacherModel *teacherModel;
@property (nonatomic,strong) NSString *positionStr;

@end

NS_ASSUME_NONNULL_END
