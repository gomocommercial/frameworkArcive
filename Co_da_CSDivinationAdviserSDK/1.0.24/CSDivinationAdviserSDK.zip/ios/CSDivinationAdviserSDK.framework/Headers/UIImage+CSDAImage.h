//
//  UIImage+CSDAImage.h
//  CSDivinationAdviserSDK
//
//  Created by Zy on 2019/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (CSDAImage)

+ (UIImage *)daImageWithName:(NSString *)name;

+ (UIImage *)horizontalGradientStartColor:(UIColor *)startColor endColor:(UIColor *)endColor size:(CGSize)size;

+ (UIImage *)verticalGradientStartColor:(UIColor *)startColor endColor:(UIColor *)endColor size:(CGSize)size;

// 压缩图片到指定大小(单位KB)
+ (NSData *)resetSizeOfImageData:(UIImage *)sourceImage maxSize:(NSInteger)maxSize;

/**
 *  用color生成image
 *
 *  @param color 颜色
 */
+ (UIImage *)imageWithColor:(UIColor *)color;

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;

/**
*   按大小缩放
*/
- (UIImage *)imageScaledToSize:(CGSize)size;

/**
*   最小缩放
*/
- (UIImage *)imageScaledToFitSize:(CGSize)size;

/**
*   最大缩放
*/
- (UIImage *)imageScaledToFillSize:(CGSize)size;


@end

NS_ASSUME_NONNULL_END
