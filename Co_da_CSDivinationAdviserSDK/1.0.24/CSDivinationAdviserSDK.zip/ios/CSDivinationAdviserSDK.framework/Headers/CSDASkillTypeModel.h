//
//  CSDASkillTypeModel.h
//  AFNetworking
//
//  Created by 邝路平 on 2020/5/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSDASkillTypeModel : NSObject

// String    否    技能名称
@property (nonatomic,strong) NSString *skillName;
// String    否    背景URL
@property (nonatomic,strong) NSString *imageUrl;
// String    否    描述
@property (nonatomic,strong) NSString *desc;

@end

NS_ASSUME_NONNULL_END
