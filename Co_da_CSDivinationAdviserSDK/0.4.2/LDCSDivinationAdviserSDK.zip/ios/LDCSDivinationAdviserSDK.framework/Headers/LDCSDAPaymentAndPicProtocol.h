//
//  LDCSDAPaymentAndPicProtocol.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/10/30.
//

#import <Foundation/Foundation.h>
#import "LDCSDAProductModel.h"
NS_ASSUME_NONNULL_BEGIN

@protocol LDCSDAPaymentAndPicProtocol <NSObject>

// 支付
-(void)lDpaymentDidPayWithExpendProduct:(LDCSDAProductModel *)expendProduct subscribeProducts:(NSArray <LDCSDAProductModel *> *)subscribeProducts;

// 图片上传
-(void)lDpictureDidUploadWithImage:(UIImage *)image Completion:(void(^)(BOOL isSuccess,NSString *imageUrl))completion;

// 用户个人中心跳转
-(void)lDUserCenterDidClickFromVc:(UIViewController *)fromVc;


@end

NS_ASSUME_NONNULL_END
