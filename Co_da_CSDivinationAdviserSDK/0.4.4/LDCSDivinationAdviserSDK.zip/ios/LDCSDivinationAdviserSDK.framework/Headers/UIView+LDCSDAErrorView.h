//
//  UIView+LDCSDAErrorView.h
//  LDCSDivinationAdviserSDK
//
//  Created by 邝路平 on 2019/9/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (LDCSDAErrorView)

-(void)lDshowNetworkErrorViewNeedLoading:(BOOL)needLoading WithRefreshBlock:(void(^)(void))needRefreshBlock;
-(void)lDshowNoContentViewWithMsg:(NSString *)errorMsg NeedLoading:(BOOL)needLoading refreshBlock:(void(^)(void))needRefreshBlock;
- (void)lDhideNetworkErrorViewOrNoContentView;

@end

NS_ASSUME_NONNULL_END
