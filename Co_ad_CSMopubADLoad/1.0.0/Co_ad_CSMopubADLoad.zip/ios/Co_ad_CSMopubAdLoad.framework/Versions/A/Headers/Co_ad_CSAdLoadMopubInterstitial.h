//
//  CSAdMopubInterstitial.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <mopub-ios-sdk/MoPub.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadInterstitial.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadProtocol.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdLoadMopubInterstitial : Co_ad_CSAdLoadInterstitial<Co_ad_CSAdLoadProtocol,MPInterstitialAdControllerDelegate>

@property (nonatomic, strong) MPInterstitialAdController *ad;

@end

NS_ASSUME_NONNULL_END
