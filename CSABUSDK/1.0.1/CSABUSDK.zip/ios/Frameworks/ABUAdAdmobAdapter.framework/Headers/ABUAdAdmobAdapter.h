//
//  ABUAdAdmobAdapter.h
//  ABUAdAdmobAdapter
//
//  Created by wangchao on 2020/3/12.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ABUAdmobPersonaliseConfigAdapter.h"
