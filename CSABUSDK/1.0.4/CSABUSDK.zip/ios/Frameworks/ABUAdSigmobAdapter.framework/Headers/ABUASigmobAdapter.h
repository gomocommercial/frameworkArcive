//
//  ABUAdSigmobAdapter.h
//  Pods
//
//  Created by bytedance on 2021/12/7.
//

#ifndef ABUAdSigmobAdapter_h
#define ABUAdSigmobAdapter_h


#endif /* ABUAdSigmobAdapter_h */
