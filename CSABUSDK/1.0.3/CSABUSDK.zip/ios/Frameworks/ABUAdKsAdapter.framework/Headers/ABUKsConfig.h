//
//  ABUKsConfig.h
//  ABUAdSDK
//
//  Created by Makaiwen on 2021/5/31.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUKsConfig : NSObject <ABUCustomConfigAdapter>

@end

NS_ASSUME_NONNULL_END
