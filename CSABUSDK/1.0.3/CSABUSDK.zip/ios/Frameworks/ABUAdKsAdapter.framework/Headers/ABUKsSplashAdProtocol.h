//
//  ABUKsSplashAdProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/16.
//

#import <Foundation/Foundation.h>
#import "ABUKsCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABUKs_KSSplashAdView;

typedef UIView<ABUKs_KSSplashAdView> KSSplashAdView;

@protocol ABUKs_KSAdSplashInteractDelegate <NSObject>

@optional
/**
 * 闪屏广告展示
 */
- (void)ksad_splashAdDidShow;
/**
 * 闪屏广告点击转化
 */
- (void)ksad_splashAdClicked;
/**
 * 视频闪屏广告开始播放
 */
- (void)ksad_splashAdVideoDidStartPlay;
/**
 * 视频闪屏广告播放失败
 */
- (void)ksad_splashAdVideoFailedToPlay:(NSError *)error;
/**
 * 视频闪屏广告跳过
 */
- (void)ksad_splashAdVideoDidSkipped:(NSTimeInterval)playDuration;
/**
 * 闪屏广告关闭，需要在这个方法里关闭闪屏页面
 * @param converted      是否转化
 */
- (void)ksad_splashAdDismiss:(BOOL)converted;
/**
 * 转化控制器容器，如果未实现则默认闪屏页面的上级控制器
 */
- (UIViewController *)ksad_splashAdConversionRootVC;

@end

@protocol ABUKs_KSSplashAdViewDelegate <NSObject>
@optional
/**
 * splash ad request done
 */
- (void)ksad_splashAdDidLoad:(KSSplashAdView *)splashAdView;
/**
 * splash ad material load, ready to display
 */
- (void)ksad_splashAdContentDidLoad:(KSSplashAdView *)splashAdView;
/**
 * splash ad (material) failed to load
 */
- (void)ksad_splashAd:(KSSplashAdView *)splashAdView didFailWithError:(NSError *)error;
/**
 * splash ad did visible
 */
- (void)ksad_splashAdDidVisible:(KSSplashAdView *)splashAdView;
/**
 * splash ad video begin play
 * for video ad only
 */
- (void)ksad_splashAdVideoDidBeginPlay:(KSSplashAdView *)splashAdView;
/**
 * splash ad clicked
 * @param inMiniWindow whether click in mini window
 */
- (void)ksad_splashAd:(KSSplashAdView *)splashAdView didClick:(BOOL)inMiniWindow;
/**
 * splash ad will zoom out, frame can be assigned
 * for video ad only
 * @param frame target frame
 */
- (void)ksad_splashAd:(KSSplashAdView *)splashAdView willZoomTo:(inout CGRect *)frame;
/**
 * splash ad zoomout view will move to frame
 * @param frame target frame
 */
- (void)ksad_splashAd:(KSSplashAdView *)splashAdView willMoveTo:(inout CGRect *)frame;
/**
 * splash ad skipped
 * @param showDuration  splash show duration (no subsequent callbacks, remove & release KSSplashAdView here)
 */
- (void)ksad_splashAd:(KSSplashAdView *)splashAdView didSkip:(NSTimeInterval)showDuration;
/**
 * splash ad close conversion viewcontroller (no subsequent callbacks, remove & release KSSplashAdView here)
 */
- (void)ksad_splashAdDidCloseConversionVC:(KSSplashAdView *)splashAdView interactionType:(NSInteger)interactType;
/**
 * splash ad play finished & auto dismiss (no subsequent callbacks, remove & release KSSplashAdView here)
 */
- (void)ksad_splashAdDidAutoDismiss:(KSSplashAdView *)splashAdView;
/**
 * splash ad close by user (zoom out mode) (no subsequent callbacks, remove & release KSSplashAdView here)
 */
- (void)ksad_splashAdDidClose:(KSSplashAdView *)splashAdView;

@end

@protocol ABUKs_KSSplashAdView <ABUKs_KSAd>
- (id)initWithPosId:(NSString *)posId;
- (void)loadAdData;
- (void)setDelegate:(id<ABUKs_KSSplashAdViewDelegate>)delegate;
- (void)setRootViewController:(UIViewController *)rootViewController;
- (void)setTimeoutInterval:(NSTimeInterval)timeoutInterval;
- (void)setNeedShowMiniWindow:(BOOL)needShowMiniWindow;
- (void)showInView:(UIView *)view;

@property (nonatomic, readonly) BOOL showingMiniWindow;

@end

@protocol ABUKs_KSAdSplashManager <NSObject>

- (void)setPosId:(NSString *)posId;
- (BOOL)loadSplash;
- (void)checkSplashWithTimeout:(NSTimeInterval)timeoutInterval completion:(void (^)(UIViewController * _Nullable splashViewController))callback;
- (void)checkSplashWithTimeoutv2:(NSTimeInterval)timeoutInterval
                    loadCallback:(void (^)(NSError *error))loadCallback
                      completion:(void (^)(UIViewController * _Nullable splashViewController, NSError * _Nullable error))finishCallback;
- (void)setInteractDelegate:(id<ABUKs_KSAdSplashInteractDelegate>)delegate;
@end


NS_ASSUME_NONNULL_END
