//
//  ABUKsNativeAdProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/16.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, KSAdInteractionType) {
    KSAdInteractionType_Unknown,        //unknown type
    KSAdInteractionType_App,            //open downlaod page in app
    KSAdInteractionType_Web,            //open webpage in app
    KSAdInteractionType_DeepLink,       //open deeplink
    KSAdInteractionType_AppStore,       //open appstore
};

typedef NS_ENUM(NSInteger, KSAdMaterialType) {
    KSAdMaterialTypeUnkown      =       0,      // unknown
    KSAdMaterialTypeVideo       =       1,      // video
    KSAdMaterialTypeSingle      =       2,      // single image
    KSAdMaterialTypeAtlas       =       3,      // multiple image
};

@protocol ABUKs_KSAdImage <NSObject>
// image address URL
@property (nonatomic, copy) NSString *imageURL;

@property (nonatomic, strong, nullable) UIImage *image;

// image width
@property (nonatomic, assign) float width;

// image height
@property (nonatomic, assign) float height;
@end
typedef NSObject<ABUKs_KSAdImage> KSAdImage;

@protocol ABUKs_KSVideoAdView <NSObject>

@property (nonatomic, assign, readwrite) BOOL videoSoundEnable;
@property (nonatomic, assign, readwrite) BOOL playFinished;

@end
typedef UIView<ABUKs_KSVideoAdView> KSVideoAdView;

@protocol ABUKs_KSMaterialMeta <NSObject>

/// interaction types supported by ads.
@property (nonatomic, assign) NSInteger interactionType;

/// material pictures.
@property (nonatomic, strong) NSArray<KSAdImage *> *imageArray;

/// ad logo icon.
@property (nonatomic, strong, nullable) KSAdImage *sdkLogo;
@property (nonatomic, strong, nullable) KSAdImage *appIconImage;

/// 0-5
@property (nonatomic, assign) CGFloat appScore;
/// downloadCountDesc.
@property (nonatomic, copy) NSString *appDownloadCountDesc;

/// ad description.
@property (nonatomic, copy) NSString *adDescription;

/// ad source.
@property (nonatomic, copy) NSString *adSource;

/// text displayed on the creative button.
@property (nonatomic, copy) NSString *actionDescription;

/// display format of the in-feed ad, other ads ignores it.
@property (nonatomic, assign) NSInteger materialType;

// video duration
@property (nonatomic, assign) NSInteger videoDuration;

@property (nonatomic, strong) KSAdImage *videoCoverImage;

@property (nonatomic, copy) NSString *videoUrl;
// app name
@property (nonatomic, copy) NSString *appName;
// product name (for h5)
@property (nonatomic, copy) NSString *productName;

@end
typedef NSObject<ABUKs_KSMaterialMeta> KSMaterialMeta;

@protocol ABUKs_KSNativeAdDelegate;
@protocol ABUKs_KSNativeAd <NSObject>

@property (nonatomic, readonly) NSInteger ecpm;

@property (nonatomic, strong, readonly, nullable) KSMaterialMeta *data;

@property (nonatomic, weak, readwrite, nullable) id<ABUKs_KSNativeAdDelegate> delegate;

@property (nonatomic, weak, readwrite) UIViewController *rootViewController;

- (void)registerContainer:(__kindof UIView *)containerView withClickableViews:(NSArray<__kindof UIView *> *_Nullable)clickableViews;
@end
typedef NSObject<ABUKs_KSNativeAd> KSNativeAd;

@protocol ABUKs_KSNativeAdRelatedView <NSObject>

/**
 Promotion label.Need to actively add to the view.
 */
@property (nonatomic, strong, readonly, nullable) UILabel *adLabel;


/**
 Video ad view. Need to actively add to the view.
 */
@property (nonatomic, strong, readonly, nullable) KSVideoAdView *videoAdView;

/**
 Refresh the data every time you get new datas in order to show ad perfectly.
 */
- (void)refreshData:(KSNativeAd *)nativeAd;
@end
typedef NSObject<ABUKs_KSNativeAdRelatedView> KSNativeAdRelatedView;


@protocol ABUKs_KSNativeAdDelegate <NSObject>

@optional

/**
 This method is called when native ad material loaded successfully.
 */
- (void)nativeAdDidLoad:(KSNativeAd *)nativeAd;

/**
 This method is called when native ad materia failed to load.
 @param error : the reason of error
 */
- (void)nativeAd:(KSNativeAd *)nativeAd didFailWithError:(NSError *_Nullable)error;

/**
 This method is called when native ad slot has been shown.
 */
- (void)nativeAdDidBecomeVisible:(KSNativeAd *)nativeAd;

/**
 This method is called when native ad is clicked.
 */
- (void)nativeAdDidClick:(KSNativeAd *)nativeAd withView:(UIView *_Nullable)view;

/**
This method is called when another controller has been showed.
@param interactionType : open appstore in app or open the webpage or view video ad details page.
*/
- (void)nativeAdDidShowOtherController:(KSNativeAd *)nativeAd interactionType:(KSAdInteractionType)interactionType;

/**
 This method is called when another controller has been closed.
 @param interactionType : open appstore in app or open the webpage or view video ad details page.
 */
- (void)nativeAdDidCloseOtherController:(KSNativeAd *)nativeAd interactionType:(KSAdInteractionType)interactionType;

@end

@protocol ABUKs_KSFeedAdDelegate;

@protocol ABUKs_KSFeedAd <NSObject>
@property (nonatomic, weak) id<ABUKs_KSFeedAdDelegate> delegate;
@property (nonatomic, readonly) UIView *feedView;

@end

typedef NSObject<ABUKs_KSFeedAd> KSFeedAd;

@protocol ABUKs_KSFeedAdDelegate <NSObject>
@optional
- (void)feedAdViewWillShow:(KSFeedAd *)feedAd;
- (void)feedAdDidClick:(KSFeedAd *)feedAd;
- (void)feedAdDislike:(KSFeedAd *)feedAd;
- (void)feedAdDidShowOtherController:(KSFeedAd *)nativeAd interactionType:(NSInteger)interactionType;
- (void)feedAdDidCloseOtherController:(KSFeedAd *)nativeAd interactionType:(NSInteger)interactionType;

@end


@protocol ABUKs_KSFeedAdsManager;
typedef NSObject<ABUKs_KSFeedAdsManager> KSFeedAdsManager;

@protocol ABUKs_KSFeedAdsManagerDelegate <NSObject>
@optional

- (void)feedAdsManagerSuccessToLoad:(KSFeedAdsManager *)adsManager nativeAds:(NSArray *_Nullable)feedAdDataArray;

- (void)feedAdsManager:(KSFeedAdsManager *)adsManager didFailWithError:(NSError *_Nullable)error;

@end

@protocol ABUKs_KSFeedAdsManager <NSObject>
@property (nonatomic, strong, readonly) NSArray *data;

- (instancetype)initWithPosId:(NSString *)posId size:(CGSize)size;
@property (nonatomic, weak, nullable) id<ABUKs_KSFeedAdsManagerDelegate> delegate;

- (void)loadAdDataWithCount:(NSInteger)count;

@end


@protocol ABUKs_KSNativeAdsManager;
typedef NSObject<ABUKs_KSNativeAdsManager> KSNativeAdsManager;

@protocol ABUKs_KSNativeAdsManagerDelegate <NSObject>
@optional
- (void)nativeAdsManagerSuccessToLoad:(KSNativeAdsManager *)adsManager nativeAds:(NSArray *_Nullable)nativeAdDataArray;

- (void)nativeAdsManager:(KSNativeAdsManager *)adsManager didFailWithError:(NSError *_Nullable)error;

@end

@protocol ABUKs_KSNativeAdsManager <NSObject>
@property (nonatomic, strong, nullable) NSArray<KSNativeAd *> *data;

@property (nonatomic, weak, nullable) id<ABUKs_KSNativeAdsManagerDelegate> delegate;

- (id)initWithPosId:(NSString *)posId;

- (void)loadAdDataWithCount:(NSInteger)count;

@end

NS_ASSUME_NONNULL_END
