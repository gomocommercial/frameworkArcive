//
//  ABUDictionary+UValue.h
//  Ads-Mediation-CN
//
//  Created by heyinyin on 2023/5/17.
//

#import "ABUDictionary.h"
#import "ABUDictionary+internal.h"
NS_ASSUME_NONNULL_BEGIN

@interface ABUDictionary (UValue)
+ (ABUUValueApiCalled)hasLabelApiCalled;
@end

NS_ASSUME_NONNULL_END
