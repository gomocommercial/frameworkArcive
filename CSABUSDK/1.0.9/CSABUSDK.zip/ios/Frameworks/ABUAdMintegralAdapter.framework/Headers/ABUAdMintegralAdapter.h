//
//  ABUAdMintegralAdapter.h
//  Pods
//
//  Created by bytedance on 2021/12/7.
//

#ifndef ABUAdMintegralAdapter_h
#define ABUAdMintegralAdapter_h


#endif /* ABUAdMintegralAdapter_h */
