//
//  ABUKlevinSplashAdProtocol2.h
//  ABUAdSDK
//
//  Created by heyinyin on 2021/10/20.
//

#import <Foundation/Foundation.h>

#import "ABUKlevinCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABUKlevin_KLNSplashAd;
typedef void (^KLNSplashAdLoadCompletionHandler)(id<ABUKlevin_KLNSplashAd> interstitialAd,
                                                       NSError *_Nullable error);


@protocol ABUKlevin_KLNSplashAd <NSObject>

@property (nonatomic, weak, nullable) id<ABUKlevin_KLNFullScreenContentDelegate> fullScreenContentDelegate;

/// Controller for video play
@property (nonatomic, strong, readonly, nullable) KLNAdVideoController *videoController;

/// 加载开屏广告方法
///
/// @param request 开屏广告请求对象
/// @param completionHandler 广告加载结果回调（成功/失败），请注意：回调非线程安全
+ (void)loadWithRequest:(nonnull KLNSplashAdRequest *)request
      completionHandler:(KLNSplashAdLoadCompletionHandler)completionHandler;

/// 判断开屏广告是否可展示方法，请在主线程调用
/// Returns whether the splash ad can be presented from the provided root view
/// controller. Sets the error out parameter if the ad can't be presented. Must be called on the
/// main thread.
/// @param rootViewController 视图对象
/// @param error 错误信息
- (BOOL)canPresentFromRootViewController:(UIViewController *)rootViewController
                                   error:(NSError *_Nullable __autoreleasing *_Nullable)error;

/// 开屏广告展示方法，请在主线程调用
/// Presents the splash ad. Must be called on the main thread.
/// @param rootViewController A view controller to present the ad.
- (void)presentFromRootViewController:(UIViewController *)rootViewController;

@end
typedef NSObject<ABUKlevin_KLNSplashAd> KLNSplashAd;


NS_ASSUME_NONNULL_END
