//
//  ABUKsCommonProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// SDK初始化方法回调 [KlevinAdSDK startWithCompletionHandler:]
/// error为空则表示初始化成功，回调非线程安全
typedef void (^KLNAdInitializationCompletionHandler)(NSError *_Nullable error);


@protocol ABUKlevin_KlevinAdSDK <NSObject>

/// 当前SDK版本号
+ (NSString *)sdkVersion;

/// 返回KlevinAdSDK实体（单例）
+ (id<ABUKlevin_KlevinAdSDK>)sharedInstance;

/// 初始化SDK，从Info.plist 读取KlevinApplicationIdentifier配置
/// 相关配置方式见文档说明：集成及初始化SDK
/// @param completionHandler 初始化结果回调 ，非线程安全
- (void)startWithCompletionHandler:(nullable KLNAdInitializationCompletionHandler)completionHandler;

/// 输出SDK调试信息
- (void)enableDebugLogout;

/// 是否允许获取定位信息，权限需由接入方获取，SDK不会主动弹框申请
/// 基于用户地理信息，系统能推荐更精准的个性化广告，提升广告收益
/// 默认为YES
- (void)enableGPS:(BOOL)enabled;

/// 初始化SDK
/// @param appId 平台注册APPID
/// @param completionHandler 初始化结果回调 ，非线程安全
- (void)startWithAppId:(NSString *)appId withCompletionHandler:(nullable KLNAdInitializationCompletionHandler)completionHandler;

@end
typedef NSObject<ABUKlevin_KlevinAdSDK> KlevinAdSDK;


@protocol ABUKlevin_KLNAdVideoControllerDelegate;
@protocol ABUKlevin_KLNAdVideoController <NSObject>

/// Delegate for receiving video notifications.
@property(nonatomic, weak, nullable) id<ABUKlevin_KLNAdVideoControllerDelegate> delegate;

@end
typedef NSObject<ABUKlevin_KLNAdVideoController> KLNAdVideoController;



@protocol ABUKlevin_KLNAdVideoControllerDelegate <NSObject>

/// Tells the delegate that the video controller has began or resumed playing a video.
/// @param videoController controller instance
- (void)videoControllerDidPlayVideo:(nonnull KLNAdVideoController *)videoController;

/// Tells the delegate that the video controller has paused video.
/// @param videoController controller instance
- (void)videoControllerDidPauseVideo:(nonnull KLNAdVideoController *)videoController;

/// Tells the delegate that the video controller's video playback has ended.
/// @param videoController controller instance
- (void)videoControllerDidEndVideoPlayback:(nonnull KLNAdVideoController *)videoController;

/// Tells the delegate that the video controller has muted video.
/// @param videoController controller instance
- (void)videoControllerDidMuteVideo:(nonnull KLNAdVideoController *)videoController;

/// Tells the delegate that the video controller has unmuted video.
/// @param videoController controller instance
- (void)videoControllerDidUnmuteVideo:(nonnull KLNAdVideoController *)videoController;

@end


@protocol ABUKlevin_KLNAdRequest <NSObject>

/// 广告位ID
@property (nonatomic, copy, readonly) NSString *posId;

/// 请求ID
@property (nonatomic, copy, readonly) NSString *requestId;

- (instancetype)initWithPosId:(NSString *)posId;

@end
typedef NSObject<ABUKlevin_KLNAdRequest> KLNAdRequest;


@protocol ABUKlevin_KLNInterstitialAdRequest <ABUKlevin_KLNAdRequest>

@end
typedef KLNAdRequest<ABUKlevin_KLNInterstitialAdRequest> KLNInterstitialAdRequest;


@protocol ABUKlevin_KLNRewardedAdRequest <ABUKlevin_KLNAdRequest>

/// 激励视频播放是否自动静音
/// @discussion 不设置，默认NO，非静音播放
@property (nonatomic) BOOL autoMute;

/// 触发的激励类型，1：复活；2：签到；3：道具；4：虚拟货币；5：其他
/// @discussion 不设置，则默认为5
@property (nonatomic) NSUInteger rewardTrigger;

/// 激励卡秒时长
/// @discussion 默认为视频时长/赋值大于视频时长或者为非正数时，SDK以视频时长为准
@property (nonatomic) NSUInteger rewardTime;

@end
typedef KLNAdRequest<ABUKlevin_KLNRewardedAdRequest> KLNRewardedAdRequest;

@protocol ABUKlevin_KLNSplashAdRequest <ABUKlevin_KLNAdRequest>

/// 超时时长
@property (nonatomic) NSUInteger timeout;

@end
typedef KLNAdRequest<ABUKlevin_KLNSplashAdRequest> KLNSplashAdRequest;


@protocol ABUKlevin_KLNFullScreenContentDelegate;
/// 全屏类型广告协议（开屏/插屏/激励 均遵循此协议）
@protocol ABUKlevin_KLNFullScreenPresentingAd <NSObject>
/// 全屏视图展示/销毁消息回调代理
@property (nonatomic, weak, nullable) id<ABUKlevin_KLNFullScreenContentDelegate> fullScreenContentDelegate;
@end


@protocol ABUKlevin_KLNFullScreenContentDelegate <NSObject>

/// 广告曝光上报成功回调方法
/// 业务方可以通过实现该方法，统计｜曝光｜量（对账）
/// @param ad 广告对象
- (void)adDidRecordImpression:(nonnull id<ABUKlevin_KLNFullScreenPresentingAd>)ad;

/// 广告响应点击事件回调方法
/// 业务方可以通过实现该方法，统计｜点击｜量（对账）
/// @param ad 广告对象
- (void)adDidRecordClick:(nonnull id<ABUKlevin_KLNFullScreenPresentingAd>)ad;

/// 广告响应跳过回调方法
/// 业务方可以通过实现该方法，统计广告｜跳过｜量（对账）
/// @param ad 广告对象
- (void)adDidRecordSkip:(nonnull id<ABUKlevin_KLNFullScreenPresentingAd>)ad;

/// 广告展示失败回调方法
/// 业务方可以通过实现该方法，处理广告展示失败事件；比如重新拉取广告
/// @param ad 广告对象
/// @param error 错误信息
- (void)ad:(nonnull id<ABUKlevin_KLNFullScreenPresentingAd>)ad
    didFailToPresentFullScreenContentWithError:(nonnull NSError *)error;

/// 广告视图展示（did appear）回调方法
/// 业务方可以通过实现该方法，暂停业务视图上的动画/计时器等UI操作
/// @param ad 广告对象
- (void)adDidPresentFullScreenContent:(nonnull id<ABUKlevin_KLNFullScreenPresentingAd>)ad;

/// 广告视图移除（dismissal）回调方法
/// 业务方可以通过实现该方法，恢复业务视图上的动画等UI操作
/// @param ad 广告对象
- (void)adDidDismissFullScreenContent:(nonnull id<ABUKlevin_KLNFullScreenPresentingAd>)ad;

@end


NS_ASSUME_NONNULL_END
