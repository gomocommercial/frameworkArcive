//
//  ABUGdtError.h
//  Pods
//
//  Created by Makaiwen on 2021/5/31.
//

#ifndef ABUGdtError_h
#define ABUGdtError_h
#import <Foundation/Foundation.h>

static inline
NSError *ABUGdtError(int code, NSString *reason) {
    return [NSError errorWithDomain:@"com.bytedance.GroMore.gdt.adapter" code:code userInfo:@{
        NSLocalizedDescriptionKey : reason ?: @"Unknow error",
        NSLocalizedFailureReasonErrorKey : reason ?: @"Unknow error"}];
}

static inline
NSError *ABUGdtError_Setup_Failed() {
    return ABUGdtError(-1, @"Failed to set up ad.");
}

#endif /* ABUGdtError_h */
