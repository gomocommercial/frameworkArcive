//
//  ABUGdtCommonProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//logo默认宽度
extern CGFloat const kGDTLogoImageViewDefaultWidth;
//logo默认高度
extern CGFloat const kGDTLogoImageViewDefaultHeight;

/**
 *  视频播放器状态
 *
 *  播放器只可能处于以下状态中的一种
 *
 */
typedef NS_ENUM(NSUInteger, GDTMediaPlayerStatus) {
    GDTMediaPlayerStatusInitial = 0,         // 初始状态
    GDTMediaPlayerStatusLoading = 1,         // 加载中
    GDTMediaPlayerStatusStarted = 2,         // 开始播放
    GDTMediaPlayerStatusPaused = 3,          // 用户行为导致暂停
    GDTMediaPlayerStatusError = 4,           // 播放出错
    GDTMediaPlayerStatusStoped = 5,          // 播放停止
};

typedef NS_ENUM(NSInteger, GDTAdBiddingLossReason) {
    GDTAdBiddingLossReasonLowPrice          = 1,        // 竞争力不足
    GDTAdBiddingLossReasonLoadTimeout       = 2,        // 返回超时
    GDTAdBiddingLossReasonNoAd              = 3,        // 无广告回包
    GDTAdBiddingLossReasonAdDataError       = 4,        // 回包不合法
    GDTAdBiddingLossReasonOther             = 10001     // 其他
};

typedef enum GDTSDKLoginType {
    GDTSDKLoginTypeUnknow = 0,
    GDTSDKLoginTypeWeiXin = 1,    //微信账号
    GDTSDKLoginTypeQQ = 2,        //QQ账号
} GDTSDKLoginType;

typedef NS_ENUM (NSUInteger, GDTRewardAdType) {
    GDTRewardAdTypeVideo = 0,//激励视频
    GDTRewardAdTypePage = 1 //激励浏览
};

typedef NS_ENUM(NSUInteger, GDTVideoPlayPolicy) {
    GDTVideoPlayPolicyUnknow = 0, // 默认值，未设置
    GDTVideoPlayPolicyAuto = 1,   // 用户角度看起来是自动播放
    GDTVideoPlayPolicyManual = 2  // 用户角度看起来是手动播放或点击后播放
};

typedef NS_ENUM(NSUInteger, GDTVideoRenderType) {
    GDTVideoRenderTypeUnknow = 0,
    GDTVideoRenderTypeSDK = 1,
    GDTVideoRenderTypeDeveloper = 2
};

typedef NS_ENUM(NSInteger, GDTVastAdEventType) {
    GDTVastAdEventTypeUnknow,
    GDTVastAdEventTypeLoaded,
    GDTVastAdEventTypeStarted,
    GDTVastAdEventTypeFirstQuartile,
    GDTVastAdEventTypeMidPoint,
    GDTVastAdEventTypeThirdQuartile,
    GDTVastAdEventTypeComplete,
    GDTVastAdEventTypeAllAdsComplete,
    GDTVastAdEventTypeExposed,
    GDTVastAdEventTypeClicked,
};

typedef NS_ENUM(NSInteger, GDTVideoAutoPlayPolicy) {
    GDTVideoAutoPlayPolicyWIFI = 0, // WIFI 下自动播放
    GDTVideoAutoPlayPolicyAlways = 1, // 总是自动播放，无论网络条件
    GDTVideoAutoPlayPolicyNever = 2, // 从不自动播放，无论网络条件
};


@protocol ABUGDT_GDTAdTestSetting <NSObject>

@property (nonatomic, copy, nullable) NSString *playableUrl;//测试时使用的试玩广告地址

@end
typedef NSObject<ABUGDT_GDTAdTestSetting> GDTAdTestSetting;


@protocol ABUGDT_GDTSDKConfig <NSObject>
/**
 SDK 注册接口，请在 app 初始化时调用。
 @param appId - 媒体ID
 
 @return 注册是否成功。
*/
+ (BOOL)registerAppId:(NSString *)appId;

/**
 * 提供给聚合平台用来设定SDK 流量分类
 */
+ (void)setSdkSrc:(NSString *)sdkSrc;

/**
 * 查看SDK流量来源
 */
+ (NSString *)sdkSrc;

/**
 * 获取 SDK 版本
 */

+ (NSString *)sdkVersion;

+ (void)enableGPS:(BOOL)enabled;

/**
* 设置流量渠道号
 渠道号信息主要用来协助平台提升流量变现效果及您的收益，请如实填写，若渠道号无法满足您的诉求请联系平台负责商务
 
 渠道号映射关系为：
 1：百度
 2：头条
 3：广点通
 4：搜狗
 5：其他网盟
 6：oppo
 7：vivo
 8：华为
 9：应用宝
 10：小米
 11：金立
 12：百度手机助手
 13：魅族
 14：AppStore
 999：其他
*/
+ (void)setChannel:(NSInteger)channel;

+ (void)setSDKType:(NSInteger)type;

/**
 在播放音频时是否使用SDK内部对AVAudioSession设置的category及options，默认使用，若不使用，SDK内部不做任何处理，由调用方在展示广告时自行设置；
 SDK设置的category为AVAudioSessionCategoryAmbient，options为AVAudioSessionCategoryOptionDuckOthers
 */
+ (void)enableDefaultAudioSessionSetting:(BOOL)enabled;

+ (GDTAdTestSetting *)debugSetting;

/**
 设置开发阶段调试相关的配置
 */
+ (void)setDebugSetting:(GDTAdTestSetting *)debugSetting;

+ (void)forbiddenIDFA:(BOOL)forbiddened;

/**
 获取 buyerId 用于 Server Bidding 请求获取 token, 建议每次请求前调用一次, 并使用最新值请求
 */
+ (NSString *)getBuyerId;

@end
typedef NSObject<ABUGDT_GDTSDKConfig> GDTSDKConfig;


@protocol ABUGDT_GDTLoadAdParams <NSObject>

//登陆账号类型:QQ or weixin
@property (nonatomic, assign) GDTSDKLoginType loginType;

//登陆账号体系分配的appID，如QQ分配的appID或是微信分配的appID
@property (nonatomic, copy) NSString *loginAppId;

//登陆账号体系分配的openID，如QQ分配的openId或是微信分配的openId
@property (nonatomic, copy) NSString *loginOpenId;

//透传字段，key跟value都由调用方自行指定
@property (nonatomic, strong) NSDictionary *dictionary;

//透传字段，非qq小游戏
@property (nonatomic, copy) NSDictionary *devExtra;

@end
typedef NSObject<ABUGDT_GDTLoadAdParams> GDTLoadAdParams;


@protocol ABUGDT_GDTAdParams <NSObject>

/**
 *  广告大小，模板 2.0 信息流广告使用。当 height = 0，自动根据 width 算高；当 height > 0，直接使用传入的 width、height 作为模板容器 View 的大小。
 */
@property (nonatomic, assign) CGSize adSize;

/**
 *  非 WiFi 网络，视频广告是否自动播放。默认 NO。loadAd 前设置。
 */
@property (nonatomic, assign) BOOL videoAutoPlayOnWWAN;

/**
 *  视频广告自动播放时，是否静音。默认 YES。loadAd 前设置。
 */
@property (nonatomic, assign) BOOL videoMuted;

/**
 *  视频详情页播放时是否静音。默认NO。loadAd 前设置。
 */
@property (nonatomic, assign) BOOL detailPageVideoMuted;

/**
 请求视频的时长下限。
 以下两种情况会使用 0，1:不设置  2:minVideoDuration大于maxVideoDuration
*/
@property (nonatomic) NSInteger minVideoDuration;

/**
 请求视频的时长上限，视频时长有效值范围为[5,180]。
 */
@property (nonatomic) NSInteger maxVideoDuration;

@end
typedef NSObject<ABUGDT_GDTAdParams> GDTAdParams;


@protocol ABUGDT_GDTVideoConfig <NSObject>

/**
 视频自动播放策略，默认 GDTVideoAutoPlayPolicyAlways,
 选择 GDTVideoAutoPlayPolicyNever 策略时，需要开发者调用 GDTMediaView 的 play\pause 方法触发视频播、暂停，
 或者开启 userControlEnable 设置，让用户点击 MediaView 控制播放状态
 */
@property (nonatomic, assign) GDTVideoAutoPlayPolicy autoPlayPolicy;

/**
 是否静音播放视频广告，视频初始状态是否静音，默认 YES，
 可通过 GDTMediaView muteEnable: 方法实时控制播放器j静音状态，
 */
@property (nonatomic, assign) BOOL videoMuted;

/**
 视频详情页播放时是否静音，默认NO，
 */
@property (nonatomic, assign) BOOL detailPageVideoMuted;

/**
 是否启动自动续播功能，当在 tableView 等场景播放器被销毁时，广告展示时继续从上次播放位置续播，默认 NO
 */
@property (nonatomic, assign) BOOL autoResumeEnable;

/**
 广告发生点击行为时，是否展示视频详情页
 设为 NO 时，用户点击 clickableViews 会直接打开 App Store 或者广告落地页
 */
@property (nonatomic, assign) BOOL detailPageEnable;

/**
 是否支持用户点击 MediaView 改变视频播放暂停状态，默认 YES
 设为 YES 时，用户点击会切换播放器播放、暂停状态
 */
@property (nonatomic, assign) BOOL userControlEnable;

/**
 是否展示播放进度条，默认 YES
 */
@property (nonatomic, assign) BOOL progressViewEnable;

/**
 是否展示播放器封面图，默认 YES
 */
@property (nonatomic, assign) BOOL coverImageEnable;

@end
typedef NSObject<ABUGDT_GDTVideoConfig> GDTVideoConfig;


@protocol ABUGDT_GDTServerSideVerificationOptions <NSObject>

//用户的userid,可选
@property(nonatomic, copy, nullable) NSString *userIdentifier;

//服务器端验证回调中包含的可选自定义奖励字符串
@property(nonatomic, copy, nullable) NSString *customRewardString;

@end
typedef NSObject<ABUGDT_GDTServerSideVerificationOptions> GDTServerSideVerificationOptions;

NS_ASSUME_NONNULL_END
