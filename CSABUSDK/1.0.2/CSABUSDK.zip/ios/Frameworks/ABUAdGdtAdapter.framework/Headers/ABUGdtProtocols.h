//
//  ABUGdtProtocols.h
//  Pods
//
//  Created by bytedance on 2021/9/15.
//

#import "ABUGdtCommonProtocol.h"
#import "ABUGDTBannerAdProtocols.h"
