//
//  ABUGdtNativeAdapter.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUGdtNativeAdapter : NSObject <ABUCustomNativeAdapter>

@end

NS_ASSUME_NONNULL_END
