//
// Created by bytedance on 2021/7/9.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ABUPangleCommonProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABUPangle_BUMaterialMeta <NSObject>
- (NSDictionary *)mediaExt;
- (NSInteger)interactionType;
- (id <NSFastEnumeration>)imageAry;
- (id <ABUPangle_BUImage>)icon;
- (NSString *)AdTitle;
- (NSString *)AdDescription;
- (NSString *)source;
- (NSString *)buttonText;
- (NSInteger)imageMode;
- (NSInteger)score;
- (NSInteger)commentNum;
- (NSInteger)appSize;
- (NSInteger)videoDuration;
@end
typedef NSObject<ABUPangle_BUMaterialMeta> BUMaterialMeta;

@protocol ABUPangle_BUNativeAd <NSObject>
@property (nonatomic, strong, readonly) id<ABUPangle_BUMaterialMeta> data;
@property (nonatomic, weak, readwrite) UIViewController *rootViewController;
@property (nonatomic, weak, readwrite, nullable) id delegate;
- (void)registerContainer:(__kindof UIView *_Nonnull)containerView
       withClickableViews:(NSArray<__kindof UIView *> *_Nullable)clickableViews;
@end

@protocol ABUPangle_BUNativeExpressAdView <NSObject>
@property (nonatomic, weak, readwrite) UIViewController *rootViewController;
- (void)render;
@end

@protocol ABUPangle_BUVideoAdView <NSObject>
- (void)setDelegate:(id _Nullable )delegate;

@property (nonatomic, strong, readwrite, nullable) BUMaterialMeta *materialMeta;
@property (nonatomic, weak, readwrite) UIViewController *rootViewController;
@end
typedef UIView<ABUPangle_BUVideoAdView> BUVideoAdView;

@protocol ABUPangle_BUNativeAdRelatedView <NSObject>
@property (nonatomic, strong, readonly, nullable) UIButton *dislikeButton;
@property (nonatomic, strong, readonly, nullable) UILabel *adLabel;
@property (nonatomic, strong, readonly, nullable) UIImageView *logoImageView;
@property (nonatomic, strong, readonly, nullable) UIImageView *logoADImageView;
@property (nonatomic, strong, readonly, nullable) UIView<ABUPangle_BUVideoAdView> *videoAdView;
- (void)refreshData:(id<ABUPangle_BUNativeAd>_Nonnull)nativeAd;

@end

@protocol ABUPangle_BUNativeAdDelegate <NSObject>
@optional
- (void)nativeAdDidLoad:(id<ABUPangle_BUNativeAd>)nativeAd;
- (void)nativeAdDidLoad:(id<ABUPangle_BUNativeAd>)nativeAd view:(UIView *_Nullable)view;
- (void)nativeAd:(id<ABUPangle_BUNativeAd>)nativeAd didFailWithError:(NSError *_Nullable)error;
- (void)nativeAdDidBecomeVisible:(id<ABUPangle_BUNativeAd>)nativeAd;
- (void)nativeAdDidCloseOtherController:(id<ABUPangle_BUNativeAd>)nativeAd interactionType:(NSInteger)interactionType;
- (void)nativeAdDidClick:(id<ABUPangle_BUNativeAd>)nativeAd withView:(UIView *_Nullable)view;
- (void)nativeAd:(id<ABUPangle_BUNativeAd>)nativeAd dislikeWithReason:(NSArray *_Nullable)filterWords;
- (void)nativeAd:(id<ABUPangle_BUNativeAd>)nativeAd adContainerViewDidRemoved:(UIView *)adContainerView;

@end

@protocol ABUPangle_BUNativeExpressAdViewDelegate <NSObject>
@optional
- (void)nativeExpressAdViewRenderSuccess:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView;
- (void)nativeExpressAdViewRenderFail:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView error:(NSError *_Nullable)error;
- (void)nativeExpressAdViewWillShow:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView;
- (void)nativeExpressAdViewDidClick:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView;
- (void)nativeExpressAdView:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView stateDidChanged:(NSInteger)playerState;
- (void)nativeExpressAdViewPlayerDidPlayFinish:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView error:(NSError *)error;
- (void)nativeExpressAdView:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView dislikeWithReason:(NSArray<id<ABUPangle_ABUDislikeWords>> *)filterWords;
- (void)nativeExpressAdViewWillPresentScreen:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView;
- (void)nativeExpressAdViewDidCloseOtherController:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView interactionType:(NSInteger)interactionType;
- (void)nativeExpressAdViewDidRemoved:(UIView <ABUPangle_BUNativeExpressAdView>*)nativeExpressAdView;
@end

@protocol ABUPangle_BUVideoAdViewDelegate <NSObject>

/**
 This method is called when videoadview failed to play.
 @param error : the reason of error
 */
- (void)videoAdView:(BUVideoAdView *)videoAdView didLoadFailWithError:(NSError *_Nullable)error;

/**
 This method is called when videoadview ready to play.
 */
- (void)playerReadyToPlay:(BUVideoAdView *)videoAdView;

/**
 This method is called when videoadview playback status changed.
 @param playerState : player state after changed
 */
- (void)videoAdView:(BUVideoAdView *)videoAdView stateDidChanged:(NSInteger)playerState;

/**
 This method is called when videoadview end of play.
 */
- (void)playerDidPlayFinish:(BUVideoAdView *)videoAdView;

/**
 This method is called when videoadview is clicked.
 */
- (void)videoAdViewDidClick:(BUVideoAdView *)videoAdView;

/**
 This method is called when videoadview's finish view is clicked.
 */
- (void)videoAdViewFinishViewDidClick:(BUVideoAdView *)videoAdView;

/**
 This method is called when another controller has been closed.
 @param interactionType : open appstore in app or open the webpage or view video ad details page.
 */
- (void)videoAdViewDidCloseOtherController:(BUVideoAdView *)videoAdView interactionType:(NSInteger)interactionType;

@end
NS_ASSUME_NONNULL_END
