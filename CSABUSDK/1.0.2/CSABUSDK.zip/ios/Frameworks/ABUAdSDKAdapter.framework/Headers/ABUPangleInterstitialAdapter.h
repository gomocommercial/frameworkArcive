//
// Created by bytedance on 2021/7/19.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface ABUPangleInterstitialAdapter : NSObject <ABUCustomInterstitialAdapter>



@end