//
// Created by bytedance on 2021/7/4.
//

#import <Foundation/Foundation.h>
typedef NS_ENUM(NSInteger, ABUPangleSlotAdType) {
    ABUPangleSlotAdTypeUnknown       = 0,
    ABUPangleSlotAdTypeBanner        = 1,       // banner ads
    ABUPangleSlotAdTypeInterstitial  = 2,       // interstitial ads
    ABUPangleSlotAdTypeSplash        = 3,       // splash ads
    ABUPangleSlotAdTypeSplash_Cache  = 4,       // cache splash ads
    ABUPangleSlotAdTypeFeed          = 5,       // feed ads
    ABUPangleSlotAdTypePaster        = 6,       // paster ads
    ABUPangleSlotAdTypeRewardVideo   = 7,       // rewarded video ads
    ABUPangleSlotAdTypeFullscreenVideo = 8,     // full-screen video ads
    ABUPangleSlotAdTypeDrawVideo     = 9,       // vertical (immersive) video ads
};

@protocol ABUPangleSize <NSObject>
@required

@property(nonatomic, assign) NSInteger width;

@property(nonatomic, assign) NSInteger height;

@end

@protocol ABUPangleSlot <NSObject>

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, assign) CGSize adSize;

@property (nonatomic, copy) NSString *primeRit;

/// optional. AD id for preview
@property (nonatomic, copy) NSString *previewAdID;

/// optional. AD creative id for preview
@property (nonatomic, copy) NSString *previewCreativeID;

/// optional. extend msg
@property (nonatomic, copy) NSDictionary *ext;

/// optional. additional user information
@property (nonatomic, copy) NSString *userData;

//adload_seq：（针对聚合广告位）传递本次请求是为“自然日内某设备某广告位置第N次展示机会”发出的广告请求，同物理位置在自然日从1开始计数，不同物理位置独立计数；example：某原生广告位置，当天第5次产生展示机会，这次展示机向穿山甲发送了4次广告请求，则这4次广告请求的"adload_seq"的值应为5。第二天重新开始计数。
@property (nonatomic, assign) NSInteger adloadSeq;

@property (nonatomic, assign) BOOL isOriginAd;

@property (nonatomic, strong) id<ABUPangleSize> imgSize;

@property (nonatomic, assign) NSInteger AdType;

@property (nonatomic, assign) NSInteger position;

- (void)setSplashButtonType:(NSInteger)splashButtonType;
@end

@interface ABUPangleSlotCreator : NSObject

+ (id<ABUPangleSlot>)create;

+ (id<ABUPangleSlot>)createWithSlotId:(NSString *)slotId unitSlotId:(NSString *)unitSlotId type:(ABUPangleSlotAdType)type express:(BOOL)express;

+ (void)setPreviewInfo:(NSDictionary *)previewInfo toSlot:(id<ABUPangleSlot>)toSlot;
@end
