//
// Created by bytedance on 2021/6/24.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface ABUPangleRewardedVideoAdapter : NSObject <ABUCustomRewardedVideoAdapter>

@end