//
// Created by bytedance on 2021/7/5.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface ABUPangleNativeAdapter : NSObject <ABUCustomNativeAdapter>

@end