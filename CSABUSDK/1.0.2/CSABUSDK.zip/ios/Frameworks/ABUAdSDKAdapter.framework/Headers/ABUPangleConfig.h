//
//  ABUPangleConfig.h
//  ABUAdSDK
//
//  Created by Makaiwen on 2021/5/31.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUPangleConfig : NSObject <ABUCustomConfigAdapter>

+ (NSInteger)adLoadSeqOfType:(NSInteger)type express:(BOOL)express;

+ (NSString *)networkSDKVersion;

+ (NSString *)biddingTokenWithToken:(NSString *)token;

@end

NS_ASSUME_NONNULL_END
