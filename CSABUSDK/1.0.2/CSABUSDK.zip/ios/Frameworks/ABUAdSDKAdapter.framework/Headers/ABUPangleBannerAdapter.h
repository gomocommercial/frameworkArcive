//
//  ABUPangleBannerAd.h
//  ABUAdSDK
//
//  Created by Makaiwen on 2021/5/31.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import "ABUPangleConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABUPangleBannerAdapter : NSObject <ABUCustomBannerAdapter>

@end

NS_ASSUME_NONNULL_END
