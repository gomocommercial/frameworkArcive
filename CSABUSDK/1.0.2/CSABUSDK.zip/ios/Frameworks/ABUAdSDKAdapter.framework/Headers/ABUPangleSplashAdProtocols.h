//
//  ABURewardedVideoAdProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/7/14.
//

#import <Foundation/Foundation.h>
#import "ABUPangleCommonProtocols.h"

NS_ASSUME_NONNULL_BEGIN
@protocol BUSplashZoomOutViewDelegate;

@protocol ABU_BUSplashZoomOutView<NSObject>

@property (nonatomic, weak) id<BUSplashZoomOutViewDelegate> delegate;
@property (nonatomic, assign) CGSize showSize;
@property (nonatomic, weak) UIViewController *rootViewController;
@end

@protocol BUSplashAdDelegate;
@protocol ABU_BUSplashAdView<NSObject>
@property (nonatomic, copy, readonly, nonnull) NSString *slotID;
@property (nonatomic, assign) NSTimeInterval tolerateTimeout;
@property (nonatomic, assign) BOOL hideSkipButton;
@property (nonatomic, readonly) id<ABU_BUSplashZoomOutView> zoomOutView;
@property (nonatomic, weak, nullable) id<BUSplashAdDelegate> delegate;
@property (nonatomic, copy, readonly) NSDictionary *mediaExt;
@property (nonatomic) BOOL needSplashZoomOutAd;
@property (nonatomic, weak) UIViewController *rootViewController;
@property (nonatomic, getter=isAdValid, readonly) BOOL adValid;
- (instancetype)initWithSlotID:(NSString *)slotID frame:(CGRect)frame;
- (instancetype)initWithSlot:(id<ABUPangleSlot>)slot frame:(CGRect)frame;
- (void)loadAdData;
- (NSString *)biddingToken;
- (void)setMopubAdMarkUp:(NSString *)markUp;
@end

@protocol BUSplashAdDelegate <NSObject>
@optional
- (void)splashAdDidClick:(id<ABU_BUSplashAdView>)splashAd;
- (void)splashAdDidClose:(id<ABU_BUSplashAdView>)splashAd;
- (void)splashAdWillClose:(id<ABU_BUSplashAdView>)splashAd;
- (void)splashAdDidLoad:(id<ABU_BUSplashAdView>)splashAd;
- (void)splashAd:(id<ABU_BUSplashAdView>)splashAd didFailWithError:(NSError *)error;
- (void)splashAdWillVisible:(id<ABU_BUSplashAdView>)splashAd;
@end

@protocol BUSplashZoomOutViewDelegate <NSObject>
- (void)splashZoomOutViewAdDidClick:(id<ABU_BUSplashZoomOutView>)splashAd;
- (void)splashZoomOutViewAdDidClose:(id<ABU_BUSplashZoomOutView>)splashAd;
- (void)splashZoomOutViewAdDidAutoDimiss:(id<ABU_BUSplashZoomOutView>)splashAd;
- (void)splashZoomOutViewAdDidCloseOtherController:(id<ABU_BUSplashZoomOutView>)splashAd interactionType:(int)interactionType;

@end

@protocol BUNativeExpressSplashViewDelegate;
@protocol ABU_BUNativeExpressSplashView <NSObject>
@property (nonatomic, weak, nullable) id<BUNativeExpressSplashViewDelegate> delegate;
@property (nonatomic, assign) NSTimeInterval tolerateTimeout;
@property (nonatomic, assign) BOOL hideSkipButton;
@property (nonatomic, getter=isAdValid, readonly) BOOL adValid;
@property (nonatomic, copy, readonly) NSDictionary *mediaExt;
- (instancetype)initWithSlotID:(NSString *)slotID adSize:(CGSize)adSize rootViewController:(UIViewController *)rootViewController;
- (instancetype)initWithSlot:(id<ABUPangleSlot>)slot adSize:(CGSize)adSize rootViewController:(UIViewController *)rootViewController;
- (NSString *)biddingToken;
- (void)loadAdData;
- (void)setMopubAdMarkUp:(NSString *)markUp;
- (void)removeSplashView;
@end

@protocol BUNativeExpressSplashViewDelegate <NSObject>
- (void)nativeExpressSplashViewDidLoad:(id<ABU_BUNativeExpressSplashView>)splashAdView;
- (void)nativeExpressSplashView:(id<ABU_BUNativeExpressSplashView>)splashAdView didFailWithError:(NSError * _Nullable)error;
- (void)nativeExpressSplashViewRenderSuccess:(id<ABU_BUNativeExpressSplashView>)splashAdView;
- (void)nativeExpressSplashViewRenderFail:(id<ABU_BUNativeExpressSplashView>)splashAdView error:(NSError * __nullable)error;
- (void)nativeExpressSplashViewWillVisible:(id<ABU_BUNativeExpressSplashView>)splashAdView;
- (void)nativeExpressSplashViewDidClick:(id<ABU_BUNativeExpressSplashView>)splashAdView;
- (void)nativeExpressSplashViewDidClickSkip:(id<ABU_BUNativeExpressSplashView>)splashAdView;
- (void)nativeExpressSplashViewDidClose:(id<ABU_BUNativeExpressSplashView>)splashAdView;
- (void)nativeExpressSplashViewCountdownToZero:(id<ABU_BUNativeExpressSplashView>)splashAdView;
- (void)nativeExpressSplashViewFinishPlayDidPlayFinish:(id<ABU_BUNativeExpressSplashView>)splashView didFailWithError:(NSError *)error;
- (void)nativeExpressSplashViewDidCloseOtherController:(id<ABU_BUNativeExpressSplashView>)splashView interactionType:(int)interactionType;
@end

NS_ASSUME_NONNULL_END

