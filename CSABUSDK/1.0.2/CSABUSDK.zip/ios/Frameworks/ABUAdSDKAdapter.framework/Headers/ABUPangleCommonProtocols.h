//
//  ABUPangleProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/7/14.
//

#import <Foundation/Foundation.h>
#import "ABUPangleSlot.h"

NS_ASSUME_NONNULL_BEGIN
@protocol ABUPangle_BUAdSDKManager <NSObject>

- (void)setOfflineType:(NSInteger)lineType;

- (void)setUserExtData:(NSString *)extData;

- (void)setAppID:(NSString *)appID;

- (void)setThemeStatus:(NSInteger)theme;

- (NSInteger)themeStatus;

- (NSString *)SDKVersion;
@end

@protocol ABUPangle_BUImage <NSObject>
- (float)width;
- (float)height;
- (NSString *)imageURL;
@end

@protocol ABUPangle_ABUDislikeWords <NSObject>
@property (nonatomic, copy, readonly) NSString *dislikeID;
@property (nonatomic, copy, readonly) NSString *name;
@property (nonatomic, assign, readonly) BOOL isSelected;
@property (nonatomic, copy, readonly) NSArray<id<ABUPangle_ABUDislikeWords>> *options;
@end

@protocol ABUPangle_BUAdSDKPrivacyProvider <NSObject>

@optional

/// Specify whether to allow the SDK to use location data
- (BOOL)canUseLocation;
/// Return a latitude value
- (double)latitude;
/// Return a longitude value
- (double)longitude;

@end

@protocol ABUPangle_BUAdSDKConfiguration <NSObject>

+ (instancetype)configuration;

@property (nonatomic, weak) id<ABUPangle_BUAdSDKPrivacyProvider> privacyProvider;

@end

NS_ASSUME_NONNULL_END
