//
// Created by bytedance on 2021/7/9.
//

#import <Foundation/Foundation.h>
#import "ABUPangleNativeAdProtocols.h"
#import <ABUAdSDK/ABUAdSDK.h>

@interface ABUPangleNativeAdViewCreator : NSObject <ABUMediatedNativeAdViewCreator>

- (instancetype)initWithAd:(id<ABUPangle_BUNativeAd>)ad videoViewDelegate:(id)delegate;

@end