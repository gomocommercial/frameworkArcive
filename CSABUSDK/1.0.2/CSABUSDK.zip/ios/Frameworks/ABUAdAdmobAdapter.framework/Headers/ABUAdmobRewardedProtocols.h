//
//  ABUAdmobRewardedProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/22.
//

#import <Foundation/Foundation.h>
#import "ABUAdmobCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABUAdmob_GADAdReward <NSObject>

/// Type of the reward.
@property(nonatomic, readonly, nonnull) NSString *type;

/// Amount rewarded to the user.
@property(nonatomic, readonly, nonnull) NSDecimalNumber *amount;

@end

typedef NSObject<ABUAdmob_GADAdReward> GADAdReward;

@protocol ABUAdmob_GADRewardedAd <NSObject>

/// Returns whether the rewarded ad can be presented from the provided root view
/// controller. Sets the error out parameter if the ad can't be presented. Must be called on the
/// main thread.
- (BOOL)canPresentFromRootViewController:(nonnull UIViewController *)rootViewController
                                   error:(NSError *_Nullable __autoreleasing *_Nullable)error;

/// Presents the rewarded ad. Must be called on the main thread.
///
/// @param rootViewController A view controller to present the ad.
/// @param userDidEarnRewardHandler A handler to execute when the user earns a reward.
- (void)presentFromRootViewController:(nonnull UIViewController *)rootViewController
             userDidEarnRewardHandler:(nonnull void(^)(void))userDidEarnRewardHandler;

/// Delegate for handling full screen content messages.
@property(nonatomic, weak, nullable) id<ABUAdmob_GADFullScreenContentDelegate> fullScreenContentDelegate;

/// The reward earned by the user for interacting with the ad.
@property(nonatomic, readonly, nonnull) GADAdReward *adReward;
@end

typedef NSObject<ABUAdmob_GADRewardedAd> GADRewardedAd;

typedef void (^ABUAdmob_GADRewardedAdLoadCompletionHandler)(GADRewardedAd *_Nullable rewardedAd,
                                                       NSError *_Nullable error);
@protocol ABUAdmob_GADRewardedAdClass <NSObject>

/// Loads an interstitial ad.
///
/// @param adUnitID An ad unit ID created in the AdMob or Ad Manager UI.
/// @param request An ad request object. If nil, a default ad request object is used.
/// @param completionHandler A handler to execute when the load operation finishes or times out.
- (void)loadWithAdUnitID:(nonnull NSString *)adUnitID
                 request:(nullable GADRequest *)request
       completionHandler:(nonnull ABUAdmob_GADRewardedAdLoadCompletionHandler)completionHandler;

@end

NS_ASSUME_NONNULL_END
