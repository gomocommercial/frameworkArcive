//
//  ABUUnityError.h
//  Pods
//
//  Created by Makaiwen on 2021/5/31.
//

#ifndef ABUUnityError_h
#define ABUUnityError_h
#import <Foundation/Foundation.h>

static inline
NSError *ABUUnityError(NSInteger code, NSString *reason) {
    return [NSError errorWithDomain:@"com.bytedance.GroMore.unity.adapter" code:code userInfo:@{
        NSLocalizedDescriptionKey : reason ?: @"Unknow error",
        NSLocalizedFailureReasonErrorKey : reason ?: @"Unknow error"}];
}

static inline
NSError *ABUUnityError_Setup_Failed() {
    return ABUUnityError(-1, @"Failed to set up ad.");
}

#endif /* ABUUnityError_h */
