//
//  ABUUnityCommonProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol ABUUnity_UnityAdsDelegate <NSObject>

- (void)unityAdsReady: (NSString *)placementId;

- (void)unityAdsDidError: (NSInteger)error withMessage: (NSString *)message;

- (void)unityAdsDidStart: (NSString *)placementId;

- (void)unityAdsDidFinish: (NSString *)placementId
          withFinishState: (NSInteger)state;
@end

@protocol ABUUnity_UnityAdsLoadDelegate <NSObject>

- (void)unityAdsAdLoaded: (NSString *)placementId;

- (void)unityAdsAdFailedToLoad: (NSString *)placementId
                     withError: (NSInteger)error
                   withMessage: (NSString *)message;
@end

@protocol ABUUnity_UnityAdsShowDelegate <NSObject>

- (void)unityAdsShowComplete: (NSString *)placementId withFinishState: (NSInteger)state;

- (void)unityAdsShowFailed: (NSString *)placementId withError: (NSInteger)error withMessage: (NSString *)message;

- (void)unityAdsShowStart: (NSString *)placementId;

- (void)unityAdsShowClick: (NSString *)placementId;

@end

@protocol ABUUnity_UnityAds <NSObject>
- (void)        initialize: (NSString *)gameId
                  testMode: (BOOL)testMode
    enablePerPlacementLoad: (BOOL)enablePerPlacementLoad;

- (NSString *)getVersion;

- (BOOL)                  isInitialized;

- (void)addDelegate: (__nullable id<ABUUnity_UnityAdsDelegate>)delegate;

- (void)    load: (NSString *)placementId
    loadDelegate: (nullable id<ABUUnity_UnityAdsLoadDelegate>)loadDelegate;

- (void)show: (UIViewController *)viewController placementId: (NSString *)placementId showDelegate: (nullable id<ABUUnity_UnityAdsShowDelegate>)showDelegate;
@end

#pragma mark - banner
@protocol ABUUnity_UADSBannerViewDelegate;
@protocol ABUUnity_UADSBannerView <NSObject>
@property (nonatomic, readonly) CGSize size;
@property (nonatomic, readwrite, nullable, weak) NSObject <ABUUnity_UADSBannerViewDelegate> *delegate;
@property (nonatomic, readonly) NSString *placementId;

- (instancetype)initWithPlacementId: (NSString *)placementId size: (CGSize)size;

- (void)        load;

@end

typedef UIView<ABUUnity_UADSBannerView> UADSBannerView;

@protocol ABUUnity_UADSBannerViewDelegate <NSObject>

@optional
/**
 * Called when the banner is loaded and ready to be placed in the view hierarchy.
 *
 * @param bannerView View that was loaded
 */
- (void)bannerViewDidLoad: (UADSBannerView *)bannerView;

/**
 * Called when the user clicks the banner.
 *
 * @param bannerView View that the click occurred on.
 */
- (void)bannerViewDidClick: (UADSBannerView *)bannerView;

/**
 * Called when a banner causes
 * @param bannerView View that triggered leaving application
 */
- (void)bannerViewDidLeaveApplication: (UADSBannerView *)bannerView;

/**
 *  Called when `UnityAdsBanner` encounters an error. All errors will be logged but this method can be used as an additional debugging aid. This callback can also be used for collecting statistics from different error scenarios.
 *
 *  @param bannerView View that encountered an error.
 *  @param error UADSBannerError that occurred
 */
- (void)bannerViewDidError: (UADSBannerView *)bannerView error: (NSError *)error;

@end

NS_ASSUME_NONNULL_END
