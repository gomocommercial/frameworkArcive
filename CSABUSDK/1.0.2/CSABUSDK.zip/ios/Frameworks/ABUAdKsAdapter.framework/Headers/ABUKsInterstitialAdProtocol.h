//
//  ABUKsInterstitialAdProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/16.
//

#import <Foundation/Foundation.h>
#import "ABUKsCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABUKs_KSInterstitialAd;
typedef NSObject<ABUKs_KSInterstitialAd> KSInterstitialAd;

@protocol ABUKs_KSInterstitialAdDelegate <NSObject>
@optional
- (void)ksad_interstitialAdDidLoad:(KSInterstitialAd *)interstitialAd;
- (void)ksad_interstitialAdRenderSuccess:(KSInterstitialAd *)interstitialAd;
- (void)ksad_interstitialAdRenderFail:(KSInterstitialAd *)interstitialAd error:(NSError * _Nullable)error;
- (void)ksad_interstitialAdWillVisible:(KSInterstitialAd *)interstitialAd;
- (void)ksad_interstitialAdDidVisible:(KSInterstitialAd *)interstitialAd;
- (void)ksad_interstitialAd:(KSInterstitialAd *)interstitialAd didSkip:(NSTimeInterval)playDuration;
- (void)ksad_interstitialAdDidClick:(KSInterstitialAd *)interstitialAd;
- (void)ksad_interstitialAdWillClose:(KSInterstitialAd *)interstitialAd;
- (void)ksad_interstitialAdDidClose:(KSInterstitialAd *)interstitialAd;
- (void)ksad_interstitialAdDidCloseOtherController:(KSInterstitialAd *)interstitialAd interactionType:(NSInteger)interactionType;
@end

@protocol ABUKs_KSInterstitialAd <ABUKs_KSAd>
@property (nonatomic, readonly) BOOL isValid;
- (void)setDelegate:(id<ABUKs_KSInterstitialAdDelegate>)delegate;
- (instancetype)initWithPosId:(NSString *)posId;
- (instancetype)initWithPosId:(NSString *)posId containerSize:(CGSize)containerSize;
- (void)loadAdData;

- (BOOL)showFromViewController:(UIViewController *)rootViewController;

@end

NS_ASSUME_NONNULL_END
