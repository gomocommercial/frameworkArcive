//
//  ABUBaiduBannerProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/23.
//

#import <Foundation/Foundation.h>
#import "ABUBaiduCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN
@protocol ABUBaidu_BaiduMobAdViewDelegate;
@protocol ABUBaidu_BaiduMobAdView <NSObject>
/**
 *  委托对象
 */
@property(nonatomic, weak) id<ABUBaidu_BaiduMobAdViewDelegate> delegate;

/**
 *  设置／获取需要展示的广告类型
 */
@property(nonatomic, assign) NSInteger AdType; // 0

/**
 *  设置/获取代码位id
 */
@property(nonatomic, copy) NSString *AdUnitTag;

/**
 *  SDK版本
 */
@property(nonatomic, readonly) NSString *Version;

/**
 *  使用controller present 落地页
 */
@property (nonatomic, weak) UIViewController *presentAdViewController;

/**
 *  开始广告展示请求,会触发所有资源的重新加载，推荐初始化以后调用一次
 */
- (void)start;
@end

typedef UIView<ABUBaidu_BaiduMobAdView> BaiduMobAdView;

@protocol ABUBaidu_BaiduMobAdViewDelegate <NSObject>


@required
/**
 *  应用的APPID
 */
- (NSString *)publisherId;

@optional
/**
 *  渠道ID
 */
- (NSString *)channelId;
/**
 *  启动位置信息
 */
- (BOOL)enableLocation;

/**
 *  广告将要被载入
 */
- (void)willDisplayAd:(BaiduMobAdView *)adview;

/**
 *  广告载入失败
 */
- (void)failedDisplayAd:(BaiduMobFailReason)reason;

/**
 *  本次广告展示成功时的回调
 */
- (void)didAdImpressed;

/**
 *  本次广告展示被用户点击时的回调
 */
- (void)didAdClicked;

/**
 *  在用户点击完广告条出现全屏广告页面以后，用户关闭广告时的回调
 */
- (void)didDismissLandingPage;

/**
 *  用户点击关闭按钮关闭广告后的回调
 */
- (void)didAdClose;


@end

NS_ASSUME_NONNULL_END
