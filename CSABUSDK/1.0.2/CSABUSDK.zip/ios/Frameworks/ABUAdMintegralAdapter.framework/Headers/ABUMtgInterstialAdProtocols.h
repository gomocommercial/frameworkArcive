//
//  ABUMtgInterstialAdProtocols.h
//  ABUAdSDK
//
//  Created by CHAORS on 2021/9/29.
//

#import <Foundation/Foundation.h>
#import "ABUMtgCommonProtocol.h"



typedef NS_ENUM(NSInteger, MTGInterstitialAdCategory) {
    MTGInterstitial_AD_CATEGORY_ALL  = 0,
    MTGInterstitial_AD_CATEGORY_GAME = 1,
    MTGInterstitial_AD_CATEGORY_APP  = 2,
};


NS_ASSUME_NONNULL_BEGIN

@protocol ABUMtg_MTGInterstitialAdManagerLoadDelegate;
@protocol ABUMtg_MTGInterstitialAdShowDelegate;
@protocol ABUMtg_MTGInterstitialAdManager <NSObject>

@property (nonatomic,copy,readonly)   NSString * _Nonnull currentUnitId;

@property (nonatomic,copy,readonly)   NSString * _Nullable placementId;

/**
* get the id of this request ad,call  after onInterstitialLoadSuccess.
*/
@property (nonatomic,copy,readonly)   NSString * _Nullable requestId;

/**
*   Initialize the interstitial ads manager.
*  @param placementId     The id of the ad placement. You can create your placement id from our Portal.
*  @param unitId         The id of the ad unit. You can create your unit id from our Portal.
*  @param adCategory     Decide what kind of ads you want to retrieve. Games, apps or all of them. The default is All.
*/
- (nonnull instancetype)initWithPlacementId:(nullable NSString *)placementId
                                     unitId:(nonnull NSString *)unitId
                                 adCategory:(MTGInterstitialAdCategory)adCategory;
/**
 *  Called when load the Interstitial
 *
 *  @param delegate reference to the object that implements MTGInterstitialAdLoadDelegate protocol; will receive load events for the given unitId.
 */
- (void)loadWithDelegate:(nullable id <ABUMtg_MTGInterstitialAdManagerLoadDelegate>) delegate;

/**
 *  Called when show the Interstitial
 *
 *  @param delegate       reference to the object that implements MTGInterstitialAdShowDelegate protocol; will receive show events for the given unitId.
 
 *  @param viewController The UIViewController that will be used to present Interstitial Controller. If not set, it will be the root viewController of your current UIWindow. But it may failed to present our Interstitial controller if your rootViewController is presenting other view controller. So set this property is necessary.

 */
- (void)showWithDelegate:(nullable id <ABUMtg_MTGInterstitialAdShowDelegate>)delegate presentingViewController:(nullable UIViewController *)viewController;

@end
typedef NSObject<ABUMtg_MTGInterstitialAdManager> MTGInterstitialAdManager;


@protocol ABUMtg_MTGInterstitialAdManagerLoadDelegate <NSObject>
/**
 *  Sent when the ad is successfully load , and is ready to be displayed
 */
- (void) onInterstitialLoadSuccess DEPRECATED_ATTRIBUTE;
- (void) onInterstitialLoadSuccess:(MTGInterstitialAdManager *_Nonnull)adManager;

/**
 *  Sent when there was an error loading the ad.
 *
 *  @param error An NSError object with information about the failure.
 */
- (void) onInterstitialLoadFail:(nonnull NSError *)error DEPRECATED_ATTRIBUTE;
- (void) onInterstitialLoadFail:(nonnull NSError *)error adManager:(MTGInterstitialAdManager *_Nonnull)adManager;
@end


@protocol ABUMtg_MTGInterstitialAdShowDelegate <NSObject>

@optional
/**
 *  Sent when the Interstitial success to open
 */
- (void) onInterstitialShowSuccess DEPRECATED_ATTRIBUTE;
- (void) onInterstitialShowSuccess:(MTGInterstitialAdManager *_Nonnull)adManager;

/**
 *  Sent when the Interstitial failed to open for some reason
 *
 *  @param error An NSError object with information about the failure.
 */
- (void) onInterstitialShowFail:(nonnull NSError *)error DEPRECATED_ATTRIBUTE;
- (void) onInterstitialShowFail:(nonnull NSError *)error adManager:(MTGInterstitialAdManager *_Nonnull)adManager;


/**
 *  Sent when the Interstitial has been clesed from being open, and control will return to your app
 */
- (void) onInterstitialClosed DEPRECATED_ATTRIBUTE;
- (void) onInterstitialClosed:(MTGInterstitialAdManager *_Nonnull)adManager;


/**
 *  Sent after the Interstitial has been clicked by a user.
 */
- (void) onInterstitialAdClick DEPRECATED_ATTRIBUTE;
- (void) onInterstitialAdClick:(MTGInterstitialAdManager *_Nonnull)adManager;

@end

#pragma mark - bidding
@protocol ABUMtg_MTGBidInterstitialVideoDelegate;
@protocol ABUMtg_MTGBidInterstitialVideoAdManager <NSObject>
@property (nonatomic, assign) BOOL  playVideoMute;
- (nonnull instancetype)initWithPlacementId:(nullable NSString *)placementId
                                     unitId:(nonnull NSString *)unitId
                                   delegate:(nullable id<ABUMtg_MTGBidInterstitialVideoDelegate>)delegate;
- (void)loadAdWithBidToken:(nonnull NSString *)bidToken;
- (BOOL)isVideoReadyToPlayWithPlacementId:(nullable NSString *)placementId unitId:(nonnull NSString *)unitId;
- (void)showFromViewController:(UIViewController *_Nonnull)viewController;

@end
typedef NSObject<ABUMtg_MTGBidInterstitialVideoAdManager> MTGBidInterstitialVideoAdManager;

@protocol ABUMtg_MTGBidInterstitialVideoDelegate <NSObject>

/**
 *  Called when the ad is loaded , but not ready to be displayed,need to wait load video
 completely
 */
- (void)onInterstitialAdLoadSuccess:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;

/**
 *  Called when the ad is successfully load , and is ready to be displayed
 */
- (void)onInterstitialVideoLoadSuccess:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;

/**
 *  Called when there was an error loading the ad.
 *  @param error       - error object that describes the exact error encountered when loading the ad.
 */
- (void)onInterstitialVideoLoadFail:(nonnull NSError *)error adManager:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;


/**
 *  Called when the ad display success
 */
- (void)onInterstitialVideoShowSuccess:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;

/**
 *  Called when the ad failed to display for some reason
 *  @param error       - error object that describes the exact error encountered when showing the ad.
 */
- (void)onInterstitialVideoShowFail:(nonnull NSError *)error adManager:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;

/**
 *  Called only when the ad has a video content, and called when the video play completed
 */
- (void)onInterstitialVideoPlayCompleted:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;

/**
 *  Called only when the ad has a endcard content, and called when the endcard show
 */
- (void)onInterstitialVideoEndCardShowSuccess:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;


/**
 *  Called when the ad is clicked
 */
- (void)onInterstitialVideoAdClick:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;

/**
 *  Called when the ad has been dismissed from being displayed, and control will return to your app
 *  @param converted   - BOOL describing whether the ad has converted
 */
- (void)onInterstitialVideoAdDismissedWithConverted:(BOOL)converted adManager:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;

/**
 *  Called when the ad  did closed;
 */
- (void)onInterstitialVideoAdDidClosed:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;

 /**
*  If Interstitial Video  reward is set, you will receive this callback
*  @param achieved  Whether the video played to required rate
* @param alertWindowStatus  {@link MTGIVAlertWindowStatus} fro list of supported types
  NOTE:You can decide whether to give the reward based on that callback
 */
- (void)onInterstitialVideoAdPlayVideo:(BOOL)achieved alertWindowStatus:(MTGIVAlertWindowStatus)alertWindowStatus adManager:(MTGBidInterstitialVideoAdManager *_Nonnull)adManager;


@end
NS_ASSUME_NONNULL_END
