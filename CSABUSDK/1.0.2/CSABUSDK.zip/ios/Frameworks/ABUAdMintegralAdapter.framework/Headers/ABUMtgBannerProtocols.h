//
//  ABUMtgBannerProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/10/9.
//

#import <Foundation/Foundation.h>
#import "ABUMtgCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABUMtg_MTGBannerAdViewDelegate;
@protocol ABUMtg_MTGBannerAdView
/**
 This is a method to initialize an MTGBannerAdView with the given unit id
 
 @param adSize The size of the banner view.
 @param placementId The id of the ad placement id. You can create your ad placement from our Portal.
 @param unitId The id of the ad unit. You can create your unit id from our Portal.
 @param rootViewController The view controller that will be used to present full screen ads.
 
 */
- (nonnull instancetype)initBannerAdViewWithAdSize:(CGSize)adSize
                                       placementId:(nullable NSString *)placementId
                                            unitId:(nonnull NSString *) unitId
                                rootViewController:(nullable UIViewController *)rootViewController;
/**
 Automatic refresh time, the time interval of banner view displaying new ads, is set in the range of 10s~180s.
 If set 0, it will not be refreshed.
 You need to set it before loading ad.
 */
@property(nonatomic,assign) NSInteger autoRefreshTime;
/**
 the delegate
 */
@property(nonatomic,weak,nullable) id <ABUMtg_MTGBannerAdViewDelegate> delegate;
/**
 Begin to load banner ads
 */
- (void)loadBannerAd;
/*!
 This method is used to request ads with the token you got previously
 
 @param bidToken    - the token from bid request within MTGBidFramework.
 */

- (void)loadBannerAdWithBidToken:(nonnull NSString *)bidToken;
@end
typedef UIView<ABUMtg_MTGBannerAdView> MTGBannerAdView;

@protocol ABUMtg_MTGBannerAdViewDelegate <NSObject>

/**
 This method is called when adView ad slot is loaded successfully.
 
 @param adView : view for adView
 */
- (void)adViewLoadSuccess:(MTGBannerAdView *)adView;

/**
 This method is called when adView ad slot failed to load.
 
 @param adView : view for adView
 @param error : error
 */
- (void)adViewLoadFailedWithError:(NSError *)error adView:(MTGBannerAdView *)adView;

/**
 Sent immediately before the impression of an MTGBannerAdView object will be logged.
 
 @param adView An MTGBannerAdView object sending the message.
 */
- (void)adViewWillLogImpression:(MTGBannerAdView *)adView;

/**
 This method is called when ad is clicked.
 
 @param adView : view for adView
 */
- (void)adViewDidClicked:(MTGBannerAdView *)adView;

/**
 Called when the application is about to leave as a result of tapping.
 Your application will be moved to the background shortly after this method is called.
 
@param adView : view for adView
 */
- (void)adViewWillLeaveApplication:(MTGBannerAdView *)adView;

/**
 Will open the full screen view
 Called when opening storekit or opening the webpage in app
 
 @param adView : view for adView
 */
- (void)adViewWillOpenFullScreen:(MTGBannerAdView *)adView;

/**
 Close the full screen view
 Called when closing storekit or closing the webpage in app
 
 @param adView : view for adView
 */
- (void)adViewCloseFullScreen:(MTGBannerAdView *)adView;

/**
 This method is called when ad is Closed.

 @param adView : view for adView
 */
- (void)adViewClosed:(MTGBannerAdView *)adView;


@end


NS_ASSUME_NONNULL_END
