//
//  ABUMtgError.h
//  Pods
//
//  Created by Makaiwen on 2021/5/31.
//

#ifndef ABUMtgError_h
#define ABUMtgError_h
#import <Foundation/Foundation.h>

static inline
NSError *ABUMtgError(int code, NSString *reason) {
    return [NSError errorWithDomain:@"com.bytedance.GroMore.mintegral.adapter" code:code userInfo:@{
        NSLocalizedDescriptionKey : reason ?: @"Unknow error",
        NSLocalizedFailureReasonErrorKey : reason ?: @"Unknow error"}];
}

static inline
NSError *ABUMtgError_Setup_Failed() {
    return ABUMtgError(-1, @"Failed to set up ad.");
}

#endif /* ABUMtgError_h */
