//
//  ABUAdGdtAdapter.h
//  ABUAdGdtAdapter
//
//  Created by wangchao on 2020/3/9.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ABUGdtPersonaliseConfigAdapter.h"
