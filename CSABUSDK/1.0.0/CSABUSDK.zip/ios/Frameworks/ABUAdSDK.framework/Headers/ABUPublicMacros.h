//
//  ABUPublicMacros.h
//  ABUAdSDK
//
//  Created by CHAORS on 2021/1/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUPublicMacros : NSObject

@end

NS_ASSUME_NONNULL_END
