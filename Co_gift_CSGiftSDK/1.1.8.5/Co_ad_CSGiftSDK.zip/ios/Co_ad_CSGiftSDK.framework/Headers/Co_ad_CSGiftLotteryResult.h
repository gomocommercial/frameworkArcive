//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "Co_ad_CSGiftLotteryAward.h"

@class Co_ad_CSGiftWinAward;

/**
 * 抽奖结果
 */
@interface Co_ad_CSGiftLotteryResult : NSObject

/**
 * 抽奖结算id
 */
@property (assign, nonatomic) NSInteger play_id;

/**
 * 抽奖中奖奖品，一般只取第1个
 */
@property(strong, nonatomic) NSArray<Co_ad_CSGiftWinAward *> *awards;

/**
 * 数据是否有效
 */
@property (assign, nonatomic, readonly) BOOL isValid;

/**
 * 修复数据
 */
-(void)co_ad_fixData;

-(Co_ad_CSGiftWinAward *)co_ad_getWinAward:(NSInteger)lotterId;

@end
