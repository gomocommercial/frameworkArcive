//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, Co_ad_CSGiftAwardType) {
    Co_ad_CSGiftAwardType_cash = 4,
    Co_ad_CSGiftAwardType_token = 5,
};

/**
 * 抽奖活动奖品
 */
@interface Co_ad_CSGiftLotteryAward : NSObject

/**
 * id
 */
@property (assign, nonatomic) NSInteger awardId;

/**
 * 类型，目前只支持4现金和5积分
0: 默认
1：礼品卡
2：金币
3：道具
4：现金
5：积分
 */
@property (assign, nonatomic) Co_ad_CSGiftAwardType type;

/**
 * 名称
 */
@property (strong, nonatomic) NSString *name;

/**
 * 图片
 */
@property (strong, nonatomic) NSString *image;

/**
 * 内容
 */
@property (strong, nonatomic) NSString *content;

/**
 * 拓展信息，比如额外的金币数
 */
@property (strong, nonatomic) NSString *extra;

/**
 * 数据是否有效
 */
@property (assign, nonatomic, readonly) BOOL isValid;

/**
 * 修复数据
 */
-(void)co_ad_fixData;


@end
