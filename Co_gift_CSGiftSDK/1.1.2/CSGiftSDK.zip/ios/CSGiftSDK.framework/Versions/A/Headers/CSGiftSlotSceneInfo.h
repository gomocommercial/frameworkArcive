//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CSGiftSlotSceneCtrlInfo.h"
#import "CSGiftLotteryActivity.h"
#import "CSGiftLotteryResult.h"

@class CSGiftLotteryResultWrap;

/**
 * 老虎机弹窗场景信息
 */
@interface CSGiftSlotSceneInfo : NSObject

/**
 * 场景id，由客户端和"ab后台运营"约定
 */
@property (assign, nonatomic) NSInteger sceneId;

/**
 * 控制信息
 */
@property(strong, nonatomic) CSGiftSlotSceneCtrlInfo *ctrlInfo;

/**
 * 抽奖活动信息
 */
@property(strong, nonatomic) CSGiftLotteryActivity *lotteryActivity;

/**
 * 抽奖结果
 */
@property (strong, nonatomic) CSGiftLotteryResultWrap *lotteryResultWrap;

/**
 * 是否可以展示
 */
@property (assign, nonatomic, readonly) BOOL displayAvailable;

/**
 * 获取奖品信息
 * @return nil表示没中奖
 */
-(CSGiftWinAward *)getWinAward;

@end

