//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CSGiftSlotSceneInfo;
@class CSGiftUserInfo;
@class CSGiftWinAward;
@class CSGiftCurrencyRateModel;
@class CSGiftConsumeModel;
@class CSGiftGood;
@class CSGiftGoodRedeemInfo;

typedef void (^CSGiftPreloadHandler)(NSError *error);
typedef void (^CSGiftSlotSceneHandler)(CSGiftSlotSceneInfo *, NSError *error);
typedef void (^CSGiftUserInfoHandler)(CSGiftUserInfo *, NSError *error);
typedef void (^CSGiftCurrencyRateHandler)(CSGiftCurrencyRateModel *currencyRate, NSError *error);
typedef void (^CSGiftCustomSucceessHandler)(CSGiftWinAward *winAward);
typedef void (^CSSequencesSucceessHandler)(NSArray <CSGiftWinAward *> *winAwards);

typedef void (^CSGiftConsumeSucceessHandler)(NSString *orderId);
typedef void (^CSGiftGoodExchangeHandler)(NSString *cash ,NSInteger point);
typedef void (^CSGiftGoodsHandler)(NSArray<CSGiftGood*> *giftGoods);
typedef void (^CSGiftAuthResultHandler)(NSString *authCode,NSError *error);
/**
 sdk接入类型，用于区分国内和国外
 */
typedef NS_ENUM(NSInteger,CSGiftServiceAreaType) {
    CSGiftOtherServiceArea      =     0,            //其他区域
    CSGiftChinaServiceArea      =     1,            //中国国内
};

typedef NS_ENUM(NSInteger, CSGiftSlotMachineVCShowResult) {
    //配置信息全部拿到 可以展示
    CSGiftSlotMachineShowSuccess = 0,
    //CSGiftUserInfo 数据不存在
    CSGiftSlotMachineInfoError = 1,
    //获取老虎机样式问题
    CSGiftSlotMachineStyleError = 2,
    //广告未准备就绪
    CSGiftAdNoValid = 3,
    //老虎机超出展示次数
    CSGiftSlotMachineDissatisfyDisplayCount = 4,
};

//老虎机奖励结算状态
typedef NS_ENUM(NSInteger,CSGiftSlotMachineLotteryResult){
    CSGiftSlotMachine_Result_Common    = 10000, //正常
    CSGiftSlotMachine_Result_Repeat    = 10010, //重复兑奖
    CSGiftSlotMachine_Result_OverNumer = 10014, //用户活动抽奖次数超过
};

//礼品卡SDK 退出通知
FOUNDATION_EXPORT NSString * const CSGiftExitNotificationName;

/**
 * sdk接口类
 */
@interface CSGiftApi : NSObject


/**
 初始化SDK
 */
+(void)setup;

/**
 在APPDelegate 执行applicationDidBecomeActive 时调用
 */
+(void)applicationDidBecomeActive;


/**
 在APPDelegate 执行applicationDidEnterBackground 时调用
 */
+(void)applicationDidEnterBackground;

/**
在APPDelegate 执行application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation 时调用
*/
+ (void)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

/**
在APPDelegate 执行application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options 时调用
 // NOTE: 9.0以后使用新API接口
*/
+ (void)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options;


/// 请求支付宝授权权限
+(void)requstAlipayAuthresult:(CSGiftAuthResultHandler)result;

/**
 根据场景加载数据（若回调成功 请立即执行showSlotMachineWithNavigationVC:勿缓存数据）

 @param sceneId 场景ID
 @param slotSceneHandler 数据回调
 */
+(void)getSlotScene:(NSInteger)sceneId
        slotSceneHandler:(CSGiftSlotSceneHandler)slotSceneHandler;

/**
 * 展示老虎机
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param presentViewController 当前的控制器
 * @param info 老虎机数据
 * @param callback 结果回调
 * @param slotResultCallback 奖励状态回调
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)launchSlot:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController sceneInfo:(CSGiftSlotSceneInfo *)info ServiceAreaType:(CSGiftServiceAreaType)serviceAreaType resultBlock:(void (^)(CSGiftSlotMachineVCShowResult slotMachineVCShowStyle))callback slotMachineResultBlock:(void (^)(CSGiftSlotMachineLotteryResult))slotResultCallback;

/**
 展示详情页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
   @param serviceAreaType sdk接入类型，国内还是国外
 */
+ (void)launchLotteryDetails:(UINavigationController *)navigationVC ServiceAreaType:(CSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;

/**
 push展示购物卡兑换页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)pushCashOut:(UINavigationController *)navigationVC serviceAreaType:(CSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 push展示积分页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)pushTokenRedeem:(UINavigationController *)navigationVC ServiceAreaType:(CSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;

/**
 modal展示购物卡兑换页
 * @param currentVC 当前控制器
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)presentCashOut:(UIViewController *)currentVC serviceAreaType:(CSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 modal展示积分兑换页
 * @param currentVC 当前控制器
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)presentTokenRedeem:(UIViewController *)currentVC ServiceAreaType:(CSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 获取用户数据
 */
+(void)getUserInfo:(CSGiftUserInfoHandler)userInfoHandler;

/**
 获取汇率
 */
+(void)getCurrencyRate:(CSGiftCurrencyRateHandler)currencyRateHandler;

/**
 自定义事件
 error code 10001：活动过期 10002：禁止抽奖，spin不够或者无免费抽奖 10003：中奖 10004：不中奖
 10006：没有同步用户数据 10012：用户礼品卡宝箱抽奖次数超过 10014：用户活动抽奖次数超过
 */
+ (void)handleCustomEventWithSequence:(NSInteger)sequence successHandler:(CSGiftCustomSucceessHandler)successHandler failureHandler:(CSGiftPreloadHandler)failureHandler;


/// 多活动自定义事件
/// @param sequences 活动sequence字符串数组
/// @param successHandler 成功回调
/// @param failureHandler error code 10001：活动过期 10002：禁止抽奖，spin不够或者无免费抽奖 10003：中奖 10004：不中奖 10006：没有同步用户数据 10012：用户礼品卡宝箱抽奖次数超过 10014：用户活动抽奖次数超过
+ (void)handleCustomEventWithSequences:(NSArray <NSString*>*)sequences successHandler:(CSSequencesSucceessHandler)successHandler failureHandler:(CSGiftPreloadHandler)failureHandler;


/// 消费接口
/// @param model CSGiftConsumeModel
/// @param successHandler 成功
/// @param failureHandler 失败
+ (void)handleConsume:(CSGiftConsumeModel *)model successHandler:(CSGiftConsumeSucceessHandler)successHandler failureHandler:(CSGiftPreloadHandler)failureHandler;


/// 获取商品列表接口
/// @param isLimitGroup 是否指定商品组
/// @param group 指定商品组号
/// @param isLimitSequence 是否指定组内序号
/// @param sequence 指定组内序号
/// @param successHandler 返回商品列表成功的回调
/// @param failureHandler 失败的回调
+ (void)getGiftGoodsIsLimitGroup:(BOOL)isLimitGroup
                                   group:(NSInteger)group
                         isLimitSequence:(BOOL)isLimitSequence
                                sequence:(NSInteger)sequence
                          successHandler:(CSGiftGoodsHandler)successHandler
                          failureHandler:(CSGiftPreloadHandler)failureHandler;


/// 商品兑换接口
/// @param model  兑换模型 CSGiftGoodRedeemInfo
/// @param successHandler 兑换成功 10000：正常 返回剩余现金和积分
/// @param failureHandler 兑换失败 错误码 10007：现金不够 10011：积分不够 10013：库存不够
+ (void)handleGoodExchange:(CSGiftGoodRedeemInfo *)model successHandler:(CSGiftGoodExchangeHandler)successHandler failureHandler:(CSGiftPreloadHandler)failureHandler;


// MARK: - 当SDK外部使用ap/谷歌激励视频时 需在适当的时候调用以下API
/**
 开始展示广告
 */
+ (void)externalOnAdShowed;
/**
 点击广告
 */
+ (void)externalOnAdClicked;
/**
 关闭广告
 */
+ (void)externalOnAdClosed;
/**
 激励视频计费代理
 */
+ (void)externalOnAdVideoCompletePlaying;

@end
