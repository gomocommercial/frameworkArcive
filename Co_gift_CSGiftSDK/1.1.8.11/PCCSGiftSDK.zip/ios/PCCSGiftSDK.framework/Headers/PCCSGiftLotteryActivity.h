//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

@class PCCSGiftLotteryAward;

typedef NS_ENUM(NSInteger, PCCSGiftActivityType) {
 //老虎机
 PCCSGiftActivityType_slot = 5,
 //大刮刮卡
 PCCSGiftActivityType_bigCard = 6,
 //小刮刮卡
 PCCSGiftActivityType_smallCard = 7,
 //自定义事件
 PCCSGiftActivityType_custom = 9
};

/**
 * 抽奖活动信息. 对应http协议里的 LotterDetail
 * 抽奖流程：
 * 1。 首先获取抽奖活动信息PCCSGiftLotteryDetail，
 * 2。 再用活动去获取抽奖信息PCCSGiftLotteryResult（含结算id和奖品列表--仅用于展示），
 * 3。 最后用抽奖信息里的结算id去结算
 */
@interface PCCSGiftLotteryActivity : NSObject

/**
 * 活动id
 */
@property (assign, nonatomic) NSInteger activityId;

/**
 * 活动名称
 */
@property (strong, nonatomic) NSString *name;

/**
 * 活动组（类型）
 * 0：默认
1：Buffett Card
2：King of WallStreet Card
3：Millionaire Card
4：King of Quizdom Card
5：老虎机（手动兑奖）
6：大刮刮卡
7：小刮刮卡
 */
@property (assign, nonatomic) PCCSGiftActivityType group;

/**
 * 封面图
 */
@property (strong, nonatomic) NSString *cover;

/**
 * 组内序号，界面显示顺序。
 */
@property (assign, nonatomic) NSInteger sequence;

/**
 * 最大可刮奖次数, -1表示无限
 */
@property (assign, nonatomic) NSInteger maxLotteryCountPerDay;

/**
 * 活动奖品列表
 */
@property (strong, nonatomic) NSArray<PCCSGiftLotteryAward *> *awards;

/**
 * 数据是否有效
 */
@property (assign, nonatomic, readonly) BOOL isValid;

/**
 * 是否不限次数抽奖
 */
@property (assign, nonatomic, readonly) BOOL isLotteryCountUnlimited;

/**
 * 修复数据
 */
-(void)pCfixData;

/**
 * 当天剩余抽奖次数
 * @param lotteryCountTody
 * @return
 */
-(NSInteger)pCgetRemainLotteryCount:(NSInteger)lotteryCountTody;

/**
 * 是否已达到最大抽奖次数
 * @param lotteryCountToday
 * @return
 */
-(BOOL)pCisMeetMaxLotteryCount:(NSInteger)lotteryCountToday;

//-----上边是http协议数据-----分割线-----下边是界面数据------
/**
 * 是否中奖
 */
@property (nonatomic,assign) BOOL isWin;

/**
 * 刮刮卡中奖图案
 */
@property (nonatomic,copy,readonly) NSString *bonusImage;

/**
 * 刮刮卡随机图案数组
 */
@property (nonatomic,copy,readonly) NSArray *winImageArray;



@end
