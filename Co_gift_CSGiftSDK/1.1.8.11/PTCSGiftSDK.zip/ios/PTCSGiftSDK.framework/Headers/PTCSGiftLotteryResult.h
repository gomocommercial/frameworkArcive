//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "PTCSGiftLotteryAward.h"

@class PTCSGiftWinAward;

/**
 * 抽奖结果
 */
@interface PTCSGiftLotteryResult : NSObject

/**
 * 抽奖结算id
 */
@property (assign, nonatomic) NSInteger play_id;

/**
 * 抽奖中奖奖品，一般只取第1个
 */
@property(strong, nonatomic) NSArray<PTCSGiftWinAward *> *awards;

/**
 * 数据是否有效
 */
@property (assign, nonatomic, readonly) BOOL isValid;

/**
 * 修复数据
 */
-(void)pTfixData;

-(PTCSGiftWinAward *)pTgetWinAward:(NSInteger)lotterId;

@end
