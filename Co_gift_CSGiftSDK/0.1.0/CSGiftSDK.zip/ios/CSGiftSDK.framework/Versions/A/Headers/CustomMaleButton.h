//
//  CustomMaleButton.h
//  AFNetworking
//
//  Created by wlighting on 2019/4/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomMaleButton : UIButton

@end

NS_ASSUME_NONNULL_END
