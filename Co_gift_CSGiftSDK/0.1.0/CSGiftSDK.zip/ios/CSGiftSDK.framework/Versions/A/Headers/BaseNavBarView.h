//
//  BaseNavBarView.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/15.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseNavBarView : UIView

    
@property (nonatomic,weak) UIButton *leftButton;

@property (nonatomic,weak) UIButton *rightButton;

@property (nonatomic,weak) UIImageView *titleImageView;
    
@property (nonatomic,weak) UILabel *titleLabel;


@end

NS_ASSUME_NONNULL_END
