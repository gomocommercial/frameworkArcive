//
//  CSCashOutVC.h
//  AFNetworking
//
//  Created by wlighting on 2019/3/26.
//

#import "CSBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@class CSGiftUserInfo;

@interface CSCashOutVC : CSBaseViewController

@property (nonatomic,strong) CSGiftUserInfo *cSGiftUserInfo;

@end

NS_ASSUME_NONNULL_END
