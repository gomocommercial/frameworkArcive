//
// Created by matt on 2019-03-27.
//

#import <Foundation/Foundation.h>
#import "RACSignal.h"

@interface RACSignal (CSGiftSdk)

+(RACSignal *)signalFrom:(id)object orError:(NSError *)error;

@end
