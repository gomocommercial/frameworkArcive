//
//  CSGiftAbStatistics.h
//  abtestcentersdk
//
//  Created by linqiaogeng on 2018/8/2.
//

#import <Foundation/Foundation.h>

@interface CSGiftAbStatistics : NSObject


/**
 @param statisticsObject 统计对象
 @param associationObject 关联对象
 @param entrance 入口
 @param remark 备注
 */
+ (void)abRequestStatisticWithStatisticsObject:(NSString *)statisticsObject
                             associationObject:(NSString *)associationObject
                                      entrance:(NSString *)entrance
                                        remark:(NSString *)remark;
/**
 @param statisticsObject 统计对象
 @param tab Tab分类
 @param entrance 入口
 @param position 位置
 */

+ (void)abRetentionStatisticWithStatisticsObject:(NSString *)statisticsObject
                                             tab:(NSString *)tab
                                        entrance:(NSString *)entrance
                                        position:(NSString *)position ;
@end
