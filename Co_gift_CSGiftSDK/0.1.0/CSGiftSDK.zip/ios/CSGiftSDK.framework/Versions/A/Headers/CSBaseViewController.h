//
//  CSBaseViewController.h
//  AFNetworking
//
//  Created by wlighting on 2019/3/25.
//

#import <UIKit/UIKit.h>

#import "BaseNavBarView.h"
#import "CSBottomUserInfoView.h"

NS_ASSUME_NONNULL_BEGIN


@interface CSBaseViewController : UIViewController

@property (nonatomic,strong) BaseNavBarView *cSbaseNavBarView;

@property (nonatomic,weak) CSBottomUserInfoView *cSBottomUserInfoView;
- (void)setUpInitialSubView;
- (void)back;
@end

NS_ASSUME_NONNULL_END
