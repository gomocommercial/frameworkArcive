//
//  CSGiftWinAwardCacheManager.h
//  AFNetworking
//
//  Created by qiaoming on 2019/3/28.
//

#import <Foundation/Foundation.h>
#import "CSGiftLotteryActivity.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftWinAwardCacheManager : NSObject

//已结算的广告id缓存中是否存在 activityId
+(BOOL)isExitActivityId:(NSString *)activityId;
//结算一个广告id 放入缓存
+(void)hasCloseAnActivityId:(NSInteger)activityId;
//清楚缓存
+(void)cleanCacheOfActivityIds;

//获取已经抽奖的 奖品ids
+(NSArray *)getCacheAwardIds;
@end

NS_ASSUME_NONNULL_END
