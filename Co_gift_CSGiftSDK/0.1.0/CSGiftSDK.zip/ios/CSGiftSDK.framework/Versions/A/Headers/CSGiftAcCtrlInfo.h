//
// Created by matt on 2019-03-20.
//

#import <Foundation/Foundation.h>

@class CSGiftSlotSceneCtrlInfo;

/**
 * Ac控制信息
 */
@interface CSGiftAcCtrlInfo : NSObject

@property(strong, nonatomic) NSDictionary *jsonInfo;

-(CSGiftSlotSceneCtrlInfo *)getSlotSceneCtrlInfo:(NSInteger)sceneId;

@end
