//
//  CSUserInfoEditView.h
//  CSGiftSDK
//
//  Created by wlighting on 2019/3/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSUserInfoEditView : UIView

@property (nonatomic,weak) UILabel *titleLabel;

@property (nonatomic,weak) UITextField *editTextField;



@end

NS_ASSUME_NONNULL_END
