//
//  CSGNetworkErrorView.h
//  AFNetworking
//
//  Created by Zy on 2019/4/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGNetworkErrorView : UIView


+ (void)showErrorWithAction:(void(^ _Nonnull)(void))action;

+ (void)hide;

@end

NS_ASSUME_NONNULL_END
