//
//  CSGiftAbBuilder.h
//  abtestcentersdk
//
//  Created by linqiaogeng on 2018/8/1.
//

#import <Foundation/Foundation.h>

@class CSGiftAbCenterService;

@interface CSGiftAbBuilder : NSObject
@property(nonatomic, copy) NSArray<NSString *> *sids;

@property(nonatomic, assign) NSString *sid;
@property(nonatomic, assign) NSInteger cid;
@property(nonatomic, assign) NSInteger cid2;
@property(nonatomic, assign) NSInteger entrance;
@property(nonatomic, assign) NSInteger cdays;
@property(nonatomic, assign) NSInteger isupgrade;

@property(nonatomic, copy) NSString *local;
@property(nonatomic, copy) NSString *utmSource;
@property(nonatomic, copy) NSString *userForm;

- (CSGiftAbCenterService *)build;
@end
