//
//  CSAdLoadBase+giftCache.h
//  AFNetworking
//
//  Created by Zy on 2019/3/29.
//

#import <CSAdSDK/CSAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadBase (giftCache)

@property (nonatomic, assign) NSTimeInterval giftLoadTime;

@end

NS_ASSUME_NONNULL_END
