//
// Created by matt on 2019-03-20.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, CSGiftSlotStyle) {
    //没有样式，即关闭老虎机弹窗功能
            CSGiftSlotStyle_none = 0,
    //默认样式
            CSGiftSlotStyle_default = 1,
    //直接奖励样式：先出奖励，再看广告
            CSGiftSlotStyle_rewardFirst = 2,
    //自动转动样式(点击stop直接看广告  自己停止弹奖励弹框)
            CSGiftSlotStyle_rotateAuto = 3,
    //无奖励样式：先出广告，看完再出奖励
            CSGiftSlotStyle_adFirst = 4,
};

typedef NS_ENUM(NSInteger, CSGiftSlotReturn) {
    //默认返回处理
    CSGiftSlotReturn_default = 1,
    //返回详情页
    CSGiftSlotReturn_details = 2,
};

typedef NS_ENUM(NSInteger, CSGiftSlotAdPriority) {
    //优先展示全屏
    CSGiftSlotAdPriority_interstitial = 1,
    //优先展示激励视频
    CSGiftSlotAdPriority_reward = 2,
};

/**
 * 老虎机场景控制信息，来自于ac
 */
@interface CSGiftSlotSceneCtrlInfo : NSObject

/**
 * 场景id
 */
@property (assign, nonatomic) NSInteger sceneId;

/**
 * 老虎机样式 ab-->@SerializedName("style_priority")
 */
@property (assign, nonatomic) CSGiftSlotStyle style;

/**
 * 广告展示时机，第几次弹窗才展示广告 ab-->@SerializedName("ad_opportunity")
 */
@property (assign, nonatomic) NSInteger adFirstShowTime;

/**
 * 用户点击关闭，是否回到抽奖详情页 ab-->@SerializedName("return_close")
 */
@property (assign, nonatomic) BOOL isBackToLotteryDetails;

/**
 * 是否优先展示全屏广告 ab-->@SerializedName("style_priority")
 */
@property (assign, nonatomic) BOOL isShowInterstitialAdFirst;



@end
