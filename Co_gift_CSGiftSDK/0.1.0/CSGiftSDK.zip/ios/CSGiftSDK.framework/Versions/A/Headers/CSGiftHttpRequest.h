//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, HttpMethod) {
    HttpGet, // GET
    HttpPost, // POST
};

@class CSGiftHttpRequest;
@class CSGiftHttpResponse;
@class CSGiftHttpError;

typedef void (^HttpSuccessHandler)(CSGiftHttpRequest *request, CSGiftHttpResponse *response);
typedef void (^HttpFailureHandler)(CSGiftHttpRequest *request, CSGiftHttpResponse *response, CSGiftHttpError *error);

@interface CSGiftHttpRequest : NSObject

/**
 * url的base
 */
@property(strong, nonatomic) NSString *baseUrl;

/**
 * url的相对路径
 */
@property(strong, nonatomic) NSString *relativeUrl;

/**
 * url里的键值对参数
 */
@property(strong, nonatomic) NSDictionary *queryStrings;

/**
 * 键值对-payload
 */
@property(strong, nonatomic) NSDictionary *parameters;

/**
 * 请求类型
 */
@property (assign, nonatomic) HttpMethod method;

/**
 * 响应信息，每个request必定会有个非空response
 */
@property(strong, nonatomic) CSGiftHttpResponse *response;

/**
 * 成功回调
 */
@property(strong, nonatomic) HttpSuccessHandler successHandler;

/**
 * 失败回调
 */
@property(strong, nonatomic) HttpFailureHandler failureHandler;

/**
 * 缓存key，也是缓存机制开关
 */
@property(strong, nonatomic) NSString *cacheKey;

/**
 * 缓存有效时长，单位秒
 */
@property(assign, nonatomic) NSTimeInterval cacheValidTime;

/**
 * 添加QueryString
 * @param key
 * @param value
 */
-(void)setQueryString:(NSString *)key value:(NSString *)value;

-(void)setParameter:(NSString *)key value:(NSString *)value;

/**
 * 发起请求
 */
-(void)start;

/**
 * 构建device
 * @return
 */
+(NSString *)createDevice;

@end
