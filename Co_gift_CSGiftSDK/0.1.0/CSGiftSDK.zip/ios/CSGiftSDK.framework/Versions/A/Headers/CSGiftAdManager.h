//
//  CSGiftAdManager.h
//  AFNetworking
//
//  Created by Zy on 2019/3/25.
//

#import <Foundation/Foundation.h>
#import <CSAdSDK/CSAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSUInteger {
    CSGiftAdShowComplete,//广告播放成功完成
    CSGiftAdShowCloseEarly,//广告过早关闭
    CSGiftAdShowing,//广告正在播放
    CSGiftAdShowFailed,//广告播放失败
    CSGiftAdShowNoValid//广告播放未准备好
} CSGiftAdShowStatus;

typedef void(^CSGiftAdShowStatusBlock)(NSString * moduleId, CSGiftAdShowStatus status);

@interface CSGiftAdManager : NSObject

+ (instancetype)manager;


/**
 是否加载admob激励视频（默认为yes）需在广告加载前配置
 */
@property (nonatomic, assign) BOOL loadExternalAdmobRewardVideo;


/**
 广告SDK初始化配置
 */
- (void)setupByBlock:(void(^)(CSAdSetupParamsMaker * _Nonnull maker))block;


/**
 检测缓存时间
 */
- (void)checkCacheTime;
/**
 开始加载广告
 */
- (void)loadAd;

/**
 广告SDK是否已准备完成
 */
- (BOOL)isValid;


/**
 插屏广告已经准备完成
 */
- (BOOL)interstitialiIsValid;

/**
 开始展示广告
 */
- (void)show:(UIViewController *)viewController
          completion:(CSGiftAdShowStatusBlock _Nonnull) completion;

/**
 展示插屏广告
 */
- (void)showInterstitial:(UIViewController *)viewController completion:(CSGiftAdShowStatusBlock _Nonnull)completion;


// MARK: - 外部使用谷歌激励视频

/**
 开始展示广告
 */
- (void)externalOnAdShowed;


/**
 点击广告
 */
- (void)externalOnAdClicked;


/**
 关闭广告
 */
- (void)externalOnAdClosed;


/**
 激励视频计费代理
 */
-(void)externalOnAdVideoCompletePlaying;

@end

NS_ASSUME_NONNULL_END
