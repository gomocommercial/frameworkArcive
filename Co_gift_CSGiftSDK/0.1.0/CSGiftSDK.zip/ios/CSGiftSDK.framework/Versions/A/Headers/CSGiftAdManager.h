//
//  CSGiftAdManager.h
//  AFNetworking
//
//  Created by Zy on 2019/3/25.
//

#import <Foundation/Foundation.h>
#import <CSAdSDK/CSAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSUInteger {
    CSGiftAdShowComplete,//广告播放成功完成
    CSGiftAdShowCloseEarly,//广告过早关闭
    CSGiftAdShowing,//广告正在播放
    CSGiftAdShowFailed,//广告播放失败
    CSGiftAdShowNoValid//广告播放未准备好
} CSGiftAdShowStatus;

typedef void(^CSGiftAdShowStatusBlock)(CSGiftAdShowStatus status);

@interface CSGiftAdManager : NSObject

+ (instancetype)manager;

/**
 广告SDK初始化配置
 */
- (void)setupByBlock:(void(^)(CSAdSetupParamsMaker * _Nonnull maker))block;


/**
 检测缓存时间
 */
- (void)checkCacheTime;
/**
 开始加载广告
 */
- (void)loadAd;

/**
 广告SDK是否已准备完成
 */
- (BOOL)isValid;


/**
 插屏广告已经准备完成
 */
- (BOOL)interstitialiIsValid;

/**
 开始展示广告
 */
- (void)show:(UIViewController *)viewController
          completion:(CSGiftAdShowStatusBlock _Nonnull) completion;


/**
 展示插屏广告
 */
- (void)showInterstitial:(UIViewController *)viewController completion:(CSGiftAdShowStatusBlock _Nonnull)completion;
/**
 加载广告测试数据
 */
- (void)adTest;

@end

NS_ASSUME_NONNULL_END
