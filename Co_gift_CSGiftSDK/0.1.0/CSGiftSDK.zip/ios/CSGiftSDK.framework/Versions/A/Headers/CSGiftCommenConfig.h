//
//  CSGiftCommenConfig.h
//  Pods
//
//  Created by qiaoming on 2019/3/14.
//

//todo debug by matt 移动到con~~
#import "MBProgressHUD.h"
#import "CSGiftHttpError.h"

#define Gift_WeakSelf(type) autoreleasepool{} __weak __typeof__(type) weakSelf = type;
#define Gift_StrongSelf(type) autoreleasepool{} __strong __typeof__(type) strongSelf = type;

//获取设备的物理高度
#define GiftScreenHeight [UIScreen mainScreen].bounds.size.height
//获取设备的物理宽度
#define GiftScreenWidth [UIScreen mainScreen].bounds.size.width
//获取NavigationbBar 高度
#define GiftNavigationbBarHeight  44
//获取状态栏高度
#define GiftStatusBarHeight [UIApplication sharedApplication].statusBarFrame.size.height
// 转换像素
#define GiftW(x) (((x) / 1.5 * (GiftScreenWidth / 375.0)) / 2.0)
#define GiftH(x) (((x) / 1.5 * (GiftScreenHeight / 667.0)) / 2.0)

/**
 *  HUD自动隐藏
 *
 */
#define GiftHUDNormal(msg) {MBProgressHUD *hud=[MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication].delegate window] animated:NO];\
hud.mode = MBProgressHUDModeText;\
hud.minShowTime=1;\
NSInteger timeCount = 1;\
NSString *m;\
if (![msg isKindOfClass:NSString.class]){\
m = [NSString stringWithFormat:@"%@",(msg)];\
}else{ m = (msg); }\
if (m.length > 20) {\
timeCount = 3;\
}\
else if (m.length > 10){\
    timeCount = 2;\
}\
hud.detailsLabel.text = m;\
hud.detailsLabel.font = [UIFont systemFontOfSize:18];\
[hud hideAnimated:YES afterDelay:timeCount];\
}
