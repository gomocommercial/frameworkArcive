//
// Created by matt on 2019-03-20.
//

#import <Foundation/Foundation.h>

@class CSGiftLotteryActivity;
@class CSGiftLotteryResult;
@class CSGiftWinAward;
@class CSGiftCardStateInfo;

/**
 * 刮刮卡数据
 */
@interface CSGiftScratchCard : NSObject

/**
 * 刮刮卡id
 */
@property(strong, nonatomic, readonly) NSString *scratchCardId;

/**
 * 大刮刮卡
 */
@property(strong, nonatomic) CSGiftLotteryActivity *bigCard;

/**
 * 小刮刮卡
 */
@property(strong, nonatomic) CSGiftLotteryActivity *smallCard;

/**
 * 抽奖结果
 */
@property(strong, nonatomic) CSGiftLotteryResult *lotteryResult;

/**
 * 刮刮卡使用情况
 */
@property(strong, nonatomic) CSGiftCardStateInfo *stateInfo;

////todo debug by matt
///**
// * 当天使用次数
// */
//@property (assign, nonatomic) NSInteger useCountToday;
//
///**
// * 上次刮卡时间
// */
//@property (assign, nonatomic) NSInteger lastScratchTimeStampMillsec;

/**
 * 获取再次刮卡倒计时，单位：毫秒
 * @return
 */
-(NSInteger)getCratchCountDown;

/**
 * 获取大刮刮卡中奖奖品
 * @return nil表示不中奖
 */
-(CSGiftWinAward *)getBigCardWinAward;

/**
 * 获取小刮刮卡中奖奖品
 * @return nil表示不中奖
 */
-(CSGiftWinAward *)getSmallCardWinAward;

//todo debug by matt
///**
// * 上次play日期
// */
//@property (nonatomic,strong) NSDate *playingDate;

/**
 * 是否CD完成
 */
@property (nonatomic,assign,readonly) BOOL isAvailable;
/**
 * 倒计时终了时间
 */
@property (nonatomic,copy) NSString *availableTime;
/**
 * 倒计时显示时间
 */
@property (nonatomic,copy,readonly) NSString *countTime;

/**
 * 最大次数
 */
@property (nonatomic,assign,readonly) NSInteger maxCount;

/**
 * 剩余次数
 */
@property (nonatomic,assign,readonly) NSInteger remainCount;

@end
