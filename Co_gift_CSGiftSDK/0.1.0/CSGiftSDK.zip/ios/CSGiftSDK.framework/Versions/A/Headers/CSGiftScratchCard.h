//
// Created by matt on 2019-03-20.
//

#import <Foundation/Foundation.h>

@class CSGiftLotteryActivity;
@class CSGiftLotteryResult;
@class CSGiftWinAward;
@class CSGiftCardStateInfo;
@class CSGiftLotteryResultWrap;

/**
 * 刮刮卡数据
 */
@interface CSGiftScratchCard : NSObject

/**
 * 刮刮卡id
 */
@property(strong, nonatomic, readonly) NSString *scratchCardId;

/**
 * 大刮刮卡
 */
@property(strong, nonatomic) CSGiftLotteryActivity *bigCard;

/**
 * 小刮刮卡
 */
@property(strong, nonatomic) CSGiftLotteryActivity *smallCard;

/**
 * 抽奖结果
 */
@property(strong, nonatomic) CSGiftLotteryResultWrap *lotteryResultWrap;

/**
 * 刮刮卡使用情况
 */
@property(strong, nonatomic) CSGiftCardStateInfo *stateInfo;

/**
 * 获取大刮刮卡中奖奖品
 * @return nil表示不中奖
 */
-(CSGiftWinAward *)getBigCardWinAward;

/**
 * 获取小刮刮卡中奖奖品
 * @return nil表示不中奖
 */
-(CSGiftWinAward *)getSmallCardWinAward;

/**
 * 剩余次数
 */
@property (nonatomic,assign,readonly) NSInteger remainCount;

/**
 * 再次刮卡倒计时，单位：秒
 */
@property (assign, nonatomic, readonly) NSInteger scratchCountDown;

/**
 * 刮刮卡倒计时，格式"HH:mm:ss"
 */
@property(strong, nonatomic, readonly) NSString *scratchCountDownString;

/**
 * 是否可用（CD完成）
 */
@property (nonatomic,assign,readonly) BOOL isAvailable;

/**
 * 刮刮卡最大使用次数
 */
@property (assign, nonatomic, readonly) NSInteger maxCount;

/**
 * 倒计时显示时间
 */
@property (nonatomic,copy,readonly) NSString *countTime;



@end
