//
//  CSSlotMachineSceneOneView.h
//  AFNetworking
//
//  Created by qiaoming on 2019/3/22.
//

#import <UIKit/UIKit.h>
#import "CSGiftSlotMachineContentView.h"
#import "CSRewardCashView.h"
#import "CSGiftWinAward.h"
#import "CSGiftLotteryActivity.h"
#import "CSGiftLotteryResultWrap.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSSlotMachineSceneOneView : UIView

@property (nonatomic, strong) UIImageView *topImg;
@property (nonatomic, strong) UILabel *descLab;
@property (nonatomic, strong) UIImageView *backgroudImg;
@property (nonatomic, strong) UIImageView *lightImg;
@property (nonatomic, strong) CSGiftSlotMachineContentView *machineContentView;
@property (strong, nonatomic) UIButton *playBtn;
@property (nonatomic, assign) BOOL playBtnCanStop;
/*
*canClickCount 老虎机剩余可抽奖的次数
*canClickTotalCount 后台返回的当天老虎机抽奖的总次数
*/
@property (assign, nonatomic) NSInteger canClickCount;
@property (strong, nonatomic) NSMutableArray *slotMachineData;
//活动
@property (strong, nonatomic) CSGiftLotteryActivity *lotteryActivity;

@property (assign, nonatomic) NSInteger canClickTotalCount;
/*
* 抽奖结果的toast
*/
@property (strong, nonatomic) CSRewardCashView *rewardCashView;
//@property (nonatomic, strong) CSGiftWinAward *awardResult;
@property (nonatomic, strong) CSGiftLotteryResultWrap *lotteryResultWrap;

@property (nonatomic, copy) void(^slotMachineLotteryFinishCompleted)(CSGiftLotteryResultWrap *lotteryResultWrap, BOOL isNoAutoStop);
@property (nonatomic, copy) void(^slotMachineLotteryGoToDetail)(NSDictionary *resultDic);
@property (nonatomic, copy) void(^slotMachineLotteryCloseClick)(void);
@property (nonatomic, copy) void(^slotMachineLotteryPlayButtonClickToPlay)(BOOL success,CSGiftLotteryResultWrap *lotteryResultWrap);
@property (nonatomic, copy) void(^slotMachineCountDownCompleted)(void);

/*
*canClickCount 老虎机剩余可抽奖的次数
*canClickTotalCount 后台返回的当天老虎机抽奖的总次数
*/
-(void)resetSlotMachineResidueCanClickCount:(NSInteger)canClickCount slotMachineCanClickTotalCount:(NSInteger)canClickTotalCount slotMachineData:(NSArray *)slotArray;

-(void)beginFire;
- (void)beginToPlay:(UIButton *)sender;
-(void)setPlayButtonState:(NSInteger)index;
-(void)updateCashOrCoinData;
@end

NS_ASSUME_NONNULL_END
