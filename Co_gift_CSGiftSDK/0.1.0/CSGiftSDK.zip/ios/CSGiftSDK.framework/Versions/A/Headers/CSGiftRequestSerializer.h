//
// Created by matt on 2019-03-15.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>

@interface CSGiftRequestSerializer : AFJSONRequestSerializer
@end
