//
//  NavigationController.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/15.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
