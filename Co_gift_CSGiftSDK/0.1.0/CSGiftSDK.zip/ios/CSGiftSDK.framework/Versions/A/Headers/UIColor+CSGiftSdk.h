//
//  UIColor+CSGiftSdk.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/22.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (CSGiftSdk)
/*
Example: @"0xF0F", @"66ccff", @"#66CCFF88"

@param hexStr  The hex string value for the new color.

@return        An UIColor object from string, or nil if an error occurs.
*/
+ (nullable UIColor *)colorWithHexString:(NSString *)hexStr;


@end

NS_ASSUME_NONNULL_END
