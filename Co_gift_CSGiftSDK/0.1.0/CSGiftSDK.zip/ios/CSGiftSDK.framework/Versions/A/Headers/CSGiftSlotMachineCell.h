//
//  CSGiftTigerCell.h
//  tagerTest
//
//  Created by qiaoming on 2019/3/18.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftSlotMachineCell : UICollectionViewCell
@property (strong, nonatomic) UIImageView *img;
    
@end

NS_ASSUME_NONNULL_END
