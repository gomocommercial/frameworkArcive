//
// Created by matt on 2019-03-25.
//

#import <Foundation/Foundation.h>


@interface CSGiftInitParams : NSObject
@end
