//
//  CSGiftAbCommonUtils.h
//  abtestcentersdk
//
//  Created by linqiaogeng on 2018/8/1.
//

#import <Foundation/Foundation.h>

@interface CSGiftAbCommonUtils : NSObject

+ (NSData *)uncompressZippedData:(NSData *)compressedData;

+ (NSString *)decryptUseDES:(NSData *)cipherData key:(NSString *)key keyNeedBase64:(BOOL)keyNeedBase64;
@end
