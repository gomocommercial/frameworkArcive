//
//  CSGiftProgressHUD.h
//  AFNetworking
//
//  Created by Zy on 2019/4/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftProgressHUD : NSObject

//展示loading动画
+ (void)giftShowLoading NS_AVAILABLE_IOS(8_0);

//隐藏
+ (void)hideHUD;
@end

NS_ASSUME_NONNULL_END


