//
// Created by matt on 2019-04-02.
//

#import <Foundation/Foundation.h>
#import "CSGiftGoodRedeemInfo.h"
#import "CSGiftGood.h"

@class RACSignal;

@interface CSGiftRedeemRepository : NSObject

+ (instancetype)sharedInstance;

/**
 * 获取商品列表
 * @return NSArray <CSGiftGood *> *
 */
-(RACSignal *)getGoods:(CSGiftRedeemWay)redeemWay;

/**
 * 获取现金兑换的商品
 * @return CSGiftGood
 */
-(RACSignal *)getCashGood;
/**
 * 获取所有的商品
 */
//- (RACSignal *)getAllGoodsScrollTittle;
/**
 * 兑换商品
 * @param redeemInfo
 * @return CSGiftHttpResponse
 */
-(RACSignal *)redeemGood:(CSGiftGoodRedeemInfo *)redeemInfo;

@end
