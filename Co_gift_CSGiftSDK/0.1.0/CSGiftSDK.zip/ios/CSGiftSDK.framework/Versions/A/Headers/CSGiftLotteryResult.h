//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "CSGiftLotteryAward.h"

@class CSGiftWinAward;

/**
 * 抽奖结果
 */
@interface CSGiftLotteryResult : NSObject

/**
 * 抽奖结算id
 */
@property (assign, nonatomic) NSInteger play_id;

/**
 * 抽奖中奖奖品，一般只取第1个
 */
@property(strong, nonatomic) NSArray<CSGiftWinAward *> *awards;

-(CSGiftWinAward *)getWinAward:(NSInteger)lotterId;

@end
