//
// Created by matt on 2019-04-04.
//

#import <Foundation/Foundation.h>

@class CSGiftStEntry103Maker;


@interface CSGiftStatistics : NSObject


+ (void)upload103:(void(^)(CSGiftStEntry103Maker *maker)) block;

@end
