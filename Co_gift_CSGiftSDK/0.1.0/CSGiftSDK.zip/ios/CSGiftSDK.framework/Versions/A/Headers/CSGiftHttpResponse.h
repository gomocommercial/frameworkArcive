//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CSGiftHttpError;

/**
 * http响应
 */
@interface CSGiftHttpResponse : NSObject

/**
 * 业务编码，服务器处理结果
 */
@property (assign, nonatomic) NSInteger code;

/**
 * 业务数据
 */
@property(strong, nonatomic) id data;

/**
 * 响应时间戳
 */
@property (assign, nonatomic) NSInteger timestamp;

/**
 * 响应错误
 */
@property(strong, nonatomic) CSGiftHttpError *error;

/**
 * 原始响应
 */
@property(strong, nonatomic) NSHTTPURLResponse *originalResponse;

/**
 * 原始响应数据
 */
@property(strong, nonatomic) NSString *originalResponseObject;

@end



