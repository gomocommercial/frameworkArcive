//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CSGiftScratchCard.h"

@class RACSignal;

//每个刮刮卡每天最多使用次数
#define maxUseCountForScratchCard 5

/**
 * 抽奖详情页数据仓库
 */
@interface CSGLotteryDetailsRepository : NSObject

+ (instancetype)sharedInstance;

/**
 * 获取详情页数据
 * @return CSGiftLotteryDetailsData
 */
-(RACSignal *)getLotteryCards;

/**
 * 获取刮刮卡抽奖结果 CSGiftScratchCard
 * ps：点击刮刮卡时，要调用此接口获取到抽奖结果，才能跳刮刮卡页面
 * @return CSGiftScratchCard
 */
-(RACSignal *)getLotteryResult:(CSGiftScratchCard *)scratchCard;

/**
 * 抽奖结算
 * @return CSGiftHttpResponse
 */
-(RACSignal *)storeLottery:(CSGiftScratchCard *)scratchCard;

/**
 * 检查并处理过期数据
 * @return
 */
-(BOOL)checkCardStateInfosIfOutOfDate;

@end
