//
// Created by matt on 2019-03-22.
//

#import <Foundation/Foundation.h>

/**
 * 刮刮卡使用情况，本地缓存数据
 */
@interface CSGiftCardStateInfo : NSObject

/**
 * 刮刮卡id
 */
@property(strong, nonatomic) NSString *scratchCardId;

/**
 * 当天使用次数
 */
@property (assign, nonatomic) NSInteger useCountToday;

/**    
 * 上次刮卡时间，使用服务器时间
 */
@property (assign, nonatomic) NSInteger lastScratchTimeStamp;

+(CSGiftCardStateInfo *)findInArray:(NSArray *)stateInfos withId:(NSString *)scratchCardId;

@end
