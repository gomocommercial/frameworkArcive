//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, HttpErrorType) {
    /**
     * 网络异常
     */
    HttpError_netException,
    /**
     * 服务器异常：400、404、5xx、10006（没有同步用户数据）等
     */
    HttpError_serverReject,
    /**
     * 数据解析异常
     */
    HttpError_dataParseFail,
};


/**
 * 请求错误
 */
@interface CSGiftHttpError : NSObject

/**
 * 类型
 */
@property (assign, nonatomic) HttpErrorType type;

/**
 * 错误码
 */
@property (assign, nonatomic) NSInteger code;

/**
 * 错误信息
 */
@property(strong, nonatomic) NSString *msg;

/**
 * AFNetworking返回的错误
 */
@property(strong, nonatomic) NSError *afError;

@end
