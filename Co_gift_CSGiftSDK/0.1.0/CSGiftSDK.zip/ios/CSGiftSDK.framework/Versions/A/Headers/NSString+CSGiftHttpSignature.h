//
// Created by matt on 2019-03-16.
//

#import <Foundation/Foundation.h>

@interface NSString (CSGiftHttpSignature)

+(NSString *)hmacSHA256ThenBase64:(NSString *)key value:(NSString *)value;

+(NSString *)base64UrlSafe:(NSString *)content;

@end
