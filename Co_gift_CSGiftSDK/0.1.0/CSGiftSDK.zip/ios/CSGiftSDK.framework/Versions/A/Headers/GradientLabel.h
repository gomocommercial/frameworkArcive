//
//  GradientLabel.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/14.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger, GradientDirection) {//渐变色的方向
    GradientDirectionLeftToRight = 0,          //左 --> 右
    GradientDirectionTopLeftToBottomRight = 1, //左上 --> 右下
    GradientDirectionBottomLeftToTopRight = 2,  //左下 --> 右上
    GradientDirectionTopToTopBottom = 3 //上 -> 下
};
@interface GradientLabel : UILabel


/**
 金色字体
 */
+(instancetype)goldenColerLabel;

/**
 黄色字体
 */
+(instancetype)yellowColerLabel;

-(instancetype)initWithColors:(NSArray <UIColor *>*)colors;

-(instancetype)initWithColors:(NSArray <UIColor *>*)colors
            gradientDirection:(GradientDirection)gradientDirection;

@property(nonatomic, strong)NSArray <UIColor *>* colors;
@property(nonatomic, assign)GradientDirection gradientDirection;

@end
