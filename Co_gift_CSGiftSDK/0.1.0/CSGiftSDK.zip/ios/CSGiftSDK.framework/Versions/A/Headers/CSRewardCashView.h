//
//  CSRewardCashView.h
//  AFNetworking
//
//  Created by qiaoming on 2019/3/26.
//

#import <UIKit/UIKit.h>
#import "CSGiftWinAward.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, CSRewardCashViewType) {
        //现金 无get按钮
    CSRewardCashViewType_cash_tap_continue = 0,
        //现金 无get按钮
    CSRewardCashViewType_cash = 1,
        //金币 无get按钮
    CSRewardCashViewType_token = 2,
    CSRewardCashViewTypeNone = 3,//无奖励样式
};

@interface CSRewardCashView : UIView

@property (nonatomic, copy) void(^rewardCashViewCloseBtnClick)(CSGiftWinAward *awardResult, CSRewardCashViewType type);
@property (nonatomic, copy) void(^rewardCashViewGetBtnClick)(CSGiftWinAward *awardResult, CSRewardCashViewType type);

-(instancetype)initWithFrame:(CGRect)frame type:(CSRewardCashViewType)cashViewType awardResult:(CSGiftWinAward *)awardResult;
-(void)showInView:(UIView *)view;
@end

NS_ASSUME_NONNULL_END
