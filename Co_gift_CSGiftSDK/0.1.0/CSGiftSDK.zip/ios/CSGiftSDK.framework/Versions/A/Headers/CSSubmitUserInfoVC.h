//
//  CSSubmitUserInfoVC.h
//  CSGiftSDK
//
//  Created by wlighting on 2019/3/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CSGiftGood;

@interface CSSubmitUserInfoVC : UIViewController

@property (nonatomic,strong) CSGiftGood *giftGood;

@property (nonatomic,copy) void(^redeemSuccessBlock)(void);

@end

NS_ASSUME_NONNULL_END
