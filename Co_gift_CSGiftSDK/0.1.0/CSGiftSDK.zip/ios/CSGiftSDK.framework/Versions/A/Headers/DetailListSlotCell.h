//
//  DetailListSlotCell.h
//  AFNetworking
//
//  Created by wlighting on 2019/3/22.
//

#import <UIKit/UIKit.h>

#import "CSSlotMachineSceneTwoView.h"

NS_ASSUME_NONNULL_BEGIN

@interface DetailListSlotCell : UITableViewCell

@property (nonatomic,weak) CSSlotMachineSceneTwoView *slotMachineView;

@end

NS_ASSUME_NONNULL_END
