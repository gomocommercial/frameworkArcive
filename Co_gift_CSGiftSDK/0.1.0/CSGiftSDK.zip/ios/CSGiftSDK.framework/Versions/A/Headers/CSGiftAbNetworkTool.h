//
//  CSGiftAbNetworkTool.h
//  abtestcentersdk
//
//  Created by linqiaogeng on 2018/7/31.
//

#import <Foundation/Foundation.h>
#import "CSGiftAbCenterService.h"

@interface CSGiftAbNetworkTool : NSObject

- (void)requestAbtestWithService:(CSGiftAbCenterService *) abtestCenterService complete:(CSGAbRequestCompleteBlock)complete;

- (void)parseRespondWithResponseDic:(NSDictionary *)responseDic;

@property(nonatomic, copy) CSGAbRequestCompleteBlock giftAbRequestCompleteBlock;
@end
