//
//  CSTigerVC.h
//  AFNetworking
//
//  Created by qiaoming on 2019/3/18.
//

#import <UIKit/UIKit.h>
//#import "CSBaseViewController.h"
#import "CSSlotMachineSceneOneView.h"
#import "CSGiftWinAward.h"
#import "CSGiftLotteryActivity.h"
#import "CSGiftSlotSceneCtrlInfo.h"
#import "CSGiftSlotSceneCtrlInfo.h"
#import "CSGiftLotteryResult.h"

typedef NS_ENUM(NSInteger, CSGiftSlotMachineVCShowStyle) {
    //配置信息全部拿到 可以展示
    CSGiftSlotMachineShowSuccess = 0,
    //获取ab配置失败
    CSGiftSlotMachineGetABFail = 1,
    //获取场景信息失败
    CSGiftSlotMachineGetSceneConfigFail = 2,
    //其他error
    CSGiftSlotMachineError = 3,
    //没有可用广告
    CSGiftSlotMachineNoAvailableAD = 4,
};

@interface CSGiftSlotMachineVC : UIViewController

@property (nonatomic, strong) CSGiftLotteryResultWrap *lotteryResultWrap;
@property (nonatomic, strong) CSGiftWinAward *awardResult;
//@property (nonatomic,assign) CSSlotMachineScrollType scrollType;
@property (nonatomic,assign) CSGiftSlotStyle scrollType;
@property (nonatomic,strong) CSSlotMachineSceneOneView *sceneOneView;
/*
*canClickCount 老虎机剩余可抽奖的次数
*canClickTotalCount 后台返回的当天老虎机抽奖的总次数
*/
@property (assign, nonatomic) NSInteger canClickCount;
/*
*中奖奖品数组
*/
@property (strong, nonatomic) NSMutableArray *slotMachineData;
//活动
@property (strong, nonatomic) CSGiftLotteryActivity *lotteryActivity;
//控制信息
@property (strong, nonatomic) CSGiftSlotSceneCtrlInfo *ctrlInfo;

@property (assign, nonatomic) NSInteger canClickTotalCount;

@property (nonatomic,strong) UINavigationController *pushNavigationController;

-(void)showSlotMachineWithNavigationVC:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController sceneId:(NSInteger)sceneId resultBlock:(void (^)(CSGiftSlotMachineVCShowStyle slotMachineVCShowStyle))callback;

@end

