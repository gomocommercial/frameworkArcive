//
//  CSTigerVC.h
//  AFNetworking
//
//  Created by qiaoming on 2019/3/18.
//

#import <UIKit/UIKit.h>
#import "CSBaseViewController.h"
#import "CSSlotMachineSceneOneView.h"
#import "CSGiftWinAward.h"
#import "CSGiftLotteryActivity.h"
#import "CSGiftSlotSceneCtrlInfo.h"
#import "CSGiftSlotSceneCtrlInfo.h"
#import "CSGiftLotteryResult.h"

NS_ASSUME_NONNULL_BEGIN

///*
//* 老虎机的转动模式
//*/
//typedef NS_ENUM(NSInteger, CSSlotMachineScrollType) {
//    //普通模式 手动转动, 转动完需要看广告结算
//    CSSlotMachineScrollTypeDefault = 0,
//    //普通模式 手动转动, 转动完不需要看广告  直接结算
//    CSSlotMachineScrollTypeDefaultNoAd = 1,
//    //自动模式, 转动完需要看广告  直接结算
//    CSSlotMachineScrollTypeAutoScroll = 2,
//    //自动模式, 转动完不需要看广告  直接结算
//    CSSlotMachineScrollTypeAutoScrollNoAd = 3
//};

@interface CSGiftSlotMachineVC : CSBaseViewController

@property (nonatomic, strong) CSGiftLotteryResult *lotteryResult;
@property (nonatomic, strong) CSGiftWinAward *awardResult;
//@property (nonatomic,assign) CSSlotMachineScrollType scrollType;
@property (nonatomic,assign) CSGiftSlotStyle scrollType;
@property (nonatomic,strong) CSSlotMachineSceneOneView *sceneOneView;
/*
*canClickCount 老虎机剩余可抽奖的次数
*canClickTotalCount 后台返回的当天老虎机抽奖的总次数
*/
@property (assign, nonatomic) NSInteger canClickCount;
/*
*中奖奖品数组
*/
@property (strong, nonatomic) NSMutableArray *slotMachineData;
//活动
@property (strong, nonatomic) CSGiftLotteryActivity *lotteryActivity;
//控制信息
@property (strong, nonatomic) CSGiftSlotSceneCtrlInfo *ctrlInfo;

@property (assign, nonatomic) NSInteger canClickTotalCount;

@end

NS_ASSUME_NONNULL_END
