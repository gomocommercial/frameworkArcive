//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CSGiftSlotMachineVC.h"

@class CSGiftSlotSceneInfo;
@class CSGiftUserInfo;

typedef void (^CSGiftSlotSceneHandler)(CSGiftSlotSceneInfo *, NSError *error);
typedef void (^CSGiftUserInfoHandler)(CSGiftUserInfo *, NSError *error);

/**
 * sdk接口类
 */
@interface CSGiftApi : NSObject


/**
 初始化SDK
 */
+(void)setup;


/**
 在APPDelegate 执行applicationDidBecomeActive 时调用
 */
+(void)applicationDidBecomeActive;


/**
 根据场景加载数据（若回调成功 请立即执行showSlotMachineWithNavigationVC:勿缓存数据）

 @param sceneId 场景ID
 @param slotSceneHandler 数据回调
 */
+(void)getSlotScene:(NSInteger)sceneId
        slotSceneHandler:(CSGiftSlotSceneHandler)slotSceneHandler;


//展示老虎机(待修改)
+(void)showSlotMachineWithNavigationVC:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController sceneId:(NSInteger)sceneId resultBlock:(void (^)(CSGiftSlotMachineVCShowStyle slotMachineVCShowStyle))callback;

/**
 开始展示老虎机

 @param slotSceneInfo 老虎机数据
 */
+(void)launchSlot:(CSGiftSlotSceneInfo *)slotSceneInfo;


/**
 展示详情页
 */
+(void)launchLotteryDetails;


/**
 获取用户数据
 */
+(void)getUserInfo:(CSGiftUserInfoHandler)userInfoHandler;



@end
