//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CSGiftSlotSceneInfo;
@class CSGiftUserInfo;

typedef void (^CSGiftSlotSceneHandler)(CSGiftSlotSceneInfo *, NSError *error);
typedef void (^CSGiftUserInfoHandler)(CSGiftUserInfo *, NSError *error);

/**
 * sdk接口类
 */
@interface CSGiftApi : NSObject

+(void)setup;

+(void)applicationDidBecomeActive;

+(void)getSlotScene:(NSInteger)sceneId
        slotSceneHandler:(CSGiftSlotSceneHandler)slotSceneHandler;

+(void)lauchSlot:(CSGiftSlotSceneInfo *)slotSceneInfo;

+(void)launchLotteryDetails;

+(void)getUserInfo:(CSGiftUserInfoHandler)userInfoHandler;

@end
