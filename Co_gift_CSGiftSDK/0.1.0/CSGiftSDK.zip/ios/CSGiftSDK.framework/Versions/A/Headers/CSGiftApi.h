//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CSGiftSlotMachineVC.h"

@class CSGiftSlotSceneInfo;
@class CSGiftUserInfo;

typedef void (^CSGiftSlotSceneHandler)(CSGiftSlotSceneInfo *, NSError *error);
typedef void (^CSGiftUserInfoHandler)(CSGiftUserInfo *, NSError *error);

/**
 * sdk接口类
 */
@interface CSGiftApi : NSObject

+(void)setup;

+(void)applicationDidBecomeActive;

+(void)getSlotScene:(NSInteger)sceneId
        slotSceneHandler:(CSGiftSlotSceneHandler)slotSceneHandler;

+(void)launchSlot:(CSGiftSlotSceneInfo *)slotSceneInfo;

+(void)launchLotteryDetails;

+(void)getUserInfo:(CSGiftUserInfoHandler)userInfoHandler;

//展示老虎机
+(void)showSlotMachineWithNavigationVC:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController sceneId:(NSInteger)sceneId resultBlock:(void (^)(CSGiftSlotMachineVCShowStyle slotMachineVCShowStyle))callback;

@end
