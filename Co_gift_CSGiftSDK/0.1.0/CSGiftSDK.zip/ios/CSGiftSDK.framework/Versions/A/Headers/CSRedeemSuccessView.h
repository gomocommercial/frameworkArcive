//
//  CSRedeemSuccessView.h
//  AFNetworking
//
//  Created by wlighting on 2019/4/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CSRedeemSuccessView;

@protocol CSRedeemSuccessViewDelegate <NSObject>


- (void)CSRedeemSuccessViewContinued:(CSRedeemSuccessView *)redeemSuccessView;

@end

@interface CSRedeemSuccessView : UIView

@property (nonatomic,weak) id <CSRedeemSuccessViewDelegate>delegate;

@end

NS_ASSUME_NONNULL_END
