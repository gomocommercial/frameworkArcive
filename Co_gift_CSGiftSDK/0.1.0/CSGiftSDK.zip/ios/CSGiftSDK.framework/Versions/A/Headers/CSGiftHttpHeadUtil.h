//
// Created by matt on 2019-03-16.
//

#import <Foundation/Foundation.h>


@interface CSGiftHttpHeadUtil : NSObject

+(NSString *)getLanguage;

+(NSString *)getCountry;

/**
 * 获取网络类型
 * @return
 */
+(NSString *)getNetType;

+(NSString *)getBundleVersion;

+(NSString *)getBundleShortVersion;

/**
 * 获取机型信息
 * @return
 */
+(NSString *)getPhoneModel;

+(NSString *)getCpuAbi;

/**
 * 获取系统版本名称
 * @return
 */
+(NSString *)getSystemVersionName;

/**
 * 获取时区
 * @return
 */
+(NSString *)getTimeZone;

/**
 * 获取当前时间戳
 * @return
 */
+(NSInteger)getTimeStampMilliSec;

/**
 * 获取当前时间戳
 * @return
 */
+(NSString *)getTimeStampMilliSecString;


@end
