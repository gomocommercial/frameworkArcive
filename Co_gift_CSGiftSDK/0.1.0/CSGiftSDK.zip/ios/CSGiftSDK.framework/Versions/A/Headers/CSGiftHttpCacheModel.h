//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CSGiftHttpCacheModel : NSObject

@property(strong, nonatomic) NSString *key;

@property(strong, nonatomic) NSString *url;

@property(strong, nonatomic) NSDictionary *response;

@property(strong, nonatomic) NSDate *saveDate;

@end
