//
//  CSGiftUtil.h
//  AFNetworking
//
//  Created by Zy on 2019/4/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftUtil : NSObject


/**
 获取顶层Window视图
 */
+ (UIWindow *)topWindow;


/**
 获取顶层控制器视图
 */
+(UIViewController*)topViewController;

//简单存储
+ (void)userDefaultSaveForKey:(NSString *)key value:(id)value;
+ (id)userDefaultGet:(NSString *)key;
+ (void)userDefaultRemove:(NSString *)key;

/**
 根据不同样式获取当天展示的次数

 @param type
 */
+ (NSInteger)todayEarnToastShowNumber:(NSInteger)type;

@end

NS_ASSUME_NONNULL_END
