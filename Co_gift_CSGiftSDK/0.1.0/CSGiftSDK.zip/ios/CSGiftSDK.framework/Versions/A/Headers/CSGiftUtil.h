//
//  CSGiftUtil.h
//  AFNetworking
//
//  Created by Zy on 2019/4/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftUtil : NSObject


/**
 获取顶层Window视图
 */
+ (UIWindow *)topWindow;


/**
 获取顶层控制器视图
 */
+(UIViewController*)topViewController;

@end

NS_ASSUME_NONNULL_END
