//
//  CSTokenRedeemDetailView.h
//  CSGiftSDK
//
//  Created by wlighting on 2019/3/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSTokenRedeemDetailView : UIView


/**
 兑换
 */
@property (nonatomic,copy) void(^redeemBlock)(void);


@end

NS_ASSUME_NONNULL_END
