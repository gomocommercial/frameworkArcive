//
//  CSTokenRedeemDetailView.h
//  CSGiftSDK
//
//  Created by wlighting on 2019/3/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CSGiftGood;

@interface CSTokenRedeemDetailView : UIView

@property (nonatomic,strong) CSGiftGood *giftGood;
/**
 兑换
 */
@property (nonatomic,copy) void(^redeemBlock)(CSGiftGood *cSGiftGood );


@end

NS_ASSUME_NONNULL_END
