//
//  CSGiftSlotMachineContentView.h
//  AFNetworking
//
//  Created by qiaoming on 2019/3/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftSlotMachineContentView : UIView

//老虎机滚动结束的回调
@property (nonatomic, copy) void(^slotMachineScrollCompleted)(BOOL autoStop);

-(instancetype)initWithFrame:(CGRect)frame leftVTop:(CGFloat)top leftVbottom:(CGFloat)bottom SlotMachineCellHeight:(CGFloat)slotMachineCellHeight;
/*
*抽奖前 重置老虎机初始界面
*resultArr抽奖结果(需要转为数字)
*timeTotalCount老虎机定时器次数(自动模式 均为5秒120  手动模式为120, 144, 168)
*canClickCount 老虎机剩余可抽奖的次数
*canClickTotalCount 后台返回的当天老虎机抽奖的总次数
*/
-(void)resetSlotMachineContentOffsetYWithResult:(NSArray<NSNumber *> *)resultArr timeTotalCount:(NSArray *)timeTotalCount;
-(void)stopClick;
-(void)beginFire;

@end

NS_ASSUME_NONNULL_END
