//
//  CSGiftWonRollView.h
//  AFNetworking
//
//  Created by Zy on 2019/3/28.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftWonRollView : UIView

+ (CSGiftWonRollView *)viewWithPoint:(CGPoint)point;

- (void)setGiftList:(NSArray <NSString *> *)giftList;

@end

@interface CSGiftWonRollCell : UICollectionViewCell

- (void)reset:(NSString *)title;

@end

NS_ASSUME_NONNULL_END
