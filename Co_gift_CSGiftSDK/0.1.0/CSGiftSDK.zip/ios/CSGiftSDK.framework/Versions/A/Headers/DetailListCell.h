//
//  DetailListCell.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/15.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CSGiftScratchCard;

@interface DetailListCell : UITableViewCell
    
@property (nonatomic,strong) CSGiftScratchCard *giftScratchCard;
/** 倒计时 */
@property (nonatomic,weak) UILabel *timeCountLabel;

@property (nonatomic,copy)  void(^rfereshBlock)(void);

@end

NS_ASSUME_NONNULL_END
