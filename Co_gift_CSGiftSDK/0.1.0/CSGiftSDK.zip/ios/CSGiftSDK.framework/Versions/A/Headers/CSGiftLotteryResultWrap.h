//
// Created by matt on 2019-04-01.
//

#import <Foundation/Foundation.h>

@class CSGiftLotteryResult;

/**
 * 中奖结果包装，主要是为了方便清除失效的中奖信息
 */
@interface CSGiftLotteryResultWrap : NSObject

@property(strong, nonatomic) CSGiftLotteryResult *value;

+ (CSGiftLotteryResultWrap *)allocFromValue:(CSGiftLotteryResult *)value;

- (void)setNewestResult:(CSGiftLotteryResult *)result;

@end
