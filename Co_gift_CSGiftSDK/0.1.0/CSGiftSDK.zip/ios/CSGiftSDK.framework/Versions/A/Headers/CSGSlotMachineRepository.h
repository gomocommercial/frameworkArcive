//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "CSGiftApi.h"

@class RACSignal;
@class CSGiftLotteryActivity;
@class CSGiftLotteryResult;
@class CSGiftSlotSceneCtrlInfo;

/**
 * 老虎机数据仓库
 *
 */
@interface CSGSlotMachineRepository : NSObject

/**
 * 老虎机场景控制信息
 */
@property(strong, nonatomic) NSArray<CSGiftSlotSceneCtrlInfo *> *sceneCtrlInfos;

/**
 * 老虎机活动信息
 */
@property(strong, nonatomic) CSGiftLotteryActivity *activity;

/**
 * 中奖信息，跟老虎机活动id绑定。消费后自动缓存一个。
 */
@property(strong, nonatomic) CSGiftLotteryResult *lotteryResult;

/**
 * 当天展示次数
 */
@property (assign, nonatomic) NSInteger displayCountToday;

/**
 * 累计展示次数
 */
@property (assign, nonatomic) NSInteger displayCountTotal;


+ (instancetype)sharedInstance;

-(BOOL)isAvailableDisplay:(CSGiftSlotSceneInfo *)sceneInfo;

/**
 * 获取场景信息 CSGiftSlotSceneInfo.
 * 弹窗界面不应缓存场景信息（主要是中奖信息不能缓存）
 * @param sceneId
 */
-(RACSignal *)getSlotScene:(NSInteger)sceneId;

/**
 * 获取中奖结果
 * @return
 */
-(RACSignal *)getLotteryResult;

/**
 * 抽奖结算
 * @return
 */
-(RACSignal *)storeLottery;

/**
 * 添加展示次数
 */
-(void)addDisplayCount;

@end
