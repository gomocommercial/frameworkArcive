//
//  GOMOAdManager.h
//  abtestcentersdk
//
//  Created by linqiaogeng on 2018/8/1.
//

#import <Foundation/Foundation.h>

@class CSGiftAbBuilder;

typedef enum : NSInteger {
    CSGiftAbStatusSuccess = 1,
    CSGiftAbStatusFailure = -1,
    CSGiftAbStatusLocal = 2,
} CSGiftAbStatus;

typedef enum : NSInteger {
    CSGiftMAIN_PACKAGE = 1,
    CSGiftTHEME = 2,
    CSGiftTEST = 999

} CSGiftAbEntrance;


#define GMAbLog(fmt, ...) {\
if ([CSGiftConfig sharedInstance].enableLog) {\
NSLog((@"%s[Line %d] GM_AB_LOG:" fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);\
} else {}\
}

typedef void (^CSGAbRequestCompleteBlock)(CSGiftAbStatus abStatus, NSDictionary *resDic, NSError *error);

typedef void (^CSGAbManagerBuilder)(CSGiftAbBuilder *gomoAbBuilder);

@interface CSGiftAbCenterService : NSObject
@property(nonatomic, assign) NSInteger cid;
@property(nonatomic, assign) NSInteger cid2;
@property(nonatomic, assign) NSInteger entrance;
@property(nonatomic, assign) NSInteger cdays;
@property(nonatomic, assign) NSInteger isupgrade;
@property(nonatomic, copy) NSString *sid;
@property(nonatomic, copy) NSString *local;
@property(nonatomic, copy) NSString *utmSource;
@property(nonatomic, copy) NSString *userForm;

+ (instancetype)createWithBuilder:(CSGAbManagerBuilder)block;

- (void)requestAbtest:(CSGAbRequestCompleteBlock)complete;

+ (void)retentionStaticsWithCid2:(NSInteger)cid2 sid:(NSString *)sid abtestId:(NSInteger)abtestId filterId:(NSInteger)filterId;

@end
