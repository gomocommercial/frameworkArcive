//
//  DetailListVC.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/15.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import "CSBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DetailListVC : CSBaseViewController

@property (nonatomic, assign) NSInteger adFirstTime;

@property (nonatomic, copy)void(^ _Nonnull slotAction)(void);

@end

NS_ASSUME_NONNULL_END
