//
//  CSSlotMachineSceneTwoView.h
//  AFNetworking
//
//  Created by qiaoming on 2019/3/21.
//

#import <UIKit/UIKit.h>
#import "CSGiftSlotMachineContentView.h"
#import "CSRewardCashView.h"
#import "CSGiftWinAward.h"
#import "CSGiftLotteryActivity.h"
#import "CSGiftLotteryResult.h"

@class CSGiftLotteryResultWrap;

NS_ASSUME_NONNULL_BEGIN

@interface CSSlotMachineSceneTwoView : UIView
/*
* 抽奖结果的toast
*/
@property (strong, nonatomic) CSRewardCashView *rewardCashView;
@property (nonatomic, strong) UIImageView *backgroudImg;
@property (nonatomic, strong) CSGiftSlotMachineContentView *machineContentView;
@property (strong, nonatomic) UIButton *playBtn;
//活动
@property (strong, nonatomic) CSGiftLotteryActivity *lotteryActivity;
/*
*canClickCount 老虎机剩余可抽奖的次数
*canClickTotalCount 后台返回的当天老虎机抽奖的总次数
*/
@property (assign, nonatomic) NSInteger canClickCount;
@property (assign, nonatomic) NSInteger canClickTotalCount;
@property (nonatomic, strong) UIImageView *lightImg;
@property (nonatomic, strong) CSGiftWinAward *awardResult;
@property (nonatomic, strong) CSGiftLotteryResultWrap *lotteryResultWrap;

@property (nonatomic, copy) void(^slotMachineLotteryFinishCompleted)(CSGiftLotteryResultWrap *lotteryResultWrap);
@property (nonatomic, copy) void(^slotMachineLotteryPlayButtonClickToPlay)(CSGiftLotteryResultWrap *lotteryResultWrap);
@property (nonatomic, copy) void(^slotMachineCountDownCompleted)(void);
/*
*canClickCount 老虎机剩余可抽奖的次数
*canClickTotalCount 后台返回的当天老虎机抽奖的总次数
*/
-(void)resetSlotMachineResidueCanClickCount:(NSInteger)canClickCount slotMachineCanClickTotalCount:(NSInteger)canClickTotalCount;
-(void)beginFire;
-(void)setPlayButtonState:(NSInteger)index;

@end

NS_ASSUME_NONNULL_END
