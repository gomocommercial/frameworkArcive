//
// Created by matt on 2019-03-18.
//

#import <Foundation/Foundation.h>

@interface NSString (CSGiftSdk)

+(NSString *)stringFromData:(NSData *)data;

+(NSData *)dataFromString:(NSString *)string;

+(NSString *)jsonStringFromDictionary:(NSDictionary *)dictionary;

/**
 正则匹配
 */
- (BOOL)isRegex:(NSString *)regexStr;

@end
