//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * （用于兑换的）商品信息
 */
@interface CSGiftGood : NSObject

/**
 * 商品id
 */
@property (assign, nonatomic) NSInteger goodId;

/**
 * 类型，0：购物卡
 */
@property (assign, nonatomic) NSInteger type;

/**
 * 名称
 */
@property(strong, nonatomic) NSString *name;

/**
 * 图片
 */
@property(strong, nonatomic) NSString *image;

/**
 * 价格
 */
@property (assign, nonatomic) NSInteger price;

/**
 * 积分价格
 */
@property (assign, nonatomic) NSInteger point_price;

/**
 * 描述信息
 */
@property(strong, nonatomic) NSString *descriptionString;

/**
 * 库存
 */
@property (assign, nonatomic) NSInteger stock;

/**
 * 用户注册地区
 * 用于显示现金价格图案
 */
@property(strong, nonatomic) NSString *country;

/**
 * 兑换方式
 * 1现金 2积分
 */
@property(assign, nonatomic) NSInteger redeem_way;

@end
