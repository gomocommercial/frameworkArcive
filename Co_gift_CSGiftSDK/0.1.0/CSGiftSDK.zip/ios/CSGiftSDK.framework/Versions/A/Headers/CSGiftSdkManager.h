//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "CSGiftApi.h"

/**
 * sdk管理器，处理核心业务逻辑
 */
@interface CSGiftSdkManager : NSObject

+ (instancetype)sharedInstance;

-(void)setup;

-(void)getSlotScene:(NSInteger)sceneId
           slotSceneHandler:(CSGiftSlotSceneHandler)slotSceneHandler;

-(void)launchSlot:(CSGiftSlotSceneInfo *)slotSceneInfo;

-(void)launchLotteryDetails;

-(void)getUserInfo:(CSGiftUserInfoHandler)userInfoHandler;

@end
