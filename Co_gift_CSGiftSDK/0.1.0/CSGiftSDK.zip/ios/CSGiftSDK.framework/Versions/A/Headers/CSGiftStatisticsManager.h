//
//  CSGiftStatisticsManager.h
//  CSGiftSDK
//
//  Created by qiaoming on 2019/4/3.
//

#import <Foundation/Foundation.h>
#import "CSGiftSlotSceneCtrlInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftStatisticsManager : NSObject

+ (void)uploadStatisticsStatisticsObject:(NSString *)statisticsObject operationCode:(NSString *)operationCode tab:(NSString *)tab position:(NSString *)position associationObject:(NSString *)associationObject;

//弹框展示样式的统计 , 弹框点击
+ (void)slotMachineAppearStatisticsObject:(CSGiftSlotStyle)slotStyle operationCode:(NSString *)operationCode;
//弹框关闭
//+ (void)slotMachineAppearStatisticsObject:(CSGiftSlotStyle)slotStyle operationCode:(NSString *)operationCode;

@end

NS_ASSUME_NONNULL_END
