//
//  CSGiftStatisticsManager.h
//  CSGiftSDK
//
//  Created by qiaoming on 2019/4/3.
//

#import <Foundation/Foundation.h>
#import "CSGiftSlotSceneCtrlInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftStatisticsManager : NSObject

+ (void)uploadStatisticsStatisticsObject:(NSString *)statisticsObject operationCode:(NSString *)operationCode tab:(NSString *)tab position:(NSString *)position associationObject:(NSString *)associationObject;

//弹框展示样式的统计 , 弹框点击
+ (void)slotMachineAppearStatisticsObject:(CSGiftSlotStyle)slotStyle operationCode:(NSString *)operationCode;
//弹框关闭
//+ (void)slotMachineAppearStatisticsObject:(CSGiftSlotStyle)slotStyle operationCode:(NSString *)operationCode;

+ (void)uploadStatisticsOperationCode:(NSString *)operationCode;

+ (void)uploadStatisticsOperationCode:(NSString *)operationCode tab:(NSString *)tab;

+ (void)uploadStatisticsOperationCode:(NSString *)operationCode tab:(NSString *)tab associationObject:(NSString *)associationObject;

+ (void)uploadStatisticsOperationCode:(NSString *)operationCode tab:(NSString *)tab position:(NSString *)position;

+ (void)uploadStatisticsOperationCode:(NSString *)operationCode position:(NSString *)position;

/**
发起广告流程

 @param associationObject 虚拟模块ID
 */
+ (void)adRequest:(NSString *)associationObject;


/**
 广告请求

 @param associationObject 虚拟模块ID
 */
+ (void)adLoad:(NSString *)associationObject;


/**
 广告缓存成功

 @param statisticsObject 类名
 @param tab 1、缓存已经存在；2、请求返回成功
 @param associationObject 虚拟模块ID
 */
+ (void)adRequestSus:(NSString *)statisticsObject tab:(NSString *)tab associationObject:(NSString *)associationObject;


@end

NS_ASSUME_NONNULL_END
