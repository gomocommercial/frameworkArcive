//
// Created by matt on 2019-03-20.
//

#import <Foundation/Foundation.h>
#import "CSGiftUserBaseInfo.h"

@class CSGiftUserInfo;
@class RACSignal;
@class CSGiftUpdateUserInfo;


@interface CSGUserInfoRepository : NSObject

+ (instancetype)sharedInstance;

/**
 * 用户信息
 */
@property(strong, nonatomic) CSGiftUserInfo *userInfo;

/**
 * 用户信息更新标记
 */
@property (assign, nonatomic) NSInteger userInfoChangeFlag;

/**
 * 获取用户信息 CSGiftUserInfo。
 * @return
 */
-(RACSignal *)getUserInfo;

/**
 * 更新用户信息
 * @param updateUserInfo
 * @return CSGiftHttpResponse
 */
-(RACSignal *)updateUserInfo:(CSGiftUpdateUserInfo *)updateUserInfo;

-(void)updateCash:(NSString *)cash withToken:(NSInteger)token;

-(void)updateUserBaseInfo:(CSGiftUserBaseInfo *)userBaseInfo;

@end
