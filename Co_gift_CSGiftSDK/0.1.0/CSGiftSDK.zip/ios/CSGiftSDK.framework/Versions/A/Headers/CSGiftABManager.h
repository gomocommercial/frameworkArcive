//
//  CSGiftABManager.h
//  AFNetworking
//
//  Created by Zy on 2019/3/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftABManager : NSObject

/**
 获取AB配置
 */
+ (void)loadABWithCompletion:(void(^_Nullable)( NSDictionary * _Nullable dic ,  NSError * _Nullable error))completion;


@end

NS_ASSUME_NONNULL_END
