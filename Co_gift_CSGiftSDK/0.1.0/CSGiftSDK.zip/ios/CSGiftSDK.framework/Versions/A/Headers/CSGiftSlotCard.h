//
// Created by matt on 2019-03-20.
//

#import <Foundation/Foundation.h>

@class CSGiftLotteryActivity;

/**
 * 抽奖详情页的老虎机卡片数据
 */
@interface CSGiftSlotCard : NSObject

/**
 * 活动数据
 */
@property(strong, nonatomic) CSGiftLotteryActivity *activity;


@end
