//
// Created by matt on 2019-03-22.
//

#import <Foundation/Foundation.h>

@interface NSDate (CSGiftSdk)

+(NSInteger)dayFromTimeStamp:(NSInteger)timeStampMillSec;

+(BOOL)isSameDay:(NSInteger)timeStamp timeStamp2:(NSInteger)timeStamp2;

@end
