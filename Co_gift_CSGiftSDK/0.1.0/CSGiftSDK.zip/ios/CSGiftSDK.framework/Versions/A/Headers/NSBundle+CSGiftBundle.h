//
//  NSBundle+CSGiftBundle.h
//  CSGiftSDK
//
//  Created by qiaoming on 2019/3/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (CSGiftBundle)

//返回资源文件的bundle
+(NSBundle *)getGiftBundlePath;

//读取资源文件的多语言文案
+ (NSString *)localizedStringForKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
