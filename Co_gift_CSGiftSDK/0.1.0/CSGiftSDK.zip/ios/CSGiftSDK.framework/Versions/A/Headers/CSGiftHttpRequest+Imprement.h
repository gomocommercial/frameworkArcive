//
// Created by matt on 2019-03-18.
//

#import <Foundation/Foundation.h>
#import "CSGiftHttpRequest.h"
#import "CSGiftConfig.h"
#import "CSGiftUpdateUserInfo.h"
#import "CSGiftGoodRedeemInfo.h"

@interface CSGiftHttpRequest (Imprement)

/**
 * 用户注册，只需调用一次
 * @param successHandler
 * @param failureHandler
 */
+(void)register:(HttpSuccessHandler)successHandler
         failureHandler:(HttpFailureHandler)failureHandler;

/**
 * 获取用户信息
 * @param successHandler
 * @param failureHandler
 */
+(void)getUserInfo:(HttpSuccessHandler)successHandler
         failureHandler:(HttpFailureHandler)failureHandler;

/**
 * 更新用户信息，用于兑奖用户信息填写
 * @param userInfo
 * @param successHandler
 * @param failureHandler
 */
+(void)updateUserInfo:(CSGiftUpdateUserInfo *)userInfo
               successHandler:(HttpSuccessHandler)successHandler
               failureHandler:(HttpFailureHandler)failureHandler;

/**
 * 获取抽奖活动
 * @param successHandler
 * @param failureHandler
 */
+(void)getLotteryDetails:(HttpSuccessHandler)successHandler
                  failureHandler:(HttpFailureHandler)failureHandler;

/**
 * 获取抽奖结果
 * @param lotteryIds
 * @param successHandler
 * @param failureHandler
 *
 */
+(void)getLotteryResult:(NSArray<NSNumber *> *)lotteryIds
                 successHandler:(HttpSuccessHandler)successHandler
                  failureHandler:(HttpFailureHandler)failureHandler;

/**
 * 结算抽奖结果
 * @param play_id 结算id，即getLotteryResult接口返回的play_id
 * @param successHandler
 * @param failureHandler
 *
 */
+(void)storeLotteryResult:(NSInteger)play_id
                   successHandler:(HttpSuccessHandler)successHandler
                  failureHandler:(HttpFailureHandler)failureHandler;

/**
 * 获取（用于兑换的）商品列表
 * @param successHandler
 * @param failureHandler
 */
+(void)getGoods:(HttpSuccessHandler)successHandler
                  failureHandler:(HttpFailureHandler)failureHandler;

/**
 * （用现金、积分）兑换商品（目前仅礼品卡）
 * @param redeemInfo
 * @param successHandler
 * @param failureHandler
 */
+(void)redeemGood:(CSGiftGoodRedeemInfo *)redeemInfo
           successHandler:(HttpSuccessHandler)successHandler
           failureHandler:(HttpFailureHandler)failureHandler;




@end
