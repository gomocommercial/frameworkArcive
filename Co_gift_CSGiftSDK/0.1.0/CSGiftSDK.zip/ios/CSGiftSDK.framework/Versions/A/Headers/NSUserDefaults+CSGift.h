//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSUserDefaults (CSGift)

+ (void)setSdkVc:(NSInteger)value;
+ (NSInteger)getSdkVc;

/**
 * 是否已经调用过注册接口
 * @return
 */
+ (BOOL)isRegistered;
+ (void)setRegistered;

/**
 * 当前服务器时间戳，单位MillionSecond
 * @return
 */
+ (NSTimeInterval)getCurrentServerTimeStamp;
+ (void)setBaseServerTimeStamp:(NSTimeInterval)value;


/**
 * 刮刮卡缓存数据的日期，时间戳
 * @return
 */
+ (NSInteger)getScratchRecordDate;
+ (void)setScratchRecordDate:(NSInteger)value;

/**
 * 老虎机缓存数据的日期，时间戳
 * @return
 */
+ (NSInteger)getSlotRecordDate;
+ (void)setSlotRecordDate:(NSInteger)value;

/**
 * 老虎机弹窗当天展示次数
 * @return
 */
+ (NSInteger)getSlotWinDisplayCountToday;
+ (void)setSlotWinDisplayCountToday:(NSInteger)value;
+ (void)addSlotWinDisplayCountToday;
+ (void)resetSlotWinDisplayCountToday;

/**
 * 老虎机弹窗总展示次数
 * @return
 */
+ (NSInteger)getSlotWinDisplayTotalCount;
+ (void)addSlotWinDisplayTotalCount;

@end
