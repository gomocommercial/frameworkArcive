//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSUserDefaults (CSGift)

+ (void)setSdkVc:(NSInteger)value;
+ (NSInteger)getSdkVc;

/**
 * 当前服务器时间戳，单位MillionSecond
 * @return
 */
+ (NSInteger)getServerTimeStamp;
+ (void)setServerTimeStamp:(NSInteger)value;

/**
 * 刮刮卡缓存数据的日期，时间戳
 * @return
 */
+ (NSInteger)getScratchRecordDate;
+ (void)setScratchRecordDate:(NSInteger)value;

/**
 * 是否已经调用过注册接口
 * @return
 */
+ (BOOL)isRegistered;
+ (void)setRegistered;

/**
 * 老虎机弹窗总展示次数
 * @return
 */
+ (NSInteger)getSlotWinDisplayTotalCount;
+ (void)addSlotWinDisplayTotalCount;

@end
