//
//  CSGiftToast.h
//  AFNetworking
//
//  Created by Zy on 2019/4/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftToast : UIView


@property (nonatomic, assign) uint duration;

/**
展示中金币提示
 */
+ (void)giftshowGoldToast:(NSInteger)num  on:(UIView * _Nullable)view;


/**
 展示中现金提示
 */
+ (void)giftshowMoneyToast:(NSInteger)money on:(UIView * _Nullable)view;


/**
 展示信息
 */
+ (void)giftshowMessage:(NSString *)message  on:(UIView * _Nullable)view;


/**
 隐藏
 */
+ (void)cSGiftHide;

@end

NS_ASSUME_NONNULL_END
