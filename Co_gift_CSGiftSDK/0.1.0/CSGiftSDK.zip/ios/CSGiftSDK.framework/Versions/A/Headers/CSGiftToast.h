//
//  CSGiftToast.h
//  AFNetworking
//
//  Created by Zy on 2019/4/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftToast : UIView


/**
展示中金币提示
 */
+ (void)showGoldToast:(NSInteger)num;


/**
 展示中现金提示
 */
+ (void)showMoneyToast:(NSInteger)money;


/**
 展示信息
 */
+ (void)showMessage:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
