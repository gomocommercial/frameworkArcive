//
//  CSGExitView.h
//  AFNetworking
//
//  Created by Zy on 2019/4/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGExitView : UIView

//退出弹框
+ (void)show:(void(^ _Nonnull)(BOOL isExit))exitAction;
//奖励退出弹框
+ (void)RewardShow:(void(^ _Nonnull)(BOOL isExit))exitAction;

+ (void)hide;

@end

NS_ASSUME_NONNULL_END
