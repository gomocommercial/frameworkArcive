//
//  CSGExitView.h
//  AFNetworking
//
//  Created by Zy on 2019/4/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGExitView : UIView

+ (void)show:(void(^ _Nonnull)(BOOL isExit))exitAction;

+ (void)hide;

@end

NS_ASSUME_NONNULL_END
