//
//  TopScratcherView.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/18.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CSGiftLotteryActivity;

@interface TopScratcherInnerView : UIView

@property (nonatomic,strong) CSGiftLotteryActivity *lotteryActivity;

@end

NS_ASSUME_NONNULL_END
