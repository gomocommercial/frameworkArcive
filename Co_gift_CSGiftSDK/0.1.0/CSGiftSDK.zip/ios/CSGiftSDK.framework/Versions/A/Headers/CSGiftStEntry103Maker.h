//
// Created by matt on 2019-04-04.
//

#import <Foundation/Foundation.h>
#import <CSStatistics/CSStatistics/NcsStEntry103Maker.h>


@interface CSGiftStEntry103Maker : NcsStEntry103Maker
@end
