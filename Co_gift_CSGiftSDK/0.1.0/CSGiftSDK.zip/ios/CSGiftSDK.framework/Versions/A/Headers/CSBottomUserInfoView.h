//
//  CSBottomUserInfoView.h
//  CSGiftSDK
//
//  Created by wlighting on 2019/3/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSBottomUserInfoView : UIView
/**
 展示现金兑换兑换
 */
@property (nonatomic,copy) void(^showCashBlock)(void);

/**
 展示积分兑换
 */
@property (nonatomic,copy) void(^showTokenhBlock)(void);

@end

NS_ASSUME_NONNULL_END
