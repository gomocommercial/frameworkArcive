//
// Created by matt on 2019-03-18.
//

#import <Foundation/Foundation.h>


#define CSGiftLog(fmt, ...) {\
if ([CSGiftConfig sharedInstance].enableLog) {\
    NSLog((@"[礼品卡sdk]%s," "[lineNum:%d]" fmt) , __FUNCTION__, __LINE__, ##__VA_ARGS__);\
} else {}\
}

@interface CSGiftConstants : NSObject
@end
