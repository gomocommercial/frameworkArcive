//
// Created by matt on 2019-03-18.
//

#import <Foundation/Foundation.h>
#import "CSGiftConfig.h"

#define CSGiftLog(fmt, ...) {\
if ([CSGiftConfig sharedInstance].enableLog) {\
    NSLog((@"[礼品卡sdk]%s," "[lineNum:%d]" fmt) , __FUNCTION__, __LINE__, ##__VA_ARGS__);\
} else {}\
}

//时间定义---begin
#define CSGiftAMinute (60)
#define CSGiftAHour (60 * 60)
#define CSGiftADay (24 * 60 * 60)
//时间定义---end

//事件通知----begin
#define CSGiftEvent_ClearLotteryResult (@"csgift-clear-lottery-result")
#define CSGiftEventKey_NewResult (@"csgift-key-new-result")
#define CSGiftEvent_ScratchCardStateChanged (@"csgift-scratchCard-state-changed")
#define CSGiftEvent_SlotCountTodayChanged (@"csgift-slotCount-today-changed")
//事件通知----end

//UserDefaults-key定义----begin

//UserDefaults-key定义----end


//业务常量定义---begin
//刮卡时间间隔，20分钟
#define CSGiftScratchInterval (20*CSGiftAMinute)
//业务常量定义---end


@interface CSGiftConstants : NSObject
@end
