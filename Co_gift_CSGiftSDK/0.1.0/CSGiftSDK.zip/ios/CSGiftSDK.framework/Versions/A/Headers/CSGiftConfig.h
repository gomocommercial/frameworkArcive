//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CSGiftConfig : NSObject

+ (instancetype)sharedInstance;

/**
 * sdk是否已初始化
 */
@property (assign, nonatomic) BOOL inited;

/**
 * 设置是否输出日志。默认NO，不输出。
 */
@property (assign, nonatomic) BOOL enableLog;

/**
 * 设置测试服。YES则测服，NO则正式服（默认）。
 */
@property (assign, nonatomic) BOOL testServer;

/**
 * 客户端版本号
 */
@property (assign, nonatomic) NSInteger appVersionCode;

@property (assign, nonatomic, readonly) NSInteger sdkVersionCode;

@property (strong, nonatomic, readonly) NSString *sdkVersionName;

/**
 * 是否sdk升级用户
 */
@property (assign, nonatomic) BOOL isSdkUpgrade;

/**
 * 上个版本的sdk版本号，仅当isSdkUpgrade为YES时有意义。否则为0
 */
@property (assign, nonatomic, readonly) NSInteger lastSdkVersionCode;

/**
 * 应用appId
 */
@property (strong, nonatomic) NSString *appId;

/**
 * 应用发布渠道
 */
@property (strong, nonatomic) NSString *channel;

/**
 * 服务器url
 */
@property(strong, nonatomic) NSString *serverBaseUrl;

/**
 * 服务器appKey
 */
@property(strong, nonatomic) NSString *serverAppKey;

/**
 * 服务器appSecret
 */
@property(strong, nonatomic) NSString *serverAppSecret;

/**
 * 用户id，从统计sdk拿
 */
@property(strong, nonatomic, readonly) NSString *UUID;

/**
 * 用户买量渠道
 */
@property (copy, nonatomic) NSString * userBuyChannel;


/**
 * 用户买量类型
 */
@property (copy, nonatomic) NSString * userFrom;

/**
 * 产品id, 用于广告和ab
 */
@property (assign, nonatomic) NSInteger cid;

/**
 * 统计协议产品id(用于104-534 统计对象)
 */
@property (assign, nonatomic) NSInteger statisticCid;

/**
 * SDK安装天数
 */
@property (assign, nonatomic) NSInteger cDays;

-(void)checkIfValid;
@end
