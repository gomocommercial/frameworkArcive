//
//  ScratcherRewardVC.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/19.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CSGiftScratchCard;

@interface ScratcherRewardVC : UIViewController

@property (nonatomic,strong) CSGiftScratchCard *cSGiftScratchCard;

@property (nonatomic,copy) void(^continueBlock)(void);

@end

NS_ASSUME_NONNULL_END
