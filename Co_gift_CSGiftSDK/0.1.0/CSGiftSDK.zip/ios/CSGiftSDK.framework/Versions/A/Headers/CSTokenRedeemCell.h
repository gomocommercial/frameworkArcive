//
//  CSTokenRedeemCell.h
//  CSGiftSDK
//
//  Created by wlighting on 2019/3/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CSGiftGood;

@interface CSTokenRedeemCell : UICollectionViewCell

@property (nonatomic,strong) CSGiftGood *csGiftGood;

@end

NS_ASSUME_NONNULL_END
