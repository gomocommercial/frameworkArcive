//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (CSGiftSdk)

+(NSDictionary *)dictionaryFromObject:(id)obj;

- (NSInteger)intValueForKey:(NSString *)key;

@end
