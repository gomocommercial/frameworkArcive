//
//  PCCSGiftSlotPreload.h
//  AFNetworking
//
//  Created by Zy on 2019/5/5.
//

#import <UIKit/UIKit.h>
#import "PCCSGiftApi.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCCSGiftSlotPreload : NSObject

//是否自动加载(会在SDK关闭时自动加载)
+ (void)pCsetAutomaticProload:(BOOL)isAutomatic;

//设置预加载失败时的执行方案（可在此根据情况重新执行预加载）
+ (void)pCsetFailtureHandler:(PCCSGiftPreloadHandler)preloadHandler;

//预加载老虎机数据
+ (void)pCpreloadSlotInfo;

//是否完成加载
+ (BOOL)pCisLoaded;

/// 跳转老虎机
/// @param navigationVC  当前导航控制器
/// @param presentViewController
/// @param sceneId
/// @param serviceAreaType sdk接入类型，用于区分国内和国外
/// @param callback 页面展示回调
/// @param slotResultCallback 兑换结果回调
+ (void)pClaunchSlot:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController scene:(NSInteger)sceneId ServiceAreaType:(PCCSGiftServiceAreaType)serviceAreaType resultBlock:(void (^)(PCCSGiftSlotMachineVCShowResult slotMachineVCShowStyle))callback slotMachineResultBlock:(nonnull void (^)(PCCSGiftSlotMachineLotteryResult))slotResultCallback;

@end

NS_ASSUME_NONNULL_END
