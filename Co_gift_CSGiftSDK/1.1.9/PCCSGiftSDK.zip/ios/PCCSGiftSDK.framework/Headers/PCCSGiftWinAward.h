//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PCCSGiftLotteryAward.h"

/**
 * 抽奖活动de中奖奖品信息
 */
@interface PCCSGiftWinAward : NSObject

/**
 * 奖品id
 */
@property (assign, nonatomic) NSInteger awardId;

/**
 * 活动id
 */
@property (assign, nonatomic) NSInteger lottery_id;

/**
 * 针对积分卡余额，积分卡余额是一个区间，每次抽奖才确定
 */
@property (strong, nonatomic) NSString *content;

/**
 * 奖品类型
0: 默认
1：礼品卡
2：金币
3：道具
4：现金
5：积分
 */
@property (assign, nonatomic) PCCSGiftAwardType type;

/**
 * 用户注册的地区，用于现金
如果是现金，针对不同地区显示不同的货币图案
 */
@property (assign, nonatomic) NSString *country;

/**
 * 数据是否有效
 */
@property (assign, nonatomic, readonly) BOOL isValid;

/**
 * 修复数据
 */
-(void)pCfixData;

//将服务器返回的中奖content 转化为中奖结果的数组 (即显示的第几章图片)
+(NSArray *)getLotteryResultWithWinAward:(PCCSGiftWinAward *)awardResult;
@end
