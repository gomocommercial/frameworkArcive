//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "CPCSGiftLotteryAward.h"

@class CPCSGiftWinAward;

/**
 * 抽奖结果
 */
@interface CPCSGiftLotteryResult : NSObject

/**
 * 抽奖结算id
 */
@property (assign, nonatomic) NSInteger play_id;

/**
 * 抽奖中奖奖品，一般只取第1个
 */
@property(strong, nonatomic) NSArray<CPCSGiftWinAward *> *awards;

/**
 * 数据是否有效
 */
@property (assign, nonatomic, readonly) BOOL isValid;

/**
 * 修复数据
 */
-(void)cPfixData;

-(CPCSGiftWinAward *)cPgetWinAward:(NSInteger)lotterId;

@end