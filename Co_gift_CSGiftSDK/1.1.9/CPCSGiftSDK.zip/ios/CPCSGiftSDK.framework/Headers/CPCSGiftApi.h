//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CPCSGiftSlotSceneInfo;
@class CPCSGiftUserInfo;
@class CPCSGiftWinAward;
@class CPCSGiftCurrencyRateModel;
@class CPCSGiftConsumeModel;
@class CPCSGiftGood;
@class CPCSGiftGoodRedeemInfo;

typedef void (^CPCSGiftPreloadHandler)(NSError *error);
typedef void (^CPCSGiftSlotSceneHandler)(CPCSGiftSlotSceneInfo *, NSError *error);
typedef void (^CPCSGiftUserInfoHandler)(CPCSGiftUserInfo *, NSError *error);
typedef void (^CPCSGiftCurrencyRateHandler)(CPCSGiftCurrencyRateModel *currencyRate, NSError *error);
typedef void (^CPCSGiftCustomSucceessHandler)(CPCSGiftWinAward *winAward);
typedef void (^CPCSSequencesSucceessHandler)(NSArray <CPCSGiftWinAward *> *winAwards);

typedef void (^CPCSGiftConsumeSucceessHandler)(NSString *orderId);
typedef void (^CPCSGiftGoodExchangeHandler)(NSString *cash ,NSInteger point);
typedef void (^CPCSGiftGoodsHandler)(NSArray<CPCSGiftGood*> *giftGoods);
typedef void (^CPCSGiftAuthResultHandler)(NSString *authCode,NSError *error);
/**
 sdk接入类型，用于区分国内和国外
 */
typedef NS_ENUM(NSInteger,CPCSGiftServiceAreaType) {
    CPCSGiftOtherServiceArea      =     0,            //其他区域
    CPCSGiftChinaServiceArea      =     1,            //中国国内
};

typedef NS_ENUM(NSInteger, CPCSGiftSlotMachineVCShowResult) {
    //配置信息全部拿到 可以展示
    CPCSGiftSlotMachineShowSuccess = 0,
    //CPCSGiftUserInfo 数据不存在
    CPCSGiftSlotMachineInfoError = 1,
    //获取老虎机样式问题
    CPCSGiftSlotMachineStyleError = 2,
    //广告未准备就绪
    CPCSGiftAdNoValid = 3,
    //老虎机超出展示次数
    CPCSGiftSlotMachineDissatisfyDisplayCount = 4,
};

//老虎机奖励结算状态
typedef NS_ENUM(NSInteger,CPCSGiftSlotMachineLotteryResult){
    CPCSGiftSlotMachine_Result_Common    = 10000, //正常
    CPCSGiftSlotMachine_Result_Repeat    = 10010, //重复兑奖
    CPCSGiftSlotMachine_Result_OverNumer = 10014, //用户活动抽奖次数超过
};

//礼品卡SDK 退出通知
FOUNDATION_EXPORT NSString * const CPCSGiftExitNotificationName;

/**
 * sdk接口类
 */
@interface CPCSGiftApi : NSObject


/**
 初始化SDK
 */
+(void)cPsetup;

/**
 在APPDelegate 执行applicationDidBecomeActive 时调用
 */
+(void)applicationDidBecomeActive;


/**
 在APPDelegate 执行applicationDidEnterBackground 时调用
 */
+(void)applicationDidEnterBackground;

/**
在APPDelegate 执行application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation 时调用
*/
+ (void)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

/**
在APPDelegate 执行application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options 时调用
 // NOTE: 9.0以后使用新API接口
*/
+ (void)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options;


/// 请求支付宝授权权限(暂时移除)
//+(void)cPrequstAlipayAuthresult:(CPCSGiftAuthResultHandler)result;

/**
 根据场景加载数据（若回调成功 请立即执行cPshowSlotMachineWithNavigationVC:勿缓存数据）

 @param sceneId 场景ID
 @param slotSceneHandler 数据回调
 */
+(void)cPgetSlotScene:(NSInteger)sceneId
        slotSceneHandler:(CPCSGiftSlotSceneHandler)slotSceneHandler;

/**
 * 展示老虎机
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param presentViewController 当前的控制器
 * @param info 老虎机数据
 * @param callback 结果回调
 * @param slotResultCallback 奖励状态回调
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)cPlaunchSlot:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController sceneInfo:(CPCSGiftSlotSceneInfo *)info ServiceAreaType:(CPCSGiftServiceAreaType)serviceAreaType resultBlock:(void (^)(CPCSGiftSlotMachineVCShowResult slotMachineVCShowStyle))callback slotMachineResultBlock:(void (^)(CPCSGiftSlotMachineLotteryResult))slotResultCallback;

/**
 展示详情页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
   @param serviceAreaType sdk接入类型，国内还是国外
 */
+ (void)cPlaunchLotteryDetails:(UINavigationController *)navigationVC ServiceAreaType:(CPCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;

/**
 push展示购物卡兑换页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)cPpushCashOut:(UINavigationController *)navigationVC serviceAreaType:(CPCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 push展示积分页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)cPpushTokenRedeem:(UINavigationController *)navigationVC ServiceAreaType:(CPCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;

/**
 modal展示购物卡兑换页
 * @param currentVC 当前控制器
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)cPpresentCashOut:(UIViewController *)currentVC serviceAreaType:(CPCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 modal展示积分兑换页
 * @param currentVC 当前控制器
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)cPpresentTokenRedeem:(UIViewController *)currentVC ServiceAreaType:(CPCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 获取用户数据
 */
+(void)cPgetUserInfo:(CPCSGiftUserInfoHandler)userInfoHandler;

/**
 获取汇率
 */
+(void)cPgetCurrencyRate:(CPCSGiftCurrencyRateHandler)currencyRateHandler;

/**
 自定义事件
 error code 10001：活动过期 10002：禁止抽奖，spin不够或者无免费抽奖 10003：中奖 10004：不中奖
 10006：没有同步用户数据 10012：用户礼品卡宝箱抽奖次数超过 10014：用户活动抽奖次数超过
 */
+ (void)cPhandleCustomEventWithSequence:(NSInteger)sequence successHandler:(CPCSGiftCustomSucceessHandler)successHandler failureHandler:(CPCSGiftPreloadHandler)failureHandler;


/// 多活动自定义事件
/// @param sequences 活动sequence字符串数组
/// @param successHandler 成功回调
/// @param failureHandler error code 10001：活动过期 10002：禁止抽奖，spin不够或者无免费抽奖 10003：中奖 10004：不中奖 10006：没有同步用户数据 10012：用户礼品卡宝箱抽奖次数超过 10014：用户活动抽奖次数超过
+ (void)cPhandleCustomEventWithSequences:(NSArray <NSString*>*)sequences successHandler:(CPCSSequencesSucceessHandler)successHandler failureHandler:(CPCSGiftPreloadHandler)failureHandler;


/// 消费接口
/// @param model CPCSGiftConsumeModel
/// @param successHandler 成功
/// @param failureHandler 失败
+ (void)cPhandleConsume:(CPCSGiftConsumeModel *)model successHandler:(CPCSGiftConsumeSucceessHandler)successHandler failureHandler:(CPCSGiftPreloadHandler)failureHandler;


/// 获取商品列表接口
/// @param isLimitGroup 是否指定商品组
/// @param group 指定商品组号
/// @param isLimitSequence 是否指定组内序号
/// @param sequence 指定组内序号
/// @param successHandler 返回商品列表成功的回调
/// @param failureHandler 失败的回调
+ (void)cPgetGiftGoodsIsLimitGroup:(BOOL)isLimitGroup
                                   group:(NSInteger)group
                         isLimitSequence:(BOOL)isLimitSequence
                                sequence:(NSInteger)sequence
                          successHandler:(CPCSGiftGoodsHandler)successHandler
                          failureHandler:(CPCSGiftPreloadHandler)failureHandler;


/// 商品兑换接口
/// @param model  兑换模型 CPCSGiftGoodRedeemInfo
/// @param successHandler 兑换成功 10000：正常 返回剩余现金和积分
/// @param failureHandler 兑换失败 错误码 10007：现金不够 10011：积分不够 10013：库存不够
+ (void)cPhandleGoodExchange:(CPCSGiftGoodRedeemInfo *)model successHandler:(CPCSGiftGoodExchangeHandler)successHandler failureHandler:(CPCSGiftPreloadHandler)failureHandler;


// MARK: - 当SDK外部使用ap/谷歌激励视频时 需在适当的时候调用以下API
/**
 开始展示广告
 */
+ (void)cPexternalOnAdShowed;
/**
 点击广告
 */
+ (void)cPexternalOnAdClicked;
/**
 关闭广告
 */
+ (void)cPexternalOnAdClosed;
/**
 激励视频计费代理
 */
+ (void)cPexternalOnAdVideoCompletePlaying;

@end
