//
//  CPCSGiftSlotPreload.h
//  AFNetworking
//
//  Created by Zy on 2019/5/5.
//

#import <UIKit/UIKit.h>
#import "CPCSGiftApi.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPCSGiftSlotPreload : NSObject

//是否自动加载(会在SDK关闭时自动加载)
+ (void)cPsetAutomaticProload:(BOOL)isAutomatic;

//设置预加载失败时的执行方案（可在此根据情况重新执行预加载）
+ (void)cPsetFailtureHandler:(CPCSGiftPreloadHandler)preloadHandler;

//预加载老虎机数据
+ (void)cPpreloadSlotInfo;

//是否完成加载
+ (BOOL)cPisLoaded;

/// 跳转老虎机
/// @param navigationVC  当前导航控制器
/// @param presentViewController
/// @param sceneId
/// @param serviceAreaType sdk接入类型，用于区分国内和国外
/// @param callback 页面展示回调
/// @param slotResultCallback 兑换结果回调
+ (void)cPlaunchSlot:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController scene:(NSInteger)sceneId ServiceAreaType:(CPCSGiftServiceAreaType)serviceAreaType resultBlock:(void (^)(CPCSGiftSlotMachineVCShowResult slotMachineVCShowStyle))callback slotMachineResultBlock:(nonnull void (^)(CPCSGiftSlotMachineLotteryResult))slotResultCallback;

@end

NS_ASSUME_NONNULL_END
