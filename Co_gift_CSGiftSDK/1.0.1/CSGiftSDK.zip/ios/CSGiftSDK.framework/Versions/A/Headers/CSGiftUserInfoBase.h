//
// Created by matt on 2019-03-26.
//

#import <Foundation/Foundation.h>


@interface CSGiftUserInfoBase : NSObject
@end
