//
//  DetailListHeaderView.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/20.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailListHeaderView : UIView

@property (nonatomic,copy) NSArray *giftList;

@end

NS_ASSUME_NONNULL_END
