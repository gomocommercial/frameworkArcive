//
// Created by matt on 2019-03-20.
//

#import <Foundation/Foundation.h>

@class RACSignal;

/**
 * ac请求控制器
 */
@interface CSGiftAcHandler : NSObject

+ (instancetype)sharedInstance;

/**
 * 获取 CSGiftAcCtrlInfo
 * @return RACSignal
 */
-(RACSignal *)getAcCtrlInfo;

@end
