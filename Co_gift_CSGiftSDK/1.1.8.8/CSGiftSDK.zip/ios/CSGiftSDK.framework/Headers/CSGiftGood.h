//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * 兑换方式
 */
typedef NS_ENUM(NSInteger, CSGiftRedeemWay) {
    CSGiftRedeemWay_token = 1,
    CSGiftRedeemWay_cash = 2,
};

/**
 * （用于兑换的）商品信息
 */
@interface CSGiftGood : NSObject

/**
 * 商品id
 */
@property (assign, nonatomic) NSInteger goodId;

/**
 * 类型，0：购物卡
 */
@property (assign, nonatomic) NSInteger type;

/**
 * 名称
 */
@property(strong, nonatomic) NSString *name;

/**
 * 图片
 */
@property(strong, nonatomic) NSString *image;

/**
 * 价格
 */
@property (copy, nonatomic) NSString *price;

/**
 * 积分价格
 */
@property (assign, nonatomic) NSInteger point_price;

/**
 * 描述信息
 */
@property(strong, nonatomic) NSString *descriptionString;

/**
 * 库存
 */
@property (assign, nonatomic) NSInteger stock;

/**
 * 兑换方式
 * 0：所有方式 1：积分 2：现金
 */
@property(assign, nonatomic) CSGiftRedeemWay redeemWay;

/**
 * 数据是否有效
 */
@property (assign, nonatomic, readonly) BOOL isValid;

/**
 * 是否新人专享 false: 否 true: 是
*/
@property (nonatomic,assign) BOOL newExclusive;

/**
 * 金币价格
 */
@property (assign, nonatomic) NSInteger coin_price;

/**
 * 商品组
 */
@property (assign, nonatomic) NSInteger group;

/**
 * 组内序号
 */
@property (assign, nonatomic) NSInteger sequence;

/**
 商品冷却时间
 */
@property (assign,nonatomic) NSInteger recovery_time;
/**
 兑换倒计时
*/
@property (strong, nonatomic) NSString *redeemCountDownString;
/**
 * 修复数据
 */
-(void)fixData;


//是否是最低档价格
@property (nonatomic,assign) BOOL isLowPrice;
@end
