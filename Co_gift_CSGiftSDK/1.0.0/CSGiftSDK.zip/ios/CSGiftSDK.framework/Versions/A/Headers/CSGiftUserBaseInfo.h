//
// Created by matt on 2019-03-26.
//

#import <Foundation/Foundation.h>

/**
 * 用户基础信息
 */
@interface CSGiftUserBaseInfo : NSObject

/**
 * 昵称
 */
@property(strong, nonatomic) NSString *nick_name;

/**
 * 邮箱
 */
@property(strong, nonatomic) NSString *email;

/**
 * 性别
 * 0：未知
1：男
2：女
 */
@property (assign, nonatomic) NSInteger gender;

/**
 * 地区
 */
@property(strong, nonatomic) NSString *country;

/**
 * 头像
 */
@property(strong, nonatomic) NSString *avatar;

-(void)copyOther:(CSGiftUserBaseInfo *)other;

@end
