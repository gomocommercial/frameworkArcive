//
//  CSGiftAbCache.h
//  abtestcentersdk
//
//  Created by linqiaogeng on 2018/8/1.
//

#import <Foundation/Foundation.h>
#import "CSGiftAbNetworkTool.h"

#define Cid2_key @"Cid2_key_%@"
#define LastTime_key @"LastTime_key_%@"
#define AbtestId_key @"AbtestId_key_%@"
#define FilterId_key @"FilterId_key_%@"

@interface CSGiftAbCache : NSObject

+ (BOOL)getResponseFromCacheWithUrl:(NSString *)url network:(CSGiftAbNetworkTool *)network;

+ (void)setResponseToCacheWithUrl:(NSString *)url responseDic:(NSMutableDictionary *)responseDic;

+ (void)saveAliveStatus:(NSString *)sid responseDic:(NSDictionary *)responseDic;

+ (void)saveRequestSwitchStatus:(NSString *)sid responseDic:(NSDictionary *)responseDic;

+ (NSInteger)getRequestSwitchStatus:(NSString *)sid ;


+ (NSInteger)getSwitchAlive:(NSString *)sid;

+ (void)saveRetentionInfoWithCid2:(NSInteger)cid2 sid:(NSString *)sid abtestId:(NSInteger)abtestId filterId:(NSInteger)filterId hasUploaded:(BOOL)hasUploaded;
@end
