//
//  CSGiftSlotMachineContentView.h
//  AFNetworking
//
//  Created by qiaoming on 2019/3/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftSlotMachineContentView : UIView

//老虎机滚动结束的回调
@property (nonatomic, copy) void(^slotMachineScrollCompleted)(BOOL autoStop);

-(instancetype)initWithFrame:(CGRect)frame leftVTop:(CGFloat)top leftVbottom:(CGFloat)bottom SlotMachineCellHeight:(CGFloat)slotMachineCellHeight;
/*
*抽奖前 重置老虎机初始界面
*resultArr抽奖结果图片
*/
-(void)resetSlotMachineContentOffsetYWithResult:(NSArray<NSNumber *> *)resultArr;
-(void)stopClick;
-(void)beginFire;

@end

NS_ASSUME_NONNULL_END
