//
// Created by matt on 2019-03-18.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"


@interface CSGiftResponseSerializer : AFJSONResponseSerializer

@property(strong, nonatomic) id responseObject;

@end
