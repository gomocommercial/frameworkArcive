//
// Created by matt on 2019-03-20.
//

#import <Foundation/Foundation.h>

@class CSGiftScratchCard;
@class CSGiftSlotCard;

/**
 * 抽奖详情页数据
 */
@interface CSGiftLotteryDetailsData : NSObject

/**
 * 老虎机卡片信息
 */
@property(strong, nonatomic) CSGiftSlotCard *slotCard;

/**
 * 刮刮卡数据
 */
@property(strong, nonatomic) NSArray<CSGiftScratchCard *> *scratchCards;


/**
 返回排好序的详情页数据
 */
@property (nonatomic,strong) NSMutableArray *orderedMixArray;

/**
 删除不可用的刮刮卡
 @return 返回排好序的详情页数据
 */
- (NSMutableArray *)clearSpentOutScratchCards;

- (void)clearAllStateInfos;

@end
