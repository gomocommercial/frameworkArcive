//
// Created by matt on 2019-03-19.
//

#import <UIKit/UIKit.h>
#import "CSGiftApi.h"

/**
 * sdk管理器，处理核心业务逻辑
 */
@interface CSGiftSdkManager : NSObject


/**
 SDK进入时的老虎机实例
 */
@property (nonatomic, weak) CSGiftSlotMachineVC *slotMachineViewController;


+ (instancetype)sharedInstance;

-(void)setup;

-(void)getSlotScene:(NSInteger)sceneId
           slotSceneHandler:(CSGiftSlotSceneHandler)slotSceneHandler;

//-(void)launchSlot:(CSGiftSlotSceneInfo *)slotSceneInfo;

//-(void)launchLotteryDetails;

-(void)getUserInfo:(CSGiftUserInfoHandler)userInfoHandler;

-(void)closeSDK;
@end
