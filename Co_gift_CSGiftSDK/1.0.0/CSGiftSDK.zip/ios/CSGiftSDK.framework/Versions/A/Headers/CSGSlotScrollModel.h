//
//  CSGSlotScrollModel.h
//  AFNetworking
//
//  Created by Zy on 2019/4/19.
//

#import <Foundation/Foundation.h>

@interface CSGSlotScrollModel : NSObject

//可滑动秒数
@property (nonatomic, assign, readonly) float totalSeconds;
//已滑动的时间
@property (nonatomic, assign) float scrollSeconds;
//滚动速度
@property (nonatomic, assign) float speed;
//每秒帧数
@property (nonatomic, assign, readonly) float fps;
//是否开始减速
@property (nonatomic, assign, readonly) BOOL isSlowDown;
//最后停止时的索引
@property (nonatomic, strong) NSIndexPath * lastIndex;

//最后的Y坐标
@property (nonatomic, assign) float lastY;

- (instancetype)initWithTotalSecond:(float)second startSpeed:(float)speed maxSpeed:(float)maxSpeed minSpeed:(float)minSpeed fps:(float)fps;

@property (nonatomic, copy) void(^lastScroll)(void);

//开始减速
- (void)startSlowDown;

//滑动记录-》每次滑动使用此方法记录 对速度进行修改
- (void)recordScroll;

@end
