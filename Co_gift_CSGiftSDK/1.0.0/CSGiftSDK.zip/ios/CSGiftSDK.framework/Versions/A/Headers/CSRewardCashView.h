//
//  CSRewardCashView.h
//  AFNetworking
//
//  Created by qiaoming on 2019/3/26.
//

#import <UIKit/UIKit.h>
#import "CSGiftWinAward.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, CSRewardCashViewType) {
    //现金 无get按钮
    CSRewardCashViewType_cash_tap_continue = 0,
    //积分 无get按钮
    CSRewardCashViewType_token_tap_continue = 1,
    //现金 直接奖励弹框
    CSRewardCashViewType_cash_first = 2,
    //积分 直接奖励弹框
    CSRewardCashViewType_token_first = 3,
    //现金 ok按钮
    CSRewardCashViewType_cash_ok = 5,
    //积分 ok按钮
    CSRewardCashViewType_token_ok = 6,
    CSRewardCashViewTypeNone = 7,//无奖励样式
};

@interface CSRewardCashView : UIView

@property (strong, nonatomic) UIImageView *animationImageView;
@property (nonatomic, copy) void(^rewardCashViewCloseBtnClick)(CSGiftWinAward *awardResult, CSRewardCashViewType type);
@property (nonatomic, copy) void(^rewardCashViewGetBtnClick)(CSGiftWinAward *awardResult, CSRewardCashViewType type);

-(instancetype)initWithFrame:(CGRect)frame type:(CSRewardCashViewType)cashViewType awardResult:(CSGiftWinAward *)awardResult;
-(void)showInView:(UIView *)view;
@end

NS_ASSUME_NONNULL_END
