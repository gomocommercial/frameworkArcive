//
//  CSGiftStatisticsManager.h
//  CSGiftSDK
//
//  Created by qiaoming on 2019/4/3.
//

#import <Foundation/Foundation.h>
#import "CSGiftSlotSceneCtrlInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftStatisticsManager : NSObject

+ (void)uploadStatisticsStatisticsObject:(NSString *)statisticsObject operationCode:(NSString *)operationCode tab:(NSString *)tab position:(NSString *)position associationObject:(NSString *)associationObject;


+ (void)uploadStatisticsOperationCode:(NSString *)operationCode;

+ (void)uploadStatisticsOperationCode:(NSString *)operationCode tab:(NSString *)tab;

+ (void)uploadStatisticsOperationCode:(NSString *)operationCode tab:(NSString *)tab associationObject:(NSString *)associationObject;

+ (void)uploadStatisticsOperationCode:(NSString *)operationCode tab:(NSString *)tab position:(NSString *)position;

+ (void)uploadStatisticsOperationCode:(NSString *)operationCode position:(NSString *)position;

/**
发起广告流程

 @param associationObject 虚拟模块ID
 */
+ (void)adRequest:(NSString *)associationObject;


/**
 广告请求

 @param associationObject 虚拟模块ID
 */
+ (void)adLoad:(NSString *)associationObject;


/**
 广告缓存成功

 @param statisticsObject 类名
 @param tab 1、缓存已经存在；2、请求返回成功
 @param associationObject 虚拟模块ID
 */
+ (void)adRequestSus:(NSString *)statisticsObject tab:(NSString *)tab associationObject:(NSString *)associationObject;

// MARK: - 老虎机
/**
 弹窗>>弹窗展示 done

 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 
 1、不支持无奖励样式；
 2、统计对象区分到四种AB样式，下文均用【同上】表示。
 */
+ (void)popupShow:(NSString *)statisticsObject;

/**
 弹窗>>弹窗点击 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 
 不支持无奖励样式
 */
+ (void)popupClick:(NSString *)statisticsObject;

/**
 弹窗>>弹窗关闭 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 @param position 1、Leave；2、Stay
 
 1、不支持无奖励样式；
 2、【位置】统计仅支持直接奖励样式、自动转动样式。
 */
+ (void)popupClose:(NSString *)statisticsObject position:(NSString *)position;


/**
 home键点击 done

 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 @param tab 1、弹窗；2、老虎机弹窗
 */
+ (void)homeClick:(NSString *)statisticsObject tab:(NSString *)tab;

/**
 Toast展示 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 @param tab 第n次，为当天累计次数
 
 每次场景出来第一个toast位置打第0次
 */
+ (void)popupToast:(NSString *)statisticsObject tab:(NSString *)tab;

/**
 老虎机展示 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 */
+ (void)slotShow:(NSString *)statisticsObject;

/**
 老虎机关闭 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 @param position 1、返回到默认界面 2、返回到详情页
 */
+ (void)slotClose:(NSString *)statisticsObject position:(NSString *)position;

/**
老虎机按钮点击 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
@param position  1、弹窗；2、详情页(详情页不上传统计对象)
 */
+ (void)slotClick:(NSString *)statisticsObject position:(NSString *)position;

/**
 老虎机完成 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 @param tab 第n次，为当天累计次数
 @param position  1、弹窗；2、详情页(详情页不上传统计对象，每次场景出来第一个toast位置打第0次)
 @param associationObject  第n次，为历史累计次数
 
 详情页不上传统计对象，每次场景出来第一个toast位置打第0次
 */
+ (void)slotFinish:(NSString *)statisticsObject tab:(NSString *)tab position:(NSString *)position associationObject:(NSString *)associationObject;

/**
奖励弹窗展示 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 
 支持旧样式、自动转动样式
 */
+ (void)popupRewardShow:(NSString *)statisticsObject;

/**
奖励弹窗点击 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 
 仅支持自动转动样式
 */
+ (void)popupRewardClick:(NSString *)statisticsObject;

/**
 弹窗>>跳转详情页 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）

 */
+ (void)popupPushInfo:(NSString *)statisticsObject;


/**
 弹窗>>弹窗广告展示成功 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 @param associationObject  虚拟模块ID

 */
+ (void)popupAdShow:(NSString *)statisticsObject associationObject:(NSString *)associationObject;

/**
 弹窗>>弹窗广告展示失败 done
 
 @param statisticsObject 1、默认样式；
 2、直接奖励样式；
 3、自动转动样式；
 4、无奖励样式；
 5、【安卓】直接奖励（无老虎机样式）
 
 广告没缓存的时候打
 */
+ (void)popupAdFail:(NSString *)statisticsObject;


/**
 重试按钮点击 done
 */
+ (void)retryClick;

@end

NS_ASSUME_NONNULL_END
