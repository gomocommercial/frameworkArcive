//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "CSGiftApi.h"

@class RACSignal;
@class CSGiftLotteryActivity;
@class CSGiftLotteryResult;
@class CSGiftSlotSceneCtrlInfo;

/**
 * 老虎机数据仓库
 *
 */
@interface CSGSlotMachineRepository : NSObject

/**
 * 当天展示次数
 */
@property (assign, nonatomic, readonly) NSInteger displayCountToday;

/**
 * 累计展示次数
 */
@property (assign, nonatomic, readonly) NSInteger displayCountTotal;

/**
 * 当天最大展示次数
 */
@property (assign, nonatomic) NSInteger maxDisplayCountToday;

/**
 * 是否优先展示全屏广告
 */
@property (assign, nonatomic) BOOL isShowInterstitialAdFirst;

+ (instancetype)sharedInstance;

/**
 * 获取场景信息 CSGiftSlotSceneInfo. 含控制信息和当前中奖结果
 * 弹窗界面不应缓存场景信息（主要是中奖信息不能缓存）
 * @param sceneId
 * return CSGiftSlotSceneInfo
 */
-(RACSignal *)getSlotScene:(NSInteger)sceneId;

/**
 * 是否可以展示弹窗
 * @param sceneInfo
 * @return
 */
-(BOOL)isAvailableDisplaySlotWin:(CSGiftSlotSceneInfo *)sceneInfo;

/**
 * 获取中奖结果，用于 老虎机弹窗下一次抽奖、 详情页老虎机抽奖。
 * @return CSGiftLotteryResultWrap
 */
-(RACSignal *)getLotteryResult:(CSGiftLotteryActivity *)slotActivity;

/**
 * 老虎机抽奖结算
 * @return CSGiftHttpResponse
 */
-(RACSignal *)storeLottery:(CSGiftLotteryResult *)lotteryResult;

/**
 * 检查并处理过期数据
 * @return
 */
-(BOOL)checkSlotWinDisplayCountIfOutOfDate;

@end
