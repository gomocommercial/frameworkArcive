//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>

/**
 * 商品兑换请求信息
 */
@interface CSGiftGoodRedeemInfo : NSObject

/**
 * 商品id
 */
@property (assign, nonatomic) NSInteger goods_id;

/**
 * 备注，选填
 */
@property(strong, nonatomic) NSString *remark;

/**
 * 消费方式
1：现金消费
2：积分消费
 */
@property (assign, nonatomic) NSInteger cost_type;

@property(strong, nonatomic) NSString *nick_name;

@property(strong, nonatomic) NSString *email;

@property (assign, nonatomic) NSInteger gender;

@property(strong, nonatomic) NSString *country;

@end
