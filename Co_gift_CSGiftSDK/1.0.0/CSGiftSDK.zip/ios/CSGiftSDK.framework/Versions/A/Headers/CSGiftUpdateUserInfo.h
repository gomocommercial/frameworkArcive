//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "CSGiftUserBaseInfo.h"


@interface CSGiftUpdateUserInfo : CSGiftUserBaseInfo



@end
