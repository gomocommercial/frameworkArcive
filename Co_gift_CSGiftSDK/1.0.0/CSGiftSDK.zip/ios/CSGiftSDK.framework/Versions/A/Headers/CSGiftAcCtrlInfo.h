//
// Created by matt on 2019-03-20.
//

#import <Foundation/Foundation.h>

@class CSGiftSlotSceneCtrlInfo;

/**
 * Ac控制信息
 */
@interface CSGiftAcCtrlInfo : NSObject

/**
 * dic[@"cfgs"][0]，ac控制信息里的第1项
 */
@property(strong, nonatomic) NSDictionary *jsonInfo;

@property (nonatomic, assign, readonly) NSInteger adFirstShowTime;

-(CSGiftSlotSceneCtrlInfo *)getSlotSceneCtrlInfo:(NSInteger)sceneId;

@end
