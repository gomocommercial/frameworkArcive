//
//  ScracherVC.h
//  GiftSDKDemo
//
//  Created by wlighting on 2019/3/15.
//  Copyright © 2019 wlighting. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CSBaseViewController.h"
NS_ASSUME_NONNULL_BEGIN

@class CSGiftScratchCard;
@interface ScratcherVC : CSBaseViewController

@property (nonatomic,strong) CSGiftScratchCard *cSGiftScratchCard;

/**
 刮完后刷新详情页数据
 */
@property (nonatomic,copy) void(^refreshCountBlock)(void);
@property (nonatomic,copy) void(^backBlock)(void);


@end

NS_ASSUME_NONNULL_END
