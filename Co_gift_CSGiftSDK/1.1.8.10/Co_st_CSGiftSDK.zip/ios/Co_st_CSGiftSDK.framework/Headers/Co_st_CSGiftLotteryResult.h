//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "Co_st_CSGiftLotteryAward.h"

@class Co_st_CSGiftWinAward;

/**
 * 抽奖结果
 */
@interface Co_st_CSGiftLotteryResult : NSObject

/**
 * 抽奖结算id
 */
@property (assign, nonatomic) NSInteger play_id;

/**
 * 抽奖中奖奖品，一般只取第1个
 */
@property(strong, nonatomic) NSArray<Co_st_CSGiftWinAward *> *awards;

/**
 * 数据是否有效
 */
@property (assign, nonatomic, readonly) BOOL isValid;

/**
 * 修复数据
 */
-(void)co_st_fixData;

-(Co_st_CSGiftWinAward *)co_st_getWinAward:(NSInteger)lotterId;

@end
