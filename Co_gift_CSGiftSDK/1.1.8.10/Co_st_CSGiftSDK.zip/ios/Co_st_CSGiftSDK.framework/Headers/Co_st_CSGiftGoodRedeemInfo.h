//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>

/**
 * 商品兑换请求信息
 */
@interface Co_st_CSGiftGoodRedeemInfo : NSObject

/**
 * 商品id    允许为空 ：否
 */
@property (assign, nonatomic) NSInteger goods_id;

/**
 * 备注，选填
 */
@property(strong, nonatomic) NSString *remark;

/**
 * 消费方式   允许为空 ：否
1：现金消费
2：积分消费
 */
@property (assign, nonatomic) NSInteger cost_type;
/**
* 用户昵称
*/
@property (strong, nonatomic) NSString *nick_name;
/**
* 用户邮箱
*/
@property (strong, nonatomic) NSString *email;
/**
* 用户性别
*/
@property (assign, nonatomic) NSInteger gender;
/**
* 用户地区
*/
@property (strong, nonatomic) NSString *country;
/**
* 支付账号
*/
@property (strong, nonatomic) NSString *pay_account;
/**
* 支付账号类型    0：paypal 1：支付宝
*/
@property (assign, nonatomic) NSInteger pay_account_type;
/**
* 兑换图片地址    允许为空 ：是 redeem_image和redeemImageArray只需传一个
*/
@property (strong, nonatomic) NSMutableArray <NSString *> *redeem_image;
/**
* 兑换图片    允许为空 ：是  redeem_image和redeemImageArray只需传一个
*/
@property (strong, nonatomic) NSMutableArray <UIImage *> *redeemImageArray;

@end
