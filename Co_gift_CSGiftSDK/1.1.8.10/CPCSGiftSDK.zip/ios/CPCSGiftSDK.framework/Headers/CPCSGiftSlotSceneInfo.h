//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CPCSGiftSlotSceneCtrlInfo.h"
#import "CPCSGiftLotteryActivity.h"
#import "CPCSGiftLotteryResult.h"

@class CPCSGiftLotteryResultWrap;

/**
 * 老虎机弹窗场景信息
 */
@interface CPCSGiftSlotSceneInfo : NSObject

/**
 * 场景id，由客户端和"ab后台运营"约定
 */
@property (assign, nonatomic) NSInteger sceneId;

/**
 * 控制信息
 */
@property(strong, nonatomic) CPCSGiftSlotSceneCtrlInfo *ctrlInfo;

/**
 * 抽奖活动信息
 */
@property(strong, nonatomic) CPCSGiftLotteryActivity *lotteryActivity;

/**
 * 抽奖结果
 */
@property (strong, nonatomic) CPCSGiftLotteryResultWrap *lotteryResultWrap;

/**
 * 是否可以展示
 */
@property (assign, nonatomic, readonly) BOOL displayAvailable;

/**
 * 获取奖品信息
 * @return nil表示没中奖
 */
-(CPCSGiftWinAward *)cPgetWinAward;

@end

