//
// Created by matt on 2019-03-14.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CSGiftConfig : NSObject

+ (instancetype)sharedInstance;

/**
 * sdk是否已初始化
 */
@property (assign, nonatomic) BOOL inited;

/**
 * 设置是否输出日志。默认NO，不输出。
 */
@property (assign, nonatomic) BOOL enableLog;

/**
 * 设置测试服。YES则测服，NO则正式服（默认）。
 */
@property (assign, nonatomic) BOOL testServer;

// MARK: - loadExternalAdmobRewardVideo 和 externalApplovinRewardVideoId 仅可使用一种，不可同时使用.对于使用其他广告源加载时无需配置。
/**
 是否在外部加载admob激励视频，需在广告加载前配置
 */
@property (nonatomic, assign) BOOL loadExternalAdmobRewardVideo;

/**
 是否加载applovin激励视频（默认为空）需在广告加载前配置
 */
@property (nonatomic, copy) NSString * externalApplovinRewardVideoId;


/**
 * 客户端版本号
 */
@property (assign, nonatomic) NSInteger appVersionCode;

@property (assign, nonatomic, readonly) NSInteger sdkVersionCode;

@property (strong, nonatomic, readonly) NSString *sdkVersionName;

/**
 * 是否sdk升级用户
 */
@property (assign, nonatomic) BOOL isSdkUpgrade;

/**
 * 上个版本的sdk版本号，仅当isSdkUpgrade为YES时有意义。否则为0
 */
@property (assign, nonatomic, readonly) NSInteger lastSdkVersionCode;

/**
 * 应用appId
 */
@property (strong, nonatomic) NSString *appId;

/**
 * 应用发布渠道
 */
@property (strong, nonatomic) NSString *channel;

/**
 * 服务器url
 */
@property(strong, nonatomic, readonly) NSString *serverBaseUrl;

@property(strong, nonatomic, readonly) NSString *uploadBaseUrl;

/**
 * 服务器appKey
 */
@property(strong, nonatomic) NSString *serverAppKey;

/**
 * 服务器appSecret
 */
@property(strong, nonatomic) NSString *serverAppSecret;
/**
 * 上传图片服务器appKey
 */
@property(strong, nonatomic) NSString *uploadAppKey;

/**
 * 上传图片服务器appSecret
 */
@property(strong, nonatomic) NSString *uploadAppSecret;
/**
 * 用户id，从统计sdk拿
 */
@property(strong, nonatomic, readonly) NSString *UUID;

/**
 * 用户买量渠道
 */
@property (copy, nonatomic) NSString * userBuyChannel;


/**
 * 用户买量类型
 */
@property (copy, nonatomic) NSString * userFrom;

/**
 * 产品id, 用于广告和ab
 */
@property (assign, nonatomic) NSInteger cid;

/**
 * 统计协议产品id(用于104-534 统计对象)
 */
@property (assign, nonatomic) NSInteger statisticCid;

/**
 * SDK安装天数
 */
@property (assign, nonatomic) NSInteger cDays;


/// 是否使用国内广告
@property (nonatomic, assign) BOOL isChinaAD;


/// AB服务AccessKey
@property (nonatomic, copy) NSString* BCAccessKey;

/// AB服务prodkey
@property (nonatomic, copy) NSString* BCProdkey;

/**
 SDK内部兑换页指定商品组号 不指定时不需设置
*/
@property (nonatomic, copy) NSString *exchangeGroup;

/**
  SDK内部兑换页指定商品组内排序号 不指定时不需设置
*/
@property (nonatomic, copy) NSString *exchangeSequence;

 /// 是否使用支付宝授权自动提现
@property (nonatomic, assign) BOOL isUseAlipayAutoRedeem;

/// 使用支付宝授权需自行指定scheme （不实用支付宝授权自动提现可忽略）
@property (nonatomic, copy) NSString *scheme;

/// 支付宝服务的对应支付宝后台产品id
@property (nonatomic, copy) NSString *alipyAppId;
/**
 检查是否配置完成
 */
-(void)checkIfValid;

/**
 获取SDK版本号

 @return String
 */
-(NSString *)getSDKVersion;
@end
