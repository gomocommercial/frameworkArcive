//
//  CSGiftSlotPreload.h
//  AFNetworking
//
//  Created by Zy on 2019/5/5.
//

#import <UIKit/UIKit.h>
#import "CSGiftApi.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSGiftSlotPreload : NSObject

//是否自动加载(会在SDK关闭时自动加载)
+ (void)setAutomaticProload:(BOOL)isAutomatic;

//设置预加载失败时的执行方案（可在此根据情况重新执行预加载）
+ (void)setFailtureHandler:(CSGiftPreloadHandler)preloadHandler;

//预加载老虎机数据
+ (void)preloadSlotInfo;

//是否完成加载
+ (BOOL)isLoaded;

//跳转老虎机
+ (void)launchSlot:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController scene:(NSInteger)sceneId resultBlock:(void (^)(CSGiftSlotMachineVCShowResult slotMachineVCShowStyle))callback;

@end

NS_ASSUME_NONNULL_END
