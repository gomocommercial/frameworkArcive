//
// Created by matt on 2019-03-19.
//

#import <Foundation/Foundation.h>
#import "PCCSGiftLotteryAward.h"

@class PCCSGiftWinAward;

/**
 * 抽奖结果
 */
@interface PCCSGiftLotteryResult : NSObject

/**
 * 抽奖结算id
 */
@property (assign, nonatomic) NSInteger play_id;

/**
 * 抽奖中奖奖品，一般只取第1个
 */
@property(strong, nonatomic) NSArray<PCCSGiftWinAward *> *awards;

/**
 * 数据是否有效
 */
@property (assign, nonatomic, readonly) BOOL isValid;

/**
 * 修复数据
 */
-(void)pCfixData;

-(PCCSGiftWinAward *)pCgetWinAward:(NSInteger)lotterId;

@end
