//
//  PTCSGiftSlotPreload.h
//  AFNetworking
//
//  Created by Zy on 2019/5/5.
//

#import <UIKit/UIKit.h>
#import "PTCSGiftApi.h"

NS_ASSUME_NONNULL_BEGIN

@interface PTCSGiftSlotPreload : NSObject

//是否自动加载(会在SDK关闭时自动加载)
+ (void)pTsetAutomaticProload:(BOOL)isAutomatic;

//设置预加载失败时的执行方案（可在此根据情况重新执行预加载）
+ (void)pTsetFailtureHandler:(PTCSGiftPreloadHandler)preloadHandler;

//预加载老虎机数据
+ (void)pTpreloadSlotInfo;

//是否完成加载
+ (BOOL)pTisLoaded;

/// 跳转老虎机
/// @param navigationVC  当前导航控制器
/// @param presentViewController
/// @param sceneId
/// @param serviceAreaType sdk接入类型，用于区分国内和国外
/// @param callback 页面展示回调
/// @param slotResultCallback 兑换结果回调
+ (void)pTlaunchSlot:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController scene:(NSInteger)sceneId ServiceAreaType:(PTCSGiftServiceAreaType)serviceAreaType resultBlock:(void (^)(PTCSGiftSlotMachineVCShowResult slotMachineVCShowStyle))callback slotMachineResultBlock:(nonnull void (^)(PTCSGiftSlotMachineLotteryResult))slotResultCallback;

@end

NS_ASSUME_NONNULL_END
