//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PTCSGiftSlotSceneInfo;
@class PTCSGiftUserInfo;
@class PTCSGiftWinAward;
@class PTCSGiftCurrencyRateModel;
@class PTCSGiftConsumeModel;
@class PTCSGiftGood;
@class PTCSGiftGoodRedeemInfo;

typedef void (^PTCSGiftPreloadHandler)(NSError *error);
typedef void (^PTCSGiftSlotSceneHandler)(PTCSGiftSlotSceneInfo *, NSError *error);
typedef void (^PTCSGiftUserInfoHandler)(PTCSGiftUserInfo *, NSError *error);
typedef void (^PTCSGiftCurrencyRateHandler)(PTCSGiftCurrencyRateModel *currencyRate, NSError *error);
typedef void (^PTCSGiftCustomSucceessHandler)(PTCSGiftWinAward *winAward);
typedef void (^PTCSSequencesSucceessHandler)(NSArray <PTCSGiftWinAward *> *winAwards);

typedef void (^PTCSGiftConsumeSucceessHandler)(NSString *orderId);
typedef void (^PTCSGiftGoodExchangeHandler)(NSString *cash ,NSInteger point);
typedef void (^PTCSGiftGoodsHandler)(NSArray<PTCSGiftGood*> *giftGoods);
typedef void (^PTCSGiftAuthResultHandler)(NSString *authCode,NSError *error);
/**
 sdk接入类型，用于区分国内和国外
 */
typedef NS_ENUM(NSInteger,PTCSGiftServiceAreaType) {
    PTCSGiftOtherServiceArea      =     0,            //其他区域
    PTCSGiftChinaServiceArea      =     1,            //中国国内
};

typedef NS_ENUM(NSInteger, PTCSGiftSlotMachineVCShowResult) {
    //配置信息全部拿到 可以展示
    PTCSGiftSlotMachineShowSuccess = 0,
    //PTCSGiftUserInfo 数据不存在
    PTCSGiftSlotMachineInfoError = 1,
    //获取老虎机样式问题
    PTCSGiftSlotMachineStyleError = 2,
    //广告未准备就绪
    PTCSGiftAdNoValid = 3,
    //老虎机超出展示次数
    PTCSGiftSlotMachineDissatisfyDisplayCount = 4,
};

//老虎机奖励结算状态
typedef NS_ENUM(NSInteger,PTCSGiftSlotMachineLotteryResult){
    PTCSGiftSlotMachine_Result_Common    = 10000, //正常
    PTCSGiftSlotMachine_Result_Repeat    = 10010, //重复兑奖
    PTCSGiftSlotMachine_Result_OverNumer = 10014, //用户活动抽奖次数超过
};

//礼品卡SDK 退出通知
FOUNDATION_EXPORT NSString * const PTCSGiftExitNotificationName;

/**
 * sdk接口类
 */
@interface PTCSGiftApi : NSObject


/**
 初始化SDK
 */
+(void)pTsetup;

/**
 在APPDelegate 执行applicationDidBecomeActive 时调用
 */
+(void)applicationDidBecomeActive;


/**
 在APPDelegate 执行applicationDidEnterBackground 时调用
 */
+(void)applicationDidEnterBackground;

/**
在APPDelegate 执行application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation 时调用
*/
+ (void)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

/**
在APPDelegate 执行application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options 时调用
 // NOTE: 9.0以后使用新API接口
*/
+ (void)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options;


/// 请求支付宝授权权限(暂时移除)
//+(void)pTrequstAlipayAuthresult:(PTCSGiftAuthResultHandler)result;

/**
 根据场景加载数据（若回调成功 请立即执行pTshowSlotMachineWithNavigationVC:勿缓存数据）

 @param sceneId 场景ID
 @param slotSceneHandler 数据回调
 */
+(void)pTgetSlotScene:(NSInteger)sceneId
        slotSceneHandler:(PTCSGiftSlotSceneHandler)slotSceneHandler;

/**
 * 展示老虎机
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param presentViewController 当前的控制器
 * @param info 老虎机数据
 * @param callback 结果回调
 * @param slotResultCallback 奖励状态回调
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)pTlaunchSlot:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController sceneInfo:(PTCSGiftSlotSceneInfo *)info ServiceAreaType:(PTCSGiftServiceAreaType)serviceAreaType resultBlock:(void (^)(PTCSGiftSlotMachineVCShowResult slotMachineVCShowStyle))callback slotMachineResultBlock:(void (^)(PTCSGiftSlotMachineLotteryResult))slotResultCallback;

/**
 展示详情页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
   @param serviceAreaType sdk接入类型，国内还是国外
 */
+ (void)pTlaunchLotteryDetails:(UINavigationController *)navigationVC ServiceAreaType:(PTCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;

/**
 push展示购物卡兑换页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)pTpushCashOut:(UINavigationController *)navigationVC serviceAreaType:(PTCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 push展示积分页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)pTpushTokenRedeem:(UINavigationController *)navigationVC ServiceAreaType:(PTCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;

/**
 modal展示购物卡兑换页
 * @param currentVC 当前控制器
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)pTpresentCashOut:(UIViewController *)currentVC serviceAreaType:(PTCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 modal展示积分兑换页
 * @param currentVC 当前控制器
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)pTpresentTokenRedeem:(UIViewController *)currentVC ServiceAreaType:(PTCSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 获取用户数据
 */
+(void)pTgetUserInfo:(PTCSGiftUserInfoHandler)userInfoHandler;

/**
 获取汇率
 */
+(void)pTgetCurrencyRate:(PTCSGiftCurrencyRateHandler)currencyRateHandler;

/**
 自定义事件
 error code 10001：活动过期 10002：禁止抽奖，spin不够或者无免费抽奖 10003：中奖 10004：不中奖
 10006：没有同步用户数据 10012：用户礼品卡宝箱抽奖次数超过 10014：用户活动抽奖次数超过
 */
+ (void)pThandleCustomEventWithSequence:(NSInteger)sequence successHandler:(PTCSGiftCustomSucceessHandler)successHandler failureHandler:(PTCSGiftPreloadHandler)failureHandler;


/// 多活动自定义事件
/// @param sequences 活动sequence字符串数组
/// @param successHandler 成功回调
/// @param failureHandler error code 10001：活动过期 10002：禁止抽奖，spin不够或者无免费抽奖 10003：中奖 10004：不中奖 10006：没有同步用户数据 10012：用户礼品卡宝箱抽奖次数超过 10014：用户活动抽奖次数超过
+ (void)pThandleCustomEventWithSequences:(NSArray <NSString*>*)sequences successHandler:(PTCSSequencesSucceessHandler)successHandler failureHandler:(PTCSGiftPreloadHandler)failureHandler;


/// 消费接口
/// @param model PTCSGiftConsumeModel
/// @param successHandler 成功
/// @param failureHandler 失败
+ (void)pThandleConsume:(PTCSGiftConsumeModel *)model successHandler:(PTCSGiftConsumeSucceessHandler)successHandler failureHandler:(PTCSGiftPreloadHandler)failureHandler;


/// 获取商品列表接口
/// @param isLimitGroup 是否指定商品组
/// @param group 指定商品组号
/// @param isLimitSequence 是否指定组内序号
/// @param sequence 指定组内序号
/// @param successHandler 返回商品列表成功的回调
/// @param failureHandler 失败的回调
+ (void)pTgetGiftGoodsIsLimitGroup:(BOOL)isLimitGroup
                                   group:(NSInteger)group
                         isLimitSequence:(BOOL)isLimitSequence
                                sequence:(NSInteger)sequence
                          successHandler:(PTCSGiftGoodsHandler)successHandler
                          failureHandler:(PTCSGiftPreloadHandler)failureHandler;


/// 商品兑换接口
/// @param model  兑换模型 PTCSGiftGoodRedeemInfo
/// @param successHandler 兑换成功 10000：正常 返回剩余现金和积分
/// @param failureHandler 兑换失败 错误码 10007：现金不够 10011：积分不够 10013：库存不够
+ (void)pThandleGoodExchange:(PTCSGiftGoodRedeemInfo *)model successHandler:(PTCSGiftGoodExchangeHandler)successHandler failureHandler:(PTCSGiftPreloadHandler)failureHandler;


// MARK: - 当SDK外部使用ap/谷歌激励视频时 需在适当的时候调用以下API
/**
 开始展示广告
 */
+ (void)pTexternalOnAdShowed;
/**
 点击广告
 */
+ (void)pTexternalOnAdClicked;
/**
 关闭广告
 */
+ (void)pTexternalOnAdClosed;
/**
 激励视频计费代理
 */
+ (void)pTexternalOnAdVideoCompletePlaying;

@end
