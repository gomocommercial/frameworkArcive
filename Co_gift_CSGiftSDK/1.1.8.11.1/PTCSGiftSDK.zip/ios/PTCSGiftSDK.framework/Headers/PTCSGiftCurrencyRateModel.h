//
//  PTCSGiftCurrencyRateModel.h
//  AFNetworking
//
//  Created by wlighting on 2019/9/2.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PTCSGiftCurrencyRateModel : NSObject

/** 货币符号 */
@property (copy, nonatomic) NSString *country;

/** 货币符号 */
@property (copy, nonatomic) NSString *currency;

/** 货币汇率 */
@property (assign, nonatomic) double dollar_currency_rate;

/** 换算比例 */
@property (assign, nonatomic) double scale;

/** 最终比例 */
@property (assign, nonatomic ,readonly) double totalScale;


@end

NS_ASSUME_NONNULL_END
