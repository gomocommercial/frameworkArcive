//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CSGiftUserBaseInfo.h"


@interface CSGiftUserInfo : CSGiftUserBaseInfo

/**
 * 现金
 */
@property (strong, nonatomic) NSString *cash;

/**
 * 积分, 对应key "point"
 */
@property (assign, nonatomic) NSInteger token;

/**
 * 金币
 */
@property (assign, nonatomic) NSInteger coin;

/**
 * 货币符号
 */
@property (copy, nonatomic) NSString *currency;

@end
