//
//  CSGiftConsumeModel.h
//  AFNetworking
//
//  Created by Zy on 2020/3/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSUInteger {
    CSGiftConsumeSuccess = 10000,//消费成功
    CSGiftConsumeLackOfBlance = 10016,//余额不足
    CSGiftConsumeRepeatPurchase = 10017,//重复消费
} CSGiftConsumeStatus;

@interface CSGiftConsumeModel : NSObject
//订单ID (不可为空)
@property (nonatomic, assign) long orderId;
//价格 (不可为空)
@property (nonatomic, copy) NSString* price;
//花费方式 0：积分 1：现金 (不可为空)
@property (nonatomic, assign) int priceType;
//商品ID (不可为空)
@property (nonatomic, copy) NSString* goodsId;
//商品类型 如： 0：主题商店壁纸 (不可为空)
@property (nonatomic, assign) int goodsType;
//商品名称 (可以为空)
@property (nonatomic, copy) NSString* goodsName;
//商品描述 (可以为空)
@property (nonatomic, copy) NSString* des;
//额外信息字段，传JSON字符串 (可以为空)
@property (nonatomic, copy) NSString* extra;

- (NSDictionary *)modelToDic;

@end

NS_ASSUME_NONNULL_END
