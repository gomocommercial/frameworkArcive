//
// Created by matt on 2019-03-13.
// Copyright (c) 2019 cs. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Co_ad_CSGiftSlotSceneInfo;
@class Co_ad_CSGiftUserInfo;
@class Co_ad_CSGiftWinAward;
@class Co_ad_CSGiftCurrencyRateModel;
@class Co_ad_CSGiftConsumeModel;

typedef void (^Co_ad_CSGiftPreloadHandler)(NSError *error);
typedef void (^Co_ad_CSGiftSlotSceneHandler)(Co_ad_CSGiftSlotSceneInfo *, NSError *error);
typedef void (^Co_ad_CSGiftUserInfoHandler)(Co_ad_CSGiftUserInfo *, NSError *error);
typedef void (^Co_ad_CSGiftCurrencyRateHandler)(Co_ad_CSGiftCurrencyRateModel *currencyRate, NSError *error);
typedef void (^Co_ad_CSGiftCustomSucceessHandler)(Co_ad_CSGiftWinAward *winAward);
typedef void (^Co_ad_CSGiftConsumeSucceessHandler)(NSString *orderId);

/**
 sdk接入类型，用于区分国内和国外
 */
typedef NS_ENUM(NSInteger,Co_ad_CSGiftServiceAreaType) {
    Co_ad_CSGiftOtherServiceArea      =     0,            //其他区域
    Co_ad_CSGiftChinaServiceArea      =     1,            //中国国内
};

typedef NS_ENUM(NSInteger, Co_ad_CSGiftSlotMachineVCShowResult) {
    //配置信息全部拿到 可以展示
    Co_ad_CSGiftSlotMachineShowSuccess = 0,
    //Co_ad_CSGiftUserInfo 数据不存在
    Co_ad_CSGiftSlotMachineInfoError = 1,
    //获取老虎机样式问题
    Co_ad_CSGiftSlotMachineStyleError = 2,
    //广告未准备就绪
    Co_ad_CSGiftAdNoValid = 3,
    //老虎机超出展示次数
    Co_ad_CSGiftSlotMachineDissatisfyDisplayCount = 4,
};

//老虎机奖励结算状态
typedef NS_ENUM(NSInteger,Co_ad_CSGiftSlotMachineLotteryResult){
    Co_ad_CSGiftSlotMachine_Result_Common    = 10000, //正常
    Co_ad_CSGiftSlotMachine_Result_Repeat    = 10010, //重复兑奖
    Co_ad_CSGiftSlotMachine_Result_OverNumer = 10014, //用户活动抽奖次数超过
};

//礼品卡SDK 退出通知
FOUNDATION_EXPORT NSString * const Co_ad_CSGiftExitNotificationName;

/**
 * sdk接口类
 */
@interface Co_ad_CSGiftApi : NSObject


/**
 初始化SDK
 */
+(void)co_ad_setup;

/**
 在APPDelegate 执行applicationDidBecomeActive 时调用
 */
+(void)applicationDidBecomeActive;


/**
 在APPDelegate 执行applicationDidEnterBackground 时调用
 */
+(void)applicationDidEnterBackground;

/**
 根据场景加载数据（若回调成功 请立即执行co_ad_showSlotMachineWithNavigationVC:勿缓存数据）

 @param sceneId 场景ID
 @param slotSceneHandler 数据回调
 */
+(void)co_ad_getSlotScene:(NSInteger)sceneId
        slotSceneHandler:(Co_ad_CSGiftSlotSceneHandler)slotSceneHandler;

/**
 * 展示老虎机
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param presentViewController 当前的控制器
 * @param info 老虎机数据
 * @param callback 结果回调
 * @param slotResultCallback 奖励状态回调
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)co_ad_launchSlot:(UINavigationController *)navigationVC presentViewController:(UIViewController *)presentViewController sceneInfo:(Co_ad_CSGiftSlotSceneInfo *)info ServiceAreaType:(Co_ad_CSGiftServiceAreaType)serviceAreaType resultBlock:(void (^)(Co_ad_CSGiftSlotMachineVCShowResult slotMachineVCShowStyle))callback slotMachineResultBlock:(void (^)(Co_ad_CSGiftSlotMachineLotteryResult))slotResultCallback;

/**
 展示详情页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
   @param serviceAreaType sdk接入类型，国内还是国外
 */
+ (void)co_ad_launchLotteryDetails:(UINavigationController *)navigationVC ServiceAreaType:(Co_ad_CSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;

/**
 push展示购物卡兑换页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 */
+(void)co_ad_pushCashOut:(UINavigationController *)navigationVC animated:(BOOL)animated;
/**
 push展示积分页
 * @param navigationVC 当前控制器的导航控制器 确保可以执行push操作
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)co_ad_pushTokenRedeem:(UINavigationController *)navigationVC ServiceAreaType:(Co_ad_CSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;

/**
 modal展示购物卡兑换页
 * @param currentVC 当前控制器
 */
+(void)co_ad_presentCashOut:(UIViewController *)currentVC animated:(BOOL)animated;
/**
 modal展示积分兑换页
 * @param currentVC 当前控制器
 * @param serviceAreaType  sdk接入类型，用于区分国内和国外
 */
+(void)co_ad_presentTokenRedeem:(UIViewController *)currentVC ServiceAreaType:(Co_ad_CSGiftServiceAreaType)serviceAreaType animated:(BOOL)animated;
/**
 获取用户数据
 */
+(void)co_ad_getUserInfo:(Co_ad_CSGiftUserInfoHandler)userInfoHandler;

/**
 获取汇率
 */
+(void)co_ad_getCurrencyRate:(Co_ad_CSGiftCurrencyRateHandler)currencyRateHandler;

/**
 自定义事件
 error code 10001：活动过期 10002：禁止抽奖，spin不够或者无免费抽奖 10003：中奖 10004：不中奖
 10006：没有同步用户数据 10012：用户礼品卡宝箱抽奖次数超过 10014：用户活动抽奖次数超过
 */
+ (void)co_ad_handleCustomEventWithSequence:(NSInteger)sequence
                            successHandler:(Co_ad_CSGiftCustomSucceessHandler)successHandler
                              failureHandler:(Co_ad_CSGiftPreloadHandler)failureHandler;


/// 消费接口
/// @param model Co_ad_CSGiftConsumeModel
/// @param successHandler <#successHandler description#>
/// @param failureHandler <#failureHandler description#>
+ (void)co_ad_handleConsume:(Co_ad_CSGiftConsumeModel *)model successHandler:(Co_ad_CSGiftConsumeSucceessHandler)successHandler failureHandler:(Co_ad_CSGiftPreloadHandler)failureHandler;

// MARK: - 当SDK外部使用ap/谷歌激励视频时 需在适当的时候调用以下API
/**
 开始展示广告
 */
+ (void)co_ad_externalOnAdShowed;
/**
 点击广告
 */
+ (void)co_ad_externalOnAdClicked;
/**
 关闭广告
 */
+ (void)co_ad_externalOnAdClosed;
/**
 激励视频计费代理
 */
+ (void)co_ad_externalOnAdVideoCompletePlaying;

@end
