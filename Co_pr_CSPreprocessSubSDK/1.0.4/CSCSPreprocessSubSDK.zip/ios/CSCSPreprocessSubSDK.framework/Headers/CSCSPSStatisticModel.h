//
//  CSCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *cSstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *cSoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *cSresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *cSenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *cStabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *cSpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *cSassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *cSadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *cSremarkStr;



@end

NS_ASSUME_NONNULL_END
