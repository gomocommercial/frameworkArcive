//
//  CSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *statisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *operationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *resultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *enterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *tabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *positionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *associationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *advertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *remarkStr;



@end

NS_ASSUME_NONNULL_END
