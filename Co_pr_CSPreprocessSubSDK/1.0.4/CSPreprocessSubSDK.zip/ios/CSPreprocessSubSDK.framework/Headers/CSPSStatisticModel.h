//
//  CSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSPSStatisticModel : NSObject

@property (nonatomic, copy) NSString *operationStr;
@property (nonatomic, copy) NSString *statisticsStr;
@property (nonatomic, copy) NSString *associationStr;
@property (nonatomic, copy) NSString *enterStr;
@property (nonatomic, copy) NSString *tabStr;
@property (nonatomic, copy) NSString *remarkStr;
@property (nonatomic, copy) NSString *positionStr;
@property (nonatomic, assign) NSInteger orderTypeInt;
@property (nonatomic, copy) NSString *orderIdStr;
@property (nonatomic, copy) NSString *resultCodeStr;
@property (nonatomic, copy) NSString *advertIdStr;

@end

NS_ASSUME_NONNULL_END
