//
//  CSPSInitParams.h
//  AFNetworking
//
//  Created by 邝路平 on 2019/9/25.
//

#import <Foundation/Foundation.h>
#import <CSPreprocessSubSDK/CSPSProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CSPSInitParams : NSObject

/**
 * 用于统计用的产品id，19协议的业务id，必传。
 */
@property (strong, nonatomic) NSString *funId;

/**
 * 设置是否测试模式。默认NO，测试模式下，配置错误会Crash。
 */
@property (assign, nonatomic) BOOL isTestMode;

/**
 * 设置是否输出日志。默认NO，不输出。
 */
@property (assign, nonatomic) BOOL enableLog;

- (BOOL)prCheckValid;

@end

NS_ASSUME_NONNULL_END
