//
//  Co_pr_CSPSApi.h
//  AFNetworking
//
//  Created by Zy on 2020/7/14.
//

#import <UIKit/UIKit.h>
#import <Co_pr_CSPreprocessSubSDK/Co_pr_CSPSProtocol.h>

@class Co_pr_CSPSContentModel;
@class Co_pr_CSPSInitParams;

NS_ASSUME_NONNULL_BEGIN

@interface Co_pr_CSPSApi : NSObject

/*********************************SDK初始化及配置*****************************************/
/**
* 启动sdk, 推荐在UIApplicationDelegate#didFinishLaunchingWithOptions里调用，无网络请求。
* 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
* 推荐debug包，默认打开log配置，方便排查问题。
* @param params 初始化参数，funid必填，其它选填,可通过Co_pr_CSPSConfig单例对变量进行修改。
*/
+ (void)co_pr_prSetup:(Co_pr_CSPSInitParams *)params;



// MARK: - 以下接口为客户端通过AB配置对应买量素材展示样式
/// 获取AB配置SID
/// @param isChina 是否为中国区
+ (NSString *)co_pr_prContentIDWithIsChina:(BOOL)isChina;

/// 配置AB模型，当获取成功，SDK会自动预加载对应的视频,当不使用SDK时请不要调用此API
/// @param info AB配置中下key 为infos或infos_”(SDK所使用的SID)“中的数据
/*如：
        infos/infos_927 =     {
            "abtest_id" = 15703;
            cfgs =             (
                                {
                    "cfg_id" = 19158;
                    "cfg_tb_id" = 0;
                    material = yyc03;
                    style = 3;
                    url = {...};
                }
            );
            "filter_id" = 11860;
        };
 */
+ (BOOL)co_pr_prSetupContentModels:(NSDictionary *)info;


/// 验证素材是否有效
/// @param material 素材字符串
+ (BOOL)co_pr_prCheckMaterial:(NSString *)material;


/// Modal前置订阅页
/// @param viewController 在此控制器执行Modal操作
/// @param delegate 事件代理
/// @param material 素材
+ (void)co_pr_prShowWithPresentViewController:(UIViewController *)viewController delegate:(id<Co_pr_CSPSShowDelegate>)delegate material:(NSString *)material;

/// 获取前置订阅页
/// @param delegate 事件代理
/// @param material 素材
+ (UIViewController * _Nullable)co_pr_prGetViewControllerWithDelegate:(id<Co_pr_CSPSShowDelegate>)delegate material:(NSString *)material;




// MARK: - 以下接口为客户端自行选择展示样式


/// 设置前置订阅页展示视频（必须在调用前置订阅页前设置）
/// @param url 视频URL
/// @param showType 展示类型
+ (void)co_pr_prSetupVideoUrl:(NSURL *)url showType:(Co_pr_CSPSShowType)showType;

/// Modal前置订阅页 返回跳转成功/失败
/// @param viewController 在此控制器执行Modal操作
/// @param delegate 事件代理
/// @param showType 样式类型
+ (BOOL)co_pr_prShowWithPresentViewController:(UIViewController *)viewController delegate:(id<Co_pr_CSPSShowDelegate>)delegate showType:(Co_pr_CSPSShowType)showType;

/// 获取前置订阅页
/// @param delegate 事件代理
/// @param showType 样式类型
+ (UIViewController * _Nullable)co_pr_prGetViewControllerWithDelegate:(id<Co_pr_CSPSShowDelegate>)delegate showType:(Co_pr_CSPSShowType)showType;



// MARK: - 以下接口为客户端自行传递统计使用，优先级高于统计SDK

/// 设置自行传递统计统计协议用代理
/// @param delegate 事件代理
+ (void)co_pr_prSetupStatisticDelegate:(id<Co_pr_CSPSStatisticProtocol>)delegate;

@end

NS_ASSUME_NONNULL_END
