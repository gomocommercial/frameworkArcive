//
//  Co_pr_CSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_pr_CSPSStatisticModel : NSObject

@property (nonatomic, copy) NSString *co_pr_operationStr;
@property (nonatomic, copy) NSString *co_pr_statisticsStr;
@property (nonatomic, copy) NSString *co_pr_associationStr;
@property (nonatomic, copy) NSString *co_pr_enterStr;
@property (nonatomic, copy) NSString *co_pr_tabStr;
@property (nonatomic, copy) NSString *co_pr_remarkStr;
@property (nonatomic, copy) NSString *co_pr_positionStr;
@property (nonatomic, assign) NSInteger co_pr_orderTypeInt;
@property (nonatomic, copy) NSString *co_pr_orderIdStr;
@property (nonatomic, copy) NSString *co_pr_resultCodeStr;
@property (nonatomic, copy) NSString *co_pr_advertIdStr;

@end

NS_ASSUME_NONNULL_END
