//
//  PZCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PZCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *pZstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *pZoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *pZresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *pZenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *pZtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *pZpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *pZassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *pZadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *pZremarkStr;



@end

NS_ASSUME_NONNULL_END
