//
//  PCCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *pCstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *pCoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *pCresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *pCenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *pCtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *pCpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *pCassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *pCadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *pCremarkStr;



@end

NS_ASSUME_NONNULL_END
