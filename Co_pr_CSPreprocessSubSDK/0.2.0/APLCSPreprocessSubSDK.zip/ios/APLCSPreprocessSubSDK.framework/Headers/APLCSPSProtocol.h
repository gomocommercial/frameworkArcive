//
//  APLCSPSProtocol.h
//  Pods
//
//  Created by Zy on 2020/7/20.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>

typedef enum : NSUInteger {
    APLCSPSShowTypeOfError = 0,
    APLCSPSShowTypeOfArtLove,//quick art-love样式
    APLCSPSShowTypeOfLove,//illus-love样式
    APLCSPSShowTypeOfIhandy,//ihandy样式
} APLCSPSShowType;//展示样式

typedef enum : NSUInteger {
    APLCSPSWindowTypeOfNormal = 1,//首次弹框
    APLCSPSWindowTypeOfPersuade,//挽留弹框
} APLCSPSWindowType;//弹窗样式

@protocol APLCSPSViewControllerProtocol <NSObject>

/// 订阅成功
/// @param productId 商品ID
- (void)aPLprSubSuccessWithProductId:(NSString * _Nullable)productId;


/// 订阅失败
/// @param productId 商品ID
/// @param errorCode 错误码
- (void)aPLprSubFailedWithProductId:(NSString * _Nullable)productId errorCode:(SKErrorCode)errorCode;

/// 返回起始控制器
- (void)aPLprBackToRootViewController;

@end


@protocol APLCSPSShowDelegate <NSObject>


/// 页面展示
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)aPLprPSDidShowWithShowType:(APLCSPSShowType)showType windowType:(APLCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 订阅点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)aPLprPSSubActionWithCurrentViewController:(UIViewController<APLCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(APLCSPSShowType)showType windowType:(APLCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 关闭点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)aPLprPSCloseActionWithCurrentViewController:(UIViewController<APLCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(APLCSPSShowType)showType windowType:(APLCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;


/// 服务条款点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)aPLprPSTermsOfServiceActionWithCurrentViewController:(UIViewController<APLCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(APLCSPSShowType)showType windowType:(APLCSPSWindowType)windowType;

/// 隐私协议点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)aPLprPSPrivacyPolicyActionWithCurrentViewController:(UIViewController<APLCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(APLCSPSShowType)showType windowType:(APLCSPSWindowType)windowType;

@end
