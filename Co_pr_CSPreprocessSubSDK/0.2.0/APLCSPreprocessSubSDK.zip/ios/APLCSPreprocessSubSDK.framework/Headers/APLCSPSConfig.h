//
//  APLCSPSConfig.h
//
//  Created by Zy on 2019/9/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN




@interface APLCSPSConfig : NSObject

+ (instancetype)aPLprConfig;

/**
 * 设置是否测试服。默认NO，正式服。
 */
@property (assign, nonatomic) BOOL isTestMode;

/**
 * 用于统计用的产品id，19协议的业务id，必传。
 */
@property (strong, nonatomic) NSString *funId;

/**
 * 设置是否输出日志。默认NO，不输出。
 */
@property (assign, nonatomic) BOOL enableLog;


/// 素材
@property (strong, nonatomic) NSString *material;

/// 配置ID
@property (strong, nonatomic) NSString *contentId;


/// SDK版本
@property (strong, nonatomic) NSString *sdkVersionName;

@end

NS_ASSUME_NONNULL_END
