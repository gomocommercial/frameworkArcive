//
//  Co_pr_CSPSProtocol.h
//  Pods
//
//  Created by Zy on 2020/7/20.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>

typedef enum : NSUInteger {
    Co_pr_CSPSShowTypeOfError = 0,
    Co_pr_CSPSShowTypeOfArtLove,//art-love、art-love样式
    Co_pr_CSPSShowTypeOfIhandy,//ihandy样式
    Co_pr_CSPSShowTypeOfLove,//illus-love样式
} Co_pr_CSPSShowType;//展示样式

typedef enum : NSUInteger {
    Co_pr_CSPSWindowTypeOfNormal = 1,//首次弹框
    Co_pr_CSPSWindowTypeOfPersuade,//挽留弹框
} Co_pr_CSPSWindowType;//弹窗样式

@protocol Co_pr_CSPSViewControllerProtocol <NSObject>

/// 订阅成功
/// @param productId 商品ID
- (void)co_pr_prSubSuccessWithProductId:(NSString * _Nullable)productId;


/// 订阅失败
/// @param productId 商品ID
/// @param errorCode 错误码
- (void)co_pr_prSubFailedWithProductId:(NSString * _Nullable)productId errorCode:(SKErrorCode)errorCode;

/// 返回起始控制器
- (void)co_pr_prBackToRootViewController;

@end


@protocol Co_pr_CSPSShowDelegate <NSObject>


/// 页面展示
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)co_pr_prPSViewControllerDidShowWithShowType:(Co_pr_CSPSShowType)showType windowType:(Co_pr_CSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 订阅点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)co_pr_prPSViewControllerSubActionWithCurrentViewController:(UIViewController<Co_pr_CSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(Co_pr_CSPSShowType)showType windowType:(Co_pr_CSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 关闭点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)co_pr_prPSViewControllerCloseActionWithCurrentViewController:(UIViewController<Co_pr_CSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(Co_pr_CSPSShowType)showType windowType:(Co_pr_CSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

@end
