//
//  Co_pr_CSPSApi.h
//  AFNetworking
//
//  Created by Zy on 2020/7/14.
//

#import <Foundation/Foundation.h>
#import <Co_pr_CSPreprocessSubSDK/Co_pr_CSPSProtocol.h>

@class Co_pr_CSPSContentModel;
@class Co_pr_CSPSInitParams;

NS_ASSUME_NONNULL_BEGIN

@interface Co_pr_CSPSApi : NSObject

/*********************************SDK初始化及配置*****************************************/
/**
* 启动sdk, 推荐在UIApplicationDelegate#didFinishLaunchingWithOptions里调用，无网络请求。
* 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
* 推荐debug包，默认打开log配置，方便排查问题。
* @param params 初始化参数，funid必填，其它选填。
*/
+ (void)co_pr_prSetup:(Co_pr_CSPSInitParams *)params;

/// 获取AB配置SID
/// @param isChina 是否为中国区
+ (NSString *)co_pr_prContentIDWithIsChina:(BOOL)isChina;

/// 配置AB模型
/// @param info AB配置中key 为info中对应的字段
+ (BOOL)co_pr_prSetupContentModels:(NSDictionary *)info;


/// 素材是否有效
/// @param material 素材字符串
+ (BOOL)co_pr_prIsValidForMaterial:(NSString *)material;


/// Modal前置订阅页
/// @param viewController 在此控制器执行Modal操作
/// @param delegate 事件代理
/// @param material 素材
+ (void)showWithPresentViewController:(UIViewController *)viewController delegate:(id<Co_pr_CSPSShowDelegate>)delegate material:(NSString *)material;

@end

NS_ASSUME_NONNULL_END
