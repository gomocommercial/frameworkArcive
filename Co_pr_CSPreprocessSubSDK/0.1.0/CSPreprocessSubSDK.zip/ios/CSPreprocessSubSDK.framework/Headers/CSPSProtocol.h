//
//  CSPSProtocol.h
//  Pods
//
//  Created by Zy on 2020/7/20.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>

typedef enum : NSUInteger {
    CSPSShowTypeOfError = 0,
    CSPSShowTypeOfArtLove,//quick art-love样式
    CSPSShowTypeOfLove,//illus-love样式
    CSPSShowTypeOfIhandy,//ihandy样式
} CSPSShowType;//展示样式

typedef enum : NSUInteger {
    CSPSWindowTypeOfNormal = 1,//首次弹框
    CSPSWindowTypeOfPersuade,//挽留弹框
} CSPSWindowType;//弹窗样式

@protocol CSPSViewControllerProtocol <NSObject>

/// 订阅成功
/// @param productId 商品ID
- (void)prSubSuccessWithProductId:(NSString * _Nullable)productId;


/// 订阅失败
/// @param productId 商品ID
/// @param errorCode 错误码
- (void)prSubFailedWithProductId:(NSString * _Nullable)productId errorCode:(SKErrorCode)errorCode;

/// 返回起始控制器
- (void)prBackToRootViewController;

@end


@protocol CSPSShowDelegate <NSObject>


/// 页面展示
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)prPSDidShowWithShowType:(CSPSShowType)showType windowType:(CSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 订阅点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)prPSSubActionWithCurrentViewController:(UIViewController<CSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(CSPSShowType)showType windowType:(CSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 关闭点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)prPSCloseActionWithCurrentViewController:(UIViewController<CSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(CSPSShowType)showType windowType:(CSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;


/// 服务条款点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)prPSTermsOfServiceActionWithCurrentViewController:(UIViewController<CSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(CSPSShowType)showType windowType:(CSPSWindowType)windowType;

/// 隐私协议点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)prPSPrivacyPolicyActionWithCurrentViewController:(UIViewController<CSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(CSPSShowType)showType windowType:(CSPSWindowType)windowType;

@end
