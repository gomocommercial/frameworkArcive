//
//  BYTECSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BYTECSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *bYTEstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *bYTEoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *bYTEresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *bYTEenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *bYTEtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *bYTEpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *bYTEassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *bYTEadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *bYTEremarkStr;



@end

NS_ASSUME_NONNULL_END
