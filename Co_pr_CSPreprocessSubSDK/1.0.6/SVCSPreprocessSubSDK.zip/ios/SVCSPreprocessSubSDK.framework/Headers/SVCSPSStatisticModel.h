//
//  SVCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SVCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *sVstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *sVoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *sVresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *sVenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *sVtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *sVpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *sVassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *sVadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *sVremarkStr;



@end

NS_ASSUME_NONNULL_END
