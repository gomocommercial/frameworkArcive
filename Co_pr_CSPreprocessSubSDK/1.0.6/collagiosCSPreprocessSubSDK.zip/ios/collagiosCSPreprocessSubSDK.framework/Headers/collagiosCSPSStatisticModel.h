//
//  collagiosCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface collagiosCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *collagiosstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *collagiosoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *collagiosresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *collagiosenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *collagiostabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *collagiospositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *collagiosassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *collagiosadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *collagiosremarkStr;



@end

NS_ASSUME_NONNULL_END
