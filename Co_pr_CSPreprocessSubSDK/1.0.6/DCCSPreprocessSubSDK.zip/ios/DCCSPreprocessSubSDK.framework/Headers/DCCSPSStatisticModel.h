//
//  DCCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *dCstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *dCoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *dCresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *dCenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *dCtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *dCpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *dCassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *dCadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *dCremarkStr;



@end

NS_ASSUME_NONNULL_END
