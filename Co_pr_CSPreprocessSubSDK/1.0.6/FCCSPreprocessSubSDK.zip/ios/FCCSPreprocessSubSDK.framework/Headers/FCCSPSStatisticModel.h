//
//  FCCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FCCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *fCstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *fCoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *fCresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *fCenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *fCtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *fCpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *fCassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *fCadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *fCremarkStr;



@end

NS_ASSUME_NONNULL_END
