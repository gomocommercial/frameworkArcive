//
//  FCCSPSProtocol.h
//  Pods
//
//  Created by Zy on 2020/7/20.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>
#import <FCCSPreprocessSubSDK/FCCSPSStatisticModel.h>

typedef enum : NSUInteger {
    FCCSPSShowTypeOfError = 0,//错误状态(预留默认状态)，此状态下SDK不可用,素材验证成功后不会出现此状态
    FCCSPSShowTypeOfArtLove,//quick art-love样式
    FCCSPSShowTypeOfLove,//illus-love样式
    FCCSPSShowTypeOfIhandy,//ihandy样式
} FCCSPSShowType;//展示样式

typedef enum : NSUInteger {
    FCCSPSWindowTypeOfNormal = 1,//首次弹框
    FCCSPSWindowTypeOfPersuade,//挽留弹框
} FCCSPSWindowType;//弹窗样式

@protocol FCCSPSViewControllerProtocol <NSObject>

/// 订阅成功（客户端订阅成功后必须调用此方法通知SDK
/// @param productId 商品ID
- (void)fCprSubSuccessWithProductId:(NSString * _Nullable)productId;


/// 订阅失败（客户端订阅失败后必须调用此方法通知SDK）
/// @param productId 商品ID
/// @param errorCode 错误码
- (void)fCprSubFailedWithProductId:(NSString * _Nullable)productId errorCode:(SKErrorCode)errorCode;

/// 返回从客户端进入SDK的起始控制器（客户端选择性调用）
- (void)fCprBackToRootViewController;

@end


@protocol FCCSPSShowDelegate <NSObject>


/// 订阅页面展示
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)fCprPSDidShowWithShowType:(FCCSPSShowType)showType windowType:(FCCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 订阅点击事件（SDK自带Loading动画，当客户端主动调用FCCSPSViewControllerProtocol中订阅相关协议时，动画结束）
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)fCprPSSubActionWithCurrentViewController:(UIViewController<FCCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(FCCSPSShowType)showType windowType:(FCCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 关闭点击事件（SDK不会主动执行返回操作，需客户端自主控制）
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)fCprPSCloseActionWithCurrentViewController:(UIViewController<FCCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(FCCSPSShowType)showType windowType:(FCCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;


/// 服务条款点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)fCprPSTermsOfServiceActionWithCurrentViewController:(UIViewController<FCCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(FCCSPSShowType)showType windowType:(FCCSPSWindowType)windowType;

/// 隐私协议点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)fCprPSPrivacyPolicyActionWithCurrentViewController:(UIViewController<FCCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(FCCSPSShowType)showType windowType:(FCCSPSWindowType)windowType;

@end

@protocol FCCSPSStatisticProtocol <NSObject>


/// 统计事件触发
/// @param model 统计模型
- (void)fCprPSstatisticActionWithStatisticModel:(FCCSPSStatisticModel * _Nonnull)model;

@end
