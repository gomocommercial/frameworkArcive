//
//  INDOCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface INDOCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *iNDOstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *iNDOoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *iNDOresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *iNDOenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *iNDOtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *iNDOpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *iNDOassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *iNDOadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *iNDOremarkStr;



@end

NS_ASSUME_NONNULL_END
