//
//  FRCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FRCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *fRstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *fRoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *fRresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *fRenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *fRtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *fRpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *fRassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *fRadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *fRremarkStr;



@end

NS_ASSUME_NONNULL_END
