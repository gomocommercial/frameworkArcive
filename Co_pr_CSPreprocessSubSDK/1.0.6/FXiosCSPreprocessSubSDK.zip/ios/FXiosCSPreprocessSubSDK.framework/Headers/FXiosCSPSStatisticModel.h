//
//  FXiosCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FXiosCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *fXiosstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *fXiosoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *fXiosresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *fXiosenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *fXiostabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *fXiospositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *fXiosassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *fXiosadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *fXiosremarkStr;



@end

NS_ASSUME_NONNULL_END
