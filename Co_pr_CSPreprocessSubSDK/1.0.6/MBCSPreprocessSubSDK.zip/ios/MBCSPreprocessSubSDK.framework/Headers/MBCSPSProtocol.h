//
//  MBCSPSProtocol.h
//  Pods
//
//  Created by Zy on 2020/7/20.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>
#import <MBCSPreprocessSubSDK/MBCSPSStatisticModel.h>

typedef enum : NSUInteger {
    MBCSPSShowTypeOfError = 0,//错误状态(预留默认状态)，此状态下SDK不可用,素材验证成功后不会出现此状态
    MBCSPSShowTypeOfArtLove,//quick art-love样式
    MBCSPSShowTypeOfLove,//illus-love样式
    MBCSPSShowTypeOfIhandy,//ihandy样式
} MBCSPSShowType;//展示样式

typedef enum : NSUInteger {
    MBCSPSWindowTypeOfNormal = 1,//首次弹框
    MBCSPSWindowTypeOfPersuade,//挽留弹框
} MBCSPSWindowType;//弹窗样式

@protocol MBCSPSViewControllerProtocol <NSObject>

/// 订阅成功（客户端订阅成功后必须调用此方法通知SDK
/// @param productId 商品ID
- (void)mBprSubSuccessWithProductId:(NSString * _Nullable)productId;


/// 订阅失败（客户端订阅失败后必须调用此方法通知SDK）
/// @param productId 商品ID
/// @param errorCode 错误码
- (void)mBprSubFailedWithProductId:(NSString * _Nullable)productId errorCode:(SKErrorCode)errorCode;

/// 返回从客户端进入SDK的起始控制器（客户端选择性调用）
- (void)mBprBackToRootViewController;

@end


@protocol MBCSPSShowDelegate <NSObject>


/// 订阅页面展示
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)mBprPSDidShowWithShowType:(MBCSPSShowType)showType windowType:(MBCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 订阅点击事件（SDK自带Loading动画，当客户端主动调用MBCSPSViewControllerProtocol中订阅相关协议时，动画结束）
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)mBprPSSubActionWithCurrentViewController:(UIViewController<MBCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(MBCSPSShowType)showType windowType:(MBCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 关闭点击事件（SDK不会主动执行返回操作，需客户端自主控制）
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)mBprPSCloseActionWithCurrentViewController:(UIViewController<MBCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(MBCSPSShowType)showType windowType:(MBCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;


/// 服务条款点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)mBprPSTermsOfServiceActionWithCurrentViewController:(UIViewController<MBCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(MBCSPSShowType)showType windowType:(MBCSPSWindowType)windowType;

/// 隐私协议点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)mBprPSPrivacyPolicyActionWithCurrentViewController:(UIViewController<MBCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(MBCSPSShowType)showType windowType:(MBCSPSWindowType)windowType;

@end

@protocol MBCSPSStatisticProtocol <NSObject>


/// 统计事件触发
/// @param model 统计模型
- (void)mBprPSstatisticActionWithStatisticModel:(MBCSPSStatisticModel * _Nonnull)model;

@end
