//
//  MBCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MBCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *mBstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *mBoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *mBresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *mBenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *mBtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *mBpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *mBassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *mBadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *mBremarkStr;



@end

NS_ASSUME_NONNULL_END
