//
//  RCCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RCCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *rCstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *rCoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *rCresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *rCenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *rCtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *rCpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *rCassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *rCadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *rCremarkStr;



@end

NS_ASSUME_NONNULL_END
