//
//  SWCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SWCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *sWstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *sWoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *sWresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *sWenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *sWtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *sWpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *sWassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *sWadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *sWremarkStr;



@end

NS_ASSUME_NONNULL_END
