//
//  PHCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PHCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *pHstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *pHoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *pHresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *pHenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *pHtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *pHpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *pHassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *pHadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *pHremarkStr;



@end

NS_ASSUME_NONNULL_END
