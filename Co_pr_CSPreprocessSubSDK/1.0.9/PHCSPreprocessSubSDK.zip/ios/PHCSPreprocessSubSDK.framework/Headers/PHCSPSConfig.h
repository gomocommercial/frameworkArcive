//
//  PHCSPSConfig.h
//
//  Created by Zy on 2019/9/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN




@interface PHCSPSConfig : NSObject

+ (instancetype)pHprConfig;

/**
 * 设置是否测试模式。默认NO，测试模式下，配置错误会Crash。
 */
@property (assign, nonatomic) BOOL isTestMode;

/**
 * 用于统计用的产品id，19协议的业务id，必传。
 */
@property (copy, nonatomic) NSString *funId;

/**
 * 设置是否输出日志。默认NO，不输出。
 */
@property (assign, nonatomic) BOOL enableLog;


/// 素材
@property (copy, nonatomic) NSString *material;

/// 配置ID
@property (copy, nonatomic) NSString *contentId;


/// SDK版本
@property (copy, nonatomic) NSString *sdkVersionName;

/// 统计备注字段,可由客户端自定义内容
@property (copy, nonatomic) NSString *statisticRemark;

/// 订阅页中可能会显示的价格,格式为货币符号+价格+/+周期，例$1.99/weak
@property (copy, nonatomic) NSString *subPriceString;

/// 挽留页中可能会显示的价格,格式为货币符号+价格+/+周期，例$1.99/weak
@property (copy, nonatomic) NSString *retainPriceString;

@end

NS_ASSUME_NONNULL_END
