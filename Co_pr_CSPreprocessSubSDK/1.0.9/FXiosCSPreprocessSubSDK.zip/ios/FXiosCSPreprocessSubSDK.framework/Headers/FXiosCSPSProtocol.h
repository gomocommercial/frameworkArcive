//
//  FXiosCSPSProtocol.h
//  Pods
//
//  Created by Zy on 2020/7/20.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>
#import <FXiosCSPreprocessSubSDK/FXiosCSPSStatisticModel.h>

typedef enum : NSUInteger {
    FXiosCSPSShowTypeOfError = 0,//错误状态(预留默认状态)，此状态下SDK不可用,素材验证成功后不会出现此状态
    FXiosCSPSShowTypeOfArtLove,//quick art-love样式
    FXiosCSPSShowTypeOfLove,//illus-love样式
    FXiosCSPSShowTypeOfIhandy,//ihandy样式
    FXiosCSPSShowTypeOfSeekMe,//Seekme样式
    FXiosCSPSShowTypeOfFaceSeer,//FaceSeer样式
    FXiosCSPSShowTypeOfLifeAdvisor,//LifeAdvisor（宝宝）样式
    FXiosCSPSShowTypeOfPicsjoy//Picsjoy（变年轻）样式
} FXiosCSPSShowType;//展示样式

typedef enum : NSUInteger {
    FXiosCSPSWindowTypeOfNormal = 1,//首次弹框
    FXiosCSPSWindowTypeOfPersuade,//挽留弹框
} FXiosCSPSWindowType;//弹窗样式

@protocol FXiosCSPSViewControllerProtocol <NSObject>

/// 订阅成功（客户端订阅成功后必须调用此方法通知SDK
/// @param productId 商品ID
- (void)fXiosprSubSuccessWithProductId:(NSString * _Nullable)productId;


/// 订阅失败（客户端订阅失败后必须调用此方法通知SDK）
/// @param productId 商品ID
/// @param errorCode 错误码
- (void)fXiosprSubFailedWithProductId:(NSString * _Nullable)productId errorCode:(SKErrorCode)errorCode;

/// 返回从客户端进入SDK的起始控制器（客户端选择性调用）
- (void)fXiosprBackToRootViewController;

@end


@protocol FXiosCSPSShowDelegate <NSObject>


/// 订阅页面展示
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)fXiosprPSDidShowWithShowType:(FXiosCSPSShowType)showType windowType:(FXiosCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 订阅点击事件（SDK自带Loading动画，当客户端主动调用FXiosCSPSViewControllerProtocol中订阅相关协议时，动画结束）
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)fXiosprPSSubActionWithCurrentViewController:(UIViewController<FXiosCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(FXiosCSPSShowType)showType windowType:(FXiosCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 关闭点击事件（SDK不会主动执行返回操作，需客户端自主控制）
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)fXiosprPSCloseActionWithCurrentViewController:(UIViewController<FXiosCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(FXiosCSPSShowType)showType windowType:(FXiosCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;


/// 服务条款点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)fXiosprPSTermsOfServiceActionWithCurrentViewController:(UIViewController<FXiosCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(FXiosCSPSShowType)showType windowType:(FXiosCSPSWindowType)windowType;

/// 隐私协议点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)fXiosprPSPrivacyPolicyActionWithCurrentViewController:(UIViewController<FXiosCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(FXiosCSPSShowType)showType windowType:(FXiosCSPSWindowType)windowType;

@end

@protocol FXiosCSPSStatisticProtocol <NSObject>


/// 统计事件触发
/// @param model 统计模型
- (void)fXiosprPSstatisticActionWithStatisticModel:(FXiosCSPSStatisticModel * _Nonnull)model;

@end
