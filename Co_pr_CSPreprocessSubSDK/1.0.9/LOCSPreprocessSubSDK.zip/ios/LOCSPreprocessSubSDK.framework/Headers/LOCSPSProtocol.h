//
//  LOCSPSProtocol.h
//  Pods
//
//  Created by Zy on 2020/7/20.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>
#import <LOCSPreprocessSubSDK/LOCSPSStatisticModel.h>

typedef enum : NSUInteger {
    LOCSPSShowTypeOfError = 0,//错误状态(预留默认状态)，此状态下SDK不可用,素材验证成功后不会出现此状态
    LOCSPSShowTypeOfArtLove,//quick art-love样式
    LOCSPSShowTypeOfLove,//illus-love样式
    LOCSPSShowTypeOfIhandy,//ihandy样式
    LOCSPSShowTypeOfSeekMe,//Seekme样式
    LOCSPSShowTypeOfFaceSeer,//FaceSeer样式
    LOCSPSShowTypeOfLifeAdvisor,//LifeAdvisor（宝宝）样式
    LOCSPSShowTypeOfPicsjoy//Picsjoy（变年轻）样式
} LOCSPSShowType;//展示样式

typedef enum : NSUInteger {
    LOCSPSWindowTypeOfNormal = 1,//首次弹框
    LOCSPSWindowTypeOfPersuade,//挽留弹框
} LOCSPSWindowType;//弹窗样式

@protocol LOCSPSViewControllerProtocol <NSObject>

/// 订阅成功（客户端订阅成功后必须调用此方法通知SDK
/// @param productId 商品ID
- (void)lOprSubSuccessWithProductId:(NSString * _Nullable)productId;


/// 订阅失败（客户端订阅失败后必须调用此方法通知SDK）
/// @param productId 商品ID
/// @param errorCode 错误码
- (void)lOprSubFailedWithProductId:(NSString * _Nullable)productId errorCode:(SKErrorCode)errorCode;

/// 返回从客户端进入SDK的起始控制器（客户端选择性调用）
- (void)lOprBackToRootViewController;

@end


@protocol LOCSPSShowDelegate <NSObject>


/// 订阅页面展示
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)lOprPSDidShowWithShowType:(LOCSPSShowType)showType windowType:(LOCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 订阅点击事件（SDK自带Loading动画，当客户端主动调用LOCSPSViewControllerProtocol中订阅相关协议时，动画结束）
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)lOprPSSubActionWithCurrentViewController:(UIViewController<LOCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(LOCSPSShowType)showType windowType:(LOCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 关闭点击事件（SDK不会主动执行返回操作，需客户端自主控制）
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片(ihandly样式没有图片)
- (void)lOprPSCloseActionWithCurrentViewController:(UIViewController<LOCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(LOCSPSShowType)showType windowType:(LOCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;


/// 服务条款点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)lOprPSTermsOfServiceActionWithCurrentViewController:(UIViewController<LOCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(LOCSPSShowType)showType windowType:(LOCSPSWindowType)windowType;

/// 隐私协议点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)lOprPSPrivacyPolicyActionWithCurrentViewController:(UIViewController<LOCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(LOCSPSShowType)showType windowType:(LOCSPSWindowType)windowType;

@end

@protocol LOCSPSStatisticProtocol <NSObject>


/// 统计事件触发
/// @param model 统计模型
- (void)lOprPSstatisticActionWithStatisticModel:(LOCSPSStatisticModel * _Nonnull)model;

@end
