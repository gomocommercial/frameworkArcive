//
//  LOCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LOCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *lOstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *lOoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *lOresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *lOenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *lOtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *lOpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *lOassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *lOadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *lOremarkStr;



@end

NS_ASSUME_NONNULL_END
