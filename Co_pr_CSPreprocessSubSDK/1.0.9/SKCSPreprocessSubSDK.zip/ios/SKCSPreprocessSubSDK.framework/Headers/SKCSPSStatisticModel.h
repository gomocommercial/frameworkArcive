//
//  SKCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SKCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *sKstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *sKoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *sKresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *sKenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *sKtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *sKpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *sKassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *sKadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *sKremarkStr;



@end

NS_ASSUME_NONNULL_END
