//
//  AJCSPSProtocol.h
//  Pods
//
//  Created by Zy on 2020/7/20.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>

typedef enum : NSUInteger {
    AJCSPSShowTypeOfError = 0,//错误状态(预留默认状态)，此状态下SDK不可用,素材验证成功后不会出现此状态
    AJCSPSShowTypeOfArtLove,//quick art-love样式
    AJCSPSShowTypeOfLove,//illus-love样式
    AJCSPSShowTypeOfIhandy,//ihandy样式
} AJCSPSShowType;//展示样式

typedef enum : NSUInteger {
    AJCSPSWindowTypeOfNormal = 1,//首次弹框
    AJCSPSWindowTypeOfPersuade,//挽留弹框
} AJCSPSWindowType;//弹窗样式

@protocol AJCSPSViewControllerProtocol <NSObject>

/// 订阅成功
/// @param productId 商品ID
- (void)aJprSubSuccessWithProductId:(NSString * _Nullable)productId;


/// 订阅失败
/// @param productId 商品ID
/// @param errorCode 错误码
- (void)aJprSubFailedWithProductId:(NSString * _Nullable)productId errorCode:(SKErrorCode)errorCode;

/// 返回起始控制器
- (void)aJprBackToRootViewController;

@end


@protocol AJCSPSShowDelegate <NSObject>


/// 页面展示
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)aJprPSDidShowWithShowType:(AJCSPSShowType)showType windowType:(AJCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 订阅点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)aJprPSSubActionWithCurrentViewController:(UIViewController<AJCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(AJCSPSShowType)showType windowType:(AJCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;

/// 关闭点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
/// @param selecctImage 用户选中的图片
- (void)aJprPSCloseActionWithCurrentViewController:(UIViewController<AJCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(AJCSPSShowType)showType windowType:(AJCSPSWindowType)windowType selectImage:( UIImage * _Nullable )selecctImage;


/// 服务条款点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)aJprPSTermsOfServiceActionWithCurrentViewController:(UIViewController<AJCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(AJCSPSShowType)showType windowType:(AJCSPSWindowType)windowType;

/// 隐私协议点击事件
/// @param currentViewController 当前展示的控制器
/// @param showType 展示类型
/// @param windowType 弹窗类型
- (void)aJprPSPrivacyPolicyActionWithCurrentViewController:(UIViewController<AJCSPSViewControllerProtocol> *_Nonnull)currentViewController showType:(AJCSPSShowType)showType windowType:(AJCSPSWindowType)windowType;

@end
