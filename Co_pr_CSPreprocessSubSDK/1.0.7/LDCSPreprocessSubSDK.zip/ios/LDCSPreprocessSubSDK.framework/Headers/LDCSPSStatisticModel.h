//
//  LDCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LDCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *lDstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *lDoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *lDresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *lDenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *lDtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *lDpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *lDassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *lDadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *lDremarkStr;



@end

NS_ASSUME_NONNULL_END
