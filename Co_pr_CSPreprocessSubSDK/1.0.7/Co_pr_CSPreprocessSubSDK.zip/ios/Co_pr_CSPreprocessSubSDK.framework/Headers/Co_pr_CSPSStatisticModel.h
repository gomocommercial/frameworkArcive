//
//  Co_pr_CSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_pr_CSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *co_pr_statisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *co_pr_operationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *co_pr_resultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *co_pr_enterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *co_pr_tabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *co_pr_positionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *co_pr_associationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *co_pr_advertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *co_pr_remarkStr;



@end

NS_ASSUME_NONNULL_END
