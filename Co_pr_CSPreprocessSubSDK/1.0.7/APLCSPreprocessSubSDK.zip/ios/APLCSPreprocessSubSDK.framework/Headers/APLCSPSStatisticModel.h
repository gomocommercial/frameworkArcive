//
//  APLCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface APLCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *aPLstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *aPLoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *aPLresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *aPLenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *aPLtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *aPLpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *aPLassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *aPLadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *aPLremarkStr;



@end

NS_ASSUME_NONNULL_END
