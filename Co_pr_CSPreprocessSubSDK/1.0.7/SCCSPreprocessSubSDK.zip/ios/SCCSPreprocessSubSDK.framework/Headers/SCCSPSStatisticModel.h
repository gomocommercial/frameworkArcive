//
//  SCCSPSStatisticModel.h
//  AFNetworking
//
//  Created by Zy on 2020/8/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SCCSPSStatisticModel : NSObject

/**
 * 统计对象
*/
@property (nonatomic, copy) NSString *sCstatisticsStr;
/**
 * 操作代码
*/
@property (nonatomic, copy) NSString *sCoperationStr;
/**
 * 操作结果
*/
@property (nonatomic, copy) NSString *sCresultCodeStr;
/**
 * 入口
*/
@property (nonatomic, copy) NSString *sCenterStr;
/**
 * Tab分类
*/
@property (nonatomic, copy) NSString *sCtabStr;
/**
 * 位置
*/
@property (nonatomic, copy) NSString *sCpositionStr;
/**
 * 关联对象
*/
@property (nonatomic, copy) NSString *sCassociationStr;
/**
 * 广告ID
 */
@property (nonatomic, copy) NSString *sCadvertIdStr;
/**
 * 备注
*/
@property (nonatomic, copy) NSString *sCremarkStr;



@end

NS_ASSUME_NONNULL_END
