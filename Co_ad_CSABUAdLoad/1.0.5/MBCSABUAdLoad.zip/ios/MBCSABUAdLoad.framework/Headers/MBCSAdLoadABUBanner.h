//
//  MBCSAdLoadABUBanner.h
//  MBCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <MBCSAdSDK/MBCSAdLoadProtocol.h>
#import <MBCSAdSDK/MBCSAdLoadBanner.h>
#import <MBCSAdSDK/MBCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface MBCSAdLoadABUBanner : MBCSAdLoadBanner <ABUBannerAdDelegate,MBCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

