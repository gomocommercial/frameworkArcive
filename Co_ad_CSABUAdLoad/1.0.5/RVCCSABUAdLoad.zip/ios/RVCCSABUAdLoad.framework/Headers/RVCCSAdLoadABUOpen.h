//
//  RVCCSAdLoadABUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <RVCCSAdSDK/RVCCSAdLoadOpen.h>
#import <RVCCSAdSDK/RVCCSAdLoadProtocol.h>
#import <RVCCSAdSDK/RVCCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface RVCCSAdLoadABUOpen : RVCCSAdLoadOpen<ABUSplashAdDelegate,RVCCSAdLoadProtocol>

@property(nonatomic, strong) ABUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
