//
//  RVCCSAdLoadABUBanner.h
//  RVCCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <RVCCSAdSDK/RVCCSAdLoadProtocol.h>
#import <RVCCSAdSDK/RVCCSAdLoadBanner.h>
#import <RVCCSAdSDK/RVCCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface RVCCSAdLoadABUBanner : RVCCSAdLoadBanner <ABUBannerAdDelegate,RVCCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

