//
//  APLCSAdLoadABUBanner.h
//  APLCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <APLCSAdSDK/APLCSAdLoadProtocol.h>
#import <APLCSAdSDK/APLCSAdLoadBanner.h>
#import <APLCSAdSDK/APLCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface APLCSAdLoadABUBanner : APLCSAdLoadBanner <ABUBannerAdDelegate,APLCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

