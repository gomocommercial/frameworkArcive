//
//  LDCSAdLoadABUBanner.h
//  LDCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <LDCSAdSDK/LDCSAdLoadProtocol.h>
#import <LDCSAdSDK/LDCSAdLoadBanner.h>
#import <LDCSAdSDK/LDCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface LDCSAdLoadABUBanner : LDCSAdLoadBanner <ABUBannerAdDelegate,LDCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

