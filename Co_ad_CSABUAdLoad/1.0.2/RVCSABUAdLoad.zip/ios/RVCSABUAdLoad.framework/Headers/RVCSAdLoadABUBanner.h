//
//  RVCSAdLoadABUBanner.h
//  RVCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadBanner.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface RVCSAdLoadABUBanner : RVCSAdLoadBanner <ABUBannerAdDelegate,RVCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

