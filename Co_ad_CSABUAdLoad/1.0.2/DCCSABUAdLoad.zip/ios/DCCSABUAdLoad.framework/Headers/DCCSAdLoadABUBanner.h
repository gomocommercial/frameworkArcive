//
//  DCCSAdLoadABUBanner.h
//  DCCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadBanner.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface DCCSAdLoadABUBanner : DCCSAdLoadBanner <ABUBannerAdDelegate,DCCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

