//
//  abufullscreenAd.h
//  AICSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <AICSAdSDK/AICSAdLoadInterstitial.h>
#import <AICSAdSDK/AICSAdLoadProtocol.h>
#import <AICSAdSDK/AICSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <AICSABUAdLoad/AICSABUAdloadConfig.h>

@interface AICSAdLoadABUFullscreenVideo : AICSAdLoadInterstitial<AICSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
