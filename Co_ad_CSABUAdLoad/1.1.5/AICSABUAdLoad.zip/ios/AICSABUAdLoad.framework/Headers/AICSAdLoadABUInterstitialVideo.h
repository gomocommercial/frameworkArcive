//
//  ABUInterstitialProAd.h
//  AICSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <AICSAdSDK/AICSAdLoadInterstitial.h>
#import <AICSAdSDK/AICSAdLoadProtocol.h>
#import <AICSAdSDK/AICSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <AICSABUAdLoad/AICSABUAdloadConfig.h>

///暂时不用
@interface AICSAdLoadABUInterstitialVideo : AICSAdLoadInterstitial<AICSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


