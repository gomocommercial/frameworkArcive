////
////  AICSAdLoadABUInterstitial.h
//
//
//#import <AICSAdSDK/AICSAdLoadInterstitial.h>
//#import <AICSAdSDK/AICSAdLoadProtocol.h>
//#import <AICSAdSDK/AICSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <AICSABUAdLoad/AICSABUAdloadConfig.h>
//
//@interface AICSAdLoadABUInterstitial : AICSAdLoadInterstitial<AICSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
