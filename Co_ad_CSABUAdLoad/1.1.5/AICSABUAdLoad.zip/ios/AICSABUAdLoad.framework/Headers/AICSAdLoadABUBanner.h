//
//  AICSAdLoadABUBanner.h
//  AICSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <AICSAdSDK/AICSAdLoadProtocol.h>
#import <AICSAdSDK/AICSAdLoadBanner.h>
#import <AICSAdSDK/AICSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface AICSAdLoadABUBanner : AICSAdLoadBanner <ABUBannerAdDelegate,AICSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

