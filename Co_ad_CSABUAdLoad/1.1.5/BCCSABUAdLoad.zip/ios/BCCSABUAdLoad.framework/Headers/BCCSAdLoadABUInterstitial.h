////
////  BCCSAdLoadABUInterstitial.h
//
//
//#import <BCCSAdSDK/BCCSAdLoadInterstitial.h>
//#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
//#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <BCCSABUAdLoad/BCCSABUAdloadConfig.h>
//
//@interface BCCSAdLoadABUInterstitial : BCCSAdLoadInterstitial<BCCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
