//
//  ABUInterstitialProAd.h
//  BCCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <BCCSAdSDK/BCCSAdLoadInterstitial.h>
#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <BCCSABUAdLoad/BCCSABUAdloadConfig.h>

///暂时不用
@interface BCCSAdLoadABUInterstitialVideo : BCCSAdLoadInterstitial<BCCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


