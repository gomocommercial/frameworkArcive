//
//  BCCSAdLoadABUBanner.h
//  BCCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadBanner.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface BCCSAdLoadABUBanner : BCCSAdLoadBanner <ABUBannerAdDelegate,BCCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

