//
//  RVCSAdLoadABUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <RVCSAdSDK/RVCSAdLoadOpen.h>
#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface RVCSAdLoadABUOpen : RVCSAdLoadOpen<ABUSplashAdDelegate,RVCSAdLoadProtocol>

@property(nonatomic, strong) ABUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
