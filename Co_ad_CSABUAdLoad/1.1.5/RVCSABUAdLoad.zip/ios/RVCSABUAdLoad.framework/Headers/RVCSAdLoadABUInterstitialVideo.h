//
//  ABUInterstitialProAd.h
//  RVCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <RVCSAdSDK/RVCSAdLoadInterstitial.h>
#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <RVCSABUAdLoad/RVCSABUAdloadConfig.h>

///暂时不用
@interface RVCSAdLoadABUInterstitialVideo : RVCSAdLoadInterstitial<RVCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


