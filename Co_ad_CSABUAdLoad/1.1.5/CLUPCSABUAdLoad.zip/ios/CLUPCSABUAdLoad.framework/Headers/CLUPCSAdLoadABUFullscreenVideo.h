//
//  abufullscreenAd.h
//  CLUPCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <CLUPCSAdSDK/CLUPCSAdLoadInterstitial.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadProtocol.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <CLUPCSABUAdLoad/CLUPCSABUAdloadConfig.h>

@interface CLUPCSAdLoadABUFullscreenVideo : CLUPCSAdLoadInterstitial<CLUPCSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
