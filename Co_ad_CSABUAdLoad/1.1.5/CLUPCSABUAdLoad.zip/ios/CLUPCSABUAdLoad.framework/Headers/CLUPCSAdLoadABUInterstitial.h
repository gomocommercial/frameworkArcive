////
////  CLUPCSAdLoadABUInterstitial.h
//
//
//#import <CLUPCSAdSDK/CLUPCSAdLoadInterstitial.h>
//#import <CLUPCSAdSDK/CLUPCSAdLoadProtocol.h>
//#import <CLUPCSAdSDK/CLUPCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <CLUPCSABUAdLoad/CLUPCSABUAdloadConfig.h>
//
//@interface CLUPCSAdLoadABUInterstitial : CLUPCSAdLoadInterstitial<CLUPCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
