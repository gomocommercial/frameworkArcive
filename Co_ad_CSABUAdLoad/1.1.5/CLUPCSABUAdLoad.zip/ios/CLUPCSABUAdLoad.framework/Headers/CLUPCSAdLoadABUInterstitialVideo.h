//
//  ABUInterstitialProAd.h
//  CLUPCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <CLUPCSAdSDK/CLUPCSAdLoadInterstitial.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadProtocol.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <CLUPCSABUAdLoad/CLUPCSABUAdloadConfig.h>

///暂时不用
@interface CLUPCSAdLoadABUInterstitialVideo : CLUPCSAdLoadInterstitial<CLUPCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


