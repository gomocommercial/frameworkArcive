//
//  abufullscreenAd.h
//  LDCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <LDCSAdSDK/LDCSAdLoadInterstitial.h>
#import <LDCSAdSDK/LDCSAdLoadProtocol.h>
#import <LDCSAdSDK/LDCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <LDCSABUAdLoad/LDCSABUAdloadConfig.h>

@interface LDCSAdLoadABUFullscreenVideo : LDCSAdLoadInterstitial<LDCSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
