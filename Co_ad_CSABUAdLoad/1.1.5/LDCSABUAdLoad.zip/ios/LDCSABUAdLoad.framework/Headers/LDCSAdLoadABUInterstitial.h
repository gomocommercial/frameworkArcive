////
////  LDCSAdLoadABUInterstitial.h
//
//
//#import <LDCSAdSDK/LDCSAdLoadInterstitial.h>
//#import <LDCSAdSDK/LDCSAdLoadProtocol.h>
//#import <LDCSAdSDK/LDCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <LDCSABUAdLoad/LDCSABUAdloadConfig.h>
//
//@interface LDCSAdLoadABUInterstitial : LDCSAdLoadInterstitial<LDCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
