//
//  ABUInterstitialProAd.h
//  LDCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <LDCSAdSDK/LDCSAdLoadInterstitial.h>
#import <LDCSAdSDK/LDCSAdLoadProtocol.h>
#import <LDCSAdSDK/LDCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <LDCSABUAdLoad/LDCSABUAdloadConfig.h>

///暂时不用
@interface LDCSAdLoadABUInterstitialVideo : LDCSAdLoadInterstitial<LDCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


