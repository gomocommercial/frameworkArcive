//
//  ABUInterstitialProAd.h
//  CSCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <CSCSAdSDK/CSCSAdLoadInterstitial.h>
#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <CSCSABUAdLoad/CSCSABUAdloadConfig.h>

///暂时不用
@interface CSCSAdLoadABUInterstitialVideo : CSCSAdLoadInterstitial<CSCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


