//
//  abufullscreenAd.h
//  CSCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <CSCSAdSDK/CSCSAdLoadInterstitial.h>
#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <CSCSABUAdLoad/CSCSABUAdloadConfig.h>

@interface CSCSAdLoadABUFullscreenVideo : CSCSAdLoadInterstitial<CSCSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
