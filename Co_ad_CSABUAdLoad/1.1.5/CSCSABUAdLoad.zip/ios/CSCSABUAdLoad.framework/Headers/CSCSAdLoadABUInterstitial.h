////
////  CSCSAdLoadABUInterstitial.h
//
//
//#import <CSCSAdSDK/CSCSAdLoadInterstitial.h>
//#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
//#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <CSCSABUAdLoad/CSCSABUAdloadConfig.h>
//
//@interface CSCSAdLoadABUInterstitial : CSCSAdLoadInterstitial<CSCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
