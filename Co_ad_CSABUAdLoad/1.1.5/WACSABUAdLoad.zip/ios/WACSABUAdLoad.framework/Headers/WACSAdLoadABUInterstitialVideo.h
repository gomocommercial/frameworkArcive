//
//  ABUInterstitialProAd.h
//  WACSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <WACSAdSDK/WACSAdLoadInterstitial.h>
#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <WACSABUAdLoad/WACSABUAdloadConfig.h>

///暂时不用
@interface WACSAdLoadABUInterstitialVideo : WACSAdLoadInterstitial<WACSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


