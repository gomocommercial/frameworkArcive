//
//  CSCSAdLoadABUInterstitial.h
//  CSCSPeriod
//
//  Created by zhangxin on 2021/12/30.
//

#import <CSCSAdSDK/CSCSAdLoadInterstitial.h>
#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <CSCSABUAdLoad/CSCSABUAdloadConfig.h>

@interface CSCSAdLoadABUInterstitial : CSCSAdLoadInterstitial<CSCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end

