//
//  SLCSAdLoadABUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SLCSAdSDK/SLCSAdLoadReward.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadABUReward : SLCSAdLoadReward<ABURewardedVideoAdDelegate,SLCSAdLoadProtocol>

@property(nonatomic, strong) ABURewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
