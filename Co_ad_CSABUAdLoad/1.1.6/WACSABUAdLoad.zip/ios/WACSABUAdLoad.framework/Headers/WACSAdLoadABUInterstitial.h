////
////  WACSAdLoadABUInterstitial.h
//
//
//#import <WACSAdSDK/WACSAdLoadInterstitial.h>
//#import <WACSAdSDK/WACSAdLoadProtocol.h>
//#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <WACSABUAdLoad/WACSABUAdloadConfig.h>
//
//@interface WACSAdLoadABUInterstitial : WACSAdLoadInterstitial<WACSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
