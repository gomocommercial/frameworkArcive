//
//  abufullscreenAd.h
//  WACSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <WACSAdSDK/WACSAdLoadInterstitial.h>
#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <WACSABUAdLoad/WACSABUAdloadConfig.h>

@interface WACSAdLoadABUFullscreenVideo : WACSAdLoadInterstitial<WACSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
