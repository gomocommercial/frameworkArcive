//
//  CSCSAdLoadABUBanner.h
//  CSCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadBanner.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface CSCSAdLoadABUBanner : CSCSAdLoadBanner <ABUBannerAdDelegate,CSCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

