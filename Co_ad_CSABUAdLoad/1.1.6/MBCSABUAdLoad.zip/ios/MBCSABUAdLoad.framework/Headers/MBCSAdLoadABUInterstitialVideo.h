//
//  ABUInterstitialProAd.h
//  MBCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <MBCSAdSDK/MBCSAdLoadInterstitial.h>
#import <MBCSAdSDK/MBCSAdLoadProtocol.h>
#import <MBCSAdSDK/MBCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <MBCSABUAdLoad/MBCSABUAdloadConfig.h>

///暂时不用
@interface MBCSAdLoadABUInterstitialVideo : MBCSAdLoadInterstitial<MBCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


