////
////  MBCSAdLoadABUInterstitial.h
//
//
//#import <MBCSAdSDK/MBCSAdLoadInterstitial.h>
//#import <MBCSAdSDK/MBCSAdLoadProtocol.h>
//#import <MBCSAdSDK/MBCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <MBCSABUAdLoad/MBCSABUAdloadConfig.h>
//
//@interface MBCSAdLoadABUInterstitial : MBCSAdLoadInterstitial<MBCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
