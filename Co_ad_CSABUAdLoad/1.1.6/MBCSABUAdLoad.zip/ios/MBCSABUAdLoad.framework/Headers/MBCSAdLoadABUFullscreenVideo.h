//
//  abufullscreenAd.h
//  MBCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <MBCSAdSDK/MBCSAdLoadInterstitial.h>
#import <MBCSAdSDK/MBCSAdLoadProtocol.h>
#import <MBCSAdSDK/MBCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <MBCSABUAdLoad/MBCSABUAdloadConfig.h>

@interface MBCSAdLoadABUFullscreenVideo : MBCSAdLoadInterstitial<MBCSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
