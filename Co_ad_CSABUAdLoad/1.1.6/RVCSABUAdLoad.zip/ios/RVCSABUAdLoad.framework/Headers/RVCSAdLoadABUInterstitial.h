////
////  RVCSAdLoadABUInterstitial.h
//
//
//#import <RVCSAdSDK/RVCSAdLoadInterstitial.h>
//#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
//#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <RVCSABUAdLoad/RVCSABUAdloadConfig.h>
//
//@interface RVCSAdLoadABUInterstitial : RVCSAdLoadInterstitial<RVCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
