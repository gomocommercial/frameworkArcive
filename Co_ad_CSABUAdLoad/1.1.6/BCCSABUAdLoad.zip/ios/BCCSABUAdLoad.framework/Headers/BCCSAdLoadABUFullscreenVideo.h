//
//  abufullscreenAd.h
//  BCCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <BCCSAdSDK/BCCSAdLoadInterstitial.h>
#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <BCCSABUAdLoad/BCCSABUAdloadConfig.h>

@interface BCCSAdLoadABUFullscreenVideo : BCCSAdLoadInterstitial<BCCSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
