//
//  ABUInterstitialProAd.h
//  HOCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <HOCSAdSDK/HOCSAdLoadInterstitial.h>
#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <HOCSABUAdLoad/HOCSABUAdloadConfig.h>

///暂时不用
@interface HOCSAdLoadABUInterstitialVideo : HOCSAdLoadInterstitial<HOCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


