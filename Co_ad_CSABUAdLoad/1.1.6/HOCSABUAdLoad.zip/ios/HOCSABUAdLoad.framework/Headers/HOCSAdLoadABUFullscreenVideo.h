//
//  abufullscreenAd.h
//  HOCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <HOCSAdSDK/HOCSAdLoadInterstitial.h>
#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <HOCSABUAdLoad/HOCSABUAdloadConfig.h>

@interface HOCSAdLoadABUFullscreenVideo : HOCSAdLoadInterstitial<HOCSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
