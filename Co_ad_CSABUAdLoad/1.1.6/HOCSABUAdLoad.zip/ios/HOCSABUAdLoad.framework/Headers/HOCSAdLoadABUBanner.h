//
//  HOCSAdLoadABUBanner.h
//  HOCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
#import <HOCSAdSDK/HOCSAdLoadBanner.h>
#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface HOCSAdLoadABUBanner : HOCSAdLoadBanner <ABUBannerAdDelegate,HOCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

