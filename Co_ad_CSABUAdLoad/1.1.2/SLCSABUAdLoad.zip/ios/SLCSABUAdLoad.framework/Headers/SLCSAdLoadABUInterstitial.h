////
////  SLCSAdLoadABUInterstitial.h
//
//
//#import <SLCSAdSDK/SLCSAdLoadInterstitial.h>
//#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
//#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <SLCSABUAdLoad/SLCSABUAdloadConfig.h>
//
//@interface SLCSAdLoadABUInterstitial : SLCSAdLoadInterstitial<SLCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
