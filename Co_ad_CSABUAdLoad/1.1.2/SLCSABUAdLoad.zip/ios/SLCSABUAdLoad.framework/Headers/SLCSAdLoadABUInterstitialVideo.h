//
//  ABUInterstitialProAd.h
//  SLCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <SLCSAdSDK/SLCSAdLoadInterstitial.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <SLCSABUAdLoad/SLCSABUAdloadConfig.h>

///暂时不用
@interface SLCSAdLoadABUInterstitialVideo : SLCSAdLoadInterstitial<SLCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


