//
//  FRCSAdLoadABUBanner.h
//  FRCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <FRCSAdSDK/FRCSAdLoadProtocol.h>
#import <FRCSAdSDK/FRCSAdLoadBanner.h>
#import <FRCSAdSDK/FRCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface FRCSAdLoadABUBanner : FRCSAdLoadBanner <ABUBannerAdDelegate,FRCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

