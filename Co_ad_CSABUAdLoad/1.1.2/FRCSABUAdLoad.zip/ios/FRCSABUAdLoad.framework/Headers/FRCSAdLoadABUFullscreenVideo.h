//
//  abufullscreenAd.h
//  FRCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <FRCSAdSDK/FRCSAdLoadInterstitial.h>
#import <FRCSAdSDK/FRCSAdLoadProtocol.h>
#import <FRCSAdSDK/FRCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <FRCSABUAdLoad/FRCSABUAdloadConfig.h>

@interface FRCSAdLoadABUFullscreenVideo : FRCSAdLoadInterstitial<FRCSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
