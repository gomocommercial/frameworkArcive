//
//  ABUInterstitialProAd.h
//  FRCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <FRCSAdSDK/FRCSAdLoadInterstitial.h>
#import <FRCSAdSDK/FRCSAdLoadProtocol.h>
#import <FRCSAdSDK/FRCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <FRCSABUAdLoad/FRCSABUAdloadConfig.h>

///暂时不用
@interface FRCSAdLoadABUInterstitialVideo : FRCSAdLoadInterstitial<FRCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


