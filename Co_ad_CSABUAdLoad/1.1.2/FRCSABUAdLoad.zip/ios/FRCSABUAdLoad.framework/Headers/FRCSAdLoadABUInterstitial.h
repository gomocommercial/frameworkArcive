////
////  FRCSAdLoadABUInterstitial.h
//
//
//#import <FRCSAdSDK/FRCSAdLoadInterstitial.h>
//#import <FRCSAdSDK/FRCSAdLoadProtocol.h>
//#import <FRCSAdSDK/FRCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <FRCSABUAdLoad/FRCSABUAdloadConfig.h>
//
//@interface FRCSAdLoadABUInterstitial : FRCSAdLoadInterstitial<FRCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
