//
//  ABUInterstitialProAd.h
//  AhhhCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadInterstitial.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <AhhhCSABUAdLoad/AhhhCSABUAdloadConfig.h>

///暂时不用
@interface AhhhCSAdLoadABUInterstitialVideo : AhhhCSAdLoadInterstitial<AhhhCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


