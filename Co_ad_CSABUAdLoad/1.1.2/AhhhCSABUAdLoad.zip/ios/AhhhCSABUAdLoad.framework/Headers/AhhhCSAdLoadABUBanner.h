//
//  AhhhCSAdLoadABUBanner.h
//  AhhhCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadBanner.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface AhhhCSAdLoadABUBanner : AhhhCSAdLoadBanner <ABUBannerAdDelegate,AhhhCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

