////
////  AhhhCSAdLoadABUInterstitial.h
//
//
//#import <AhhhCSAdSDK/AhhhCSAdLoadInterstitial.h>
//#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
//#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <AhhhCSABUAdLoad/AhhhCSABUAdloadConfig.h>
//
//@interface AhhhCSAdLoadABUInterstitial : AhhhCSAdLoadInterstitial<AhhhCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
