//
//  AhhhCSAdLoadABUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <AhhhCSAdSDK/AhhhCSAdLoadOpen.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadABUOpen : AhhhCSAdLoadOpen<ABUSplashAdDelegate,AhhhCSAdLoadProtocol>

@property(nonatomic, strong) ABUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
