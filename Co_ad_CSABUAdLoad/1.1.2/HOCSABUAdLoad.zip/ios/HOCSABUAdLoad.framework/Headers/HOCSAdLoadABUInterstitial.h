////
////  HOCSAdLoadABUInterstitial.h
//
//
//#import <HOCSAdSDK/HOCSAdLoadInterstitial.h>
//#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
//#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <HOCSABUAdLoad/HOCSABUAdloadConfig.h>
//
//@interface HOCSAdLoadABUInterstitial : HOCSAdLoadInterstitial<HOCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
