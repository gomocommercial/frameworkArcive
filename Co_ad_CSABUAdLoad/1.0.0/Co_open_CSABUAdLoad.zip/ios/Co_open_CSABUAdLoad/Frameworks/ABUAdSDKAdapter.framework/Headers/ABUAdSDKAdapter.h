//
//  ABUAdSDKAdapter.h
//  ABUAdSDKAdapter
//
//  Created by wangchao on 2020/2/27.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ABUPanglePersonaliseConfigAdapter.h"
