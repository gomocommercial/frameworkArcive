//
//  Co_open_CSAdLoadABUBanner.h
//  Co_open_CSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <Co_open_CSAdSDK/Co_open_CSAdLoadProtocol.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadBanner.h>
#import <Co_open_CSAdSDK/Co_open_CSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface Co_open_CSAdLoadABUBanner : Co_open_CSAdLoadBanner <ABUBannerAdDelegate,Co_open_CSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

