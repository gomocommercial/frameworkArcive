//
//  Co_open_CSABUConfigModel.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_open_CSABUConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;
//激励视频
@property (nonatomic, copy) NSString *rewardUserID;
@property (nonatomic, assign) ABURitSceneType rewardRitScene;
@property (nonatomic, copy) NSString *rewardRitSceneDescribe;
//插屏
@property (nonatomic, assign) CGSize interstitialAdSize;
@property (nonatomic, copy) NSString *interstitialSceneDescirbe;

//Banner专用 adSize为广告后台配置的尺寸 转换成对应屏幕尺寸的size 居中显示
@property (nonatomic, assign) CGSize adSize;
@property (nonatomic, assign) NSInteger interval;
@property (nonatomic, strong) UIViewController *rootVC;

/**
 Open专用
 Maximum allowable load timeout, default 3s, unit s.
 */
@property (nonatomic, assign) NSTimeInterval tolerateTimeout;

@end

NS_ASSUME_NONNULL_END
