//
//  SWCSAdLoadABUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <SWCSAdSDK/SWCSAdLoadOpen.h>
#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface SWCSAdLoadABUOpen : SWCSAdLoadOpen<ABUSplashAdDelegate,SWCSAdLoadProtocol>

@property(nonatomic, strong) ABUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
