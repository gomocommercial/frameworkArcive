//
//  ABUInterstitialProAd.h
//  SWCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <SWCSAdSDK/SWCSAdLoadInterstitial.h>
#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <SWCSABUAdLoad/SWCSABUAdloadConfig.h>

///暂时不用
@interface SWCSAdLoadABUInterstitialVideo : SWCSAdLoadInterstitial<SWCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


