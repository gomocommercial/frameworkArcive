//
//  abufullscreenAd.h
//  SWCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <SWCSAdSDK/SWCSAdLoadInterstitial.h>
#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <SWCSABUAdLoad/SWCSABUAdloadConfig.h>

@interface SWCSAdLoadABUFullscreenVideo : SWCSAdLoadInterstitial<SWCSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
