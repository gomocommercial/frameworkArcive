////
////  SWCSAdLoadABUInterstitial.h
//
//
//#import <SWCSAdSDK/SWCSAdLoadInterstitial.h>
//#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
//#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <SWCSABUAdLoad/SWCSABUAdloadConfig.h>
//
//@interface SWCSAdLoadABUInterstitial : SWCSAdLoadInterstitial<SWCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
