//
//  SWCSAdLoadABUBanner.h
//  SWCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadBanner.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface SWCSAdLoadABUBanner : SWCSAdLoadBanner <ABUBannerAdDelegate,SWCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

