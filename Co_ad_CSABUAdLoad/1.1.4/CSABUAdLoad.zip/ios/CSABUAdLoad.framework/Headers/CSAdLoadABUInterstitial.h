////
////  CSAdLoadABUInterstitial.h
//
//
//#import <CSAdSDK/CSAdLoadInterstitial.h>
//#import <CSAdSDK/CSAdLoadProtocol.h>
//#import <CSAdSDK/CSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <CSABUAdLoad/CSABUAdloadConfig.h>
//
//@interface CSAdLoadABUInterstitial : CSAdLoadInterstitial<CSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
