//
//  abufullscreenAd.h
//  CSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <CSAdSDK/CSAdLoadInterstitial.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <CSABUAdLoad/CSABUAdloadConfig.h>

@interface CSAdLoadABUFullscreenVideo : CSAdLoadInterstitial<CSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
