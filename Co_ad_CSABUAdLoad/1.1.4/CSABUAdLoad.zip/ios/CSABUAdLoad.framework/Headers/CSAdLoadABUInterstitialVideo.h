//
//  ABUInterstitialProAd.h
//  CSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <CSAdSDK/CSAdLoadInterstitial.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <CSABUAdLoad/CSABUAdloadConfig.h>

///暂时不用
@interface CSAdLoadABUInterstitialVideo : CSAdLoadInterstitial<CSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


