//
//  CSAdLoadABUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CSAdSDK/CSAdLoadReward.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadABUReward : CSAdLoadReward<ABURewardedVideoAdDelegate,CSAdLoadProtocol>

@property(nonatomic, strong) ABURewardedVideoAd *ad;


@end

NS_ASSUME_NONNULL_END
