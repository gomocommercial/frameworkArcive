//
//  CLUPCSAdLoadABUBanner.h
//  CLUPCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <CLUPCSAdSDK/CLUPCSAdLoadProtocol.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadBanner.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface CLUPCSAdLoadABUBanner : CLUPCSAdLoadBanner <ABUBannerAdDelegate,CLUPCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

