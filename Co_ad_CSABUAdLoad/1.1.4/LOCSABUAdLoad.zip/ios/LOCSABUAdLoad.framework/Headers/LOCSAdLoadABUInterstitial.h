////
////  LOCSAdLoadABUInterstitial.h
//
//
//#import <LOCSAdSDK/LOCSAdLoadInterstitial.h>
//#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
//#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>
//#import <ABUAdSDK/ABUAdSDK.h>
//#import <LOCSABUAdLoad/LOCSABUAdloadConfig.h>
//
//@interface LOCSAdLoadABUInterstitial : LOCSAdLoadInterstitial<LOCSAdLoadProtocol,ABUInterstitialAdDelegate>
//@property(nonatomic, strong) ABUInterstitialAd *ad;
//@end
//
