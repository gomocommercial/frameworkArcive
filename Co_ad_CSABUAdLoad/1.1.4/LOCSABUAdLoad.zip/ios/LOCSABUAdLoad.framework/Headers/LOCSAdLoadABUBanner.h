//
//  LOCSAdLoadABUBanner.h
//  LOCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadBanner.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface LOCSAdLoadABUBanner : LOCSAdLoadBanner <ABUBannerAdDelegate,LOCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

