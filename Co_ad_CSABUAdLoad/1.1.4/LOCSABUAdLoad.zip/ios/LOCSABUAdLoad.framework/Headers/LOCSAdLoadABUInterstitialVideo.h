//
//  ABUInterstitialProAd.h
//  LOCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <LOCSAdSDK/LOCSAdLoadInterstitial.h>
#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <LOCSABUAdLoad/LOCSABUAdloadConfig.h>

///暂时不用
@interface LOCSAdLoadABUInterstitialVideo : LOCSAdLoadInterstitial<LOCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end


