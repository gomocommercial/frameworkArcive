//
//  abufullscreenAd.h
//  SLCSABUAdLoad
//
//  Created by linming on 2023/1/5.
//

#import <SLCSAdSDK/SLCSAdLoadInterstitial.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <SLCSABUAdLoad/SLCSABUAdloadConfig.h>

@interface SLCSAdLoadABUFullscreenVideo : SLCSAdLoadInterstitial<SLCSAdLoadProtocol,ABUFullscreenVideoAdDelegate>
@property(nonatomic, strong) ABUFullscreenVideoAd *ad;
@end
