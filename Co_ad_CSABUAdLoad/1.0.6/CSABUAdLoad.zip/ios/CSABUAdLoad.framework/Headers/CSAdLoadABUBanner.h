//
//  CSAdLoadABUBanner.h
//  CSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadBanner.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface CSAdLoadABUBanner : CSAdLoadBanner <ABUBannerAdDelegate,CSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

