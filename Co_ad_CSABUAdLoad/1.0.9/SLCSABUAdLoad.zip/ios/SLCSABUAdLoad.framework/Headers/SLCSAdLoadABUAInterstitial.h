//
//  SLCSAdLoadABUAInterstitial.h
//  SLCSPeriod
//
//  Created by zhangxin on 2021/12/30.
//

#import <SLCSAdSDK/SLCSAdLoadInterstitial.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <SLCSABUAdLoad/SLCSABUAdloadConfig.h>

@interface SLCSAdLoadABUAInterstitial : SLCSAdLoadInterstitial<SLCSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end

