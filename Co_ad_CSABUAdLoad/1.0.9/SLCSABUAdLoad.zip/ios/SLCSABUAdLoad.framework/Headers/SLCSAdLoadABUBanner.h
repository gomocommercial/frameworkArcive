//
//  SLCSAdLoadABUBanner.h
//  SLCSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadBanner.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface SLCSAdLoadABUBanner : SLCSAdLoadBanner <ABUBannerAdDelegate,SLCSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

