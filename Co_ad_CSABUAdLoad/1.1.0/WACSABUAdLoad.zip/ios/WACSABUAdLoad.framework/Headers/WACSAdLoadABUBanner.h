//
//  WACSAdLoadABUBanner.h
//  WACSBUAdLoad
//
//  Created by qiaoming on 2020/12/4.
//

#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadBanner.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface WACSAdLoadABUBanner : WACSAdLoadBanner <ABUBannerAdDelegate,WACSAdLoadProtocol>

@property(nonatomic, strong) ABUBannerAd *ad;

@property(nonatomic, strong) UIView *adView;

@end

