//
//  WACSAdLoadABUInterstitial.h
//  WACSPeriod
//
//  Created by zhangxin on 2021/12/30.
//

#import <WACSAdSDK/WACSAdLoadInterstitial.h>
#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import <WACSABUAdLoad/WACSABUAdloadConfig.h>

@interface WACSAdLoadABUInterstitial : WACSAdLoadInterstitial<WACSAdLoadProtocol,ABUInterstitialProAdDelegate>
@property(nonatomic, strong) ABUInterstitialProAd *ad;
@end

