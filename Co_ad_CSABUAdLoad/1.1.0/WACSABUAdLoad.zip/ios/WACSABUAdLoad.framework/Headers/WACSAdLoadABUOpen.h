//
//  WACSAdLoadABUReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//
#import <WACSAdSDK/WACSAdLoadOpen.h>
#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface WACSAdLoadABUOpen : WACSAdLoadOpen<ABUSplashAdDelegate,WACSAdLoadProtocol>

@property(nonatomic, strong) ABUSplashAd *ad;


@end

NS_ASSUME_NONNULL_END
