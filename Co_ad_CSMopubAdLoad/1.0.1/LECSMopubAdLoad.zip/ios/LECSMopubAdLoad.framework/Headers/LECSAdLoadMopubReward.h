//
//  LECSAdLoadMopubReward.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <mopub-ios-sdk/MoPub.h>
#import <LECSAdSDK/LECSAdLoadReward.h>
#import <LECSAdSDK/LECSAdLoadProtocol.h>
#import <LECSAdSDK/LECSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LECSAdLoadMopubReward : LECSAdLoadReward<LECSAdLoadProtocol,MPRewardedVideoDelegate>

@end

NS_ASSUME_NONNULL_END
