//
//  CSAdMopubInterstitial.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <mopub-ios-sdk/MoPub.h>
#import <QRCSAdSDK/QRCSAdLoadInterstitial.h>
#import <QRCSAdSDK/QRCSAdLoadProtocol.h>
#import <QRCSAdSDK/QRCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QRCSAdLoadMopubInterstitial : QRCSAdLoadInterstitial<QRCSAdLoadProtocol,MPInterstitialAdControllerDelegate>

@property (nonatomic, strong) MPInterstitialAdController *ad;

@end

NS_ASSUME_NONNULL_END
