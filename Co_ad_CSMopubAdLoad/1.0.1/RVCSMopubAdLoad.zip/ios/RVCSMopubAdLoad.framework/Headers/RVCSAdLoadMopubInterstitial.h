//
//  CSAdMopubInterstitial.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <mopub-ios-sdk/MoPub.h>
#import <RVCSAdSDK/RVCSAdLoadInterstitial.h>
#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface RVCSAdLoadMopubInterstitial : RVCSAdLoadInterstitial<RVCSAdLoadProtocol,MPInterstitialAdControllerDelegate>

@property (nonatomic, strong) MPInterstitialAdController *ad;

@end

NS_ASSUME_NONNULL_END
