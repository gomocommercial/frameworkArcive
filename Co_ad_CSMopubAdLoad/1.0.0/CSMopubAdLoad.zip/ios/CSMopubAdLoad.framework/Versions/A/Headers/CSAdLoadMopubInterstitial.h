//
//  CSAdMopubInterstitial.h
//  AdDemo
//
//  Created by Zy on 2019/3/22.
//  Copyright © 2019 Zy. All rights reserved.
//

#import <mopub-ios-sdk/MoPub.h>
#import <CSAdSDK/CSAdLoadInterstitial.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadMopubInterstitial : CSAdLoadInterstitial<CSAdLoadProtocol,MPInterstitialAdControllerDelegate>

@property (nonatomic, strong) MPInterstitialAdController *ad;

@end

NS_ASSUME_NONNULL_END
