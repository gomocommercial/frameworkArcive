//
//  GMRequest.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

@class GMURL;

typedef NS_ENUM(NSUInteger, GMRequestActionType) {
    GMRequestActionTypeAsync,      // 异步请求
    GMRequestActionTypeSync        // 同步请求
};

typedef NS_ENUM (NSInteger, GMHttpAuthenticationType) {
    GMHttpAuthenticationTypeNone = 0,
    GMHttpAuthenticationTypeBasic,//HTTP BASIC认证
    GMHttpAuthenticationTypeToken,//账户系统的Access Token认证
    GMHttpAuthenticationTypeTransactionToken,//交易token
    GMHttpAuthenticationTypeTransactionAccessToken//交易access token
};

typedef NS_ENUM (NSInteger, GMHttpMethod) {
    GMHttpMethodGET = 0,
//    GWSHttpMethodGETLastModified,//Conditional Get
//    GWSHttpMethodGETETag,//Conditional Get
    GMHttpMethodPOST,
    GMHttpMethodPUT,
    GMHttpMethodDELETE,
    GMHttpMethodUPDATE,
};

@interface GMRequest : NSObject

@property (nonatomic, readonly) GMURL *URL;

@property (nonatomic,copy) NSString *originQueryString; //最原始的请求URL,在搜索请求中，非英文，需要UTF8转码，而使用URL生成签名时，又不需要对非英文转码，所以需要保留最原始的URL请求字符串

@property (nonatomic, assign) GMHttpAuthenticationType authenticationType;

@property (nonatomic, assign) GMHttpMethod method;

@property (nonatomic, copy) NSDictionary *queries;//参数

@property (nonatomic, strong, readonly) NSMutableDictionary *additionalQueryDictionary;//增加参数

@property (nonatomic, copy) NSString *XSignatureKey;

@property (nonatomic, copy) NSString *clientID;

@property (nonatomic, copy) NSString *clientSecret;

@property (nonatomic, copy) NSString *access_token;

@property (nonatomic, copy) NSString *account_id;

@property (nonatomic, assign) BOOL isForConfigure; //是否为配置项管理后台的请求，因为他们的头部签名定义不一样
@property (nonatomic, copy) NSString *hostHeader;

@property (nonatomic) BOOL needDeviceForGet;

/**
 * 账号系统的加密头
 */
@property (nonatomic) BOOL needCrypto;

/**
 * 账号系统自定义did
 */
@property (nonatomic, copy) NSString *customize_did;

/**
 * ColorCall业务逻辑加密头
 */
@property (nonatomic) BOOL needServerEncrypt;

/// 请求类型(默认异步请求)
@property (nonatomic, assign) GMRequestActionType requestActionType;

@property (nonatomic) BOOL isForShortVideo;

/**
 * 短视频位置信息，专门为短视频提供Phead数据的
 */
@property (nonatomic, copy) NSString *locationForVideo;

/**
 用于(glive-api)
 */
@property (nonatomic) BOOL needXUserIdHeader;

- (instancetype)initWithBaseUrl:(NSString *)url domain:(NSString *)domain;

/**
 参数会加到additionalQueryDictionary
 */
- (void)setQueryValue:(id)value forKey:(NSString *)key;

/**（请求方法）用于X-Signature签名 **/
- (NSString *)methodName;
/*（请求路径） 用于X-Signature签名 **/
- (NSString *)requestUri;
/*（查询字符串）用于X-Signature签名 **/
- (NSString *)queryString;
/*（请求体）用于X-Signature签名 **/
- (NSString *)payload;


@end
