//
//  NSString+AhhhGMNetSecure.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (AhhhGMNetSecure)
NSData * ahhhcsAccountHmacForKeyAndData(NSString *key, NSString *data);

//- (NSString *)SHA256;

- (NSString *)ahhhcsAcountSha256;

- (NSString *)ahhhcsAccountSha256AndUpperCase;

- (NSString *)ahhhcsAccountBase64EncodedString:(NSString *)string;

- (NSString *)ahhhcsAccountBase64DecodedString:(NSString *)string;

- (NSString *)ahhhcsAccountsafeUrlBase64Encode:(NSString *)str;

- (NSString *)ahhhcsAccountSafeUrlBase64Decode:(NSString *)safeUrlbase64Str;

+ (NSString *)ahhhcsAccountHmac:(NSString *)plaintext withKey:(NSString *)key;

+ (NSString *)ahhhcsAccountHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

@end

NS_ASSUME_NONNULL_END
