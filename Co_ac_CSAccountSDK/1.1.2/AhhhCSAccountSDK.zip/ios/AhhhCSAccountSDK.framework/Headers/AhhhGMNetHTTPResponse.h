//
//  AhhhGMNetHTTPResponse.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

#import "AhhhGMNetError.h"

typedef NS_ENUM(NSInteger , AhhhGMHttpStatus) {
    AhhhGMHttpStatusFail = -1,
    AhhhGMHttpStatusSuccess = 0,
    AhhhGMHttpStatusInvalidSign = -100,//无效的签名
};

@interface AhhhGMNetHTTPResponse : NSObject
@property (nonatomic) AhhhGMHttpStatus status;


/**
 http 的返回码
 */
@property (nonatomic) NSInteger statusCode;
@property (nonatomic, strong) AhhhGMNetError *error;
@property (nonatomic, copy) NSDictionary *bodyData;
@property (nonatomic, copy) NSString *bodyString;
@property (nonatomic, strong) NSURLResponse *response;


/**
 资源路径
 */
@property (nonatomic, copy) NSString *path;

@property (nonatomic, copy) NSDictionary *httpHeader;


- (BOOL)isSuccess;

- (NSString *)errorLog;

- (NSString *)errorTips;


@end
