//
//  AhhhGMNetHelper.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLRequestSerialization.h>
#import <AFNetworking/AFURLResponseSerialization.h>
#import "AhhhGMNetHTTPResponse.h"
#import "AhhhGMRequest.h"
#import "AhhhGMHttpSesstionManager.h"
NS_ASSUME_NONNULL_BEGIN

typedef void (^AhhhGMAccountHTTPResponseSucceedHandler)(AhhhGMNetHTTPResponse *response);

@interface AhhhGMNetHelper : NSObject

@property (nonatomic, strong) AhhhGMHttpSesstionManager *httpManager;

- (void)startAsyncWithRequest:(AhhhGMRequest *)request finish:(AhhhGMAccountHTTPResponseSucceedHandler)finish;

@end


NS_ASSUME_NONNULL_END
