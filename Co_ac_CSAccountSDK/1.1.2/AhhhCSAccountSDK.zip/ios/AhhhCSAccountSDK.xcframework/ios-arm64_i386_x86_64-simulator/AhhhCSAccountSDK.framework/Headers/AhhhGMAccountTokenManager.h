//
//  AhhhGMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AhhhGMAccountTokenInfo.h"
#import "AhhhGMAccountCenterApiManager.h"

typedef NS_ENUM(NSInteger,AhhhGMTokenStateType) {
    AhhhGMTokenNormal,                  //token正常，无需刷新
    AhhhGMTokenRefreshed,               //已刷新token
};
typedef void (^AhhhGMTokenRefreshStateBlock)(AhhhGMTokenStateType tokenState);
@interface AhhhGMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) AhhhGMAccountTokenInfo *tokenInfo;

+ (AhhhGMAccountTokenManager *)sharedManager;

- (void)ahhhupdateTokenInfo:(AhhhGMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)ahhhcleanTokenInfo;


/**
 *判断token是否过期去刷新token,应用启动时应该显式的调用
 *freshStateBlock刷新状态回调
 */
- (void)ahhhrefreshTokenIfNeed:(AhhhGMAccountCenterApiCompleteBlock)complete RefreshState:(AhhhGMTokenRefreshStateBlock)freshStateBlock;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)ahhhneedRefreshToken;

@end
