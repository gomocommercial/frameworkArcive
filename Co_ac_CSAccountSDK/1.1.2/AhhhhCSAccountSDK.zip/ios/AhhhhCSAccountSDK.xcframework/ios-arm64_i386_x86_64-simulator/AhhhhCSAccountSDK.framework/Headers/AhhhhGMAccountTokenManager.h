//
//  AhhhhGMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AhhhhGMAccountTokenInfo.h"
#import "AhhhhGMAccountCenterApiManager.h"

typedef NS_ENUM(NSInteger,AhhhhGMTokenStateType) {
    AhhhhGMTokenNormal,                  //token正常，无需刷新
    AhhhhGMTokenRefreshed,               //已刷新token
};
typedef void (^AhhhhGMTokenRefreshStateBlock)(AhhhhGMTokenStateType tokenState);
@interface AhhhhGMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) AhhhhGMAccountTokenInfo *tokenInfo;

+ (AhhhhGMAccountTokenManager *)sharedManager;

- (void)ahhhhupdateTokenInfo:(AhhhhGMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)ahhhhcleanTokenInfo;


/**
 *判断token是否过期去刷新token,应用启动时应该显式的调用
 *freshStateBlock刷新状态回调
 */
- (void)ahhhhrefreshTokenIfNeed:(AhhhhGMAccountCenterApiCompleteBlock)complete RefreshState:(AhhhhGMTokenRefreshStateBlock)freshStateBlock;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)ahhhhneedRefreshToken;

@end
