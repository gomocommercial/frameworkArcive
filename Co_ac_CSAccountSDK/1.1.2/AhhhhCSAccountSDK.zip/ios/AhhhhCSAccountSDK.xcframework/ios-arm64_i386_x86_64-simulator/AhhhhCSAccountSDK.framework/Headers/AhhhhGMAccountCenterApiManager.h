//
//  AhhhhGMAccountCenterApiManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/11.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AhhhhGMABindAccount.h"

#define kVerificationCodeTypeRegister   @"REGISTER" //注册
#define kVerificationCodeTypeLogin      @"LOGIN" //登陆
#define kVerificationCodeTypeBinding    @"BINDING" //绑定
#define kVerificationCodeTypeUnbinding  @"UNBINDING" //解除绑定
#define kVerificationCodeTypeRetrievePwd @"RETRIEVE_PWD" //找回密码

#define kRegisterTypeVisitor            @"visitor"
#define kRegisterTypeMobile             @"mobile"
#define kRegisterTypeEmail              @"email"
#define kRegisterTypeFacebook           @"facebook"
#define kRegisterTypeGoogle             @"google"
#define kRegisterTypeTwitter            @"twitter"
#define kRegisterTypeInstagram          @"instagram"

#define kOpenConnectTypeFacebook        @"facebook"
#define kOpenConnectTypeGoogle          @"google"
#define kOpenConnectTypeTwitter         @"twitter"
#define kOpenConnectTypeInstagram       @"instagram"
#define kOpenConnectTypeIOS             @"ios"

#define kBindingTypeMobileToOpenID      @"MOBILE_TO_OPEN_ID"
#define kBindingTypeOpebIDToMobile      @"OPEN_ID_TO_MOBILE"

@class AhhhhGMNetHTTPResponse;
typedef void (^AhhhhGMAccountCenterApiCompleteBlock) (AhhhhGMNetHTTPResponse *response);
typedef void (^AhhhhGMAccountNeedLoginBlock)(void);

@interface AhhhhGMAccountCenterApiManager : NSObject

+ (AhhhhGMAccountCenterApiManager *)sharedManager;

@property (nonatomic, copy) AhhhhGMAccountNeedLoginBlock accountNeedLoginBlock;

#pragma mark - 第三方登陆接口

/**
 第三方登陆接口 POST HTTP BASIC 认证
 //资源路径：/v3/{open_connect_type}/login
 @param openConnectType 第三方登陆类型
 @param openId 第三方登陆Id 非空
 @param vistorId 非必需项，如果客户端需要将已存在的游客用户转化为第三方登陆用户，则传此值
 @param open_connect_user_name 非空
 @param complete <#complete description#>
 */
- (void)ahhhhloginThirdPartyWithOpenConnectType:(NSString *)openConnectType openId:(NSString *)openId visitorId:(NSString *)visitorId openConnectUserName:(NSString *)open_connect_user_name complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 游客接口

/**
 游客注册登录 POST Access Token认证
 //资源路径：/v3/visitor/login
 @param accountId 账号id
 @param complete <#complete description#>
 */
- (void)ahhhhloginWithVisitorRegisterWithAccountId:(NSString *)accountId complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;
#pragma mark - Token接口
/**
 刷新token post
 //资源路径：/v3/token/refresh

 @param complete <#complete description#>
 */
- (void)ahhhhrefreshTokencomplete:(AhhhhGMAccountCenterApiCompleteBlock)complete;
#pragma mark - 注册用户信息通用操作接口
/**
 退出登陆 POST HTTP BASIC 认证
 退出后，之前所分配的access token将被置为无效
 @param registerType <#registerType description#>
 @param complete <#complete description#>
 */
- (void)ahhhhlogoutWithRegisterType:(NSString *)registerType complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

- (void)ahhhhcancellationForOpenUserWithiOS:(NSString *)registerType bindAccounts:(NSArray<AhhhhGMABindAccount *> *)bindAccounts complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;
- (void)ahhhhcancellationWithiOS:(NSString *)registerType identityId:(NSString *)identityId complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;
#pragma mark - 获取用户的账号基本信息
/**
 获取用户的账号基本信息 GET Access Token认证
资源路径：/v3/{register_type}/basic
 @param register_type 注册方式的小写形式，例如：mobile	非空
 @param complete <#complete description#>
 */
- (void)ahhhhfetchUserBasicInfo:(NSString *)register_type complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 获取用户的profile信息
/**
 获取用户的profile信息 GET Access Token认证
 资源路径：/v3/{register_type}/profile
 @param register_type 注册方式的小写形式，例如：mobile
 @param complete <#complete description#>
 */
- (void)ahhhhfetchUserProfileWithRegisterType:(NSString *)register_type complete:(AhhhhGMAccountCenterApiCompleteBlock)complete ;

#pragma mark - 新增或更新用户的profile信息
/**
 新增或更新用户的profile信息 PUT
 资源路径：/v3/{register_type}/profile
 @param profileJsonDic 只需设置需要更新的字段信息即可
 @param complete <#complete description#>
 */
- (void)ahhhhupdataUserProfile:(NSDictionary *)profileJsonDic registerType:(NSString *)register_type complete:(AhhhhGMAccountCenterApiCompleteBlock)complete ;

#pragma mark - 获取用户的所有附加信息

/**
 获取用户的所有附加信息 GET Access Token认证
 资源路径：资源路径：/v3/{register_type}/attach_info
 @param register_type 注册方式的小写形式，例如：mobile 非空
 @param complete <#complete description#>
 */
- (void)ahhhhfetchUserAttachInfoWithRegisterType:(NSString *)register_type complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;


#pragma mark - 获取用户的某一部分附加信息

/**
 获取用户的某一部分附加信息 POST Access Token认证
资源路径：/v3/{register_type}/attach_info/segment
 @param register_type 注册方式的小写形式，例如：mobile
 @param complete <#complete description#>
 */
- (void)ahhhhfetchUserAttachInfoSegmentWithRegisterType:(NSString *)register_type complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;


#pragma mark - 新增或更新用户的附加信息

/**
 新增或更新用户的附加信息 PUT Access Token认证
 资源路径：资源路径：/v3/{register_type}/attach_info
 @param register_type 注册方式的小写形式，例如：mobile 非空
 @param JsonObject 更新的键值对信息，其键为用JsonPath表示的key，其值为对应的更新值
 @param complete <#complete description#>
 */
- (void)ahhhhupdataUserAttachInfoWithRegisterType:(NSString *)register_type jsonObject:(id)JsonObject complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - *************************手机接口****************************

#pragma mark - 手机号码密码登录

/**
 手机号码密码登录 POST HTTP BASIC 认证
 资源路径：/v2/mobile/{phonenumber}/login/password

 @param phoneNumber <#phoneNumber description#>
 @param password <#password description#>
 @param complete <#complete description#>
 */
- (void)ahhhhloginWithPhone:(NSString *)phoneNumber password:(NSString *)password complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 验证码登录
/**
 验证码登录
 
 @param phoneNumber <#phoneNumber description#>
 @param auto_register 如果该手机号之前尚未注册，是否自动注册
 @param complete <#complete description#>
 */
- (void)ahhhhloginWithMobileSMSVerificationCode:(NSString *)phoneNumber auto_register:(BOOL)auto_register complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 发送短信验证码
/**
 发送短信验证码 POST HTTP BASIC 认证
 * 资源路径：/v2/mobile/{phonenumber}/verification_code

 @param phone <#phone description#>
 @param complete <#complete description#>
 */
- (void)ahhhhgetMobileSMSVerificationCode:(NSString *)phone verificationCodeType:(NSString *)verificationCodeType complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 验证短信验证码
/**
 验证短信验证码 POST HTTP BASIC 认证
 资源路径：/v2/mobile/{phonenumber}/verification_code/{verificationCode}
 @param phone <#phone description#>
 @param code <#code description#>
 @param verificationCodeType 验证的短信验证码类型,REGISTER 注册 LOGIN 登陆 BINDING 手机绑定 RETRIVE_PWD 找回密码
 @param complete <#complete description#>
 */
- (void)ahhhhcheckMobileSMSVerificationCode:(NSString *)phone code:(NSString *)code verificationCodeType:(NSString *)verificationCodeType complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 手机号码注册

/**
 * 注册 POST HTTP BASIC 认证
 * 调用此接口需要注册短信验证码权限
 * 用户注册成功后，默认用户密码为空字符串，是否需要为用户设置密码由客户端决定
 * 如果客户端需要为注册用户设置密码，则调用重置密码接口，旧密码传空字符串
 * 资源路径：/v2/mobile/{phonenumber}/register

 @param phone 格式为国家号码格式或标准的E.164格式,如果号码格式为国家号码格式，国家信息取至Device中的country字段
 @param password 使用SHA256对原始密码进行哈希,非必需项，如果指定，表示注册时同时设定密码
 @param visitorId 非必需项，如果客户端需要将已存在的游客用户转化为手机注册用户，则传此值
 @param complete <#complete description#>
 */
- (void)ahhhhregisterWithPhone:(NSString *)phone password:(NSString *)password visitorId:(NSString *)visitorId complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 重置密码
/**
 重置密码 PUT HTTP BASIC 认证
 资源路径：/v2/mobile/{phonenumber}/password/reset
 @param phone 路径参数
 @param oldPassword 旧密码（大写形式）,使用SHA256对原始密码进行哈希
 @param newPassword 新密码（大写形式）使用SHA256对原始密码进行哈希
 @param complete <#complete description#>
 */
- (void)ahhhhresetPassWordWithPhone:(NSString *)phone oldPassword:(NSString *)oldPassword newPassword:(NSString *)newPassword complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 找回密码
/**
 找回密码,调用此接口需要找回密码短信验证码权限 PUT HTTP BASIC 认证
/v2/mobile/{phonenumber}/password/retrieve
 @param phone <#phone description#>
 @param password <#password description#>
 @param complete <#complete description#>
 */
- (void)ahhhhretrivePasswordWithPhone:(NSString *)phone password:(NSString *)password complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 手机号码绑定
/**
 手机绑定 POST Access Token认证
/v2/mobile/binding
 @param phone <#phone description#>
 @param bindingType 取值有
 MOBILE_TO_OPEN_ID 已存在的手机号绑定未存在的第三方登陆账号
 OPEN_ID_TO_MOBILE 已存在的第三方登陆账号绑定绑定未存在的手机号
 @param openConnectType <#openConnectType description#>
 @param openId <#openId description#>
 @param complete <#complete description#>
 */
- (void)ahhhhmobileBindingWithPhone:(NSString *)phone bindingType:(NSString *)bindingType openConnectType:(NSString *)openConnectType openId:(NSString *)openId complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 手机号码解绑
/**
 手机解绑 调用此接口需要解绑手机短信验证码权限（UNBINDING ）
/v2/mobile/unbinding POST Access Token认证
 @param phone <#phone description#>
 @param bindingType 取值有
 MOBILE_TO_OPEN_ID 使用手机号解绑第三方登陆账号
 OPEN_ID_TO_MOBILE 使用第三方登陆账号解绑手机号
 @param openConnectType <#openConnectType description#>
 @param openId <#openId description#>
 @param complete <#complete description#>
 */
- (void)ahhhhmobileUnbindingWithPhone:(NSString *)phone bindingType:(NSString *)bindingType openConnectType:(NSString *)openConnectType openId:(NSString *)openId complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 获取绑定账号列表
/**
 获取绑定账号列表 GET Access Token认证
/v2/{register_type}/binding
 @param register_type <#register_type description#>
 @param complete <#complete description#>
 */
- (void)ahhhhfetchBindingWithRegisterType:(NSString *)register_type complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 绑定
/**
 绑定:绑定操作为使用已存在的注册用户绑定不存在的注册用户
 注册用户之间支持互相绑定，绑定和解绑手机需要验证码授权，如果注册方式不支持绑定操作，将返回错误码NOT_SUPPORTED
/v2/{register_type}/binding POST Access Token认证
 @param register_type <#register_type description#>
 @param binding_register_type <#binding_register_type description#>
 @param binding_identity_id <#binding_identity_id description#>
 @param binding_account_attach_info <#binding_account_attach_info description#>
 @param complete <#complete description#>
 */
- (void)ahhhhbindingWithRegisterType:(NSString *)register_type bindingRegisterType:(NSString *)binding_register_type bindingIdentityId:(NSString *)binding_identity_id bindingAccountAttachInfo:(NSString *)binding_account_attach_info complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 解绑
/**
 解绑:解绑手机需要验证码授权，如果注册方式不支持绑定操作，将返回错误码NOT_SUPPORTED
/v2/{register_type}/unbinding POST Access Token认证
 @param register_type <#register_type description#>
 @param unbinding_register_type <#unbinding_register_type description#>
 @param unbinding_identity_id <#unbinding_identity_id description#>
 @param complete <#complete description#>
 */
- (void)ahhhhunbindingWithRegisterType:(NSString *)register_type unbindingRegisterType:(NSString *)unbinding_register_type unbindingIdentityId:(NSString *)unbinding_identity_id complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark - 更换绑定的手机号
/**
 更换绑定的手机号,调用此接口需要有旧手机解绑和新手机绑定的短信验证码权限
 /v3/mobile/change
 @param oldPhonenumber <#oldPhonenumber description#>
 @param newPhonenumber <#newPhonenumber description#>
 @param complete <#complete description#>
 */
- (void)ahhhhchangePhoneWithOldPhonenumber:(NSString *)oldPhonenumber newPhonenumber:(NSString *)newPhonenumber complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;


#pragma mark- *******************************邮箱服务*****************************

#pragma mark -  发送邮箱验证码
/**
 发送邮箱验证码 POST HTTP BASIC 认证
 * 资源路径：/v3/email/verification_code

 @param email <#email description#>
 @param verificationCodeType 验证的验证码类型,REGISTER 注册 BINDING 邮箱绑定 UNBINDING 邮箱解绑 RETRIVE_PWD 找回密码
 @param complete <#complete description#>
 */
- (void)ahhhhgetEmailVerificationCode:(NSString *)email verificationCodeType:(NSString *)verificationCodeType complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark -  验证邮箱验证码
/**
 验证邮箱验证码 POST HTTP BASIC 认证
 资源路径：/v3/email/verification_code/{verificationCode}
 @param email <#phone description#>
 @param code <#code description#>
 @param verificationCodeType 验证的验证码类型,REGISTER 注册 BINDING 邮箱绑定 UNBINDING 邮箱解绑 RETRIVE_PWD 找回密码
 @param complete <#complete description#>
 校验码校验成功后，会授予客户端调用相应接口功能(注册等)的验证码权限，有效期为码验码验证成功后的10分钟内
 如果客户端调用相应接口时，服务器返回不存在相应的验证码权限，客户端需要提示用户重新获取验证码
 */
- (void)ahhhhcheckEmailVerificationCode:(NSString *)email code:(NSString *)code verificationCodeType:(NSString *)verificationCodeType complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark -  邮箱注册
/**
 * 邮箱注册 POST HTTP BASIC 认证
 * 如果客户端在服务器后台配置要求注册时进行验证码授权，则调用此接口需要注册邮箱验证码权限，否则可直接注册
 * 资源路径：/v3/email/register
 
 @param email 格式为国家号码格式或标准的E.164格式,如果号码格式为国家号码格式，国家信息取至Device中的country字段
 @param password 使用SHA256对原始密码进行哈希(大写),非必需项，如果指定，表示注册时同时设定密码，否则，默认用户密码为空字符串
 @param visitorId 非必需项，如果客户端需要将已存在的游客用户转化为邮箱注册用户，则传此值
 @param complete <#complete description#>
 */
- (void)ahhhhregisterWithEmail:(NSString *)email password:(NSString *)password visitorId:(NSString *)visitorId complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;
#pragma mark -  邮箱密码登录

/**
 邮箱密码登录 POST HTTP BASIC 认证
 资源路径：/v3/email/login/password
 
 @param email <#phoneNumber description#>
 @param password 非空，使用SHA256对原始密码进行哈希(大写)
 @param complete <#complete description#>
 */
- (void)ahhhhloginWithEmail:(NSString *)email password:(NSString *)password complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark -  重置邮箱密码
/**
 重置邮箱密码 PUT HTTP BASIC 认证
 资源路径：/v3/email/password/reset
 @param email 路径参数
 @param oldPassword 旧密码（大写形式）,使用SHA256对原始密码进行哈希
 @param newPassword 新密码（大写形式）使用SHA256对原始密码进行哈希
 @param complete <#complete description#>
 */
- (void)ahhhhresetPassWordWithEmail:(NSString *)email oldPassword:(NSString *)oldPassword newPassword:(NSString *)newPassword complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark -  找回邮箱密码
/**
 找回邮箱密码,调用此接口需要找回密码短信验证码权限 PUT HTTP BASIC 认证
 /v3/email/password/retrieve
 @param email <#phone description#>
 @param password 新密码（大写形式）使用SHA256对原始密码进行哈希
 @param complete <#complete description#>
 */
- (void)ahhhhretrivePasswordWithEmail:(NSString *)email password:(NSString *)password complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark -  iOS登录
/**
 iOS登录 POST HTTP BASIC 认证
 如果用户尚未注册，则登陆时将自动注册并绑定IOS标识Id
 此登陆操作永不失败，如果服务器发现用户尚未绑定IOS标识Id，则进行绑定并返回相关信息，否则直接返回已存在的信息
 资源路径：/v3/ios/login
 
 @param identityId 非空，为防止敏感问题，其值为MD5(用户的AppleId)
 @param visitorId 非必需项，如果客户端需要将已存在的游客用户转化为IOS注册用户，则传此值
 @param complete <#complete description#>
 */
- (void)ahhhhloginWithiOS:(NSString *)identityId visitorId:(NSString *)visitorId complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

#pragma mark- test
//产品版本管理服务
//http://version.api.goforandroid.com/api/v3/product/versions?app_key=${app_key}&device=${device}&timestamp=${timestamp}
- (void)checkAppVersionComplete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

//http://version.api.goforandroid.com/api/v1/product/versions?product_id=1016&version_number=20&channel=200&country=CN&lang=zh
- (void)checkAppVersionWithProductId:(NSString *)product_id versionNumber:(NSString *)version_number channel:(NSString *)channel country:(NSString *)country lang:(NSString *)lan complete:(AhhhhGMAccountCenterApiCompleteBlock)complete;

@end
