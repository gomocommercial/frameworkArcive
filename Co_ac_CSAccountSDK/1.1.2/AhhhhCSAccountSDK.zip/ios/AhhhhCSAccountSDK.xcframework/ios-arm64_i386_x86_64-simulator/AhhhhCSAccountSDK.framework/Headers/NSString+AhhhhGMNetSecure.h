//
//  NSString+AhhhhGMNetSecure.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (AhhhhGMNetSecure)
NSData * ahhhhcsAccountHmacForKeyAndData(NSString *key, NSString *data);

//- (NSString *)SHA256;

- (NSString *)ahhhhcsAcountSha256;

- (NSString *)ahhhhcsAccountSha256AndUpperCase;

- (NSString *)ahhhhcsAccountBase64EncodedString:(NSString *)string;

- (NSString *)ahhhhcsAccountBase64DecodedString:(NSString *)string;

- (NSString *)ahhhhcsAccountsafeUrlBase64Encode:(NSString *)str;

- (NSString *)ahhhhcsAccountSafeUrlBase64Decode:(NSString *)safeUrlbase64Str;

+ (NSString *)ahhhhcsAccountHmac:(NSString *)plaintext withKey:(NSString *)key;

+ (NSString *)ahhhhcsAccountHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

@end

NS_ASSUME_NONNULL_END
