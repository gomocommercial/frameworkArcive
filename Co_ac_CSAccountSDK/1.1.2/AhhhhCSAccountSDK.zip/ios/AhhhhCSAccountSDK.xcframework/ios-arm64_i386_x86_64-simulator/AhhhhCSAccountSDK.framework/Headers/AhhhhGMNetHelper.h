//
//  AhhhhGMNetHelper.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLRequestSerialization.h>
#import <AFNetworking/AFURLResponseSerialization.h>
#import "AhhhhGMNetHTTPResponse.h"
#import "AhhhhGMRequest.h"
#import "AhhhhGMHttpSesstionManager.h"
NS_ASSUME_NONNULL_BEGIN

typedef void (^AhhhhGMAccountHTTPResponseSucceedHandler)(AhhhhGMNetHTTPResponse *response);

@interface AhhhhGMNetHelper : NSObject

@property (nonatomic, strong) AhhhhGMHttpSesstionManager *httpManager;

- (void)startAsyncWithRequest:(AhhhhGMRequest *)request finish:(AhhhhGMAccountHTTPResponseSucceedHandler)finish;

@end


NS_ASSUME_NONNULL_END
