//
//  AhhhhGMNetHTTPResponse.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

#import "AhhhhGMNetError.h"

typedef NS_ENUM(NSInteger , AhhhhGMHttpStatus) {
    AhhhhGMHttpStatusFail = -1,
    AhhhhGMHttpStatusSuccess = 0,
    AhhhhGMHttpStatusInvalidSign = -100,//无效的签名
};

@interface AhhhhGMNetHTTPResponse : NSObject
@property (nonatomic) AhhhhGMHttpStatus status;


/**
 http 的返回码
 */
@property (nonatomic) NSInteger statusCode;
@property (nonatomic, strong) AhhhhGMNetError *error;
@property (nonatomic, copy) NSDictionary *bodyData;
@property (nonatomic, copy) NSString *bodyString;
@property (nonatomic, strong) NSURLResponse *response;


/**
 资源路径
 */
@property (nonatomic, copy) NSString *path;

@property (nonatomic, copy) NSDictionary *httpHeader;


- (BOOL)isSuccess;

- (NSString *)errorLog;

- (NSString *)errorTips;


@end
