//
//  NSString+FSLPGMNetSecure.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (FSLPGMNetSecure)
NSData * fSLPcsAccountHmacForKeyAndData(NSString *key, NSString *data);

//- (NSString *)SHA256;

- (NSString *)fSLPcsAcountSha256;

- (NSString *)fSLPcsAccountSha256AndUpperCase;

- (NSString *)fSLPcsAccountBase64EncodedString:(NSString *)string;

- (NSString *)fSLPcsAccountBase64DecodedString:(NSString *)string;

- (NSString *)fSLPcsAccountsafeUrlBase64Encode:(NSString *)str;

- (NSString *)fSLPcsAccountSafeUrlBase64Decode:(NSString *)safeUrlbase64Str;

+ (NSString *)fSLPcsAccountHmac:(NSString *)plaintext withKey:(NSString *)key;

+ (NSString *)fSLPcsAccountHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

@end

NS_ASSUME_NONNULL_END
