//
//  FSLPGMNetDeviceInfo.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSLPGMNetDeviceInfo : NSObject

+ (NSDictionary *)device;

+ (NSDictionary *)deviceWithDid:(NSString *)did;

+ (NSDictionary *)deviceForNetworkMonitor;

+ (NSString *)getBundleId;

+ (NSString *)getDeviceUUID;

//获取对应的国家电话区码
+ (NSString *)getCurrentMoblileCountryCode;

+ (NSString *)getDeviceCountryName;

+ (NSString *)getDeviceLangName;
+ (NSString *)getAppVersion;

+ (NSString *)getAppBuildVersion;

+ (NSString *)getiOSVersion;

+ (NSString *)getCPUType;

+ (NSString *)getPackageName;

+ (NSString *)getIPAddress;

+ (NSArray *)getDNSAddresses;

+ (NSString*)getIPAddressByHostName:(NSString*)strHostName;

+ (BOOL)getIsIpad;
@end

NS_ASSUME_NONNULL_END
