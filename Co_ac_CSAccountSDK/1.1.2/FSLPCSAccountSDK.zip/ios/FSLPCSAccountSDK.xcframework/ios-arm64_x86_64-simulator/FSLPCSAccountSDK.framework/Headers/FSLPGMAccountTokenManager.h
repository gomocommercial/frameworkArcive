//
//  FSLPGMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FSLPGMAccountTokenInfo.h"
#import "FSLPGMAccountCenterApiManager.h"

typedef NS_ENUM(NSInteger,FSLPGMTokenStateType) {
    FSLPGMTokenNormal,                  //token正常，无需刷新
    FSLPGMTokenRefreshed,               //已刷新token
};
typedef void (^FSLPGMTokenRefreshStateBlock)(FSLPGMTokenStateType tokenState);
@interface FSLPGMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) FSLPGMAccountTokenInfo *tokenInfo;

+ (FSLPGMAccountTokenManager *)sharedManager;

- (void)fSLPupdateTokenInfo:(FSLPGMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)fSLPcleanTokenInfo;


/**
 *判断token是否过期去刷新token,应用启动时应该显式的调用
 *freshStateBlock刷新状态回调
 */
- (void)fSLPrefreshTokenIfNeed:(FSLPGMAccountCenterApiCompleteBlock)complete RefreshState:(FSLPGMTokenRefreshStateBlock)freshStateBlock;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)fSLPneedRefreshToken;

@end
