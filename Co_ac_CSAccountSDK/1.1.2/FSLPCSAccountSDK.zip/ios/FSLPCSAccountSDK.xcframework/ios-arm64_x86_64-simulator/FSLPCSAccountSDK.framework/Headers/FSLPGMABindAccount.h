//
// Created by Kevin Guo on 2022/6/17.
//

#import <Foundation/Foundation.h>


@interface FSLPGMABindAccount : NSObject

@property (nonatomic, copy) NSString *registerType;
@property (nonatomic, copy) NSString *identityId;

+(instancetype) modelWithJSON:(NSDictionary *) json;

-(NSDictionary *) modelToJSONObject;

@end