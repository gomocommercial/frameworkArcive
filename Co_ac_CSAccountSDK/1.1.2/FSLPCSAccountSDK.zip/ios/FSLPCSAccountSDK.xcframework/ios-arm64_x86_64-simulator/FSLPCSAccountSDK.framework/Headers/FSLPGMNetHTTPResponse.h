//
//  FSLPGMNetHTTPResponse.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

#import "FSLPGMNetError.h"

typedef NS_ENUM(NSInteger , FSLPGMHttpStatus) {
    FSLPGMHttpStatusFail = -1,
    FSLPGMHttpStatusSuccess = 0,
    FSLPGMHttpStatusInvalidSign = -100,//无效的签名
};

@interface FSLPGMNetHTTPResponse : NSObject
@property (nonatomic) FSLPGMHttpStatus status;


/**
 http 的返回码
 */
@property (nonatomic) NSInteger statusCode;
@property (nonatomic, strong) FSLPGMNetError *error;
@property (nonatomic, copy) NSDictionary *bodyData;
@property (nonatomic, copy) NSString *bodyString;
@property (nonatomic, strong) NSURLResponse *response;


/**
 资源路径
 */
@property (nonatomic, copy) NSString *path;

@property (nonatomic, copy) NSDictionary *httpHeader;


- (BOOL)isSuccess;

- (NSString *)errorLog;

- (NSString *)errorTips;


@end
