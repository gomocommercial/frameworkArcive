//
//  FSLPGMNetHelper.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLRequestSerialization.h>
#import <AFNetworking/AFURLResponseSerialization.h>
#import "FSLPGMNetHTTPResponse.h"
#import "FSLPGMRequest.h"
#import "FSLPGMHttpSesstionManager.h"
NS_ASSUME_NONNULL_BEGIN

typedef void (^FSLPGMAccountHTTPResponseSucceedHandler)(FSLPGMNetHTTPResponse *response);

@interface FSLPGMNetHelper : NSObject

@property (nonatomic, strong) FSLPGMHttpSesstionManager *httpManager;

- (void)startAsyncWithRequest:(FSLPGMRequest *)request finish:(FSLPGMAccountHTTPResponseSucceedHandler)finish;

@end


NS_ASSUME_NONNULL_END
