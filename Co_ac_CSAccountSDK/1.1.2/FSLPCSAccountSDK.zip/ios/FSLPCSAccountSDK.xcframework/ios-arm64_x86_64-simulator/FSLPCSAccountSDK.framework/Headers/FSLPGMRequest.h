//
//  FSLPGMRequest.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

@class FSLPGMURL;

typedef NS_ENUM(NSUInteger, FSLPGMRequestActionType) {
    FSLPGMRequestActionTypeAsync,      // 异步请求
    FSLPGMRequestActionTypeSync        // 同步请求
};

typedef NS_ENUM (NSInteger, FSLPGMHttpAuthenticationType) {
    FSLPGMHttpAuthenticationTypeNone = 0,
    FSLPGMHttpAuthenticationTypeBasic,//HTTP BASIC认证
    FSLPGMHttpAuthenticationTypeToken,//账户系统的Access Token认证
    FSLPGMHttpAuthenticationTypeTransactionToken,//交易token
    FSLPGMHttpAuthenticationTypeTransactionAccessToken//交易access token
};

typedef NS_ENUM (NSInteger, FSLPGMHttpMethod) {
    FSLPGMHttpMethodGET = 0,
//    GWSHttpMethodGETLastModified,//Conditional Get
//    GWSHttpMethodGETETag,//Conditional Get
    FSLPGMHttpMethodPOST,
    FSLPGMHttpMethodPUT,
    FSLPGMHttpMethodDELETE,
    FSLPGMHttpMethodUPDATE,
};

@interface FSLPGMRequest : NSObject

@property (nonatomic, readonly) FSLPGMURL *URL;

@property (nonatomic,copy) NSString *originQueryString; //最原始的请求URL,在搜索请求中，非英文，需要UTF8转码，而使用URL生成签名时，又不需要对非英文转码，所以需要保留最原始的URL请求字符串

@property (nonatomic, assign) FSLPGMHttpAuthenticationType authenticationType;

@property (nonatomic, assign) FSLPGMHttpMethod method;

@property (nonatomic, copy) NSDictionary *queries;//参数

@property (nonatomic, strong, readonly) NSMutableDictionary *additionalQueryDictionary;//增加参数

@property (nonatomic, copy) NSString *XSignatureKey;

@property (nonatomic, copy) NSString *clientID;

@property (nonatomic, copy) NSString *clientSecret;

@property (nonatomic, copy) NSString *access_token;

@property (nonatomic, copy) NSString *account_id;

@property (nonatomic, assign) BOOL isForConfigure; //是否为配置项管理后台的请求，因为他们的头部签名定义不一样
@property (nonatomic, copy) NSString *hostHeader;

@property (nonatomic) BOOL needDeviceForGet;

/**
 * 账号系统的加密头
 */
@property (nonatomic) BOOL needCrypto;

/**
 * 账号系统自定义did
 */
@property (nonatomic, copy) NSString *customize_did;

/**
 * ColorCall业务逻辑加密头
 */
@property (nonatomic) BOOL needServerEncrypt;

/// 请求类型(默认异步请求)
@property (nonatomic, assign) FSLPGMRequestActionType requestActionType;

@property (nonatomic) BOOL isForShortVideo;

/**
 * 短视频位置信息，专门为短视频提供Phead数据的
 */
@property (nonatomic, copy) NSString *locationForVideo;

/**
 用于(glive-api)
 */
@property (nonatomic) BOOL needXUserIdHeader;

- (instancetype)initWithBaseUrl:(NSString *)url domain:(NSString *)domain;

/**
 参数会加到additionalQueryDictionary
 */
- (void)setQueryValue:(id)value forKey:(NSString *)key;

/**（请求方法）用于X-Signature签名 **/
- (NSString *)methodName;
/*（请求路径） 用于X-Signature签名 **/
- (NSString *)requestUri;
/*（查询字符串）用于X-Signature签名 **/
- (NSString *)queryString;
/*（请求体）用于X-Signature签名 **/
- (NSString *)payload;


@end
