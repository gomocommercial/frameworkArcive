//
//  Constants.h
//  LVBIMDemo
//
//  Created by realingzhou on 16/8/22.
//  Copyright © 2016年 tencent. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


extern NSString * kAccountCenterDomain;
extern NSString * kAccountCenterDomainHost;
extern NSString * KHttpBasicAuthorizationUserName;
extern NSString * kHttpBasicAuthorizationUserValue;
extern NSString * kAccountCenterApiXSignatureSignatureKey;
extern NSString * kEnvtype;


@interface WDGMAccountConfigs:NSObject

+ (void)wDsetConfigIsTest:(BOOL) isTest
              client_id:(NSString *) client_id
          client_secret:(NSString *) client_secret
          signature_key:(NSString *) signature_key
         des_secret_key:(NSString *) des_secret_key;
    
//useIP 使用IP替代域名
+(void)wDsetConfigIsTest:(BOOL)isTest
                   client_id:(NSString *)client_id
               client_secret:(NSString *)client_secret
               signature_key:(NSString *)signature_key
              des_secret_key:(NSString *)des_secret_key
                       useIP:(BOOL) useIP;
    
+(void) wDsetDebugLog:(BOOL) debugLog;
@end
