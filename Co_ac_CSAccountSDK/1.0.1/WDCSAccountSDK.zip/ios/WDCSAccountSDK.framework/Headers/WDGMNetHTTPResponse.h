//
//  WDGMNetHTTPResponse.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

#import "WDGMNetError.h"

typedef NS_ENUM(NSInteger , WDGMHttpStatus) {
    WDGMHttpStatusFail = -1,
    WDGMHttpStatusSuccess = 0,
    WDGMHttpStatusInvalidSign = -100,//无效的签名
};

@interface WDGMNetHTTPResponse : NSObject
@property (nonatomic) WDGMHttpStatus status;


/**
 http 的返回码
 */
@property (nonatomic) NSInteger statusCode;
@property (nonatomic, strong) WDGMNetError *error;
@property (nonatomic, copy) NSDictionary *bodyData;
@property (nonatomic, copy) NSString *bodyString;
@property (nonatomic, strong) NSURLResponse *response;


/**
 资源路径
 */
@property (nonatomic, copy) NSString *path;

@property (nonatomic, copy) NSDictionary *httpHeader;


- (BOOL)isSuccess;

- (NSString *)errorLog;

- (NSString *)errorTips;


@end
