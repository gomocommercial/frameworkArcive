//
//  WDGMNetHelper.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLRequestSerialization.h>
#import <AFNetworking/AFURLResponseSerialization.h>
#import "WDGMNetHTTPResponse.h"
#import "WDGMRequest.h"
#import "WDGMHttpSesstionManager.h"
NS_ASSUME_NONNULL_BEGIN

typedef void (^WDGMAccountHTTPResponseSucceedHandler)(WDGMNetHTTPResponse *response);

@interface WDGMNetHelper : NSObject

@property (nonatomic, strong) WDGMHttpSesstionManager *httpManager;

- (void)startAsyncWithRequest:(WDGMRequest *)request finish:(WDGMAccountHTTPResponseSucceedHandler)finish;

@end


NS_ASSUME_NONNULL_END
