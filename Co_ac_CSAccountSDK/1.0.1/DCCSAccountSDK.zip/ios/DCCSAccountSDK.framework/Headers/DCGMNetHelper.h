//
//  DCGMNetHelper.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLRequestSerialization.h>
#import <AFNetworking/AFURLResponseSerialization.h>
#import "DCGMNetHTTPResponse.h"
#import "DCGMRequest.h"
#import "DCGMHttpSesstionManager.h"
NS_ASSUME_NONNULL_BEGIN

typedef void (^DCGMAccountHTTPResponseSucceedHandler)(DCGMNetHTTPResponse *response);

@interface DCGMNetHelper : NSObject

@property (nonatomic, strong) DCGMHttpSesstionManager *httpManager;

- (void)startAsyncWithRequest:(DCGMRequest *)request finish:(DCGMAccountHTTPResponseSucceedHandler)finish;

@end


NS_ASSUME_NONNULL_END
