//
//  DCGMNetDESUtlis.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/4.
//

#import <Foundation/Foundation.h>



@interface DCGMNetDESUtlis : NSObject


+ (NSData *)encryptUseDES2:(NSString *)plainText key:(NSString *)key keyBase64:(BOOL)keyNeedBase64;

+ (NSString *)decryptUseDESString:(NSString *)cipherText key:(NSString *)key;

+ (NSString *)decryptUseDES:(NSData *)cipherData key:(NSString *)key keyNeedBase64:(BOOL)keyNeedBase64;

+ (NSString *)encryptWithText:(NSString *)sText forKey:(NSString *)key;

+ (NSString *)decryptWithText:(NSData *)sText forKey:(NSString *)key;
@end
