//
//  DCGMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DCGMAccountTokenInfo.h"
#import "DCGMAccountCenterApiManager.h"

typedef NS_ENUM(NSInteger,DCGMTokenStateType) {
    DCGMTokenNormal,                  //token正常，无需刷新
    DCGMTokenRefreshed,               //已刷新token
};
typedef void (^DCGMTokenRefreshStateBlock)(DCGMTokenStateType tokenState);
@interface DCGMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) DCGMAccountTokenInfo *tokenInfo;

+ (DCGMAccountTokenManager *)sharedManager;

- (void)dCupdateTokenInfo:(DCGMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)dCcleanTokenInfo;


/**
 *判断token是否过期去刷新token,应用启动时应该显式的调用
 *freshStateBlock刷新状态回调
 */
- (void)dCrefreshTokenIfNeed:(DCGMAccountCenterApiCompleteBlock)complete RefreshState:(DCGMTokenRefreshStateBlock)freshStateBlock;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)dCneedRefreshToken;

@end
