//
//  Co_ac_GMNetHelper.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLRequestSerialization.h>
#import <AFNetworking/AFURLResponseSerialization.h>
#import "Co_ac_GMNetHTTPResponse.h"
#import "Co_ac_GMRequest.h"
#import "Co_ac_GMHttpSesstionManager.h"
NS_ASSUME_NONNULL_BEGIN

typedef void (^Co_ac_GMAccountHTTPResponseSucceedHandler)(Co_ac_GMNetHTTPResponse *response);

@interface Co_ac_GMNetHelper : NSObject

@property (nonatomic, strong) Co_ac_GMHttpSesstionManager *httpManager;

- (void)startAsyncWithRequest:(Co_ac_GMRequest *)request finish:(Co_ac_GMAccountHTTPResponseSucceedHandler)finish;

@end


NS_ASSUME_NONNULL_END
