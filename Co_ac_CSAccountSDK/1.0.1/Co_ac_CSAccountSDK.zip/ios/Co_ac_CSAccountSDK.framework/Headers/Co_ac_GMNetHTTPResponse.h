//
//  Co_ac_GMNetHTTPResponse.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

#import "Co_ac_GMNetError.h"

typedef NS_ENUM(NSInteger , Co_ac_GMHttpStatus) {
    Co_ac_GMHttpStatusFail = -1,
    Co_ac_GMHttpStatusSuccess = 0,
    Co_ac_GMHttpStatusInvalidSign = -100,//无效的签名
};

@interface Co_ac_GMNetHTTPResponse : NSObject
@property (nonatomic) Co_ac_GMHttpStatus status;


/**
 http 的返回码
 */
@property (nonatomic) NSInteger statusCode;
@property (nonatomic, strong) Co_ac_GMNetError *error;
@property (nonatomic, copy) NSDictionary *bodyData;
@property (nonatomic, copy) NSString *bodyString;
@property (nonatomic, strong) NSURLResponse *response;


/**
 资源路径
 */
@property (nonatomic, copy) NSString *path;

@property (nonatomic, copy) NSDictionary *httpHeader;


- (BOOL)isSuccess;

- (NSString *)errorLog;

- (NSString *)errorTips;


@end
