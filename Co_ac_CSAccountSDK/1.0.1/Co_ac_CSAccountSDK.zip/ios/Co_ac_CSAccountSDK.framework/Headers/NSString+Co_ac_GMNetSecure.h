//
//  NSString+Co_ac_GMNetSecure.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Co_ac_GMNetSecure)
NSData * hmacForKeyAndData(NSString *key, NSString *data);

//- (NSString *)SHA256;

- (NSString *)sha256;

- (NSString *)sha256AndUpperCase;

- (NSString *)base64EncodedString:(NSString *)string;

- (NSString *)base64DecodedString:(NSString *)string;

- (NSString *)safeUrlBase64Encode:(NSString *)str;

- (NSString *)safeUrlBase64Decode:(NSString *)safeUrlbase64Str;

+ (NSString *)hmac:(NSString *)plaintext withKey:(NSString *)key;

+ (NSString *)hmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

@end

NS_ASSUME_NONNULL_END
