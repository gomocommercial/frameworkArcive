//
//  LDGMNetHelper.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLRequestSerialization.h>
#import <AFNetworking/AFURLResponseSerialization.h>
#import "LDGMNetHTTPResponse.h"
#import "LDGMRequest.h"
#import "LDGMHttpSesstionManager.h"
NS_ASSUME_NONNULL_BEGIN

typedef void (^LDGMAccountHTTPResponseSucceedHandler)(LDGMNetHTTPResponse *response);

@interface LDGMNetHelper : NSObject

@property (nonatomic, strong) LDGMHttpSesstionManager *httpManager;

- (void)startAsyncWithRequest:(LDGMRequest *)request finish:(LDGMAccountHTTPResponseSucceedHandler)finish;

@end


NS_ASSUME_NONNULL_END
