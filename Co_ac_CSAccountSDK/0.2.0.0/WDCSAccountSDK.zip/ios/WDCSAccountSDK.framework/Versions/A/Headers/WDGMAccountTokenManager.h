//
//  WDGMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WDGMAccountTokenInfo.h"
#import "WDGMAccountCenterApiManager.h"

@interface WDGMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) WDGMAccountTokenInfo *tokenInfo;

+ (WDGMAccountTokenManager *)sharedManager;

- (void)wDupdateTokenInfo:(WDGMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)wDcleanTokenInfo;


/**
 判断token是否过期去刷新token,应用启动时应该显式的调用
 */
- (void)wDrefreshTokenIfNeed:(WDGMAccountCenterApiCompleteBlock)complete;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)wDneedRefreshToken;

@end
