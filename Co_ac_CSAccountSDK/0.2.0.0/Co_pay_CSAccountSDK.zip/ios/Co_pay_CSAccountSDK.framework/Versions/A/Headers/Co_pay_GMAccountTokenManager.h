//
//  Co_pay_GMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Co_pay_GMAccountTokenInfo.h"
#import "Co_pay_GMAccountCenterApiManager.h"

@interface Co_pay_GMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) Co_pay_GMAccountTokenInfo *tokenInfo;

+ (Co_pay_GMAccountTokenManager *)sharedManager;

- (void)co_pay_updateTokenInfo:(Co_pay_GMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)co_pay_cleanTokenInfo;


/**
 判断token是否过期去刷新token,应用启动时应该显式的调用
 */
- (void)co_pay_refreshTokenIfNeed:(Co_pay_GMAccountCenterApiCompleteBlock)complete;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)co_pay_needRefreshToken;

@end
