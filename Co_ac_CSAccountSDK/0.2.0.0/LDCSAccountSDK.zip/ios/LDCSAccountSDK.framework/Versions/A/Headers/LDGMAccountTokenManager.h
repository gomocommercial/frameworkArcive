//
//  LDGMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LDGMAccountTokenInfo.h"
#import "LDGMAccountCenterApiManager.h"

@interface LDGMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) LDGMAccountTokenInfo *tokenInfo;

+ (LDGMAccountTokenManager *)sharedManager;

- (void)lDupdateTokenInfo:(LDGMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)lDcleanTokenInfo;


/**
 判断token是否过期去刷新token,应用启动时应该显式的调用
 */
- (void)lDrefreshTokenIfNeed:(LDGMAccountCenterApiCompleteBlock)complete;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)lDneedRefreshToken;

@end
