//
//  Co_da_GMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Co_da_GMAccountTokenInfo.h"
#import "Co_da_GMAccountCenterApiManager.h"

@interface Co_da_GMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) Co_da_GMAccountTokenInfo *tokenInfo;

+ (Co_da_GMAccountTokenManager *)sharedManager;

- (void)co_da_updateTokenInfo:(Co_da_GMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)co_da_cleanTokenInfo;


/**
 判断token是否过期去刷新token,应用启动时应该显式的调用
 */
- (void)co_da_refreshTokenIfNeed:(Co_da_GMAccountCenterApiCompleteBlock)complete;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)co_da_needRefreshToken;

@end
