//
//  WDGMURL.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>


@class WDGMRequest;

@interface WDGMURL : NSObject

@property (nonatomic, copy, readonly) NSString *base;

/**
 * 主要用于签名
 */
@property (nonatomic, copy, readonly) NSString *domain;

- (instancetype)initWithUrl:(NSString *)url domain:(NSString *)domain;

@property (nonatomic, weak) WDGMRequest *request;

/**
 * 生成请求体参数
 */
- (NSDictionary *)buildPayload;

/**
 * 生成查询参数集合
 */
- (NSDictionary *)buildQueries;

/**
 * 生成查询参数字符串 ie:a=a&b=b
 */
- (NSString *)buildQueryString:(BOOL) encodeUTF8;

/**
 * 生成完整地址，域名+资源路径+查询参数
 */
- (NSString *)buildFullUrlString;


/**
 增加查询参数

 @param key <#key description#>
 @param value <#value description#>
 */
- (void)addQueriesWithKey:(NSString *)key value:(id)value;

- (void)addQueriesWithDic:(NSDictionary *)dic;

//- (void)parseQueryStr:(NSString *)query;

@end

