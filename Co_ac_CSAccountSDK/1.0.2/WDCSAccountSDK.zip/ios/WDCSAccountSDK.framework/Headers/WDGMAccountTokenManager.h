//
//  WDGMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WDGMAccountTokenInfo.h"
#import "WDGMAccountCenterApiManager.h"

typedef NS_ENUM(NSInteger,WDGMTokenStateType) {
    WDGMTokenNormal,                  //token正常，无需刷新
    WDGMTokenRefreshed,               //已刷新token
};
typedef void (^WDGMTokenRefreshStateBlock)(WDGMTokenStateType tokenState);
@interface WDGMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) WDGMAccountTokenInfo *tokenInfo;

+ (WDGMAccountTokenManager *)sharedManager;

- (void)wDupdateTokenInfo:(WDGMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)wDcleanTokenInfo;


/**
 *判断token是否过期去刷新token,应用启动时应该显式的调用
 *freshStateBlock刷新状态回调
 */
- (void)wDrefreshTokenIfNeed:(WDGMAccountCenterApiCompleteBlock)complete RefreshState:(WDGMTokenRefreshStateBlock)freshStateBlock;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)wDneedRefreshToken;

@end
