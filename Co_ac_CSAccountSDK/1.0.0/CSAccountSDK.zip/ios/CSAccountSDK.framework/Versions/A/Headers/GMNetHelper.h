//
//  GMNetHelper.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "GMNetHTTPResponse.h"
#import "GMRequest.h"
#import "GMHttpSesstionManager.h"
NS_ASSUME_NONNULL_BEGIN

typedef void (^GMAccountHTTPResponseSucceedHandler)(GMNetHTTPResponse *response);

@interface GMNetHelper : NSObject

@property (nonatomic, strong) GMHttpSesstionManager *httpManager;

- (void)startAsyncWithRequest:(GMRequest *)request finish:(GMAccountHTTPResponseSucceedHandler)finish;

@end


NS_ASSUME_NONNULL_END
