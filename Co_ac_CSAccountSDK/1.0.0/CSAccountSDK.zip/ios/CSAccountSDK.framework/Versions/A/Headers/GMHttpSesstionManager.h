//
//  GMHttpSesstionManager.h
//  CSAccountSDK
//
//  Created by zhangxin on 2019/11/6.
//

#import "AFHTTPSessionManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface GMHttpSesstionManager : AFHTTPSessionManager
#pragma mark - customer method
- (NSURLSessionDataTask *)GM_POST:(NSString *)URLString
                    parameters:(id __nullable)parameters
                      progress:(void (^)(NSProgress * _Nonnull))uploadProgress
                       success:(void (^)(NSURLSessionDataTask * _Nonnull, id _Nullable))success
                       failure:(void (^)(NSURLSessionDataTask * _Nullable, NSError * _Nonnull))failure;
- (NSURLSessionDataTask *)GM_GET:(NSString *)URLString
                   parameters:(id __nullable)parameters
                     progress:(void (^)(NSProgress * _Nonnull))downloadProgress
                      success:(void (^)(NSURLSessionDataTask * _Nonnull, id _Nullable))success
                         failure:(void (^)(NSURLSessionDataTask * _Nullable, NSError * _Nonnull))failure;

- (NSURLSessionDataTask *)GM_PUT:(NSString *)URLString
                   parameters:(id __nullable)parameters
                      success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                         failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;
- (NSURLSessionDataTask *)GM_DELETE:(NSString *)URLString
                      parameters:(id __nullable)parameters
                         success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                            failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;
@end

NS_ASSUME_NONNULL_END
