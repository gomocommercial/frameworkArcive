//
//  Co_ac_GMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Co_ac_GMAccountTokenInfo.h"
#import "Co_ac_GMAccountCenterApiManager.h"

@interface Co_ac_GMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) Co_ac_GMAccountTokenInfo *tokenInfo;

+ (Co_ac_GMAccountTokenManager *)sharedManager;

- (void)co_ac_updateTokenInfo:(Co_ac_GMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)co_ac_cleanTokenInfo;


/**
 判断token是否过期去刷新token,应用启动时应该显式的调用
 */
- (void)co_ac_refreshTokenIfNeed:(Co_ac_GMAccountCenterApiCompleteBlock)complete;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)co_ac_needRefreshToken;

@end
