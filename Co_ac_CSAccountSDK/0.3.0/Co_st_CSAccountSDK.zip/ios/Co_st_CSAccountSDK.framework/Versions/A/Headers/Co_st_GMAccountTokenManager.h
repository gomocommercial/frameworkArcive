//
//  Co_st_GMAccountTokenManager.h
//  GLive
//
//  Created by Gordon Su on 17/4/12.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Co_st_GMAccountTokenInfo.h"
#import "Co_st_GMAccountCenterApiManager.h"

@interface Co_st_GMAccountTokenManager : NSObject

@property (nonatomic, strong, readonly) Co_st_GMAccountTokenInfo *tokenInfo;

+ (Co_st_GMAccountTokenManager *)sharedManager;

- (void)co_st_updateTokenInfo:(Co_st_GMAccountTokenInfo *)token;


/**
 清除token信息，包括本地的
 */
- (void)co_st_cleanTokenInfo;


/**
 判断token是否过期去刷新token,应用启动时应该显式的调用
 */
- (void)co_st_refreshTokenIfNeed:(Co_st_GMAccountCenterApiCompleteBlock)complete;
//
///**
// 强制刷新token
// */
//- (void)refreshToken;

- (BOOL)co_st_needRefreshToken;

@end
