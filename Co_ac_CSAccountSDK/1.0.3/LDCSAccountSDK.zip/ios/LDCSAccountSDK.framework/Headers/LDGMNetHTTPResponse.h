//
//  LDGMNetHTTPResponse.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

#import "LDGMNetError.h"

typedef NS_ENUM(NSInteger , LDGMHttpStatus) {
    LDGMHttpStatusFail = -1,
    LDGMHttpStatusSuccess = 0,
    LDGMHttpStatusInvalidSign = -100,//无效的签名
};

@interface LDGMNetHTTPResponse : NSObject
@property (nonatomic) LDGMHttpStatus status;


/**
 http 的返回码
 */
@property (nonatomic) NSInteger statusCode;
@property (nonatomic, strong) LDGMNetError *error;
@property (nonatomic, copy) NSDictionary *bodyData;
@property (nonatomic, copy) NSString *bodyString;
@property (nonatomic, strong) NSURLResponse *response;


/**
 资源路径
 */
@property (nonatomic, copy) NSString *path;

@property (nonatomic, copy) NSDictionary *httpHeader;


- (BOOL)isSuccess;

- (NSString *)errorLog;

- (NSString *)errorTips;


@end
