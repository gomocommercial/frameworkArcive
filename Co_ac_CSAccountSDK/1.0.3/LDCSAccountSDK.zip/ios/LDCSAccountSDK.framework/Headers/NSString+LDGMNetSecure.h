//
//  NSString+LDGMNetSecure.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (LDGMNetSecure)
NSData * lDcsAccountHmacForKeyAndData(NSString *key, NSString *data);

//- (NSString *)SHA256;

- (NSString *)lDcsAcountSha256;

- (NSString *)lDcsAccountSha256AndUpperCase;

- (NSString *)lDcsAccountBase64EncodedString:(NSString *)string;

- (NSString *)lDcsAccountBase64DecodedString:(NSString *)string;

- (NSString *)lDcsAccountsafeUrlBase64Encode:(NSString *)str;

- (NSString *)lDcsAccountSafeUrlBase64Decode:(NSString *)safeUrlbase64Str;

+ (NSString *)lDcsAccountHmac:(NSString *)plaintext withKey:(NSString *)key;

+ (NSString *)lDcsAccountHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

@end

NS_ASSUME_NONNULL_END
