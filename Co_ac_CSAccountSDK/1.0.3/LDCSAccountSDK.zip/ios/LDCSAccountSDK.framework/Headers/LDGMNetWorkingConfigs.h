//
//  LDGMNetWorkingConfigs.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LDGMNetWorkingConfigs : NSObject
+ (instancetype)sharedInstance;

-(NSString *)getColorCallDESKey;
-(NSString *) getDesKy;
-(BOOL)getDebugLog;

- (void) setDebugLog:(BOOL) debugLog;

- (void)setEnvtType:(BOOL)isTest;

- (void)setDesKey:(NSString *) desKey;
- (void)setColorCallDESKey:(NSString *)desKey;

- (NSString *)getEnvtType;

- (void)setDesBytesCapacity:(long long)capacity;

- (long long)getDesBytesCapacity;

- (void)setTimeoutIntervalForRequest:(NSTimeInterval)timeInterval;

- (NSTimeInterval)getTimeoutIntervalForRequest;
@end

NS_ASSUME_NONNULL_END
