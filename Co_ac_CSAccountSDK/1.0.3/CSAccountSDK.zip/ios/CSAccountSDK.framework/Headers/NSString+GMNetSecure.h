//
//  NSString+GMNetSecure.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (GMNetSecure)
NSData * csAccountHmacForKeyAndData(NSString *key, NSString *data);

//- (NSString *)SHA256;

- (NSString *)csAcountSha256;

- (NSString *)csAccountSha256AndUpperCase;

- (NSString *)csAccountBase64EncodedString:(NSString *)string;

- (NSString *)csAccountBase64DecodedString:(NSString *)string;

- (NSString *)csAccountsafeUrlBase64Encode:(NSString *)str;

- (NSString *)csAccountSafeUrlBase64Decode:(NSString *)safeUrlbase64Str;

+ (NSString *)csAccountHmac:(NSString *)plaintext withKey:(NSString *)key;

+ (NSString *)csAccountHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

@end

NS_ASSUME_NONNULL_END
