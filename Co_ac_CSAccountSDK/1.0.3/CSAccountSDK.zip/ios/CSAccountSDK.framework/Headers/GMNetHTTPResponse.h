//
//  GMNetHTTPResponse.h
//  AFNetworking
//
//  Created by zhangxin on 2019/11/1.
//

#import <Foundation/Foundation.h>

#import "GMNetError.h"

typedef NS_ENUM(NSInteger , GMHttpStatus) {
    GMHttpStatusFail = -1,
    GMHttpStatusSuccess = 0,
    GMHttpStatusInvalidSign = -100,//无效的签名
};

@interface GMNetHTTPResponse : NSObject
@property (nonatomic) GMHttpStatus status;


/**
 http 的返回码
 */
@property (nonatomic) NSInteger statusCode;
@property (nonatomic, strong) GMNetError *error;
@property (nonatomic, copy) NSDictionary *bodyData;
@property (nonatomic, copy) NSString *bodyString;
@property (nonatomic, strong) NSURLResponse *response;


/**
 资源路径
 */
@property (nonatomic, copy) NSString *path;

@property (nonatomic, copy) NSDictionary *httpHeader;


- (BOOL)isSuccess;

- (NSString *)errorLog;

- (NSString *)errorTips;


@end
