//
//  DCCSAdLoadGDTInterstitial.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/2.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <DCCSAdSDK/DCCSAdLoadInterstitial.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
#import "GDTUnifiedInterstitialAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadGDTInterstitial : DCCSAdLoadInterstitial<GDTUnifiedInterstitialAdDelegate,DCCSAdLoadProtocol>

@property(nonatomic, strong) GDTUnifiedInterstitialAd *ad;
- (void)dCloadData:(DCCSAdLoadCompleteBlock)csAdLoadCompleteBlock;

@end

NS_ASSUME_NONNULL_END
