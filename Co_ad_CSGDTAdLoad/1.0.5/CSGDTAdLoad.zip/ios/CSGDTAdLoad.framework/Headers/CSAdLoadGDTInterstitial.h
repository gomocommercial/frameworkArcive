//
//  CSAdLoadGDTInterstitial.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/2.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <CSAdSDK/CSAdLoadInterstitial.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>
#import "GDTUnifiedInterstitialAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadGDTInterstitial : CSAdLoadInterstitial<GDTUnifiedInterstitialAdDelegate,CSAdLoadProtocol>

@property(nonatomic, strong) GDTUnifiedInterstitialAd *ad;
- (void)loadData:(CSAdLoadCompleteBlock)csAdLoadCompleteBlock;

@end

NS_ASSUME_NONNULL_END
