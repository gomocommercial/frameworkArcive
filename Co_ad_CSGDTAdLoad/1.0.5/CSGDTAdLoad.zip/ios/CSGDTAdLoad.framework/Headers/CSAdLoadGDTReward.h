//
//  CSAdLoadGDTReward.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/3.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CSAdSDK/CSAdLoadReward.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>
#import "GDTRewardVideoAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadGDTReward : CSAdLoadReward<GDTRewardedVideoAdDelegate,CSAdLoadProtocol>

@property(nonatomic, strong) GDTRewardVideoAd *ad;
@property(nonatomic, assign) BOOL isVideoLoaded;

@end

NS_ASSUME_NONNULL_END
