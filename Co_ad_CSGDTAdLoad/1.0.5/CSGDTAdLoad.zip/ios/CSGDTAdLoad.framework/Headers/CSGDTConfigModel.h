//
//  CSBUConfigModel.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/10.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSGDTConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;
@property (nonatomic, copy) NSString *appID;
@property (nonatomic, assign) BOOL videoAutoPlaySwitch;// 设置视频是否在非 WiFi 网络自动播放
@property (nonatomic, assign) NSInteger sliderValue;// 如果需要设置视频最大时长，可以通过这个参数来进行设置

@property (nonatomic, assign) BOOL videoMuted;//设置激励视频是否静音

@end

NS_ASSUME_NONNULL_END
