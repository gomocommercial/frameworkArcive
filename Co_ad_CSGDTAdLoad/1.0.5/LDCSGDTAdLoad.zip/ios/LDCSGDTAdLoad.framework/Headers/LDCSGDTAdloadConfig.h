//
//  LDCSBUAdloadConfig.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/10/9.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LDCSGDTConfigModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LDCSGDTAdloadConfig : NSObject

@property (nonatomic, strong, readonly) NSMutableArray<LDCSGDTConfigModel *> *configs;

+ (instancetype)sharedInstance;

// MARK: - 插屏视频配置
/*
videoAutoPlaySwitch;// 设置视频是否在非 WiFi 网络自动播放
sliderValue;// 如果需要设置视频最大时长，可以通过这个参数来进行设置
*/
+ (void)setInterstitialVideoConfigWithMoudleId:(NSString *)modudleID videoAutoPlaySwitch:(BOOL)videoAutoPlaySwitch appID:(NSString *)appID maxVideoDurationSlider:(NSInteger)maxVideoDurationSlider; 

// MARK: - 激励视频展示配置 必须配置
/*
videoMuted;// 设置激励视频是否静音
*/
+ (void)setRewardConfigWithMoudleId:(NSString *)modudleID appID:(NSString *)appID videoMuted:(BOOL)videoMuted;


@end

NS_ASSUME_NONNULL_END
