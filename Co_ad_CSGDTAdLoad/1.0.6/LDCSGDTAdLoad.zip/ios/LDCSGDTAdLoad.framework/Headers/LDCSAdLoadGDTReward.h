//
//  LDCSAdLoadGDTReward.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/3.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <LDCSAdSDK/LDCSAdLoadReward.h>
#import <LDCSAdSDK/LDCSAdLoadProtocol.h>
#import <LDCSAdSDK/LDCSAdLoadShowProtocol.h>
#import "GDTRewardVideoAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface LDCSAdLoadGDTReward : LDCSAdLoadReward<GDTRewardedVideoAdDelegate,LDCSAdLoadProtocol>

@property(nonatomic, strong) GDTRewardVideoAd *ad;
@property(nonatomic, assign) BOOL isVideoLoaded;

@end

NS_ASSUME_NONNULL_END
