//
//  LDCSAdLoadGDTInterstitial.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/2.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <LDCSAdSDK/LDCSAdLoadInterstitial.h>
#import <LDCSAdSDK/LDCSAdLoadProtocol.h>
#import <LDCSAdSDK/LDCSAdLoadShowProtocol.h>
#import "GDTUnifiedInterstitialAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface LDCSAdLoadGDTInterstitial : LDCSAdLoadInterstitial<GDTUnifiedInterstitialAdDelegate,LDCSAdLoadProtocol>

@property(nonatomic, strong) GDTUnifiedInterstitialAd *ad;
- (void)lDloadData:(LDCSAdLoadCompleteBlock)csAdLoadCompleteBlock;

@end

NS_ASSUME_NONNULL_END
