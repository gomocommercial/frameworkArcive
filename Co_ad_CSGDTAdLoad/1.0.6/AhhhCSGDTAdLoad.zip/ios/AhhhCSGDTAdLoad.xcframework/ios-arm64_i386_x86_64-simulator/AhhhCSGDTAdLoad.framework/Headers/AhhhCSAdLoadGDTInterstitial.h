//
//  AhhhCSAdLoadGDTInterstitial.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/2.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadInterstitial.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import "GDTUnifiedInterstitialAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadGDTInterstitial : AhhhCSAdLoadInterstitial<GDTUnifiedInterstitialAdDelegate,AhhhCSAdLoadProtocol>

@property(nonatomic, strong) GDTUnifiedInterstitialAd *ad;
- (void)ahhhloadData:(AhhhCSAdLoadCompleteBlock)csAdLoadCompleteBlock;

@end

NS_ASSUME_NONNULL_END
