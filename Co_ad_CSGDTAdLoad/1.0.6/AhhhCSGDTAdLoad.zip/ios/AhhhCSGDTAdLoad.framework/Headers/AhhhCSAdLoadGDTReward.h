//
//  AhhhCSAdLoadGDTReward.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/3.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadReward.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import "GDTRewardVideoAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadGDTReward : AhhhCSAdLoadReward<GDTRewardedVideoAdDelegate,AhhhCSAdLoadProtocol>

@property(nonatomic, strong) GDTRewardVideoAd *ad;
@property(nonatomic, assign) BOOL isVideoLoaded;

@end

NS_ASSUME_NONNULL_END
