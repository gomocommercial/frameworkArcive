//
//  RVCSAdLoadGDTInterstitial.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/2.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <RVCSAdSDK/RVCSAdLoadInterstitial.h>
#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>
#import "GDTUnifiedInterstitialAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface RVCSAdLoadGDTInterstitial : RVCSAdLoadInterstitial<GDTUnifiedInterstitialAdDelegate,RVCSAdLoadProtocol>

@property(nonatomic, strong) GDTUnifiedInterstitialAd *ad;
- (void)rVloadData:(RVCSAdLoadCompleteBlock)csAdLoadCompleteBlock;

@end

NS_ASSUME_NONNULL_END
