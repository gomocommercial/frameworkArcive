//
//  RVCSAdLoadGDTReward.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/3.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RVCSAdSDK/RVCSAdLoadReward.h>
#import <RVCSAdSDK/RVCSAdLoadProtocol.h>
#import <RVCSAdSDK/RVCSAdLoadShowProtocol.h>
#import "GDTRewardVideoAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface RVCSAdLoadGDTReward : RVCSAdLoadReward<GDTRewardedVideoAdDelegate,RVCSAdLoadProtocol>

@property(nonatomic, strong) GDTRewardVideoAd *ad;
@property(nonatomic, assign) BOOL isVideoLoaded;

@end

NS_ASSUME_NONNULL_END
