#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "CSGDTAdloadConfig.h"
#import "CSGDTConfigModel.h"
#import "CSAdLoadGDTInterstitial.h"
#import "CSAdLoadGDTReward.h"

FOUNDATION_EXPORT double CSGDTAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char CSGDTAdLoadVersionString[];

