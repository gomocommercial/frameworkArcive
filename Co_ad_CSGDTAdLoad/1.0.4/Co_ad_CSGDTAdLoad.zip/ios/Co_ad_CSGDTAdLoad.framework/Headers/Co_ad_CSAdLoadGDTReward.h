//
//  Co_ad_CSAdLoadGDTReward.h
//  CSAdSDK_Example
//
//  Created by qiaoming on 2020/1/3.
//  Copyright © 2020 dengnengwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadReward.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadProtocol.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadShowProtocol.h>
#import "GDTRewardVideoAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdLoadGDTReward : Co_ad_CSAdLoadReward<GDTRewardedVideoAdDelegate,Co_ad_CSAdLoadProtocol>

@property(nonatomic, strong) GDTRewardVideoAd *ad;
@property(nonatomic, assign) BOOL isVideoLoaded;

@end

NS_ASSUME_NONNULL_END
