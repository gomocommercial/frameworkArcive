//
//  OpenAdMedel.h
//  LDCSOpenAdSDK
//
//  Created by Zy on 2021/9/27.
//

#import <Foundation/Foundation.h>
#import <LDCSAdSDK/LDCSAdLoadOpen.h>

NS_ASSUME_NONNULL_BEGIN

@interface OpenAdModel : NSObject

@property (nonatomic, strong) LDCSAdLoadOpen<LDCSAdLoadProtocol> * openAd;
@property (nonatomic, assign) BOOL requestFailed;

@end

NS_ASSUME_NONNULL_END
