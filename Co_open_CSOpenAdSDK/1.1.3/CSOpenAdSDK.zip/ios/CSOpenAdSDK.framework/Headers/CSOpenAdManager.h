//
//  CSOpenAdManager.h
//  CSOpenAdSDK
//
//  Created by qiaoming on 2021/1/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSInteger {
    openSuccess = 1,//成功
    abFailure = 2,//ab获取失败
    abClose = 3,//ab配置关
    adFailure = 4,//广告获取失败
    openTimeOut = 5,//超时
} OpenAdManagerStatus;

typedef enum : NSInteger {
    firstCoolLaunch = 1,//首次冷启动
    otherCoolLaunch = 2,//非首次冷启动
    hotLaunch = 3//热启动
} LaunchType;

typedef enum : NSInteger {
    openLaunchNone = 0,//没有超时
    firstCoolLaunchTimeOut = 1,//首次冷启动超时
    otherCoolLaunchTimeOut = 2,//非首次冷启动超时
    hotLaunchTimeOut = 3//热启动超时
} OpenLaunchTimeOut;

@class CSOpenAdManager;
typedef void (^OpenAdManagerCompleteBlock)(OpenAdManagerStatus status, CSOpenAdManager *admanager);

@interface CSOpenAdManager : NSObject

//ab请求的服务器域名
@property (nonatomic, strong) NSString *contentConfUrl;
@property (nonatomic, strong) NSString *productKey;
@property (nonatomic, strong) NSString *accessKey;
/*
isFirstLaunch: 是不是首次冷启动
cid: ab服务的产品ID
statisticsCid: 统计协议105 对应的产品id
contentConfUrl: ab域名
cid<481的，prodKey和AccessKey可以传空 否则都得传值, ab请求时候签名使用
prodKey: 
AccessKey: 
*/
+(instancetype)initWithFirstLaunch:(LaunchType)launch cid:(NSInteger)cid statisticsCid:(NSInteger)statisticsCid productKey:(NSString *)productKey accessKey:(NSString *)accessKey contentConfUrl:(NSString *)contentConfUrl adManagerCompleteBlock:(OpenAdManagerCompleteBlock)completeBlock;
+ (instancetype)sharedInstance;
//热启动 需要调的方法
+(void)hotLaunchAdManagerCompleteBlock:(OpenAdManagerCompleteBlock)completeBlock;
//客户端通知sdk 广告要显示的控制器
-(void)noticeSdkShowAdInViewController:(UIViewController *)showVC;
//客户端设置超时
+(void)setLaunchTimeOut:(OpenLaunchTimeOut)timeOut;
//campaign: 买量sdk返回的utmSourse
+(void)setFirstLaunchCampaign:(NSString *)firstLaunchCampaign;

@end

NS_ASSUME_NONNULL_END
