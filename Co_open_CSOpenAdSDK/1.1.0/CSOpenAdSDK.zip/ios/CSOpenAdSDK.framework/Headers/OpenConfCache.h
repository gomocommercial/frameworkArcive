
#import <Foundation/Foundation.h>

#define kCid2_key @"kCid2_key_%@"
#define kLastTime_key @"kLastTime_key_%@"
#define kAbtestId_key @"kAbtestId_key_%@"
#define kFilterId_key @"kFilterId_key_%@"

@interface OpenConfCache : NSObject
+ (BOOL)getResponseFromCacheWithKey:(NSString *)key;
+ (NSDictionary *)getContentCacheWithKey:(NSString *)key;
+ (void)setResponseToCacheWithKey:(NSString *)key responseDic:(NSMutableDictionary *)responseDic;

+ (void)saveAliveStatus:(NSString *)sid responseDic:(NSDictionary *)responseDic;

+ (void)saveRequestSwitchStatus:(NSString *)sid responseDic:(NSDictionary *)responseDic;

+ (int)getRequestSwitchStatus:(NSString *)sid;


+ (NSInteger)getSwitchAlive:(NSString *)sid;

+ (void)saveRetentionInfoWithCid2:(NSInteger)cid2 sid:(NSString *)sid abtestId:(NSInteger)abtestId filterId:(NSInteger)filterId hasUploaded:(BOOL)hasUploaded;
@end
