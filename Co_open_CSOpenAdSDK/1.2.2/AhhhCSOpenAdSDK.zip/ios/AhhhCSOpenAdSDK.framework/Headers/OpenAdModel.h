//
//  OpenAdMedel.h
//  AhhhCSOpenAdSDK
//
//  Created by Zy on 2021/9/27.
//

#import <Foundation/Foundation.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadOpen.h>

NS_ASSUME_NONNULL_BEGIN

@interface OpenAdModel : NSObject

@property (nonatomic, strong) AhhhCSAdLoadOpen<AhhhCSAdLoadProtocol> * openAd;
@property (nonatomic, assign) BOOL requestFailed;

@end

NS_ASSUME_NONNULL_END
