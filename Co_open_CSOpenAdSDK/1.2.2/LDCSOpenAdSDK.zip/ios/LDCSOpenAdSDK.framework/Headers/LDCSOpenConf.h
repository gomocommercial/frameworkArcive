//
//  LDCSOpenConf.h
//  Pods
//
//  Created by qiaoming on 2021/1/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LDCSOpenConf : NSObject
//广告开关 yes开 no关
@property (nonatomic, assign) BOOL ad_switch;

//虚拟模块id
@property (nonatomic, strong) NSString *first_cold;
@property (nonatomic, strong) NSString *cold_module_id;
@property (nonatomic, strong) NSString *warm_module_id;
@property (nonatomic, strong) NSString *key_word;

@property (nonatomic, strong) NSString *first_cold2;
@property (nonatomic, strong) NSString *cold_module_id2;
@property (nonatomic, strong) NSString *warm_module_id2;
@property (nonatomic, strong) NSString *key_word2;


//"cfg_id" = 25631;
//"cfg_tb_id" = 0;
-(void)contentConfiToModel:(NSDictionary *)dic;
@end

NS_ASSUME_NONNULL_END
