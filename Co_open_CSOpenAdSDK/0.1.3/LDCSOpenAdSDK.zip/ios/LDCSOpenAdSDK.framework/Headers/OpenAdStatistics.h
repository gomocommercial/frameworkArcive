//
//  OpenAdStatistics.h
//  abtestcentersdk
//
//  Created by linqiaogeng on 2018/8/2.
//

#import <Foundation/Foundation.h>

@interface OpenAdStatistics : NSObject

+(void)openUploadStatisticWithOperationCode:(NSString *)operationCode statisticsObject:(NSString *)statisticsObject associationObject:(NSInteger)associationObject tab:(NSString *)tab position:(NSInteger)position advertId:(NSString *)advertId entrance:(NSInteger)entrance;

@end
