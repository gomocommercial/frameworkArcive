
#import <Foundation/Foundation.h>

@interface OpenConfiCommonUtils : NSObject
+ (NSData *)uncompressZippedData:(NSData *)compressedData;
+ (NSString *)decryptUseDES:(NSData *)cipherData key:(NSString *)key keyNeedBase64:(BOOL)keyNeedBase64;
@end
