//
//  OpenAdMedel.h
//  PHCSOpenAdSDK
//
//  Created by Zy on 2021/9/27.
//

#import <Foundation/Foundation.h>
#import <PHCSAdSDK/PHCSAdLoadOpen.h>

NS_ASSUME_NONNULL_BEGIN

@interface OpenAdModel : NSObject

@property (nonatomic, strong) PHCSAdLoadOpen<PHCSAdLoadProtocol> * openAd;
@property (nonatomic, assign) BOOL requestFailed;

@end

NS_ASSUME_NONNULL_END
