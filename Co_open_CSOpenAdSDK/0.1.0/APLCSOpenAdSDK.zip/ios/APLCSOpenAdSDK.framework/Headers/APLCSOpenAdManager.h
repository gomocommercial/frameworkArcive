//
//  APLCSOpenAdManager.h
//  APLCSOpenAdSDK
//
//  Created by qiaoming on 2021/1/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSInteger {
    openSuccess = 1,
    abFailure = 2,
    abClose = 3,
    adFailure = 4,
    openTimeOut = 5,
} OpenAdManagerStatus;

typedef enum : NSInteger {
    firstCoolLaunch = 1,
    otherCoolLaunch = 2,
    hotLaunch = 3
} LaunchType;

typedef enum : NSInteger {
    openLaunchNone = 0,
    firstCoolLaunchTimeOut = 1,
    otherCoolLaunchTimeOut = 2,
    hotLaunchTimeOut = 3
} OpenLaunchTimeOut;

@class APLCSOpenAdManager;
typedef void (^OpenAdManagerCompleteBlock)(OpenAdManagerStatus status, APLCSOpenAdManager *admanager);

@interface APLCSOpenAdManager : NSObject

//ab请求的服务器域名
@property (nonatomic, strong) NSString *contentConfUrl;

+(instancetype)aPLinitWithFirstLaunch:(LaunchType)launch cid:(NSInteger)cid statisticsCid:(NSInteger)statisticsCid compaign:(NSString *)compaign contentConfUrl:(NSString *)contentConfUrl adManagerCompleteBlock:(OpenAdManagerCompleteBlock)completeBlock;
+ (instancetype)aPLsharedInstance;
//热启动 需要调的方法
+(void)aPLhotLaunchAdManagerCompleteBlock:(OpenAdManagerCompleteBlock)completeBlock;
//客户端通知sdk 广告要显示的控制器
-(void)aPLnoticeSdkShowAdInViewController:(UIViewController *)showVC;
//客户端设置超时
-(void)aPLsetLaunchTimeOut:(OpenLaunchTimeOut)timeOut;

@end

NS_ASSUME_NONNULL_END
