
#import <Foundation/Foundation.h>
#import "OpenConfiCenterService.h"

extern NSString *kOpenContentConfiData;

@interface OpenConfiNetworkTool : NSObject
+ (instancetype)sharedInstance;

- (void)requestAbtestWithService:(OpenConfiCenterService *) centerService complete:(GOMOAbRequestCompleteBlock)complete;

- (void)parseRespondWithResponseDic:(NSDictionary *)responseDic useCache:(BOOL)useCache;

@property(nonatomic, copy) GOMOAbRequestCompleteBlock gomoAbRequestCompleteBlock;
@end
