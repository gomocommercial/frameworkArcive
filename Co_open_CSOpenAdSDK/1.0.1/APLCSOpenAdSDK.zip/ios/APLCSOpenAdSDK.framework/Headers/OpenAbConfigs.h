//
//  OpenAbConfigs.h

#import <Foundation/Foundation.h>
#define GMOpenAbLog(fmt, ...) NSLog((@"%s[Line %d] GM_Open_LOG:" fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
@interface OpenAbConfigs : NSObject
+ (instancetype)sharedInstance;

- (BOOL)getDebugLog;
- (void)setDebugLog:(BOOL)debugLog;
- (BOOL)isDebug;
- (void)setDebugEnv:(BOOL)debug;
@end
