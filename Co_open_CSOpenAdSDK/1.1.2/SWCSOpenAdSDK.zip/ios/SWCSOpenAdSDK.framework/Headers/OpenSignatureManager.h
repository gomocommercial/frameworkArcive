//
//  OpenSignatureManager.h
//  SWCSOpenAdSDK
//
//  Created by qiaoming on 2021/2/7.
//

#import <Foundation/Foundation.h>
#import "OpenAbConfigs.h"

NS_ASSUME_NONNULL_BEGIN

@interface OpenSignatureManager : NSObject

+(NSString *)openHmacSHA256ThenBase64:(NSString *)key value:(NSString *)value;

@end

NS_ASSUME_NONNULL_END
