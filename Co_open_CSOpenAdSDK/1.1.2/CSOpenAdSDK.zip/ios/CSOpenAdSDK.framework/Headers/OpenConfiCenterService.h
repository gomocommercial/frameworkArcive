//
//  GOMOAdManager.h
//  abtestcentersdk
//
//  Created by linqiaogeng on 2018/8/1.
//

#import <Foundation/Foundation.h>

@class OpenAbBuilder;

typedef enum : NSInteger {
    OpenAbSuccess = 1,
    OpenAbFailure = -1,
} OpenAbStatus;

typedef enum : NSInteger {
    OPEN_MAIN_PACKAGE = 1,
    OPEN_THEME = 2,
    OPEN_TEST = 999

} OpenEntrance;



typedef void (^GOMOAbRequestCompleteBlock)(OpenAbStatus abStatus, NSDictionary *resDic, NSError *error);

typedef void (^GOMOAbManagerBuilder)(OpenAbBuilder *openBuilder);

@interface OpenConfiCenterService : NSObject
@property(nonatomic, assign) NSInteger cid;
@property(nonatomic, assign) NSInteger cid2;
@property(nonatomic, assign) NSInteger entrance;
@property(nonatomic, assign) NSInteger cdays;
@property(nonatomic, assign) NSInteger isupgrade;
@property(nonatomic, copy) NSString *sid;
@property(nonatomic, copy) NSString *local;
@property(nonatomic, copy) NSString *utmSource;
@property(nonatomic, copy) NSString *userForm;

+ (instancetype)createWithBuilder:(GOMOAbManagerBuilder)block;

- (void)requestAbtest:(GOMOAbRequestCompleteBlock)complete;

+ (void)retentionStaticsWithCid2:(NSInteger)cid2 sids:(NSArray *)sids abtestIds:(NSArray *)abtestIds filterIds:(NSArray *)filterIds;

+ (void)retentionStaticsWithCid2:(NSInteger)cid2 sid:(NSString *)sid abtestId:(NSInteger)abtestId filterId:(NSInteger)filterId;
@end
