

#import <Foundation/Foundation.h>

@class OpenConfiCenterService;

@interface OpenAbBuilder : NSObject
@property(nonatomic, copy) NSArray<NSString *> *sids;

@property(nonatomic, assign) NSString *sid;
@property(nonatomic, assign) NSInteger cid;
@property(nonatomic, assign) NSInteger cid2;
@property(nonatomic, assign) NSInteger entrance;
@property(nonatomic, assign) NSInteger cdays;
@property(nonatomic, assign) NSInteger isupgrade;

@property(nonatomic, copy) NSString *local;
@property(nonatomic, copy) NSString *utmSource;
@property(nonatomic, copy) NSString *userForm;

- (OpenConfiCenterService *)build;
@end
