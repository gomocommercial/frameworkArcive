//
//  APLGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "APLGMProductModel.h"
#import "APLPayNotificationHTTPResponse.h"
#import <APLGMPaymentSDK/APLGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface APLGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^APLGMCkeckPayStateApiCompleteBlock) (APLPayNotificationHTTPResponse *gmresponse);
+ (APLGMCheckPayReceiptisValid *)aPLsharedManager;
-(void)aPLfetchIAPPreorderAndCheckReceiptIsValid:(APLGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(APLGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
