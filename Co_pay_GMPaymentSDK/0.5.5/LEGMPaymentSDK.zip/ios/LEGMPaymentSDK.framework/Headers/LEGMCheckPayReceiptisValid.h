//
//  LEGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "LEGMProductModel.h"
#import "LEPayNotificationHTTPResponse.h"
#import <LEGMPaymentSDK/LEGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface LEGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^LEGMCkeckPayStateApiCompleteBlock) (LEPayNotificationHTTPResponse *gmresponse);
+ (LEGMCheckPayReceiptisValid *)lEsharedManager;
-(void)lEfetchIAPPreorderAndCheckReceiptIsValid:(LEGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(LEGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
