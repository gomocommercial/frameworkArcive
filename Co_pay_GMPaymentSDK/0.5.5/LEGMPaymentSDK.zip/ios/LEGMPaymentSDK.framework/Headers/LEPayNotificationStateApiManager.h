//
//  LEPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LEPayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "LEPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^LEPayNotificationStateApiCompleteBlock) (LEPayNotificationHTTPResponse *response);

@interface LEPayNotificationStateApiManager : AFHTTPSessionManager
+ (LEPayNotificationStateApiManager *)lEsharedManager;
//支付成功新增后台 通知接口
-(void)lEcheckiOSIAPPayOrderWithPayNotificationModel:(LEPayNotificationModel *)payNotificationModel  complete:(LEPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
