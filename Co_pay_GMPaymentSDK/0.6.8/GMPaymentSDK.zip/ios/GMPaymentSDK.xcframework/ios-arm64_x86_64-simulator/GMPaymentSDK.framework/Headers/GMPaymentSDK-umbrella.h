#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "CheckPayReceiptistSerializer.h"
#import "GMPaymentConfig.h"
#import "GMCheckPayReceiptisValid.h"
#import "GMPaymentSDK.h"
#import "GMPayNotificationConfig.h"
#import "GMPayNotificationDeviceModel.h"
#import "GMIAPManager.h"
#import "GMCheckOrderModel.h"
#import "GMPayCusConfigModel.h"
#import "GMPayDeviceModel.h"
#import "GMProductModel.h"
#import "NSString+PayNotificationSecure.h"
#import "PayNotificationFailManager.h"
#import "PayNotificationHTTPResponse.h"
#import "PayNotificationModel.h"
#import "PayNotificationRequestSerializer.h"
#import "PayNotificationSecureManager.h"
#import "PayNotificationStateApiManager.h"
#import "GMPaymentSDK-Bridging-Header.h"
#import "MyTest.h"

FOUNDATION_EXPORT double GMPaymentSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char GMPaymentSDKVersionString[];

