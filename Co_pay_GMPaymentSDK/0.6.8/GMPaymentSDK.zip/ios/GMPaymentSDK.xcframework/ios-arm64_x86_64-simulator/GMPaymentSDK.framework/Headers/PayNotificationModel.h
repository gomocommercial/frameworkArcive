//
//  PayNotificationModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PayNotificationModel : NSObject<NSCoding>

@property (nonatomic, copy) NSString *uuid;

@property (nonatomic, copy) NSString *product_id;

//不再使用交易凭证
//@property (nonatomic, copy) NSString *receipt;

//原始订单id
@property (nonatomic, copy) NSString *originalTransactionId;

@end

NS_ASSUME_NONNULL_END
