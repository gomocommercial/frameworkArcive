//
//  MyTest.h
//  Pods-GMPaymentSDK_Example
//
//  Created by zhangxin on 2024/10/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyTest : NSObject

@end

NS_ASSUME_NONNULL_END
