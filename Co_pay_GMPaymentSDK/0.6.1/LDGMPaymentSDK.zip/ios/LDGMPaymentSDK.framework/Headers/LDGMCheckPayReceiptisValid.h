//
//  LDGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "LDGMProductModel.h"
#import "LDPayNotificationHTTPResponse.h"
#import <LDGMPaymentSDK/LDGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface LDGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^LDGMCkeckPayStateApiCompleteBlock) (LDPayNotificationHTTPResponse *gmresponse);
+ (LDGMCheckPayReceiptisValid *)lDsharedManager;
-(void)lDfetchIAPPreorderAndCheckReceiptIsValid:(LDGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(LDGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
