//
//  Co_st_GMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "Co_st_GMProductModel.h"
#import "Co_st_PayNotificationHTTPResponse.h"
#import <Co_st_GMPaymentSDK/Co_st_GMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface Co_st_GMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^Co_st_GMCkeckPayStateApiCompleteBlock) (Co_st_PayNotificationHTTPResponse *gmresponse);
+ (Co_st_GMCheckPayReceiptisValid *)co_st_sharedManager;
-(void)co_st_fetchIAPPreorderAndCheckReceiptIsValid:(Co_st_GMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(Co_st_GMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
