//
//  Co_st_PayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Co_st_PayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "Co_st_PayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^Co_st_PayNotificationStateApiCompleteBlock) (Co_st_PayNotificationHTTPResponse *response);

@interface Co_st_PayNotificationStateApiManager : AFHTTPSessionManager
+ (Co_st_PayNotificationStateApiManager *)co_st_sharedManager;
//支付成功新增后台 通知接口
-(void)co_st_checkiOSIAPPayOrderWithPayNotificationModel:(Co_st_PayNotificationModel *)payNotificationModel  complete:(Co_st_PayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
