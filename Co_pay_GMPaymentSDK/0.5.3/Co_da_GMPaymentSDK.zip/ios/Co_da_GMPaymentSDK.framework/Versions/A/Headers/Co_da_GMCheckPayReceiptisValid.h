//
//  Co_da_GMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "Co_da_GMProductModel.h"
#import "Co_da_PayNotificationHTTPResponse.h"
#import <Co_da_GMPaymentSDK/Co_da_GMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface Co_da_GMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^Co_da_GMCkeckPayStateApiCompleteBlock) (Co_da_PayNotificationHTTPResponse *gmresponse);
+ (Co_da_GMCheckPayReceiptisValid *)co_da_sharedManager;
-(void)co_da_fetchIAPPreorderAndCheckReceiptIsValid:(Co_da_GMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(Co_da_GMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
