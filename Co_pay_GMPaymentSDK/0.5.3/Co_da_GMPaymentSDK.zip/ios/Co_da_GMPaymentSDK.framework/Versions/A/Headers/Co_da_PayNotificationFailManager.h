//
//  Co_da_PayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "Co_da_PayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_da_PayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)co_da_saveToCacheWithProductId:(NSString *)product_id;
+(Co_da_PayNotificationModel*)co_da_unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)co_da_delSerializedBean:(Co_da_PayNotificationModel*)bean;
+(NSArray <Co_da_PayNotificationModel *>*)co_da_getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)co_da_retryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
