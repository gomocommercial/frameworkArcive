//
//  Co_da_PayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Co_da_PayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "Co_da_PayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^Co_da_PayNotificationStateApiCompleteBlock) (Co_da_PayNotificationHTTPResponse *response);

@interface Co_da_PayNotificationStateApiManager : AFHTTPSessionManager
+ (Co_da_PayNotificationStateApiManager *)co_da_sharedManager;
//支付成功新增后台 通知接口
-(void)co_da_checkiOSIAPPayOrderWithPayNotificationModel:(Co_da_PayNotificationModel *)payNotificationModel  complete:(Co_da_PayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
