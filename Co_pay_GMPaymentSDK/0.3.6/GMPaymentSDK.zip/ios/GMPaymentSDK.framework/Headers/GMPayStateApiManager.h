//
//  GMPayStateApiManager.h
//  GLive
//
//  Created by Gordon Su on 2017/5/22.
//  Copyright © 2017年 3g.cn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GMPayNotificationModel.h"

@class GMNetHTTPResponse;
typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);

@interface GMPayStateApiManager : NSObject

+ (GMPayStateApiManager *)sharedManager;
#pragma mark - IAP
/**
 生成预支付订单号 POST
/v1/ios/preorder
 @param tran_purpose <#tran_purpose description#>∫∫
 @param amount <#amount description#>
 @param product_id <#product_id description#>
 @param body <#body description#>
 @param detail <#detail description#>
 @param attach_info <#attach_info description#>
 @param complete <#complete description#>
 */
- (void)fetchIAPPreorderWithTranPurpose:(NSString *)tran_purpose
                                 amount:(float)amount
                          currency_code:(NSString *)currency_code
                             product_id:(NSString *)product_id
                                   body:(NSString *)body
                                 detail:(NSString *)detail
                            attach_info:(id)attach_info
                               complete:(GMPayStateApiCompleteBlock)complete;

/**
 <#Description#>

 @param tran_id 预支付调用中服务器生成的交易订单号
 @param complete <#complete description#>
 */
- (void)checkIAPWithTranId:(NSString *)tran_id receipt:(NSString *)receipt complete:(GMPayStateApiCompleteBlock)complete;

- (void)checkIAPSubscriptionsState:(NSString *)transitionID withReceiptID:(NSString *)receiptID withComplete:(GMPayStateApiCompleteBlock)complete;

///**
// 根据订单号获取订单支付结果 GET
///v1/order/{tranId}
// @param tranId 交易订单号
// */
//- (void)checkOrderWithTranId:(NSString *)tranId complete:(GLPayStateApiCompleteBlock)complete;

////订单查询
/////v1/order
////GET
//- (void)fetchOrderListWithNextPageQueryParam:(NSString *_Nullable)next_page_query_param complete:(GLPayStateApiCompleteBlock)complete;

- (void)getSubscriptionWithComplete:(GMPayStateApiCompleteBlock)complete;


- (void)getSubscriptionIdentifierWithReceipt:(NSString *)receipt complete:(GMPayStateApiCompleteBlock)complete;

//支付成功新增后台 通知接口
- (void)checkiOSIAPPayOrderWithPayNotificationModel:(GMPayNotificationModel *)payNotificationModel  complete:(GMPayStateApiCompleteBlock)complete;

@end
