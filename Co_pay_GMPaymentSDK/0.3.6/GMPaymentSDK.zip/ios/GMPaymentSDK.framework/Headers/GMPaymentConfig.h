//
// Created by zhangjiemin on 2018/7/4.
//

#import <Foundation/Foundation.h>

#define GM_PURPOSE_PURCHASE @"PRODUCT_PURCHASE"
#define GM_PURPOSE_RECHARGE @"VCOIN_RECHARGE"
#define GM_PURPOSE_SUBCRIPTION @"PRODUCT_SUBSCRIPTION"

@interface GMPaymentConfig : NSObject
@property (nonatomic,copy) NSString *accessToken;
@property (nonatomic,copy) NSString *accountId;
@property(nonatomic, assign) BOOL isTest;

- (void)initPaymentConfigDebugWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId;

- (void)initPaymentConfigReleaseWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId;

- (NSString *)getPayStateDomain;

- (NSString *)getSignatureKey;

- (NSString *)getClientID;

- (NSString *)getStaticUUID;

- (void)setStaticUUID:(NSString *)uuid;

+ (instancetype)sharedManger;
@end
