//
// Created by zhangjiemin on 2018/7/4.
//

#import <Foundation/Foundation.h>
#import "AMAGMPayCusConfigModel.h"

#define GM_PURPOSE_PURCHASE @"PRODUCT_PURCHASE"
#define GM_PURPOSE_RECHARGE @"VCOIN_RECHARGE"
#define GM_PURPOSE_SUBCRIPTION @"PRODUCT_SUBSCRIPTION"

@interface AMAGMPaymentConfig : NSObject
@property (nonatomic,copy) NSString *accessToken;
@property (nonatomic,copy) NSString *accountId;
@property(nonatomic, assign) BOOL isTest;//是否是测试环境 YES代表debug环境
@property(nonatomic, copy) NSString *localPassword;
@property(nonatomic, copy) NSString *staticUUID;

/**
 提示：初始化配置时，若cusConfigModelbu不为空时，PaymentSDKUrl和CheckPayReceiptUrl中配置的域名将失效（仅域名，其他配置有效）
 */
- (void)aMAinitPaymentConfigDebugWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password isIpUrl:(BOOL)isIpUrl cusConfigModel: (AMAGMPayCusConfigModel *)cusConfig;

/**
 提示：初始化配置时，若cusConfigModelbu不为空时，PaymentSDKUrl和CheckPayReceiptUrl中配置的域名将失效（仅域名，其他配置有效）
 */
- (void)aMAinitPaymentConfigReleaseWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password isIpUrl:(BOOL)isIpUrl cusConfigModel: (AMAGMPayCusConfigModel *)cusConfig;

- (NSString *)aMAgetPayStateDomain;

- (NSString *)aMAgetSignatureKey;

- (NSString *)aMAgetClientID;

- (NSString *)aMAgetStaticUUID;

- (void)setStaticUUID:(NSString *)uuid;

+ (instancetype)aMAsharedManger;
@end
