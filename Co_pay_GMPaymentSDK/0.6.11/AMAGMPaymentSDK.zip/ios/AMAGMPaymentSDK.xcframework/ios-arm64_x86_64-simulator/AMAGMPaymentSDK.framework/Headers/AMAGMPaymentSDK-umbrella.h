#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "AMACheckPayReceiptistSerializer.h"
#import "AMAGMCheckPayReceiptisValid.h"
#import "AMAGMPaymentSDK.h"
#import "AMAGMPayNotificationConfig.h"
#import "AMAGMPayNotificationDeviceModel.h"
#import "AMAPayNotificationFailManager.h"
#import "AMAPayNotificationHTTPResponse.h"
#import "AMAPayNotificationModel.h"
#import "AMAPayNotificationRequestSerializer.h"
#import "AMAPayNotificationSecureManager.h"
#import "AMAPayNotificationStateApiManager.h"
#import "AMAGMPaymentConfig.h"
#import "AMAGMIAPManager.h"
#import "AMAGMCheckOrderModel.h"
#import "AMAGMPayCusConfigModel.h"
#import "AMAGMPayDeviceModel.h"
#import "AMAGMProductModel.h"
#import "NSString+AMAPayNotificationSecure.h"

FOUNDATION_EXPORT double AMAGMPaymentSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char AMAGMPaymentSDKVersionString[];

