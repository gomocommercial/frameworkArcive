//
//  AMAGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "AMAGMProductModel.h"
#import "AMAPayNotificationHTTPResponse.h"
#import <AMAGMPaymentSDK/AMAGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface AMAGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^AMAGMCkeckPayStateApiCompleteBlock) (AMAPayNotificationHTTPResponse *gmresponse);
typedef void (^AMAGMPrePaymentApiCompleteBlock) (AMAPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (AMAGMCheckPayReceiptisValid *)aMAsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)aMAprepaymentWithProduct:(AMAGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(AMAGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)aMAfetchIAPPreorderAndCheckReceiptIsValid:(AMAGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(AMAGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
