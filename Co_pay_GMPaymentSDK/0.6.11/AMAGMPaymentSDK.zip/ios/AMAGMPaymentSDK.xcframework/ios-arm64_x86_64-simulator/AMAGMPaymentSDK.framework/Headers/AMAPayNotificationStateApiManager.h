//
//  AMAPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AMAPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "AMAPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^AMAPayNotificationStateApiCompleteBlock) (AMAPayNotificationHTTPResponse *response);

@interface AMAPayNotificationStateApiManager : AFHTTPSessionManager
+ (AMAPayNotificationStateApiManager *)aMAsharedManager;
//支付成功新增后台 通知接口
-(void)aMAcheckiOSIAPPayOrderWithPayNotificationModel:(AMAPayNotificationModel *)payNotificationModel  complete:(AMAPayNotificationStateApiCompleteBlock)complete;
-(void)aMAgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(AMAPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
