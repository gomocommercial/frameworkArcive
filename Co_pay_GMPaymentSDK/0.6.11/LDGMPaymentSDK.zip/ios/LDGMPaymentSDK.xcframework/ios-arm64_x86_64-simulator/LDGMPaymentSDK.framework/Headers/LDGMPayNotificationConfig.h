//
//  LDGMPayNotificationConfig.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LDGMPayCusConfigModel.h"

typedef NS_ENUM (NSInteger, PayNotificationMethod) {
    PayNotificationHttpMethodGET = 0,
    PayNotificationMethodPOST,
};
NS_ASSUME_NONNULL_BEGIN

@interface LDGMPayNotificationConfig : NSObject

@property (nonatomic,copy) NSString *accessToken;
@property (nonatomic,copy) NSString *accountId;
@property(nonatomic, assign) BOOL isTest;
@property(nonatomic, copy) NSString *staticUUID;
@property(nonatomic, copy) NSString *clientID;
@property(nonatomic, copy) NSString *xSignatureKey;
@property(nonatomic, copy) NSString *payStateDomain;
@property(nonatomic, copy) NSString *desKey;
@property(nonatomic, copy) NSString *hostHeader;
@property(nonatomic, assign) BOOL isIpUrl;
@property(nonatomic, strong) LDGMPayCusConfigModel *cusConfigModel;

@property(nonatomic, assign)NSInteger desBytesCapacity;
@property(nonatomic, assign)NSInteger requestTimeout;
- (void)lDinitPayNotificationConfigWith:(BOOL)isDebug withClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey appid:(NSString *)appId cusConfigModel: (LDGMPayCusConfigModel *)configModel;

- (NSString *)lDgetPayStateDomain;

- (NSString *)lDgetSignatureKey;

- (NSString *)lDgetClientID;
- (NSString *)lDgetStaticUUID;

- (void)setStaticUUID:(NSString *)uuid;

+ (instancetype)lDsharedManger;

@end

NS_ASSUME_NONNULL_END
