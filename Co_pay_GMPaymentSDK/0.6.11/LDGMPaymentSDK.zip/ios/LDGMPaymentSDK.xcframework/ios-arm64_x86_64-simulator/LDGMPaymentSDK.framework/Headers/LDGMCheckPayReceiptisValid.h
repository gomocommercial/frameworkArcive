//
//  LDGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "LDGMProductModel.h"
#import "LDPayNotificationHTTPResponse.h"
#import <LDGMPaymentSDK/LDGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface LDGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^LDGMCkeckPayStateApiCompleteBlock) (LDPayNotificationHTTPResponse *gmresponse);
typedef void (^LDGMPrePaymentApiCompleteBlock) (LDPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (LDGMCheckPayReceiptisValid *)lDsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)lDprepaymentWithProduct:(LDGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(LDGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)lDfetchIAPPreorderAndCheckReceiptIsValid:(LDGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(LDGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
