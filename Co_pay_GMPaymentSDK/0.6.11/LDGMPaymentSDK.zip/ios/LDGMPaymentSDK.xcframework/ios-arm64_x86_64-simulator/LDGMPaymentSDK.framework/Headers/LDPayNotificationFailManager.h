//
//  LDPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "LDPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LDPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)lDsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(LDPayNotificationModel*)lDunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)lDdelSerializedBean:(LDPayNotificationModel*)bean;
+(NSArray <LDPayNotificationModel *>*)lDgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lDretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
