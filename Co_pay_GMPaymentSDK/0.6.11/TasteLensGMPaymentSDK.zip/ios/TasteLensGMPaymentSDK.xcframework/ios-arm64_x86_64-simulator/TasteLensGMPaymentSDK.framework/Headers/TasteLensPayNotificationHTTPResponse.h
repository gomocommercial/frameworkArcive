//
//  TasteLensPayNotificationHTTPResponse.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/28.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef NS_ENUM(NSInteger , PayNotificationHttpStatus) {
    GetCheckPayAccountIDOrTokenValid  = 0,      //账号id或者token失效(未登录)
    GetCheckPayTranIDFail             = -2,     //获取预支付订单号 失败
    CheckReceiptIsValidFail           = -1,     //服务器验单 失败
    ReplaceOrderIsValidFail           = -3,     //服务器补单失败
    PayNotificationHttpStatusFail     = 0,      //上报 失败
    GetCheckPayTranIDSuccess          = 1,      //获取预支付订单号 成功
    CheckReceiptIsValidSuccess        = 2,      //服务器验单 成功
    PayNotificationHttpStatusSuccess  = 3       //上报 成功
};
NS_ASSUME_NONNULL_BEGIN

@interface TasteLensPayNotificationHTTPResponse : NSObject

/**
 http 的返回码
 */
@property (nonatomic) NSInteger statusCode;
@property (nonatomic, strong) NSError *error;
@property (nonatomic, copy) NSDictionary *bodyData;
//{"error_result":{"error_code":"SUCCESS","error_msg":"SUCCESS"},"pay_success":false}
@property (nonatomic, copy) NSString *bodyString;
@property (nonatomic, strong) NSURLResponse *response;

@end

NS_ASSUME_NONNULL_END
