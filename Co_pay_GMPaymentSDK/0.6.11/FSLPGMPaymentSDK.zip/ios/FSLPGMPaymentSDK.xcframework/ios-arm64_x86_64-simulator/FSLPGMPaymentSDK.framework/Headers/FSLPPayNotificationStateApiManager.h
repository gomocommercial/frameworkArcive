//
//  FSLPPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FSLPPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "FSLPPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^FSLPPayNotificationStateApiCompleteBlock) (FSLPPayNotificationHTTPResponse *response);

@interface FSLPPayNotificationStateApiManager : AFHTTPSessionManager
+ (FSLPPayNotificationStateApiManager *)fSLPsharedManager;
//支付成功新增后台 通知接口
-(void)fSLPcheckiOSIAPPayOrderWithPayNotificationModel:(FSLPPayNotificationModel *)payNotificationModel  complete:(FSLPPayNotificationStateApiCompleteBlock)complete;
-(void)fSLPgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(FSLPPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
