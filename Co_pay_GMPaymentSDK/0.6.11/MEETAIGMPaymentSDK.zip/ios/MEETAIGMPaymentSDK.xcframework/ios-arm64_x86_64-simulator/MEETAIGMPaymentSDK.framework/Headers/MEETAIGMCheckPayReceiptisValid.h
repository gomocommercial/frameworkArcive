//
//  MEETAIGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "MEETAIGMProductModel.h"
#import "MEETAIPayNotificationHTTPResponse.h"
#import <MEETAIGMPaymentSDK/MEETAIGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface MEETAIGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^MEETAIGMCkeckPayStateApiCompleteBlock) (MEETAIPayNotificationHTTPResponse *gmresponse);
typedef void (^MEETAIGMPrePaymentApiCompleteBlock) (MEETAIPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (MEETAIGMCheckPayReceiptisValid *)mEETAIsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)mEETAIprepaymentWithProduct:(MEETAIGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(MEETAIGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)mEETAIfetchIAPPreorderAndCheckReceiptIsValid:(MEETAIGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(MEETAIGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
