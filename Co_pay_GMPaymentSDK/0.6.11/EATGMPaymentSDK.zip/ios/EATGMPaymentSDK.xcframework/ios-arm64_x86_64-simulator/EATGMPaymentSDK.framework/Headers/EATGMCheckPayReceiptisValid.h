//
//  EATGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "EATGMProductModel.h"
#import "EATPayNotificationHTTPResponse.h"
#import <EATGMPaymentSDK/EATGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface EATGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^EATGMCkeckPayStateApiCompleteBlock) (EATPayNotificationHTTPResponse *gmresponse);
typedef void (^EATGMPrePaymentApiCompleteBlock) (EATPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (EATGMCheckPayReceiptisValid *)eATsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)eATprepaymentWithProduct:(EATGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(EATGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)eATfetchIAPPreorderAndCheckReceiptIsValid:(EATGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(EATGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
