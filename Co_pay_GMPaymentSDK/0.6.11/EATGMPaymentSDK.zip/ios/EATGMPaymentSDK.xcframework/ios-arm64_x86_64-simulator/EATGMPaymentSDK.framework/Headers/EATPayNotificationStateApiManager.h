//
//  EATPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EATPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "EATPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^EATPayNotificationStateApiCompleteBlock) (EATPayNotificationHTTPResponse *response);

@interface EATPayNotificationStateApiManager : AFHTTPSessionManager
+ (EATPayNotificationStateApiManager *)eATsharedManager;
//支付成功新增后台 通知接口
-(void)eATcheckiOSIAPPayOrderWithPayNotificationModel:(EATPayNotificationModel *)payNotificationModel  complete:(EATPayNotificationStateApiCompleteBlock)complete;
-(void)eATgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(EATPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
