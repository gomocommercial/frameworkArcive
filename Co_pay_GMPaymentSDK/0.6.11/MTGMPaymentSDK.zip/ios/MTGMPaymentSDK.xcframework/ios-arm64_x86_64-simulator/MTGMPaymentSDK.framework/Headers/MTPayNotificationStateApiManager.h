//
//  MTPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MTPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "MTPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^MTPayNotificationStateApiCompleteBlock) (MTPayNotificationHTTPResponse *response);

@interface MTPayNotificationStateApiManager : AFHTTPSessionManager
+ (MTPayNotificationStateApiManager *)mTsharedManager;
//支付成功新增后台 通知接口
-(void)mTcheckiOSIAPPayOrderWithPayNotificationModel:(MTPayNotificationModel *)payNotificationModel  complete:(MTPayNotificationStateApiCompleteBlock)complete;
-(void)mTgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(MTPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
