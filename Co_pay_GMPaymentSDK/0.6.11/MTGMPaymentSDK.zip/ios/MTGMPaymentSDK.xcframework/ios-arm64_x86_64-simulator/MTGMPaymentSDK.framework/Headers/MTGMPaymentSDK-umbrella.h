#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MTGMPaymentConfig.h"
#import "MTGMIAPManager.h"
#import "MTGMCheckOrderModel.h"
#import "MTGMPayCusConfigModel.h"
#import "MTGMPayDeviceModel.h"
#import "MTGMProductModel.h"
#import "MTCheckPayReceiptistSerializer.h"
#import "MTGMCheckPayReceiptisValid.h"
#import "MTGMPaymentSDK.h"
#import "MTGMPayNotificationConfig.h"
#import "MTGMPayNotificationDeviceModel.h"
#import "MTPayNotificationFailManager.h"
#import "MTPayNotificationHTTPResponse.h"
#import "MTPayNotificationModel.h"
#import "MTPayNotificationRequestSerializer.h"
#import "MTPayNotificationSecureManager.h"
#import "MTPayNotificationStateApiManager.h"
#import "NSString+MTPayNotificationSecure.h"

FOUNDATION_EXPORT double MTGMPaymentSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char MTGMPaymentSDKVersionString[];

