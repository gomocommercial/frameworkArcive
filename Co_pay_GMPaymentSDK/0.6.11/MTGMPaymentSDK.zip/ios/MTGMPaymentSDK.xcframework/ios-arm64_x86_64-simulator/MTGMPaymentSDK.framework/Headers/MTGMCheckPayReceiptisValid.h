//
//  MTGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "MTGMProductModel.h"
#import "MTPayNotificationHTTPResponse.h"
#import <MTGMPaymentSDK/MTGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface MTGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^MTGMCkeckPayStateApiCompleteBlock) (MTPayNotificationHTTPResponse *gmresponse);
typedef void (^MTGMPrePaymentApiCompleteBlock) (MTPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (MTGMCheckPayReceiptisValid *)mTsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)mTprepaymentWithProduct:(MTGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(MTGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)mTfetchIAPPreorderAndCheckReceiptIsValid:(MTGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(MTGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
