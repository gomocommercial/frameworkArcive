//
// Created by zhangjiemin on 2018/7/4.
//

#import <Foundation/Foundation.h>
#import "PPP_PGMPayCusConfigModel.h"

#define GM_PURPOSE_PURCHASE @"PRODUCT_PURCHASE"
#define GM_PURPOSE_RECHARGE @"VCOIN_RECHARGE"
#define GM_PURPOSE_SUBCRIPTION @"PRODUCT_SUBSCRIPTION"

@interface PPP_PGMPaymentConfig : NSObject
@property (nonatomic,copy) NSString *accessToken;
@property (nonatomic,copy) NSString *accountId;
@property(nonatomic, assign) BOOL isTest;//是否是测试环境 YES代表debug环境
@property(nonatomic, copy) NSString *localPassword;
@property(nonatomic, copy) NSString *staticUUID;

/**
 提示：初始化配置时，若cusConfigModelbu不为空时，PaymentSDKUrl和CheckPayReceiptUrl中配置的域名将失效（仅域名，其他配置有效）
 */
- (void)pPP_PinitPaymentConfigDebugWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password isIpUrl:(BOOL)isIpUrl cusConfigModel: (PPP_PGMPayCusConfigModel *)cusConfig;

/**
 提示：初始化配置时，若cusConfigModelbu不为空时，PaymentSDKUrl和CheckPayReceiptUrl中配置的域名将失效（仅域名，其他配置有效）
 */
- (void)pPP_PinitPaymentConfigReleaseWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password isIpUrl:(BOOL)isIpUrl cusConfigModel: (PPP_PGMPayCusConfigModel *)cusConfig;

- (NSString *)pPP_PgetPayStateDomain;

- (NSString *)pPP_PgetSignatureKey;

- (NSString *)pPP_PgetClientID;

- (NSString *)pPP_PgetStaticUUID;

- (void)setStaticUUID:(NSString *)uuid;

+ (instancetype)pPP_PsharedManger;
@end
