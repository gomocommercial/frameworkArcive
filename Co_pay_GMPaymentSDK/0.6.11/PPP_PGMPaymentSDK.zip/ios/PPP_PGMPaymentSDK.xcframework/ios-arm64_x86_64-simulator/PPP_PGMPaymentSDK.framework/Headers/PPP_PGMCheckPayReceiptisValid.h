//
//  PPP_PGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "PPP_PGMProductModel.h"
#import "PPP_PPayNotificationHTTPResponse.h"
#import <PPP_PGMPaymentSDK/PPP_PGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface PPP_PGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^PPP_PGMCkeckPayStateApiCompleteBlock) (PPP_PPayNotificationHTTPResponse *gmresponse);
typedef void (^PPP_PGMPrePaymentApiCompleteBlock) (PPP_PPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (PPP_PGMCheckPayReceiptisValid *)pPP_PsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)pPP_PprepaymentWithProduct:(PPP_PGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(PPP_PGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)pPP_PfetchIAPPreorderAndCheckReceiptIsValid:(PPP_PGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(PPP_PGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
