//
//  PPP_PGMPayDeviceModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PGMPayDeviceModel : NSObject
+ (NSDictionary *)pPP_Pdevice;
@end

NS_ASSUME_NONNULL_END
