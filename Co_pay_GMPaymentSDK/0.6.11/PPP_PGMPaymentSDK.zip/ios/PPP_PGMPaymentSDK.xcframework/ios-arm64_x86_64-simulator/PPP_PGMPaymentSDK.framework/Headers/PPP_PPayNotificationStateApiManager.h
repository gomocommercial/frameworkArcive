//
//  PPP_PPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PPP_PPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "PPP_PPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^PPP_PPayNotificationStateApiCompleteBlock) (PPP_PPayNotificationHTTPResponse *response);

@interface PPP_PPayNotificationStateApiManager : AFHTTPSessionManager
+ (PPP_PPayNotificationStateApiManager *)pPP_PsharedManager;
//支付成功新增后台 通知接口
-(void)pPP_PcheckiOSIAPPayOrderWithPayNotificationModel:(PPP_PPayNotificationModel *)payNotificationModel  complete:(PPP_PPayNotificationStateApiCompleteBlock)complete;
-(void)pPP_PgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(PPP_PPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
