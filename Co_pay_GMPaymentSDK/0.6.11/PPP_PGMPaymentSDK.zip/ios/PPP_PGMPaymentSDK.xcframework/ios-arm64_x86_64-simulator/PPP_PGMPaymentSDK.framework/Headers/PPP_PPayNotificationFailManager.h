//
//  PPP_PPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "PPP_PPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)pPP_PsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(PPP_PPayNotificationModel*)pPP_PunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)pPP_PdelSerializedBean:(PPP_PPayNotificationModel*)bean;
+(NSArray <PPP_PPayNotificationModel *>*)pPP_PgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pPP_PretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
