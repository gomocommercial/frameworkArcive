//
//  PPP_P_PayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PPP_P_PayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "PPP_P_PayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^PPP_P_PayNotificationStateApiCompleteBlock) (PPP_P_PayNotificationHTTPResponse *response);

@interface PPP_P_PayNotificationStateApiManager : AFHTTPSessionManager
+ (PPP_P_PayNotificationStateApiManager *)pPP_P_sharedManager;
//支付成功新增后台 通知接口
-(void)pPP_P_checkiOSIAPPayOrderWithPayNotificationModel:(PPP_P_PayNotificationModel *)payNotificationModel  complete:(PPP_P_PayNotificationStateApiCompleteBlock)complete;
-(void)pPP_P_getDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(PPP_P_PayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
