//
//  PPP_P_GMPayDeviceModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_GMPayDeviceModel : NSObject
+ (NSDictionary *)pPP_P_device;
@end

NS_ASSUME_NONNULL_END
