//
//  PPP_P_PayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "PPP_P_PayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_PayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)pPP_P_saveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(PPP_P_PayNotificationModel*)pPP_P_unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)pPP_P_delSerializedBean:(PPP_P_PayNotificationModel*)bean;
+(NSArray <PPP_P_PayNotificationModel *>*)pPP_P_getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pPP_P_retryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
