//
//  CUC_PPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "CUC_PPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)cUC_PsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(CUC_PPayNotificationModel*)cUC_PunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)cUC_PdelSerializedBean:(CUC_PPayNotificationModel*)bean;
+(NSArray <CUC_PPayNotificationModel *>*)cUC_PgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cUC_PretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
