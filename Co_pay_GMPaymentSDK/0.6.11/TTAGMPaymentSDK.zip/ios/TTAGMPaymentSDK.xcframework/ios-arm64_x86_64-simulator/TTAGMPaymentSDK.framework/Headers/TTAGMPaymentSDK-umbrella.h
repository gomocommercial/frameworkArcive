#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TTAGMPaymentConfig.h"
#import "TTAGMIAPManager.h"
#import "TTAGMCheckOrderModel.h"
#import "TTAGMPayCusConfigModel.h"
#import "TTAGMPayDeviceModel.h"
#import "TTAGMProductModel.h"
#import "NSString+TTAPayNotificationSecure.h"
#import "TTACheckPayReceiptistSerializer.h"
#import "TTAGMCheckPayReceiptisValid.h"
#import "TTAGMPaymentSDK.h"
#import "TTAGMPayNotificationConfig.h"
#import "TTAGMPayNotificationDeviceModel.h"
#import "TTAPayNotificationFailManager.h"
#import "TTAPayNotificationHTTPResponse.h"
#import "TTAPayNotificationModel.h"
#import "TTAPayNotificationRequestSerializer.h"
#import "TTAPayNotificationSecureManager.h"
#import "TTAPayNotificationStateApiManager.h"

FOUNDATION_EXPORT double TTAGMPaymentSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char TTAGMPaymentSDKVersionString[];

