//
//  TTAPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TTAPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "TTAPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^TTAPayNotificationStateApiCompleteBlock) (TTAPayNotificationHTTPResponse *response);

@interface TTAPayNotificationStateApiManager : AFHTTPSessionManager
+ (TTAPayNotificationStateApiManager *)tTAsharedManager;
//支付成功新增后台 通知接口
-(void)tTAcheckiOSIAPPayOrderWithPayNotificationModel:(TTAPayNotificationModel *)payNotificationModel  complete:(TTAPayNotificationStateApiCompleteBlock)complete;
-(void)tTAgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(TTAPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
