//
//  MACUGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "MACUGMProductModel.h"
#import "MACUPayNotificationHTTPResponse.h"
#import <MACUGMPaymentSDK/MACUGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface MACUGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^MACUGMCkeckPayStateApiCompleteBlock) (MACUPayNotificationHTTPResponse *gmresponse);
typedef void (^MACUGMPrePaymentApiCompleteBlock) (MACUPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (MACUGMCheckPayReceiptisValid *)mACUsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)mACUprepaymentWithProduct:(MACUGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(MACUGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)mACUfetchIAPPreorderAndCheckReceiptIsValid:(MACUGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(MACUGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
