//
//  MACUPayNotificationModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MACUPayNotificationModel : NSObject<NSCoding>

@property (nonatomic, copy) NSString *uuid;

@property (nonatomic, copy) NSString *product_id;

//不再使用交易凭证
//@property (nonatomic, copy) NSString *receipt;

//苹果支付的原始订单id
@property (nonatomic, copy) NSString *originalTransactionId;
//我们自己服务器生成的交易订单号
@property (nonatomic, copy) NSString *tran_id;

@end

NS_ASSUME_NONNULL_END
