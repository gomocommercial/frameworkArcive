#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MACUGMPaymentConfig.h"
#import "MACUGMIAPManager.h"
#import "MACUCheckPayReceiptistSerializer.h"
#import "MACUGMCheckPayReceiptisValid.h"
#import "MACUGMPaymentSDK.h"
#import "MACUGMPayNotificationConfig.h"
#import "MACUGMPayNotificationDeviceModel.h"
#import "MACUPayNotificationFailManager.h"
#import "MACUPayNotificationHTTPResponse.h"
#import "MACUPayNotificationModel.h"
#import "MACUPayNotificationRequestSerializer.h"
#import "MACUPayNotificationSecureManager.h"
#import "MACUPayNotificationStateApiManager.h"
#import "MACUGMCheckOrderModel.h"
#import "MACUGMPayCusConfigModel.h"
#import "MACUGMPayDeviceModel.h"
#import "MACUGMProductModel.h"
#import "NSString+MACUPayNotificationSecure.h"

FOUNDATION_EXPORT double MACUGMPaymentSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char MACUGMPaymentSDKVersionString[];

