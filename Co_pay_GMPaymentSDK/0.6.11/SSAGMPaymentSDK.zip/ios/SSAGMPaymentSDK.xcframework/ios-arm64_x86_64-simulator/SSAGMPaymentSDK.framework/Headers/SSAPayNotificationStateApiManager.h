//
//  SSAPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SSAPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "SSAPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^SSAPayNotificationStateApiCompleteBlock) (SSAPayNotificationHTTPResponse *response);

@interface SSAPayNotificationStateApiManager : AFHTTPSessionManager
+ (SSAPayNotificationStateApiManager *)sSAsharedManager;
//支付成功新增后台 通知接口
-(void)sSAcheckiOSIAPPayOrderWithPayNotificationModel:(SSAPayNotificationModel *)payNotificationModel  complete:(SSAPayNotificationStateApiCompleteBlock)complete;
-(void)sSAgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(SSAPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
