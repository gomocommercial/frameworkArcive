#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "SSAGMPaymentConfig.h"
#import "SSAGMIAPManager.h"
#import "SSAGMCheckOrderModel.h"
#import "SSAGMPayCusConfigModel.h"
#import "SSAGMPayDeviceModel.h"
#import "SSAGMProductModel.h"
#import "NSString+SSAPayNotificationSecure.h"
#import "SSACheckPayReceiptistSerializer.h"
#import "SSAGMCheckPayReceiptisValid.h"
#import "SSAGMPaymentSDK.h"
#import "SSAGMPayNotificationConfig.h"
#import "SSAGMPayNotificationDeviceModel.h"
#import "SSAPayNotificationFailManager.h"
#import "SSAPayNotificationHTTPResponse.h"
#import "SSAPayNotificationModel.h"
#import "SSAPayNotificationRequestSerializer.h"
#import "SSAPayNotificationSecureManager.h"
#import "SSAPayNotificationStateApiManager.h"

FOUNDATION_EXPORT double SSAGMPaymentSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char SSAGMPaymentSDKVersionString[];

