//
//  SSAPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "SSAPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SSAPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)sSAsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(SSAPayNotificationModel*)sSAunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)sSAdelSerializedBean:(SSAPayNotificationModel*)bean;
+(NSArray <SSAPayNotificationModel *>*)sSAgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sSAretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
