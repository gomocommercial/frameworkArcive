//
//  MLCGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "MLCGMProductModel.h"
#import "MLCPayNotificationHTTPResponse.h"
#import <MLCGMPaymentSDK/MLCGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface MLCGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^MLCGMCkeckPayStateApiCompleteBlock) (MLCPayNotificationHTTPResponse *gmresponse);
typedef void (^MLCGMPrePaymentApiCompleteBlock) (MLCPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (MLCGMCheckPayReceiptisValid *)mLCsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)mLCprepaymentWithProduct:(MLCGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(MLCGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)mLCfetchIAPPreorderAndCheckReceiptIsValid:(MLCGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(MLCGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
