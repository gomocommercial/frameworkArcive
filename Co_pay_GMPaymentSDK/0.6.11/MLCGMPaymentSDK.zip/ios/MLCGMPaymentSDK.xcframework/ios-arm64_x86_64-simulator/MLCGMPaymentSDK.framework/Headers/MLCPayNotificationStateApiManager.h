//
//  MLCPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MLCPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "MLCPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^MLCPayNotificationStateApiCompleteBlock) (MLCPayNotificationHTTPResponse *response);

@interface MLCPayNotificationStateApiManager : AFHTTPSessionManager
+ (MLCPayNotificationStateApiManager *)mLCsharedManager;
//支付成功新增后台 通知接口
-(void)mLCcheckiOSIAPPayOrderWithPayNotificationModel:(MLCPayNotificationModel *)payNotificationModel  complete:(MLCPayNotificationStateApiCompleteBlock)complete;
-(void)mLCgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(MLCPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
