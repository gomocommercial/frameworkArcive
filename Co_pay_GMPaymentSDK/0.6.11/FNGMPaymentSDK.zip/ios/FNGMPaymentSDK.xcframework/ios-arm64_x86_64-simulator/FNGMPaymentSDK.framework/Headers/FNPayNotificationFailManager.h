//
//  FNPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "FNPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)fNsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(FNPayNotificationModel*)fNunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)fNdelSerializedBean:(FNPayNotificationModel*)bean;
+(NSArray <FNPayNotificationModel *>*)fNgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fNretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
