//
//  FNPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FNPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "FNPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^FNPayNotificationStateApiCompleteBlock) (FNPayNotificationHTTPResponse *response);

@interface FNPayNotificationStateApiManager : AFHTTPSessionManager
+ (FNPayNotificationStateApiManager *)fNsharedManager;
//支付成功新增后台 通知接口
-(void)fNcheckiOSIAPPayOrderWithPayNotificationModel:(FNPayNotificationModel *)payNotificationModel  complete:(FNPayNotificationStateApiCompleteBlock)complete;
-(void)fNgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(FNPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
