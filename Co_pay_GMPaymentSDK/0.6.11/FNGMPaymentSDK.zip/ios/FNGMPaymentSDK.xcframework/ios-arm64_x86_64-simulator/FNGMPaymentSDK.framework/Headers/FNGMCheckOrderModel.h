//
//  FNGMCheckOrderModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FNGMCheckOrderModel : NSObject

@property (nonatomic, copy) NSString *environment;//environment = Sandbox;
/*
 receipt =     {
    "adam_id" = 0;
    "app_item_id" = 0;
    "application_version" = 2;
    "bundle_id" = "com.meditation.relax";
    "download_id" = 0;
    "original_application_version" = "1.0";
    "original_purchase_date" = "2013-08-01 07:00:00 Etc/GMT";
    "original_purchase_date_ms" = 1375340400000;
    "original_purchase_date_pst" = "2013-08-01 00:00:00 America/Los_Angeles";
    "receipt_creation_date" = "2018-12-26 06:46:16 Etc/GMT";
    "receipt_creation_date_ms" = 1545806776000;
    "receipt_creation_date_pst" = "2018-12-25 22:46:16 America/Los_Angeles";
    "receipt_type" = ProductionSandbox;
    "request_date" = "2018-12-26 06:46:20 Etc/GMT";
    "request_date_ms" = 1545806780814;
    "request_date_pst" = "2018-12-25 22:46:20 America/Los_Angeles";
    "version_external_identifier" = 0;
    "in_app" =         (
        {
        "expires_date" = "2018-12-25 07:10:45 Etc/GMT";
        "expires_date_ms" = 1545721845000;
        "expires_date_pst" = "2018-12-24 23:10:45 America/Los_Angeles";
        "is_in_intro_offer_period" = false;
        "is_trial_period" = false;
        "original_purchase_date" = "2018-12-25 07:05:45 Etc/GMT";
        "original_purchase_date_ms" = 1545721545000;
        "original_purchase_date_pst" = "2018-12-24 23:05:45 America/Los_Angeles";
        "original_transaction_id" = 1000000489696980;
        "product_id" = "hexa.puzzle.game.block899_1";
        "purchase_date" = "2018-12-25 07:05:45 Etc/GMT";
        "purchase_date_ms" = 1545721545000;
        "purchase_date_pst" = "2018-12-24 23:05:45 America/Los_Angeles";
        quantity = 1;
        "transaction_id" = 1000000489696980;
        "web_order_line_item_id" = 1000000041965351;
        }
    )
 }
 
 */
@property (nonatomic, copy) NSDictionary *receipt;//凭证解析出来的信息, 里面包括所有的订单
@property (nonatomic, assign) NSInteger status;// = 0成功
@property (nonatomic, copy) NSString *latest_receipt;//最新凭证
/*
 "latest_receipt_info" =     (
    {
    "expires_date" = "2018-12-26 03:08:18 Etc/GMT";到期时间
    "expires_date_ms" = 1545793698000;到期时间毫秒
    "expires_date_pst" = "2018-12-25 19:08:18 America/Los_Angeles";到期时间（太平洋的时间
    "is_in_intro_offer_period" = false;对于自动更新订阅，无论它是否处于介绍性价格期间。
    "is_trial_period" = false;对于订阅，是否在免费试用期间。
    "original_purchase_date" = "2018-12-25 07:05:45 Etc/GMT";最初的购买时间
    "original_purchase_date_ms" = 1545721545000;最初的购买时间毫秒
    "original_purchase_date_pst" = "2018-12-24 23:05:45 America/Los_Angeles";最初的购买时间（太平洋的时间）
    "original_transaction_id" = 1000000489696980;
    "product_id" = "hexa.puzzle.game.block899_1";产品id
    "purchase_date" = "2018-12-26 03:03:18 Etc/GMT";最新的购买时间
    "purchase_date_ms" = 1545793398000;最新的购买时间毫秒
    "purchase_date_pst" = "2018-12-25 19:03:18 America/Los_Angeles";最新的购买时间（太平洋的时间）
    quantity = 1;
    "transaction_id" = 1000000489829331;
    "web_order_line_item_id" = 1000000041971628;
    }
 );
 */
@property (nonatomic, copy) NSArray *latest_receipt_info;//最新凭证详情（可能会有多个，因为是不同组的产品，产品id是不同的）

/*
 "pending_renewal_info" =     (
    {
    "auto_renew_product_id" = "hexa.puzzle.game.block899_1";
    "auto_renew_status" = 0;
    "expiration_intent" = 1;
    "is_in_billing_retry_period" = 0;
    "original_transaction_id" = 1000000489696980;
    "product_id" = "hexa.puzzle.game.block899_1";
    }
 );
 */
@property (nonatomic, copy) NSArray *pending_renewal_info;//

@end

NS_ASSUME_NONNULL_END
