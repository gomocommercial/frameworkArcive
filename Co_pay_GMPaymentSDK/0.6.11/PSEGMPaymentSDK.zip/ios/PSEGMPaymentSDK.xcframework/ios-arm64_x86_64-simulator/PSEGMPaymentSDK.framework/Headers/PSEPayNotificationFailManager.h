//
//  PSEPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "PSEPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSEPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)pSEsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(PSEPayNotificationModel*)pSEunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)pSEdelSerializedBean:(PSEPayNotificationModel*)bean;
+(NSArray <PSEPayNotificationModel *>*)pSEgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pSEretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
