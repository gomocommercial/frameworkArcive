//
//  JLCPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JLCPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "JLCPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^JLCPayNotificationStateApiCompleteBlock) (JLCPayNotificationHTTPResponse *response);

@interface JLCPayNotificationStateApiManager : AFHTTPSessionManager
+ (JLCPayNotificationStateApiManager *)jLCsharedManager;
//支付成功新增后台 通知接口
-(void)jLCcheckiOSIAPPayOrderWithPayNotificationModel:(JLCPayNotificationModel *)payNotificationModel  complete:(JLCPayNotificationStateApiCompleteBlock)complete;
-(void)jLCgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(JLCPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
