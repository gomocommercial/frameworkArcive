//
//  LDPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LDPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "LDPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^LDPayNotificationStateApiCompleteBlock) (LDPayNotificationHTTPResponse *response);

@interface LDPayNotificationStateApiManager : AFHTTPSessionManager
+ (LDPayNotificationStateApiManager *)lDsharedManager;
//支付成功新增后台 通知接口
-(void)lDcheckiOSIAPPayOrderWithPayNotificationModel:(LDPayNotificationModel *)payNotificationModel  complete:(LDPayNotificationStateApiCompleteBlock)complete;
-(void)lDgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(LDPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
