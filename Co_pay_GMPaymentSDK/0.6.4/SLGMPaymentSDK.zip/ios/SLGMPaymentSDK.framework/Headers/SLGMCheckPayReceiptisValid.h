//
//  SLGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "SLGMProductModel.h"
#import "SLPayNotificationHTTPResponse.h"
#import <SLGMPaymentSDK/SLGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface SLGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^SLGMCkeckPayStateApiCompleteBlock) (SLPayNotificationHTTPResponse *gmresponse);
+ (SLGMCheckPayReceiptisValid *)sLsharedManager;
-(void)sLfetchIAPPreorderAndCheckReceiptIsValid:(SLGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(SLGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
