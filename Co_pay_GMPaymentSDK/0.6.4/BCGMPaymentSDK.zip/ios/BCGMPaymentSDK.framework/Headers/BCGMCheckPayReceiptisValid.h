//
//  BCGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "BCGMProductModel.h"
#import "BCPayNotificationHTTPResponse.h"
#import <BCGMPaymentSDK/BCGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface BCGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^BCGMCkeckPayStateApiCompleteBlock) (BCPayNotificationHTTPResponse *gmresponse);
+ (BCGMCheckPayReceiptisValid *)bCsharedManager;
-(void)bCfetchIAPPreorderAndCheckReceiptIsValid:(BCGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(BCGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
