//
//  BCPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BCPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "BCPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^BCPayNotificationStateApiCompleteBlock) (BCPayNotificationHTTPResponse *response);

@interface BCPayNotificationStateApiManager : AFHTTPSessionManager
+ (BCPayNotificationStateApiManager *)bCsharedManager;
//支付成功新增后台 通知接口
-(void)bCcheckiOSIAPPayOrderWithPayNotificationModel:(BCPayNotificationModel *)payNotificationModel  complete:(BCPayNotificationStateApiCompleteBlock)complete;
-(void)bCgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(BCPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
