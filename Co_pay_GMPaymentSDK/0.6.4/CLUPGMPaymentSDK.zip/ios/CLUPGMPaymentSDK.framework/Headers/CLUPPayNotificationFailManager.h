//
//  CLUPPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "CLUPPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CLUPPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)cLUPsaveToCacheWithProductId:(NSString *)product_id;
+(CLUPPayNotificationModel*)cLUPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)cLUPdelSerializedBean:(CLUPPayNotificationModel*)bean;
+(NSArray <CLUPPayNotificationModel *>*)cLUPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cLUPretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
