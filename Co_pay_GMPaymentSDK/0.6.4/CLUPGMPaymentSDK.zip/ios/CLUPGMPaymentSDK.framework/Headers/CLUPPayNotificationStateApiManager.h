//
//  CLUPPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLUPPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "CLUPPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^CLUPPayNotificationStateApiCompleteBlock) (CLUPPayNotificationHTTPResponse *response);

@interface CLUPPayNotificationStateApiManager : AFHTTPSessionManager
+ (CLUPPayNotificationStateApiManager *)cLUPsharedManager;
//支付成功新增后台 通知接口
-(void)cLUPcheckiOSIAPPayOrderWithPayNotificationModel:(CLUPPayNotificationModel *)payNotificationModel  complete:(CLUPPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
