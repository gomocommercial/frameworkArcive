//
//  DCPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "DCPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)dCsaveToCacheWithProductId:(NSString *)product_id;
+(DCPayNotificationModel*)dCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)dCdelSerializedBean:(DCPayNotificationModel*)bean;
+(NSArray <DCPayNotificationModel *>*)dCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)dCretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
