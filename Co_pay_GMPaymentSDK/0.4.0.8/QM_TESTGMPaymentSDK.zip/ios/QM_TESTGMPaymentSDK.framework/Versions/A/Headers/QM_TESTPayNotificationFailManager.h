//
//  QM_TESTPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "QM_TESTPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface QM_TESTPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)qM_TESTsaveToCacheWithProductId:(NSString *)product_id;
+(QM_TESTPayNotificationModel*)qM_TESTunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)qM_TESTdelSerializedBean:(QM_TESTPayNotificationModel*)bean;
+(NSArray <QM_TESTPayNotificationModel *>*)qM_TESTgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)qM_TESTretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
