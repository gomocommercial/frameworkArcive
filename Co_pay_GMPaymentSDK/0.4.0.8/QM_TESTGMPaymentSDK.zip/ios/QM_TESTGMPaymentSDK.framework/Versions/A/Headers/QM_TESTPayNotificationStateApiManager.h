//
//  QM_TESTPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QM_TESTPayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "QM_TESTPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^QM_TESTPayNotificationStateApiCompleteBlock) (QM_TESTPayNotificationHTTPResponse *response);

@interface QM_TESTPayNotificationStateApiManager : AFHTTPSessionManager
+ (QM_TESTPayNotificationStateApiManager *)qM_TESTsharedManager;
//支付成功新增后台 通知接口
-(void)qM_TESTcheckiOSIAPPayOrderWithPayNotificationModel:(QM_TESTPayNotificationModel *)payNotificationModel  complete:(QM_TESTPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
