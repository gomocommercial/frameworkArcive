//
//  MJPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "MJPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^MJPayNotificationStateApiCompleteBlock) (MJPayNotificationHTTPResponse *response);

@interface MJPayNotificationStateApiManager : AFHTTPSessionManager
+ (MJPayNotificationStateApiManager *)mJsharedManager;
//支付成功新增后台 通知接口
-(void)mJcheckiOSIAPPayOrderWithPayNotificationModel:(MJPayNotificationModel *)payNotificationModel  complete:(MJPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
