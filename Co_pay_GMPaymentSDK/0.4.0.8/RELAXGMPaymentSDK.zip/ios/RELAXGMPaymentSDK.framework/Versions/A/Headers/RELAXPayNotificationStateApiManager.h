//
//  RELAXPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RELAXPayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "RELAXPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^RELAXPayNotificationStateApiCompleteBlock) (RELAXPayNotificationHTTPResponse *response);

@interface RELAXPayNotificationStateApiManager : AFHTTPSessionManager
+ (RELAXPayNotificationStateApiManager *)rELAXsharedManager;
//支付成功新增后台 通知接口
-(void)rELAXcheckiOSIAPPayOrderWithPayNotificationModel:(RELAXPayNotificationModel *)payNotificationModel  complete:(RELAXPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
