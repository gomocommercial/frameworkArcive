//
//  RELAXPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "RELAXPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface RELAXPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)rELAXsaveToCacheWithProductId:(NSString *)product_id;
+(RELAXPayNotificationModel*)rELAXunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)rELAXdelSerializedBean:(RELAXPayNotificationModel*)bean;
+(NSArray <RELAXPayNotificationModel *>*)rELAXgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)rELAXretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
