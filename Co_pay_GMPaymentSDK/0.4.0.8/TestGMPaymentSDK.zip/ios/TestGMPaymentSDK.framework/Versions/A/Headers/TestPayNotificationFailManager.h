//
//  TestPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "TestPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TestPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)testsaveToCacheWithProductId:(NSString *)product_id;
+(TestPayNotificationModel*)testunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)testdelSerializedBean:(TestPayNotificationModel*)bean;
+(NSArray <TestPayNotificationModel *>*)testgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)testretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
