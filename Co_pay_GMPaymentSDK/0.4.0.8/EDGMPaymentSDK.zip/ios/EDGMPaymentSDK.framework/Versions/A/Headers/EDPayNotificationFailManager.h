//
//  EDPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "EDPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface EDPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)eDsaveToCacheWithProductId:(NSString *)product_id;
+(EDPayNotificationModel*)eDunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)eDdelSerializedBean:(EDPayNotificationModel*)bean;
+(NSArray <EDPayNotificationModel *>*)eDgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)eDretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
