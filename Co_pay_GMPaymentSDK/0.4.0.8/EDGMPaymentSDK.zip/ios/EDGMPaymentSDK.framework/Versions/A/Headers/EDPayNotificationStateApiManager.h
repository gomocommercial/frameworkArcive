//
//  EDPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EDPayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "EDPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^EDPayNotificationStateApiCompleteBlock) (EDPayNotificationHTTPResponse *response);

@interface EDPayNotificationStateApiManager : AFHTTPSessionManager
+ (EDPayNotificationStateApiManager *)eDsharedManager;
//支付成功新增后台 通知接口
-(void)eDcheckiOSIAPPayOrderWithPayNotificationModel:(EDPayNotificationModel *)payNotificationModel  complete:(EDPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
