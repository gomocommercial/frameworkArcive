//
//  FBGMIAPManager.h
//  GLive
//
//  Created by Gordon Su on 2017/5/26.
//  Copyright © 2017年 3g.cn. All rights reserved.
//




#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
#import "FBGMCheckOrderModel.h"
#define GMPaymentSDKLog(fmt, ...) NSLog((@"%s[Line %d] GMPaymentSDK:" fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);

@class FBGMIAPManager;
@class FBGMProductModel;
@class GMNetHTTPResponse;

typedef void (^FBPayCheckComplete)(BOOL success, FBGMProductModel *productModel, GMNetHTTPResponse *response);

@protocol FBIAPManagerDelegate <NSObject>

@optional

/**
 * 查询商品列表失败
 *
 * @param manager
 * @param request
 * @param error
 */
- (void)gmIAPManager:(FBGMIAPManager*) manager iapRequest:(SKRequest *)request didFailWithError:(NSError *)error;

/**
 * 查询商品列表成功
 *
 * @param manager
 * @param productList
 * @param request
 */
- (void)gmIAPManager:(FBGMIAPManager *)manager withProductList:(NSArray<SKProduct *> *)productList iapRequestDidFinish:(SKRequest *)request;

/**
 交易成功
 */
- (void)gmIAPManager:(FBGMIAPManager *)manager iapPaymentSuccess:(FBGMProductModel *)productModel transaction:(SKPaymentTransaction *)transaction;

/**
 * 重复购买的回调
 * @param manager
 * @param transaction
 */
-(void)gmIAPManager:(FBGMIAPManager *)manager iapPaymentRepay:(SKPaymentTransaction *)transaction;


/**
 * 购买还原(restore)
 * @param manager
 * @param response
 */
-(void)gmIAPManager:(FBGMIAPManager *)manager iapPaymentRestore:(FBGMCheckOrderModel *)checkOrderModel;

/**
 交易失败
 */
- (void)gmIAPManager:(FBGMIAPManager*) manager iapPaymentFail:(SKPaymentTransaction *)transaction;

/**
 * 没有权限进行购买，需要提示用户开启购买权限
 * @param manager manager实例
 */
-(void)gmIAPManagerNoPermission:(FBGMIAPManager *)manager;

/**
 * 恢复购买失败
 * @param queue
 * @param error
 */
- (void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error;

@end



@interface FBGMIAPManager : NSObject<SKPaymentTransactionObserver>

//是否打开log日志 默认不打开
@property (nonatomic, assign) BOOL enableLog;

/**
 * 回调
 */
@property (nonatomic, weak) id<FBIAPManagerDelegate> delegate;

/**
 * 单例
 * @return
 */
+ (FBGMIAPManager *)fBsharedManager;

/**
 * 刷新所有的产品
 * @param identifiesList
 */
- (void)fBrefreshAllProductsWithIdentifies:(NSSet <NSString *> *)identifiesList;

/**
 * 购买商品
 * @param product
 * @param purpose
 */
- (void)fBpayWithProduct:(FBGMProductModel *)product withPurpose:(NSString *)purpose ;

/**
 * 客户端一般不需要主动调用，除非一直有异常订单，
 * SDK处理失败，可以使用此接口结束异常订单的回调
 * @param transaction 交易Model
 * @param isRemoveCopy  是否移除本地的存储，如果后面不再需要此次订单信息，则建议移除
 */
- (void)fBcompleteTransaction:(SKPaymentTransaction *)transaction removeCopy:(BOOL)isRemoveCopy;


// 同步旧用户订单
- (void)fBupdateOldUserOrderWithProductId:(NSString *)productId;

/**
 * 基于 receipt 恢复订单
 * @param receipt  用户交易凭证
 * @param complete
 */
- (void)fBrestoreCompletedTransactions;

/**
 支付记录实时上传 (即时上传服务器) (59协议)功能点
 
 @param operationCode 操作码
 @param statisticsObject 统计对象
 @param associationObject 关联对象 购买成功价格(以分为单位)
 @param tab Tab分类
 @param position 购买成功时，上传谷歌或第三方订单编号
 @param entrance 入口
 @param remark 备注: 部分支付方式，例如fortumo，取不到用户相关的帐号信息，则此字段为空）
 @param orderType 订单来源; 1：普通内购，2：订阅
 @param result 操作结果; 0：点击购买，1：购买成功
 */
+(void)fBpostUserRealtimePayMentStatisticOperationCode:(NSString *)operationCode
                                     statisticsObject:(NSString *)statisticsObject
                                    associationObject:(NSString *)associationObject
                                                  tab:(NSString *)tab
                                             position:(NSString *)position
                                             entrance:(NSString *)entrance
                                               remark:(NSString *)remark
                                            orderType:(NSInteger)orderType
                                            resultObj:(NSString *)result;

//新增优化支付sdk
//获取当前苹果的验单结果信息
//latest_receipt 最新凭证
//latest_receipt_info 最新凭证详情（可能会有多个，因为是不同组的产品，产品id是不同的)
-(void)fBgetCurrentAllOrderInfoFromAppleWithcomplete:(void (^)(FBGMCheckOrderModel *checkOrderModel))result;
//获取当前时间戳(毫秒级别)
-(void)fBgetCurrentServiceTimeIntervalComplete:(void (^)(NSTimeInterval timeInterval))complete;
@end


