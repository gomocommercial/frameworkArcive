//
//  FBPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "FBPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FBPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)fBsaveToCacheWithProductId:(NSString *)product_id;
+(FBPayNotificationModel*)fBunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)fBdelSerializedBean:(FBPayNotificationModel*)bean;
+(NSArray <FBPayNotificationModel *>*)fBgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fBretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
