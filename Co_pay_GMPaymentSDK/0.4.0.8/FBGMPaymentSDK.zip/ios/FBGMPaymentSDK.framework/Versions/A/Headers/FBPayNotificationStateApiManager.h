//
//  FBPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FBPayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "FBPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^FBPayNotificationStateApiCompleteBlock) (FBPayNotificationHTTPResponse *response);

@interface FBPayNotificationStateApiManager : AFHTTPSessionManager
+ (FBPayNotificationStateApiManager *)fBsharedManager;
//支付成功新增后台 通知接口
-(void)fBcheckiOSIAPPayOrderWithPayNotificationModel:(FBPayNotificationModel *)payNotificationModel  complete:(FBPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
