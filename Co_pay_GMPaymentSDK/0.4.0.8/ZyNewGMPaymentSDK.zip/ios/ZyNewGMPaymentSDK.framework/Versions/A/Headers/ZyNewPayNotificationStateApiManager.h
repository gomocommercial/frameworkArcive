//
//  ZyNewPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZyNewPayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "ZyNewPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^ZyNewPayNotificationStateApiCompleteBlock) (ZyNewPayNotificationHTTPResponse *response);

@interface ZyNewPayNotificationStateApiManager : AFHTTPSessionManager
+ (ZyNewPayNotificationStateApiManager *)zyNewsharedManager;
//支付成功新增后台 通知接口
-(void)zyNewcheckiOSIAPPayOrderWithPayNotificationModel:(ZyNewPayNotificationModel *)payNotificationModel  complete:(ZyNewPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
