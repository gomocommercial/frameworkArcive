//
//  QTPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QTPayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "QTPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^QTPayNotificationStateApiCompleteBlock) (QTPayNotificationHTTPResponse *response);

@interface QTPayNotificationStateApiManager : AFHTTPSessionManager
+ (QTPayNotificationStateApiManager *)qTsharedManager;
//支付成功新增后台 通知接口
-(void)qTcheckiOSIAPPayOrderWithPayNotificationModel:(QTPayNotificationModel *)payNotificationModel  complete:(QTPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
