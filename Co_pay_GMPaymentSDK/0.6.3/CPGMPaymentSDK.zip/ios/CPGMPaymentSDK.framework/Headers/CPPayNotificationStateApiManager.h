//
//  CPPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CPPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "CPPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^CPPayNotificationStateApiCompleteBlock) (CPPayNotificationHTTPResponse *response);

@interface CPPayNotificationStateApiManager : AFHTTPSessionManager
+ (CPPayNotificationStateApiManager *)cPsharedManager;
//支付成功新增后台 通知接口
-(void)cPcheckiOSIAPPayOrderWithPayNotificationModel:(CPPayNotificationModel *)payNotificationModel  complete:(CPPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
