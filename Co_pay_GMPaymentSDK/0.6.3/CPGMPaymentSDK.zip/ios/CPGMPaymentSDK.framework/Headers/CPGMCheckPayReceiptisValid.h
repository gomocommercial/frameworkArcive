//
//  CPGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "CPGMProductModel.h"
#import "CPPayNotificationHTTPResponse.h"
#import <CPGMPaymentSDK/CPGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface CPGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^CPGMCkeckPayStateApiCompleteBlock) (CPPayNotificationHTTPResponse *gmresponse);
+ (CPGMCheckPayReceiptisValid *)cPsharedManager;
-(void)cPfetchIAPPreorderAndCheckReceiptIsValid:(CPGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(CPGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
