//
//  CPPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "CPPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)cPsaveToCacheWithProductId:(NSString *)product_id;
+(CPPayNotificationModel*)cPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)cPdelSerializedBean:(CPPayNotificationModel*)bean;
+(NSArray <CPPayNotificationModel *>*)cPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cPretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
