//
//  NBPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "NBPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface NBPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)nBsaveToCacheWithProductId:(NSString *)product_id;
+(NBPayNotificationModel*)nBunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)nBdelSerializedBean:(NBPayNotificationModel*)bean;
+(NSArray <NBPayNotificationModel *>*)nBgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)nBretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
