//
//  NBPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NBPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "NBPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^NBPayNotificationStateApiCompleteBlock) (NBPayNotificationHTTPResponse *response);

@interface NBPayNotificationStateApiManager : AFHTTPSessionManager
+ (NBPayNotificationStateApiManager *)nBsharedManager;
//支付成功新增后台 通知接口
-(void)nBcheckiOSIAPPayOrderWithPayNotificationModel:(NBPayNotificationModel *)payNotificationModel  complete:(NBPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
