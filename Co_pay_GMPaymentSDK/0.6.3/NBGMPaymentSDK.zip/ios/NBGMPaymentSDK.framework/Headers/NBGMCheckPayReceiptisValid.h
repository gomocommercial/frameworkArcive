//
//  NBGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "NBGMProductModel.h"
#import "NBPayNotificationHTTPResponse.h"
#import <NBGMPaymentSDK/NBGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface NBGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^NBGMCkeckPayStateApiCompleteBlock) (NBPayNotificationHTTPResponse *gmresponse);
+ (NBGMCheckPayReceiptisValid *)nBsharedManager;
-(void)nBfetchIAPPreorderAndCheckReceiptIsValid:(NBGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(NBGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
