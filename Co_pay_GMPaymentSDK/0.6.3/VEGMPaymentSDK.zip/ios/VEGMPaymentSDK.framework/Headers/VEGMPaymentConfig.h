//
// Created by zhangjiemin on 2018/7/4.
//

#import <Foundation/Foundation.h>

#define GM_PURPOSE_PURCHASE @"PRODUCT_PURCHASE"
#define GM_PURPOSE_RECHARGE @"VCOIN_RECHARGE"
#define GM_PURPOSE_SUBCRIPTION @"PRODUCT_SUBSCRIPTION"

@interface VEGMPaymentConfig : NSObject
@property (nonatomic,copy) NSString *accessToken;
@property (nonatomic,copy) NSString *accountId;
@property(nonatomic, assign) BOOL isTest;//是否是测试环境 YES代表debug环境
@property(nonatomic, copy) NSString *localPassword;
@property(nonatomic, copy) NSString *staticUUID;

- (void)vEinitPaymentConfigDebugWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password isIpUrl:(BOOL)isIpUrl ;

- (void)vEinitPaymentConfigReleaseWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password isIpUrl:(BOOL)isIpUrl ;

- (NSString *)vEgetPayStateDomain;

- (NSString *)vEgetSignatureKey;

- (NSString *)vEgetClientID;

- (NSString *)vEgetStaticUUID;

- (void)setStaticUUID:(NSString *)uuid;

+ (instancetype)vEsharedManger;
@end
