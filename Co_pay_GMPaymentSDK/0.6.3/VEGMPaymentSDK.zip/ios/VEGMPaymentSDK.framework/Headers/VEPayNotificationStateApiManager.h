//
//  VEPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VEPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "VEPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^VEPayNotificationStateApiCompleteBlock) (VEPayNotificationHTTPResponse *response);

@interface VEPayNotificationStateApiManager : AFHTTPSessionManager
+ (VEPayNotificationStateApiManager *)vEsharedManager;
//支付成功新增后台 通知接口
-(void)vEcheckiOSIAPPayOrderWithPayNotificationModel:(VEPayNotificationModel *)payNotificationModel  complete:(VEPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
