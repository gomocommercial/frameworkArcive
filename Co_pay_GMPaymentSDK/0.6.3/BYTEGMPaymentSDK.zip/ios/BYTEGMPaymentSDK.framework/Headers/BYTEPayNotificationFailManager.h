//
//  BYTEPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "BYTEPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BYTEPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)bYTEsaveToCacheWithProductId:(NSString *)product_id;
+(BYTEPayNotificationModel*)bYTEunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)bYTEdelSerializedBean:(BYTEPayNotificationModel*)bean;
+(NSArray <BYTEPayNotificationModel *>*)bYTEgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)bYTEretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
