//
//  DCPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DCPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "DCPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^DCPayNotificationStateApiCompleteBlock) (DCPayNotificationHTTPResponse *response);

@interface DCPayNotificationStateApiManager : AFHTTPSessionManager
+ (DCPayNotificationStateApiManager *)dCsharedManager;
//支付成功新增后台 通知接口
-(void)dCcheckiOSIAPPayOrderWithPayNotificationModel:(DCPayNotificationModel *)payNotificationModel  complete:(DCPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
