//
//  AJPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "AJPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AJPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)aJsaveToCacheWithProductId:(NSString *)product_id;
+(AJPayNotificationModel*)aJunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)aJdelSerializedBean:(AJPayNotificationModel*)bean;
+(NSArray <AJPayNotificationModel *>*)aJgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)aJretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
