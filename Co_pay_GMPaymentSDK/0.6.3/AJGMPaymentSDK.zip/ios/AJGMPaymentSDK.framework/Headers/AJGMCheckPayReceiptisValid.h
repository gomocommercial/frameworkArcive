//
//  AJGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "AJGMProductModel.h"
#import "AJPayNotificationHTTPResponse.h"
#import <AJGMPaymentSDK/AJGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface AJGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^AJGMCkeckPayStateApiCompleteBlock) (AJPayNotificationHTTPResponse *gmresponse);
+ (AJGMCheckPayReceiptisValid *)aJsharedManager;
-(void)aJfetchIAPPreorderAndCheckReceiptIsValid:(AJGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(AJGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
