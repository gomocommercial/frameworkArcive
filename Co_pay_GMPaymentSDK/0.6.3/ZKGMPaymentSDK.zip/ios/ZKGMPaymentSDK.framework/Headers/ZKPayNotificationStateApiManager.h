//
//  ZKPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZKPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "ZKPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^ZKPayNotificationStateApiCompleteBlock) (ZKPayNotificationHTTPResponse *response);

@interface ZKPayNotificationStateApiManager : AFHTTPSessionManager
+ (ZKPayNotificationStateApiManager *)zKsharedManager;
//支付成功新增后台 通知接口
-(void)zKcheckiOSIAPPayOrderWithPayNotificationModel:(ZKPayNotificationModel *)payNotificationModel  complete:(ZKPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
