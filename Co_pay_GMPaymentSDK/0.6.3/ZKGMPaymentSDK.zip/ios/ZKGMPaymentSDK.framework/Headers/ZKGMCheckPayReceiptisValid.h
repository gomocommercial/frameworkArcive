//
//  ZKGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "ZKGMProductModel.h"
#import "ZKPayNotificationHTTPResponse.h"
#import <ZKGMPaymentSDK/ZKGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface ZKGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^ZKGMCkeckPayStateApiCompleteBlock) (ZKPayNotificationHTTPResponse *gmresponse);
+ (ZKGMCheckPayReceiptisValid *)zKsharedManager;
-(void)zKfetchIAPPreorderAndCheckReceiptIsValid:(ZKGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(ZKGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
