//
//  CSPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CSPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "CSPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^CSPayNotificationStateApiCompleteBlock) (CSPayNotificationHTTPResponse *response);

@interface CSPayNotificationStateApiManager : AFHTTPSessionManager
+ (CSPayNotificationStateApiManager *)cSsharedManager;
//支付成功新增后台 通知接口
-(void)cScheckiOSIAPPayOrderWithPayNotificationModel:(CSPayNotificationModel *)payNotificationModel  complete:(CSPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
