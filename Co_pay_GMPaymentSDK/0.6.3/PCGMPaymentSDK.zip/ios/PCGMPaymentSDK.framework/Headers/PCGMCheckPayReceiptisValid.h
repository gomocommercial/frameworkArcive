//
//  PCGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "PCGMProductModel.h"
#import "PCPayNotificationHTTPResponse.h"
#import <PCGMPaymentSDK/PCGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface PCGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^PCGMCkeckPayStateApiCompleteBlock) (PCPayNotificationHTTPResponse *gmresponse);
+ (PCGMCheckPayReceiptisValid *)pCsharedManager;
-(void)pCfetchIAPPreorderAndCheckReceiptIsValid:(PCGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(PCGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
