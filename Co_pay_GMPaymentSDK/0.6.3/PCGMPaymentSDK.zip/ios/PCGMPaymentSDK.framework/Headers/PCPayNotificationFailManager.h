//
//  PCPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "PCPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)pCsaveToCacheWithProductId:(NSString *)product_id;
+(PCPayNotificationModel*)pCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)pCdelSerializedBean:(PCPayNotificationModel*)bean;
+(NSArray <PCPayNotificationModel *>*)pCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pCretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
