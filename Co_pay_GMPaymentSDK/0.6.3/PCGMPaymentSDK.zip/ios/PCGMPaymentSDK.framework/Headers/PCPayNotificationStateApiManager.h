//
//  PCPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PCPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "PCPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^PCPayNotificationStateApiCompleteBlock) (PCPayNotificationHTTPResponse *response);

@interface PCPayNotificationStateApiManager : AFHTTPSessionManager
+ (PCPayNotificationStateApiManager *)pCsharedManager;
//支付成功新增后台 通知接口
-(void)pCcheckiOSIAPPayOrderWithPayNotificationModel:(PCPayNotificationModel *)payNotificationModel  complete:(PCPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
