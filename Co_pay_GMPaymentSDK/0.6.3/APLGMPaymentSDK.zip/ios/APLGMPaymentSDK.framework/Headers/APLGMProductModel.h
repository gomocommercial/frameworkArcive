//
// Created by zhangjiemin on 2018/7/5.
//

#import <Foundation/Foundation.h>

@class SKProduct;


@interface APLGMProductModel : NSObject
@property (nonatomic) NSInteger gold_coin;
@property (nonatomic) NSInteger diamond;
@property (nonatomic, copy) NSString *gold_coin_img_url;
@property (nonatomic) float price;
//
@property (nonatomic, strong) NSString *product_id;

@property (nonatomic,copy) NSString *currency_code;
@property (nonatomic,copy) NSString *price_readable;
@property (nonatomic,copy) NSString *product_desc;
@property (nonatomic, copy) NSString* tran_id;  //tran_id
@property (nonatomic, copy) NSString *purpose;   //内购的途径: 订阅为@"PRODUCT_SUBSCRIPTION" 内购为@"PRODUCT_PURCHASE"
@property (nonatomic,strong) SKProduct *product;
@property (nonatomic,strong) NSDictionary *productDic;
@property (nonatomic) Boolean isPayment;
@property (nonatomic) BOOL isNeedCheckOrder;//是否需要服务端验单

- (instancetype)initWithProduct:(SKProduct *)product;


+(instancetype)aPLmodelWithJSON:(NSDictionary *)json;

-(NSDictionary *)aPLmodelToJSONObject;
@end
