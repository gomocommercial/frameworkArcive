//
//  INDOPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "INDOPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface INDOPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)iNDOsaveToCacheWithProductId:(NSString *)product_id;
+(INDOPayNotificationModel*)iNDOunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)iNDOdelSerializedBean:(INDOPayNotificationModel*)bean;
+(NSArray <INDOPayNotificationModel *>*)iNDOgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)iNDOretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
