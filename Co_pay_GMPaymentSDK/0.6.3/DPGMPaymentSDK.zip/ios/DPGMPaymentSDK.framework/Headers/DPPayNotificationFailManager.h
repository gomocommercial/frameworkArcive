//
//  DPPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "DPPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DPPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)dPsaveToCacheWithProductId:(NSString *)product_id;
+(DPPayNotificationModel*)dPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)dPdelSerializedBean:(DPPayNotificationModel*)bean;
+(NSArray <DPPayNotificationModel *>*)dPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)dPretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
