//
//  DPGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "DPGMProductModel.h"
#import "DPPayNotificationHTTPResponse.h"
#import <DPGMPaymentSDK/DPGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface DPGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^DPGMCkeckPayStateApiCompleteBlock) (DPPayNotificationHTTPResponse *gmresponse);
+ (DPGMCheckPayReceiptisValid *)dPsharedManager;
-(void)dPfetchIAPPreorderAndCheckReceiptIsValid:(DPGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(DPGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
