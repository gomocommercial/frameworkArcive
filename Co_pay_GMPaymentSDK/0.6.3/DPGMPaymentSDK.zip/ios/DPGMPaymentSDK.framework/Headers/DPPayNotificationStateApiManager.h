//
//  DPPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DPPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "DPPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^DPPayNotificationStateApiCompleteBlock) (DPPayNotificationHTTPResponse *response);

@interface DPPayNotificationStateApiManager : AFHTTPSessionManager
+ (DPPayNotificationStateApiManager *)dPsharedManager;
//支付成功新增后台 通知接口
-(void)dPcheckiOSIAPPayOrderWithPayNotificationModel:(DPPayNotificationModel *)payNotificationModel  complete:(DPPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
