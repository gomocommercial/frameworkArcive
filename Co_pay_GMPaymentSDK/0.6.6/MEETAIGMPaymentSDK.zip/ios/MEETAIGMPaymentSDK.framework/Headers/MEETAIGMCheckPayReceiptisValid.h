//
//  MEETAIGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "MEETAIGMProductModel.h"
#import "MEETAIPayNotificationHTTPResponse.h"
#import <MEETAIGMPaymentSDK/MEETAIGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface MEETAIGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^MEETAIGMCkeckPayStateApiCompleteBlock) (MEETAIPayNotificationHTTPResponse *gmresponse);
+ (MEETAIGMCheckPayReceiptisValid *)mEETAIsharedManager;
-(void)mEETAIfetchIAPPreorderAndCheckReceiptIsValid:(MEETAIGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(MEETAIGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
