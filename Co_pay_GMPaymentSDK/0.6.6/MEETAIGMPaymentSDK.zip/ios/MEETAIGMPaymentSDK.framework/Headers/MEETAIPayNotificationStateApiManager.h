//
//  MEETAIPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MEETAIPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "MEETAIPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^MEETAIPayNotificationStateApiCompleteBlock) (MEETAIPayNotificationHTTPResponse *response);

@interface MEETAIPayNotificationStateApiManager : AFHTTPSessionManager
+ (MEETAIPayNotificationStateApiManager *)mEETAIsharedManager;
//支付成功新增后台 通知接口
-(void)mEETAIcheckiOSIAPPayOrderWithPayNotificationModel:(MEETAIPayNotificationModel *)payNotificationModel  complete:(MEETAIPayNotificationStateApiCompleteBlock)complete;
-(void)mEETAIgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(MEETAIPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
