//
//  MEETAIPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "MEETAIPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MEETAIPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)mEETAIsaveToCacheWithProductId:(NSString *)product_id;
+(MEETAIPayNotificationModel*)mEETAIunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)mEETAIdelSerializedBean:(MEETAIPayNotificationModel*)bean;
+(NSArray <MEETAIPayNotificationModel *>*)mEETAIgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mEETAIretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
