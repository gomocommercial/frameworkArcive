#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "AWCheckPayReceiptistSerializer.h"
#import "AWGMCheckPayReceiptisValid.h"
#import "AWGMPaymentSDK.h"
#import "AWGMPayNotificationConfig.h"
#import "AWGMPayNotificationDeviceModel.h"
#import "AWPayNotificationFailManager.h"
#import "AWPayNotificationHTTPResponse.h"
#import "AWPayNotificationModel.h"
#import "AWPayNotificationRequestSerializer.h"
#import "AWPayNotificationSecureManager.h"
#import "AWPayNotificationStateApiManager.h"
#import "AWGMPaymentConfig.h"
#import "AWGMIAPManager.h"
#import "AWGMCheckOrderModel.h"
#import "AWGMPayCusConfigModel.h"
#import "AWGMPayDeviceModel.h"
#import "AWGMProductModel.h"
#import "NSString+AWPayNotificationSecure.h"

FOUNDATION_EXPORT double AWGMPaymentSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char AWGMPaymentSDKVersionString[];

