//
//  GMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "GMProductModel.h"
#import "PayNotificationHTTPResponse.h"
#import <GMPaymentSDK/GMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface GMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^GMCkeckPayStateApiCompleteBlock) (PayNotificationHTTPResponse *gmresponse);
+ (GMCheckPayReceiptisValid *)sharedManager;
-(void)fetchIAPPreorderAndCheckReceiptIsValid:(GMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(GMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
