//
//  CUC_PGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "CUC_PGMProductModel.h"
#import "CUC_PPayNotificationHTTPResponse.h"
#import <CUC_PGMPaymentSDK/CUC_PGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface CUC_PGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^CUC_PGMCkeckPayStateApiCompleteBlock) (CUC_PPayNotificationHTTPResponse *gmresponse);
+ (CUC_PGMCheckPayReceiptisValid *)cUC_PsharedManager;
-(void)cUC_PfetchIAPPreorderAndCheckReceiptIsValid:(CUC_PGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(CUC_PGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
