//
//  CUC_PPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CUC_PPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "CUC_PPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^CUC_PPayNotificationStateApiCompleteBlock) (CUC_PPayNotificationHTTPResponse *response);

@interface CUC_PPayNotificationStateApiManager : AFHTTPSessionManager
+ (CUC_PPayNotificationStateApiManager *)cUC_PsharedManager;
//支付成功新增后台 通知接口
-(void)cUC_PcheckiOSIAPPayOrderWithPayNotificationModel:(CUC_PPayNotificationModel *)payNotificationModel  complete:(CUC_PPayNotificationStateApiCompleteBlock)complete;
-(void)cUC_PgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(CUC_PPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
