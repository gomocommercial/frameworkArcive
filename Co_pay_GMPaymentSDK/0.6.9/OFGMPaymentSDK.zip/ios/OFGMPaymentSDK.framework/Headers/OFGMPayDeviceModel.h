//
//  OFGMPayDeviceModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OFGMPayDeviceModel : NSObject
+ (NSDictionary *)oFdevice;
@end

NS_ASSUME_NONNULL_END
