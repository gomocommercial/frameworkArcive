//
//  OFPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OFPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "OFPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^OFPayNotificationStateApiCompleteBlock) (OFPayNotificationHTTPResponse *response);

@interface OFPayNotificationStateApiManager : AFHTTPSessionManager
+ (OFPayNotificationStateApiManager *)oFsharedManager;
//支付成功新增后台 通知接口
-(void)oFcheckiOSIAPPayOrderWithPayNotificationModel:(OFPayNotificationModel *)payNotificationModel  complete:(OFPayNotificationStateApiCompleteBlock)complete;
-(void)oFgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(OFPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
