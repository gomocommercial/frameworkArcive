//
//  OFGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "OFGMProductModel.h"
#import "OFPayNotificationHTTPResponse.h"
#import <OFGMPaymentSDK/OFGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface OFGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^OFGMCkeckPayStateApiCompleteBlock) (OFPayNotificationHTTPResponse *gmresponse);
typedef void (^OFGMPrePaymentApiCompleteBlock) (OFPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (OFGMCheckPayReceiptisValid *)oFsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)oFprepaymentWithProduct:(OFGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(OFGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)oFfetchIAPPreorderAndCheckReceiptIsValid:(OFGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(OFGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
