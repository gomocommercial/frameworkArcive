//
//  PSEGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "PSEGMProductModel.h"
#import "PSEPayNotificationHTTPResponse.h"
#import <PSEGMPaymentSDK/PSEGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface PSEGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^PSEGMCkeckPayStateApiCompleteBlock) (PSEPayNotificationHTTPResponse *gmresponse);
typedef void (^PSEGMPrePaymentApiCompleteBlock) (PSEPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (PSEGMCheckPayReceiptisValid *)pSEsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)pSEprepaymentWithProduct:(PSEGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(PSEGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)pSEfetchIAPPreorderAndCheckReceiptIsValid:(PSEGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(PSEGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
