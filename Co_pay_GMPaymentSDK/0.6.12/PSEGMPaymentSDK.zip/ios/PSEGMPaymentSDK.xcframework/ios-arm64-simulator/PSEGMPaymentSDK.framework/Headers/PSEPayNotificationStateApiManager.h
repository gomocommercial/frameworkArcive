//
//  PSEPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PSEPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "PSEPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^PSEPayNotificationStateApiCompleteBlock) (PSEPayNotificationHTTPResponse *response);

@interface PSEPayNotificationStateApiManager : AFHTTPSessionManager
+ (PSEPayNotificationStateApiManager *)pSEsharedManager;
//支付成功新增后台 通知接口
-(void)pSEcheckiOSIAPPayOrderWithPayNotificationModel:(PSEPayNotificationModel *)payNotificationModel  complete:(PSEPayNotificationStateApiCompleteBlock)complete;
-(void)pSEgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(PSEPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
