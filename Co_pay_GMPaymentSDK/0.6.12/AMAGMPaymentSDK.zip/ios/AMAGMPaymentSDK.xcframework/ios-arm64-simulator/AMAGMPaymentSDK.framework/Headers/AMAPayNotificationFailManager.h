//
//  AMAPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "AMAPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AMAPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)aMAsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(AMAPayNotificationModel*)aMAunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)aMAdelSerializedBean:(AMAPayNotificationModel*)bean;
+(NSArray <AMAPayNotificationModel *>*)aMAgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)aMAretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
