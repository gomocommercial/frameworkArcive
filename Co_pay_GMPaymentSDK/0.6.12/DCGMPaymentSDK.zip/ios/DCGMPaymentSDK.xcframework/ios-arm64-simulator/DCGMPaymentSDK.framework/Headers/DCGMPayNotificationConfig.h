//
//  DCGMPayNotificationConfig.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DCGMPayCusConfigModel.h"

typedef NS_ENUM (NSInteger, PayNotificationMethod) {
    PayNotificationHttpMethodGET = 0,
    PayNotificationMethodPOST,
};
NS_ASSUME_NONNULL_BEGIN

@interface DCGMPayNotificationConfig : NSObject

@property (nonatomic,copy) NSString *accessToken;
@property (nonatomic,copy) NSString *accountId;
@property(nonatomic, assign) BOOL isTest;
@property(nonatomic, copy) NSString *staticUUID;
@property(nonatomic, copy) NSString *clientID;
@property(nonatomic, copy) NSString *xSignatureKey;
@property(nonatomic, copy) NSString *payStateDomain;
@property(nonatomic, copy) NSString *desKey;
@property(nonatomic, copy) NSString *hostHeader;
@property(nonatomic, assign) BOOL isIpUrl;
@property(nonatomic, strong) DCGMPayCusConfigModel *cusConfigModel;

@property(nonatomic, assign)NSInteger desBytesCapacity;
@property(nonatomic, assign)NSInteger requestTimeout;
- (void)dCinitPayNotificationConfigWith:(BOOL)isDebug withClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey appid:(NSString *)appId cusConfigModel: (DCGMPayCusConfigModel *)configModel;

- (NSString *)dCgetPayStateDomain;

- (NSString *)dCgetSignatureKey;

- (NSString *)dCgetClientID;
- (NSString *)dCgetStaticUUID;

- (void)setStaticUUID:(NSString *)uuid;

+ (instancetype)dCsharedManger;

@end

NS_ASSUME_NONNULL_END
