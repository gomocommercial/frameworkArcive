//
//  DCGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "DCGMProductModel.h"
#import "DCPayNotificationHTTPResponse.h"
#import <DCGMPaymentSDK/DCGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface DCGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^DCGMCkeckPayStateApiCompleteBlock) (DCPayNotificationHTTPResponse *gmresponse);
typedef void (^DCGMPrePaymentApiCompleteBlock) (DCPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (DCGMCheckPayReceiptisValid *)dCsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)dCprepaymentWithProduct:(DCGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(DCGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)dCfetchIAPPreorderAndCheckReceiptIsValid:(DCGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(DCGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
