//
//  TTAPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "TTAPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTAPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)tTAsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(TTAPayNotificationModel*)tTAunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)tTAdelSerializedBean:(TTAPayNotificationModel*)bean;
+(NSArray <TTAPayNotificationModel *>*)tTAgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)tTAretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
