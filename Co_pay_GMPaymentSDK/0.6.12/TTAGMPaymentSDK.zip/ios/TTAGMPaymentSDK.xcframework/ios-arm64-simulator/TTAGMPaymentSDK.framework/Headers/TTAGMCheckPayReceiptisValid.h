//
//  TTAGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "TTAGMProductModel.h"
#import "TTAPayNotificationHTTPResponse.h"
#import <TTAGMPaymentSDK/TTAGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface TTAGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^TTAGMCkeckPayStateApiCompleteBlock) (TTAPayNotificationHTTPResponse *gmresponse);
typedef void (^TTAGMPrePaymentApiCompleteBlock) (TTAPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (TTAGMCheckPayReceiptisValid *)tTAsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)tTAprepaymentWithProduct:(TTAGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(TTAGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)tTAfetchIAPPreorderAndCheckReceiptIsValid:(TTAGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(TTAGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
