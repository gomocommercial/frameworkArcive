//
//  TTAGMPayDeviceModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TTAGMPayDeviceModel : NSObject
+ (NSDictionary *)tTAdevice;
@end

NS_ASSUME_NONNULL_END
