//
//  FSLGPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "FSLGPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLGPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)fSLGsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(FSLGPayNotificationModel*)fSLGunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)fSLGdelSerializedBean:(FSLGPayNotificationModel*)bean;
+(NSArray <FSLGPayNotificationModel *>*)fSLGgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fSLGretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
