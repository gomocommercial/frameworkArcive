//
//  FSLGGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "FSLGGMProductModel.h"
#import "FSLGPayNotificationHTTPResponse.h"
#import <FSLGGMPaymentSDK/FSLGGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface FSLGGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^FSLGGMCkeckPayStateApiCompleteBlock) (FSLGPayNotificationHTTPResponse *gmresponse);
typedef void (^FSLGGMPrePaymentApiCompleteBlock) (FSLGPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (FSLGGMCheckPayReceiptisValid *)fSLGsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)fSLGprepaymentWithProduct:(FSLGGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(FSLGGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)fSLGfetchIAPPreorderAndCheckReceiptIsValid:(FSLGGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(FSLGGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
