//
//  FSLGPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FSLGPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "FSLGPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^FSLGPayNotificationStateApiCompleteBlock) (FSLGPayNotificationHTTPResponse *response);

@interface FSLGPayNotificationStateApiManager : AFHTTPSessionManager
+ (FSLGPayNotificationStateApiManager *)fSLGsharedManager;
//支付成功新增后台 通知接口
-(void)fSLGcheckiOSIAPPayOrderWithPayNotificationModel:(FSLGPayNotificationModel *)payNotificationModel  complete:(FSLGPayNotificationStateApiCompleteBlock)complete;
-(void)fSLGgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(FSLGPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
