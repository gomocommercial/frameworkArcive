//
//  FSLPGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "FSLPGMProductModel.h"
#import "FSLPPayNotificationHTTPResponse.h"
#import <FSLPGMPaymentSDK/FSLPGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface FSLPGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^FSLPGMCkeckPayStateApiCompleteBlock) (FSLPPayNotificationHTTPResponse *gmresponse);
typedef void (^FSLPGMPrePaymentApiCompleteBlock) (FSLPPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (FSLPGMCheckPayReceiptisValid *)fSLPsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)fSLPprepaymentWithProduct:(FSLPGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(FSLPGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)fSLPfetchIAPPreorderAndCheckReceiptIsValid:(FSLPGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(FSLPGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
