//
//  FSLPPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "FSLPPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLPPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)fSLPsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(FSLPPayNotificationModel*)fSLPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)fSLPdelSerializedBean:(FSLPPayNotificationModel*)bean;
+(NSArray <FSLPPayNotificationModel *>*)fSLPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fSLPretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
