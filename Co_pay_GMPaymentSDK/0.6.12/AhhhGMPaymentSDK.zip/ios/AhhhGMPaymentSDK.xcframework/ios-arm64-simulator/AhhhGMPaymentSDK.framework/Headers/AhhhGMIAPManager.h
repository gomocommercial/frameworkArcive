//
//  AhhhGMIAPManager.h
//  GLive
//
//  Created by Gordon Su on 2017/5/26.
//  Copyright © 2017年 3g.cn. All rights reserved.
//




#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
#import "AhhhGMCheckOrderModel.h"
#import "AhhhGMCheckPayReceiptisValid.h"
#define GMPaymentSDKLog(fmt, ...) NSLog((@"%s[Line %d] GMPaymentSDK:" fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);

@class AhhhGMIAPManager;
@class AhhhGMProductModel;
@class GMNetHTTPResponse;

typedef void (^AhhhGMManagerCkeckPayStateApiCompleteBlock) (AhhhPayNotificationHTTPResponse *gmresponse);
typedef void (^AhhhGMManagerGetDiscountCompleteBlock) (SKPaymentDiscount *discount, AhhhPayNotificationHTTPResponse *gmresponse);
typedef void (^AhhhPayCheckComplete)(BOOL success, AhhhGMProductModel *productModel, GMNetHTTPResponse *response);

@protocol AhhhIAPManagerDelegate <NSObject>

@optional

/**
 * 查询商品列表失败 或者restore的时候 刷新凭证失败
 *
 * @param manager
 * @param request
 * @param error
 */
- (void)gmIAPManager:(AhhhGMIAPManager*) manager iapRequest:(SKRequest *)request didFailWithError:(NSError *)error;

/**
 * 查询商品列表成功
 *
 * @param manager
 * @param productList
 * @param request
 */
- (void)gmIAPManager:(AhhhGMIAPManager *)manager withProductList:(NSArray<SKProduct *> *)productList iapRequestDidFinish:(SKRequest *)request;

/**
 交易成功
 */
- (void)gmIAPManager:(AhhhGMIAPManager *)manager iapPaymentSuccess:(AhhhGMProductModel *)productModel transaction:(SKPaymentTransaction *)transaction;

/**
 交易成功 但是设置了需要服务器验单,  需要客户端在这个回调里面  调起验单服务AhhhGMCheckPayReceiptisValid的接口
 */
- (void)gmIAPManager:(AhhhGMIAPManager *)manager iapPaymentSuccessButNeedCheckPayReceiptisValid:(AhhhGMProductModel *)productModel transaction:(SKPaymentTransaction *)transaction;

/**
 * 重复购买的回调
 * @param manager
 * @param transaction
 */
-(void)gmIAPManager:(AhhhGMIAPManager *)manager iapPaymentRepay:(SKPaymentTransaction *)transaction;


/**
 * 购买还原(restore)
 * @param manager
 * @param response
 */
-(void)gmIAPManager:(AhhhGMIAPManager *)manager iapPaymentRestore:(AhhhGMCheckOrderModel *)checkOrderModel;

/**
 交易失败
 */
- (void)gmIAPManager:(AhhhGMIAPManager*) manager iapPaymentFail:(SKPaymentTransaction *)transaction;

/**
 * 没有权限进行购买，需要提示用户开启购买权限
 * @param manager manager实例
 */
-(void)gmIAPManagerNoPermission:(AhhhGMIAPManager *)manager;

/**
 * 恢复购买失败
 * @param queue
 * @param error
 */
- (void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error;

@end



@interface AhhhGMIAPManager : NSObject<SKPaymentTransactionObserver>

//是否打开log日志 默认不打开
@property (nonatomic, assign) BOOL enableLog;

/**
 * 回调
 */
@property (nonatomic, weak) id<AhhhIAPManagerDelegate> delegate;

/**
 * 单例
 * @return
 */
+ (AhhhGMIAPManager *)ahhhsharedManager;

/**
 * 刷新所有的产品
 * @param identifiesList
 */
- (void)ahhhrefreshAllProductsWithIdentifies:(NSSet <NSString *> *)identifiesList;

/**
 * 购买商品
 * @param product 商品模型
 * @param purpose 内购还是订阅
 */
- (void)ahhhpayWithProduct:(AhhhGMProductModel *)product withPurpose:(NSString *)purpose ;
/**
* 购买商品
* @param product 商品模型
* @param purpose 内购还是订阅
* @param isNeedCheckOrder 是否需要服务端验单, 设置为YES 要等服务端验单成功  才会finish苹果的支付
*/
- (void)ahhhpayWithProduct:(AhhhGMProductModel *)product withPurpose:(NSString *)purpose isNeedCheckOrder:(BOOL)isNeedCheckOrder;
/**
 * 客户端一般不需要主动调用，除非一直有异常订单，
 * SDK处理失败，可以使用此接口结束异常订单的回调
 * @param transaction 交易Model
 * @param isRemoveCopy  是否移除本地的存储，如果后面不再需要此次订单信息，则建议移除
 */
- (void)ahhhcompleteTransaction:(SKPaymentTransaction *)transaction removeCopy:(BOOL)isRemoveCopy;


// 同步旧用户订单
- (void)ahhhupdateOldUserOrderWithProductId:(NSString *)productId;

/**
 * 基于 receipt 恢复订单
 * @param receipt  用户交易凭证
 * @param complete
 */
- (void)ahhhrestoreCompletedTransactions;

/**
 * 上报支付结果（未使用订阅SDK，自主上报时使用，使用订阅SDK订阅商品时不可调用）
 * @param prodcutId 商品id
 */
- (void)ahhhnotifyServeriOSIAPPayOrderWith:(NSString *)prodcutId;

/**
 支付记录实时上传 (即时上传服务器) (59协议)功能点
 
 @param operationCode 操作码
 @param statisticsObject 统计对象
 @param associationObject 关联对象 购买成功价格(以分为单位)
 @param tab Tab分类
 @param position 购买成功时，上传谷歌或第三方订单编号
 @param entrance 入口
 @param remark 备注: 部分支付方式，例如fortumo，取不到用户相关的帐号信息，则此字段为空）
 @param orderType 订单来源; 1：普通内购，2：订阅
 @param result 操作结果; 0：点击购买，1：购买成功
 */
+(void)ahhhpostUserRealtimePayMentStatisticOperationCode:(NSString *)operationCode
                                     statisticsObject:(NSString *)statisticsObject
                                    associationObject:(NSString *)associationObject
                                                  tab:(NSString *)tab
                                             position:(NSString *)position
                                             entrance:(NSString *)entrance
                                               remark:(NSString *)remark
                                            orderType:(NSInteger)orderType
                                            resultObj:(NSString *)result;

//新增优化支付sdk
//获取当前苹果的验单结果信息
//latest_receipt 最新凭证
//latest_receipt_info 最新凭证详情（可能会有多个，因为是不同组的产品，产品id是不同的)
-(void)ahhhgetCurrentAllOrderInfoFromAppleWithcomplete:(void (^)(AhhhGMCheckOrderModel *checkOrderModel))result;
//获取当前时间戳(毫秒级别)
-(void)ahhhgetCurrentServiceTimeIntervalComplete:(void (^)(NSTimeInterval timeInterval))complete;

//上传j007统计(客户端请勿调用)
+(void)ahhhpostUserRealtimePayMentStatisticOperationCode:(NSString *)operationCode
 statisticsObject:(NSString *)statisticsObject
associationObject:(NSString *)associationObject
              tab:(NSString *)tab
         position:(NSString *)position
         entrance:(NSString *)entrance
           remark:(NSString *)remark
        orderType:(NSInteger)orderType
        resultObj:(NSString *)result;
        
//货币符号转换(客户端请勿调用)       
-(CGFloat )localPriceTransformPart:(NSString *)storeCountry price:(CGFloat)price;

// 服务器验单
-(void)ahhhmanagerfetchIAPPreorderAndCheckReceiptIsValid:(AhhhGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(AhhhGMManagerCkeckPayStateApiCompleteBlock)completeCkeckPay;
-(void)ahhhpayWithProduct:(AhhhGMProductModel *)product discountOffer:(SKPaymentDiscount *)discountOffer withPurpose:(NSString *)purpose;
-(void)ahhhgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(AhhhGMManagerGetDiscountCompleteBlock)complete;

@end


