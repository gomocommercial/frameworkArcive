//
//  AhhhPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "AhhhPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)ahhhsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(AhhhPayNotificationModel*)ahhhunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)ahhhdelSerializedBean:(AhhhPayNotificationModel*)bean;
+(NSArray <AhhhPayNotificationModel *>*)ahhhgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)ahhhretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
