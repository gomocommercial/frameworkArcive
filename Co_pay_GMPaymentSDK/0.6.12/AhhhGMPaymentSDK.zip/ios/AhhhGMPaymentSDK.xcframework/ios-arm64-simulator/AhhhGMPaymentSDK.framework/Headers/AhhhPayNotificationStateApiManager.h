//
//  AhhhPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AhhhPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "AhhhPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^AhhhPayNotificationStateApiCompleteBlock) (AhhhPayNotificationHTTPResponse *response);

@interface AhhhPayNotificationStateApiManager : AFHTTPSessionManager
+ (AhhhPayNotificationStateApiManager *)ahhhsharedManager;
//支付成功新增后台 通知接口
-(void)ahhhcheckiOSIAPPayOrderWithPayNotificationModel:(AhhhPayNotificationModel *)payNotificationModel  complete:(AhhhPayNotificationStateApiCompleteBlock)complete;
-(void)ahhhgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(AhhhPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
