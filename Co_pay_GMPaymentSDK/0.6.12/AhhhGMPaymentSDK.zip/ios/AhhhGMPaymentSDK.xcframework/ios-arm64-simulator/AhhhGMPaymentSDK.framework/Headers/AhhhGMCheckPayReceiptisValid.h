//
//  AhhhGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "AhhhGMProductModel.h"
#import "AhhhPayNotificationHTTPResponse.h"
#import <AhhhGMPaymentSDK/AhhhGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface AhhhGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^AhhhGMCkeckPayStateApiCompleteBlock) (AhhhPayNotificationHTTPResponse *gmresponse);
typedef void (^AhhhGMPrePaymentApiCompleteBlock) (AhhhPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (AhhhGMCheckPayReceiptisValid *)ahhhsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)ahhhprepaymentWithProduct:(AhhhGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(AhhhGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)ahhhfetchIAPPreorderAndCheckReceiptIsValid:(AhhhGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(AhhhGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
