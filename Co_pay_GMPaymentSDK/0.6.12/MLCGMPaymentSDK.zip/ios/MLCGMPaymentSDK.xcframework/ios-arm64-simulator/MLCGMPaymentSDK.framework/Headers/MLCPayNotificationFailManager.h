//
//  MLCPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "MLCPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MLCPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)mLCsaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(MLCPayNotificationModel*)mLCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)mLCdelSerializedBean:(MLCPayNotificationModel*)bean;
+(NSArray <MLCPayNotificationModel *>*)mLCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mLCretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
