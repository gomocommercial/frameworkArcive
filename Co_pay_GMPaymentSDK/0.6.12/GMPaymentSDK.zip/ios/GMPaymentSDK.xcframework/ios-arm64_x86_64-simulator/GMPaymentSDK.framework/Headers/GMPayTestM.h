//
//  GMPayTestM.h
//  GMPaymentSDK
//
//  Created by zhangxin on 2025/6/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GMPayTestM : NSObject
- (void)testOC;
@end

NS_ASSUME_NONNULL_END
