//
//  FurTalesPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "FurTalesPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)furTalessaveToCacheWithProductId:(NSString *)product_id originTransactionId:(NSString *)originTrId tranId: (NSString *)tranId;
+(FurTalesPayNotificationModel*)furTalesunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)furTalesdelSerializedBean:(FurTalesPayNotificationModel*)bean;
+(NSArray <FurTalesPayNotificationModel *>*)furTalesgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)furTalesretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
