//
//  FurTalesGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "FurTalesGMProductModel.h"
#import "FurTalesPayNotificationHTTPResponse.h"
#import <FurTalesGMPaymentSDK/FurTalesGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface FurTalesGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^FurTalesGMCkeckPayStateApiCompleteBlock) (FurTalesPayNotificationHTTPResponse *gmresponse);
typedef void (^FurTalesGMPrePaymentApiCompleteBlock) (FurTalesPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (FurTalesGMCheckPayReceiptisValid *)furTalessharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)furTalesprepaymentWithProduct:(FurTalesGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(FurTalesGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)furTalesfetchIAPPreorderAndCheckReceiptIsValid:(FurTalesGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(FurTalesGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
