//
//  FurTalesPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FurTalesPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "FurTalesPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^FurTalesPayNotificationStateApiCompleteBlock) (FurTalesPayNotificationHTTPResponse *response);

@interface FurTalesPayNotificationStateApiManager : AFHTTPSessionManager
+ (FurTalesPayNotificationStateApiManager *)furTalessharedManager;
//支付成功新增后台 通知接口
-(void)furTalescheckiOSIAPPayOrderWithPayNotificationModel:(FurTalesPayNotificationModel *)payNotificationModel  complete:(FurTalesPayNotificationStateApiCompleteBlock)complete;
-(void)furTalesgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(FurTalesPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
