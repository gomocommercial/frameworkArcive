//
//  FurTalesGMPayDeviceModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesGMPayDeviceModel : NSObject
+ (NSDictionary *)furTalesdevice;
@end

NS_ASSUME_NONNULL_END
