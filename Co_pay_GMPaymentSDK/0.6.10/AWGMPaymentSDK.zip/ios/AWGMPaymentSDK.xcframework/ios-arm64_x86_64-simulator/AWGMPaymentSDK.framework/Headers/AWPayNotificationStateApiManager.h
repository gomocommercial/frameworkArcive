//
//  AWPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AWPayNotificationModel.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "AWPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^AWPayNotificationStateApiCompleteBlock) (AWPayNotificationHTTPResponse *response);

@interface AWPayNotificationStateApiManager : AFHTTPSessionManager
+ (AWPayNotificationStateApiManager *)aWsharedManager;
//支付成功新增后台 通知接口
-(void)aWcheckiOSIAPPayOrderWithPayNotificationModel:(AWPayNotificationModel *)payNotificationModel  complete:(AWPayNotificationStateApiCompleteBlock)complete;
-(void)aWgetDiscountOfferWith:(NSString *)productIdentifier offerIdentifier:(NSString *)offerIdentifier complete:(AWPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
