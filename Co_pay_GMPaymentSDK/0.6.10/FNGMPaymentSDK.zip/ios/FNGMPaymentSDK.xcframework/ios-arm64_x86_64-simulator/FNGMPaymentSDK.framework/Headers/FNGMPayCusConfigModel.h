//
//  FNGMPayCusConfigModel.h
//  FNGMPaymentSDK
//
//  Created by 张新 on 2023/9/7.
//

#import <Foundation/Foundation.h>

@interface FNGMPayCusConfigModel : NSObject

//支付域名（未配置时默认使用PaymentSDKUrl中的配置）
@property (nonatomic, copy) NSString *payDomain;
//check pay (未配置时默认使用CheckPayReceiptUrl中的配置）
@property (nonatomic, copy) NSString *checkPayDomain;





@end
