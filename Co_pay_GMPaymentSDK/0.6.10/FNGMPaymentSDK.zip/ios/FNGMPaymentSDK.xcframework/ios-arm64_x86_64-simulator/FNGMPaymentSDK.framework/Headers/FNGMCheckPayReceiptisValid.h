//
//  FNGMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "FNGMProductModel.h"
#import "FNPayNotificationHTTPResponse.h"
#import <FNGMPaymentSDK/FNGMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface FNGMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^FNGMCkeckPayStateApiCompleteBlock) (FNPayNotificationHTTPResponse *gmresponse);
typedef void (^FNGMPrePaymentApiCompleteBlock) (FNPayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (FNGMCheckPayReceiptisValid *)fNsharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)fNprepaymentWithProduct:(FNGMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(FNGMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)fNfetchIAPPreorderAndCheckReceiptIsValid:(FNGMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(FNGMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
