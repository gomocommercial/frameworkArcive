//
//  GMCheckPayReceiptisValid.h
//  Tarot
//
//  Created by qiaoming on 2019/6/28.
//  Copyright © 2019年 郭鹏. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CSNetSDK/GMNetHTTPResponse.h>
#import "GMProductModel.h"
#import "PayNotificationHTTPResponse.h"
#import <GMPaymentSDK/GMIAPManager.h>

NS_ASSUME_NONNULL_BEGIN



@interface GMCheckPayReceiptisValid : NSObject

@property (nonatomic, copy) NSString *desKey;//
typedef void (^GMCkeckPayStateApiCompleteBlock) (PayNotificationHTTPResponse *gmresponse);
typedef void (^GMPrePaymentApiCompleteBlock) (PayNotificationHTTPResponse *gmresponse, NSString *tranId, NSString *uuidStr);
+ (GMCheckPayReceiptisValid *)sharedManager;

/// 生成预订单
/// - Parameters:
///   - productModel: 商品信息model
///   - accessToken:
///   - accountId:
///   - complete: 回调（服务器交易单号，服务器返回的uuid）
- (void)prepaymentWithProduct:(GMProductModel *)productModel accessToken:(NSString *)accessToken accountId:(NSString *)accountId complete:(GMPrePaymentApiCompleteBlock)complete;



/// 验单
-(void)fetchIAPPreorderAndCheckReceiptIsValid:(GMProductModel *)productModel tranId: (NSString *)tranId accessToken:(NSString *)accessToken accountId:(NSString *)accountId transaction:(SKPaymentTransaction *)transaction withComplete:(GMCkeckPayStateApiCompleteBlock)completeCkeckPay;

@end

NS_ASSUME_NONNULL_END
