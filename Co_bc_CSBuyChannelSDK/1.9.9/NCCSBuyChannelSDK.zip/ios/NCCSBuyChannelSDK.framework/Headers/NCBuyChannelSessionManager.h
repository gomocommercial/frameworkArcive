//
//  NCBuyChannelSessionManager.h
//  NCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "NCCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface NCBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(NCBuyChannelSessionManager*)nCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(NCBuyChannelSessionManager*)getBuySessionManager;

-(void)nCstartAsyncRequestComplete:(void(^)(NCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)nCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(NCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
