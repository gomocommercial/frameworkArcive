//
//  ATBuyChannelIPCheckSessionManager.h
//  ATCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "ATCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ATBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(ATBuyChannelIPCheckSessionManager*)aTsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(ATBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)aTstartAsyncRequestComplete:(void(^)(ATCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
