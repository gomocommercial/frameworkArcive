//
//  ATCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "ATCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ATCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)aTsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(ATCSTrackFailModel*)aTunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)aTdelSerializedBean:(ATCSTrackFailModel*)bean;
//+(NSArray <ATCSTrackFailModel *>*)aTgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)aTretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
