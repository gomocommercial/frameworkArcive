//
//  PSBuyChannelSessionManager.h
//  PSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PSCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PSBuyChannelSessionManager*)pSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6;

+(PSBuyChannelSessionManager*)getBuySessionManager;

-(void)pSstartAsyncRequestComplete:(void(^)(PSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
