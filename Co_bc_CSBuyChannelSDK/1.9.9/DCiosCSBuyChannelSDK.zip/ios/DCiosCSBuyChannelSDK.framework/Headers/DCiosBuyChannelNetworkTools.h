//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface DCiosBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)dCiosgetIPv6AddressesOfAllInterface;
+ (NSString *)dCiosgetIPv6AddressOfInterfaces;
+ (NSString *)dCiosgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end