//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface APLBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)aPLgetIPv6AddressesOfAllInterface;
+ (NSString *)aPLgetIPv6AddressOfInterfaces;
+ (NSString *)aPLgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end