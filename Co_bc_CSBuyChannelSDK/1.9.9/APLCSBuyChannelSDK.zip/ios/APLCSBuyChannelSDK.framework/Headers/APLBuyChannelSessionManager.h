//
//  APLBuyChannelSessionManager.h
//  APLCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "APLCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface APLBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(APLBuyChannelSessionManager*)aPLsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(APLBuyChannelSessionManager*)getBuySessionManager;

-(void)aPLstartAsyncRequestComplete:(void(^)(APLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)aPLtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(APLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
