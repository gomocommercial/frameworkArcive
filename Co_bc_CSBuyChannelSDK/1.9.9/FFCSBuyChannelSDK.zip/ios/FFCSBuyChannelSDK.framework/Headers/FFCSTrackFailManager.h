//
//  FFCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "FFCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FFCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)fFsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(FFCSTrackFailModel*)fFunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)fFdelSerializedBean:(FFCSTrackFailModel*)bean;
//+(NSArray <FFCSTrackFailModel *>*)fFgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fFretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
