//
//  FFBuyChannelSessionManager.h
//  FFCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "FFCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface FFBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(FFBuyChannelSessionManager*)fFsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(FFBuyChannelSessionManager*)getBuySessionManager;

-(void)fFstartAsyncRequestComplete:(void(^)(FFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)fFtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(FFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
