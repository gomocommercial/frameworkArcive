//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface FFBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)fFgetIPv6AddressesOfAllInterface;
+ (NSString *)fFgetIPv6AddressOfInterfaces;
+ (NSString *)fFgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end