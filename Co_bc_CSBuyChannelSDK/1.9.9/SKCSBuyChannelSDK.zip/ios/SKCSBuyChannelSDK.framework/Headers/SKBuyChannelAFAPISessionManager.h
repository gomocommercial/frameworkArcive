//
// Created by Kevin Guo on 2024/9/19.
//

#import <Foundation/Foundation.h>


@interface SKBuyChannelAFAPISessionManager : NSObject
+(void)sKstartGetGcdDataWithAppId:(NSString *)appId devKey:(NSString *)devkey retryCount:(NSInteger)retryCount complete:(void(^)(NSDictionary *gcdData))complete;
@end