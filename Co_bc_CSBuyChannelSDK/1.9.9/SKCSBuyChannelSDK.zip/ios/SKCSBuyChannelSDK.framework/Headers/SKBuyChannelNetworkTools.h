//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface SKBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)sKgetIPv6AddressesOfAllInterface;
+ (NSString *)sKgetIPv6AddressOfInterfaces;
+ (NSString *)sKgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end