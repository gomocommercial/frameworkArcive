//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface DCBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)dCgetIPv6AddressesOfAllInterface;
+ (NSString *)dCgetIPv6AddressOfInterfaces;
+ (NSString *)dCgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end