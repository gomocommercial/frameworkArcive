//
//  DCBuyChannelIPCheckSessionManager.h
//  DCCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DCCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(DCBuyChannelIPCheckSessionManager*)dCsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(DCBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)dCstartAsyncRequestComplete:(void(^)(DCCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
