//
//  FRBuyChannelIPCheckSessionManager.h
//  FRCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "FRCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FRBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(FRBuyChannelIPCheckSessionManager*)fRsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(FRBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)fRstartAsyncRequestComplete:(void(^)(FRCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
