//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface FRBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)fRgetIPv6AddressesOfAllInterface;
+ (NSString *)fRgetIPv6AddressOfInterfaces;
+ (NSString *)fRgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end