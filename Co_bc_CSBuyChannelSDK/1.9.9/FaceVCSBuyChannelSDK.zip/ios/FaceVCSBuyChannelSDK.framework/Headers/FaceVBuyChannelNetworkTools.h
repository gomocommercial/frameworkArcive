//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface FaceVBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)faceVgetIPv6AddressesOfAllInterface;
+ (NSString *)faceVgetIPv6AddressOfInterfaces;
+ (NSString *)faceVgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end