//
//  PCSCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PCSCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pCSsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PCSCSTrackFailModel*)pCSunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pCSdelSerializedBean:(PCSCSTrackFailModel*)bean;
//+(NSArray <PCSCSTrackFailModel *>*)pCSgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pCSretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
