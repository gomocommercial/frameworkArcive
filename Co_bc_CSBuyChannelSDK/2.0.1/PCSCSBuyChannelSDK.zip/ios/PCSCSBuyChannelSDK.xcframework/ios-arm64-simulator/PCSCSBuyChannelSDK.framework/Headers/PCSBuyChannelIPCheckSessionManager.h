//
//  PCSBuyChannelIPCheckSessionManager.h
//  PCSCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "PCSCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCSBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(PCSBuyChannelIPCheckSessionManager*)pCSsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PCSBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)pCSstartAsyncRequestComplete:(void(^)(PCSCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
