//
//  NSString+CUC_PCSBuyChannelSecure.h
//  CUC_PCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (CUC_PCSBuyChannelSecure)

+(NSString *)cUC_PbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)cUC_PbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
