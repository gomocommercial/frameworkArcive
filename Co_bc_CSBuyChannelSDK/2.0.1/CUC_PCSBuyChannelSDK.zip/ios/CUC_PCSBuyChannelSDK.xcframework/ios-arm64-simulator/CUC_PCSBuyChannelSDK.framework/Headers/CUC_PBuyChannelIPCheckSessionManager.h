//
//  CUC_PBuyChannelIPCheckSessionManager.h
//  CUC_PCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "CUC_PCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(CUC_PBuyChannelIPCheckSessionManager*)cUC_PsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CUC_PBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cUC_PstartAsyncRequestComplete:(void(^)(CUC_PCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
