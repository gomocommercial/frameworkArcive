//
//  LOCSBuyPheadModel.h
//  LOCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LOCSBuyPheadModel : NSObject

+ (NSDictionary *)lOgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
