//
//  MLCBuyChannelIPCheckSessionManager.h
//  MLCCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MLCCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MLCBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(MLCBuyChannelIPCheckSessionManager*)mLCsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(MLCBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)mLCstartAsyncRequestComplete:(void(^)(MLCCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
