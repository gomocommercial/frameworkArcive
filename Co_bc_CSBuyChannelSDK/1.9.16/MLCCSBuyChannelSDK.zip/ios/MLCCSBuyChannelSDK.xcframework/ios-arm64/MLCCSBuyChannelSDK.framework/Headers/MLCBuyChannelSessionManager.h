//
//  MLCBuyChannelSessionManager.h
//  MLCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MLCCSBuyChannelHTTPResponse.h"
#import "MLCBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface MLCBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(MLCBuyChannelSessionManager*)mLCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(MLCBuyChannelSessionManager*)getBuySessionManager;

-(void)mLCstartAsyncRequestComplete:(void(^)(MLCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)mLCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MLCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
