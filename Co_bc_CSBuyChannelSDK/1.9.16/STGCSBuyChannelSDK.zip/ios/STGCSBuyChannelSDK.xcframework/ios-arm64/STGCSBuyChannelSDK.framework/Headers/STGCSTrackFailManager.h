//
//  STGCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "STGCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STGCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sTGsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(STGCSTrackFailModel*)sTGunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sTGdelSerializedBean:(STGCSTrackFailModel*)bean;
//+(NSArray <STGCSTrackFailModel *>*)sTGgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sTGretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
