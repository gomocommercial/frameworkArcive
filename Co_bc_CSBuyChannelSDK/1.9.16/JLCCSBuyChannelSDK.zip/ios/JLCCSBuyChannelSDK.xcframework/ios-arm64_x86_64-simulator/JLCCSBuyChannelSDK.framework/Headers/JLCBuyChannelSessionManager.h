//
//  JLCBuyChannelSessionManager.h
//  JLCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "JLCCSBuyChannelHTTPResponse.h"
#import "JLCBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface JLCBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(JLCBuyChannelSessionManager*)jLCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(JLCBuyChannelSessionManager*)getBuySessionManager;

-(void)jLCstartAsyncRequestComplete:(void(^)(JLCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)jLCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(JLCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
