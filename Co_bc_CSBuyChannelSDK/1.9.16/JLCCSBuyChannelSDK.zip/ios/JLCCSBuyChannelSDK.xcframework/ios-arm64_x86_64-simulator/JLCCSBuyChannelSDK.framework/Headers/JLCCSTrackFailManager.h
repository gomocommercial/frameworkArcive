//
//  JLCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "JLCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JLCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)jLCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(JLCCSTrackFailModel*)jLCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)jLCdelSerializedBean:(JLCCSTrackFailModel*)bean;
//+(NSArray <JLCCSTrackFailModel *>*)jLCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)jLCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
