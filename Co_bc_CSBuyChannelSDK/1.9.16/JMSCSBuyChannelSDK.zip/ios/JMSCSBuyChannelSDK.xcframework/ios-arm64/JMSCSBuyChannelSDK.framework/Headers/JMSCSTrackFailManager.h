//
//  JMSCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "JMSCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JMSCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)jMSsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(JMSCSTrackFailModel*)jMSunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)jMSdelSerializedBean:(JMSCSTrackFailModel*)bean;
//+(NSArray <JMSCSTrackFailModel *>*)jMSgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)jMSretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
