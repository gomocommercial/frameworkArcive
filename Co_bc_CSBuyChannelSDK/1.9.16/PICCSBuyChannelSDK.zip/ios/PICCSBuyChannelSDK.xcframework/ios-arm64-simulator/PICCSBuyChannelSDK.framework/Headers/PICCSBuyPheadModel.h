//
//  PICCSBuyPheadModel.h
//  PICCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PICCSBuyPheadModel : NSObject

+ (NSDictionary *)pICgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
