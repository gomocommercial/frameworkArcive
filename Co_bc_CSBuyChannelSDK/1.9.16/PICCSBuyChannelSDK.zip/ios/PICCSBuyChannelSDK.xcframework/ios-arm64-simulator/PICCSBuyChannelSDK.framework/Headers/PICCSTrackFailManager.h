//
//  PICCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PICCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PICCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pICsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PICCSTrackFailModel*)pICunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pICdelSerializedBean:(PICCSTrackFailModel*)bean;
//+(NSArray <PICCSTrackFailModel *>*)pICgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pICretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
