//
//  PICBuyChannelSessionManager.h
//  PICCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PICCSBuyChannelHTTPResponse.h"
#import "PICBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface PICBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PICBuyChannelSessionManager*)pICsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PICBuyChannelSessionManager*)getBuySessionManager;

-(void)pICstartAsyncRequestComplete:(void(^)(PICCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pICtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PICCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
