//
//  PICBuyChannelIPCheckSessionManager.h
//  PICCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PICCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PICBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(PICBuyChannelIPCheckSessionManager*)pICsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PICBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)pICstartAsyncRequestComplete:(void(^)(PICCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
