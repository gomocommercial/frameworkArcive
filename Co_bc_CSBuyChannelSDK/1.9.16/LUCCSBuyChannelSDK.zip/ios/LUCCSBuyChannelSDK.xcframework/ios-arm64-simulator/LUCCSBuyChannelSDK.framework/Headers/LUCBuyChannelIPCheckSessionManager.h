//
//  LUCBuyChannelIPCheckSessionManager.h
//  LUCCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LUCCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUCBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(LUCBuyChannelIPCheckSessionManager*)lUCsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LUCBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)lUCstartAsyncRequestComplete:(void(^)(LUCCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
