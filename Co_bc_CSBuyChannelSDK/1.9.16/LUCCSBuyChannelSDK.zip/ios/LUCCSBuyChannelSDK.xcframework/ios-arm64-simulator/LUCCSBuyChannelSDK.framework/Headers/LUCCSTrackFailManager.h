//
//  LUCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LUCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lUCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LUCCSTrackFailModel*)lUCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lUCdelSerializedBean:(LUCCSTrackFailModel*)bean;
//+(NSArray <LUCCSTrackFailModel *>*)lUCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lUCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
