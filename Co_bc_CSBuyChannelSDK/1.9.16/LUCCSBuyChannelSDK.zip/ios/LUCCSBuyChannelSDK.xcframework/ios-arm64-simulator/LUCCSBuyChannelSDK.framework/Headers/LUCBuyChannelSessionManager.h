//
//  LUCBuyChannelSessionManager.h
//  LUCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LUCCSBuyChannelHTTPResponse.h"
#import "LUCBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUCBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(LUCBuyChannelSessionManager*)lUCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(LUCBuyChannelSessionManager*)getBuySessionManager;

-(void)lUCstartAsyncRequestComplete:(void(^)(LUCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lUCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LUCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
