//
//  BBBBuyChannelSessionManager.h
//  BBBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "BBBCSBuyChannelHTTPResponse.h"
#import "BBBBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface BBBBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(BBBBuyChannelSessionManager*)bBBsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(BBBBuyChannelSessionManager*)getBuySessionManager;

-(void)bBBstartAsyncRequestComplete:(void(^)(BBBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)bBBtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(BBBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
