//
//  BBBBuyChannelIPCheckSessionManager.h
//  BBBCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "BBBCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BBBBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(BBBBuyChannelIPCheckSessionManager*)bBBsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(BBBBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)bBBstartAsyncRequestComplete:(void(^)(BBBCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
