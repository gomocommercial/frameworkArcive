//
//  BBBCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "BBBCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BBBCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)bBBsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(BBBCSTrackFailModel*)bBBunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)bBBdelSerializedBean:(BBBCSTrackFailModel*)bean;
//+(NSArray <BBBCSTrackFailModel *>*)bBBgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)bBBretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
