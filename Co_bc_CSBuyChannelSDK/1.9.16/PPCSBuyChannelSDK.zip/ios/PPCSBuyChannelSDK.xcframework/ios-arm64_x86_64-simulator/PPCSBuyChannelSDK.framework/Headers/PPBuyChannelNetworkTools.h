//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFHTTPSessionManager.h>


@interface PPBuyChannelNetworkTools : NSObject

+ (void)pPstartGetIPv6AddressWithLocalAddressDetectWithEnableIPv6:(BOOL)enableIPv6
                                                          geoipAPIURL:(NSString *)geoipAPIURL
                                                        maxRetryCount:(NSInteger)maxRetryCount
                                                            complete:(void(^)(NSDictionary* address))complete;

+ (NSDictionary *)decryptStringTransToDic:(id)responseObject desKey:(NSString *)desKey;
+ (NSString *)signatureWithAccesskey:(NSString *)accesskey methodName:(NSString *)methodName requestUrl:(NSString *)requestUrl queries:(NSString *)queryString payload:(NSMutableDictionary *)payload;
@end
