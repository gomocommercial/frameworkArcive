//
//  TLBuyChannelIPCheckSessionManager.h
//  TLCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "TLCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TLBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(TLBuyChannelIPCheckSessionManager*)tLsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TLBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)tLstartAsyncRequestComplete:(void(^)(TLCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
