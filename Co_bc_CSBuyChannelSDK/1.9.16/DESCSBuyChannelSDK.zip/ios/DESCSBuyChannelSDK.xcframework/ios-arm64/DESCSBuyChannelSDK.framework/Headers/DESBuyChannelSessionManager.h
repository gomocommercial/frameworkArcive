//
//  DESBuyChannelSessionManager.h
//  DESCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DESCSBuyChannelHTTPResponse.h"
#import "DESBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface DESBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(DESBuyChannelSessionManager*)dESsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(DESBuyChannelSessionManager*)getBuySessionManager;

-(void)dESstartAsyncRequestComplete:(void(^)(DESCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)dEStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(DESCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
