//
//  DESBuyChannelIPCheckSessionManager.h
//  DESCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DESCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DESBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(DESBuyChannelIPCheckSessionManager*)dESsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(DESBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)dESstartAsyncRequestComplete:(void(^)(DESCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
