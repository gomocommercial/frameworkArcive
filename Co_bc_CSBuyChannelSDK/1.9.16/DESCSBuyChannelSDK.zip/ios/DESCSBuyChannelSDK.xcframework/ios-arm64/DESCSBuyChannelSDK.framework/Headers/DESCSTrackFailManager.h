//
//  DESCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "DESCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DESCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)dESsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(DESCSTrackFailModel*)dESunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)dESdelSerializedBean:(DESCSTrackFailModel*)bean;
//+(NSArray <DESCSTrackFailModel *>*)dESgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)dESretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
