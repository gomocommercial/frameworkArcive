#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "DESBuyChannelAFAPISessionManager.h"
#import "DESBuyChannelFBSessionManager.h"
#import "DESBuyChannelIPCheckSessionManager.h"
#import "DESBuyChannelNetworkTools.h"
#import "DESBuyChannelSessionManager.h"
#import "DESBuyChannelWebEvent.h"
#import "DESCSBuyChannel.h"
#import "DESCSBuyChannelFlyerModel.h"
#import "DESCSBuyChannelFlyerOneLinkModel.h"
#import "DESCSBuyChannelHTTPResponse.h"
#import "DESCSBuyChannelInitParams.h"
#import "DESCSBuyChannelRequestSerializer.h"
#import "DESCSBuyChannelSecureManager.h"
#import "DESCSBuyPheadModel.h"
#import "DESCSCustomPostData.h"
#import "DESCSTrackFailManager.h"
#import "DESCSTrackFailModel.h"
#import "NSString+DESCSBuyChannelSecure.h"
#import "DESBuyChannelAFAPISessionManager.h"
#import "DESBuyChannelFBSessionManager.h"
#import "DESBuyChannelIPCheckSessionManager.h"
#import "DESBuyChannelNetworkTools.h"
#import "DESBuyChannelSessionManager.h"
#import "DESBuyChannelWebEvent.h"
#import "DESCSBuyChannel.h"
#import "DESCSBuyChannelFlyerModel.h"
#import "DESCSBuyChannelFlyerOneLinkModel.h"
#import "DESCSBuyChannelHTTPResponse.h"
#import "DESCSBuyChannelInitParams.h"
#import "DESCSBuyChannelRequestSerializer.h"
#import "DESCSBuyChannelSecureManager.h"
#import "DESCSBuyPheadModel.h"
#import "DESCSCustomPostData.h"
#import "DESCSTrackFailManager.h"
#import "DESCSTrackFailModel.h"
#import "NSString+DESCSBuyChannelSecure.h"

FOUNDATION_EXPORT double DESCSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char DESCSBuyChannelSDKVersionString[];

