//
//  CSPCSBuyPheadModel.h
//  CSPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSPCSBuyPheadModel : NSObject

+ (NSDictionary *)cSPgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
