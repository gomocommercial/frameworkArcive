//
//  CSPCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CSPCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSPCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cSPsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CSPCSTrackFailModel*)cSPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cSPdelSerializedBean:(CSPCSTrackFailModel*)bean;
//+(NSArray <CSPCSTrackFailModel *>*)cSPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cSPretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
