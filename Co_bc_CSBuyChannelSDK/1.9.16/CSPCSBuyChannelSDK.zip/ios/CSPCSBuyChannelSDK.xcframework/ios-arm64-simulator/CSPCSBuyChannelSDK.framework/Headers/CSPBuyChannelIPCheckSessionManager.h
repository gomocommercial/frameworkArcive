//
//  CSPBuyChannelIPCheckSessionManager.h
//  CSPCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CSPCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSPBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(CSPBuyChannelIPCheckSessionManager*)cSPsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CSPBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cSPstartAsyncRequestComplete:(void(^)(CSPCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
