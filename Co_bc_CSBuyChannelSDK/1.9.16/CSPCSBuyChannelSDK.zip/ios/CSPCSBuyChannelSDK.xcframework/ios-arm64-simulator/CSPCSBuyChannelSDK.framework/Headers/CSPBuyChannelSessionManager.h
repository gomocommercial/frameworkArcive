//
//  CSPBuyChannelSessionManager.h
//  CSPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CSPCSBuyChannelHTTPResponse.h"
#import "CSPBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSPBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(CSPBuyChannelSessionManager*)cSPsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(CSPBuyChannelSessionManager*)getBuySessionManager;

-(void)cSPstartAsyncRequestComplete:(void(^)(CSPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cSPtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CSPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
