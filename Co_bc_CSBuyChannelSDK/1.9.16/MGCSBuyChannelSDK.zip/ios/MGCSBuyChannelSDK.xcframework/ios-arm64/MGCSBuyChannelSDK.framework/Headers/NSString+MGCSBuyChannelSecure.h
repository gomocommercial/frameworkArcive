//
//  NSString+MGCSBuyChannelSecure.h
//  MGCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (MGCSBuyChannelSecure)

+(NSString *)mGbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)mGbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
