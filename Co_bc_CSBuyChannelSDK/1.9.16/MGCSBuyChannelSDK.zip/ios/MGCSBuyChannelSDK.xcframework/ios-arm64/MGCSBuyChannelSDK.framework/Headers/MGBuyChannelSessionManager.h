//
//  MGBuyChannelSessionManager.h
//  MGCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MGCSBuyChannelHTTPResponse.h"
#import "MGBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(MGBuyChannelSessionManager*)mGsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(MGBuyChannelSessionManager*)getBuySessionManager;

-(void)mGstartAsyncRequestComplete:(void(^)(MGCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)mGtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MGCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
