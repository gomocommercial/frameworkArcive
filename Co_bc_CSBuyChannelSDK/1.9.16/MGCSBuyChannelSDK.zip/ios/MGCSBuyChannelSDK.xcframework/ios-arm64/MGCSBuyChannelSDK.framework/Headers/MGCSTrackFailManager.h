//
//  MGCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MGCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mGsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MGCSTrackFailModel*)mGunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mGdelSerializedBean:(MGCSTrackFailModel*)bean;
//+(NSArray <MGCSTrackFailModel *>*)mGgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mGretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
