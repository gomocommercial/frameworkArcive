#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MGBuyChannelAFAPISessionManager.h"
#import "MGBuyChannelFBSessionManager.h"
#import "MGBuyChannelIPCheckSessionManager.h"
#import "MGBuyChannelNetworkTools.h"
#import "MGBuyChannelSessionManager.h"
#import "MGBuyChannelWebEvent.h"
#import "MGCSBuyChannel.h"
#import "MGCSBuyChannelFlyerModel.h"
#import "MGCSBuyChannelFlyerOneLinkModel.h"
#import "MGCSBuyChannelHTTPResponse.h"
#import "MGCSBuyChannelInitParams.h"
#import "MGCSBuyChannelRequestSerializer.h"
#import "MGCSBuyChannelSecureManager.h"
#import "MGCSBuyPheadModel.h"
#import "MGCSCustomPostData.h"
#import "MGCSTrackFailManager.h"
#import "MGCSTrackFailModel.h"
#import "NSString+MGCSBuyChannelSecure.h"
#import "MGBuyChannelAFAPISessionManager.h"
#import "MGBuyChannelFBSessionManager.h"
#import "MGBuyChannelIPCheckSessionManager.h"
#import "MGBuyChannelNetworkTools.h"
#import "MGBuyChannelSessionManager.h"
#import "MGBuyChannelWebEvent.h"
#import "MGCSBuyChannel.h"
#import "MGCSBuyChannelFlyerModel.h"
#import "MGCSBuyChannelFlyerOneLinkModel.h"
#import "MGCSBuyChannelHTTPResponse.h"
#import "MGCSBuyChannelInitParams.h"
#import "MGCSBuyChannelRequestSerializer.h"
#import "MGCSBuyChannelSecureManager.h"
#import "MGCSBuyPheadModel.h"
#import "MGCSCustomPostData.h"
#import "MGCSTrackFailManager.h"
#import "MGCSTrackFailModel.h"
#import "NSString+MGCSBuyChannelSecure.h"

FOUNDATION_EXPORT double MGCSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char MGCSBuyChannelSDKVersionString[];

