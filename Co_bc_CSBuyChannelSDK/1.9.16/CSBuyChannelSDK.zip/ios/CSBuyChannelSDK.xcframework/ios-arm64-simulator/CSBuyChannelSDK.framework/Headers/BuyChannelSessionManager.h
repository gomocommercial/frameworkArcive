//
//  BuyChannelSessionManager.h
//  CSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#if __has_include(<AFNetworking/AFHTTPSessionManager.h>)
#import <AFNetworking/AFHTTPSessionManager.h>
#else
@import AFNetworking;
#endif
#import "CSBuyChannelHTTPResponse.h"
#import "BuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface BuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(BuyChannelSessionManager*)sharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(BuyChannelSessionManager*)getBuySessionManager;

-(void)startAsyncRequestComplete:(void(^)(CSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)trackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
