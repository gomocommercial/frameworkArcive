//
//  BuyChannelIPCheckSessionManager.h
//  CSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#if __has_include(<AFNetworking/AFHTTPSessionManager.h>)
#import <AFNetworking/AFHTTPSessionManager.h>
#else
@import AFNetworking;
#endif
#import "CSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(BuyChannelIPCheckSessionManager*)sharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(BuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)startAsyncRequestComplete:(void(^)(CSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
