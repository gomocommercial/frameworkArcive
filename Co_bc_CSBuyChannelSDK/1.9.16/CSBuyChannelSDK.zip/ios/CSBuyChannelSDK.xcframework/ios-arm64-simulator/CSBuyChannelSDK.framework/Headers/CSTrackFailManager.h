//
//  CSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)saveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CSTrackFailModel*)unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)delSerializedBean:(CSTrackFailModel*)bean;
//+(NSArray <CSTrackFailModel *>*)getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)retryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
