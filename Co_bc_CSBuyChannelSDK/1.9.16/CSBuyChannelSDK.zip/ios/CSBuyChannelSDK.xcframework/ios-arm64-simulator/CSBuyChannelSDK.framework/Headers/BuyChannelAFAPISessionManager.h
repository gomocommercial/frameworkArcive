//
// Created by Kevin Guo on 2024/9/19.
//

#import <Foundation/Foundation.h>


@interface BuyChannelAFAPISessionManager : NSObject
+(void)startGetGcdDataWithAppId:(NSString *)appId devKey:(NSString *)devkey retryCount:(NSInteger)retryCount complete:(void(^)(NSDictionary *gcdData, NSError *error))complete;
@end