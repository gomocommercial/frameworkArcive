//
//  FNBKCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "FNBKCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNBKCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)fNBKsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(FNBKCSTrackFailModel*)fNBKunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)fNBKdelSerializedBean:(FNBKCSTrackFailModel*)bean;
//+(NSArray <FNBKCSTrackFailModel *>*)fNBKgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fNBKretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
