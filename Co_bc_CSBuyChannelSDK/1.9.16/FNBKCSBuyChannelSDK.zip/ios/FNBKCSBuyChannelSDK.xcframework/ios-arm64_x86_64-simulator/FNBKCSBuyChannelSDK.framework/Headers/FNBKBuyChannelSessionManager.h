//
//  FNBKBuyChannelSessionManager.h
//  FNBKCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "FNBKCSBuyChannelHTTPResponse.h"
#import "FNBKBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNBKBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(FNBKBuyChannelSessionManager*)fNBKsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(FNBKBuyChannelSessionManager*)getBuySessionManager;

-(void)fNBKstartAsyncRequestComplete:(void(^)(FNBKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)fNBKtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(FNBKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
