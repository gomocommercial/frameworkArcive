//
//  FNBKBuyChannelIPCheckSessionManager.h
//  FNBKCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "FNBKCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNBKBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(FNBKBuyChannelIPCheckSessionManager*)fNBKsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(FNBKBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)fNBKstartAsyncRequestComplete:(void(^)(FNBKCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
