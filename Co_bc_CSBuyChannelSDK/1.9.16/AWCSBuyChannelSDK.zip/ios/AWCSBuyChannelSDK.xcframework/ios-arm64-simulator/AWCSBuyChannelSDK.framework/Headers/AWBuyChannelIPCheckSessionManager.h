//
//  AWBuyChannelIPCheckSessionManager.h
//  AWCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "AWCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AWBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(AWBuyChannelIPCheckSessionManager*)aWsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(AWBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)aWstartAsyncRequestComplete:(void(^)(AWCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
