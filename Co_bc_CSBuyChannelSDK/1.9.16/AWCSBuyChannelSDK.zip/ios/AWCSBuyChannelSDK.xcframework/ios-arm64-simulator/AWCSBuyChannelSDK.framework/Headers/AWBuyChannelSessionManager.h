//
//  AWBuyChannelSessionManager.h
//  AWCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "AWCSBuyChannelHTTPResponse.h"
#import "AWBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface AWBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(AWBuyChannelSessionManager*)aWsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(AWBuyChannelSessionManager*)getBuySessionManager;

-(void)aWstartAsyncRequestComplete:(void(^)(AWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)aWtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(AWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
