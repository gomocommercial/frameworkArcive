//
//  NSString+AWCSBuyChannelSecure.h
//  AWCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (AWCSBuyChannelSecure)

+(NSString *)aWbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)aWbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
