//
//  AWCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "AWCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AWCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)aWsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(AWCSTrackFailModel*)aWunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)aWdelSerializedBean:(AWCSTrackFailModel*)bean;
//+(NSArray <AWCSTrackFailModel *>*)aWgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)aWretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
