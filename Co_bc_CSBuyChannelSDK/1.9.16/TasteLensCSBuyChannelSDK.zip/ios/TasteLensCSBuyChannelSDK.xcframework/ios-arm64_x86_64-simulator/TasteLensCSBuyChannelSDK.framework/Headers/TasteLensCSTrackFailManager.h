//
//  TasteLensCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "TasteLensCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TasteLensCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)tasteLenssaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(TasteLensCSTrackFailModel*)tasteLensunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)tasteLensdelSerializedBean:(TasteLensCSTrackFailModel*)bean;
//+(NSArray <TasteLensCSTrackFailModel *>*)tasteLensgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)tasteLensretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
