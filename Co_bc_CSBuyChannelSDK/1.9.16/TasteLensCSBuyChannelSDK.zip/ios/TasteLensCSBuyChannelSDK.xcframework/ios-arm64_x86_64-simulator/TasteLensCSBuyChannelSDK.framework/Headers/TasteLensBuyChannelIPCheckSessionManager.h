//
//  TasteLensBuyChannelIPCheckSessionManager.h
//  TasteLensCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "TasteLensCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TasteLensBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(TasteLensBuyChannelIPCheckSessionManager*)tasteLenssharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TasteLensBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)tasteLensstartAsyncRequestComplete:(void(^)(TasteLensCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
