//
//  TasteLensBuyChannelSessionManager.h
//  TasteLensCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "TasteLensCSBuyChannelHTTPResponse.h"
#import "TasteLensBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface TasteLensBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(TasteLensBuyChannelSessionManager*)tasteLenssharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(TasteLensBuyChannelSessionManager*)getBuySessionManager;

-(void)tasteLensstartAsyncRequestComplete:(void(^)(TasteLensCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)tasteLenstrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(TasteLensCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
