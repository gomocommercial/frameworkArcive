//
//  LASCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LASCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LASCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lASsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LASCSTrackFailModel*)lASunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lASdelSerializedBean:(LASCSTrackFailModel*)bean;
//+(NSArray <LASCSTrackFailModel *>*)lASgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lASretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
