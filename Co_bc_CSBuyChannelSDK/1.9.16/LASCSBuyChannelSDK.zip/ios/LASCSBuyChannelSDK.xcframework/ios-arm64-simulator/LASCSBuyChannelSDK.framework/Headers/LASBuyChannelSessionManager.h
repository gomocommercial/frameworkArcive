//
//  LASBuyChannelSessionManager.h
//  LASCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LASCSBuyChannelHTTPResponse.h"
#import "LASBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LASBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(LASBuyChannelSessionManager*)lASsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(LASBuyChannelSessionManager*)getBuySessionManager;

-(void)lASstartAsyncRequestComplete:(void(^)(LASCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lAStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LASCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
