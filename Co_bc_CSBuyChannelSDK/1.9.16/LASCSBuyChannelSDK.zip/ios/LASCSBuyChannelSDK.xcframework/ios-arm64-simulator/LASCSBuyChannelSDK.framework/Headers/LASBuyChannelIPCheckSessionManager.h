//
//  LASBuyChannelIPCheckSessionManager.h
//  LASCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LASCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LASBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(LASBuyChannelIPCheckSessionManager*)lASsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LASBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)lASstartAsyncRequestComplete:(void(^)(LASCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
