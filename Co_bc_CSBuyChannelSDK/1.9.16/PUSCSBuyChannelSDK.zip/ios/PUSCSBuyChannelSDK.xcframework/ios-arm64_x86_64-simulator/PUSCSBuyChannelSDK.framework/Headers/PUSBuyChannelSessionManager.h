//
//  PUSBuyChannelSessionManager.h
//  PUSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PUSCSBuyChannelHTTPResponse.h"
#import "PUSBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface PUSBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PUSBuyChannelSessionManager*)pUSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PUSBuyChannelSessionManager*)getBuySessionManager;

-(void)pUSstartAsyncRequestComplete:(void(^)(PUSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pUStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PUSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
