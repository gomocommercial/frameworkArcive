//
//  PUSCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PUSCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PUSCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pUSsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PUSCSTrackFailModel*)pUSunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pUSdelSerializedBean:(PUSCSTrackFailModel*)bean;
//+(NSArray <PUSCSTrackFailModel *>*)pUSgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pUSretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
