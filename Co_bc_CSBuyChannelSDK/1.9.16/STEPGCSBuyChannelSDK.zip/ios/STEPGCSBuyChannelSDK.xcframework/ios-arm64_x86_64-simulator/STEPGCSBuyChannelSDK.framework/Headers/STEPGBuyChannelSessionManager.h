//
//  STEPGBuyChannelSessionManager.h
//  STEPGCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "STEPGCSBuyChannelHTTPResponse.h"
#import "STEPGBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface STEPGBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(STEPGBuyChannelSessionManager*)sTEPGsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(STEPGBuyChannelSessionManager*)getBuySessionManager;

-(void)sTEPGstartAsyncRequestComplete:(void(^)(STEPGCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sTEPGtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(STEPGCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
