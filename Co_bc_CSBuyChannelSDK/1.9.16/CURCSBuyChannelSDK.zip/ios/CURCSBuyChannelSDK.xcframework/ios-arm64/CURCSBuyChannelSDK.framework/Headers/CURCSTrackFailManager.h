//
//  CURCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CURCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CURCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cURsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CURCSTrackFailModel*)cURunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cURdelSerializedBean:(CURCSTrackFailModel*)bean;
//+(NSArray <CURCSTrackFailModel *>*)cURgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cURretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
