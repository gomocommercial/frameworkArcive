//
//  CURBuyChannelSessionManager.h
//  CURCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CURCSBuyChannelHTTPResponse.h"
#import "CURBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface CURBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(CURBuyChannelSessionManager*)cURsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(CURBuyChannelSessionManager*)getBuySessionManager;

-(void)cURstartAsyncRequestComplete:(void(^)(CURCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cURtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CURCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
