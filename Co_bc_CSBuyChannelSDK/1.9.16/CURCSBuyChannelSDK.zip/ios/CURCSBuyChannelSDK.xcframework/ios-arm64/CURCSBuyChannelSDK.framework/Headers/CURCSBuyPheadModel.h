//
//  CURCSBuyPheadModel.h
//  CURCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CURCSBuyPheadModel : NSObject

+ (NSDictionary *)cURgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
