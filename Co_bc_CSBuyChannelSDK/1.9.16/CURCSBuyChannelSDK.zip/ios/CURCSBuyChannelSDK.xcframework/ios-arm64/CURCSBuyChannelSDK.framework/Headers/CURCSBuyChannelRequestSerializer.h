//
//  CURCSBuyChannelRequestSerializer.h
//  CURCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <AFNetworking/AFURLRequestSerialization.h>

NS_ASSUME_NONNULL_BEGIN

@interface CURCSBuyChannelRequestSerializer : AFHTTPRequestSerializer

@property (nonatomic, copy) NSString *desKey;

/**
 Returns a request with the specified parameters encoded into a copy of the original request.
 
 @param request The original request.
 @param parameters The parameters to be encoded.
 @param error The error that occurred while attempting to encode the request parameters.
 
 @return A serialized request.
 */
- (nullable NSURLRequest *)requestBySerializingRequest:(NSURLRequest *)request
                                        withParameters:(nullable id)parameters
                                                 error:(NSError * _Nullable __autoreleasing *)error NS_SWIFT_NOTHROW;

@end

NS_ASSUME_NONNULL_END
