//
//  CURBuyChannelIPCheckSessionManager.h
//  CURCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CURCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CURBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(CURBuyChannelIPCheckSessionManager*)cURsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CURBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cURstartAsyncRequestComplete:(void(^)(CURCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
