//
//  BCBuyChannelIPCheckSessionManager.h
//  BCCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "BCCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BCBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(BCBuyChannelIPCheckSessionManager*)bCsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(BCBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)bCstartAsyncRequestComplete:(void(^)(BCCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
