//
//  CSBuyChannel.h
//  AppsFlyer
//
//  Created by qiaoming on 2018/8/21.
//  Copyright © 2018年 qiaoming. All rights reserved.
//#import <CSStatistics/CSStatistics.h>
//#import <CSStatistics/CSStatisticsDeviceInfo.h>
//---1.5.3
#import <Foundation/Foundation.h>
#import "LECSBuyChannelFlyerModel.h"

//af返回的数据有改变的时候 发出这个通知
#define NOTIFACTION_NAME_BUY_CHANNELS_IDENTIFER @"NOTIFACTION_NAME_BUY_CHANNELS_IDENTIFER"

FOUNDATION_EXPORT double CSBuyChannelVersionNumber;

//! Project version string for CSBuyChannel.
FOUNDATION_EXPORT const unsigned char CSBuyChannelVersionString[];


@protocol LECSBuyChannelDelegate <NSObject>

@optional

/*
 回调AF返回的原始数据
 */
- (void)lEbuyChannelOnConversionDataReceivedBuyChannel:(NSString *)buyChannel userFrom:(NSString *)userFrom;
- (void)lEbuyChannelOnConversionDataRequestFailure:(NSError *)error;

@end

@interface LECSBuyChannel : NSObject

////用户类型
//@property (nonatomic, copy) NSString *utmSource;
////用户类型标识
//@property (nonatomic, copy) NSString *userSource;
//用户类型  （买量渠道（fb或者adwords之类的字符串））
@property (nonatomic, copy) NSString *buyChannel;
//用户类型标识 （用户类型标示(-1 - 9数字)
@property (nonatomic, copy) NSString *userFrom;

/*
 * CSBuyChannel delegate. See CSBuyChannelDelegate abvoe
 */
@property (weak, nonatomic) id<LECSBuyChannelDelegate> delegate;

/* 你可以用这个属性 获取af返回的关键信息  例如:media_source  和  buychannel, agency campaign*/
@property (nonatomic, strong) LECSBuyChannelFlyerModel *channelFlyerModel;

/**
 用户类型sdk的初始化方法,请用这个方法初始化
 @param appsDevKey AppsFlyer上面返回的appsDevKey
 @param appleAppID AppsFlyer上面返回的appleAppID
 */
+(LECSBuyChannel*)lEsharedBuyChannelAppsDevKey:(NSString *)appsDevKey appleAppID:(NSString *)appleAppID configureDisseminationFuncId:(NSString *)funcId cid:(NSString *)cid;

//确保初始化完成之后 才能使用这个获取单利的方法,目的是获取值使用的
+(LECSBuyChannel*)getCsBuyChannel;

//调起AF
+(void)lEtrackAppLaunch;

//测试跑量数据使用
+(NSDictionary *)lEtestAfOriginalData:(NSDictionary *)installData isUploadToCSStatistics:(BOOL)uploadFlag;

//是否开启log日志输出
+(void)setEnableLog:(BOOL)enanleLog;

/**
 设置统计SDK的编译环境 是否是debug环境
 
 Debug: 数据上传测试服
 
 Release: 数据上传正式服 (默认)
 
 @param isDebug 编译环境类型
 */
+ (void)setEnvironmentIsDebug:(BOOL)isDebug;

//获取sdk的版本
+(NSString *)getSDKVersion;

//清除缓存的用户类型以及标示,清除完成之后,默认会返回自然的类型(-1), 不建议调用
+(void)lEclearAppsFlyerOriginalData;

//是否是买量类型
+(BOOL)lEisBuyUserSource;

//是否是带量类型
+(BOOL)lEisBandUserSource;

//是否是自然类型
+(BOOL)lEisOrganicUserSource;

//模拟买量的数据和类型
+(void)lESimulateBuyChannel:(NSString *)buyChannel userForm:(NSString *)userForm;


@end
