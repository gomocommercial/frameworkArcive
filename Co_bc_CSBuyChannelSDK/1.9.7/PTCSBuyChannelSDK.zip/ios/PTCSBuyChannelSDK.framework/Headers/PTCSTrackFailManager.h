//
//  PTCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PTCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PTCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pTsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PTCSTrackFailModel*)pTunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pTdelSerializedBean:(PTCSTrackFailModel*)bean;
//+(NSArray <PTCSTrackFailModel *>*)pTgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pTretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
