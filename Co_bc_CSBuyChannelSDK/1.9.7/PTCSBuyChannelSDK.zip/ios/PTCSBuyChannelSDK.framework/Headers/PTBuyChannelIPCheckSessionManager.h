//
//  PTBuyChannelIPCheckSessionManager.h
//  PTCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PTCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PTBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(PTBuyChannelIPCheckSessionManager*)pTsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PTBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)pTstartAsyncRequestComplete:(void(^)(PTCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
