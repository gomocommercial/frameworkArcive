//
//  SWCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "SWCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SWCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sWsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(SWCSTrackFailModel*)sWunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sWdelSerializedBean:(SWCSTrackFailModel*)bean;
//+(NSArray <SWCSTrackFailModel *>*)sWgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sWretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
