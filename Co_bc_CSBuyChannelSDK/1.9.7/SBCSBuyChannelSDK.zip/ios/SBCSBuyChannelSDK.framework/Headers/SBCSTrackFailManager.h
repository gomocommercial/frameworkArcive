//
//  SBCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "SBCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sBsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(SBCSTrackFailModel*)sBunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sBdelSerializedBean:(SBCSTrackFailModel*)bean;
//+(NSArray <SBCSTrackFailModel *>*)sBgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sBretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
