//
//  ATBuyChannelSessionManager.h
//  ATCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "ATCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface ATBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(ATBuyChannelSessionManager*)aTsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(ATBuyChannelSessionManager*)getBuySessionManager;

-(void)aTstartAsyncRequestComplete:(void(^)(ATCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)aTtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(ATCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
