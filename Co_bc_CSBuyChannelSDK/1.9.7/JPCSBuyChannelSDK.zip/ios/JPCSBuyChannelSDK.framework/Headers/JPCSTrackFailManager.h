//
//  JPCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "JPCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JPCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)jPsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(JPCSTrackFailModel*)jPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)jPdelSerializedBean:(JPCSTrackFailModel*)bean;
//+(NSArray <JPCSTrackFailModel *>*)jPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)jPretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
