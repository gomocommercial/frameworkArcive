//
//  JPBuyChannelSessionManager.h
//  JPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "JPCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface JPBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(JPBuyChannelSessionManager*)jPsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(JPBuyChannelSessionManager*)getBuySessionManager;

-(void)jPstartAsyncRequestComplete:(void(^)(JPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)jPtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(JPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
