//
//  TESTIOSBuyChannelIPCheckSessionManager.h
//  TESTIOSCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "TESTIOSCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TESTIOSBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(TESTIOSBuyChannelIPCheckSessionManager*)tESTIOSsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TESTIOSBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)tESTIOSstartAsyncRequestComplete:(void(^)(TESTIOSCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
