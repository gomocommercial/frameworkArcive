//
//  TESTIOSBuyChannelSessionManager.h
//  TESTIOSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "TESTIOSCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface TESTIOSBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(TESTIOSBuyChannelSessionManager*)tESTIOSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TESTIOSBuyChannelSessionManager*)getBuySessionManager;

-(void)tESTIOSstartAsyncRequestComplete:(void(^)(TESTIOSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)tESTIOStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(TESTIOSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
