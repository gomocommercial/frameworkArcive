//
//  HSBuyChannelSessionManager.h
//  HSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "HSCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface HSBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(HSBuyChannelSessionManager*)hSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(HSBuyChannelSessionManager*)getBuySessionManager;

-(void)hSstartAsyncRequestComplete:(void(^)(HSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)hStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(HSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
