//
//  MGBuyChannelIPCheckSessionManager.h
//  MGCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MGCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(MGBuyChannelIPCheckSessionManager*)mGsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(MGBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)mGstartAsyncRequestComplete:(void(^)(MGCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
