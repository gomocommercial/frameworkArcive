//
//  SMBuyChannelIPCheckSessionManager.h
//  SMCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SMCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SMBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(SMBuyChannelIPCheckSessionManager*)sMsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(SMBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sMstartAsyncRequestComplete:(void(^)(SMCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
