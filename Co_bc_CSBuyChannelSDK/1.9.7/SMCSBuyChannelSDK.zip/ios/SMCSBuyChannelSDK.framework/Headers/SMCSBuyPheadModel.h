//
//  SMCSBuyPheadModel.h
//  SMCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SMCSBuyPheadModel : NSObject

+ (NSDictionary *)sMgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
