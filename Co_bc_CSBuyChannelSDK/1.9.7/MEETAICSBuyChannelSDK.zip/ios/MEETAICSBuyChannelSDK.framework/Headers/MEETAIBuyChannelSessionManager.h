//
//  MEETAIBuyChannelSessionManager.h
//  MEETAICSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MEETAICSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface MEETAIBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(MEETAIBuyChannelSessionManager*)mEETAIsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(MEETAIBuyChannelSessionManager*)getBuySessionManager;

-(void)mEETAIstartAsyncRequestComplete:(void(^)(MEETAICSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)mEETAItrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MEETAICSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
