//
//  WBBuyChannelSessionManager.h
//  WBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "WBCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface WBBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(WBBuyChannelSessionManager*)wBsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(WBBuyChannelSessionManager*)getBuySessionManager;

-(void)wBstartAsyncRequestComplete:(void(^)(WBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)wBtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(WBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
