//
//  WBCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "WBCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface WBCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)wBsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(WBCSTrackFailModel*)wBunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)wBdelSerializedBean:(WBCSTrackFailModel*)bean;
//+(NSArray <WBCSTrackFailModel *>*)wBgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)wBretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
