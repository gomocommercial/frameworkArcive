//
//  CWBuyChannelSessionManager.h
//  CWCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CWCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface CWBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(CWBuyChannelSessionManager*)cWsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CWBuyChannelSessionManager*)getBuySessionManager;

-(void)cWstartAsyncRequestComplete:(void(^)(CWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cWtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
