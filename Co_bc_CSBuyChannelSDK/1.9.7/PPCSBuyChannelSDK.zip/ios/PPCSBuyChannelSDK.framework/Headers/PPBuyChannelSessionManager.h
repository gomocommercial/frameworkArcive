//
//  PPBuyChannelSessionManager.h
//  PPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PPCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PPBuyChannelSessionManager*)pPsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PPBuyChannelSessionManager*)getBuySessionManager;

-(void)pPstartAsyncRequestComplete:(void(^)(PPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pPtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
