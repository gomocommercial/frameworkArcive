//
//  PPCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PPCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pPsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PPCSTrackFailModel*)pPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pPdelSerializedBean:(PPCSTrackFailModel*)bean;
//+(NSArray <PPCSTrackFailModel *>*)pPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pPretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
