#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "NSString+WPSCSBuyChannelSecure.h"
#import "WPSBuyChannelIPCheckSessionManager.h"
#import "WPSBuyChannelSessionManager.h"
#import "WPSCSBuyChannel.h"
#import "WPSCSBuyChannelFlyerModel.h"
#import "WPSCSBuyChannelFlyerOneLinkModel.h"
#import "WPSCSBuyChannelHTTPResponse.h"
#import "WPSCSBuyChannelInitParams.h"
#import "WPSCSBuyChannelIPCheckRequestSerializer.h"
#import "WPSCSBuyChannelRequestSerializer.h"
#import "WPSCSBuyChannelSecureManager.h"
#import "WPSCSBuyPheadModel.h"
#import "WPSCSCustomPostData.h"
#import "WPSCSTrackFailManager.h"
#import "WPSCSTrackFailModel.h"
#import "NSString+WPSCSBuyChannelSecure.h"
#import "WPSBuyChannelIPCheckSessionManager.h"
#import "WPSBuyChannelSessionManager.h"
#import "WPSCSBuyChannel.h"
#import "WPSCSBuyChannelFlyerModel.h"
#import "WPSCSBuyChannelFlyerOneLinkModel.h"
#import "WPSCSBuyChannelHTTPResponse.h"
#import "WPSCSBuyChannelInitParams.h"
#import "WPSCSBuyChannelIPCheckRequestSerializer.h"
#import "WPSCSBuyChannelRequestSerializer.h"
#import "WPSCSBuyChannelSecureManager.h"
#import "WPSCSBuyPheadModel.h"
#import "WPSCSCustomPostData.h"
#import "WPSCSTrackFailManager.h"
#import "WPSCSTrackFailModel.h"

FOUNDATION_EXPORT double WPSCSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char WPSCSBuyChannelSDKVersionString[];

