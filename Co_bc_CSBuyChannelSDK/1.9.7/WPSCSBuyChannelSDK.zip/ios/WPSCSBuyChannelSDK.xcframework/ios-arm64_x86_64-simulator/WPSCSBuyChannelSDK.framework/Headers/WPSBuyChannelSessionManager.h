//
//  WPSBuyChannelSessionManager.h
//  WPSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "WPSCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface WPSBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(WPSBuyChannelSessionManager*)wPSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(WPSBuyChannelSessionManager*)getBuySessionManager;

-(void)wPSstartAsyncRequestComplete:(void(^)(WPSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)wPStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(WPSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
