//
//  NDBuyChannelSessionManager.h
//  NDCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "NDCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface NDBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(NDBuyChannelSessionManager*)nDsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(NDBuyChannelSessionManager*)getBuySessionManager;

-(void)nDstartAsyncRequestComplete:(void(^)(NDCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)nDtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(NDCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
