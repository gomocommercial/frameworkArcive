//
//  NDBuyChannelIPCheckSessionManager.h
//  NDCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "NDCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface NDBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(NDBuyChannelIPCheckSessionManager*)nDsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(NDBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)nDstartAsyncRequestComplete:(void(^)(NDCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
