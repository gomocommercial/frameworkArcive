//
//  FurTalesCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "FurTalesCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)furTalessaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(FurTalesCSTrackFailModel*)furTalesunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)furTalesdelSerializedBean:(FurTalesCSTrackFailModel*)bean;
//+(NSArray <FurTalesCSTrackFailModel *>*)furTalesgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)furTalesretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
