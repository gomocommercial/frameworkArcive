//
//  FurTalesBuyChannelIPCheckSessionManager.h
//  FurTalesCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "FurTalesCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(FurTalesBuyChannelIPCheckSessionManager*)furTalessharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(FurTalesBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)furTalesstartAsyncRequestComplete:(void(^)(FurTalesCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
