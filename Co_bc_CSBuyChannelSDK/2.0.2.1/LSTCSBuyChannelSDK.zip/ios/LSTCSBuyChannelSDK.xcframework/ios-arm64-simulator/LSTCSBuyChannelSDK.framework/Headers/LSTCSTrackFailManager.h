//
//  LSTCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LSTCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lSTsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LSTCSTrackFailModel*)lSTunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lSTdelSerializedBean:(LSTCSTrackFailModel*)bean;
//+(NSArray <LSTCSTrackFailModel *>*)lSTgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lSTretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
