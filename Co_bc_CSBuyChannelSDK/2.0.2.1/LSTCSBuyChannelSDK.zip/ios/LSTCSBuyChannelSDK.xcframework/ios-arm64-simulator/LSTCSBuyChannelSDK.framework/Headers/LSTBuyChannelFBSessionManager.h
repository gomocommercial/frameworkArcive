//
//  LSTBuyChannelFBSessionManager.h
//  LSTCSBuyChannelSDK
//
//  Created by KevinGuo on 2025/6/9.
//

#import <Foundation/Foundation.h>
#import "LSTCSBuyChannelHTTPResponse.h"
#import "LSTBuyChannelWebEvent.h"


NS_ASSUME_NONNULL_BEGIN

@interface LSTBuyChannelFBSessionManager : NSObject

+(LSTBuyChannelFBSessionManager*)lSTsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(LSTBuyChannelFBSessionManager*)getBuySessionManager;

//https://wiki.3g.net.cn/pages/viewpage.action?pageId=35325635#id-%E4%B9%B0%E9%87%8F%E8%AF%86%E5%88%AB-API%E6%8E%A5%E5%8F%A3-17%E3%80%81Web%E5%AE%89%E8%A3%85%E4%BA%8B%E4%BB%B6%E4%B8%8A%E6%8A%A5%EF%BC%88ISO1818017%EF%BC%89
-(void)lSTstartWebInstallEventRequestWith:(NSString *)externalId Complete:(void(^)(LSTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

//https://wiki.3g.net.cn/pages/viewpage.action?pageId=35325635#id-%E4%B9%B0%E9%87%8F%E8%AF%86%E5%88%AB-API%E6%8E%A5%E5%8F%A3-18%E3%80%81Web%E5%85%B6%E4%BB%96%E4%BA%8B%E4%BB%B6%E4%B8%8A%E6%8A%A5%EF%BC%88ISO1818018%EF%BC%89
-(void)lSTstartWebOtherEventRequestWith:(LSTBuyChannelWebEvent *)event Complete:(void(^)(LSTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
