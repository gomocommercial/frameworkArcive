//
//  LSTBuyChannelIPCheckSessionManager.h
//  LSTCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "LSTCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSTBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(LSTBuyChannelIPCheckSessionManager*)lSTsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LSTBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)lSTstartAsyncRequestComplete:(void(^)(LSTCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
