//
//  LSTBuyChannelSessionManager.h
//  LSTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "LSTCSBuyChannelHTTPResponse.h"
#import "LSTBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSTBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(LSTBuyChannelSessionManager*)lSTsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(LSTBuyChannelSessionManager*)getBuySessionManager;

-(void)lSTstartAsyncRequestComplete:(void(^)(LSTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lSTtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LSTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
