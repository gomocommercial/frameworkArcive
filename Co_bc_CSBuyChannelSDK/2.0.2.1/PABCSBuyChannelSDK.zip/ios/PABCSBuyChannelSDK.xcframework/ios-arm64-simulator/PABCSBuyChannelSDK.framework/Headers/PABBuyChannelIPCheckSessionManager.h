//
//  PABBuyChannelIPCheckSessionManager.h
//  PABCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "PABCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PABBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(PABBuyChannelIPCheckSessionManager*)pABsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PABBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)pABstartAsyncRequestComplete:(void(^)(PABCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
