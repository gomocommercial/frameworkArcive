//
//  PABBuyChannelSessionManager.h
//  PABCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "PABCSBuyChannelHTTPResponse.h"
#import "PABBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface PABBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(PABBuyChannelSessionManager*)pABsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PABBuyChannelSessionManager*)getBuySessionManager;

-(void)pABstartAsyncRequestComplete:(void(^)(PABCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pABtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PABCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
