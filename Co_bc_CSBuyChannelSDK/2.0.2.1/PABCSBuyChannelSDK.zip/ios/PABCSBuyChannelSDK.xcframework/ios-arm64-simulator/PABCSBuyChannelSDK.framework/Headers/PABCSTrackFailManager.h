//
//  PABCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PABCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PABCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pABsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PABCSTrackFailModel*)pABunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pABdelSerializedBean:(PABCSTrackFailModel*)bean;
//+(NSArray <PABCSTrackFailModel *>*)pABgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pABretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
