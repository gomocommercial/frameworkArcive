//
//  HPFCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "HPFCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)hPFsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(HPFCSTrackFailModel*)hPFunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)hPFdelSerializedBean:(HPFCSTrackFailModel*)bean;
//+(NSArray <HPFCSTrackFailModel *>*)hPFgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)hPFretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
