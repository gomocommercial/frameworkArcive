//
//  HPFBuyChannelIPCheckSessionManager.h
//  HPFCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "HPFCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HPFBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(HPFBuyChannelIPCheckSessionManager*)hPFsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(HPFBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)hPFstartAsyncRequestComplete:(void(^)(HPFCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
