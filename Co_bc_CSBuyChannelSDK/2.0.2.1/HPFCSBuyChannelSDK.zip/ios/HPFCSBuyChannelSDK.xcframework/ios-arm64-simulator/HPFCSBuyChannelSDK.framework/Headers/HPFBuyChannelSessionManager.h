//
//  HPFBuyChannelSessionManager.h
//  HPFCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "HPFCSBuyChannelHTTPResponse.h"
#import "HPFBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface HPFBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(HPFBuyChannelSessionManager*)hPFsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(HPFBuyChannelSessionManager*)getBuySessionManager;

-(void)hPFstartAsyncRequestComplete:(void(^)(HPFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)hPFtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(HPFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
