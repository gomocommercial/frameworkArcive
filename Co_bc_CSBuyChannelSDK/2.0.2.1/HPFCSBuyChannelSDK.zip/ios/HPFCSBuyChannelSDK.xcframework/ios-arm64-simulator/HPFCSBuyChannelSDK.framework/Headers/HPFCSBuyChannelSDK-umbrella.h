#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "HPFBuyChannelAFAPISessionManager.h"
#import "HPFBuyChannelFBSessionManager.h"
#import "HPFBuyChannelIPCheckSessionManager.h"
#import "HPFBuyChannelNetworkTools.h"
#import "HPFBuyChannelSessionManager.h"
#import "HPFBuyChannelWebEvent.h"
#import "HPFCSBuyChannel.h"
#import "HPFCSBuyChannelFlyerModel.h"
#import "HPFCSBuyChannelFlyerOneLinkModel.h"
#import "HPFCSBuyChannelHTTPResponse.h"
#import "HPFCSBuyChannelInitParams.h"
#import "HPFCSBuyChannelRequestSerializer.h"
#import "HPFCSBuyChannelSecureManager.h"
#import "HPFCSBuyPheadModel.h"
#import "HPFCSCustomPostData.h"
#import "HPFCSTrackFailManager.h"
#import "HPFCSTrackFailModel.h"
#import "NSString+HPFCSBuyChannelSecure.h"
#import "HPFBuyChannelAFAPISessionManager.h"
#import "HPFBuyChannelFBSessionManager.h"
#import "HPFBuyChannelIPCheckSessionManager.h"
#import "HPFBuyChannelNetworkTools.h"
#import "HPFBuyChannelSessionManager.h"
#import "HPFBuyChannelWebEvent.h"
#import "HPFCSBuyChannel.h"
#import "HPFCSBuyChannelFlyerModel.h"
#import "HPFCSBuyChannelFlyerOneLinkModel.h"
#import "HPFCSBuyChannelHTTPResponse.h"
#import "HPFCSBuyChannelInitParams.h"
#import "HPFCSBuyChannelRequestSerializer.h"
#import "HPFCSBuyChannelSecureManager.h"
#import "HPFCSBuyPheadModel.h"
#import "HPFCSCustomPostData.h"
#import "HPFCSTrackFailManager.h"
#import "HPFCSTrackFailModel.h"
#import "NSString+HPFCSBuyChannelSecure.h"

FOUNDATION_EXPORT double HPFCSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char HPFCSBuyChannelSDKVersionString[];

