//
//  MMSWBuyChannelSessionManager.h
//  MMSWCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "MMSWCSBuyChannelHTTPResponse.h"
#import "MMSWBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface MMSWBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(MMSWBuyChannelSessionManager*)mMSWsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(MMSWBuyChannelSessionManager*)getBuySessionManager;

-(void)mMSWstartAsyncRequestComplete:(void(^)(MMSWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)mMSWtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MMSWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
