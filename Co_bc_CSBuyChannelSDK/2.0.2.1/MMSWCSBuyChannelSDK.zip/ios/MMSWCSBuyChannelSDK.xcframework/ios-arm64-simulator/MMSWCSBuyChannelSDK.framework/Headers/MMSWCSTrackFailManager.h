//
//  MMSWCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MMSWCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MMSWCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mMSWsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MMSWCSTrackFailModel*)mMSWunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mMSWdelSerializedBean:(MMSWCSTrackFailModel*)bean;
//+(NSArray <MMSWCSTrackFailModel *>*)mMSWgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mMSWretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
