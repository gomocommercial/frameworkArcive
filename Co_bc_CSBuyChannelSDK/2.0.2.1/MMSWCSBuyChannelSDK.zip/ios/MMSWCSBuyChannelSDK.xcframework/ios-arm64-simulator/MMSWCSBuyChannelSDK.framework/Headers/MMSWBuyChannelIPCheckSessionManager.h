//
//  MMSWBuyChannelIPCheckSessionManager.h
//  MMSWCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "MMSWCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MMSWBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(MMSWBuyChannelIPCheckSessionManager*)mMSWsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(MMSWBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)mMSWstartAsyncRequestComplete:(void(^)(MMSWCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
