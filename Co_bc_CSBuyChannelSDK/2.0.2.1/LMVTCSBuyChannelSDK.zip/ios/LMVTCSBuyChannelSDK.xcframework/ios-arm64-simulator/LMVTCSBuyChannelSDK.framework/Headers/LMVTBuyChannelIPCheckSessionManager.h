//
//  LMVTBuyChannelIPCheckSessionManager.h
//  LMVTCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "LMVTCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LMVTBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(LMVTBuyChannelIPCheckSessionManager*)lMVTsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LMVTBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)lMVTstartAsyncRequestComplete:(void(^)(LMVTCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
