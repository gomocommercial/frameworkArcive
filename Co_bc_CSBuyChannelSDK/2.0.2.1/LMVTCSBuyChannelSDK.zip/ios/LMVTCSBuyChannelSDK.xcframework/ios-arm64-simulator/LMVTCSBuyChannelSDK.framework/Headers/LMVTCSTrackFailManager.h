//
//  LMVTCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LMVTCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LMVTCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lMVTsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LMVTCSTrackFailModel*)lMVTunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lMVTdelSerializedBean:(LMVTCSTrackFailModel*)bean;
//+(NSArray <LMVTCSTrackFailModel *>*)lMVTgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lMVTretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
