//
//  LMVTBuyChannelSessionManager.h
//  LMVTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "LMVTCSBuyChannelHTTPResponse.h"
#import "LMVTBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LMVTBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(LMVTBuyChannelSessionManager*)lMVTsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(LMVTBuyChannelSessionManager*)getBuySessionManager;

-(void)lMVTstartAsyncRequestComplete:(void(^)(LMVTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lMVTtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LMVTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
