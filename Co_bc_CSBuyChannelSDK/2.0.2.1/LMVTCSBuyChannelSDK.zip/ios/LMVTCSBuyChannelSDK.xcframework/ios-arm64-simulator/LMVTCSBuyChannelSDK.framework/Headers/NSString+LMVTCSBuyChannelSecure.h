//
//  NSString+LMVTCSBuyChannelSecure.h
//  LMVTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (LMVTCSBuyChannelSecure)

+(NSString *)lMVTbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)lMVTbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
