//
//  LMVTCSBuyPheadModel.h
//  LMVTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LMVTCSBuyPheadModel : NSObject

+ (NSDictionary *)lMVTgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
