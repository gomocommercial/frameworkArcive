//
//  STPBCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "STPBCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sTPBsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(STPBCSTrackFailModel*)sTPBunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sTPBdelSerializedBean:(STPBCSTrackFailModel*)bean;
//+(NSArray <STPBCSTrackFailModel *>*)sTPBgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sTPBretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
