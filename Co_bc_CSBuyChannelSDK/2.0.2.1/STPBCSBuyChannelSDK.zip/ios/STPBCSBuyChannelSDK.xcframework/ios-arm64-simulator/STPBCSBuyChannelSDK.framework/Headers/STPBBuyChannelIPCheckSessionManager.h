//
//  STPBBuyChannelIPCheckSessionManager.h
//  STPBCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "STPBCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STPBBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(STPBBuyChannelIPCheckSessionManager*)sTPBsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(STPBBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sTPBstartAsyncRequestComplete:(void(^)(STPBCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
