#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "NSString+STPBCSBuyChannelSecure.h"
#import "STPBBuyChannelAFAPISessionManager.h"
#import "STPBBuyChannelFBSessionManager.h"
#import "STPBBuyChannelIPCheckSessionManager.h"
#import "STPBBuyChannelNetworkTools.h"
#import "STPBBuyChannelSessionManager.h"
#import "STPBBuyChannelWebEvent.h"
#import "STPBCSBuyChannel.h"
#import "STPBCSBuyChannelFlyerModel.h"
#import "STPBCSBuyChannelFlyerOneLinkModel.h"
#import "STPBCSBuyChannelHTTPResponse.h"
#import "STPBCSBuyChannelInitParams.h"
#import "STPBCSBuyChannelRequestSerializer.h"
#import "STPBCSBuyChannelSecureManager.h"
#import "STPBCSBuyPheadModel.h"
#import "STPBCSCustomPostData.h"
#import "STPBCSTrackFailManager.h"
#import "STPBCSTrackFailModel.h"
#import "NSString+STPBCSBuyChannelSecure.h"
#import "STPBBuyChannelAFAPISessionManager.h"
#import "STPBBuyChannelFBSessionManager.h"
#import "STPBBuyChannelIPCheckSessionManager.h"
#import "STPBBuyChannelNetworkTools.h"
#import "STPBBuyChannelSessionManager.h"
#import "STPBBuyChannelWebEvent.h"
#import "STPBCSBuyChannel.h"
#import "STPBCSBuyChannelFlyerModel.h"
#import "STPBCSBuyChannelFlyerOneLinkModel.h"
#import "STPBCSBuyChannelHTTPResponse.h"
#import "STPBCSBuyChannelInitParams.h"
#import "STPBCSBuyChannelRequestSerializer.h"
#import "STPBCSBuyChannelSecureManager.h"
#import "STPBCSBuyPheadModel.h"
#import "STPBCSCustomPostData.h"
#import "STPBCSTrackFailManager.h"
#import "STPBCSTrackFailModel.h"

FOUNDATION_EXPORT double STPBCSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char STPBCSBuyChannelSDKVersionString[];

