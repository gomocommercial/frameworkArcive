//
//  STPBBuyChannelSessionManager.h
//  STPBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "STPBCSBuyChannelHTTPResponse.h"
#import "STPBBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface STPBBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(STPBBuyChannelSessionManager*)sTPBsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(STPBBuyChannelSessionManager*)getBuySessionManager;

-(void)sTPBstartAsyncRequestComplete:(void(^)(STPBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sTPBtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(STPBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
