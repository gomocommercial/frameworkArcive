//
//  PCRBuyChannelIPCheckSessionManager.h
//  PCRCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "PCRCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCRBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(PCRBuyChannelIPCheckSessionManager*)pCRsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PCRBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)pCRstartAsyncRequestComplete:(void(^)(PCRCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
