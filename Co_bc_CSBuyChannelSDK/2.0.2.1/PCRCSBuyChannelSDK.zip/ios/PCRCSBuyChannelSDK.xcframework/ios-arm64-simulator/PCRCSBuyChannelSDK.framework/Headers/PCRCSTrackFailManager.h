//
//  PCRCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PCRCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCRCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pCRsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PCRCSTrackFailModel*)pCRunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pCRdelSerializedBean:(PCRCSTrackFailModel*)bean;
//+(NSArray <PCRCSTrackFailModel *>*)pCRgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pCRretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
