//
//  PCRBuyChannelSessionManager.h
//  PCRCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "PCRCSBuyChannelHTTPResponse.h"
#import "PCRBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCRBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(PCRBuyChannelSessionManager*)pCRsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PCRBuyChannelSessionManager*)getBuySessionManager;

-(void)pCRstartAsyncRequestComplete:(void(^)(PCRCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pCRtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PCRCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
