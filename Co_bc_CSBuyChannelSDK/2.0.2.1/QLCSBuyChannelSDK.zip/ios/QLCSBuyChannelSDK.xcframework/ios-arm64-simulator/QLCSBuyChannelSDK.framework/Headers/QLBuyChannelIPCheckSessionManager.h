//
//  QLBuyChannelIPCheckSessionManager.h
//  QLCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "QLCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface QLBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(QLBuyChannelIPCheckSessionManager*)qLsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(QLBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)qLstartAsyncRequestComplete:(void(^)(QLCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
