//
//  QLBuyChannelSessionManager.h
//  QLCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "QLCSBuyChannelHTTPResponse.h"
#import "QLBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface QLBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(QLBuyChannelSessionManager*)qLsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(QLBuyChannelSessionManager*)getBuySessionManager;

-(void)qLstartAsyncRequestComplete:(void(^)(QLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)qLtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(QLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
