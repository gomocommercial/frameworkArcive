//
//  QLCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "QLCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface QLCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)qLsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(QLCSTrackFailModel*)qLunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)qLdelSerializedBean:(QLCSTrackFailModel*)bean;
//+(NSArray <QLCSTrackFailModel *>*)qLgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)qLretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
