//
//  JPBuyChannelSessionManager.h
//  JPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "JPCSBuyChannelHTTPResponse.h"
#import "JPBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface JPBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(JPBuyChannelSessionManager*)jPsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(JPBuyChannelSessionManager*)getBuySessionManager;

-(void)jPstartAsyncRequestComplete:(void(^)(JPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)jPtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(JPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
