//
//  JPBuyChannelIPCheckSessionManager.h
//  JPCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "JPCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JPBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(JPBuyChannelIPCheckSessionManager*)jPsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(JPBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)jPstartAsyncRequestComplete:(void(^)(JPCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
