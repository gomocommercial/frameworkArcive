//
//  SBCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "SBCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sBCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(SBCCSTrackFailModel*)sBCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sBCdelSerializedBean:(SBCCSTrackFailModel*)bean;
//+(NSArray <SBCCSTrackFailModel *>*)sBCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sBCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
