//
//  SBCBuyChannelIPCheckSessionManager.h
//  SBCCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "SBCCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBCBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(SBCBuyChannelIPCheckSessionManager*)sBCsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(SBCBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sBCstartAsyncRequestComplete:(void(^)(SBCCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
