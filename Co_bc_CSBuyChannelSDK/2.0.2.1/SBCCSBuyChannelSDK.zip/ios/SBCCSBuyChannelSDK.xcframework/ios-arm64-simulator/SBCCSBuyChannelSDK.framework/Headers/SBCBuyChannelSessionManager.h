//
//  SBCBuyChannelSessionManager.h
//  SBCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "SBCCSBuyChannelHTTPResponse.h"
#import "SBCBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBCBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(SBCBuyChannelSessionManager*)sBCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(SBCBuyChannelSessionManager*)getBuySessionManager;

-(void)sBCstartAsyncRequestComplete:(void(^)(SBCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sBCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SBCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
