//
//  PSEBuyChannelIPCheckSessionManager.h
//  PSECSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "PSECSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSEBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(PSEBuyChannelIPCheckSessionManager*)pSEsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PSEBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)pSEstartAsyncRequestComplete:(void(^)(PSECSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
