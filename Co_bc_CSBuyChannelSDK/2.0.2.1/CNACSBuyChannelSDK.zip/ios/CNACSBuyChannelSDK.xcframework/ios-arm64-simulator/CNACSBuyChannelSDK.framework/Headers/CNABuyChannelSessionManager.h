//
//  CNABuyChannelSessionManager.h
//  CNACSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "CNACSBuyChannelHTTPResponse.h"
#import "CNABuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface CNABuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(CNABuyChannelSessionManager*)cNAsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(CNABuyChannelSessionManager*)getBuySessionManager;

-(void)cNAstartAsyncRequestComplete:(void(^)(CNACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cNAtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CNACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
