//
//  CNACSBuyPheadModel.h
//  CNACSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CNACSBuyPheadModel : NSObject

+ (NSDictionary *)cNAgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
