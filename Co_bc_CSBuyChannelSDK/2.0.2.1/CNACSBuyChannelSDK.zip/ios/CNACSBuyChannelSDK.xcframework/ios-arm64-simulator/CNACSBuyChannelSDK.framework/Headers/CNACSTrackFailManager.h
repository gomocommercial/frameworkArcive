//
//  CNACSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CNACSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CNACSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cNAsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CNACSTrackFailModel*)cNAunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cNAdelSerializedBean:(CNACSTrackFailModel*)bean;
//+(NSArray <CNACSTrackFailModel *>*)cNAgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cNAretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
