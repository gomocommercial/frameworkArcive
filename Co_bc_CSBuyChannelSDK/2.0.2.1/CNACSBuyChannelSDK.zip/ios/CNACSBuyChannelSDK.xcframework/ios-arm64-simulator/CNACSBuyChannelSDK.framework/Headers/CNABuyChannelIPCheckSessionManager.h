//
//  CNABuyChannelIPCheckSessionManager.h
//  CNACSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "CNACSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CNABuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(CNABuyChannelIPCheckSessionManager*)cNAsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CNABuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cNAstartAsyncRequestComplete:(void(^)(CNACSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
