//
//  CLECSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CLECSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CLECSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cLEsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CLECSTrackFailModel*)cLEunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cLEdelSerializedBean:(CLECSTrackFailModel*)bean;
//+(NSArray <CLECSTrackFailModel *>*)cLEgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cLEretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
