//
//  CLECSPayNotificationSecureManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/28.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLECSBuyChannelSecureManager : NSObject

//加密
+ (NSData *)cLEencryptUseDES2:(NSString *)plainText key:(NSString *)key keyBase64:(BOOL)keyNeedBase64;

//解密
+ (NSString *)cLEdecryptUseDES:(NSData *)cipherData key:(NSString *)key keyNeedBase64:(BOOL)keyNeedBase64;

@end

NS_ASSUME_NONNULL_END
