//
//  CLEBuyChannelSessionManager.h
//  CLECSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "CLECSBuyChannelHTTPResponse.h"
#import "CLEBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface CLEBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(CLEBuyChannelSessionManager*)cLEsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(CLEBuyChannelSessionManager*)getBuySessionManager;

-(void)cLEstartAsyncRequestComplete:(void(^)(CLECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cLEtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CLECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
