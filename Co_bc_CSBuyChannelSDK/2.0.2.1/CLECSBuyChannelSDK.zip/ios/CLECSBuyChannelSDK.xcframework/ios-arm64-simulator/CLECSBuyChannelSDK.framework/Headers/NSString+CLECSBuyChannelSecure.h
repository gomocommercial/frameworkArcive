//
//  NSString+CLECSBuyChannelSecure.h
//  CLECSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (CLECSBuyChannelSecure)

+(NSString *)cLEbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)cLEbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
