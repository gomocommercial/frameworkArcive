//
//  CLEBuyChannelIPCheckSessionManager.h
//  CLECSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "CLECSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CLEBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(CLEBuyChannelIPCheckSessionManager*)cLEsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CLEBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cLEstartAsyncRequestComplete:(void(^)(CLECSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
