//
//  TIVBuyChannelSessionManager.h
//  TIVCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "TIVCSBuyChannelHTTPResponse.h"
#import "TIVBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface TIVBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(TIVBuyChannelSessionManager*)tIVsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(TIVBuyChannelSessionManager*)getBuySessionManager;

-(void)tIVstartAsyncRequestComplete:(void(^)(TIVCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)tIVtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(TIVCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
