//
//  TIVBuyChannelIPCheckSessionManager.h
//  TIVCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "TIVCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TIVBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(TIVBuyChannelIPCheckSessionManager*)tIVsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TIVBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)tIVstartAsyncRequestComplete:(void(^)(TIVCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
