//
//  TIVCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "TIVCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TIVCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)tIVsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(TIVCSTrackFailModel*)tIVunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)tIVdelSerializedBean:(TIVCSTrackFailModel*)bean;
//+(NSArray <TIVCSTrackFailModel *>*)tIVgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)tIVretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
