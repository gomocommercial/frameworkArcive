//
//  FSLPBuyChannelSessionManager.h
//  FSLPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "FSLPCSBuyChannelHTTPResponse.h"
#import "FSLPBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLPBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(FSLPBuyChannelSessionManager*)fSLPsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(FSLPBuyChannelSessionManager*)getBuySessionManager;

-(void)fSLPstartAsyncRequestComplete:(void(^)(FSLPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)fSLPtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(FSLPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
