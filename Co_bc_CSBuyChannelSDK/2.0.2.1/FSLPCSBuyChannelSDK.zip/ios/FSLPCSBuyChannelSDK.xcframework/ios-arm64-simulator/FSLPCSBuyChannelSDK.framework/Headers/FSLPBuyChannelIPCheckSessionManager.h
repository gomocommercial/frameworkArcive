//
//  FSLPBuyChannelIPCheckSessionManager.h
//  FSLPCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "FSLPCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLPBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(FSLPBuyChannelIPCheckSessionManager*)fSLPsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(FSLPBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)fSLPstartAsyncRequestComplete:(void(^)(FSLPCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
