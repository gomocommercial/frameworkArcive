//
//  FSLPCSBuyPheadModel.h
//  FSLPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSBuyPheadModel : NSObject

+ (NSDictionary *)fSLPgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
