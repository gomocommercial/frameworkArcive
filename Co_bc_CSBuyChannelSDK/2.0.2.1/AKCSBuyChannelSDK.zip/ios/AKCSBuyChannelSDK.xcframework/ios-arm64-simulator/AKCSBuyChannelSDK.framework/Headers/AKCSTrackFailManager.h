//
//  AKCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "AKCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AKCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)aKsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(AKCSTrackFailModel*)aKunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)aKdelSerializedBean:(AKCSTrackFailModel*)bean;
//+(NSArray <AKCSTrackFailModel *>*)aKgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)aKretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
