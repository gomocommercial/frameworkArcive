//
//  AKBuyChannelSessionManager.h
//  AKCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "AKCSBuyChannelHTTPResponse.h"
#import "AKBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface AKBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(AKBuyChannelSessionManager*)aKsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(AKBuyChannelSessionManager*)getBuySessionManager;

-(void)aKstartAsyncRequestComplete:(void(^)(AKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)aKtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(AKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
