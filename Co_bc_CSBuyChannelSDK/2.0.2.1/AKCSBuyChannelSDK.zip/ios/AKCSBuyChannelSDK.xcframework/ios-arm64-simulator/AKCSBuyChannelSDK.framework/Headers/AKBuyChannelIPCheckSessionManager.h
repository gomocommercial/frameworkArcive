//
//  AKBuyChannelIPCheckSessionManager.h
//  AKCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "AKCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AKBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(AKBuyChannelIPCheckSessionManager*)aKsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(AKBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)aKstartAsyncRequestComplete:(void(^)(AKCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
