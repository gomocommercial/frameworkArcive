//
//  MEETAICSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MEETAICSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MEETAICSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mEETAIsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MEETAICSTrackFailModel*)mEETAIunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mEETAIdelSerializedBean:(MEETAICSTrackFailModel*)bean;
//+(NSArray <MEETAICSTrackFailModel *>*)mEETAIgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mEETAIretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
