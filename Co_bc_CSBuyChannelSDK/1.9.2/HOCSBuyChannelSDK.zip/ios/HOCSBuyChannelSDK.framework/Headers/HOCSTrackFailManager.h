//
//  HOCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "HOCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HOCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)hOsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(HOCSTrackFailModel*)hOunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)hOdelSerializedBean:(HOCSTrackFailModel*)bean;
//+(NSArray <HOCSTrackFailModel *>*)hOgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)hOretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
