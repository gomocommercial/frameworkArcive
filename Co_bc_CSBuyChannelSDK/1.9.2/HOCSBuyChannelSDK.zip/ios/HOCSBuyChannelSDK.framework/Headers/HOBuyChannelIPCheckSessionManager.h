//
//  HOBuyChannelIPCheckSessionManager.h
//  HOCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "HOCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HOBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(HOBuyChannelIPCheckSessionManager*)hOsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(HOBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)hOstartAsyncRequestComplete:(void(^)(HOCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
