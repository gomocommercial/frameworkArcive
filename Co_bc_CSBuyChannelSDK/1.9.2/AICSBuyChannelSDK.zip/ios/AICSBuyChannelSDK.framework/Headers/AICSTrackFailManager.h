//
//  AICSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "AICSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AICSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)aIsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(AICSTrackFailModel*)aIunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)aIdelSerializedBean:(AICSTrackFailModel*)bean;
//+(NSArray <AICSTrackFailModel *>*)aIgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)aIretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
