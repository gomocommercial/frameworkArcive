//
//  GSBuyChannelSessionManager.h
//  GSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "GSCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface GSBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(GSBuyChannelSessionManager*)gSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(GSBuyChannelSessionManager*)getBuySessionManager;

-(void)gSstartAsyncRequestComplete:(void(^)(GSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)gStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(GSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
