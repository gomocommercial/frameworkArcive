//
//  WOCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "WOCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface WOCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)wOsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(WOCSTrackFailModel*)wOunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)wOdelSerializedBean:(WOCSTrackFailModel*)bean;
//+(NSArray <WOCSTrackFailModel *>*)wOgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)wOretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
