//
//  WOBuyChannelSessionManager.h
//  WOCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "WOCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface WOBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(WOBuyChannelSessionManager*)wOsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(WOBuyChannelSessionManager*)getBuySessionManager;

-(void)wOstartAsyncRequestComplete:(void(^)(WOCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)wOtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(WOCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
