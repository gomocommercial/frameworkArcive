//
//  VCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "VCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface VCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)vCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(VCCSTrackFailModel*)vCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)vCdelSerializedBean:(VCCSTrackFailModel*)bean;
//+(NSArray <VCCSTrackFailModel *>*)vCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)vCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
