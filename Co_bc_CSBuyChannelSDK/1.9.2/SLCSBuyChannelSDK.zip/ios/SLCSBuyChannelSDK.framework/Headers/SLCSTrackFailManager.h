//
//  SLCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "SLCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SLCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sLsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(SLCSTrackFailModel*)sLunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sLdelSerializedBean:(SLCSTrackFailModel*)bean;
//+(NSArray <SLCSTrackFailModel *>*)sLgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sLretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
