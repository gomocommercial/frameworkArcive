//
//  SLBuyChannelIPCheckSessionManager.h
//  SLCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SLCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SLBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(SLBuyChannelIPCheckSessionManager*)sLsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(SLBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sLstartAsyncRequestComplete:(void(^)(SLCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
