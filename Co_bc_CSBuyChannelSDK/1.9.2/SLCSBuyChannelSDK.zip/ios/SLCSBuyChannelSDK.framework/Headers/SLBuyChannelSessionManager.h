//
//  SLBuyChannelSessionManager.h
//  SLCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SLCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface SLBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(SLBuyChannelSessionManager*)sLsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(SLBuyChannelSessionManager*)getBuySessionManager;

-(void)sLstartAsyncRequestComplete:(void(^)(SLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sLtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
