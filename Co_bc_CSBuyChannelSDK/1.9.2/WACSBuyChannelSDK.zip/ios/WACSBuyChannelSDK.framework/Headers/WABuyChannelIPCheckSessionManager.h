//
//  WABuyChannelIPCheckSessionManager.h
//  WACSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "WACSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface WABuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(WABuyChannelIPCheckSessionManager*)wAsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(WABuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)wAstartAsyncRequestComplete:(void(^)(WACSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
