//
//  QTBuyChannelIPCheckSessionManager.h
//  QTCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "QTCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface QTBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(QTBuyChannelIPCheckSessionManager*)qTsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(QTBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)qTstartAsyncRequestComplete:(void(^)(QTCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
