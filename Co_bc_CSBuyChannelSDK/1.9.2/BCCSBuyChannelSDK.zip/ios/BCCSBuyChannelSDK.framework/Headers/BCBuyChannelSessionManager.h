//
//  BCBuyChannelSessionManager.h
//  BCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "BCCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface BCBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(BCBuyChannelSessionManager*)bCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(BCBuyChannelSessionManager*)getBuySessionManager;

-(void)bCstartAsyncRequestComplete:(void(^)(BCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)bCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(BCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
