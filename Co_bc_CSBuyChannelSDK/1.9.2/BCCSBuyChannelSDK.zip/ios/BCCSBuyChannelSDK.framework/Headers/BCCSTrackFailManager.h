//
//  BCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "BCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)bCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(BCCSTrackFailModel*)bCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)bCdelSerializedBean:(BCCSTrackFailModel*)bean;
//+(NSArray <BCCSTrackFailModel *>*)bCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)bCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
