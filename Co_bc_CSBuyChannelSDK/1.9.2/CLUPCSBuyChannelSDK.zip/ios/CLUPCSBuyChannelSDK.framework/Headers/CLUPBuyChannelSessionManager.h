//
//  CLUPBuyChannelSessionManager.h
//  CLUPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CLUPCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface CLUPBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(CLUPBuyChannelSessionManager*)cLUPsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CLUPBuyChannelSessionManager*)getBuySessionManager;

-(void)cLUPstartAsyncRequestComplete:(void(^)(CLUPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cLUPtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CLUPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
