//
//  CCBuyChannelSessionManager.h
//  CCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CCCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(CCBuyChannelSessionManager*)cCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CCBuyChannelSessionManager*)getBuySessionManager;

-(void)cCstartAsyncRequestComplete:(void(^)(CCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
