//
//  CCBuyChannelIPCheckSessionManager.h
//  CCCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CCCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(CCBuyChannelIPCheckSessionManager*)cCsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CCBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cCstartAsyncRequestComplete:(void(^)(CCCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
