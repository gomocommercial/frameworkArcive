//
//  DGCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "DGCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DGCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)dGsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(DGCSTrackFailModel*)dGunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)dGdelSerializedBean:(DGCSTrackFailModel*)bean;
//+(NSArray <DGCSTrackFailModel *>*)dGgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)dGretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
