//
//  DCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "DCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)dCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(DCCSTrackFailModel*)dCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)dCdelSerializedBean:(DCCSTrackFailModel*)bean;
//+(NSArray <DCCSTrackFailModel *>*)dCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)dCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
