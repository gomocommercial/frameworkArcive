//
//  SCBuyChannelSessionManager.h
//  SCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import "AFHTTPSessionManager.h"
#import "SCCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface SCBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(SCBuyChannelSessionManager*)sCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(SCBuyChannelSessionManager*)getBuySessionManager;
-(void)sCstartAsyncRequestComplete:(void(^)(SCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
@end

NS_ASSUME_NONNULL_END
