//
//  LFBuyChannelSessionManager.h
//  LFCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LFCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface LFBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(LFBuyChannelSessionManager*)lFsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(LFBuyChannelSessionManager*)getBuySessionManager;
-(void)lFstartAsyncRequestComplete:(void(^)(LFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)lFtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
