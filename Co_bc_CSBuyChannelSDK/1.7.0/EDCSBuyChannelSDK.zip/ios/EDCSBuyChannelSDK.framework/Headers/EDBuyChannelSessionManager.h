//
//  EDBuyChannelSessionManager.h
//  EDCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "EDCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface EDBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(EDBuyChannelSessionManager*)eDsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(EDBuyChannelSessionManager*)getBuySessionManager;
-(void)eDstartAsyncRequestComplete:(void(^)(EDCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)eDtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(EDCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
