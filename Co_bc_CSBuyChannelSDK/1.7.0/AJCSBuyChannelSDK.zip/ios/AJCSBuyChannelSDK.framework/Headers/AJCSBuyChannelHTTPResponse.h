//
//  AJCSBuyChannelHTTPResponse.h
//  AJCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger , BuyChannelHttpStatus) {
    BuyChannelHttpStatusFail = -1,
    BuyChannelHttpStatusSuccess = 0,
};

@interface AJCSBuyChannelHTTPResponse : NSObject

@property (nonatomic) BuyChannelHttpStatus status;

/**
 http 的返回码
 */
@property (nonatomic, strong) NSError *error;
@property (nonatomic, copy) NSDictionary *bodyData;

@end

NS_ASSUME_NONNULL_END
