//
//  AJBuyChannelSessionManager.h
//  AJCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "AJCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface AJBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(AJBuyChannelSessionManager*)aJsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(AJBuyChannelSessionManager*)getBuySessionManager;
-(void)aJstartAsyncRequestComplete:(void(^)(AJCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)aJtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(AJCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
