//
//  AJCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "AJCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AJCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)aJsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(AJCSTrackFailModel*)aJunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)aJdelSerializedBean:(AJCSTrackFailModel*)bean;
//+(NSArray <AJCSTrackFailModel *>*)aJgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)aJretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
