//
//  PCBuyChannelSessionManager.h
//  PCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PCCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(PCBuyChannelSessionManager*)pCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(PCBuyChannelSessionManager*)getBuySessionManager;
-(void)pCstartAsyncRequestComplete:(void(^)(PCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)pCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
