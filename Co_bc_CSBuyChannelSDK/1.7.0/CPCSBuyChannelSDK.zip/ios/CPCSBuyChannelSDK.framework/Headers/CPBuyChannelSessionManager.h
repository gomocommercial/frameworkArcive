//
//  CPBuyChannelSessionManager.h
//  CPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CPCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(CPBuyChannelSessionManager*)cPsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(CPBuyChannelSessionManager*)getBuySessionManager;
-(void)cPstartAsyncRequestComplete:(void(^)(CPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)cPtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
