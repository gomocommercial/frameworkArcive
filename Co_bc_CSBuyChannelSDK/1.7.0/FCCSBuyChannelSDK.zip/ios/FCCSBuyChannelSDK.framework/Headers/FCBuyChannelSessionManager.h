//
//  FCBuyChannelSessionManager.h
//  FCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "FCCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface FCBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(FCBuyChannelSessionManager*)fCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(FCBuyChannelSessionManager*)getBuySessionManager;
-(void)fCstartAsyncRequestComplete:(void(^)(FCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)fCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(FCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
