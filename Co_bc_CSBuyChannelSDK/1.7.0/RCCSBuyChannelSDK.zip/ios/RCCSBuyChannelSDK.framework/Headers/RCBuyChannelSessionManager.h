//
//  RCBuyChannelSessionManager.h
//  RCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "RCCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface RCBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(RCBuyChannelSessionManager*)rCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(RCBuyChannelSessionManager*)getBuySessionManager;
-(void)rCstartAsyncRequestComplete:(void(^)(RCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)rCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(RCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
