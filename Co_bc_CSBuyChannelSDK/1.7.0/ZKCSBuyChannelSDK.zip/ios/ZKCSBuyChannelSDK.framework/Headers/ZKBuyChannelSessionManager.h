//
//  ZKBuyChannelSessionManager.h
//  ZKCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "ZKCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZKBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(ZKBuyChannelSessionManager*)zKsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(ZKBuyChannelSessionManager*)getBuySessionManager;
-(void)zKstartAsyncRequestComplete:(void(^)(ZKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)zKtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(ZKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
