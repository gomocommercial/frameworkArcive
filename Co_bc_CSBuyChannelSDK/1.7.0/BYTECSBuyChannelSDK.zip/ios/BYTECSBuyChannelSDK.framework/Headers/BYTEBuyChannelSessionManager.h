//
//  BYTEBuyChannelSessionManager.h
//  BYTECSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "BYTECSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface BYTEBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(BYTEBuyChannelSessionManager*)bYTEsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(BYTEBuyChannelSessionManager*)getBuySessionManager;
-(void)bYTEstartAsyncRequestComplete:(void(^)(BYTECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)bYTEtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(BYTECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
