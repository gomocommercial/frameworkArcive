//
//  BYTECSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "BYTECSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BYTECSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)bYTEsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(BYTECSTrackFailModel*)bYTEunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)bYTEdelSerializedBean:(BYTECSTrackFailModel*)bean;
//+(NSArray <BYTECSTrackFailModel *>*)bYTEgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)bYTEretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
