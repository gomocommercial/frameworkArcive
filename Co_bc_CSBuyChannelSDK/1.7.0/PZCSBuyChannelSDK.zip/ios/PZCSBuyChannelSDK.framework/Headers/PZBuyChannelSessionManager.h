//
//  PZBuyChannelSessionManager.h
//  PZCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PZCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface PZBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(PZBuyChannelSessionManager*)pZsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(PZBuyChannelSessionManager*)getBuySessionManager;
-(void)pZstartAsyncRequestComplete:(void(^)(PZCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)pZtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PZCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
