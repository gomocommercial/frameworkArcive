//
//  MJBuyChannelSessionManager.h
//  MJCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MJCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface MJBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(MJBuyChannelSessionManager*)mJsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(MJBuyChannelSessionManager*)getBuySessionManager;
-(void)mJstartAsyncRequestComplete:(void(^)(MJCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)mJtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MJCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
