//
//  MJCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MJCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MJCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mJsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MJCSTrackFailModel*)mJunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mJdelSerializedBean:(MJCSTrackFailModel*)bean;
//+(NSArray <MJCSTrackFailModel *>*)mJgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mJretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
