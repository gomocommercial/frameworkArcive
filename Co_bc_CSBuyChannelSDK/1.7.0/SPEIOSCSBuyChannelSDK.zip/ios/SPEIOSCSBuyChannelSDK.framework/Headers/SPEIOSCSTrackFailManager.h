//
//  SPEIOSCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "SPEIOSCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SPEIOSCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sPEIOSsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(SPEIOSCSTrackFailModel*)sPEIOSunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sPEIOSdelSerializedBean:(SPEIOSCSTrackFailModel*)bean;
//+(NSArray <SPEIOSCSTrackFailModel *>*)sPEIOSgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sPEIOSretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
