//
//  SPEIOSBuyChannelSessionManager.h
//  SPEIOSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SPEIOSCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface SPEIOSBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(SPEIOSBuyChannelSessionManager*)sPEIOSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(SPEIOSBuyChannelSessionManager*)getBuySessionManager;
-(void)sPEIOSstartAsyncRequestComplete:(void(^)(SPEIOSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)sPEIOStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SPEIOSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
