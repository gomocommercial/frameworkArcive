//
//  FBBuyChannelSessionManager.h
//  FBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "FBCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface FBBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(FBBuyChannelSessionManager*)fBsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(FBBuyChannelSessionManager*)getBuySessionManager;
-(void)fBstartAsyncRequestComplete:(void(^)(FBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)fBtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(FBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
