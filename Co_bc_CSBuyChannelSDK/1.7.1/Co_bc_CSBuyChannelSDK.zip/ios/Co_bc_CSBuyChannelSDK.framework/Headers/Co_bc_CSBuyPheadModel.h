//
//  Co_bc_CSBuyPheadModel.h
//  Co_bc_CSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_bc_CSBuyPheadModel : NSObject

+ (NSDictionary *)co_bc_getPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
