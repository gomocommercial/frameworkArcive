//
//  Co_bc_CSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "Co_bc_CSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_bc_CSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)co_bc_saveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(Co_bc_CSTrackFailModel*)co_bc_unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)co_bc_delSerializedBean:(Co_bc_CSTrackFailModel*)bean;
//+(NSArray <Co_bc_CSTrackFailModel *>*)co_bc_getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)co_bc_retryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
