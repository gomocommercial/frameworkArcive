//
//  Co_bc_BuyChannelSessionManager.h
//  Co_bc_CSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "Co_bc_CSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_bc_BuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(Co_bc_BuyChannelSessionManager*)co_bc_sharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(Co_bc_BuyChannelSessionManager*)getBuySessionManager;
-(void)co_bc_startAsyncRequestComplete:(void(^)(Co_bc_CSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)co_bc_trackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(Co_bc_CSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
