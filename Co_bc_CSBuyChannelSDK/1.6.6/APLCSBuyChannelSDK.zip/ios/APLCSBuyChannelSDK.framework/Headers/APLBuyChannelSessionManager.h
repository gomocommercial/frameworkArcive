//
//  APLBuyChannelSessionManager.h
//  APLCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import "AFHTTPSessionManager.h"
#import "APLCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface APLBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(APLBuyChannelSessionManager*)aPLsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(APLBuyChannelSessionManager*)getBuySessionManager;
-(void)aPLstartAsyncRequestComplete:(void(^)(APLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
@end

NS_ASSUME_NONNULL_END
