//
//  LDBuyChannelSessionManager.h
//  LDCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LDCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface LDBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(LDBuyChannelSessionManager*)lDsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(LDBuyChannelSessionManager*)getBuySessionManager;
-(void)lDstartAsyncRequestComplete:(void(^)(LDCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
@end

NS_ASSUME_NONNULL_END
