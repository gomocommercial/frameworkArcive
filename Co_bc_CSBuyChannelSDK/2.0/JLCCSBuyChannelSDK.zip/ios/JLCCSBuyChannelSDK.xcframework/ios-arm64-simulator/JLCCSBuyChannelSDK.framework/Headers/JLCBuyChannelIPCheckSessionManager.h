//
//  JLCBuyChannelIPCheckSessionManager.h
//  JLCCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "JLCCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JLCBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(JLCBuyChannelIPCheckSessionManager*)jLCsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(JLCBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)jLCstartAsyncRequestComplete:(void(^)(JLCCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
