//
//  JLCCSBuyChannelRequestSerializer.h
//  JLCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 请求体序列化工具类:
/// 将参数 JSON 序列化, 然后用 DES 加密, 再做 Base64, 最后以 UTF-8 字节作为 HTTP body
/// 与原基于 AFHTTPRequestSerializer 的 requestBySerializingRequest:withParameters:error: 行为保持一致
@interface JLCCSBuyChannelRequestSerializer : NSObject

@property (nonatomic, copy) NSString *desKey;

/// 用 desKey 对参数进行 DES 加密 + Base64, 返回可直接作为 HTTP Body 的 NSData
+ (nullable NSData *)jLCserializedBodyDataWithParameters:(nullable NSDictionary *)parameters
                                                     desKey:(NSString *)desKey;

@end

NS_ASSUME_NONNULL_END
