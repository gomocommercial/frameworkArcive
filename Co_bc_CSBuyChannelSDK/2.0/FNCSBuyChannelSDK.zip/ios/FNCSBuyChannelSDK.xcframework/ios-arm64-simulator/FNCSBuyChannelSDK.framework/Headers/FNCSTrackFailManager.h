//
//  FNCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "FNCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)fNsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(FNCSTrackFailModel*)fNunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)fNdelSerializedBean:(FNCSTrackFailModel*)bean;
//+(NSArray <FNCSTrackFailModel *>*)fNgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fNretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
