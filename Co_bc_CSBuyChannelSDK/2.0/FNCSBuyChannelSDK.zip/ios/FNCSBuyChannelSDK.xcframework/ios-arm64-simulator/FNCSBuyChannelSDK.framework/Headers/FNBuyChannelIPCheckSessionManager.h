//
//  FNBuyChannelIPCheckSessionManager.h
//  FNCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "FNCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(FNBuyChannelIPCheckSessionManager*)fNsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(FNBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)fNstartAsyncRequestComplete:(void(^)(FNCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
