//
//  SKBuyChannelSessionManager.h
//  SKCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SKCSBuyChannelHTTPResponse.h"
#import "SKBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface SKBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(SKBuyChannelSessionManager*)sKsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(SKBuyChannelSessionManager*)getBuySessionManager;

-(void)sKstartAsyncRequestComplete:(void(^)(SKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sKtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
