//
//  PPP_P_BuyChannelSessionManager.h
//  PPP_P_CSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PPP_P_CSBuyChannelHTTPResponse.h"
#import "PPP_P_BuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_BuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PPP_P_BuyChannelSessionManager*)pPP_P_sharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PPP_P_BuyChannelSessionManager*)getBuySessionManager;

-(void)pPP_P_startAsyncRequestComplete:(void(^)(PPP_P_CSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pPP_P_trackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PPP_P_CSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
