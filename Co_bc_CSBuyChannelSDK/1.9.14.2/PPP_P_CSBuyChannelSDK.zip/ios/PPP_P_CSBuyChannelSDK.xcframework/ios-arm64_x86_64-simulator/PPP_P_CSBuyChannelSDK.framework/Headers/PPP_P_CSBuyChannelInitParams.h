//
//  PPP_P_CSBuyChannelInitParams.h
//  PPP_P_CSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSBuyChannelInitParams : NSObject

//MARK: 买量初始化参数(必填)

/// AppsFlyer上面返回的appsDevKey
@property (nonatomic, copy)NSString * appsDevKey;

///  AppsFlyer上面返回的appleAppID
@property (nonatomic, copy)NSString * appleAppId;

/// 统计45协议功能点ID
@property (nonatomic, copy)NSString * funcId;

/// 统计协议产品ID
@property (nonatomic, copy)NSString * cid;

/// 是否开启LOG(默认为false)
@property (nonatomic, assign)BOOL enableLog;

/// 是否开启Debug模式(默认为false)
@property (nonatomic, assign)BOOL debugMode;

//MARK: 买量互补方案参数

/// 买量互补方案域名
@property (nonatomic, copy)NSString * supplementDomainName;

/// 买量互补方案签名秘钥
@property (nonatomic, copy)NSString * supplementSignatureKey;

/// 买量互补方案加密秘钥(默认:5NDZOADK)
@property (nonatomic, copy)NSString * supplementDesKey;

/// 买量互补方案产品标识
@property (nonatomic, copy)NSString * supplementProdKey;

/// 买量互补方案启用 IPv6， 默认为NO，请按文档申请域名后设置为 YES, 并通过 supplementGeoipAPIURL 设置 API 地址
/// https://wiki.3g.net.cn/pages/viewpage.action?pageId=35325635#id-%E4%B9%B0%E9%87%8F%E8%AF%86%E5%88%AB-API%E6%8E%A5%E5%8F%A3-1%E3%80%81%E4%B9%B0%E9%87%8F%E6%9D%A5%E6%BA%90%E8%AF%86%E5%88%AB%EF%BC%88ISO1818002%EF%BC%89
@property (nonatomic, assign)BOOL supplementEnableIPv6;

/// 买量互补方案Geoip API URL
@property (nonatomic, copy)NSString * supplementGeoipAPIURL;

/// Web 安装事件上报是否使用剪切板, 默认 YES
@property (nonatomic, assign)BOOL webInstallUsePasteboard;

/// Web事件上报域名
@property (nonatomic, copy)NSString * webEventDomainName;

/// Web事件上报签名秘钥
@property (nonatomic, copy)NSString * webEventSignatureKey;

/// Web事件上报加密秘钥
@property (nonatomic, copy)NSString * webEventDesKey;

/// Web事件上报产品标识
@property (nonatomic, copy)NSString * webEventProdKey;

/// 是否上传 web 安装事件数据到45
@property (nonatomic, assign) BOOL isUploadWebInstallTo45;

/// 是否优先执行自研归因
@property (nonatomic, assign) BOOL firstTrackService;


//MARK: 自研IP归因方案

/// 自研IP归因方案域名
@property (nonatomic, copy)NSString * ipDomainName;

/// 自研IP归因方案访问秘钥
@property (nonatomic, copy)NSString * ipAccessKey;

/// 自研IP归因方案产品标识
@property (nonatomic, copy)NSString * ipProdKey;

/// 买量互补方案加密秘钥(默认:5NDZOELE)
@property (nonatomic, copy)NSString * ipDesKey;

//MARK: 其他可选参数

/// af自定义用户标识(默认为统计协议用户ID)
@property (nonatomic, copy)NSString * afCustomerUserID;

///是否开启appsflyer的onelink深度链接回调，设置为true时，请从CSBuyChannelFlyerOneLinkModel获取结果，并且保证有网络了再初始化买量sdk（一启动就会回调结果并依赖网络）
@property (nonatomic, assign) BOOL isOpenOneLink;

///巨量广告转化融合归因优化上报等待时常（默认0.5s）,这个等待指的是融合归因优化上报之后请求自归因接口前的等待时间
@property (nonatomic, assign) CGFloat bdaWaitTime;
///是否开启巨量广告转化融合归因优化（默认开启，如果客户端外部已接入，可设置为false不开启，不开启时bdaWaitTime等待时长不生效)
@property (nonatomic, assign) BOOL isOpenBDAFlow;
///使用巨量广告转化融合时是否允许开启idfa（会触发att弹窗)，默认是关闭
@property (nonatomic, assign) BOOL isOpenBDAIdfa;

/// 校验必填参数
- (BOOL)pPP_P_buyChannelCheckParams;

/// 校验互补方案参数
- (BOOL)pPP_P_buyChannelCheckSupplementParams;

/// 校验IP归因参数
- (BOOL)pPP_P_buyChannelCheckIpParams;

/// 校验Web事件上报参数
- (BOOL)pPP_P_buyChannelCheckWebParams;

@end

NS_ASSUME_NONNULL_END
