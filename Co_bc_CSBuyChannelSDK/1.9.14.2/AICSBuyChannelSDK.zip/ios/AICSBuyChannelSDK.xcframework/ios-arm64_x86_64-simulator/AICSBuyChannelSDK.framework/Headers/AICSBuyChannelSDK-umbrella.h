#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "AIBuyChannelAFAPISessionManager.h"
#import "AIBuyChannelFBSessionManager.h"
#import "AIBuyChannelIPCheckSessionManager.h"
#import "AIBuyChannelNetworkTools.h"
#import "AIBuyChannelSessionManager.h"
#import "AIBuyChannelWebEvent.h"
#import "AICSBuyChannel.h"
#import "AICSBuyChannelFlyerModel.h"
#import "AICSBuyChannelFlyerOneLinkModel.h"
#import "AICSBuyChannelHTTPResponse.h"
#import "AICSBuyChannelInitParams.h"
#import "AICSBuyChannelRequestSerializer.h"
#import "AICSBuyChannelSecureManager.h"
#import "AICSBuyPheadModel.h"
#import "AICSCustomPostData.h"
#import "AICSTrackFailManager.h"
#import "AICSTrackFailModel.h"
#import "NSString+AICSBuyChannelSecure.h"
#import "AIBuyChannelAFAPISessionManager.h"
#import "AIBuyChannelFBSessionManager.h"
#import "AIBuyChannelIPCheckSessionManager.h"
#import "AIBuyChannelNetworkTools.h"
#import "AIBuyChannelSessionManager.h"
#import "AIBuyChannelWebEvent.h"
#import "AICSBuyChannel.h"
#import "AICSBuyChannelFlyerModel.h"
#import "AICSBuyChannelFlyerOneLinkModel.h"
#import "AICSBuyChannelHTTPResponse.h"
#import "AICSBuyChannelInitParams.h"
#import "AICSBuyChannelRequestSerializer.h"
#import "AICSBuyChannelSecureManager.h"
#import "AICSBuyPheadModel.h"
#import "AICSCustomPostData.h"
#import "AICSTrackFailManager.h"
#import "AICSTrackFailModel.h"
#import "NSString+AICSBuyChannelSecure.h"

FOUNDATION_EXPORT double AICSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char AICSBuyChannelSDKVersionString[];

