#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "NSString+WACSBuyChannelSecure.h"
#import "WABuyChannelAFAPISessionManager.h"
#import "WABuyChannelIPCheckSessionManager.h"
#import "WABuyChannelNetworkTools.h"
#import "WABuyChannelSessionManager.h"
#import "WACSBuyChannel.h"
#import "WACSBuyChannelFlyerModel.h"
#import "WACSBuyChannelFlyerOneLinkModel.h"
#import "WACSBuyChannelHTTPResponse.h"
#import "WACSBuyChannelInitParams.h"
#import "WACSBuyChannelIPCheckRequestSerializer.h"
#import "WACSBuyChannelRequestSerializer.h"
#import "WACSBuyChannelSecureManager.h"
#import "WACSBuyPheadModel.h"
#import "WACSCustomPostData.h"
#import "WACSTrackFailManager.h"
#import "WACSTrackFailModel.h"
#import "NSString+WACSBuyChannelSecure.h"
#import "WABuyChannelAFAPISessionManager.h"
#import "WABuyChannelIPCheckSessionManager.h"
#import "WABuyChannelNetworkTools.h"
#import "WABuyChannelSessionManager.h"
#import "WACSBuyChannel.h"
#import "WACSBuyChannelFlyerModel.h"
#import "WACSBuyChannelFlyerOneLinkModel.h"
#import "WACSBuyChannelHTTPResponse.h"
#import "WACSBuyChannelInitParams.h"
#import "WACSBuyChannelIPCheckRequestSerializer.h"
#import "WACSBuyChannelRequestSerializer.h"
#import "WACSBuyChannelSecureManager.h"
#import "WACSBuyPheadModel.h"
#import "WACSCustomPostData.h"
#import "WACSTrackFailManager.h"
#import "WACSTrackFailModel.h"

FOUNDATION_EXPORT double WACSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char WACSBuyChannelSDKVersionString[];

