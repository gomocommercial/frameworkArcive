//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface WABuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)wAgetIPv6AddressesOfAllInterface;
+ (NSString *)wAgetIPv6AddressOfInterfaces;
+ (NSString *)wAgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end