//
//  TTACSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "TTACSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTACSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)tTAsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(TTACSTrackFailModel*)tTAunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)tTAdelSerializedBean:(TTACSTrackFailModel*)bean;
//+(NSArray <TTACSTrackFailModel *>*)tTAgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)tTAretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
