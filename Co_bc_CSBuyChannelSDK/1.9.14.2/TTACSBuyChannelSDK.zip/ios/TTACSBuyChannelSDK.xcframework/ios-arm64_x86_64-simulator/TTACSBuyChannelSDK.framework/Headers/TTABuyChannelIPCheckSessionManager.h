//
//  TTABuyChannelIPCheckSessionManager.h
//  TTACSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "TTACSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTABuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(TTABuyChannelIPCheckSessionManager*)tTAsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TTABuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)tTAstartAsyncRequestComplete:(void(^)(TTACSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
