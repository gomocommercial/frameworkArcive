//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface WIOBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)wIOgetIPv6AddressesOfAllInterface;
+ (NSString *)wIOgetIPv6AddressOfInterfaces;
+ (NSString *)wIOgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end