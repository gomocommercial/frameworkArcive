//
//  CFCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CFCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cFsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CFCSTrackFailModel*)cFunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cFdelSerializedBean:(CFCSTrackFailModel*)bean;
//+(NSArray <CFCSTrackFailModel *>*)cFgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cFretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
