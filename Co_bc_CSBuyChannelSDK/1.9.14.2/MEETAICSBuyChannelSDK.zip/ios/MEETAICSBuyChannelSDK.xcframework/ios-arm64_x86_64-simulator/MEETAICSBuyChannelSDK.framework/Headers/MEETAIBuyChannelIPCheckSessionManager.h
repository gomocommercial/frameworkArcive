//
//  MEETAIBuyChannelIPCheckSessionManager.h
//  MEETAICSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MEETAICSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MEETAIBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(MEETAIBuyChannelIPCheckSessionManager*)mEETAIsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(MEETAIBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)mEETAIstartAsyncRequestComplete:(void(^)(MEETAICSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
