//
//  JMSBuyChannelSessionManager.h
//  JMSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "JMSCSBuyChannelHTTPResponse.h"
#import "JMSBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface JMSBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(JMSBuyChannelSessionManager*)jMSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(JMSBuyChannelSessionManager*)getBuySessionManager;

-(void)jMSstartAsyncRequestComplete:(void(^)(JMSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)jMStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(JMSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
