//
//  JMSCSBuyPheadModel.h
//  JMSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JMSCSBuyPheadModel : NSObject

+ (NSDictionary *)jMSgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
