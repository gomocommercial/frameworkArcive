//
//  JMSBuyChannelIPCheckSessionManager.h
//  JMSCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "JMSCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JMSBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(JMSBuyChannelIPCheckSessionManager*)jMSsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(JMSBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)jMSstartAsyncRequestComplete:(void(^)(JMSCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
