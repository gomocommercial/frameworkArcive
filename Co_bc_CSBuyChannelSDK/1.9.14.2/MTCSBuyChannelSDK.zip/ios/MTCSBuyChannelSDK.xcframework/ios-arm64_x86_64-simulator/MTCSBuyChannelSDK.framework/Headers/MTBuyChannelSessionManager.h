//
//  MTBuyChannelSessionManager.h
//  MTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MTCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface MTBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(MTBuyChannelSessionManager*)mTsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(MTBuyChannelSessionManager*)getBuySessionManager;

-(void)mTstartAsyncRequestComplete:(void(^)(MTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)mTtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
