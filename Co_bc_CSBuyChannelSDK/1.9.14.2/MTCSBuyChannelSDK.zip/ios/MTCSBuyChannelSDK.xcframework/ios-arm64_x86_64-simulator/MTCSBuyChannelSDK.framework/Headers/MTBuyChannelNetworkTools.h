//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface MTBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)mTgetIPv6AddressesOfAllInterface;
+ (NSString *)mTgetIPv6AddressOfInterfaces;
+ (NSString *)mTgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end