//
//  PABuyChannelWebEvent.h
//  PACSBuyChannelSDK
//
//  Created by Kevin Guo on 2025/6/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
//        eventType	String	事件类型
//订阅事件: subscribe
//
//        注册事件: register
//
//自定义启用事件: login
//
//        购买事件: purchase
//
//        试用事件: startTrial
//
//        有试用首次付费订阅: startTrialSubscribe
//
//        无试用付费订阅: noTrialSubscribe
//
//        eventTime	String	触发事件的时间，以毫秒为单位时间戳
//        样例：1575194434123
//
//attribute	String	事件属性
//        若是订阅或者购买事件，则传订单号
//
//        currency
//
//String	币种	购买事件必传
//        value
//Integer
//
//        金额	购买事件必传。单位为 “分”，如 12.9 元需表示为 1290
//

typedef NS_ENUM(NSUInteger, PABuyChannelWebEventType) {
    PABuyChannelWebEventSubscribe,
    PABuyChannelWebEventRegister,
    PABuyChannelWebEventLogin,
    PABuyChannelWebEventPurchase,
    PABuyChannelWebEventStartTrial,
    PABuyChannelWebEventStartTrialSubscribe,
    PABuyChannelWebEventNoTrialSubscribe,
};

@interface PABuyChannelWebEvent: NSObject

@property(nonatomic, assign) PABuyChannelWebEventType eventType; // 事件类型
@property(nonatomic, copy) NSString *attribute; // 事件属性（可选）
@property(nonatomic, copy) NSString *currency;  // 币种（可选，购买事件必传）
@property(nonatomic, strong) NSNumber *value;   // 金额（单位分，购买事件必传）

- (NSDictionary *)toDictionary;
- (NSString *)eventTypeString;
@end


NS_ASSUME_NONNULL_END
