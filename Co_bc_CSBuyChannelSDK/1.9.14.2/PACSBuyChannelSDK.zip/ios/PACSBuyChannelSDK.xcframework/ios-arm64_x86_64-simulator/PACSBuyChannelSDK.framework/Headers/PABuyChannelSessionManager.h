//
//  PABuyChannelSessionManager.h
//  PACSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PACSBuyChannelHTTPResponse.h"
#import "PABuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface PABuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PABuyChannelSessionManager*)pAsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PABuyChannelSessionManager*)getBuySessionManager;

-(void)pAstartAsyncRequestComplete:(void(^)(PACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pAtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
