//
//  SBBuyChannelSessionManager.h
//  SBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SBCSBuyChannelHTTPResponse.h"
#import "SBBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(SBBuyChannelSessionManager*)sBsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(SBBuyChannelSessionManager*)getBuySessionManager;

-(void)sBstartAsyncRequestComplete:(void(^)(SBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sBtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
