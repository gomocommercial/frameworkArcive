//
//  SBBuyChannelIPCheckSessionManager.h
//  SBCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SBCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SBBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(SBBuyChannelIPCheckSessionManager*)sBsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(SBBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sBstartAsyncRequestComplete:(void(^)(SBCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
