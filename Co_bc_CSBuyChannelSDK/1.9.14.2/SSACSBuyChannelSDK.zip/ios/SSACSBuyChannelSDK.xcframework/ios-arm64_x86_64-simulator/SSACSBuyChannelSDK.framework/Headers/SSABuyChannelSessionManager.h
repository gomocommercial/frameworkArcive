//
//  SSABuyChannelSessionManager.h
//  SSACSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SSACSBuyChannelHTTPResponse.h"
#import "SSABuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface SSABuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(SSABuyChannelSessionManager*)sSAsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(SSABuyChannelSessionManager*)getBuySessionManager;

-(void)sSAstartAsyncRequestComplete:(void(^)(SSACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sSAtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SSACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
