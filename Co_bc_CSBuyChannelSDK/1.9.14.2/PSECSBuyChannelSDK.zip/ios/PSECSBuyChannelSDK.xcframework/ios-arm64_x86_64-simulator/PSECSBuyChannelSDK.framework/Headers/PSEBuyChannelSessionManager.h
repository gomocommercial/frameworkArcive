//
//  PSEBuyChannelSessionManager.h
//  PSECSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PSECSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSEBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PSEBuyChannelSessionManager*)pSEsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PSEBuyChannelSessionManager*)getBuySessionManager;

-(void)pSEstartAsyncRequestComplete:(void(^)(PSECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pSEtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PSECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
