//
//  LOBuyChannelIPCheckSessionManager.h
//  LOCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LOCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LOBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(LOBuyChannelIPCheckSessionManager*)lOsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LOBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)lOstartAsyncRequestComplete:(void(^)(LOCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
