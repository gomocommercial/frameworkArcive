//
//  SKBuyChannelIPCheckSessionManager.h
//  SKCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SKCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SKBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(SKBuyChannelIPCheckSessionManager*)sKsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(SKBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sKstartAsyncRequestComplete:(void(^)(SKCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
