//
//  OFCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "OFCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface OFCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)oFsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(OFCSTrackFailModel*)oFunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)oFdelSerializedBean:(OFCSTrackFailModel*)bean;
//+(NSArray <OFCSTrackFailModel *>*)oFgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)oFretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
