//
//  OFBuyChannelSessionManager.h
//  OFCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "OFCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface OFBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(OFBuyChannelSessionManager*)oFsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(OFBuyChannelSessionManager*)getBuySessionManager;

-(void)oFstartAsyncRequestComplete:(void(^)(OFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)oFtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(OFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
