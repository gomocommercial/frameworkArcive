//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface SWBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)sWgetIPv6AddressesOfAllInterface;
+ (NSString *)sWgetIPv6AddressOfInterfaces;
+ (NSString *)sWgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end