//
//  SWBuyChannelSessionManager.h
//  SWCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SWCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface SWBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(SWBuyChannelSessionManager*)sWsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(SWBuyChannelSessionManager*)getBuySessionManager;

-(void)sWstartAsyncRequestComplete:(void(^)(SWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sWtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
