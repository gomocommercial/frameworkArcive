//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface PHBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)pHgetIPv6AddressesOfAllInterface;
+ (NSString *)pHgetIPv6AddressOfInterfaces;
+ (NSString *)pHgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end