//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface CLUPBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)cLUPgetIPv6AddressesOfAllInterface;
+ (NSString *)cLUPgetIPv6AddressOfInterfaces;
+ (NSString *)cLUPgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end