//
//  CUC_PBuyChannelSessionManager.h
//  CUC_PCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CUC_PCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(CUC_PBuyChannelSessionManager*)cUC_PsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(CUC_PBuyChannelSessionManager*)getBuySessionManager;

-(void)cUC_PstartAsyncRequestComplete:(void(^)(CUC_PCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cUC_PtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CUC_PCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
