//
//  CUC_PCSBuyPheadModel.h
//  CUC_PCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSBuyPheadModel : NSObject

+ (NSDictionary *)cUC_PgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
