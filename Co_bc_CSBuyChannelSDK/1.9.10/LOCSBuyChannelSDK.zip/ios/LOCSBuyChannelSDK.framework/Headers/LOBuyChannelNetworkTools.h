//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface LOBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)lOgetIPv6AddressesOfAllInterface;
+ (NSString *)lOgetIPv6AddressOfInterfaces;
+ (NSString *)lOgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end