//
//  RVBuyChannelIPCheckSessionManager.h
//  RVCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "RVCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface RVBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(RVBuyChannelIPCheckSessionManager*)rVsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(RVBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)rVstartAsyncRequestComplete:(void(^)(RVCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
