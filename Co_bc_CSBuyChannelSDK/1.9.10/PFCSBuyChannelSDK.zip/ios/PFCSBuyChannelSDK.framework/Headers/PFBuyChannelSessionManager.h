//
//  PFBuyChannelSessionManager.h
//  PFCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PFCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface PFBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PFBuyChannelSessionManager*)pFsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PFBuyChannelSessionManager*)getBuySessionManager;

-(void)pFstartAsyncRequestComplete:(void(^)(PFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pFtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PFCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
