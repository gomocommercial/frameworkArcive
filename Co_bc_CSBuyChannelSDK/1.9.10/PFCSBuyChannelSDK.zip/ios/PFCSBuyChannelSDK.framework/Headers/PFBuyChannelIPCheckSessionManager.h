//
//  PFBuyChannelIPCheckSessionManager.h
//  PFCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PFCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PFBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(PFBuyChannelIPCheckSessionManager*)pFsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PFBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)pFstartAsyncRequestComplete:(void(^)(PFCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
