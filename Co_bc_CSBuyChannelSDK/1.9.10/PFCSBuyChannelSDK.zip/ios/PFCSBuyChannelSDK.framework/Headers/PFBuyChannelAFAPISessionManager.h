//
// Created by Kevin Guo on 2024/9/19.
//

#import <Foundation/Foundation.h>


@interface PFBuyChannelAFAPISessionManager : NSObject
+(void)pFstartGetGcdDataWithAppId:(NSString *)appId devKey:(NSString *)devkey retryCount:(NSInteger)retryCount complete:(void(^)(NSDictionary *gcdData, NSError *error))complete;
@end