//
//  PFCSTrackFailModel.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PFCSTrackFailModel : NSObject

@property (nonatomic, copy) NSString *uuid;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *eventTime;
@property (nonatomic, copy) NSDictionary *values;

@end

NS_ASSUME_NONNULL_END
