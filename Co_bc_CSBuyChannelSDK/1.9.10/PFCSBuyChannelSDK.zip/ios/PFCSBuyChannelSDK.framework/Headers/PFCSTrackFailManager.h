//
//  PFCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PFCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PFCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pFsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PFCSTrackFailModel*)pFunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pFdelSerializedBean:(PFCSTrackFailModel*)bean;
//+(NSArray <PFCSTrackFailModel *>*)pFgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pFretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
