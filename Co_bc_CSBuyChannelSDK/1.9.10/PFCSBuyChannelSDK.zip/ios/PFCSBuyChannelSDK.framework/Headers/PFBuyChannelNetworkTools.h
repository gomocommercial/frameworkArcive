//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface PFBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)pFgetIPv6AddressesOfAllInterface;
+ (NSString *)pFgetIPv6AddressOfInterfaces;
+ (NSString *)pFgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end