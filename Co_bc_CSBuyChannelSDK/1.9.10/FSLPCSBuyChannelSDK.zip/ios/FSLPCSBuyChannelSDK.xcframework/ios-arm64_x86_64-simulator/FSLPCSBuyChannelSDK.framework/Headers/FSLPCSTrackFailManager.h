//
//  FSLPCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "FSLPCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)fSLPsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(FSLPCSTrackFailModel*)fSLPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)fSLPdelSerializedBean:(FSLPCSTrackFailModel*)bean;
//+(NSArray <FSLPCSTrackFailModel *>*)fSLPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fSLPretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
