//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface SJBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)sJgetIPv6AddressesOfAllInterface;
+ (NSString *)sJgetIPv6AddressOfInterfaces;
+ (NSString *)sJgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end