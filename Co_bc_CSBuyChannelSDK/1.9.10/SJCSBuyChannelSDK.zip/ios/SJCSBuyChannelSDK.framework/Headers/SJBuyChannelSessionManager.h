//
//  SJBuyChannelSessionManager.h
//  SJCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SJCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface SJBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(SJBuyChannelSessionManager*)sJsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(SJBuyChannelSessionManager*)getBuySessionManager;

-(void)sJstartAsyncRequestComplete:(void(^)(SJCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sJtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SJCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
