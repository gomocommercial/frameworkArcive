//
//  SJBuyChannelIPCheckSessionManager.h
//  SJCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SJCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SJBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(SJBuyChannelIPCheckSessionManager*)sJsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(SJBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sJstartAsyncRequestComplete:(void(^)(SJCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
