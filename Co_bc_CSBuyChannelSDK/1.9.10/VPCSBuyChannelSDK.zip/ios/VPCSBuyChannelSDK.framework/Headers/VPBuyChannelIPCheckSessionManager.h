//
//  VPBuyChannelIPCheckSessionManager.h
//  VPCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "VPCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface VPBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(VPBuyChannelIPCheckSessionManager*)vPsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(VPBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)vPstartAsyncRequestComplete:(void(^)(VPCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
