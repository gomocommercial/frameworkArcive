//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface ATBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)aTgetIPv6AddressesOfAllInterface;
+ (NSString *)aTgetIPv6AddressOfInterfaces;
+ (NSString *)aTgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end