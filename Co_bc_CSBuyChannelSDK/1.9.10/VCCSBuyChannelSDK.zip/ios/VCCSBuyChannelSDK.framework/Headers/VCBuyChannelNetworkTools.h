//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface VCBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)vCgetIPv6AddressesOfAllInterface;
+ (NSString *)vCgetIPv6AddressOfInterfaces;
+ (NSString *)vCgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end