//
//  VCBuyChannelSessionManager.h
//  VCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "VCCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface VCBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(VCBuyChannelSessionManager*)vCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(VCBuyChannelSessionManager*)getBuySessionManager;

-(void)vCstartAsyncRequestComplete:(void(^)(VCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)vCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(VCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
