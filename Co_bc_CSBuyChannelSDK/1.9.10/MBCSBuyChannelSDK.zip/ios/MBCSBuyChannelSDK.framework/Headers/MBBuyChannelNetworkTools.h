//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface MBBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)mBgetIPv6AddressesOfAllInterface;
+ (NSString *)mBgetIPv6AddressOfInterfaces;
+ (NSString *)mBgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end