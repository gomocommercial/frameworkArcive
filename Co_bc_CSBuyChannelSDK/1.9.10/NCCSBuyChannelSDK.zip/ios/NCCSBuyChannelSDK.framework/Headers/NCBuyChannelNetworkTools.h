//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface NCBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)nCgetIPv6AddressesOfAllInterface;
+ (NSString *)nCgetIPv6AddressOfInterfaces;
+ (NSString *)nCgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end