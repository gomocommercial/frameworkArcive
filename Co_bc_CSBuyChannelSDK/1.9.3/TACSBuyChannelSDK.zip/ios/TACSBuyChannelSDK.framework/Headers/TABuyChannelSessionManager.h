//
//  TABuyChannelSessionManager.h
//  TACSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "TACSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface TABuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(TABuyChannelSessionManager*)tAsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TABuyChannelSessionManager*)getBuySessionManager;

-(void)tAstartAsyncRequestComplete:(void(^)(TACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)tAtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(TACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
