//
//  LTCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LTCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LTCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lTCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LTCCSTrackFailModel*)lTCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lTCdelSerializedBean:(LTCCSTrackFailModel*)bean;
//+(NSArray <LTCCSTrackFailModel *>*)lTCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lTCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
