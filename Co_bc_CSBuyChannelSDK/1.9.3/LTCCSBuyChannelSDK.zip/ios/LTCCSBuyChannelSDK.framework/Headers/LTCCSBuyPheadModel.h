//
//  LTCCSBuyPheadModel.h
//  LTCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LTCCSBuyPheadModel : NSObject

+ (NSDictionary *)lTCgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
