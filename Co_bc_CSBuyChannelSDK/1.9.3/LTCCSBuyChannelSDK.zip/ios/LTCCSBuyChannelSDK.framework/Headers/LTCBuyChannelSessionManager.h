//
//  LTCBuyChannelSessionManager.h
//  LTCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LTCCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface LTCBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(LTCBuyChannelSessionManager*)lTCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LTCBuyChannelSessionManager*)getBuySessionManager;

-(void)lTCstartAsyncRequestComplete:(void(^)(LTCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lTCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LTCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
