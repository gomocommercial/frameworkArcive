//
//  LECSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LECSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LECSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lEsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LECSTrackFailModel*)lEunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lEdelSerializedBean:(LECSTrackFailModel*)bean;
//+(NSArray <LECSTrackFailModel *>*)lEgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lEretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
