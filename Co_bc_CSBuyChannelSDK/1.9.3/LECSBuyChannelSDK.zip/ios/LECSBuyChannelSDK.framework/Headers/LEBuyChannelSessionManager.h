//
//  LEBuyChannelSessionManager.h
//  LECSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LECSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface LEBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(LEBuyChannelSessionManager*)lEsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LEBuyChannelSessionManager*)getBuySessionManager;

-(void)lEstartAsyncRequestComplete:(void(^)(LECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lEtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
