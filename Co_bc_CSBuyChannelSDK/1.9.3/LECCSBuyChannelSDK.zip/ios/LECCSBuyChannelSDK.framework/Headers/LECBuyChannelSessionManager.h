//
//  LECBuyChannelSessionManager.h
//  LECCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LECCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface LECBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(LECBuyChannelSessionManager*)lECsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LECBuyChannelSessionManager*)getBuySessionManager;

-(void)lECstartAsyncRequestComplete:(void(^)(LECCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lECtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LECCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
