//
//  MGCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MGCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mGCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MGCCSTrackFailModel*)mGCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mGCdelSerializedBean:(MGCCSTrackFailModel*)bean;
//+(NSArray <MGCCSTrackFailModel *>*)mGCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mGCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
