//
//  DCiosBuyChannelIPCheckSessionManager.h
//  DCiosCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DCiosCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCiosBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(DCiosBuyChannelIPCheckSessionManager*)dCiossharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(DCiosBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)dCiosstartAsyncRequestComplete:(void(^)(DCiosCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
