//
//  MBCSBuyChannelInitParams.h
//  MBCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MBCSBuyChannelInitParams : NSObject

//MARK: 买量初始化参数(必填)

/// AppsFlyer上面返回的appsDevKey
@property (nonatomic, copy)NSString * appsDevKey;

///  AppsFlyer上面返回的appleAppID
@property (nonatomic, copy)NSString * appleAppId;

/// 统计45协议功能点ID
@property (nonatomic, copy)NSString * funcId;

/// 统计协议产品ID
@property (nonatomic, copy)NSString * cid;

/// 是否开启LOG(默认为false)
@property (nonatomic, assign)BOOL enableLog;

/// 是否开启Debug模式(默认为false)
@property (nonatomic, assign)BOOL debugMode;

//MARK: 买量互补方案参数

/// 买量互补方案域名
@property (nonatomic, copy)NSString * supplementDomainName;

/// 买量互补方案签名秘钥
@property (nonatomic, copy)NSString * supplementSignatureKey;

/// 买量互补方案加密秘钥(默认:5NDZOADK)
@property (nonatomic, copy)NSString * supplementDesKey;

/// 买量互补方案产品标识
@property (nonatomic, copy)NSString * supplementProdKey;

/// 是否优先执行自研归因
@property (nonatomic, assign) BOOL firstTrackService;


//MARK: 自研IP归因方案

/// 自研IP归因方案域名
@property (nonatomic, copy)NSString * ipDomainName;

/// 自研IP归因方案访问秘钥
@property (nonatomic, copy)NSString * ipAccessKey;

/// 自研IP归因方案产品标识
@property (nonatomic, copy)NSString * ipProdKey;

/// 买量互补方案加密秘钥(默认:5NDZOELE)
@property (nonatomic, copy)NSString * ipDesKey;

//MARK: 其他可选参数

/// af自定义用户标识(默认为统计协议用户ID)
@property (nonatomic, copy)NSString * afCustomerUserID;

/// 校验必填参数
- (BOOL)mBbuyChannelCheckParams;

/// 校验互补方案参数
- (BOOL)mBbuyChannelCheckSupplementParams;

/// 校验IP归因参数
- (BOOL)mBbuyChannelCheckIpParams;

@end

NS_ASSUME_NONNULL_END
