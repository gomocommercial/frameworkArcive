//
//  PIKBuyChannelIPCheckSessionManager.h
//  PIKCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PIKCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PIKBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(PIKBuyChannelIPCheckSessionManager*)pIKsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PIKBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)pIKstartAsyncRequestComplete:(void(^)(PIKCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
