//
//  PIKBuyChannelSessionManager.h
//  PIKCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PIKCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface PIKBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PIKBuyChannelSessionManager*)pIKsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PIKBuyChannelSessionManager*)getBuySessionManager;

-(void)pIKstartAsyncRequestComplete:(void(^)(PIKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pIKtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PIKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
