//
//  CSBuyChannelSessionManager.h
//  CSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CSCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(CSBuyChannelSessionManager*)cSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CSBuyChannelSessionManager*)getBuySessionManager;

-(void)cSstartAsyncRequestComplete:(void(^)(CSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
