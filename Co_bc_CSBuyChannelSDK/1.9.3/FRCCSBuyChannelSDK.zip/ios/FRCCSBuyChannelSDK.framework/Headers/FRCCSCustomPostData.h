//
//  FRCCSCustomPostData.h
//  CSBuyChannelSDK
//
//  Created by qiaoming on 2018/10/16.
//

#import <Foundation/Foundation.h>

@interface FRCCSCustomPostData : NSObject

+ (NSString *)fRCgetPostStringWithObject:(NSString *)timeInterval//*统计对象  传拿到appsflyer配置时间（s)
                                 code:(NSString *)code//操作代码 af_get_time
                               result:(NSString *)result//   默认传1
                             entrance:(NSString *)entrance// 传GA的原始referrer
                                  tab:(NSString *)tab//  传Appsflyer返回的map原始数据
                             position:(NSString *)position// 1.Android  2.IOS
                                  cid:(NSString *)cid;//传产品CID

@end

