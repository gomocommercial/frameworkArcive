//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface CUC_PBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)cUC_PgetIPv6AddressesOfAllInterface;
+ (NSString *)cUC_PgetIPv6AddressOfInterfaces;
+ (NSString *)cUC_PgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end