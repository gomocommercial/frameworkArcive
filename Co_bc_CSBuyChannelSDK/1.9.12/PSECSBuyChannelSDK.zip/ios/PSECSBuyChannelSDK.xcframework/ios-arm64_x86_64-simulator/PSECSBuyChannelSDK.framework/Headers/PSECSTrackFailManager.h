//
//  PSECSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PSECSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSECSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pSEsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PSECSTrackFailModel*)pSEunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pSEdelSerializedBean:(PSECSTrackFailModel*)bean;
//+(NSArray <PSECSTrackFailModel *>*)pSEgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pSEretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
