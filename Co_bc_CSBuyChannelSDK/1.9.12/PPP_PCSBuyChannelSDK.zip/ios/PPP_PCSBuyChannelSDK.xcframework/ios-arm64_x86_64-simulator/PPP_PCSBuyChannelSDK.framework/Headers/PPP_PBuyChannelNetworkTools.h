//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface PPP_PBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)pPP_PgetIPv6AddressesOfAllInterface;
+ (NSString *)pPP_PgetIPv6AddressOfInterfaces;
+ (NSString *)pPP_PgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end