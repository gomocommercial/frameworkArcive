//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface JLCBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)jLCgetIPv6AddressesOfAllInterface;
+ (NSString *)jLCgetIPv6AddressOfInterfaces;
+ (NSString *)jLCgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end