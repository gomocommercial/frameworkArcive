//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface SSABuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)sSAgetIPv6AddressesOfAllInterface;
+ (NSString *)sSAgetIPv6AddressOfInterfaces;
+ (NSString *)sSAgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end