//
//  FNBuyChannelSessionManager.h
//  FNCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "FNCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface FNBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(FNBuyChannelSessionManager*)fNsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(FNBuyChannelSessionManager*)getBuySessionManager;

-(void)fNstartAsyncRequestComplete:(void(^)(FNCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)fNtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(FNCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
