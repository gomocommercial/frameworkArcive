//
//  NSString+FNCSBuyChannelSecure.h
//  FNCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (FNCSBuyChannelSecure)

+(NSString *)fNbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)fNbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
