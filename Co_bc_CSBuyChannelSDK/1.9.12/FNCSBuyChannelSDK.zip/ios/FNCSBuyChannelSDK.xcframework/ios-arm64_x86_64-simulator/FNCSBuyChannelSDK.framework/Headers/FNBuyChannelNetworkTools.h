//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface FNBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)fNgetIPv6AddressesOfAllInterface;
+ (NSString *)fNgetIPv6AddressOfInterfaces;
+ (NSString *)fNgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end