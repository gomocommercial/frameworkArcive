//
//  NSString+PPP_P_CSBuyChannelSecure.h
//  PPP_P_CSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (PPP_P_CSBuyChannelSecure)

+(NSString *)pPP_P_buyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)pPP_P_buyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
