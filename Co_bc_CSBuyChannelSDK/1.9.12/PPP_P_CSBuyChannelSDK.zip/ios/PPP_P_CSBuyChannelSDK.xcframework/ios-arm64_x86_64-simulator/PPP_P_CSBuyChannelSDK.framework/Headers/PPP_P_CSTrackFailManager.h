//
//  PPP_P_CSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PPP_P_CSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pPP_P_saveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PPP_P_CSTrackFailModel*)pPP_P_unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pPP_P_delSerializedBean:(PPP_P_CSTrackFailModel*)bean;
//+(NSArray <PPP_P_CSTrackFailModel *>*)pPP_P_getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pPP_P_retryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
