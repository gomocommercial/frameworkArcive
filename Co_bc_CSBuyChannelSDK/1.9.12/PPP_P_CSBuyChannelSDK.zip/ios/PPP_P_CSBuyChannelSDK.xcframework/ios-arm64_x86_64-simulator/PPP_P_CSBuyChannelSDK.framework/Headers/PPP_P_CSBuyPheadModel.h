//
//  PPP_P_CSBuyPheadModel.h
//  PPP_P_CSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSBuyPheadModel : NSObject

+ (NSDictionary *)pPP_P_getPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
