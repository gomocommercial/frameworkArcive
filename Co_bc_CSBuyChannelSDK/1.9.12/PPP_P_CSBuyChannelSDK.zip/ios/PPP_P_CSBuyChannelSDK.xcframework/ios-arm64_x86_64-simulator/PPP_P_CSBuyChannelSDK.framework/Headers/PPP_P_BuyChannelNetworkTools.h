//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface PPP_P_BuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)pPP_P_getIPv6AddressesOfAllInterface;
+ (NSString *)pPP_P_getIPv6AddressOfInterfaces;
+ (NSString *)pPP_P_getSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end