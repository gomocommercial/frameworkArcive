//
//  EATBuyChannelSessionManager.h
//  EATCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "EATCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface EATBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(EATBuyChannelSessionManager*)eATsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(EATBuyChannelSessionManager*)getBuySessionManager;

-(void)eATstartAsyncRequestComplete:(void(^)(EATCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)eATtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(EATCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
