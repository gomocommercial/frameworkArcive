//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface EATBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)eATgetIPv6AddressesOfAllInterface;
+ (NSString *)eATgetIPv6AddressOfInterfaces;
+ (NSString *)eATgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end