//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface MLCBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)mLCgetIPv6AddressesOfAllInterface;
+ (NSString *)mLCgetIPv6AddressOfInterfaces;
+ (NSString *)mLCgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end