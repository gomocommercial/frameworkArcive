//
//  MLCCSBuyPheadModel.h
//  MLCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MLCCSBuyPheadModel : NSObject

+ (NSDictionary *)mLCgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
