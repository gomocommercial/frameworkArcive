//
//  CSBuyChannelIPCheckSessionManager.h
//  CSCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CSCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(CSBuyChannelIPCheckSessionManager*)cSsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CSBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cSstartAsyncRequestComplete:(void(^)(CSCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
