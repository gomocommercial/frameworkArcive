//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface CSBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)cSgetIPv6AddressesOfAllInterface;
+ (NSString *)cSgetIPv6AddressOfInterfaces;
+ (NSString *)cSgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end