#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "NSString+TTACSBuyChannelSecure.h"
#import "TTABuyChannelAFAPISessionManager.h"
#import "TTABuyChannelIPCheckSessionManager.h"
#import "TTABuyChannelNetworkTools.h"
#import "TTABuyChannelSessionManager.h"
#import "TTACSBuyChannel.h"
#import "TTACSBuyChannelFlyerModel.h"
#import "TTACSBuyChannelFlyerOneLinkModel.h"
#import "TTACSBuyChannelHTTPResponse.h"
#import "TTACSBuyChannelInitParams.h"
#import "TTACSBuyChannelIPCheckRequestSerializer.h"
#import "TTACSBuyChannelRequestSerializer.h"
#import "TTACSBuyChannelSecureManager.h"
#import "TTACSBuyPheadModel.h"
#import "TTACSCustomPostData.h"
#import "TTACSTrackFailManager.h"
#import "TTACSTrackFailModel.h"
#import "NSString+TTACSBuyChannelSecure.h"
#import "TTABuyChannelAFAPISessionManager.h"
#import "TTABuyChannelIPCheckSessionManager.h"
#import "TTABuyChannelNetworkTools.h"
#import "TTABuyChannelSessionManager.h"
#import "TTACSBuyChannel.h"
#import "TTACSBuyChannelFlyerModel.h"
#import "TTACSBuyChannelFlyerOneLinkModel.h"
#import "TTACSBuyChannelHTTPResponse.h"
#import "TTACSBuyChannelInitParams.h"
#import "TTACSBuyChannelIPCheckRequestSerializer.h"
#import "TTACSBuyChannelRequestSerializer.h"
#import "TTACSBuyChannelSecureManager.h"
#import "TTACSBuyPheadModel.h"
#import "TTACSCustomPostData.h"
#import "TTACSTrackFailManager.h"
#import "TTACSTrackFailModel.h"

FOUNDATION_EXPORT double TTACSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char TTACSBuyChannelSDKVersionString[];

