//
//  MACUBuyChannelSessionManager.h
//  MACUCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MACUCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface MACUBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(MACUBuyChannelSessionManager*)mACUsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(MACUBuyChannelSessionManager*)getBuySessionManager;

-(void)mACUstartAsyncRequestComplete:(void(^)(MACUCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)mACUtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MACUCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
