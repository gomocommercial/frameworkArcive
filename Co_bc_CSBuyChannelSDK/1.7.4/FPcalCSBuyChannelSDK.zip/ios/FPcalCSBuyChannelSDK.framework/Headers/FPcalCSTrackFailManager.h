//
//  FPcalCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "FPcalCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FPcalCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)fPcalsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(FPcalCSTrackFailModel*)fPcalunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)fPcaldelSerializedBean:(FPcalCSTrackFailModel*)bean;
//+(NSArray <FPcalCSTrackFailModel *>*)fPcalgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fPcalretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
