//
//  PHBuyChannelSessionManager.h
//  PHCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PHCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface PHBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(PHBuyChannelSessionManager*)pHsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(PHBuyChannelSessionManager*)getBuySessionManager;
-(void)pHstartAsyncRequestComplete:(void(^)(PHCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)pHtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PHCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
