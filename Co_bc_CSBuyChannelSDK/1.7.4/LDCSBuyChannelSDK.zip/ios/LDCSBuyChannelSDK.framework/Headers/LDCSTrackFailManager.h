//
//  LDCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LDCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LDCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lDsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LDCSTrackFailModel*)lDunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lDdelSerializedBean:(LDCSTrackFailModel*)bean;
//+(NSArray <LDCSTrackFailModel *>*)lDgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lDretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
