//
//  LECSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LECSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LECSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)co_bc_saveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LECSTrackFailModel*)co_bc_unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)co_bc_delSerializedBean:(LECSTrackFailModel*)bean;
//+(NSArray <LECSTrackFailModel *>*)co_bc_getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)co_bc_retryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
