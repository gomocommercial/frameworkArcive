//
//  INDOCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "INDOCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface INDOCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)iNDOsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(INDOCSTrackFailModel*)iNDOunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)iNDOdelSerializedBean:(INDOCSTrackFailModel*)bean;
//+(NSArray <INDOCSTrackFailModel *>*)iNDOgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)iNDOretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
