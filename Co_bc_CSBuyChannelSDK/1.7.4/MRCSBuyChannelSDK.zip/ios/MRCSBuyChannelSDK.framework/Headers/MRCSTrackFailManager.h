//
//  MRCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MRCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MRCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mRsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MRCSTrackFailModel*)mRunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mRdelSerializedBean:(MRCSTrackFailModel*)bean;
//+(NSArray <MRCSTrackFailModel *>*)mRgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mRretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
