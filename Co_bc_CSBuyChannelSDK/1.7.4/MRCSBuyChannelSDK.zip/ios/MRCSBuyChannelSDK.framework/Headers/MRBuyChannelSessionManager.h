//
//  MRBuyChannelSessionManager.h
//  MRCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MRCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface MRBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(MRBuyChannelSessionManager*)mRsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(MRBuyChannelSessionManager*)getBuySessionManager;
-(void)mRstartAsyncRequestComplete:(void(^)(MRCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)mRtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MRCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
