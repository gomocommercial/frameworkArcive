//
//  VEBuyChannelSessionManager.h
//  VECSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "VECSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface VEBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(VEBuyChannelSessionManager*)vEsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(VEBuyChannelSessionManager*)getBuySessionManager;
-(void)vEstartAsyncRequestComplete:(void(^)(VECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)vEtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(VECSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
