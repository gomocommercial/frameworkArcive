//
//  WABuyChannelSessionManager.h
//  WACSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "WACSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface WABuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(WABuyChannelSessionManager*)wAsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(WABuyChannelSessionManager*)getBuySessionManager;
-(void)wAstartAsyncRequestComplete:(void(^)(WACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)wAtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(WACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
