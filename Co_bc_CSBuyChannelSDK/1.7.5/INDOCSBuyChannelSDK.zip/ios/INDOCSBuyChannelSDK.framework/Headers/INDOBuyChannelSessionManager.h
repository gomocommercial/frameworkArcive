//
//  INDOBuyChannelSessionManager.h
//  INDOCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "INDOCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface INDOBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(INDOBuyChannelSessionManager*)iNDOsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(INDOBuyChannelSessionManager*)getBuySessionManager;
-(void)iNDOstartAsyncRequestComplete:(void(^)(INDOCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)iNDOtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(INDOCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
