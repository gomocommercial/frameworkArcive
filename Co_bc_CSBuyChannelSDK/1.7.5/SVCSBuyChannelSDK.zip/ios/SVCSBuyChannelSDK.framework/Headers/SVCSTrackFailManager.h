//
//  SVCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "SVCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SVCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sVsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(SVCSTrackFailModel*)sVunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sVdelSerializedBean:(SVCSTrackFailModel*)bean;
//+(NSArray <SVCSTrackFailModel *>*)sVgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sVretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
