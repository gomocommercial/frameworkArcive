//
//  FLCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "FLCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FLCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)fLsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(FLCSTrackFailModel*)fLunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)fLdelSerializedBean:(FLCSTrackFailModel*)bean;
//+(NSArray <FLCSTrackFailModel *>*)fLgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)fLretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
