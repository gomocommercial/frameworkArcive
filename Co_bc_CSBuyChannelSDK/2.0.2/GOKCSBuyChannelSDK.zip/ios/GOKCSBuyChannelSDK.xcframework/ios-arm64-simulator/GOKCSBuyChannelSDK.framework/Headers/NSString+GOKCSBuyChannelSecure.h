//
//  NSString+GOKCSBuyChannelSecure.h
//  GOKCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (GOKCSBuyChannelSecure)

+(NSString *)gOKbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)gOKbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
