//
//  GOKBuyChannelIPCheckSessionManager.h
//  GOKCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "GOKCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface GOKBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(GOKBuyChannelIPCheckSessionManager*)gOKsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(GOKBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)gOKstartAsyncRequestComplete:(void(^)(GOKCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
