//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, GOKNetworkReachabilityStatus) {
    GOKNetworkReachabilityStatusUnknown          = -1,
    GOKNetworkReachabilityStatusNotReachable     = 0,
    GOKNetworkReachabilityStatusReachableViaWWAN = 1,
    GOKNetworkReachabilityStatusReachableViaWiFi = 2,
};

@interface GOKBuyChannelNetworkTools : NSObject

+ (void)gOKstartGetIPv6AddressWithLocalAddressDetectWithEnableIPv6:(BOOL)enableIPv6
                                                          geoipAPIURL:(nullable NSString *)geoipAPIURL
                                                        maxRetryCount:(NSInteger)maxRetryCount
                                                            complete:(void(^)(NSDictionary* address))complete;

+ (nullable NSDictionary *)decryptStringTransToDic:(nullable id)responseObject desKey:(NSString *)desKey;
+ (NSString *)signatureWithAccesskey:(NSString *)accesskey methodName:(NSString *)methodName requestUrl:(NSString *)requestUrl queries:(nullable NSString *)queryString payload:(NSMutableDictionary *)payload;

#pragma mark - 网络请求工具方法 (基于 NSURLSession, 替代 AFNetworking)

/// SDK 内部使用的共享 NSURLSession, 配置等价于原 AFHTTPSessionManager 的默认配置, 并允许无效证书
+ (NSURLSession *)gOKsharedURLSession;

/// 发起 GET 请求, parameters 会按 application/x-www-form-urlencoded 拼接到 URL 上
/// 回调会在主队列执行, 与原 AFHTTPSessionManager 行为一致
+ (void)gOKGETWithURLString:(NSString *)urlString
                    parameters:(nullable NSDictionary *)parameters
                       headers:(nullable NSDictionary<NSString *, NSString *> *)headers
                      complete:(void(^)(NSData * _Nullable responseData, NSError * _Nullable error))complete;

/// 发起 POST 请求, bodyData 由调用方按需序列化(包括 DES 加密 + Base64 等)
/// 回调会在主队列执行, 与原 AFHTTPSessionManager 行为一致
+ (void)gOKPOSTWithURLString:(NSString *)urlString
                        headers:(nullable NSDictionary<NSString *, NSString *> *)headers
                       bodyData:(nullable NSData *)bodyData
                       complete:(void(^)(NSData * _Nullable responseData, NSError * _Nullable error))complete;

#pragma mark - 网络可达性 (替代 AFNetworkReachabilityManager)

/// 当前是否有可用网络
+ (BOOL)gOKisNetworkReachable;

/// 当前网络状态
+ (GOKNetworkReachabilityStatus)gOKcurrentReachabilityStatus;

/// 注册网络状态变化回调, 多次调用会替换之前的回调, block 在主队列回调
+ (void)gOKstartMonitoringReachabilityChange:(void(^)(GOKNetworkReachabilityStatus status))block;

@end

NS_ASSUME_NONNULL_END
