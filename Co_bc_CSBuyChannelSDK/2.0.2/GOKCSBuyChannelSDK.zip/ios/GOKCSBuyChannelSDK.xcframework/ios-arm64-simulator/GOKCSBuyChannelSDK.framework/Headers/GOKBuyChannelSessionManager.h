//
//  GOKBuyChannelSessionManager.h
//  GOKCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "GOKCSBuyChannelHTTPResponse.h"
#import "GOKBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface GOKBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(GOKBuyChannelSessionManager*)gOKsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(GOKBuyChannelSessionManager*)getBuySessionManager;

-(void)gOKstartAsyncRequestComplete:(void(^)(GOKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)gOKtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(GOKCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
