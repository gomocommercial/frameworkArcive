//
//  PCXCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PCXCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCXCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pCXsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PCXCSTrackFailModel*)pCXunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pCXdelSerializedBean:(PCXCSTrackFailModel*)bean;
//+(NSArray <PCXCSTrackFailModel *>*)pCXgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pCXretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
