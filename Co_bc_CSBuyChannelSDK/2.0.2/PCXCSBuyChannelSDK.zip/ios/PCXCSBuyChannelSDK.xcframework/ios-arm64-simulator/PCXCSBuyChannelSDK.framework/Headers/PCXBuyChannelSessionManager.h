//
//  PCXBuyChannelSessionManager.h
//  PCXCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "PCXCSBuyChannelHTTPResponse.h"
#import "PCXBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCXBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(PCXBuyChannelSessionManager*)pCXsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PCXBuyChannelSessionManager*)getBuySessionManager;

-(void)pCXstartAsyncRequestComplete:(void(^)(PCXCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pCXtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PCXCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
