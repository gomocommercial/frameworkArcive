//
//  PCXBuyChannelIPCheckSessionManager.h
//  PCXCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "PCXCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PCXBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(PCXBuyChannelIPCheckSessionManager*)pCXsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PCXBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)pCXstartAsyncRequestComplete:(void(^)(PCXCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
