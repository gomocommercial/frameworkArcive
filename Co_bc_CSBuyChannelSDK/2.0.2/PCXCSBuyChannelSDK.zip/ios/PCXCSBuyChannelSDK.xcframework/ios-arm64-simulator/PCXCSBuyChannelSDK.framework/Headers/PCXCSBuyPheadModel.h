//
//  PCXCSBuyPheadModel.h
//  PCXCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCXCSBuyPheadModel : NSObject

+ (NSDictionary *)pCXgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
