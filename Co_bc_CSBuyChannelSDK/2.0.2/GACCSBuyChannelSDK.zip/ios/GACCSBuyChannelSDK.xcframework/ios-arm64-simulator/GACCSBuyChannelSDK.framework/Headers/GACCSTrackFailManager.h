//
//  GACCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "GACCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface GACCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)gACsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(GACCSTrackFailModel*)gACunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)gACdelSerializedBean:(GACCSTrackFailModel*)bean;
//+(NSArray <GACCSTrackFailModel *>*)gACgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)gACretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
