//
//  GACBuyChannelSessionManager.h
//  GACCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "GACCSBuyChannelHTTPResponse.h"
#import "GACBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface GACBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(GACBuyChannelSessionManager*)gACsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(GACBuyChannelSessionManager*)getBuySessionManager;

-(void)gACstartAsyncRequestComplete:(void(^)(GACCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)gACtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(GACCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
