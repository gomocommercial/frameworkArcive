//
//  GACBuyChannelIPCheckSessionManager.h
//  GACCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "GACCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface GACBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(GACBuyChannelIPCheckSessionManager*)gACsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(GACBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)gACstartAsyncRequestComplete:(void(^)(GACCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
