//
//  VSBuyChannelSessionManager.h
//  VSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "VSCSBuyChannelHTTPResponse.h"
#import "VSBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface VSBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(VSBuyChannelSessionManager*)vSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(VSBuyChannelSessionManager*)getBuySessionManager;

-(void)vSstartAsyncRequestComplete:(void(^)(VSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)vStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(VSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
