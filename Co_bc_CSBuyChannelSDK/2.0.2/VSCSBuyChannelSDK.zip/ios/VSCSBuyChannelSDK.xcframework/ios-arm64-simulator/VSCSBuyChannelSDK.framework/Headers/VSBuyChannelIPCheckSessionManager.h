//
//  VSBuyChannelIPCheckSessionManager.h
//  VSCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "VSCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface VSBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(VSBuyChannelIPCheckSessionManager*)vSsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(VSBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)vSstartAsyncRequestComplete:(void(^)(VSCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
