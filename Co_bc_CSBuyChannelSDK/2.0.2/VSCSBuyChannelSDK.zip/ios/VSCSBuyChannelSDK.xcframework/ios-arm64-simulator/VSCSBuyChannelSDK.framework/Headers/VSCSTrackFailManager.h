//
//  VSCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "VSCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface VSCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)vSsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(VSCSTrackFailModel*)vSunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)vSdelSerializedBean:(VSCSTrackFailModel*)bean;
//+(NSArray <VSCSTrackFailModel *>*)vSgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)vSretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
