//
//  WBBuyChannelIPCheckSessionManager.h
//  WBCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "WBCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface WBBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(WBBuyChannelIPCheckSessionManager*)wBsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(WBBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)wBstartAsyncRequestComplete:(void(^)(WBCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
