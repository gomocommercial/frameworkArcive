//
//  STGBuyChannelSessionManager.h
//  STGCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "STGCSBuyChannelHTTPResponse.h"
#import "STGBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface STGBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(STGBuyChannelSessionManager*)sTGsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(STGBuyChannelSessionManager*)getBuySessionManager;

-(void)sTGstartAsyncRequestComplete:(void(^)(STGCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sTGtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(STGCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
