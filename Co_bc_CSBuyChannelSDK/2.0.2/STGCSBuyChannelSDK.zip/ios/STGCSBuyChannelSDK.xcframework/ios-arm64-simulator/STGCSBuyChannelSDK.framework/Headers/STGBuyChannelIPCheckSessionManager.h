//
//  STGBuyChannelIPCheckSessionManager.h
//  STGCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "STGCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STGBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(STGBuyChannelIPCheckSessionManager*)sTGsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(STGBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sTGstartAsyncRequestComplete:(void(^)(STGCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
