//
//  TRCBuyChannelSessionManager.h
//  TRCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "TRCCSBuyChannelHTTPResponse.h"
#import "TRCBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(TRCBuyChannelSessionManager*)tRCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(TRCBuyChannelSessionManager*)getBuySessionManager;

-(void)tRCstartAsyncRequestComplete:(void(^)(TRCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)tRCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(TRCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
