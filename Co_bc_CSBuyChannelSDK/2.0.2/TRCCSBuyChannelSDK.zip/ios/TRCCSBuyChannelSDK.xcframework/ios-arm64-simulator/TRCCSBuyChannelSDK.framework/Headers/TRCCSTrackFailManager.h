//
//  TRCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "TRCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)tRCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(TRCCSTrackFailModel*)tRCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)tRCdelSerializedBean:(TRCCSTrackFailModel*)bean;
//+(NSArray <TRCCSTrackFailModel *>*)tRCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)tRCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
