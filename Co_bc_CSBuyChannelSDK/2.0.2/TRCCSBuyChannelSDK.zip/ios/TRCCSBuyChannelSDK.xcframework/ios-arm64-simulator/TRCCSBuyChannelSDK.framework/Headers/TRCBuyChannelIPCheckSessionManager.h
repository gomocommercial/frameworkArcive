//
//  TRCBuyChannelIPCheckSessionManager.h
//  TRCCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "TRCCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(TRCBuyChannelIPCheckSessionManager*)tRCsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TRCBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)tRCstartAsyncRequestComplete:(void(^)(TRCCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
