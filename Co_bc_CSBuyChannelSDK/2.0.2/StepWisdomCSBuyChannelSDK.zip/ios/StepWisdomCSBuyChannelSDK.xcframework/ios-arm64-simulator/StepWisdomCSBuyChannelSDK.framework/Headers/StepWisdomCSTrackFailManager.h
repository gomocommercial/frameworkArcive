//
//  StepWisdomCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "StepWisdomCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)stepWisdomsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(StepWisdomCSTrackFailModel*)stepWisdomunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)stepWisdomdelSerializedBean:(StepWisdomCSTrackFailModel*)bean;
//+(NSArray <StepWisdomCSTrackFailModel *>*)stepWisdomgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)stepWisdomretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
