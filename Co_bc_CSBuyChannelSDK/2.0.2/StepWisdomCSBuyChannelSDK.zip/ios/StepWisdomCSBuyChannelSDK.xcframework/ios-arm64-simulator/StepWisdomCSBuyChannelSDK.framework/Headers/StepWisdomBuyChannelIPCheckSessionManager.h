//
//  StepWisdomBuyChannelIPCheckSessionManager.h
//  StepWisdomCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "StepWisdomCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(StepWisdomBuyChannelIPCheckSessionManager*)stepWisdomsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(StepWisdomBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)stepWisdomstartAsyncRequestComplete:(void(^)(StepWisdomCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
