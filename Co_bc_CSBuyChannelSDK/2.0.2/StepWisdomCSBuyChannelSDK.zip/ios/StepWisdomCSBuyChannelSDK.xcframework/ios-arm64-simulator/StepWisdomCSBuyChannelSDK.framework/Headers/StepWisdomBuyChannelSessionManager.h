//
//  StepWisdomBuyChannelSessionManager.h
//  StepWisdomCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "StepWisdomCSBuyChannelHTTPResponse.h"
#import "StepWisdomBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(StepWisdomBuyChannelSessionManager*)stepWisdomsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(StepWisdomBuyChannelSessionManager*)getBuySessionManager;

-(void)stepWisdomstartAsyncRequestComplete:(void(^)(StepWisdomCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)stepWisdomtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(StepWisdomCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
