//
//  MMCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MMCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MMCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mMsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MMCSTrackFailModel*)mMunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mMdelSerializedBean:(MMCSTrackFailModel*)bean;
//+(NSArray <MMCSTrackFailModel *>*)mMgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mMretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
