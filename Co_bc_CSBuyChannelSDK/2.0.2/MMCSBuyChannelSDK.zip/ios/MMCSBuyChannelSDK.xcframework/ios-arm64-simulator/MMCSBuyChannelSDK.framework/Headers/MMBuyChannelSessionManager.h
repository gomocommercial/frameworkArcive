//
//  MMBuyChannelSessionManager.h
//  MMCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "MMCSBuyChannelHTTPResponse.h"
#import "MMBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface MMBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(MMBuyChannelSessionManager*)mMsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(MMBuyChannelSessionManager*)getBuySessionManager;

-(void)mMstartAsyncRequestComplete:(void(^)(MMCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)mMtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MMCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
