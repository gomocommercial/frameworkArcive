//
//  MMBuyChannelIPCheckSessionManager.h
//  MMCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "MMCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MMBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(MMBuyChannelIPCheckSessionManager*)mMsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(MMBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)mMstartAsyncRequestComplete:(void(^)(MMCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
