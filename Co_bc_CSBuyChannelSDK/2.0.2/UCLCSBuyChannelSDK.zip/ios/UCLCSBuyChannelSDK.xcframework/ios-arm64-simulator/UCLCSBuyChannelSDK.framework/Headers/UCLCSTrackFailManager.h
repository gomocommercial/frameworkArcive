//
//  UCLCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "UCLCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface UCLCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)uCLsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(UCLCSTrackFailModel*)uCLunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)uCLdelSerializedBean:(UCLCSTrackFailModel*)bean;
//+(NSArray <UCLCSTrackFailModel *>*)uCLgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)uCLretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
