//
//  UCLBuyChannelIPCheckSessionManager.h
//  UCLCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "UCLCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface UCLBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(UCLBuyChannelIPCheckSessionManager*)uCLsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(UCLBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)uCLstartAsyncRequestComplete:(void(^)(UCLCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
