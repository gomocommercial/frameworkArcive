//
//  UCLBuyChannelSessionManager.h
//  UCLCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "UCLCSBuyChannelHTTPResponse.h"
#import "UCLBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface UCLBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(UCLBuyChannelSessionManager*)uCLsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(UCLBuyChannelSessionManager*)getBuySessionManager;

-(void)uCLstartAsyncRequestComplete:(void(^)(UCLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)uCLtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(UCLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
