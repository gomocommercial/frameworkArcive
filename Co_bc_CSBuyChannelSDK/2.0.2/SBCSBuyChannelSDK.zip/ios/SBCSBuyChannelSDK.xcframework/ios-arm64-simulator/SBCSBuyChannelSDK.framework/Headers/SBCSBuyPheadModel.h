//
//  SBCSBuyPheadModel.h
//  SBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SBCSBuyPheadModel : NSObject

+ (NSDictionary *)sBgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
