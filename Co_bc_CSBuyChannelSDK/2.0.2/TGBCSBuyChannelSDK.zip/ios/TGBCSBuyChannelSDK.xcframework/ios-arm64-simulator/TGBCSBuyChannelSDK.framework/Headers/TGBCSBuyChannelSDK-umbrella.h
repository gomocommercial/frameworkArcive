#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "NSString+TGBCSBuyChannelSecure.h"
#import "TGBBuyChannelAFAPISessionManager.h"
#import "TGBBuyChannelFBSessionManager.h"
#import "TGBBuyChannelIPCheckSessionManager.h"
#import "TGBBuyChannelNetworkTools.h"
#import "TGBBuyChannelSessionManager.h"
#import "TGBBuyChannelWebEvent.h"
#import "TGBCSBuyChannel.h"
#import "TGBCSBuyChannelFlyerModel.h"
#import "TGBCSBuyChannelFlyerOneLinkModel.h"
#import "TGBCSBuyChannelHTTPResponse.h"
#import "TGBCSBuyChannelInitParams.h"
#import "TGBCSBuyChannelRequestSerializer.h"
#import "TGBCSBuyChannelSecureManager.h"
#import "TGBCSBuyPheadModel.h"
#import "TGBCSCustomPostData.h"
#import "TGBCSTrackFailManager.h"
#import "TGBCSTrackFailModel.h"
#import "NSString+TGBCSBuyChannelSecure.h"
#import "TGBBuyChannelAFAPISessionManager.h"
#import "TGBBuyChannelFBSessionManager.h"
#import "TGBBuyChannelIPCheckSessionManager.h"
#import "TGBBuyChannelNetworkTools.h"
#import "TGBBuyChannelSessionManager.h"
#import "TGBBuyChannelWebEvent.h"
#import "TGBCSBuyChannel.h"
#import "TGBCSBuyChannelFlyerModel.h"
#import "TGBCSBuyChannelFlyerOneLinkModel.h"
#import "TGBCSBuyChannelHTTPResponse.h"
#import "TGBCSBuyChannelInitParams.h"
#import "TGBCSBuyChannelRequestSerializer.h"
#import "TGBCSBuyChannelSecureManager.h"
#import "TGBCSBuyPheadModel.h"
#import "TGBCSCustomPostData.h"
#import "TGBCSTrackFailManager.h"
#import "TGBCSTrackFailModel.h"

FOUNDATION_EXPORT double TGBCSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char TGBCSBuyChannelSDKVersionString[];

