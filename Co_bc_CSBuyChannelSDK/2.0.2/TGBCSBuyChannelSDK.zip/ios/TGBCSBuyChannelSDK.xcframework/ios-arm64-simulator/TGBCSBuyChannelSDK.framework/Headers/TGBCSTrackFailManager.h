//
//  TGBCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "TGBCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)tGBsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(TGBCSTrackFailModel*)tGBunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)tGBdelSerializedBean:(TGBCSTrackFailModel*)bean;
//+(NSArray <TGBCSTrackFailModel *>*)tGBgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)tGBretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
