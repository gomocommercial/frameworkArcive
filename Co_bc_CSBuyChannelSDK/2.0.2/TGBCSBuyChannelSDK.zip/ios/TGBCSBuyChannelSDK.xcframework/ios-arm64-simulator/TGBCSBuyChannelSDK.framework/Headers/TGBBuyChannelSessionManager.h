//
//  TGBBuyChannelSessionManager.h
//  TGBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "TGBCSBuyChannelHTTPResponse.h"
#import "TGBBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGBBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(TGBBuyChannelSessionManager*)tGBsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(TGBBuyChannelSessionManager*)getBuySessionManager;

-(void)tGBstartAsyncRequestComplete:(void(^)(TGBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)tGBtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(TGBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
