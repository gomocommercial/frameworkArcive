//
//  TGBBuyChannelIPCheckSessionManager.h
//  TGBCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "TGBCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TGBBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(TGBBuyChannelIPCheckSessionManager*)tGBsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TGBBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)tGBstartAsyncRequestComplete:(void(^)(TGBCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
