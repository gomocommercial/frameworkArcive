//
//  STEPTCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "STEPTCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sTEPTsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(STEPTCSTrackFailModel*)sTEPTunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sTEPTdelSerializedBean:(STEPTCSTrackFailModel*)bean;
//+(NSArray <STEPTCSTrackFailModel *>*)sTEPTgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sTEPTretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
