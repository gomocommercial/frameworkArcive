//
//  NSString+STEPTCSBuyChannelSecure.h
//  STEPTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (STEPTCSBuyChannelSecure)

+(NSString *)sTEPTbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)sTEPTbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
