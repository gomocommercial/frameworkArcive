//
//  STEPTBuyChannelIPCheckSessionManager.h
//  STEPTCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "STEPTCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STEPTBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(STEPTBuyChannelIPCheckSessionManager*)sTEPTsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(STEPTBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sTEPTstartAsyncRequestComplete:(void(^)(STEPTCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
