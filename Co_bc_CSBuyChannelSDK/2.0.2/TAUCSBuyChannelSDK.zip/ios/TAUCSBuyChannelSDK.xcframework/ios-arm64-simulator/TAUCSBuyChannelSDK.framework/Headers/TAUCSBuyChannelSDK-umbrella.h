#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "NSString+TAUCSBuyChannelSecure.h"
#import "TAUBuyChannelAFAPISessionManager.h"
#import "TAUBuyChannelFBSessionManager.h"
#import "TAUBuyChannelIPCheckSessionManager.h"
#import "TAUBuyChannelNetworkTools.h"
#import "TAUBuyChannelSessionManager.h"
#import "TAUBuyChannelWebEvent.h"
#import "TAUCSBuyChannel.h"
#import "TAUCSBuyChannelFlyerModel.h"
#import "TAUCSBuyChannelFlyerOneLinkModel.h"
#import "TAUCSBuyChannelHTTPResponse.h"
#import "TAUCSBuyChannelInitParams.h"
#import "TAUCSBuyChannelRequestSerializer.h"
#import "TAUCSBuyChannelSecureManager.h"
#import "TAUCSBuyPheadModel.h"
#import "TAUCSCustomPostData.h"
#import "TAUCSTrackFailManager.h"
#import "TAUCSTrackFailModel.h"
#import "NSString+TAUCSBuyChannelSecure.h"
#import "TAUBuyChannelAFAPISessionManager.h"
#import "TAUBuyChannelFBSessionManager.h"
#import "TAUBuyChannelIPCheckSessionManager.h"
#import "TAUBuyChannelNetworkTools.h"
#import "TAUBuyChannelSessionManager.h"
#import "TAUBuyChannelWebEvent.h"
#import "TAUCSBuyChannel.h"
#import "TAUCSBuyChannelFlyerModel.h"
#import "TAUCSBuyChannelFlyerOneLinkModel.h"
#import "TAUCSBuyChannelHTTPResponse.h"
#import "TAUCSBuyChannelInitParams.h"
#import "TAUCSBuyChannelRequestSerializer.h"
#import "TAUCSBuyChannelSecureManager.h"
#import "TAUCSBuyPheadModel.h"
#import "TAUCSCustomPostData.h"
#import "TAUCSTrackFailManager.h"
#import "TAUCSTrackFailModel.h"

FOUNDATION_EXPORT double TAUCSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char TAUCSBuyChannelSDKVersionString[];

