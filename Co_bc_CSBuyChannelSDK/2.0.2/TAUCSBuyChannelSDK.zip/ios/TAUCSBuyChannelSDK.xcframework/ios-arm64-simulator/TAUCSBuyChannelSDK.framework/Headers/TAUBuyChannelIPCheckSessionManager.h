//
//  TAUBuyChannelIPCheckSessionManager.h
//  TAUCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "TAUCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TAUBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(TAUBuyChannelIPCheckSessionManager*)tAUsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TAUBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)tAUstartAsyncRequestComplete:(void(^)(TAUCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
