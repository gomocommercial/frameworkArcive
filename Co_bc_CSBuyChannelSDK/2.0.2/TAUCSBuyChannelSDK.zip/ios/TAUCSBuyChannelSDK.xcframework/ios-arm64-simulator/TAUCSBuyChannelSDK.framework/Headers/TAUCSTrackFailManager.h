//
//  TAUCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "TAUCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TAUCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)tAUsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(TAUCSTrackFailModel*)tAUunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)tAUdelSerializedBean:(TAUCSTrackFailModel*)bean;
//+(NSArray <TAUCSTrackFailModel *>*)tAUgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)tAUretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
