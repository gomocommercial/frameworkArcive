//
//  TAUBuyChannelSessionManager.h
//  TAUCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "TAUCSBuyChannelHTTPResponse.h"
#import "TAUBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface TAUBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(TAUBuyChannelSessionManager*)tAUsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(TAUBuyChannelSessionManager*)getBuySessionManager;

-(void)tAUstartAsyncRequestComplete:(void(^)(TAUCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)tAUtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(TAUCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
