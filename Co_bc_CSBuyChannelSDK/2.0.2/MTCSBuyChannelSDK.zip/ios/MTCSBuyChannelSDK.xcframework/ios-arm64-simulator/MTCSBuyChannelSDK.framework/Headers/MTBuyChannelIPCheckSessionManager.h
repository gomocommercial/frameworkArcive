//
//  MTBuyChannelIPCheckSessionManager.h
//  MTCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "MTCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MTBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(MTBuyChannelIPCheckSessionManager*)mTsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(MTBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)mTstartAsyncRequestComplete:(void(^)(MTCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
