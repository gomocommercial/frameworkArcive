//
//  MTCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MTCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MTCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mTsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MTCSTrackFailModel*)mTunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mTdelSerializedBean:(MTCSTrackFailModel*)bean;
//+(NSArray <MTCSTrackFailModel *>*)mTgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mTretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
