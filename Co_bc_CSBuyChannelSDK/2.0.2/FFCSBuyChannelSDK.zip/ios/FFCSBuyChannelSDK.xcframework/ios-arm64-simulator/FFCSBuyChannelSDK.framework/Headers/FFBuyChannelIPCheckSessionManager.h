//
//  FFBuyChannelIPCheckSessionManager.h
//  FFCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "FFCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FFBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(FFBuyChannelIPCheckSessionManager*)fFsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(FFBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)fFstartAsyncRequestComplete:(void(^)(FFCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
