//
//  CFXBuyChannelSessionManager.h
//  CFXCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "CFXCSBuyChannelHTTPResponse.h"
#import "CFXBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFXBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(CFXBuyChannelSessionManager*)cFXsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(CFXBuyChannelSessionManager*)getBuySessionManager;

-(void)cFXstartAsyncRequestComplete:(void(^)(CFXCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cFXtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CFXCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
