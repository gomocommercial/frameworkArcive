//
//  CFXCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CFXCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFXCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cFXsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CFXCSTrackFailModel*)cFXunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cFXdelSerializedBean:(CFXCSTrackFailModel*)bean;
//+(NSArray <CFXCSTrackFailModel *>*)cFXgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cFXretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
