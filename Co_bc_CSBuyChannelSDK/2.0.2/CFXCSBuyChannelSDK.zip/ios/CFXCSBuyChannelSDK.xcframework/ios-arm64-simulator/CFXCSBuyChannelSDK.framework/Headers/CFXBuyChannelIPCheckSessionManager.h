//
//  CFXBuyChannelIPCheckSessionManager.h
//  CFXCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "CFXCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFXBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(CFXBuyChannelIPCheckSessionManager*)cFXsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CFXBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cFXstartAsyncRequestComplete:(void(^)(CFXCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
