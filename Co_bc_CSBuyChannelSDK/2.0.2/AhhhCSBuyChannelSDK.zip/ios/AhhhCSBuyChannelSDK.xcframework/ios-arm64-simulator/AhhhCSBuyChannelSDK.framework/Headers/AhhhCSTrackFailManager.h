//
//  AhhhCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "AhhhCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)ahhhsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(AhhhCSTrackFailModel*)ahhhunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)ahhhdelSerializedBean:(AhhhCSTrackFailModel*)bean;
//+(NSArray <AhhhCSTrackFailModel *>*)ahhhgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)ahhhretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
