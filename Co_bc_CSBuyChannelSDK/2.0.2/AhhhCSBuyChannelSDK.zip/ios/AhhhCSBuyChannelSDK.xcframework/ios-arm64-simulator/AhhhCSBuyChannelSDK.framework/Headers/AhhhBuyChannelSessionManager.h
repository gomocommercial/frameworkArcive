//
//  AhhhBuyChannelSessionManager.h
//  AhhhCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "AhhhCSBuyChannelHTTPResponse.h"
#import "AhhhBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(AhhhBuyChannelSessionManager*)ahhhsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(AhhhBuyChannelSessionManager*)getBuySessionManager;

-(void)ahhhstartAsyncRequestComplete:(void(^)(AhhhCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)ahhhtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(AhhhCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
