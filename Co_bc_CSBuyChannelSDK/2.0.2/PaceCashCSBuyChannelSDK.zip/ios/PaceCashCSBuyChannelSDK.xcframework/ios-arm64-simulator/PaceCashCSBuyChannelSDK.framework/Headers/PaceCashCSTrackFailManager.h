//
//  PaceCashCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PaceCashCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)paceCashsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PaceCashCSTrackFailModel*)paceCashunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)paceCashdelSerializedBean:(PaceCashCSTrackFailModel*)bean;
//+(NSArray <PaceCashCSTrackFailModel *>*)paceCashgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)paceCashretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
