//
//  PaceCashBuyChannelSessionManager.h
//  PaceCashCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "PaceCashCSBuyChannelHTTPResponse.h"
#import "PaceCashBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(PaceCashBuyChannelSessionManager*)paceCashsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PaceCashBuyChannelSessionManager*)getBuySessionManager;

-(void)paceCashstartAsyncRequestComplete:(void(^)(PaceCashCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)paceCashtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PaceCashCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
