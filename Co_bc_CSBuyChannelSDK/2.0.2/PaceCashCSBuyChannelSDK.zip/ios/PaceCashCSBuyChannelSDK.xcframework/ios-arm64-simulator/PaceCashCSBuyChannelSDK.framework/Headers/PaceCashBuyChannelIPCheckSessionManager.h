//
//  PaceCashBuyChannelIPCheckSessionManager.h
//  PaceCashCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "PaceCashCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(PaceCashBuyChannelIPCheckSessionManager*)paceCashsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(PaceCashBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)paceCashstartAsyncRequestComplete:(void(^)(PaceCashCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
