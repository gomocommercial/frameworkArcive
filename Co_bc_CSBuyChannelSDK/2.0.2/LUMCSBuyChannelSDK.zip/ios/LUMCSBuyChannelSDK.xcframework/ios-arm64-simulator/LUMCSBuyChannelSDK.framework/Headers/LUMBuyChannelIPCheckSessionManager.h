//
//  LUMBuyChannelIPCheckSessionManager.h
//  LUMCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "LUMCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUMBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(LUMBuyChannelIPCheckSessionManager*)lUMsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LUMBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)lUMstartAsyncRequestComplete:(void(^)(LUMCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
