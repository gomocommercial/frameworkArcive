//
//  LUMCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LUMCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUMCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lUMsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LUMCSTrackFailModel*)lUMunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lUMdelSerializedBean:(LUMCSTrackFailModel*)bean;
//+(NSArray <LUMCSTrackFailModel *>*)lUMgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lUMretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
