//
//  LUMBuyChannelSessionManager.h
//  LUMCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "LUMCSBuyChannelHTTPResponse.h"
#import "LUMBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LUMBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(LUMBuyChannelSessionManager*)lUMsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(LUMBuyChannelSessionManager*)getBuySessionManager;

-(void)lUMstartAsyncRequestComplete:(void(^)(LUMCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lUMtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LUMCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
