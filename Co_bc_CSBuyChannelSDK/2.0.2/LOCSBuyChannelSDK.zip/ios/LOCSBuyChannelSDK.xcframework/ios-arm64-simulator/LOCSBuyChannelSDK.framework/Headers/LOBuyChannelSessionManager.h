//
//  LOBuyChannelSessionManager.h
//  LOCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "LOCSBuyChannelHTTPResponse.h"
#import "LOBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LOBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(LOBuyChannelSessionManager*)lOsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(LOBuyChannelSessionManager*)getBuySessionManager;

-(void)lOstartAsyncRequestComplete:(void(^)(LOCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lOtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LOCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
