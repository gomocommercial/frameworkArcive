//
//  LOCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LOCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LOCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lOsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LOCSTrackFailModel*)lOunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lOdelSerializedBean:(LOCSTrackFailModel*)bean;
//+(NSArray <LOCSTrackFailModel *>*)lOgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lOretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
