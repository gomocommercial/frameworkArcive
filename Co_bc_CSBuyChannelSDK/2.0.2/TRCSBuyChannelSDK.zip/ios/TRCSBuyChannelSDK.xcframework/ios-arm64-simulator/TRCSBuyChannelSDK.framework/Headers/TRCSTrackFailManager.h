//
//  TRCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "TRCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)tRsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(TRCSTrackFailModel*)tRunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)tRdelSerializedBean:(TRCSTrackFailModel*)bean;
//+(NSArray <TRCSTrackFailModel *>*)tRgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)tRretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
