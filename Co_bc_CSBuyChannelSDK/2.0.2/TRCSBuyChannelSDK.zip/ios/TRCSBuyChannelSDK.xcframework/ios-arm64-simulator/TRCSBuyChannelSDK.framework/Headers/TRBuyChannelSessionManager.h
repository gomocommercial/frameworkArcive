//
//  TRBuyChannelSessionManager.h
//  TRCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "TRCSBuyChannelHTTPResponse.h"
#import "TRBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(TRBuyChannelSessionManager*)tRsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(TRBuyChannelSessionManager*)getBuySessionManager;

-(void)tRstartAsyncRequestComplete:(void(^)(TRCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)tRtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(TRCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
