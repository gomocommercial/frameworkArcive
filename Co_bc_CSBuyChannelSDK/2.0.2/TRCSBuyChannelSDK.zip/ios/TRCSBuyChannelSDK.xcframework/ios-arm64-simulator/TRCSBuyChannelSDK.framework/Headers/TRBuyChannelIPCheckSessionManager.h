//
//  TRBuyChannelIPCheckSessionManager.h
//  TRCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "TRCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(TRBuyChannelIPCheckSessionManager*)tRsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(TRBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)tRstartAsyncRequestComplete:(void(^)(TRCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
