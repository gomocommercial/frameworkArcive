//
//  NSString+TRCSBuyChannelSecure.h
//  TRCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (TRCSBuyChannelSecure)

+(NSString *)tRbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)tRbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
