//
//  SNAPCBuyChannelSessionManager.h
//  SNAPCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "SNAPCCSBuyChannelHTTPResponse.h"
#import "SNAPCBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface SNAPCBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(SNAPCBuyChannelSessionManager*)sNAPCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(SNAPCBuyChannelSessionManager*)getBuySessionManager;

-(void)sNAPCstartAsyncRequestComplete:(void(^)(SNAPCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sNAPCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SNAPCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
