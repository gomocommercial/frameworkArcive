//
//  SNAPCCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "SNAPCCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SNAPCCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)sNAPCsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(SNAPCCSTrackFailModel*)sNAPCunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)sNAPCdelSerializedBean:(SNAPCCSTrackFailModel*)bean;
//+(NSArray <SNAPCCSTrackFailModel *>*)sNAPCgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)sNAPCretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
