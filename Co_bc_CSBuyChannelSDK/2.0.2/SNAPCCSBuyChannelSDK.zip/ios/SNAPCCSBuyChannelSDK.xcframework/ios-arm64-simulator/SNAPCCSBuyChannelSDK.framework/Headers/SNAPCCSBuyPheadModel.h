//
//  SNAPCCSBuyPheadModel.h
//  SNAPCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SNAPCCSBuyPheadModel : NSObject

+ (NSDictionary *)sNAPCgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
