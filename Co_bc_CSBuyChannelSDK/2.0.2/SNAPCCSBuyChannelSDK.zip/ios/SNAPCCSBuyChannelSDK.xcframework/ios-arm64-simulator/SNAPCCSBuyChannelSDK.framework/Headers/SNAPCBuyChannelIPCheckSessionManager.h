//
//  SNAPCBuyChannelIPCheckSessionManager.h
//  SNAPCCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "SNAPCCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SNAPCBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(SNAPCBuyChannelIPCheckSessionManager*)sNAPCsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(SNAPCBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sNAPCstartAsyncRequestComplete:(void(^)(SNAPCCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
