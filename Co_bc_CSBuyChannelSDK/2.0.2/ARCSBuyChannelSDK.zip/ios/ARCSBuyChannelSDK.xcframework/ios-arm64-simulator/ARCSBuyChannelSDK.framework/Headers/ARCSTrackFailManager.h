//
//  ARCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "ARCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ARCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)aRsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(ARCSTrackFailModel*)aRunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)aRdelSerializedBean:(ARCSTrackFailModel*)bean;
//+(NSArray <ARCSTrackFailModel *>*)aRgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)aRretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
