//
//  ARBuyChannelIPCheckSessionManager.h
//  ARCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "ARCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ARBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(ARBuyChannelIPCheckSessionManager*)aRsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(ARBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)aRstartAsyncRequestComplete:(void(^)(ARCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
