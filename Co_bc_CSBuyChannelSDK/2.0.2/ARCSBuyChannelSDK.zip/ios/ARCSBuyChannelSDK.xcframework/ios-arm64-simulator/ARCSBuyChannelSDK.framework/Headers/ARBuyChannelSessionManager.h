//
//  ARBuyChannelSessionManager.h
//  ARCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "ARCSBuyChannelHTTPResponse.h"
#import "ARBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface ARBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(ARBuyChannelSessionManager*)aRsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(ARBuyChannelSessionManager*)getBuySessionManager;

-(void)aRstartAsyncRequestComplete:(void(^)(ARCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)aRtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(ARCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
