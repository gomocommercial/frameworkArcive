//
//  MBBuyChannelSessionManager.h
//  MBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MBCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface MBBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(MBBuyChannelSessionManager*)mBsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(MBBuyChannelSessionManager*)getBuySessionManager;
-(void)mBstartAsyncRequestComplete:(void(^)(MBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)mBtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
