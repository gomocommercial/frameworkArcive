//
//  NBBuyChannelSessionManager.h
//  NBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "NBCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface NBBuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(NBBuyChannelSessionManager*)nBsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(NBBuyChannelSessionManager*)getBuySessionManager;
-(void)nBstartAsyncRequestComplete:(void(^)(NBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)nBtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(NBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
