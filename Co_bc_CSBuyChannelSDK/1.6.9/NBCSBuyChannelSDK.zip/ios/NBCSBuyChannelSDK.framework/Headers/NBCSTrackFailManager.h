//
//  NBCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "NBCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface NBCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)nBsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(NBCSTrackFailModel*)nBunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)nBdelSerializedBean:(NBCSTrackFailModel*)bean;
//+(NSArray <NBCSTrackFailModel *>*)nBgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)nBretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
