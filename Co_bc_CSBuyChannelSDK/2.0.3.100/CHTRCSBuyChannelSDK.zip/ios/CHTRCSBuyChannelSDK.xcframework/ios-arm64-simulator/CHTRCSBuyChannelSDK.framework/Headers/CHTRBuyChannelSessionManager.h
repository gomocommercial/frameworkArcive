//
//  CHTRBuyChannelSessionManager.h
//  CHTRCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "CHTRCSBuyChannelHTTPResponse.h"
#import "CHTRBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface CHTRBuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(CHTRBuyChannelSessionManager*)cHTRsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(CHTRBuyChannelSessionManager*)getBuySessionManager;

-(void)cHTRstartAsyncRequestComplete:(void(^)(CHTRCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cHTRtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CHTRCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
