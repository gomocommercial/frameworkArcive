//
//  CHTRCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CHTRCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CHTRCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cHTRsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CHTRCSTrackFailModel*)cHTRunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cHTRdelSerializedBean:(CHTRCSTrackFailModel*)bean;
//+(NSArray <CHTRCSTrackFailModel *>*)cHTRgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cHTRretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
