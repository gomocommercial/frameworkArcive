//
//  CHTRBuyChannelIPCheckSessionManager.h
//  CHTRCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "CHTRCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CHTRBuyChannelIPCheckSessionManager : NSObject

@property (nonatomic, copy, readonly) NSString *desKey;

+(CHTRBuyChannelIPCheckSessionManager*)cHTRsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CHTRBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cHTRstartAsyncRequestComplete:(void(^)(CHTRCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
