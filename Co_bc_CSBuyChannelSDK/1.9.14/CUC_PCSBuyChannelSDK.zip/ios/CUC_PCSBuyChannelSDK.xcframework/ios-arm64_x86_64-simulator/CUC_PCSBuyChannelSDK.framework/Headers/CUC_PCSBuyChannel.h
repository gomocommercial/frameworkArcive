//
//  CSBuyChannel.h
//  AppsFlyer
//
//  Created by qiaoming on 2018/8/21.
//  Copyright © 2018年 qiaoming. All rights reserved.
//#import <CSStatistics/CSStatistics.h>
//#import <CSStatistics/CSStatisticsDeviceInfo.h>
//---1.5.3
#import <Foundation/Foundation.h>
#import "CUC_PCSBuyChannelFlyerModel.h"
#import "CUC_PCSBuyChannelInitParams.h"
#import "CUC_PCSBuyChannelFlyerOneLinkModel.h"
#import "CUC_PBuyChannelWebEvent.h"

#define CUC_PCSBuyLog(fmt, ...)                                    \
  do                                                           \
  {                                                            \
    if ([CUC_PCSBuyChannel getCsBuyChannel].params.enableLog) \
    {                                                          \
      NSLog((fmt), ##__VA_ARGS__);                             \
    }                                                          \
  } while (0)

//af返回的数据有改变的时候 发出这个通知
#define NOTIFACTION_NAME_BUY_CHANNELS_IDENTIFER @"NOTIFACTION_NAME_BUY_CHANNELS_IDENTIFER"

FOUNDATION_EXPORT double CSBuyChannelVersionNumber;

//! Project version string for CSBuyChannel.
FOUNDATION_EXPORT const unsigned char CSBuyChannelVersionString[];

typedef enum : NSUInteger {
    CUC_PCSBuyChannelIPTypeNone = 0,//未使用
    CUC_PCSBuyChannelIPTypeBlackList = 1,//审核IP
    CUC_PCSBuyChannelIPTypeWhiteList = 2,//非审核IP，买量
    CUC_PCSBuyChannelIPTypeUnknow = 3,//非审核IP，自然
} CUC_PCSBuyChannelIPType;

typedef void(^CUC_PBuyChannelComplete)(NSString *buyChannel, NSString *userFrom, NSError *error);

@protocol CUC_PCSBuyChannelDelegate <NSObject>

@optional

/*
 回调AF返回的原始数据
 */
- (void)cUC_PbuyChannelOnConversionDataReceivedBuyChannel:(NSString *)buyChannel userFrom:(NSString *)userFrom;

/*
 * 二次确认 AF 身份,  当 AF 返回自然用户时，会再次请求服务器获取用户类型
 */
- (void)cUC_PbuyChannelOnConversionDataEnsureBuyChannel:(NSString *)buyChannel userFrom:(NSString *)userFrom;

- (void)cUC_PbuyChannelOnConversionDataRequestFailure:(NSError *)error;

/*
 * 二次确认 AF 身份失败
 */
- (void)cUC_PbuyChannelOnConversionDataEnsureFailure:(NSError *)error;

/// IP归因身份，只获取一次，之后每次会读取本地缓存
/// @param type 身份
/// @param error 错误码，null标识获取成功
- (void)cUC_PbuyChannelIpType:(CUC_PCSBuyChannelIPType)type error:(NSError  * _Nullable )error;

@end

@interface CUC_PCSBuyChannel : NSObject

@property (nonatomic, strong, readonly) CUC_PCSBuyChannelInitParams *params;

//用户类型  （买量渠道（fb或者adwords之类的字符串））
@property (nonatomic, copy) NSString *buyChannel;

//用户类型标识 （用户类型标示(-1 - 9数字)
@property (nonatomic, copy) NSString *userFrom;
//广告计划id    仅字节跳动的会下发
@property (nonatomic, copy) NSString * _Nullable aid;
//广告计划名称    仅字节跳动的会下发
@property (nonatomic, copy) NSString * _Nullable aidName;
//推广账号id    仅字节跳动的会下发
@property (nonatomic, copy) NSString * _Nullable accountId;

/// CSBuyChannel delegate. See CSBuyChannelDelegate abvoe
@property (weak, nonatomic) id<CUC_PCSBuyChannelDelegate> delegate;

/* 走海外af的方式 你可以用这个属性 获取af返回的关键信息  例如:media_source  和  buychannel, agency campaign*/
/* 国内自研的方式 你可以只用这个属性 获取 buychannel, ampaign两个值, 其余的都是null或者"", 请做空值判断*/
@property (nonatomic, strong) CUC_PCSBuyChannelFlyerModel *channelFlyerModel;

/**
 使用appsflyer的oneLink时，didResolveDeepLink方法回调的参数
 */
@property (nonatomic, strong) CUC_PCSBuyChannelFlyerOneLinkModel *oneLinkModel;

/// 买量SDK新初始化方案
/// @param params initParams
/// @param launchOptions AppDelegate方案启动需要传launchOptions
/// @param connectionOptions SceneDelegate方案需要传connectionOptions
+(void)cUC_Psetup:(CUC_PCSBuyChannelInitParams *)params launchOptions:(nullable NSDictionary *)launchOptions
 connectionOptions:(nullable UISceneConnectionOptions *)connectionOptions;

//确保初始化完成之后 才能使用这个获取单利的方法,目的是获取值使用的
+(CUC_PCSBuyChannel*)getCsBuyChannel;

//调起AF
+(void)cUC_PtrackAppLaunch;

//通过 AF gcd 接口二次确认用户身份, 通过 delegate 回调
+ (void)cUC_PstartGetAFGcdData;

//通过 AF gcd 接口二次确认用户身份, 通过 block 回调
+ (void)cUC_PstartGetAFGcdData:(nullable CUC_PBuyChannelComplete)complete;

//设置测试买量数据，一个 json 字符串，可以通过模拟买量获得
//一个示例 {"adset":"","click_time":"2024-09-23 10:19:21.975","is_incentivized":"false","af_sub2":"","is_retargeting":"false","is_branded_link":"","esp_name":"","af_siteid":"","shortlink":"78nzbcnv","agency":"","af_status":"Non-organic","http_referrer":"","af_cpi":"","af_sub1":"","cost_cents_USD":"0","CB_preload_equal_priority_enabled":"0","campaign":"applovin_IAA","is_universal_link":"","af_pmod_lookback_window":"1d","install_time":"2024-09-23 10:19:58.893","adgroup":"","iscache":"1","af_sub5":"","af_click_lookback":"7d","adset_id":"","adgroup_id":"","engmnt_source":"","media_source":"applovin","af_sub4":"","is_first_launch":"1","campaign_id":"","redirect_response_data":"","orig_cost":"0.0","match_type":"probabilistic","af_sub3":"","retargeting_conversion_type":"none"}
+ (void)cUC_PsetTestGcdData:(NSString *)buyChannel;

/// 设置ATT等待超时时间(默认不等待直接发起AF),从设置之时起开始计时，需要在cUC_PtrackAppLaunch前设置才会生效
/// @param time 设置0为一直等待
+(void)waitATTWithTimeoutInterval:(NSTimeInterval)time;

//获取sdk的版本
+(NSString *)getSDKVersion;

//是否是买量类型
+(BOOL)cUC_PisBuyUserSource;

//是否是带量类型
+(BOOL)cUC_PisBandUserSource;

//是否是自然类型
+(BOOL)cUC_PisOrganicUserSource;

+ (CUC_PCSBuyChannelIPType)cUC_PgetIpType;

//清除缓存的用户类型以及标示,清除完成之后,默认会返回自然的类型(-1), 不建议调用
+(void)cUC_PclearAppsFlyerOriginalData;

//测试跑量数据使用
+(NSDictionary *)cUC_PtestAfOriginalData:(NSDictionary *)installData isUploadToCSStatistics:(BOOL)uploadFlag;

//模拟买量的数据和类型
+(void)cUC_PSimulateBuyChannel:(NSString *)buyChannel userForm:(NSString *)userForm;
//是否已经成功获取过结果(拿到买量身份 或者互补方案(服务器和af都返回自然), 或者只走海外方案af返回自然)
+(BOOL)cUC_PisRequestFinish;

+(void)destroyChannel;
//(互补方案使用)判断是不是在中国区 通过国家CN 或者语言zh来判断
+(BOOL)isChina;
//(互补方案使用)告诉客户端 打点事件应该打给谁,返回YES调起sdk提供的打点方法, 返回NO自己调起af打点  
+(BOOL)trackEventToService;

/*
 订阅打点事件 不用关心结果 sdk内部会做重试机制(af打点请自行参考af的文档, 这个方法仅适用于国内自研服务器打点)
 @param event 事件名称:自研服务器为"subscribe"
               自研服务器实例:
               @{
                 @"attribute1": 订阅事件传原始订单号(originTransactionId),
                 @"attribute2": 订阅事件传订单号(transactionId),
                 @"attribute3": 订阅事件传商品id,
                 @"attribute4": 备用字段1,
                 @"attribute5": 备用字段2
               }   
*/
+(void)trackEvent:(NSString *)event withValues:(NSDictionary *)values;

// https://wiki.3g.net.cn/pages/viewpage.action?pageId=35325635#id-%E4%B9%B0%E9%87%8F%E8%AF%86%E5%88%AB-API%E6%8E%A5%E5%8F%A3-18%E3%80%81Web%E5%85%B6%E4%BB%96%E4%BA%8B%E4%BB%B6%E4%B8%8A%E6%8A%A5%EF%BC%88ISO1818018%EF%BC%89
+(void)trackWebEvent:(CUC_PBuyChannelWebEvent *)event;

/// 修改用户Campaign，并上传到45协议，当识别为买量时此接口无效
/// @param campaign 客户端想要设置的Campaign字符串
+ (void)cUC_PresetUserCampaign:(NSString * _Nullable)campaign;

/// 获取用户重置后的Campaign
+ (NSString * _Nullable)cUC_PgetResetUserCampaign;

//MARK: 弃用方案
/**
 用户类型sdk的初始化方法,不需要互补方案的(只会走af),请调用用这个方法初始化
 @param appsDevKey AppsFlyer上面返回的appsDevKey
 @param appleAppID AppsFlyer上面返回的appleAppID
 */
+(CUC_PCSBuyChannel*)cUC_PsharedBuyChannelAppsDevKey:(NSString *)appsDevKey appleAppID:(NSString *)appleAppID configureDisseminationFuncId:(NSString *)funcId cid:(NSString *)cid;

/**
用户类型sdk的初始化方法,需要互补方案的请调用用这个方法初始化, 并且传入域名.
1.此方法如果获取到服务器为自然, 也再走一次af补充.
2.如果获取到af为自然, 也会再走一次服务器补充
@param appsDevKey AppsFlyer上面返回的appsDevKey
@param appleAppID AppsFlyer上面返回的appleAppID
@param domainName 中国区域名
@param firstTrackService  是否需要先请求我们服务器 YES优先服务器(适用于中国大陆),  NO优先af(适用于海外)
*/
+(CUC_PCSBuyChannel*)cUC_PsharedBuyChannelAppsDevKey:(NSString *)appsDevKey appleAppID:(NSString *)appleAppID configureDisseminationFuncId:(NSString *)funcId cid:(NSString *)cid domainNameOfCn:(NSString *)domainName signatureKey:(NSString *)signatureKey desKey:(NSString *)desKey prodKey:(NSString *)prodKey firstTrackService:(BOOL)firstTrackService;

//是否开启log日志输出
+(void)setEnableLog:(BOOL)enanleLog;

/**
 设置统计SDK的编译环境 是否是debug环境
 
 Debug: 数据上传测试服
 
 Release: 数据上传正式服 (默认)
 
 @param isDebug 编译环境类型
 */
+ (void)setEnvironmentIsDebug:(BOOL)isDebug;


/// 巨量广告转化融合归因优化方案Deeplink clickid采集,当其他app通过deeplink方式打开本app时，将相关参数传递给巨量引擎转化SDK
/// 在 (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options中调用
/// - Parameter openUrl: 将url参数转换成string类型之后，传递给SDK
+ (void)cUC_PanylyseDeeplinkClickidWithOpenUrl: (NSString *)openUrl;

@end
