//
//  CUC_PCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CUC_PCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cUC_PsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CUC_PCSTrackFailModel*)cUC_PunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cUC_PdelSerializedBean:(CUC_PCSTrackFailModel*)bean;
//+(NSArray <CUC_PCSTrackFailModel *>*)cUC_PgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cUC_PretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
