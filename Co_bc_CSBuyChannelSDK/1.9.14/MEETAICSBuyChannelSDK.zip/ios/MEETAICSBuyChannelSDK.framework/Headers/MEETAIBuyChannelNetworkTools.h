//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface MEETAIBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)mEETAIgetIPv6AddressesOfAllInterface;
+ (NSString *)mEETAIgetIPv6AddressOfInterfaces;
+ (NSString *)mEETAIgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end