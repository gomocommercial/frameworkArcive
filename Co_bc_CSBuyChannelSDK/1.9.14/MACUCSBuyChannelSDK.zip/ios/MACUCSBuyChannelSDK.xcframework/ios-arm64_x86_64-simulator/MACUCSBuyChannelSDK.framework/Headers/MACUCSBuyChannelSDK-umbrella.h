#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MACUBuyChannelAFAPISessionManager.h"
#import "MACUBuyChannelIPCheckSessionManager.h"
#import "MACUBuyChannelNetworkTools.h"
#import "MACUBuyChannelSessionManager.h"
#import "MACUCSBuyChannel.h"
#import "MACUCSBuyChannelFlyerModel.h"
#import "MACUCSBuyChannelFlyerOneLinkModel.h"
#import "MACUCSBuyChannelHTTPResponse.h"
#import "MACUCSBuyChannelInitParams.h"
#import "MACUCSBuyChannelIPCheckRequestSerializer.h"
#import "MACUCSBuyChannelRequestSerializer.h"
#import "MACUCSBuyChannelSecureManager.h"
#import "MACUCSBuyPheadModel.h"
#import "MACUCSCustomPostData.h"
#import "MACUCSTrackFailManager.h"
#import "MACUCSTrackFailModel.h"
#import "NSString+MACUCSBuyChannelSecure.h"
#import "MACUBuyChannelAFAPISessionManager.h"
#import "MACUBuyChannelIPCheckSessionManager.h"
#import "MACUBuyChannelNetworkTools.h"
#import "MACUBuyChannelSessionManager.h"
#import "MACUCSBuyChannel.h"
#import "MACUCSBuyChannelFlyerModel.h"
#import "MACUCSBuyChannelFlyerOneLinkModel.h"
#import "MACUCSBuyChannelHTTPResponse.h"
#import "MACUCSBuyChannelInitParams.h"
#import "MACUCSBuyChannelIPCheckRequestSerializer.h"
#import "MACUCSBuyChannelRequestSerializer.h"
#import "MACUCSBuyChannelSecureManager.h"
#import "MACUCSBuyPheadModel.h"
#import "MACUCSCustomPostData.h"
#import "MACUCSTrackFailManager.h"
#import "MACUCSTrackFailModel.h"
#import "NSString+MACUCSBuyChannelSecure.h"

FOUNDATION_EXPORT double MACUCSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char MACUCSBuyChannelSDKVersionString[];

