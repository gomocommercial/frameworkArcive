//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface MACUBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)mACUgetIPv6AddressesOfAllInterface;
+ (NSString *)mACUgetIPv6AddressOfInterfaces;
+ (NSString *)mACUgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end