//
// Created by KevinGuo on 2024/9/9.
//

#import <Foundation/Foundation.h>


@interface AWBuyChannelNetworkTools : NSObject

+ (NSDictionary <NSString *, NSArray<NSString *> *> *)aWgetIPv6AddressesOfAllInterface;
+ (NSString *)aWgetIPv6AddressOfInterfaces;
+ (NSString *)aWgetSystemChosenIPv6AddressForDomain:(NSString *)domain port:(int)port;
+ (NSString *)getSystemChosenIPv6AddressByPublicDNS;

@end