//
//  AMACSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "AMACSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AMACSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)aMAsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(AMACSTrackFailModel*)aMAunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)aMAdelSerializedBean:(AMACSTrackFailModel*)bean;
//+(NSArray <AMACSTrackFailModel *>*)aMAgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)aMAretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
