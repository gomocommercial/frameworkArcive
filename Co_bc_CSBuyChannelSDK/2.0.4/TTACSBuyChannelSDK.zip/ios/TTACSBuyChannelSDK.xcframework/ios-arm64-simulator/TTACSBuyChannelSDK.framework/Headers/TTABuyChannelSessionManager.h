//
//  TTABuyChannelSessionManager.h
//  TTACSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <Foundation/Foundation.h>
#import "TTACSBuyChannelHTTPResponse.h"
#import "TTABuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTABuyChannelSessionManager : NSObject
@property (nonatomic, copy, readonly) NSString *desKey;

+(TTABuyChannelSessionManager*)tTAsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(TTABuyChannelSessionManager*)getBuySessionManager;

-(void)tTAstartAsyncRequestComplete:(void(^)(TTACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)tTAtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(TTACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
