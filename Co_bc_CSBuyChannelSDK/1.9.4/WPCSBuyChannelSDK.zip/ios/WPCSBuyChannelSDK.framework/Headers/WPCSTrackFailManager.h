//
//  WPCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "WPCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface WPCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)wPsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(WPCSTrackFailModel*)wPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)wPdelSerializedBean:(WPCSTrackFailModel*)bean;
//+(NSArray <WPCSTrackFailModel *>*)wPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)wPretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
