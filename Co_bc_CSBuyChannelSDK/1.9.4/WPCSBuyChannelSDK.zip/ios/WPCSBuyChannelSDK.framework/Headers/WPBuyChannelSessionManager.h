//
//  WPBuyChannelSessionManager.h
//  WPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "WPCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface WPBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(WPBuyChannelSessionManager*)wPsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(WPBuyChannelSessionManager*)getBuySessionManager;

-(void)wPstartAsyncRequestComplete:(void(^)(WPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)wPtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(WPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
