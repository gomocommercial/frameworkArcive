//
//  STEPTBuyChannelSessionManager.h
//  STEPTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "STEPTCSBuyChannelHTTPResponse.h"
#import "STEPTBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface STEPTBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(STEPTBuyChannelSessionManager*)sTEPTsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(STEPTBuyChannelSessionManager*)getBuySessionManager;

-(void)sTEPTstartAsyncRequestComplete:(void(^)(STEPTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sTEPTtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(STEPTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
