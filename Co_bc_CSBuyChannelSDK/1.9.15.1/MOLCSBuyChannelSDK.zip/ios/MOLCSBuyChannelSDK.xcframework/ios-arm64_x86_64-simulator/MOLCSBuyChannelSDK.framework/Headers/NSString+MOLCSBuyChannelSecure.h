//
//  NSString+MOLCSBuyChannelSecure.h
//  MOLCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (MOLCSBuyChannelSecure)

+(NSString *)mOLbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)mOLbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
