//
//  MOLBuyChannelSessionManager.h
//  MOLCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MOLCSBuyChannelHTTPResponse.h"
#import "MOLBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface MOLBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(MOLBuyChannelSessionManager*)mOLsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(MOLBuyChannelSessionManager*)getBuySessionManager;

-(void)mOLstartAsyncRequestComplete:(void(^)(MOLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)mOLtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MOLCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
