//
//  MOLCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MOLCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MOLCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mOLsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MOLCSTrackFailModel*)mOLunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mOLdelSerializedBean:(MOLCSTrackFailModel*)bean;
//+(NSArray <MOLCSTrackFailModel *>*)mOLgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mOLretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
