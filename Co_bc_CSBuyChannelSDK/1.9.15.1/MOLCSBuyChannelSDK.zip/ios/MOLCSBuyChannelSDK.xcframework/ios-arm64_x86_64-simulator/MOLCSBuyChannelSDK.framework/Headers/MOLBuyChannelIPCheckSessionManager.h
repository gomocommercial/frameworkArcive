//
//  MOLBuyChannelIPCheckSessionManager.h
//  MOLCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MOLCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MOLBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(MOLBuyChannelIPCheckSessionManager*)mOLsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(MOLBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)mOLstartAsyncRequestComplete:(void(^)(MOLCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
