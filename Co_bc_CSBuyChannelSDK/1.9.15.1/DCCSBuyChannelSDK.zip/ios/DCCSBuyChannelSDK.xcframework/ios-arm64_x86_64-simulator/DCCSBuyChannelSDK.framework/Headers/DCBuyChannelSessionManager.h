//
//  DCBuyChannelSessionManager.h
//  DCCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DCCSBuyChannelHTTPResponse.h"
#import "DCBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface DCBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(DCBuyChannelSessionManager*)dCsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(DCBuyChannelSessionManager*)getBuySessionManager;

-(void)dCstartAsyncRequestComplete:(void(^)(DCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)dCtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(DCCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
