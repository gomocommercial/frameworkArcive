//
//  FurTalesBuyChannelSessionManager.h
//  FurTalesCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "FurTalesCSBuyChannelHTTPResponse.h"
#import "FurTalesBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(FurTalesBuyChannelSessionManager*)furTalessharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(FurTalesBuyChannelSessionManager*)getBuySessionManager;

-(void)furTalesstartAsyncRequestComplete:(void(^)(FurTalesCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)furTalestrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(FurTalesCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
