//
//  EATCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "EATCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface EATCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)eATsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(EATCSTrackFailModel*)eATunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)eATdelSerializedBean:(EATCSTrackFailModel*)bean;
//+(NSArray <EATCSTrackFailModel *>*)eATgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)eATretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
