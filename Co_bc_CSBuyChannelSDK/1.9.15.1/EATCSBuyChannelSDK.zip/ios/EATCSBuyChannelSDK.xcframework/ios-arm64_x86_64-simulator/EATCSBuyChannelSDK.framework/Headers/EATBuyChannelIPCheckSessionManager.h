//
//  EATBuyChannelIPCheckSessionManager.h
//  EATCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "EATCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface EATBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(EATBuyChannelIPCheckSessionManager*)eATsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(EATBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)eATstartAsyncRequestComplete:(void(^)(EATCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
