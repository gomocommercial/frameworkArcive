//
//  CPSCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CPSCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPSCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cPSsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CPSCSTrackFailModel*)cPSunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cPSdelSerializedBean:(CPSCSTrackFailModel*)bean;
//+(NSArray <CPSCSTrackFailModel *>*)cPSgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cPSretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
