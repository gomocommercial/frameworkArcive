//
//  CPSBuyChannelSessionManager.h
//  CPSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CPSCSBuyChannelHTTPResponse.h"
#import "CPSBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPSBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(CPSBuyChannelSessionManager*)cPSsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(CPSBuyChannelSessionManager*)getBuySessionManager;

-(void)cPSstartAsyncRequestComplete:(void(^)(CPSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)cPStrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CPSCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
