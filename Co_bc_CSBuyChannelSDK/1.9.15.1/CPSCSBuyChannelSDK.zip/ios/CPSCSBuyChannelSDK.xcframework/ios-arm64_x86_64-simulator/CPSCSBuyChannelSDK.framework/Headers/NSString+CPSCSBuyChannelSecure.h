//
//  NSString+CPSCSBuyChannelSecure.h
//  CPSCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (CPSCSBuyChannelSecure)

+(NSString *)cPSbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)cPSbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
