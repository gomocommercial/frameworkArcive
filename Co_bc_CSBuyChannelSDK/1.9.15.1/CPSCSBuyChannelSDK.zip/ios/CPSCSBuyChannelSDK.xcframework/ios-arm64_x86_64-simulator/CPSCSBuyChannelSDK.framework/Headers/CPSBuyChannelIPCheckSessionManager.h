//
//  CPSBuyChannelIPCheckSessionManager.h
//  CPSCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CPSCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPSBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(CPSBuyChannelIPCheckSessionManager*)cPSsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CPSBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cPSstartAsyncRequestComplete:(void(^)(CPSCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
