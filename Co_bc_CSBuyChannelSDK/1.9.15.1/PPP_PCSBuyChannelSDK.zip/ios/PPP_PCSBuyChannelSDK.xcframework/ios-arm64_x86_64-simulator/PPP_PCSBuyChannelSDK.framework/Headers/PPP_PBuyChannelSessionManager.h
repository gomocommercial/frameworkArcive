//
//  PPP_PBuyChannelSessionManager.h
//  PPP_PCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "PPP_PCSBuyChannelHTTPResponse.h"
#import "PPP_PBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(PPP_PBuyChannelSessionManager*)pPP_PsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(PPP_PBuyChannelSessionManager*)getBuySessionManager;

-(void)pPP_PstartAsyncRequestComplete:(void(^)(PPP_PCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)pPP_PtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(PPP_PCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
