//
//  PPP_PCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "PPP_PCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)pPP_PsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(PPP_PCSTrackFailModel*)pPP_PunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)pPP_PdelSerializedBean:(PPP_PCSTrackFailModel*)bean;
//+(NSArray <PPP_PCSTrackFailModel *>*)pPP_PgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pPP_PretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
