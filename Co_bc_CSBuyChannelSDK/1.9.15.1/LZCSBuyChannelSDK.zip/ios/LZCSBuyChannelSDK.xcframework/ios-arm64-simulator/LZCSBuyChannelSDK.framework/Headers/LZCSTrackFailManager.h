//
//  LZCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LZCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lZsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LZCSTrackFailModel*)lZunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lZdelSerializedBean:(LZCSTrackFailModel*)bean;
//+(NSArray <LZCSTrackFailModel *>*)lZgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lZretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
