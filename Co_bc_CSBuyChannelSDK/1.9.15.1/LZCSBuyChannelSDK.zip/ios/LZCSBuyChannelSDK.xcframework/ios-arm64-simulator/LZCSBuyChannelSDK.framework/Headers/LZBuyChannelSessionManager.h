//
//  LZBuyChannelSessionManager.h
//  LZCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LZCSBuyChannelHTTPResponse.h"
#import "LZBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(LZBuyChannelSessionManager*)lZsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(LZBuyChannelSessionManager*)getBuySessionManager;

-(void)lZstartAsyncRequestComplete:(void(^)(LZCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lZtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LZCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
