//
//  LZBuyChannelIPCheckSessionManager.h
//  LZCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LZCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(LZBuyChannelIPCheckSessionManager*)lZsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LZBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)lZstartAsyncRequestComplete:(void(^)(LZCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
