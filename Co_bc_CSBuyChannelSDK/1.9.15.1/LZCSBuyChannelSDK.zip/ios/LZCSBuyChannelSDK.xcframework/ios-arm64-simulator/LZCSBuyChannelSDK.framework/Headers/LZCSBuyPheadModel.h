//
//  LZCSBuyPheadModel.h
//  LZCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZCSBuyPheadModel : NSObject

+ (NSDictionary *)lZgetPheadWithAppleID:(NSString *)appID;

@end

NS_ASSUME_NONNULL_END
