//
//  STBuyChannelIPCheckSessionManager.h
//  STCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "STCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(STBuyChannelIPCheckSessionManager*)sTsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(STBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)sTstartAsyncRequestComplete:(void(^)(STCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
