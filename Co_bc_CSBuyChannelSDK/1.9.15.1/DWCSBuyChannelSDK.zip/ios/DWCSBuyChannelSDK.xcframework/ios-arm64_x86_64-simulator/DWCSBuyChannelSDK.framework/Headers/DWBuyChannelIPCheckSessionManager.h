//
//  DWBuyChannelIPCheckSessionManager.h
//  DWCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DWCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DWBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(DWBuyChannelIPCheckSessionManager*)dWsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(DWBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)dWstartAsyncRequestComplete:(void(^)(DWCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
