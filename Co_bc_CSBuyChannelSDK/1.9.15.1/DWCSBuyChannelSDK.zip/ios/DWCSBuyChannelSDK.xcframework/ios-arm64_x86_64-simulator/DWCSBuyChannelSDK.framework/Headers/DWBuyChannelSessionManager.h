//
//  DWBuyChannelSessionManager.h
//  DWCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DWCSBuyChannelHTTPResponse.h"
#import "DWBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface DWBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(DWBuyChannelSessionManager*)dWsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(DWBuyChannelSessionManager*)getBuySessionManager;

-(void)dWstartAsyncRequestComplete:(void(^)(DWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)dWtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(DWCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
