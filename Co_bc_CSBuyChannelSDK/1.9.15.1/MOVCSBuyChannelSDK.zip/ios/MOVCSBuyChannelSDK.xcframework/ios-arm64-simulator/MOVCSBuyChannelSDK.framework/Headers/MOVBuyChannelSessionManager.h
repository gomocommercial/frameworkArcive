//
//  MOVBuyChannelSessionManager.h
//  MOVCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MOVCSBuyChannelHTTPResponse.h"
#import "MOVBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface MOVBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(MOVBuyChannelSessionManager*)mOVsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(MOVBuyChannelSessionManager*)getBuySessionManager;

-(void)mOVstartAsyncRequestComplete:(void(^)(MOVCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)mOVtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(MOVCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
