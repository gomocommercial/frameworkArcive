//
//  MOVBuyChannelIPCheckSessionManager.h
//  MOVCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "MOVCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MOVBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(MOVBuyChannelIPCheckSessionManager*)mOVsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(MOVBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)mOVstartAsyncRequestComplete:(void(^)(MOVCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
