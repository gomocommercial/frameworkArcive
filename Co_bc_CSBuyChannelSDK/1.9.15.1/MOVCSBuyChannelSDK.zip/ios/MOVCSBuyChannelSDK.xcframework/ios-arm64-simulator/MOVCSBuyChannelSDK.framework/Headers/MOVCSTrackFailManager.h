//
//  MOVCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "MOVCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MOVCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)mOVsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(MOVCSTrackFailModel*)mOVunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)mOVdelSerializedBean:(MOVCSTrackFailModel*)bean;
//+(NSArray <MOVCSTrackFailModel *>*)mOVgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)mOVretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
