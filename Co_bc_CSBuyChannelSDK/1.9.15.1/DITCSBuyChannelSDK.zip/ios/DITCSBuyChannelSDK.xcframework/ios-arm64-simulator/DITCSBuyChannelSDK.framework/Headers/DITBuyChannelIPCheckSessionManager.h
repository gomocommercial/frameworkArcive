//
//  DITBuyChannelIPCheckSessionManager.h
//  DITCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DITCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DITBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(DITBuyChannelIPCheckSessionManager*)dITsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(DITBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)dITstartAsyncRequestComplete:(void(^)(DITCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
