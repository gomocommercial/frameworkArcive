//
//  DITCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "DITCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DITCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)dITsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(DITCSTrackFailModel*)dITunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)dITdelSerializedBean:(DITCSTrackFailModel*)bean;
//+(NSArray <DITCSTrackFailModel *>*)dITgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)dITretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
