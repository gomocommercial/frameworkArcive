//
//  DITBuyChannelSessionManager.h
//  DITCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DITCSBuyChannelHTTPResponse.h"
#import "DITBuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface DITBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(DITBuyChannelSessionManager*)dITsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(DITBuyChannelSessionManager*)getBuySessionManager;

-(void)dITstartAsyncRequestComplete:(void(^)(DITCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)dITtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(DITCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
