//
// Created by Kevin Guo on 2024/9/19.
//

#import <Foundation/Foundation.h>


@interface MLCBuyChannelAFAPISessionManager : NSObject
+(void)mLCstartGetGcdDataWithAppId:(NSString *)appId devKey:(NSString *)devkey retryCount:(NSInteger)retryCount complete:(void(^)(NSDictionary *gcdData, NSError *error))complete;
@end