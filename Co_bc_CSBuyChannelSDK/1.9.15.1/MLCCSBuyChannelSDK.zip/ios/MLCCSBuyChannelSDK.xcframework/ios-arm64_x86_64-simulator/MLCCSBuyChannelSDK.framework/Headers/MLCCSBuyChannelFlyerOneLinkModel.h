//
//  MLCCSBuyChannelFlyerOneLinkModel.h
//  MLCCSBuyChannelSDK
//
//  Created by zhangxin on 2024/3/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/**
 appsflyer onelink的didResolveDeepLink回调信息
 {
     "af_sub1" = "";
     "af_sub2" = "";
     "af_sub3" = "";
     "af_sub4" = "";
     "af_sub5" = "";
     campaign = "";
     "campaign_id" = "";
     "click_http_referrer" = "";
     "deep_link_sub1" = vx101;
     "deep_link_value" = vx100;
     "match_type" = probabilistic;
     "media_source" = "";
 */
@interface MLCCSBuyChannelFlyerOneLinkModel : NSObject
@property (nonatomic, copy) NSString *af_sub1;
@property (nonatomic, copy) NSString *af_sub2;
@property (nonatomic, copy) NSString *af_sub3;
@property (nonatomic, copy) NSString *af_sub4;
@property (nonatomic, copy) NSString *af_sub5;
@property (nonatomic, copy) NSString *campaign;
@property (nonatomic, copy) NSString *campaign_id;
@property (nonatomic, copy) NSString *deep_link_sub1;
@property (nonatomic, copy) NSString *deep_link_value;
@property (nonatomic, copy) NSString *match_type;
@property (nonatomic, copy) NSString *media_source;
@end

NS_ASSUME_NONNULL_END
