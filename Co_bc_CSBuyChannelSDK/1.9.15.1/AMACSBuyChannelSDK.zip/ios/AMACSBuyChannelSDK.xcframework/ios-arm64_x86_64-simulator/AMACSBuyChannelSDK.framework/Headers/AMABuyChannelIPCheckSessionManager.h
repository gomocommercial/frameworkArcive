//
//  AMABuyChannelIPCheckSessionManager.h
//  AMACSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "AMACSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AMABuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(AMABuyChannelIPCheckSessionManager*)aMAsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(AMABuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)aMAstartAsyncRequestComplete:(void(^)(AMACSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
