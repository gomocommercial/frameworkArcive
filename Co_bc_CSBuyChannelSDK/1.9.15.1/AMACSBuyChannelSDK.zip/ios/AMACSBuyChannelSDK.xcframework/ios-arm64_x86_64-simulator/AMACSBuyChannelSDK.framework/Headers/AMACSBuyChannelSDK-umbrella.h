#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "AMABuyChannelAFAPISessionManager.h"
#import "AMABuyChannelFBSessionManager.h"
#import "AMABuyChannelIPCheckSessionManager.h"
#import "AMABuyChannelNetworkTools.h"
#import "AMABuyChannelSessionManager.h"
#import "AMABuyChannelWebEvent.h"
#import "AMACSBuyChannel.h"
#import "AMACSBuyChannelFlyerModel.h"
#import "AMACSBuyChannelFlyerOneLinkModel.h"
#import "AMACSBuyChannelHTTPResponse.h"
#import "AMACSBuyChannelInitParams.h"
#import "AMACSBuyChannelRequestSerializer.h"
#import "AMACSBuyChannelSecureManager.h"
#import "AMACSBuyPheadModel.h"
#import "AMACSCustomPostData.h"
#import "AMACSTrackFailManager.h"
#import "AMACSTrackFailModel.h"
#import "NSString+AMACSBuyChannelSecure.h"
#import "AMABuyChannelAFAPISessionManager.h"
#import "AMABuyChannelFBSessionManager.h"
#import "AMABuyChannelIPCheckSessionManager.h"
#import "AMABuyChannelNetworkTools.h"
#import "AMABuyChannelSessionManager.h"
#import "AMABuyChannelWebEvent.h"
#import "AMACSBuyChannel.h"
#import "AMACSBuyChannelFlyerModel.h"
#import "AMACSBuyChannelFlyerOneLinkModel.h"
#import "AMACSBuyChannelHTTPResponse.h"
#import "AMACSBuyChannelInitParams.h"
#import "AMACSBuyChannelRequestSerializer.h"
#import "AMACSBuyChannelSecureManager.h"
#import "AMACSBuyPheadModel.h"
#import "AMACSCustomPostData.h"
#import "AMACSTrackFailManager.h"
#import "AMACSTrackFailModel.h"
#import "NSString+AMACSBuyChannelSecure.h"

FOUNDATION_EXPORT double AMACSBuyChannelSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char AMACSBuyChannelSDKVersionString[];

