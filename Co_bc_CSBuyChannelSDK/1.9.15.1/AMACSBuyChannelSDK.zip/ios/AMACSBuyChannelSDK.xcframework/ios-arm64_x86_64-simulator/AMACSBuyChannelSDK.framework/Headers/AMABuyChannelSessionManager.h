//
//  AMABuyChannelSessionManager.h
//  AMACSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "AMACSBuyChannelHTTPResponse.h"
#import "AMABuyChannelWebEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface AMABuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(AMABuyChannelSessionManager*)aMAsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey enableIPv6:(BOOL)enableIPv6 geoipAPIURL:(NSString *)geoipAPIURL;

+(AMABuyChannelSessionManager*)getBuySessionManager;

-(void)aMAstartAsyncRequestComplete:(void(^)(AMACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)aMAtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(AMACSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
