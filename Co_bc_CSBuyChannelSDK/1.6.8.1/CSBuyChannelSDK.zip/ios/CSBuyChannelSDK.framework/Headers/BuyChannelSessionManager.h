//
//  BuyChannelSessionManager.h
//  CSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface BuyChannelSessionManager : AFHTTPSessionManager

@property (nonatomic, copy) NSString *desKey;

+(BuyChannelSessionManager*)sharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;
+(BuyChannelSessionManager*)getBuySessionManager;
-(void)startAsyncRequestComplete:(void(^)(CSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;
-(void)trackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(CSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
