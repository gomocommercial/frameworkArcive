//
//  VEBuyChannelIPCheckSessionManager.h
//  VECSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "VECSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface VEBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(VEBuyChannelIPCheckSessionManager*)vEsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(VEBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)vEstartAsyncRequestComplete:(void(^)(VECSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
