//
//  SVBuyChannelSessionManager.h
//  SVCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "SVCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface SVBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(SVBuyChannelSessionManager*)sVsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(SVBuyChannelSessionManager*)getBuySessionManager;

-(void)sVstartAsyncRequestComplete:(void(^)(SVCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)sVtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(SVCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
