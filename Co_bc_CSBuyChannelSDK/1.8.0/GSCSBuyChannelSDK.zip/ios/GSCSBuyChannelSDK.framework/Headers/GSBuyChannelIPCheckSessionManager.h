//
//  GSBuyChannelIPCheckSessionManager.h
//  GSCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "GSCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface GSBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(GSBuyChannelIPCheckSessionManager*)gSsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(GSBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)gSstartAsyncRequestComplete:(void(^)(GSCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
