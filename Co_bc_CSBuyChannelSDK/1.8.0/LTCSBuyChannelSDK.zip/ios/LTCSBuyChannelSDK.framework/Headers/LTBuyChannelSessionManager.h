//
//  LTBuyChannelSessionManager.h
//  LTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "LTCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface LTBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(LTBuyChannelSessionManager*)lTsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(LTBuyChannelSessionManager*)getBuySessionManager;

-(void)lTstartAsyncRequestComplete:(void(^)(LTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)lTtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(LTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
