//
//  LTCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "LTCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LTCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)lTsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(LTCSTrackFailModel*)lTunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)lTdelSerializedBean:(LTCSTrackFailModel*)bean;
//+(NSArray <LTCSTrackFailModel *>*)lTgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)lTretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
