//
//  CPBuyChannelIPCheckSessionManager.h
//  CPCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "CPCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CPBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(CPBuyChannelIPCheckSessionManager*)cPsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(CPBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)cPstartAsyncRequestComplete:(void(^)(CPCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
