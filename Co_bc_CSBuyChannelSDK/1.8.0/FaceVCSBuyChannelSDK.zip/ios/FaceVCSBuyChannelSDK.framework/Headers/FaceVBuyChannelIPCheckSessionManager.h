//
//  FaceVBuyChannelIPCheckSessionManager.h
//  FaceVCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "FaceVCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FaceVBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(FaceVBuyChannelIPCheckSessionManager*)faceVsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(FaceVBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)faceVstartAsyncRequestComplete:(void(^)(FaceVCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
