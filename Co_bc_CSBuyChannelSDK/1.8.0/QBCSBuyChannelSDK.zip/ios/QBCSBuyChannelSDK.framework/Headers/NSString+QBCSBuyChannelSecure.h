//
//  NSString+QBCSBuyChannelSecure.h
//  QBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (QBCSBuyChannelSecure)

+(NSString *)qBbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)qBbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
