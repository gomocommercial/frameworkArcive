//
//  QBBuyChannelSessionManager.h
//  QBCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "QBCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface QBBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(QBBuyChannelSessionManager*)qBsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(QBBuyChannelSessionManager*)getBuySessionManager;

-(void)qBstartAsyncRequestComplete:(void(^)(QBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)qBtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(QBCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
