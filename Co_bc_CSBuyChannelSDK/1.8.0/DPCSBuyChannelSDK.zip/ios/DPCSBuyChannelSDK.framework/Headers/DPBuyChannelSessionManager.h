//
//  DPBuyChannelSessionManager.h
//  DPCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "DPCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface DPBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(DPBuyChannelSessionManager*)dPsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(DPBuyChannelSessionManager*)getBuySessionManager;

-(void)dPstartAsyncRequestComplete:(void(^)(DPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)dPtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(DPCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
