//
//  NSString+QTCSBuyChannelSecure.h
//  QTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/3.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (QTCSBuyChannelSecure)

+(NSString *)qTbuyChannelSecureHmacSHA256AndSafeUrlBase64EncodeWithKey:(NSString *)key value:(NSString *)value;

- (BOOL)qTbuyChannelIsEmpty;
@end

NS_ASSUME_NONNULL_END
