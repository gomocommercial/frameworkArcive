//
//  QTBuyChannelSessionManager.h
//  QTCSBuyChannelSDK
//
//  Created by qiaoming on 2020/3/4.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "QTCSBuyChannelHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface QTBuyChannelSessionManager : AFHTTPSessionManager
@property (nonatomic, copy, readonly) NSString *desKey;

+(QTBuyChannelSessionManager*)qTsharedBuyChannelSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(QTBuyChannelSessionManager*)getBuySessionManager;

-(void)qTstartAsyncRequestComplete:(void(^)(QTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

-(void)qTtrackEventRequest:(NSString *)event withValues:(NSDictionary *)values eventTime:(NSString*)eventTime uuid:(NSString *)uuid Complete:(void(^)(QTCSBuyChannelHTTPResponse* buyChannelHTTPResponse))complete;

@end

NS_ASSUME_NONNULL_END
