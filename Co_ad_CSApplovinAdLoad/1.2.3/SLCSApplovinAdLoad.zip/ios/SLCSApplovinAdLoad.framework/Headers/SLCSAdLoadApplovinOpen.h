//
//  SLCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <SLCSAdSDK/SLCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadApplovinOpen : SLCSAdLoadOpen <SLCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
