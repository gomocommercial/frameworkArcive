//
//  TESTIOSCSAdLoadApplovinAdPlaceNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadNative.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadProtocol.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TESTIOSCSAdLoadApplovinAdPlaceNative : TESTIOSCSAdLoadNative<TESTIOSCSAdLoadProtocol,MAAdPlacerDelegate>

@property(nonatomic, strong) MATableViewAdPlacer *adTablePlacer;
@property(nonatomic, strong) MACollectionViewAdPlacer *adCollectionPlacer;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
