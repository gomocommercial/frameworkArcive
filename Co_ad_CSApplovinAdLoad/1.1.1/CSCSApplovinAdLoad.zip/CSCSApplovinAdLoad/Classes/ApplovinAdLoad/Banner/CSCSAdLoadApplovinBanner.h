//
//  CSCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <CSCSAdSDK/CSCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSCSAdLoadApplovinBanner : CSCSAdLoadBanner <CSCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
