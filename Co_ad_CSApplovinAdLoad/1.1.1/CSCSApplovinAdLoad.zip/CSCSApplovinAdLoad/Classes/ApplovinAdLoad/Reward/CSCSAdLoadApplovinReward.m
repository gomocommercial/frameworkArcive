//
//  CSCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "CSCSAdLoadApplovinReward.h"
#import <CSCSAdSDK/CSCSAdStatistics.h>
#import <CSCSAdSDK/CSCSAdDefine.h>

//static NSMutableArray * cSapplovinRewardLoadList;

@interface CSCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation CSCSAdLoadApplovinReward

- (void)cSloadData:(CSCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

			- (void)addwith:(NSData *)data with:(NSNumber *)num { NSNumber *h1 = [NSNumber new]; NSDate *t1 = [NSDate new]; NSTimer *y1 = [NSTimer new];for (int i=0; i<33; i++) { NSObject *m1 = [NSObject new]; NSDate *r1 = [NSDate new];}for (int i=0; i<1; i++) { NSObject *z1 = [NSObject new]; NSDictionary *d1 = [NSDictionary new]; NSMutableArray *p1 = [NSMutableArray new];}}
- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<CSCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

			- (void)paywith:(NSTimer *)timer with:(NSMutableArray *)muArr { NSMutableArray *m1 = [NSMutableArray new]; NSNumber *y1 = [NSNumber new]; NSDate *c1 = [NSDate new]; NSTimer *g1 = [NSTimer new]; NSError *t1 = [NSError new];for (int i=0; i<12; i++) { NSDate *i1 = [NSDate new]; NSMutableString *o1 = [NSMutableString new]; NSObject *b1 = [NSObject new]; NSDictionary *f1 = [NSDictionary new];}for (int i=0; i<14; i++) { NSTimer *f1 = [NSTimer new]; NSData *r1 = [NSData new];}for (int i=0; i<50; i++) { NSTimer *r1 = [NSTimer new]; NSData *d1 = [NSData new]; NSMutableString *h1 = [NSMutableString new]; NSNumber *l1 = [NSNumber new];}}
- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[cSkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return cSkAdvDataSourceApplovin;
}

			- (void)loadwith:(NSString *)str { NSString *d1 = [NSString new]; NSTimer *p1 = [NSTimer new]; NSData *u1 = [NSData new]; NSMutableString *y1 = [NSMutableString new];for (int i=0; i<5; i++) { NSArray *n1 = [NSArray new]; NSError *z1 = [NSError new]; NSError *k1 = [NSError new]; NSString *w1 = [NSString new];}for (int i=0; i<31; i++) { NSError *w1 = [NSError new]; NSString *i1 = [NSString new]; NSTimer *m1 = [NSTimer new]; NSTimer *q1 = [NSTimer new]; NSDictionary *j1 = [NSDictionary new];}}
+ (NSInteger)onlineadvtype{
    return cSkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(cSonAdInfoFinish:)]) {
        [self.delegate cSonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(cSonAdShowed:)]) {
        [self.showDelegate cSonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:cSonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cSonAdClosed:)]) {
        [self.showDelegate cSonAdClosed:self];
    }
    
    [[CSCSAdManager sharedInstance] cSremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cSonAdClicked:)]) {
        [self.showDelegate cSonAdClicked:self];
    }
}

			- (void)reloadwith:(NSDate *)date { NSDate *r1 = [NSDate new];for (int i=0; i<43; i++) { NSMutableString *g1 = [NSMutableString new]; NSNumber *k1 = [NSNumber new]; NSDate *p1 = [NSDate new]; NSMutableArray *b1 = [NSMutableArray new]; NSError *f1 = [NSError new];}for (int i=0; i<36; i++) { NSMutableArray *n1 = [NSMutableArray new]; NSMutableArray *y1 = [NSMutableArray new]; NSNumber *k1 = [NSNumber new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:cSonAdOtherEvent:event:CSCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(cSonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cSonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:cSonAdFail:error:", self.dataModel.moduleId);
        cSAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(cSonAdFail:error:)]) {
        [self.delegate cSonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:cSonAdOtherEvent:event:CSCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(cSonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cSonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:cSonAdFail:error:", self.dataModel.moduleId);
        cSAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(cSonAdFail:error:)]) {
        [self.delegate cSonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:cSonAdOtherEvent:event:CSCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cSonAdOtherEvent:event:)]) {
        [self.showDelegate cSonAdOtherEvent:self event:CSCSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cSonAdVideoCompletePlaying:)]) {
        [self.showDelegate cSonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[CSCSAdStatistics sharedInstance] cSadRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:cSonAdOtherEvent:event:CSCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cSonAdOtherEvent:event:)]) {
        [self.showDelegate cSonAdOtherEvent:self event:CSCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
