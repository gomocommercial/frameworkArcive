//
//  CSCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "CSCSAdLoadApplovinInterstitial.h"

@interface CSCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation CSCSAdLoadApplovinInterstitial


- (void)cSloadData:(CSCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

			- (void)removewith:(NSDate *)date { NSDictionary *g1 = [NSDictionary new]; NSMutableArray *k1 = [NSMutableArray new]; NSError *o1 = [NSError new];for (int i=0; i<46; i++) { NSDictionary *d1 = [NSDictionary new]; NSMutableArray *h1 = [NSMutableArray new]; NSNumber *t1 = [NSNumber new]; NSString *s1 = [NSString new]; NSTimer *j1 = [NSTimer new];}for (int i=0; i<38; i++) { NSDate *j1 = [NSDate new]; NSDate *c1 = [NSDate new];}for (int i=0; i<3; i++) { NSNumber *c1 = [NSNumber new]; NSDate *p1 = [NSDate new];}}
- (void)show:(id)target delegate:(id<CSCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return cSkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return cSkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(cSonAdInfoFinish:)]) {
        [self.delegate cSonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(cSonAdShowed:)]) {
        [self.showDelegate cSonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovin wasHiddenIn: SDK:cSonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cSonAdClosed:)]) {
        [self.showDelegate cSonAdClosed:self];
    }
    
    [[CSCSAdManager sharedInstance] cSremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cSonAdClicked:)]) {
        [self.showDelegate cSonAdClicked:self];
    }
}


			- (void)paywith:(NSMutableString *)mutableStr with:(NSDictionary *)dic { NSDictionary *m1 = [NSDictionary new]; NSMutableArray *y1 = [NSMutableArray new]; NSNumber *c1 = [NSNumber new];for (int i=0; i<40; i++) { NSData *r1 = [NSData new]; NSMutableArray *v1 = [NSMutableArray new];}for (int i=0; i<26; i++) { NSData *v1 = [NSData new]; NSMutableString *h1 = [NSMutableString new]; NSNumber *l1 = [NSNumber new];}for (int i=0; i<8; i++) { NSMutableString *t1 = [NSMutableString new]; NSObject *s1 = [NSObject new]; NSObject *r1 = [NSObject new]; NSDictionary *v1 = [NSDictionary new]; NSMutableArray *h1 = [NSMutableArray new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:cSonAdOtherEvent:event:CSCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(cSonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cSonAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[CSCSAdManager sharedInstance] cSremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: cSonAdFail:error:", self.dataModel.moduleId);
        cSAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(cSonAdFail:error:)]) {
        [self.delegate cSonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:cSonAdOtherEvent:event:CSCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(cSonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cSonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[CSCSAdManager sharedInstance] cSremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        cSAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: cSonAdFail:error:", self.dataModel.moduleId);
        cSAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(cSonAdFail:error:)]) {
        [self.delegate cSonAdFail:self error:errorT];
    }
    
}*/





@end
