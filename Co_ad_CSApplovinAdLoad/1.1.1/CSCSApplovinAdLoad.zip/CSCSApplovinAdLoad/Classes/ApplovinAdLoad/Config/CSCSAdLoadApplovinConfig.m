//
//  CSCSAdLoadApplovinConfig.m
//  CSCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "CSCSAdLoadApplovinConfig.h"
#import "CSCSApplovinConfigModel.h"
#import <CSCSAdSDK/CSCSAdDefine.h>
#import "CSCSAdLoadApplovinBanner.h"

@interface CSCSAdLoadApplovinConfig ()


@end

@implementation CSCSAdLoadApplovinConfig


			- (void)actionwith:(NSDate *)date with:(NSError *)err { NSError *v1 = [NSError new]; NSMutableString *a1 = [NSMutableString new]; NSTimer *m1 = [NSTimer new];for (int i=0; i<15; i++) { NSNumber *t1 = [NSNumber new]; NSDate *f1 = [NSDate new];}for (int i=0; i<2; i++) { NSNumber *f1 = [NSNumber new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[CSCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    CSCSApplovinConfigModel * model = [CSCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = cSkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[CSCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)addwith:(NSObject *)obj with:(NSArray *)arr { NSArray *t1 = [NSArray new]; NSError *g1 = [NSError new]; NSDate *k1 = [NSDate new]; NSTimer *o1 = [NSTimer new];for (int i=0; i<26; i++) { NSNumber *d1 = [NSNumber new]; NSDate *p1 = [NSDate new]; NSDate *a1 = [NSDate new]; NSArray *m1 = [NSArray new]; NSData *q1 = [NSData new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (CSCSApplovinConfigModel * model in [CSCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            model.rootViewController = nil;
            [model.banner.adView stopAutoRefresh];
            
            [[CSCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
