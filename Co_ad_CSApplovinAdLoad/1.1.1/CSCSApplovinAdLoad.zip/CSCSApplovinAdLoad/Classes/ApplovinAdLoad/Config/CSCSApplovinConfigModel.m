//
//  CSCSApplovinConfigModel.m
//  CSCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "CSCSApplovinConfigModel.h"

@implementation CSCSApplovinConfigModel

@end
