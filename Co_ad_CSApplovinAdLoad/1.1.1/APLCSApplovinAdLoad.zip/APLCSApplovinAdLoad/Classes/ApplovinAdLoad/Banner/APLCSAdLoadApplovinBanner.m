//
//  APLCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "APLCSAdLoadApplovinBanner.h"
#import "APLCSAdLoadApplovinConfig.h"

@interface APLCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation APLCSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] admob banner close SDK:aPLonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClosed:)]) {
        [self.showDelegate aPLonAdClosed:self];
    }
    
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return aPLkAdvDataSourceApplovin;
}


- (void)aPLloadData:(APLCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<APLCSApplovinConfigModel *> * configs = [APLCSAdLoadApplovinConfig sharedInstance].configs;
    APLCSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (APLCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [APLCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[APLCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            aPLAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return aPLkOnlineAdvTypeBanner;
}

			- (void)cancelwith:(NSDictionary *)dic { NSData *m1 = [NSData new]; NSMutableArray *q1 = [NSMutableArray new];for (int i=0; i<8; i++) { NSTimer *f1 = [NSTimer new]; NSData *r1 = [NSData new];}for (int i=0; i<26; i++) { NSArray *r1 = [NSArray new]; NSData *v1 = [NSData new]; NSMutableString *h1 = [NSMutableString new];}}
- (void)show:(id)traget delegate:(id<APLCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

			- (void)statuswith:(NSDate *)date with:(NSData *)data { NSData *d1 = [NSData new]; NSMutableString *h1 = [NSMutableString new]; NSObject *u1 = [NSObject new];for (int i=0; i<35; i++) { NSError *i1 = [NSError new]; NSMutableString *n1 = [NSMutableString new];}for (int i=0; i<21; i++) { NSError *n1 = [NSError new]; NSDate *z1 = [NSDate new]; NSDate *s1 = [NSDate new]; NSTimer *w1 = [NSTimer new]; NSData *a1 = [NSData new];}for (int i=0; i<43; i++) { NSArray *i1 = [NSArray new]; NSData *m1 = [NSData new]; NSMutableString *y1 = [NSMutableString new]; NSObject *c1 = [NSObject new]; NSObject *w1 = [NSObject new];}}
- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClicked:)]) {
        [self.showDelegate aPLonAdClicked:self];
    }
}


			- (void)loadwith:(NSData *)data with:(NSNumber *)num { NSNumber *n1 = [NSNumber new]; NSDate *s1 = [NSDate new]; NSMutableArray *e1 = [NSMutableArray new]; NSError *i1 = [NSError new]; NSString *u1 = [NSString new];for (int i=0; i<48; i++) { NSMutableArray *b1 = [NSMutableArray new]; NSData *j1 = [NSData new]; NSData *c1 = [NSData new]; NSMutableString *g1 = [NSMutableString new]; NSNumber *k1 = [NSNumber new];}for (int i=0; i<45; i++) { NSData *z1 = [NSData new]; NSMutableString *l1 = [NSMutableString new];}}
- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}

			- (void)resumewith:(NSArray *)arr { NSArray *h1 = [NSArray new]; NSError *t1 = [NSError new];for (int i=0; i<13; i++) { NSDictionary *i1 = [NSDictionary new]; NSMutableArray *m1 = [NSMutableArray new]; NSError *r1 = [NSError new]; NSDate *d1 = [NSDate new]; NSDate *w1 = [NSDate new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdInfoFinish:)]) {
        [self.delegate aPLonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;

    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate aPLonAdShowed:self];
    }
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasHiddenIn: SDK:aPLonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClosed:)]) {
        [self.showDelegate aPLonAdClosed:self];
    }
    
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
