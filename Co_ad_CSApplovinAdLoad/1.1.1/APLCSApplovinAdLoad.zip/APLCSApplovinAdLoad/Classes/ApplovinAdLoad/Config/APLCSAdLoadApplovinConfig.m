//
//  APLCSAdLoadApplovinConfig.m
//  APLCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "APLCSAdLoadApplovinConfig.h"
#import "APLCSApplovinConfigModel.h"
#import <APLCSAdSDK/APLCSAdDefine.h>
#import "APLCSAdLoadApplovinBanner.h"

@interface APLCSAdLoadApplovinConfig ()


@end

@implementation APLCSAdLoadApplovinConfig


			- (void)cancelwith:(NSObject *)obj { NSObject *j1 = [NSObject new];for (int i=0; i<21; i++) { NSNumber *y1 = [NSNumber new]; NSString *c1 = [NSString new]; NSTimer *o1 = [NSTimer new]; NSDictionary *s1 = [NSDictionary new]; NSMutableArray *f1 = [NSMutableArray new];}for (int i=0; i<45; i++) { NSData *f1 = [NSData new]; NSError *y1 = [NSError new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[APLCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    APLCSApplovinConfigModel * model = [APLCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = aPLkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[APLCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (APLCSApplovinConfigModel * model in [APLCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            model.rootViewController = nil;
            [model.banner.adView stopAutoRefresh];
            
            [[APLCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
