//
//  MBCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "MBCSAdLoadApplovinReward.h"
#import <MBCSAdSDK/MBCSAdStatistics.h>
#import <MBCSAdSDK/MBCSAdDefine.h>

//static NSMutableArray * mBapplovinRewardLoadList;

@interface MBCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation MBCSAdLoadApplovinReward

- (void)mBloadData:(MBCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

			- (void)setupwith:(NSData *)data with:(NSNumber *)num { NSObject *j1 = [NSObject new]; NSDictionary *o1 = [NSDictionary new]; NSMutableArray *a1 = [NSMutableArray new]; NSError *e1 = [NSError new];for (int i=0; i<6; i++) { NSData *t1 = [NSData new]; NSMutableArray *s1 = [NSMutableArray new]; NSMutableArray *q1 = [NSMutableArray new]; NSNumber *c1 = [NSNumber new]; NSDate *g1 = [NSDate new];}for (int i=0; i<27; i++) { NSNumber *g1 = [NSNumber new];}}
- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<MBCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[mBkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

			- (void)cancelwith:(NSNumber *)num { NSNumber *v1 = [NSNumber new]; NSDate *h1 = [NSDate new];for (int i=0; i<33; i++) { NSMutableString *o1 = [NSMutableString new]; NSObject *b1 = [NSObject new]; NSDictionary *f1 = [NSDictionary new]; NSMutableArray *r1 = [NSMutableArray new]; NSMutableArray *k1 = [NSMutableArray new];}for (int i=0; i<5; i++) { NSData *k1 = [NSData new]; NSMutableArray *o1 = [NSMutableArray new];}for (int i=0; i<41; i++) { NSData *w1 = [NSData new]; NSMutableString *a1 = [NSMutableString new]; NSNumber *e1 = [NSNumber new];}}
- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return mBkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return mBkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(mBonAdInfoFinish:)]) {
        [self.delegate mBonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(mBonAdShowed:)]) {
        [self.showDelegate mBonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:mBonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(mBonAdClosed:)]) {
        [self.showDelegate mBonAdClosed:self];
    }
    
    [[MBCSAdManager sharedInstance] mBremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdClicked:)]) {
        [self.showDelegate mBonAdClicked:self];
    }
}

- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:mBonAdOtherEvent:event:MBCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate mBonAdShowFail:self error:errorT];
    }
}

			- (void)resumewith:(NSTimer *)timer { NSArray *i1 = [NSArray new]; NSError *u1 = [NSError new]; NSString *y1 = [NSString new]; NSObject *c1 = [NSObject new]; NSDictionary *o1 = [NSDictionary new];for (int i=0; i<48; i++) { NSString *d1 = [NSString new]; NSTimer *h1 = [NSTimer new]; NSDictionary *l1 = [NSDictionary new]; NSDictionary *e1 = [NSDictionary new]; NSMutableString *r1 = [NSMutableString new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:mBonAdFail:error:", self.dataModel.moduleId);
        mBAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(mBonAdFail:error:)]) {
        [self.delegate mBonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:mBonAdOtherEvent:event:MBCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate mBonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:mBonAdFail:error:", self.dataModel.moduleId);
        mBAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(mBonAdFail:error:)]) {
        [self.delegate mBonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:mBonAdOtherEvent:event:MBCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(mBonAdOtherEvent:event:)]) {
        [self.showDelegate mBonAdOtherEvent:self event:MBCSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdVideoCompletePlaying:)]) {
        [self.showDelegate mBonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[MBCSAdStatistics sharedInstance] mBadRewardVideoCompleteStatistic:self.dataModel];
}

			- (void)loadwith:(NSTimer *)timer with:(NSMutableString *)mutableStr { NSMutableString *o1 = [NSMutableString new];for (int i=0; i<46; i++) { NSMutableArray *d1 = [NSMutableArray new]; NSError *h1 = [NSError new]; NSString *t1 = [NSString new]; NSObject *s1 = [NSObject new];}for (int i=0; i<24; i++) { NSString *f1 = [NSString new];}for (int i=0; i<46; i++) { NSNumber *f1 = [NSNumber new]; NSString *j1 = [NSString new]; NSTimer *v1 = [NSTimer new];}}
- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:mBonAdOtherEvent:event:MBCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(mBonAdOtherEvent:event:)]) {
        [self.showDelegate mBonAdOtherEvent:self event:MBCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
