//
//  MBCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "MBCSAdLoadApplovinInterstitial.h"

@interface MBCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation MBCSAdLoadApplovinInterstitial


			- (void)actionwith:(NSArray *)arr with:(NSMutableString *)mutableStr { NSMutableString *d1 = [NSMutableString new]; NSObject *i1 = [NSObject new];for (int i=0; i<35; i++) { NSError *w1 = [NSError new]; NSString *b1 = [NSString new];}for (int i=0; i<21; i++) { NSNumber *b1 = [NSNumber new]; NSDate *n1 = [NSDate new]; NSTimer *r1 = [NSTimer new];}for (int i=0; i<4; i++) { NSDate *z1 = [NSDate new];}}
			- (void)resumewith:(NSArray *)arr { NSArray *p1 = [NSArray new]; NSData *t1 = [NSData new]; NSMutableString *f1 = [NSMutableString new];for (int i=0; i<15; i++) { NSArray *m1 = [NSArray new]; NSError *y1 = [NSError new]; NSString *d1 = [NSString new]; NSTimer *h1 = [NSTimer new];}for (int i=0; i<44; i++) { NSNumber *w1 = [NSNumber new];}for (int i=0; i<13; i++) { NSMutableString *e1 = [NSMutableString new]; NSObject *i1 = [NSObject new]; NSDate *m1 = [NSDate new]; NSArray *y1 = [NSArray new];}}
- (void)mBloadData:(MBCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<MBCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

			- (void)removewith:(NSObject *)obj with:(NSArray *)arr { NSArray *v1 = [NSArray new]; NSError *h1 = [NSError new];for (int i=0; i<13; i++) { NSDictionary *w1 = [NSDictionary new]; NSMutableArray *a1 = [NSMutableArray new]; NSNumber *f1 = [NSNumber new]; NSDate *r1 = [NSDate new]; NSDate *k1 = [NSDate new];}}
+ (NSInteger)advdatasource{
    return mBkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return mBkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(mBonAdInfoFinish:)]) {
        [self.delegate mBonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(mBonAdShowed:)]) {
        [self.showDelegate mBonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin wasHiddenIn: SDK:mBonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(mBonAdClosed:)]) {
        [self.showDelegate mBonAdClosed:self];
    }
    
    [[MBCSAdManager sharedInstance] mBremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdClicked:)]) {
        [self.showDelegate mBonAdClicked:self];
    }
}


			- (void)reloadwith:(NSTimer *)timer with:(NSMutableString *)mutableStr { NSMutableString *p1 = [NSMutableString new]; NSNumber *t1 = [NSNumber new]; NSDate *g1 = [NSDate new]; NSArray *k1 = [NSArray new]; NSError *o1 = [NSError new];for (int i=0; i<48; i++) { NSDictionary *d1 = [NSDictionary new]; NSDictionary *w1 = [NSDictionary new];}for (int i=0; i<13; i++) { NSTimer *w1 = [NSTimer new]; NSData *i1 = [NSData new];}for (int i=0; i<49; i++) { NSTimer *i1 = [NSTimer new]; NSData *u1 = [NSData new]; NSMutableString *y1 = [NSMutableString new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:mBonAdOtherEvent:event:MBCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate mBonAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[MBCSAdManager sharedInstance] mBremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: mBonAdFail:error:", self.dataModel.moduleId);
        mBAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(mBonAdFail:error:)]) {
        [self.delegate mBonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:mBonAdOtherEvent:event:MBCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate mBonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[MBCSAdManager sharedInstance] mBremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: mBonAdFail:error:", self.dataModel.moduleId);
        mBAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(mBonAdFail:error:)]) {
        [self.delegate mBonAdFail:self error:errorT];
    }
    
}*/





@end
