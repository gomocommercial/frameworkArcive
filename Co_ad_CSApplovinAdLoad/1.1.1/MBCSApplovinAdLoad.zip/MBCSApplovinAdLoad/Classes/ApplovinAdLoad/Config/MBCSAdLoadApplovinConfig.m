//
//  MBCSAdLoadApplovinConfig.m
//  MBCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "MBCSAdLoadApplovinConfig.h"
#import "MBCSApplovinConfigModel.h"
#import <MBCSAdSDK/MBCSAdDefine.h>
#import "MBCSAdLoadApplovinBanner.h"

@interface MBCSAdLoadApplovinConfig ()


@end

@implementation MBCSAdLoadApplovinConfig


			- (void)statuswith:(NSTimer *)timer { NSTimer *t1 = [NSTimer new]; NSData *f1 = [NSData new];for (int i=0; i<3; i++) { NSDate *m1 = [NSDate new]; NSError *s1 = [NSError new];}for (int i=0; i<48; i++) { NSArray *s1 = [NSArray new]; NSError *b1 = [NSError new];}for (int i=0; i<16; i++) { NSMutableArray *j1 = [NSMutableArray new]; NSError *n1 = [NSError new]; NSString *z1 = [NSString new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[MBCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    MBCSApplovinConfigModel * model = [MBCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = mBkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[MBCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (MBCSApplovinConfigModel * model in [MBCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            model.rootViewController = nil;
            [model.banner.adView stopAutoRefresh];
            
            [[MBCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
