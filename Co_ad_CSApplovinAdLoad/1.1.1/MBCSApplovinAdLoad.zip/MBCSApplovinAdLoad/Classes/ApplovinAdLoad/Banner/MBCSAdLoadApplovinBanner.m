//
//  MBCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "MBCSAdLoadApplovinBanner.h"
#import "MBCSAdLoadApplovinConfig.h"

@interface MBCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation MBCSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        mBAdLog(@"[%ld] admob banner close SDK:mBonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(mBonAdClosed:)]) {
        [self.showDelegate mBonAdClosed:self];
    }
    
    [[MBCSAdManager sharedInstance] mBremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

			- (void)actionwith:(NSDictionary *)dic { NSData *m1 = [NSData new]; NSMutableString *y1 = [NSMutableString new];for (int i=0; i<33; i++) { NSArray *f1 = [NSArray new]; NSDate *z1 = [NSDate new];}for (int i=0; i<40; i++) { NSObject *h1 = [NSObject new]; NSDate *l1 = [NSDate new];}}
- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return mBkAdvDataSourceApplovin;
}


- (void)mBloadData:(MBCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<MBCSApplovinConfigModel *> * configs = [MBCSAdLoadApplovinConfig sharedInstance].configs;
    MBCSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (MBCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [MBCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[MBCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            mBAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return mBkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<MBCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdClicked:)]) {
        [self.showDelegate mBonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:mBonAdOtherEvent:event:MBCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate mBonAdShowFail:self error:errorT];
    }
}

			- (void)cancelwith:(NSDictionary *)dic with:(NSError *)err { NSNumber *o1 = [NSNumber new]; NSDate *s1 = [NSDate new]; NSTimer *w1 = [NSTimer new]; NSData *i1 = [NSData new];for (int i=0; i<8; i++) { NSObject *e1 = [NSObject new]; NSError *t1 = [NSError new]; NSError *m1 = [NSError new]; NSMutableString *q1 = [NSMutableString new]; NSString *j1 = [NSString new];}for (int i=0; i<28; i++) { NSError *j1 = [NSError new]; NSString *v1 = [NSString new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[MBCSAdManager sharedInstance] mBremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: mBonAdFail:error:", self.dataModel.moduleId);
        mBAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(mBonAdFail:error:)]) {
        [self.delegate mBonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:mBonAdOtherEvent:event:MBCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(mBonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate mBonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[MBCSAdManager sharedInstance] mBremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: mBonAdFail:error:", self.dataModel.moduleId);
        mBAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(mBonAdFail:error:)]) {
        [self.delegate mBonAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(mBonAdInfoFinish:)]) {
        [self.delegate mBonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;

    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(mBonAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate mBonAdShowed:self];
    }
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        mBAdLog(@"[%ld] applovin wasHiddenIn: SDK:mBonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(mBonAdClosed:)]) {
        [self.showDelegate mBonAdClosed:self];
    }
    
    [[MBCSAdManager sharedInstance] mBremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

			- (void)loadwith:(NSString *)str { NSString *p1 = [NSString new]; NSObject *t1 = [NSObject new]; NSDictionary *f1 = [NSDictionary new];for (int i=0; i<25; i++) { NSString *m1 = [NSString new]; NSTimer *y1 = [NSTimer new]; NSData *q1 = [NSData new]; NSDate *s1 = [NSDate new];}for (int i=0; i<28; i++) { NSDate *j1 = [NSDate new]; NSArray *n1 = [NSArray new];}for (int i=0; i<46; i++) { NSDictionary *v1 = [NSDictionary new]; NSArray *z1 = [NSArray new]; NSNumber *m1 = [NSNumber new];}}
- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
