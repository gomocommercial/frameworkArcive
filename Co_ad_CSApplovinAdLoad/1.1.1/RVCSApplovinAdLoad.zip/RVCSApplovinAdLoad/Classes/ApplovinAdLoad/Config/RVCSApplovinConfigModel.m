//
//  RVCSApplovinConfigModel.m
//  RVCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "RVCSApplovinConfigModel.h"

@implementation RVCSApplovinConfigModel

@end
