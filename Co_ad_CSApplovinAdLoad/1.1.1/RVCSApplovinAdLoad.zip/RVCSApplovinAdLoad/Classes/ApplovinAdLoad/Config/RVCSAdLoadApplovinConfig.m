//
//  RVCSAdLoadApplovinConfig.m
//  RVCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "RVCSAdLoadApplovinConfig.h"
#import "RVCSApplovinConfigModel.h"
#import <RVCSAdSDK/RVCSAdDefine.h>
#import "RVCSAdLoadApplovinBanner.h"

@interface RVCSAdLoadApplovinConfig ()


@end

@implementation RVCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)cancelwith:(NSNumber *)num { NSNumber *j1 = [NSNumber new]; NSDate *v1 = [NSDate new];for (int i=0; i<35; i++) { NSMutableString *k1 = [NSMutableString new]; NSNumber *o1 = [NSNumber new];}for (int i=0; i<21; i++) { NSMutableString *o1 = [NSMutableString new]; NSObject *a1 = [NSObject new]; NSDate *e1 = [NSDate new]; NSMutableArray *r1 = [NSMutableArray new]; NSMutableArray *c1 = [NSMutableArray new];}for (int i=0; i<43; i++) { NSData *k1 = [NSData new]; NSMutableArray *o1 = [NSMutableArray new]; NSNumber *a1 = [NSNumber new]; NSDate *e1 = [NSDate new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[RVCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    RVCSApplovinConfigModel * model = [RVCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = rVkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[RVCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (RVCSApplovinConfigModel * model in [RVCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            model.rootViewController = nil;
            [model.banner.adView stopAutoRefresh];
            
            [[RVCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
