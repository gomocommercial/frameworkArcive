//
//  WACSAdLoadApplovinConfig.m
//  WACSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "WACSAdLoadApplovinConfig.h"
#import "WACSApplovinConfigModel.h"
#import <WACSAdSDK/WACSAdDefine.h>
#import "WACSAdLoadApplovinBanner.h"

@interface WACSAdLoadApplovinConfig ()


@end

@implementation WACSAdLoadApplovinConfig


			- (void)notificaitonwith:(NSArray *)arr { NSArray *p1 = [NSArray new];for (int i=0; i<23; i++) { NSObject *e1 = [NSObject new]; NSDictionary *i1 = [NSDictionary new]; NSMutableArray *n1 = [NSMutableArray new]; NSNumber *z1 = [NSNumber new]; NSString *d1 = [NSString new];}for (int i=0; i<16; i++) { NSNumber *l1 = [NSNumber new]; NSNumber *w1 = [NSNumber new]; NSDate *i1 = [NSDate new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[WACSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)paywith:(NSTimer *)timer { NSTimer *b1 = [NSTimer new]; NSData *n1 = [NSData new]; NSMutableString *s1 = [NSMutableString new]; NSObject *w1 = [NSObject new];for (int i=0; i<35; i++) { NSError *l1 = [NSError new]; NSNumber *e1 = [NSNumber new]; NSString *i1 = [NSString new]; NSTimer *u1 = [NSTimer new];}for (int i=0; i<11; i++) { NSString *u1 = [NSString new]; NSTimer *y1 = [NSTimer new]; NSData *k1 = [NSData new]; NSMutableArray *o1 = [NSMutableArray new]; NSMutableArray *h1 = [NSMutableArray new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    WACSApplovinConfigModel * model = [WACSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = wAkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[WACSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (WACSApplovinConfigModel * model in [WACSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            model.rootViewController = nil;
            [model.banner.adView stopAutoRefresh];
            
            [[WACSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
