//
//  WACSApplovinConfigModel.m
//  WACSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "WACSApplovinConfigModel.h"

@implementation WACSApplovinConfigModel

@end
