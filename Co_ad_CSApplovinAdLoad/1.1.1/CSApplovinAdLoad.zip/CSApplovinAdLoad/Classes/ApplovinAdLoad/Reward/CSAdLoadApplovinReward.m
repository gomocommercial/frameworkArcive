//
//  CSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "CSAdLoadApplovinReward.h"
#import <CSAdSDK/CSAdStatistics.h>
#import <CSAdSDK/CSAdDefine.h>

//static NSMutableArray * applovinRewardLoadList;

@interface CSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation CSAdLoadApplovinReward

- (void)loadData:(CSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<CSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

			- (void)reloadwith:(NSObject *)obj { NSObject *f1 = [NSObject new]; NSDate *j1 = [NSDate new];for (int i=0; i<43; i++) { NSString *y1 = [NSString new]; NSObject *c1 = [NSObject new];}for (int i=0; i<11; i++) { NSString *k1 = [NSString new]; NSObject *o1 = [NSObject new]; NSDictionary *a1 = [NSDictionary new];}for (int i=0; i<43; i++) { NSTimer *a1 = [NSTimer new]; NSTimer *t1 = [NSTimer new]; NSData *y1 = [NSData new]; NSMutableString *k1 = [NSMutableString new]; NSObject *o1 = [NSObject new];}}
- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[kCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

			- (void)statuswith:(NSData *)data { NSData *b1 = [NSData new]; NSMutableArray *f1 = [NSMutableArray new]; NSNumber *r1 = [NSNumber new]; NSDate *v1 = [NSDate new]; NSArray *a1 = [NSArray new];for (int i=0; i<17; i++) { NSNumber *p1 = [NSNumber new];}for (int i=0; i<39; i++) { NSMutableString *o1 = [NSMutableString new];}}
- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return kAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return kOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(onAdInfoFinish:)]) {
        [self.delegate onAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(onAdShowed:)]) {
        [self.showDelegate onAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward wasHiddenIn: SDK:onAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdClosed:)]) {
        [self.showDelegate onAdClosed:self];
    }
    
    [[CSAdManager sharedInstance] removeData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdClicked:)]) {
        [self.showDelegate onAdClicked:self];
    }
}

			- (void)resetwith:(NSError *)err { NSError *w1 = [NSError new]; NSString *a1 = [NSString new];for (int i=0; i<20; i++) { NSMutableArray *p1 = [NSMutableArray new]; NSError *t1 = [NSError new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:onAdOtherEvent:event:CSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdOtherEvent:event:)]) {
        [self.showDelegate onAdOtherEvent:self event:CSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdVideoCompletePlaying:)]) {
        [self.showDelegate onAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[CSAdStatistics sharedInstance] adRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:onAdOtherEvent:event:CSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdOtherEvent:event:)]) {
        [self.showDelegate onAdOtherEvent:self event:CSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
