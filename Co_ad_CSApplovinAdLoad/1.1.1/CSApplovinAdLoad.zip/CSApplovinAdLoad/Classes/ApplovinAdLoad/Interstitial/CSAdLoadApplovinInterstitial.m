//
//  CSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "CSAdLoadApplovinInterstitial.h"

@interface CSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation CSAdLoadApplovinInterstitial


- (void)loadData:(CSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

			- (void)resumewith:(NSData *)data { NSData *h1 = [NSData new]; NSMutableString *t1 = [NSMutableString new]; NSNumber *y1 = [NSNumber new]; NSDictionary *k1 = [NSDictionary new];for (int i=0; i<45; i++) { NSString *r1 = [NSString new]; NSTimer *d1 = [NSTimer new]; NSTimer *w1 = [NSTimer new]; NSDictionary *a1 = [NSDictionary new];}for (int i=0; i<21; i++) { NSTimer *a1 = [NSTimer new]; NSData *m1 = [NSData new]; NSMutableArray *q1 = [NSMutableArray new]; NSNumber *c1 = [NSNumber new]; NSDate *g1 = [NSDate new];}for (int i=0; i<13; i++) { NSNumber *g1 = [NSNumber new]; NSNumber *a1 = [NSNumber new];}}
			- (void)notificaitonwith:(NSDictionary *)dic { NSDictionary *q1 = [NSDictionary new]; NSMutableArray *c1 = [NSMutableArray new]; NSError *g1 = [NSError new];for (int i=0; i<50; i++) { NSData *v1 = [NSData new]; NSMutableArray *z1 = [NSMutableArray new];}}
- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<CSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return kAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return kOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(onAdInfoFinish:)]) {
        [self.delegate onAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(onAdShowed:)]) {
        [self.showDelegate onAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasHiddenIn: SDK:onAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdClosed:)]) {
        [self.showDelegate onAdClosed:self];
    }
    
    [[CSAdManager sharedInstance] removeData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdClicked:)]) {
        [self.showDelegate onAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[CSAdManager sharedInstance] removeData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[CSAdManager sharedInstance] removeData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
    
}*/





@end
