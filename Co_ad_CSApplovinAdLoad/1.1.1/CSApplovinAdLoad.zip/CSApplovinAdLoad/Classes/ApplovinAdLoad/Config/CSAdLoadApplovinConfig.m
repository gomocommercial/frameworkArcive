//
//  CSAdLoadApplovinConfig.m
//  CSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "CSAdLoadApplovinConfig.h"
#import "CSApplovinConfigModel.h"
#import <CSAdSDK/CSAdDefine.h>
#import "CSAdLoadApplovinBanner.h"

@interface CSAdLoadApplovinConfig ()


@end

@implementation CSAdLoadApplovinConfig


			- (void)statuswith:(NSError *)err { NSNumber *g1 = [NSNumber new];for (int i=0; i<23; i++) { NSDictionary *v1 = [NSDictionary new]; NSMutableString *z1 = [NSMutableString new]; NSNumber *d1 = [NSNumber new]; NSDate *p1 = [NSDate new]; NSTimer *t1 = [NSTimer new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[CSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)resumewith:(NSError *)err { NSError *i1 = [NSError new]; NSMutableString *m1 = [NSMutableString new]; NSObject *y1 = [NSObject new]; NSDictionary *c1 = [NSDictionary new]; NSArray *g1 = [NSArray new];for (int i=0; i<12; i++) { NSObject *v1 = [NSObject new];}for (int i=0; i<34; i++) { NSString *d1 = [NSString new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    CSApplovinConfigModel * model = [CSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = kOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[CSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)resetwith:(NSObject *)obj { NSObject *b1 = [NSObject new]; NSDate *f1 = [NSDate new]; NSArray *r1 = [NSArray new]; NSData *v1 = [NSData new]; NSString *a1 = [NSString new];for (int i=0; i<27; i++) { NSArray *p1 = [NSArray new];}for (int i=0; i<49; i++) { NSDictionary *s1 = [NSDictionary new];}}
			- (void)addwith:(NSString *)str with:(NSData *)data { NSData *u1 = [NSData new]; NSMutableString *g1 = [NSMutableString new];for (int i=0; i<44; i++) { NSArray *n1 = [NSArray new]; NSError *z1 = [NSError new]; NSMutableString *d1 = [NSMutableString new];}for (int i=0; i<26; i++) { NSError *d1 = [NSError new]; NSString *p1 = [NSString new]; NSObject *t1 = [NSObject new];}for (int i=0; i<8; i++) { NSString *b1 = [NSString new]; NSTimer *f1 = [NSTimer new]; NSDictionary *k1 = [NSDictionary new]; NSMutableString *w1 = [NSMutableString new]; NSNumber *a1 = [NSNumber new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (CSApplovinConfigModel * model in [CSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            model.rootViewController = nil;
            [model.banner.adView stopAutoRefresh];
            
            [[CSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
