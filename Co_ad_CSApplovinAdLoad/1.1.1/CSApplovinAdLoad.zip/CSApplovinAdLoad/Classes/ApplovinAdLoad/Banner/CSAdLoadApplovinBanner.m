//
//  CSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "CSAdLoadApplovinBanner.h"
#import "CSAdLoadApplovinConfig.h"

@interface CSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation CSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        AdLog(@"[%ld] admob banner close SDK:onAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdClosed:)]) {
        [self.showDelegate onAdClosed:self];
    }
    
    [[CSAdManager sharedInstance] removeData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

			- (void)resumewith:(NSArray *)arr with:(NSMutableString *)mutableStr { NSString *a1 = [NSString new];for (int i=0; i<23; i++) { NSArray *h1 = [NSArray new]; NSNumber *t1 = [NSNumber new];}for (int i=0; i<9; i++) { NSMutableArray *t1 = [NSMutableArray new]; NSNumber *f1 = [NSNumber new]; NSDate *j1 = [NSDate new];}for (int i=0; i<42; i++) { NSNumber *j1 = [NSNumber new];}}
- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

			- (void)removewith:(NSError *)err { NSNumber *s1 = [NSNumber new]; NSString *c1 = [NSString new]; NSArray *o1 = [NSArray new]; NSArray *h1 = [NSArray new]; NSError *l1 = [NSError new];for (int i=0; i<27; i++) { NSDictionary *a1 = [NSDictionary new]; NSArray *e1 = [NSArray new]; NSError *q1 = [NSError new]; NSString *u1 = [NSString new];}for (int i=0; i<23; i++) { NSError *u1 = [NSError new]; NSString *g1 = [NSString new];}for (int i=0; i<9; i++) { NSNumber *g1 = [NSNumber new]; NSString *k1 = [NSString new]; NSString *e1 = [NSString new];}}
+ (NSInteger)advdatasource {
    return kAdvDataSourceApplovin;
}


- (void)loadData:(CSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<CSApplovinConfigModel *> * configs = [CSAdLoadApplovinConfig sharedInstance].configs;
    CSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (CSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [CSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[CSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            AdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

			- (void)actionwith:(NSMutableArray *)muArr { NSMutableString *l1 = [NSMutableString new]; NSObject *q1 = [NSObject new]; NSDictionary *c1 = [NSDictionary new]; NSArray *g1 = [NSArray new];for (int i=0; i<36; i++) { NSTimer *v1 = [NSTimer new]; NSDictionary *z1 = [NSDictionary new]; NSDictionary *s1 = [NSDictionary new]; NSMutableArray *e1 = [NSMutableArray new]; NSNumber *i1 = [NSNumber new];}for (int i=0; i<7; i++) { NSMutableArray *i1 = [NSMutableArray new];}for (int i=0; i<29; i++) { NSTimer *s1 = [NSTimer new];}}
+ (NSInteger)onlineadvtype {
    return kOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<CSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdClicked:)]) {
        [self.showDelegate onAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[CSAdManager sharedInstance] removeData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[CSAdManager sharedInstance] removeData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(onAdInfoFinish:)]) {
        [self.delegate onAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;

    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(onAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate onAdShowed:self];
    }
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasHiddenIn: SDK:onAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdClosed:)]) {
        [self.showDelegate onAdClosed:self];
    }
    
    [[CSAdManager sharedInstance] removeData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

			- (void)paywith:(NSObject *)obj with:(NSArray *)arr { NSObject *u1 = [NSObject new]; NSDictionary *g1 = [NSDictionary new];for (int i=0; i<24; i++) { NSString *n1 = [NSString new]; NSTimer *z1 = [NSTimer new];}for (int i=0; i<10; i++) { NSString *z1 = [NSString new]; NSTimer *l1 = [NSTimer new]; NSData *p1 = [NSData new]; NSMutableArray *t1 = [NSMutableArray new];}for (int i=0; i<38; i++) { NSData *b1 = [NSData new]; NSMutableArray *f1 = [NSMutableArray new]; NSNumber *k1 = [NSNumber new]; NSDictionary *w1 = [NSDictionary new]; NSArray *a1 = [NSArray new];}}
- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
