//
//  TESTIOSCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadReward.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadProtocol.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadShowProtocol.h>
#import <AppLovinSDK/AppLovinSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface TESTIOSCSAdLoadApplovinReward : TESTIOSCSAdLoadReward<TESTIOSCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
