//
//  Co_ad_CSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadReward.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadProtocol.h>
#import <Co_ad_CSAdSDK/Co_ad_CSAdLoadShowProtocol.h>
#import <AppLovinSDK/AppLovinSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSAdLoadApplovinReward : Co_ad_CSAdLoadReward<Co_ad_CSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
