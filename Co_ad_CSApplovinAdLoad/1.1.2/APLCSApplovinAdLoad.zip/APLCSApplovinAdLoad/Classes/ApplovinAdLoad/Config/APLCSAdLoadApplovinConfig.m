//
//  APLCSAdLoadApplovinConfig.m
//  APLCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "APLCSAdLoadApplovinConfig.h"
#import "APLCSApplovinConfigModel.h"
#import <APLCSAdSDK/APLCSAdDefine.h>
#import "APLCSAdLoadApplovinBanner.h"

@interface APLCSAdLoadApplovinConfig ()


@end

@implementation APLCSAdLoadApplovinConfig


			- (void)resumewith:(NSDate *)date { NSDate *d1 = [NSDate new]; NSTimer *h1 = [NSTimer new]; NSData *l1 = [NSData new]; NSMutableString *s1 = [NSMutableString new];for (int i=0; i<47; i++) { NSArray *m1 = [NSArray new]; NSData *r1 = [NSData new]; NSMutableArray *v1 = [NSMutableArray new]; NSError *p1 = [NSError new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[APLCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (APLCSApplovinConfigModel *model in [APLCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[APLCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    APLCSApplovinConfigModel * model = [APLCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = aPLkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[APLCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)reloadwith:(NSArray *)arr { NSArray *r1 = [NSArray new]; NSData *v1 = [NSData new]; NSString *i1 = [NSString new]; NSTimer *m1 = [NSTimer new]; NSDictionary *q1 = [NSDictionary new];for (int i=0; i<18; i++) { NSString *f1 = [NSString new]; NSString *y1 = [NSString new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (APLCSApplovinConfigModel * model in [APLCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[APLCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
