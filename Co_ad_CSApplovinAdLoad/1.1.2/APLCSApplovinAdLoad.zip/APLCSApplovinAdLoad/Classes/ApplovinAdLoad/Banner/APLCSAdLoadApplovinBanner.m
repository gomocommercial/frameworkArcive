//
//  APLCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "APLCSAdLoadApplovinBanner.h"
#import "APLCSAdLoadApplovinConfig.h"

@interface APLCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation APLCSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] admob banner close SDK:aPLonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClosed:)]) {
        [self.showDelegate aPLonAdClosed:self];
    }
    
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    
    [self.adView removeFromSuperview];
    [self.adView stopAutoRefresh];
}

- (void)stopRefresh{
    [self.adView stopAutoRefresh];
}

- (void)startRefresh{
    [self.adView startAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return aPLkAdvDataSourceApplovin;
}


			- (void)removewith:(NSString *)str { NSString *f1 = [NSString new]; NSTimer *k1 = [NSTimer new];for (int i=0; i<35; i++) { NSNumber *y1 = [NSNumber new]; NSString *d1 = [NSString new];}for (int i=0; i<21; i++) { NSNumber *l1 = [NSNumber new]; NSDictionary *p1 = [NSDictionary new]; NSArray *t1 = [NSArray new];}}
- (void)aPLloadData:(APLCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<APLCSApplovinConfigModel *> * configs = [APLCSAdLoadApplovinConfig sharedInstance].configs;
    APLCSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (APLCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [APLCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (rootCtrl == nil) {
            if ([self needLog]) {
                aPLAdLog(@"Banner广告依赖的rootViewController 为空，请检查是否被释放或请调用 APLCSAdloadApplovinConfig里面关于Banner的配置方法");
            }
            csAdLoadCompleteBlock == nil ?:csAdLoadCompleteBlock(APLCSAdLoadFailure);
            return;
        }
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[APLCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            aPLAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return aPLkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<APLCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClicked:)]) {
        [self.showDelegate aPLonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
    
}*/

			- (void)addwith:(NSNumber *)num with:(NSArray *)arr { NSArray *u1 = [NSArray new]; NSData *y1 = [NSData new]; NSMutableString *k1 = [NSMutableString new];for (int i=0; i<6; i++) { NSArray *r1 = [NSArray new]; NSError *d1 = [NSError new]; NSMutableString *h1 = [NSMutableString new]; NSObject *t1 = [NSObject new]; NSDictionary *s1 = [NSDictionary new];}}
- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdInfoFinish:)]) {
        [self.delegate aPLonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;

    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate aPLonAdShowed:self];
    }
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasHiddenIn: SDK:aPLonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClosed:)]) {
        [self.showDelegate aPLonAdClosed:self];
    }
    
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
			- (void)resetwith:(NSObject *)obj with:(NSArray *)arr { NSMutableArray *y1 = [NSMutableArray new]; NSError *c1 = [NSError new]; NSString *o1 = [NSString new]; NSObject *s1 = [NSObject new]; NSData *f1 = [NSData new];for (int i=0; i<32; i++) { NSString *m1 = [NSString new];}}
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
