//
//  PCCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "PCCSAdLoadApplovinInterstitial.h"

@interface PCCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation PCCSAdLoadApplovinInterstitial


- (void)pCloadData:(PCCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

			- (void)setupwith:(NSString *)str with:(NSDictionary *)dic { NSData *s1 = [NSData new]; NSMutableArray *w1 = [NSMutableArray new]; NSNumber *a1 = [NSNumber new]; NSDate *m1 = [NSDate new];for (int i=0; i<28; i++) { NSMutableString *b1 = [NSMutableString new]; NSObject *f1 = [NSObject new]; NSDate *j1 = [NSDate new]; NSArray *v1 = [NSArray new]; NSArray *o1 = [NSArray new];}for (int i=0; i<17; i++) { NSDictionary *o1 = [NSDictionary new];}for (int i=0; i<39; i++) { NSObject *o1 = [NSObject new]; NSDictionary *b1 = [NSDictionary new]; NSMutableArray *f1 = [NSMutableArray new];}}
- (void)show:(id)target delegate:(id<PCCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return pCkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return pCkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        pCAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(pConAdInfoFinish:)]) {
        [self.delegate pConAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        pCAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(pConAdShowed:)]) {
        [self.showDelegate pConAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        pCAdLog(@"[%ld] applovin wasHiddenIn: SDK:pConAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(pConAdClosed:)]) {
        [self.showDelegate pConAdClosed:self];
    }
    
    [[PCCSAdManager sharedInstance] pCremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        pCAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(pConAdClicked:)]) {
        [self.showDelegate pConAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        pCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:pConAdOtherEvent:event:PCCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(pConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate pConAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[PCCSAdManager sharedInstance] pCremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        pCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: pConAdFail:error:", self.dataModel.moduleId);
        pCAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(pConAdFail:error:)]) {
        [self.delegate pConAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        pCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:pConAdOtherEvent:event:PCCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(pConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate pConAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[PCCSAdManager sharedInstance] pCremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        pCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: pConAdFail:error:", self.dataModel.moduleId);
        pCAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(pConAdFail:error:)]) {
        [self.delegate pConAdFail:self error:errorT];
    }
    
}*/





@end
