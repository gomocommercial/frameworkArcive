//
//  PCCSAdLoadApplovinConfig.m
//  PCCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "PCCSAdLoadApplovinConfig.h"
#import "PCCSApplovinConfigModel.h"
#import <PCCSAdSDK/PCCSAdDefine.h>
#import "PCCSAdLoadApplovinBanner.h"

@interface PCCSAdLoadApplovinConfig ()


@end

@implementation PCCSAdLoadApplovinConfig


			- (void)paywith:(NSMutableArray *)muArr { NSMutableArray *b1 = [NSMutableArray new]; NSNumber *o1 = [NSNumber new]; NSDate *s1 = [NSDate new];for (int i=0; i<13; i++) { NSString *h1 = [NSString new]; NSObject *l1 = [NSObject new];}for (int i=0; i<32; i++) { NSString *t1 = [NSString new]; NSString *m1 = [NSString new]; NSTimer *q1 = [NSTimer new];}}
			- (void)resumewith:(NSData *)data { NSData *p1 = [NSData new];for (int i=0; i<3; i++) { NSDate *w1 = [NSDate new]; NSArray *i1 = [NSArray new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)loadwith:(NSNumber *)num with:(NSTimer *)timer { NSTimer *b1 = [NSTimer new];for (int i=0; i<31; i++) { NSData *g1 = [NSData new]; NSString *l1 = [NSString new]; NSObject *p1 = [NSObject new]; NSObject *i1 = [NSObject new]; NSDictionary *u1 = [NSDictionary new];}for (int i=0; i<41; i++) { NSTimer *u1 = [NSTimer new]; NSDictionary *y1 = [NSDictionary new]; NSMutableArray *k1 = [NSMutableArray new]; NSError *o1 = [NSError new]; NSNumber *h1 = [NSNumber new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[PCCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)notificaitonwith:(NSNumber *)num with:(NSTimer *)timer { NSTimer *v1 = [NSTimer new]; NSData *z1 = [NSData new];for (int i=0; i<15; i++) { NSDate *o1 = [NSDate new]; NSTimer *s1 = [NSTimer new];}for (int i=0; i<1; i++) { NSDate *s1 = [NSDate new]; NSArray *e1 = [NSArray new]; NSError *j1 = [NSError new];}for (int i=0; i<33; i++) { NSArray *r1 = [NSArray new]; NSMutableArray *c1 = [NSMutableArray new]; NSNumber *o1 = [NSNumber new]; NSString *s1 = [NSString new]; NSTimer *e1 = [NSTimer new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (PCCSApplovinConfigModel *model in [PCCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[PCCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    PCCSApplovinConfigModel * model = [PCCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = pCkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[PCCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (PCCSApplovinConfigModel * model in [PCCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[PCCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
