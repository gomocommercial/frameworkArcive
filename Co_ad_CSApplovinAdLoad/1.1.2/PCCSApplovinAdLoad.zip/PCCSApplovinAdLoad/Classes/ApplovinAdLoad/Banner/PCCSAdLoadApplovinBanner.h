//
//  PCCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PCCSAdSDK/PCCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCCSAdSDK/PCCSAdLoadProtocol.h>
#import <PCCSAdSDK/PCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCCSAdLoadApplovinBanner : PCCSAdLoadBanner <PCCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
