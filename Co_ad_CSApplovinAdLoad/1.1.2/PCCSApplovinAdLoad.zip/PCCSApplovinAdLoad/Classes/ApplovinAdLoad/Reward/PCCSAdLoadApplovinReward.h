//
//  PCCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PCCSAdSDK/PCCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCCSAdSDK/PCCSAdLoadProtocol.h>
#import <PCCSAdSDK/PCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PCCSAdLoadApplovinReward : PCCSAdLoadReward<PCCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
