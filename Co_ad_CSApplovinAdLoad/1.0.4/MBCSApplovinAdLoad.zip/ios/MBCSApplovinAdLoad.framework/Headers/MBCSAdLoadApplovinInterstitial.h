//
//  MBCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MBCSAdSDK/MBCSAdLoadInterstitial.h>
#import <MBCSAdSDK/MBCSAdLoadProtocol.h>
#import <MBCSAdSDK/MBCSAdLoadShowProtocol.h>
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface MBCSAdLoadApplovinInterstitial : MBCSAdLoadInterstitial<MBCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
