//
//  QRCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <QRCSAdSDK/QRCSAdLoadInterstitial.h>
#import <QRCSAdSDK/QRCSAdLoadProtocol.h>
#import <QRCSAdSDK/QRCSAdLoadShowProtocol.h>
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface QRCSAdLoadApplovinInterstitial : QRCSAdLoadInterstitial<QRCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
