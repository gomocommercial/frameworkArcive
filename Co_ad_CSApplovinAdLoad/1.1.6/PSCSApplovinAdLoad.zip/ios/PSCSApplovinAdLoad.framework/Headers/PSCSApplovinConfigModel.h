//
//  PSCSApplovinConfigModel.h
//  PSCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class PSCSAdLoadApplovinBanner;

@interface PSCSApplovinConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;

//Banner
@property (nonatomic, assign) CGPoint bannerPosition;
@property (nonatomic, weak) UIViewController *rootViewController;
@property (nonatomic, copy) UIColor *backgroundColor;
//Banner
@property (nonatomic, weak) PSCSAdLoadApplovinBanner *banner;

@property (nonatomic, assign) BOOL isLoadedBanner;

@end

NS_ASSUME_NONNULL_END
