//
//  WACSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <WACSAdSDK/WACSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <WACSAdSDK/WACSAdLoadProtocol.h>
#import <WACSAdSDK/WACSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface WACSAdLoadApplovinOpen : WACSAdLoadOpen <WACSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
