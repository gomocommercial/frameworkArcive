//
//  HOCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <HOCSAdSDK/HOCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface HOCSAdLoadApplovinBanner : HOCSAdLoadBanner <HOCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
