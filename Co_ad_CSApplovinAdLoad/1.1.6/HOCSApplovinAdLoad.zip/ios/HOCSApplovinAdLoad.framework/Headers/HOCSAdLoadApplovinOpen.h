//
//  HOCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <HOCSAdSDK/HOCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <HOCSAdSDK/HOCSAdLoadProtocol.h>
#import <HOCSAdSDK/HOCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface HOCSAdLoadApplovinOpen : HOCSAdLoadOpen <HOCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
