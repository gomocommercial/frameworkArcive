//
//  SWCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <SWCSAdSDK/SWCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SWCSAdLoadApplovinBanner : SWCSAdLoadBanner <SWCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
