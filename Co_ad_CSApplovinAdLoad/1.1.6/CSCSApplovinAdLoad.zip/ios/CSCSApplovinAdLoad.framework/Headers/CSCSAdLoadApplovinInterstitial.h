//
//  CSCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CSCSAdSDK/CSCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSCSAdLoadApplovinInterstitial : CSCSAdLoadInterstitial<CSCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
