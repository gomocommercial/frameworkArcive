//
//  BCCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <BCCSAdSDK/BCCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface BCCSAdLoadApplovinBanner : BCCSAdLoadBanner <BCCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
