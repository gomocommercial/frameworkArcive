//
//  APLCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <APLCSAdSDK/APLCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <APLCSAdSDK/APLCSAdLoadProtocol.h>
#import <APLCSAdSDK/APLCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface APLCSAdLoadApplovinBanner : APLCSAdLoadBanner <APLCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
