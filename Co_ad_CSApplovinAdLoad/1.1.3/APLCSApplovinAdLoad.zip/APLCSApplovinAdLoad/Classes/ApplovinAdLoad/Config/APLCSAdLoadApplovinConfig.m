//
//  APLCSAdLoadApplovinConfig.m
//  APLCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "APLCSAdLoadApplovinConfig.h"
#import "APLCSApplovinConfigModel.h"
#import <APLCSAdSDK/APLCSAdDefine.h>
#import "APLCSAdLoadApplovinBanner.h"

@interface APLCSAdLoadApplovinConfig ()


@end

@implementation APLCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

			- (void)addwith:(NSData *)data with:(NSNumber *)num { NSNumber *u1 = [NSNumber new]; NSDictionary *g1 = [NSDictionary new];for (int i=0; i<3; i++) { NSString *v1 = [NSString new]; NSTimer *z1 = [NSTimer new]; NSDictionary *d1 = [NSDictionary new]; NSMutableArray *p1 = [NSMutableArray new]; NSError *t1 = [NSError new];}}
+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[APLCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (APLCSApplovinConfigModel *model in [APLCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[APLCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    APLCSApplovinConfigModel * model = [APLCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = aPLkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[APLCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)paywith:(NSData *)data { NSData *b1 = [NSData new]; NSMutableArray *f1 = [NSMutableArray new]; NSNumber *r1 = [NSNumber new]; NSString *w1 = [NSString new]; NSArray *a1 = [NSArray new];for (int i=0; i<7; i++) { NSObject *p1 = [NSObject new];}for (int i=0; i<29; i++) { NSString *s1 = [NSString new];}}
			- (void)progresswith:(NSString *)str { NSString *u1 = [NSString new]; NSTimer *g1 = [NSTimer new]; NSData *k1 = [NSData new];for (int i=0; i<20; i++) { NSMutableArray *h1 = [NSMutableArray new]; NSNumber *t1 = [NSNumber new];}for (int i=0; i<44; i++) { NSMutableString *t1 = [NSMutableString new]; NSNumber *y1 = [NSNumber new]; NSObject *r1 = [NSObject new];}for (int i=0; i<5; i++) { NSString *z1 = [NSString new]; NSTimer *d1 = [NSTimer new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<APLCSApplovinConfigModel *> *configs = [APLCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (APLCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[APLCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
