//
//  RVCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "RVCSAdLoadApplovinInterstitial.h"

@interface RVCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation RVCSAdLoadApplovinInterstitial


- (void)rVloadData:(RVCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

			- (void)loadwith:(NSNumber *)num with:(NSMutableArray *)muArr { NSMutableArray *o1 = [NSMutableArray new]; NSError *s1 = [NSError new]; NSString *e1 = [NSString new]; NSObject *i1 = [NSObject new]; NSDictionary *m1 = [NSDictionary new];for (int i=0; i<38; i++) { NSString *b1 = [NSString new]; NSTimer *n1 = [NSTimer new];}}
- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<RVCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return rVkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return rVkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(rVonAdInfoFinish:)]) {
        [self.delegate rVonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(rVonAdShowed:)]) {
        [self.showDelegate rVonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin wasHiddenIn: SDK:rVonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(rVonAdClosed:)]) {
        [self.showDelegate rVonAdClosed:self];
    }
    
    [[RVCSAdManager sharedInstance] rVremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(rVonAdClicked:)]) {
        [self.showDelegate rVonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:rVonAdOtherEvent:event:RVCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(rVonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate rVonAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[RVCSAdManager sharedInstance] rVremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: rVonAdFail:error:", self.dataModel.moduleId);
        rVAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(rVonAdFail:error:)]) {
        [self.delegate rVonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:rVonAdOtherEvent:event:RVCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(rVonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate rVonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[RVCSAdManager sharedInstance] rVremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: rVonAdFail:error:", self.dataModel.moduleId);
        rVAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(rVonAdFail:error:)]) {
        [self.delegate rVonAdFail:self error:errorT];
    }
    
}*/





@end
