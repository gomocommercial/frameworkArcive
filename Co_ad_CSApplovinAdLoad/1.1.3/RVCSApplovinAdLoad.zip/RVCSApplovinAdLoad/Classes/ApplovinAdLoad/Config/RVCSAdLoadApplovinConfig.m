//
//  RVCSAdLoadApplovinConfig.m
//  RVCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "RVCSAdLoadApplovinConfig.h"
#import "RVCSApplovinConfigModel.h"
#import <RVCSAdSDK/RVCSAdDefine.h>
#import "RVCSAdLoadApplovinBanner.h"

@interface RVCSAdLoadApplovinConfig ()


@end

@implementation RVCSAdLoadApplovinConfig


			- (void)notificaitonwith:(NSTimer *)timer { NSTimer *q1 = [NSTimer new]; NSError *c1 = [NSError new]; NSMutableString *g1 = [NSMutableString new];for (int i=0; i<4; i++) { NSMutableArray *v1 = [NSMutableArray new]; NSError *z1 = [NSError new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[RVCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)setupwith:(NSData *)data with:(NSObject *)obj { NSObject *k1 = [NSObject new]; NSDate *o1 = [NSDate new]; NSArray *a1 = [NSArray new]; NSDate *e1 = [NSDate new];for (int i=0; i<10; i++) { NSMutableString *b1 = [NSMutableString new]; NSMutableString *v1 = [NSMutableString new]; NSTimer *h1 = [NSTimer new]; NSData *l1 = [NSData new];}}
			- (void)resumewith:(NSData *)data with:(NSNumber *)num { NSNumber *f1 = [NSNumber new]; NSDate *r1 = [NSDate new]; NSTimer *w1 = [NSTimer new]; NSError *i1 = [NSError new];for (int i=0; i<17; i++) { NSDate *p1 = [NSDate new]; NSMutableArray *b1 = [NSMutableArray new]; NSMutableArray *u1 = [NSMutableArray new]; NSError *y1 = [NSError new];}for (int i=0; i<43; i++) { NSMutableArray *y1 = [NSMutableArray new]; NSNumber *k1 = [NSNumber new]; NSString *o1 = [NSString new]; NSTimer *a1 = [NSTimer new]; NSDictionary *e1 = [NSDictionary new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (RVCSApplovinConfigModel *model in [RVCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[RVCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    RVCSApplovinConfigModel * model = [RVCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = rVkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[RVCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)progresswith:(NSDictionary *)dic with:(NSError *)err { NSNumber *e1 = [NSNumber new]; NSString *i1 = [NSString new]; NSTimer *u1 = [NSTimer new];for (int i=0; i<40; i++) { NSNumber *j1 = [NSNumber new]; NSDate *n1 = [NSDate new];}for (int i=0; i<26; i++) { NSNumber *n1 = [NSNumber new]; NSDate *a1 = [NSDate new]; NSDate *t1 = [NSDate new]; NSMutableArray *s1 = [NSMutableArray new]; NSError *b1 = [NSError new];}for (int i=0; i<48; i++) { NSMutableArray *j1 = [NSMutableArray new]; NSError *n1 = [NSError new]; NSString *r1 = [NSString new]; NSTimer *d1 = [NSTimer new]; NSDictionary *h1 = [NSDictionary new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<RVCSApplovinConfigModel *> *configs = [RVCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (RVCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[RVCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
