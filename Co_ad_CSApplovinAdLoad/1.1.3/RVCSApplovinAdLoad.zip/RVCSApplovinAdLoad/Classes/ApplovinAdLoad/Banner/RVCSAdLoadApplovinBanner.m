//
//  RVCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "RVCSAdLoadApplovinBanner.h"
#import "RVCSAdLoadApplovinConfig.h"

@interface RVCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation RVCSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        rVAdLog(@"[%ld] admob banner close SDK:rVonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(rVonAdClosed:)]) {
        [self.showDelegate rVonAdClosed:self];
    }
    
    [[RVCSAdManager sharedInstance] rVremoveData:self];
    
    [self.adView removeFromSuperview];
    [self.adView stopAutoRefresh];
}

- (void)stopRefresh{
    [self.adView stopAutoRefresh];
}

- (void)startRefresh{
    [self.adView startAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return rVkAdvDataSourceApplovin;
}


- (void)rVloadData:(RVCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<RVCSApplovinConfigModel *> * configs = [RVCSAdLoadApplovinConfig sharedInstance].configs;
    RVCSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (RVCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [RVCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (rootCtrl == nil) {
            if ([self needLog]) {
                rVAdLog(@"Banner广告依赖的rootViewController 为空，请检查是否被释放或请调用 RVCSAdloadApplovinConfig里面关于Banner的配置方法");
            }
            csAdLoadCompleteBlock == nil ?:csAdLoadCompleteBlock(RVCSAdLoadFailure);
            return;
        }
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[RVCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            rVAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return rVkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<RVCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

			- (void)notificaitonwith:(NSArray *)arr with:(NSMutableString *)mutableStr { NSMutableString *n1 = [NSMutableString new];for (int i=0; i<13; i++) { NSArray *c1 = [NSArray new]; NSError *g1 = [NSError new]; NSMutableString *l1 = [NSMutableString new]; NSTimer *s1 = [NSTimer new]; NSDictionary *b1 = [NSDictionary new];}for (int i=0; i<6; i++) { NSTimer *b1 = [NSTimer new]; NSTimer *u1 = [NSTimer new]; NSData *g1 = [NSData new];}}
- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(rVonAdClicked:)]) {
        [self.showDelegate rVonAdClicked:self];
    }
}


			- (void)statuswith:(NSDate *)date with:(NSData *)data { NSData *d1 = [NSData new]; NSMutableString *p1 = [NSMutableString new]; NSNumber *t1 = [NSNumber new];for (int i=0; i<35; i++) { NSError *i1 = [NSError new]; NSMutableString *n1 = [NSMutableString new];}for (int i=0; i<21; i++) { NSError *u1 = [NSError new]; NSDate *z1 = [NSDate new]; NSDate *s1 = [NSDate new];}}
- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:rVonAdOtherEvent:event:RVCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(rVonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate rVonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[RVCSAdManager sharedInstance] rVremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: rVonAdFail:error:", self.dataModel.moduleId);
        rVAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(rVonAdFail:error:)]) {
        [self.delegate rVonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:rVonAdOtherEvent:event:RVCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(rVonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate rVonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[RVCSAdManager sharedInstance] rVremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: rVonAdFail:error:", self.dataModel.moduleId);
        rVAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(rVonAdFail:error:)]) {
        [self.delegate rVonAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(rVonAdInfoFinish:)]) {
        [self.delegate rVonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;

    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(rVonAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate rVonAdShowed:self];
    }
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        rVAdLog(@"[%ld] applovin wasHiddenIn: SDK:rVonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(rVonAdClosed:)]) {
        [self.showDelegate rVonAdClosed:self];
    }
    
    [[RVCSAdManager sharedInstance] rVremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
