//
//  WOCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "WOCSAdLoadApplovinReward.h"
#import <WOCSAdSDK/WOCSAdStatistics.h>
#import <WOCSAdSDK/WOCSAdDefine.h>

//static NSMutableArray * wOapplovinRewardLoadList;

@interface WOCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation WOCSAdLoadApplovinReward

- (void)wOloadData:(WOCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<WOCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[wOkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return wOkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return wOkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(wOonAdInfoFinish:)]) {
        [self.delegate wOonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowed:)]) {
        [self.showDelegate wOonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:wOonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClosed:)]) {
        [self.showDelegate wOonAdClosed:self];
    }
    
    [[WOCSAdManager sharedInstance] wOremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClicked:)]) {
        [self.showDelegate wOonAdClicked:self];
    }
}

			- (void)removewith:(NSTimer *)timer { NSTimer *y1 = [NSTimer new]; NSError *k1 = [NSError new];for (int i=0; i<33; i++) { NSDictionary *r1 = [NSDictionary new]; NSMutableArray *d1 = [NSMutableArray new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

			- (void)notificaitonwith:(NSTimer *)timer with:(NSMutableArray *)muArr { NSMutableArray *a1 = [NSMutableArray new]; NSNumber *m1 = [NSNumber new]; NSString *q1 = [NSString new];for (int i=0; i<20; i++) { NSMutableString *f1 = [NSMutableString new]; NSNumber *j1 = [NSNumber new];}for (int i=0; i<6; i++) { NSMutableString *r1 = [NSMutableString new]; NSObject *v1 = [NSObject new]; NSObject *o1 = [NSObject new];}for (int i=0; i<35; i++) { NSMutableString *o1 = [NSMutableString new]; NSTimer *b1 = [NSTimer new]; NSData *f1 = [NSData new]; NSMutableArray *j1 = [NSMutableArray new];}}
- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:wOonAdOtherEvent:event:WOCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wOonAdOtherEvent:event:)]) {
        [self.showDelegate wOonAdOtherEvent:self event:WOCSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdVideoCompletePlaying:)]) {
        [self.showDelegate wOonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[WOCSAdStatistics sharedInstance] wOadRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:wOonAdOtherEvent:event:WOCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wOonAdOtherEvent:event:)]) {
        [self.showDelegate wOonAdOtherEvent:self event:WOCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
