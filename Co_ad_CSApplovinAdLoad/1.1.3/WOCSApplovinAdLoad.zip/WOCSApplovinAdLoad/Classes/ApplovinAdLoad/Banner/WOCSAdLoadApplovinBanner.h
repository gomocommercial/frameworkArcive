//
//  WOCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <WOCSAdSDK/WOCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <WOCSAdSDK/WOCSAdLoadProtocol.h>
#import <WOCSAdSDK/WOCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface WOCSAdLoadApplovinBanner : WOCSAdLoadBanner <WOCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
