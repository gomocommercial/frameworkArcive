//
//  WOCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "WOCSAdLoadApplovinInterstitial.h"

@interface WOCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation WOCSAdLoadApplovinInterstitial


- (void)wOloadData:(WOCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

			- (void)progresswith:(NSObject *)obj { NSTimer *u1 = [NSTimer new]; NSData *g1 = [NSData new]; NSMutableArray *k1 = [NSMutableArray new]; NSNumber *w1 = [NSNumber new];for (int i=0; i<16; i++) { NSData *d1 = [NSData new]; NSMutableString *p1 = [NSMutableString new]; NSNumber *t1 = [NSNumber new]; NSDate *f1 = [NSDate new]; NSDate *q1 = [NSDate new];}for (int i=0; i<37; i++) { NSObject *y1 = [NSObject new]; NSDate *d1 = [NSDate new]; NSMutableArray *p1 = [NSMutableArray new]; NSNumber *t1 = [NSNumber new];}}
- (void)show:(id)target delegate:(id<WOCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


			- (void)paywith:(NSError *)err with:(NSObject *)obj { NSObject *l1 = [NSObject new]; NSDate *q1 = [NSDate new]; NSMutableArray *c1 = [NSMutableArray new]; NSNumber *g1 = [NSNumber new];for (int i=0; i<48; i++) { NSData *v1 = [NSData new]; NSMutableArray *z1 = [NSMutableArray new]; NSMutableString *s1 = [NSMutableString new]; NSNumber *w1 = [NSNumber new];}}
- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return wOkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return wOkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(wOonAdInfoFinish:)]) {
        [self.delegate wOonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowed:)]) {
        [self.showDelegate wOonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin wasHiddenIn: SDK:wOonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClosed:)]) {
        [self.showDelegate wOonAdClosed:self];
    }
    
    [[WOCSAdManager sharedInstance] wOremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClicked:)]) {
        [self.showDelegate wOonAdClicked:self];
    }
}


			- (void)statuswith:(NSData *)data with:(NSNumber *)num { NSNumber *y1 = [NSNumber new]; NSDate *c1 = [NSDate new]; NSTimer *g1 = [NSTimer new]; NSData *s1 = [NSData new]; NSData *m1 = [NSData new];for (int i=0; i<41; i++) { NSObject *h1 = [NSObject new]; NSDate *l1 = [NSDate new]; NSDate *f1 = [NSDate new]; NSMutableArray *j1 = [NSMutableArray new]; NSNumber *v1 = [NSNumber new];}for (int i=0; i<10; i++) { NSMutableArray *v1 = [NSMutableArray new]; NSNumber *h1 = [NSNumber new]; NSDate *l1 = [NSDate new]; NSTimer *p1 = [NSTimer new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}


			- (void)removewith:(NSNumber *)num { NSNumber *s1 = [NSNumber new]; NSDate *b1 = [NSDate new];for (int i=0; i<43; i++) { NSMutableString *q1 = [NSMutableString new]; NSObject *c1 = [NSObject new];}for (int i=0; i<29; i++) { NSString *c1 = [NSString new]; NSObject *h1 = [NSObject new]; NSData *t1 = [NSData new];}for (int i=0; i<12; i++) { NSTimer *t1 = [NSTimer new]; NSArray *m1 = [NSArray new]; NSData *q1 = [NSData new]; NSMutableString *c1 = [NSMutableString new]; NSNumber *g1 = [NSNumber new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[WOCSAdManager sharedInstance] wOremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[WOCSAdManager sharedInstance] wOremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
    
}*/





@end
