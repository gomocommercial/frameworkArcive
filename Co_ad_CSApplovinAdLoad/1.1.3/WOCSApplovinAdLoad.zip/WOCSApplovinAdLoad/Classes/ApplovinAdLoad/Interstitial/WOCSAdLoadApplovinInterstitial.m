//
//  WOCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "WOCSAdLoadApplovinInterstitial.h"

@interface WOCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation WOCSAdLoadApplovinInterstitial


			- (void)addwith:(NSTimer *)timer with:(NSMutableArray *)muArr { NSMutableArray *u1 = [NSMutableArray new]; NSNumber *g1 = [NSNumber new]; NSString *k1 = [NSString new]; NSTimer *w1 = [NSTimer new]; NSData *b1 = [NSData new];for (int i=0; i<2; i++) { NSDate *p1 = [NSDate new]; NSDate *i1 = [NSDate new]; NSArray *n1 = [NSArray new]; NSError *r1 = [NSError new];}for (int i=0; i<28; i++) { NSMutableArray *z1 = [NSMutableArray new]; NSError *d1 = [NSError new]; NSString *p1 = [NSString new]; NSTimer *t1 = [NSTimer new]; NSDictionary *s1 = [NSDictionary new];}for (int i=0; i<20; i++) { NSTimer *f1 = [NSTimer new]; NSDictionary *j1 = [NSDictionary new];}}
- (void)wOloadData:(WOCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<WOCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


			- (void)reloadwith:(NSString *)str with:(NSDictionary *)dic { NSDictionary *b1 = [NSDictionary new]; NSMutableArray *o1 = [NSMutableArray new]; NSNumber *s1 = [NSNumber new]; NSDate *w1 = [NSDate new];for (int i=0; i<6; i++) { NSMutableString *l1 = [NSMutableString new]; NSMutableString *e1 = [NSMutableString new]; NSObject *q1 = [NSObject new]; NSDictionary *u1 = [NSDictionary new]; NSArray *y1 = [NSArray new];}for (int i=0; i<27; i++) { NSDictionary *g1 = [NSDictionary new]; NSArray *k1 = [NSArray new]; NSError *p1 = [NSError new]; NSNumber *i1 = [NSNumber new];}}
- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return wOkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return wOkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(wOonAdInfoFinish:)]) {
        [self.delegate wOonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowed:)]) {
        [self.showDelegate wOonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin wasHiddenIn: SDK:wOonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClosed:)]) {
        [self.showDelegate wOonAdClosed:self];
    }
    
    [[WOCSAdManager sharedInstance] wOremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClicked:)]) {
        [self.showDelegate wOonAdClicked:self];
    }
}


			- (void)notificaitonwith:(NSDictionary *)dic { NSData *q1 = [NSData new];for (int i=0; i<43; i++) { NSDate *e1 = [NSDate new]; NSArray *j1 = [NSArray new]; NSError *v1 = [NSError new]; NSString *z1 = [NSString new]; NSObject *d1 = [NSObject new];}for (int i=0; i<36; i++) { NSString *l1 = [NSString new]; NSObject *p1 = [NSObject new]; NSDictionary *t1 = [NSDictionary new];}}
			- (void)paywith:(NSString *)str { NSString *b1 = [NSString new]; NSTimer *n1 = [NSTimer new];for (int i=0; i<23; i++) { NSNumber *u1 = [NSNumber new]; NSDate *g1 = [NSDate new];}for (int i=0; i<9; i++) { NSObject *g1 = [NSObject new]; NSDictionary *l1 = [NSDictionary new]; NSMutableArray *s1 = [NSMutableArray new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[WOCSAdManager sharedInstance] wOremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[WOCSAdManager sharedInstance] wOremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
    
}*/





@end
