//
//  WOCSAdLoadApplovinConfig.m
//  WOCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "WOCSAdLoadApplovinConfig.h"
#import "WOCSApplovinConfigModel.h"
#import <WOCSAdSDK/WOCSAdDefine.h>
#import "WOCSAdLoadApplovinBanner.h"

@interface WOCSAdLoadApplovinConfig ()


@end

@implementation WOCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)statuswith:(NSMutableArray *)muArr { NSMutableArray *t1 = [NSMutableArray new]; NSNumber *f1 = [NSNumber new]; NSDate *j1 = [NSDate new];for (int i=0; i<25; i++) { NSMutableString *y1 = [NSMutableString new]; NSNumber *c1 = [NSNumber new];}for (int i=0; i<11; i++) { NSMutableString *k1 = [NSMutableString new]; NSObject *o1 = [NSObject new]; NSObject *h1 = [NSObject new];}}
			- (void)setupwith:(NSDate *)date { NSDate *i1 = [NSDate new]; NSArray *m1 = [NSArray new];for (int i=0; i<36; i++) { NSObject *b1 = [NSObject new]; NSDate *f1 = [NSDate new]; NSArray *j1 = [NSArray new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[WOCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)reloadwith:(NSNumber *)num { NSNumber *r1 = [NSNumber new]; NSDate *d1 = [NSDate new]; NSMutableArray *i1 = [NSMutableArray new]; NSError *m1 = [NSError new];for (int i=0; i<6; i++) { NSDictionary *b1 = [NSDictionary new]; NSMutableArray *n1 = [NSMutableArray new]; NSMutableArray *y1 = [NSMutableArray new]; NSNumber *k1 = [NSNumber new];}for (int i=0; i<31; i++) { NSMutableArray *k1 = [NSMutableArray new]; NSNumber *w1 = [NSNumber new]; NSDate *a1 = [NSDate new]; NSTimer *e1 = [NSTimer new]; NSTimer *s1 = [NSTimer new];}for (int i=0; i<2; i++) { NSDate *f1 = [NSDate new]; NSObject *s1 = [NSObject new]; NSDictionary *e1 = [NSDictionary new]; NSString *t1 = [NSString new];}}
			- (void)resumewith:(NSError *)err { NSError *h1 = [NSError new];for (int i=0; i<31; i++) { NSDictionary *w1 = [NSDictionary new]; NSMutableArray *i1 = [NSMutableArray new]; NSObject *n1 = [NSObject new]; NSDate *r1 = [NSDate new]; NSArray *d1 = [NSArray new];}for (int i=0; i<24; i++) { NSDate *d1 = [NSDate new]; NSArray *p1 = [NSArray new]; NSError *t1 = [NSError new];}for (int i=0; i<6; i++) { NSArray *t1 = [NSArray new]; NSError *f1 = [NSError new]; NSMutableString *j1 = [NSMutableString new]; NSObject *o1 = [NSObject new]; NSData *a1 = [NSData new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (WOCSApplovinConfigModel *model in [WOCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[WOCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    WOCSApplovinConfigModel * model = [WOCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = wOkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[WOCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<WOCSApplovinConfigModel *> *configs = [WOCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (WOCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[WOCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
