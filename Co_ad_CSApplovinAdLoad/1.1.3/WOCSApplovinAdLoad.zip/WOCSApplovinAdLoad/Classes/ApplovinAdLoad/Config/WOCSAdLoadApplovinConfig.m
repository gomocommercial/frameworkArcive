//
//  WOCSAdLoadApplovinConfig.m
//  WOCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "WOCSAdLoadApplovinConfig.h"
#import "WOCSApplovinConfigModel.h"
#import <WOCSAdSDK/WOCSAdDefine.h>
#import "WOCSAdLoadApplovinBanner.h"

@interface WOCSAdLoadApplovinConfig ()


@end

@implementation WOCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)resumewith:(NSDictionary *)dic { NSDictionary *p1 = [NSDictionary new]; NSArray *t1 = [NSArray new];for (int i=0; i<5; i++) { NSTimer *i1 = [NSTimer new]; NSDictionary *m1 = [NSDictionary new];}for (int i=0; i<41; i++) { NSTimer *u1 = [NSTimer new]; NSError *z1 = [NSError new]; NSMutableString *d1 = [NSMutableString new];}for (int i=0; i<24; i++) { NSError *l1 = [NSError new]; NSError *e1 = [NSError new]; NSString *i1 = [NSString new]; NSObject *m1 = [NSObject new]; NSDictionary *y1 = [NSDictionary new];}}
			- (void)actionwith:(NSArray *)arr with:(NSDate *)date { NSDate *m1 = [NSDate new]; NSTimer *q1 = [NSTimer new]; NSData *c1 = [NSData new]; NSMutableArray *g1 = [NSMutableArray new];for (int i=0; i<48; i++) { NSArray *v1 = [NSArray new]; NSData *z1 = [NSData new]; NSMutableString *l1 = [NSMutableString new]; NSNumber *p1 = [NSNumber new]; NSDictionary *u1 = [NSDictionary new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[WOCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (WOCSApplovinConfigModel *model in [WOCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[WOCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    WOCSApplovinConfigModel * model = [WOCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = wOkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[WOCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)addwith:(NSTimer *)timer { NSTimer *k1 = [NSTimer new]; NSData *w1 = [NSData new]; NSMutableArray *a1 = [NSMutableArray new];for (int i=0; i<38; i++) { NSArray *p1 = [NSArray new]; NSData *t1 = [NSData new];}}
			- (void)paywith:(NSDate *)date { NSDictionary *b1 = [NSDictionary new]; NSArray *f1 = [NSArray new]; NSDictionary *a1 = [NSDictionary new]; NSMutableArray *m1 = [NSMutableArray new]; NSError *q1 = [NSError new];for (int i=0; i<38; i++) { NSNumber *i1 = [NSNumber new]; NSDate *u1 = [NSDate new]; NSTimer *y1 = [NSTimer new]; NSData *c1 = [NSData new]; NSMutableString *o1 = [NSMutableString new];}for (int i=0; i<3; i++) { NSData *o1 = [NSData new]; NSData *h1 = [NSData new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<WOCSApplovinConfigModel *> *configs = [WOCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (WOCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[WOCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
