//
//  SKCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <SKCSAdSDK/SKCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SKCSAdSDK/SKCSAdLoadProtocol.h>
#import <SKCSAdSDK/SKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SKCSAdLoadApplovinBanner : SKCSAdLoadBanner <SKCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
