//
//  SKCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "SKCSAdLoadApplovinBanner.h"
#import "SKCSAdLoadApplovinConfig.h"

@interface SKCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation SKCSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        sKAdLog(@"[%ld] admob banner close SDK:sKonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(sKonAdClosed:)]) {
        [self.showDelegate sKonAdClosed:self];
    }
    
    [[SKCSAdManager sharedInstance] sKremoveData:self];
    
    [self.adView removeFromSuperview];
    [self.adView stopAutoRefresh];
}

- (void)stopRefresh{
    [self.adView stopAutoRefresh];
}

- (void)startRefresh{
    [self.adView startAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return sKkAdvDataSourceApplovin;
}


- (void)sKloadData:(SKCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<SKCSApplovinConfigModel *> * configs = [SKCSAdLoadApplovinConfig sharedInstance].configs;
    SKCSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (SKCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [SKCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (rootCtrl == nil) {
            if ([self needLog]) {
                sKAdLog(@"Banner广告依赖的rootViewController 为空，请检查是否被释放或请调用 SKCSAdloadApplovinConfig里面关于Banner的配置方法");
            }
            csAdLoadCompleteBlock == nil ?:csAdLoadCompleteBlock(SKCSAdLoadFailure);
            return;
        }
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[SKCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            sKAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

			- (void)progresswith:(NSMutableArray *)muArr { NSMutableArray *t1 = [NSMutableArray new]; NSNumber *f1 = [NSNumber new]; NSString *k1 = [NSString new]; NSArray *w1 = [NSArray new];for (int i=0; i<17; i++) { NSObject *d1 = [NSObject new];}}
- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return sKkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<SKCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(sKonAdClicked:)]) {
        [self.showDelegate sKonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:sKonAdOtherEvent:event:SKCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(sKonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate sKonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[SKCSAdManager sharedInstance] sKremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: sKonAdFail:error:", self.dataModel.moduleId);
        sKAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(sKonAdFail:error:)]) {
        [self.delegate sKonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:sKonAdOtherEvent:event:SKCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(sKonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate sKonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[SKCSAdManager sharedInstance] sKremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: sKonAdFail:error:", self.dataModel.moduleId);
        sKAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(sKonAdFail:error:)]) {
        [self.delegate sKonAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(sKonAdInfoFinish:)]) {
        [self.delegate sKonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;

    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(sKonAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate sKonAdShowed:self];
    }
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin wasHiddenIn: SDK:sKonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(sKonAdClosed:)]) {
        [self.showDelegate sKonAdClosed:self];
    }
    
    [[SKCSAdManager sharedInstance] sKremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

			- (void)statuswith:(NSDictionary *)dic { NSDictionary *b1 = [NSDictionary new]; NSMutableArray *f1 = [NSMutableArray new];for (int i=0; i<15; i++) { NSTimer *u1 = [NSTimer new]; NSDictionary *y1 = [NSDictionary new];}}
- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
