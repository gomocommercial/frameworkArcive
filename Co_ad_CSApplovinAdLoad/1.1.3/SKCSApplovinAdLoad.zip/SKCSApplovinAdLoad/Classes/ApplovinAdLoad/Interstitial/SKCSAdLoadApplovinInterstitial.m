//
//  SKCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "SKCSAdLoadApplovinInterstitial.h"

@interface SKCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation SKCSAdLoadApplovinInterstitial


- (void)sKloadData:(SKCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

			- (void)reloadwith:(NSArray *)arr with:(NSMutableString *)mutableStr { NSString *p1 = [NSString new]; NSError *k1 = [NSError new]; NSString *o1 = [NSString new]; NSTimer *a1 = [NSTimer new]; NSDictionary *e1 = [NSDictionary new];for (int i=0; i<28; i++) { NSDate *t1 = [NSDate new]; NSTimer *s1 = [NSTimer new]; NSData *j1 = [NSData new]; NSMutableArray *n1 = [NSMutableArray new]; NSNumber *r1 = [NSNumber new];}}
			- (void)setupwith:(NSData *)data { NSData *z1 = [NSData new]; NSString *m1 = [NSString new]; NSTimer *q1 = [NSTimer new]; NSDictionary *u1 = [NSDictionary new];for (int i=0; i<36; i++) { NSString *j1 = [NSString new]; NSTimer *n1 = [NSTimer new]; NSTimer *g1 = [NSTimer new]; NSData *s1 = [NSData new]; NSMutableArray *w1 = [NSMutableArray new];}for (int i=0; i<7; i++) { NSData *w1 = [NSData new]; NSMutableString *i1 = [NSMutableString new]; NSNumber *n1 = [NSNumber new]; NSObject *g1 = [NSObject new];}for (int i=0; i<32; i++) { NSString *g1 = [NSString new]; NSTimer *s1 = [NSTimer new]; NSDictionary *w1 = [NSDictionary new]; NSMutableArray *i1 = [NSMutableArray new];}}
- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<SKCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return sKkAdvDataSourceApplovin;
}

			- (void)removewith:(NSArray *)arr with:(NSMutableString *)mutableStr { NSString *i1 = [NSString new]; NSTimer *u1 = [NSTimer new];for (int i=0; i<23; i++) { NSNumber *j1 = [NSNumber new]; NSDate *n1 = [NSDate new]; NSTimer *r1 = [NSTimer new]; NSData *d1 = [NSData new]; NSMutableArray *h1 = [NSMutableArray new];}for (int i=0; i<16; i++) { NSData *p1 = [NSData new]; NSMutableString *t1 = [NSMutableString new]; NSNumber *s1 = [NSNumber new];}for (int i=0; i<48; i++) { NSMutableString *f1 = [NSMutableString new]; NSObject *k1 = [NSObject new]; NSDictionary *o1 = [NSDictionary new]; NSMutableArray *a1 = [NSMutableArray new]; NSError *e1 = [NSError new];}}
+ (NSInteger)onlineadvtype{
    return sKkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(sKonAdInfoFinish:)]) {
        [self.delegate sKonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(sKonAdShowed:)]) {
        [self.showDelegate sKonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin wasHiddenIn: SDK:sKonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(sKonAdClosed:)]) {
        [self.showDelegate sKonAdClosed:self];
    }
    
    [[SKCSAdManager sharedInstance] sKremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(sKonAdClicked:)]) {
        [self.showDelegate sKonAdClicked:self];
    }
}


			- (void)resumewith:(NSTimer *)timer with:(NSMutableArray *)muArr { NSMutableArray *f1 = [NSMutableArray new]; NSNumber *r1 = [NSNumber new];for (int i=0; i<33; i++) { NSData *y1 = [NSData new]; NSMutableString *k1 = [NSMutableString new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:sKonAdOtherEvent:event:SKCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(sKonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate sKonAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[SKCSAdManager sharedInstance] sKremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: sKonAdFail:error:", self.dataModel.moduleId);
        sKAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(sKonAdFail:error:)]) {
        [self.delegate sKonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:sKonAdOtherEvent:event:SKCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(sKonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate sKonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[SKCSAdManager sharedInstance] sKremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        sKAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: sKonAdFail:error:", self.dataModel.moduleId);
        sKAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(sKonAdFail:error:)]) {
        [self.delegate sKonAdFail:self error:errorT];
    }
    
}*/





@end
