//
//  SKCSApplovinConfigModel.m
//  SKCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "SKCSApplovinConfigModel.h"

@implementation SKCSApplovinConfigModel

@end
