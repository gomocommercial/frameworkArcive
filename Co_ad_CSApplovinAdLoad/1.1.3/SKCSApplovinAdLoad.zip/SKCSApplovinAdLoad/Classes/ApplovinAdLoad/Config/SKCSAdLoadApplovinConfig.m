//
//  SKCSAdLoadApplovinConfig.m
//  SKCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "SKCSAdLoadApplovinConfig.h"
#import "SKCSApplovinConfigModel.h"
#import <SKCSAdSDK/SKCSAdDefine.h>
#import "SKCSAdLoadApplovinBanner.h"

@interface SKCSAdLoadApplovinConfig ()


@end

@implementation SKCSAdLoadApplovinConfig


			- (void)cancelwith:(NSMutableString *)mutableStr with:(NSDate *)date { NSDate *b1 = [NSDate new]; NSArray *f1 = [NSArray new]; NSData *j1 = [NSData new]; NSMutableString *w1 = [NSMutableString new];for (int i=0; i<17; i++) { NSArray *k1 = [NSArray new]; NSNumber *p1 = [NSNumber new]; NSString *t1 = [NSString new]; NSString *m1 = [NSString new];}for (int i=0; i<43; i++) { NSNumber *u1 = [NSNumber new]; NSDate *y1 = [NSDate new]; NSTimer *c1 = [NSTimer new]; NSData *o1 = [NSData new]; NSMutableArray *s1 = [NSMutableArray new];}}
			- (void)progresswith:(NSMutableArray *)muArr with:(NSDate *)date { NSDate *e1 = [NSDate new]; NSTimer *i1 = [NSTimer new]; NSData *u1 = [NSData new]; NSMutableArray *y1 = [NSMutableArray new];for (int i=0; i<42; i++) { NSArray *n1 = [NSArray new]; NSData *r1 = [NSData new]; NSData *k1 = [NSData new]; NSString *s1 = [NSString new];}for (int i=0; i<17; i++) { NSNumber *s1 = [NSNumber new]; NSString *b1 = [NSString new]; NSTimer *n1 = [NSTimer new]; NSDictionary *r1 = [NSDictionary new];}for (int i=0; i<14; i++) { NSTimer *r1 = [NSTimer new]; NSData *d1 = [NSData new]; NSMutableArray *h1 = [NSMutableArray new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)notificaitonwith:(NSObject *)obj with:(NSArray *)arr { NSArray *a1 = [NSArray new];for (int i=0; i<31; i++) { NSObject *o1 = [NSObject new]; NSDictionary *b1 = [NSDictionary new]; NSMutableString *f1 = [NSMutableString new]; NSNumber *j1 = [NSNumber new]; NSDate *v1 = [NSDate new];}for (int i=0; i<24; i++) { NSNumber *v1 = [NSNumber new]; NSDate *z1 = [NSDate new]; NSArray *l1 = [NSArray new];}for (int i=0; i<6; i++) { NSDate *l1 = [NSDate new]; NSArray *s1 = [NSArray new]; NSError *c1 = [NSError new]; NSString *g1 = [NSString new]; NSString *z1 = [NSString new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[SKCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)resetwith:(NSArray *)arr with:(NSMutableString *)mutableStr { NSMutableString *y1 = [NSMutableString new];for (int i=0; i<43; i++) { NSArray *m1 = [NSArray new]; NSNumber *r1 = [NSNumber new]; NSString *v1 = [NSString new]; NSTimer *h1 = [NSTimer new]; NSDictionary *l1 = [NSDictionary new];}for (int i=0; i<36; i++) { NSTimer *l1 = [NSTimer new]; NSData *s1 = [NSData new]; NSNumber *a1 = [NSNumber new];}for (int i=0; i<27; i++) { NSMutableString *i1 = [NSMutableString new]; NSObject *m1 = [NSObject new]; NSDate *q1 = [NSDate new]; NSArray *c1 = [NSArray new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (SKCSApplovinConfigModel *model in [SKCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[SKCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    SKCSApplovinConfigModel * model = [SKCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = sKkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[SKCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<SKCSApplovinConfigModel *> *configs = [SKCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (SKCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[SKCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
