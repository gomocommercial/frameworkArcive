//
//  WOCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "WOCSAdLoadApplovinInterstitial.h"
#import <WOCSAdSDK/WOCSAdStatistics.h>

@interface WOCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation WOCSAdLoadApplovinInterstitial


- (void)wOloadData:(WOCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<WOCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


			- (void)reloadwith:(NSError *)err with:(NSTimer *)timer { NSTimer *k1 = [NSTimer new];for (int i=0; i<23; i++) { NSNumber *r1 = [NSNumber new]; NSDate *d1 = [NSDate new];}for (int i=0; i<10; i++) { NSNumber *d1 = [NSNumber new]; NSDate *h1 = [NSDate new]; NSArray *t1 = [NSArray new];}for (int i=0; i<42; i++) { NSDate *t1 = [NSDate new];}}
- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

			- (void)resetwith:(NSError *)err with:(NSTimer *)timer { NSTimer *g1 = [NSTimer new]; NSData *k1 = [NSData new]; NSMutableArray *o1 = [NSMutableArray new]; NSNumber *a1 = [NSNumber new];for (int i=0; i<28; i++) { NSData *p1 = [NSData new]; NSMutableString *t1 = [NSMutableString new]; NSNumber *s1 = [NSNumber new]; NSDate *j1 = [NSDate new]; NSDate *d1 = [NSDate new];}for (int i=0; i<17; i++) { NSObject *c1 = [NSObject new];}}
+ (NSInteger)advdatasource{
    return wOkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return wOkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(wOonAdInfoFinish:)]) {
        [self.delegate wOonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowed:)]) {
        [self.showDelegate wOonAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[WOCSAdStatistics sharedInstance] wOadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin wasHiddenIn: SDK:wOonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClosed:)]) {
        [self.showDelegate wOonAdClosed:self];
    }
    
    [[WOCSAdManager sharedInstance] wOremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClicked:)]) {
        [self.showDelegate wOonAdClicked:self];
    }
}


			- (void)notificaitonwith:(NSError *)err with:(NSTimer *)timer { NSTimer *i1 = [NSTimer new]; NSData *m1 = [NSData new]; NSMutableArray *q1 = [NSMutableArray new]; NSNumber *c1 = [NSNumber new]; NSString *g1 = [NSString new];for (int i=0; i<18; i++) { NSMutableString *v1 = [NSMutableString new]; NSNumber *z1 = [NSNumber new];}for (int i=0; i<36; i++) { NSMutableString *h1 = [NSMutableString new]; NSNumber *l1 = [NSNumber new]; NSObject *e1 = [NSObject new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}


			- (void)loadwith:(NSTimer *)timer with:(NSMutableString *)mutableStr { NSMutableString *o1 = [NSMutableString new]; NSObject *a1 = [NSObject new]; NSDate *e1 = [NSDate new]; NSArray *q1 = [NSArray new]; NSError *u1 = [NSError new];for (int i=0; i<42; i++) { NSDictionary *j1 = [NSDictionary new]; NSArray *n1 = [NSArray new]; NSMutableArray *g1 = [NSMutableArray new]; NSError *l1 = [NSError new];}for (int i=0; i<17; i++) { NSMutableArray *t1 = [NSMutableArray new]; NSNumber *s1 = [NSNumber new]; NSDate *j1 = [NSDate new]; NSArray *n1 = [NSArray new];}for (int i=0; i<14; i++) { NSDate *n1 = [NSDate new]; NSArray *z1 = [NSArray new]; NSData *d1 = [NSData new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[WOCSAdManager sharedInstance] wOremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[WOCSAdManager sharedInstance] wOremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
    
}*/





@end
