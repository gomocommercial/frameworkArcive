//
//  WOCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "WOCSAdLoadApplovinReward.h"
#import <WOCSAdSDK/WOCSAdStatistics.h>
#import <WOCSAdSDK/WOCSAdDefine.h>
#import <WOCSAdSDK/WOCSAdStatistics.h>

//static NSMutableArray * wOapplovinRewardLoadList;

@interface WOCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation WOCSAdLoadApplovinReward

- (void)wOloadData:(WOCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

			- (void)reloadwith:(NSNumber *)num { NSObject *r1 = [NSObject new]; NSDictionary *w1 = [NSDictionary new];for (int i=0; i<43; i++) { NSMutableString *k1 = [NSMutableString new]; NSTimer *s1 = [NSTimer new];}for (int i=0; i<11; i++) { NSDate *s1 = [NSDate new]; NSTimer *b1 = [NSTimer new]; NSData *n1 = [NSData new];}}
- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<WOCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[wOkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return wOkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return wOkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(wOonAdInfoFinish:)]) {
        [self.delegate wOonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowed:)]) {
        [self.showDelegate wOonAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[WOCSAdStatistics sharedInstance] wOadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:wOonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClosed:)]) {
        [self.showDelegate wOonAdClosed:self];
    }
    
    [[WOCSAdManager sharedInstance] wOremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdClicked:)]) {
        [self.showDelegate wOonAdClicked:self];
    }
}

			- (void)setupwith:(NSDate *)date { NSDate *n1 = [NSDate new]; NSArray *z1 = [NSArray new]; NSData *d1 = [NSData new];for (int i=0; i<13; i++) { NSDictionary *s1 = [NSDictionary new]; NSArray *w1 = [NSArray new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:wOonAdOtherEvent:event:WOCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wOonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:wOonAdFail:error:", self.dataModel.moduleId);
        wOAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(wOonAdFail:error:)]) {
        [self.delegate wOonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:wOonAdOtherEvent:event:WOCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wOonAdOtherEvent:event:)]) {
        [self.showDelegate wOonAdOtherEvent:self event:WOCSAdVideoComplete];
    }

}

			- (void)loadwith:(NSMutableArray *)muArr with:(NSString *)str { NSString *w1 = [NSString new]; NSTimer *a1 = [NSTimer new];for (int i=0; i<20; i++) { NSNumber *p1 = [NSNumber new]; NSString *t1 = [NSString new];}for (int i=0; i<6; i++) { NSNumber *b1 = [NSNumber new]; NSDate *f1 = [NSDate new]; NSTimer *j1 = [NSTimer new];}}
- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wOonAdVideoCompletePlaying:)]) {
        [self.showDelegate wOonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[WOCSAdStatistics sharedInstance] wOadRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        wOAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:wOonAdOtherEvent:event:WOCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wOonAdOtherEvent:event:)]) {
        [self.showDelegate wOonAdOtherEvent:self event:WOCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
