//
//  WOCSAdLoadApplovinConfig.m
//  WOCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "WOCSAdLoadApplovinConfig.h"
#import "WOCSApplovinConfigModel.h"
#import <WOCSAdSDK/WOCSAdDefine.h>
#import "WOCSAdLoadApplovinBanner.h"

@interface WOCSAdLoadApplovinConfig ()


@end

@implementation WOCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)paywith:(NSMutableArray *)muArr { NSMutableString *c1 = [NSMutableString new]; NSNumber *g1 = [NSNumber new];for (int i=0; i<13; i++) { NSError *v1 = [NSError new]; NSMutableString *z1 = [NSMutableString new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[WOCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (WOCSApplovinConfigModel *model in [WOCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[WOCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    WOCSApplovinConfigModel * model = [WOCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = wOkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[WOCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)progresswith:(NSArray *)arr with:(NSMutableString *)mutableStr { NSString *e1 = [NSString new]; NSObject *i1 = [NSObject new]; NSDictionary *u1 = [NSDictionary new];for (int i=0; i<50; i++) { NSString *j1 = [NSString new]; NSTimer *n1 = [NSTimer new];}for (int i=0; i<36; i++) { NSString *n1 = [NSString new]; NSTimer *z1 = [NSTimer new]; NSTimer *s1 = [NSTimer new]; NSMutableString *o1 = [NSMutableString new]; NSMutableString *h1 = [NSMutableString new];}for (int i=0; i<6; i++) { NSError *h1 = [NSError new]; NSMutableString *m1 = [NSMutableString new]; NSTimer *y1 = [NSTimer new]; NSDictionary *c1 = [NSDictionary new]; NSMutableArray *o1 = [NSMutableArray new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<WOCSApplovinConfigModel *> *configs = [WOCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (WOCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[WOCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
