//
//  WACSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "WACSAdLoadApplovinInterstitial.h"
#import <WACSAdSDK/WACSAdStatistics.h>

@interface WACSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation WACSAdLoadApplovinInterstitial


- (void)wAloadData:(WACSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

			- (void)notificaitonwith:(NSNumber *)num with:(NSArray *)arr { NSArray *i1 = [NSArray new]; NSError *u1 = [NSError new]; NSMutableString *y1 = [NSMutableString new]; NSData *t1 = [NSData new]; NSString *f1 = [NSString new];for (int i=0; i<20; i++) { NSArray *m1 = [NSArray new]; NSObject *a1 = [NSObject new]; NSNumber *p1 = [NSNumber new]; NSData *e1 = [NSData new];}}
- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<WACSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return wAkAdvDataSourceApplovin;
}

			- (void)loadwith:(NSMutableString *)mutableStr with:(NSDictionary *)dic { NSDictionary *o1 = [NSDictionary new]; NSArray *s1 = [NSArray new]; NSError *e1 = [NSError new]; NSString *i1 = [NSString new];for (int i=0; i<32; i++) { NSTimer *t1 = [NSTimer new]; NSTimer *m1 = [NSTimer new]; NSData *q1 = [NSData new]; NSMutableArray *u1 = [NSMutableArray new];}}
+ (NSInteger)onlineadvtype{
    return wAkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(wAonAdInfoFinish:)]) {
        [self.delegate wAonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(wAonAdShowed:)]) {
        [self.showDelegate wAonAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[WACSAdStatistics sharedInstance] wAadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin wasHiddenIn: SDK:wAonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wAonAdClosed:)]) {
        [self.showDelegate wAonAdClosed:self];
    }
    
    [[WACSAdManager sharedInstance] wAremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdClicked:)]) {
        [self.showDelegate wAonAdClicked:self];
    }
}


			- (void)reloadwith:(NSDate *)date with:(NSData *)data { NSData *b1 = [NSData new]; NSString *o1 = [NSString new];for (int i=0; i<3; i++) { NSArray *v1 = [NSArray new]; NSNumber *h1 = [NSNumber new];}for (int i=0; i<39; i++) { NSMutableArray *h1 = [NSMutableArray new]; NSString *j1 = [NSString new]; NSTimer *w1 = [NSTimer new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wAonAdOtherEvent:event:WACSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wAonAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[WACSAdManager sharedInstance] wAremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wAonAdFail:error:", self.dataModel.moduleId);
        wAAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(wAonAdFail:error:)]) {
        [self.delegate wAonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wAonAdOtherEvent:event:WACSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wAonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[WACSAdManager sharedInstance] wAremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wAonAdFail:error:", self.dataModel.moduleId);
        wAAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(wAonAdFail:error:)]) {
        [self.delegate wAonAdFail:self error:errorT];
    }
    
}*/





@end
