//
//  WACSAdLoadApplovinConfig.m
//  WACSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "WACSAdLoadApplovinConfig.h"
#import "WACSApplovinConfigModel.h"
#import <WACSAdSDK/WACSAdDefine.h>
#import "WACSAdLoadApplovinBanner.h"

@interface WACSAdLoadApplovinConfig ()


@end

@implementation WACSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)reloadwith:(NSError *)err { NSError *f1 = [NSError new]; NSMutableString *j1 = [NSMutableString new]; NSObject *v1 = [NSObject new];for (int i=0; i<25; i++) { NSError *c1 = [NSError new]; NSString *o1 = [NSString new]; NSObject *s1 = [NSObject new]; NSObject *m1 = [NSObject new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[WACSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (WACSApplovinConfigModel *model in [WACSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[WACSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    WACSApplovinConfigModel * model = [WACSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = wAkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[WACSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<WACSApplovinConfigModel *> *configs = [WACSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (WACSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[WACSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
