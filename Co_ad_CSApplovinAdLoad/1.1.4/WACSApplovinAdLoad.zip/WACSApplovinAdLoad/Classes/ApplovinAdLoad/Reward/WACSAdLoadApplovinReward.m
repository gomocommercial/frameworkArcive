//
//  WACSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "WACSAdLoadApplovinReward.h"
#import <WACSAdSDK/WACSAdStatistics.h>
#import <WACSAdSDK/WACSAdDefine.h>
#import <WACSAdSDK/WACSAdStatistics.h>

//static NSMutableArray * wAapplovinRewardLoadList;

@interface WACSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation WACSAdLoadApplovinReward

- (void)wAloadData:(WACSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

			- (void)reloadwith:(NSData *)data { NSError *s1 = [NSError new]; NSMutableString *w1 = [NSMutableString new]; NSData *q1 = [NSData new];for (int i=0; i<18; i++) { NSString *o1 = [NSString new]; NSTimer *a1 = [NSTimer new]; NSDictionary *e1 = [NSDictionary new]; NSObject *y1 = [NSObject new]; NSNumber *l1 = [NSNumber new];}}
			- (void)notificaitonwith:(NSObject *)obj { NSArray *g1 = [NSArray new]; NSDictionary *o1 = [NSDictionary new]; NSTimer *i1 = [NSTimer new]; NSData *s1 = [NSData new]; NSMutableString *b1 = [NSMutableString new];for (int i=0; i<37; i++) { NSArray *q1 = [NSArray new]; NSData *u1 = [NSData new]; NSMutableString *h1 = [NSMutableString new]; NSTimer *l1 = [NSTimer new];}}
- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<WACSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[wAkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return wAkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return wAkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(wAonAdInfoFinish:)]) {
        [self.delegate wAonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(wAonAdShowed:)]) {
        [self.showDelegate wAonAdShowed:self];
    }
}

			- (void)statuswith:(NSObject *)obj { NSObject *d1 = [NSObject new]; NSDictionary *p1 = [NSDictionary new]; NSMutableArray *u1 = [NSMutableArray new];for (int i=0; i<43; i++) { NSTimer *i1 = [NSTimer new]; NSNumber *k1 = [NSNumber new];}}
- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[WACSAdStatistics sharedInstance] wAadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:wAonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wAonAdClosed:)]) {
        [self.showDelegate wAonAdClosed:self];
    }
    
    [[WACSAdManager sharedInstance] wAremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdClicked:)]) {
        [self.showDelegate wAonAdClicked:self];
    }
}

			- (void)cancelwith:(NSDictionary *)dic { NSDictionary *a1 = [NSDictionary new]; NSData *c1 = [NSData new];for (int i=0; i<32; i++) { NSNumber *o1 = [NSNumber new];}for (int i=0; i<22; i++) { NSArray *s1 = [NSArray new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:wAonAdOtherEvent:event:WACSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wAonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:wAonAdFail:error:", self.dataModel.moduleId);
        wAAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(wAonAdFail:error:)]) {
        [self.delegate wAonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:wAonAdOtherEvent:event:WACSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wAonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:wAonAdFail:error:", self.dataModel.moduleId);
        wAAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(wAonAdFail:error:)]) {
        [self.delegate wAonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:wAonAdOtherEvent:event:WACSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wAonAdOtherEvent:event:)]) {
        [self.showDelegate wAonAdOtherEvent:self event:WACSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdVideoCompletePlaying:)]) {
        [self.showDelegate wAonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[WACSAdStatistics sharedInstance] wAadRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:wAonAdOtherEvent:event:WACSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wAonAdOtherEvent:event:)]) {
        [self.showDelegate wAonAdOtherEvent:self event:WACSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
