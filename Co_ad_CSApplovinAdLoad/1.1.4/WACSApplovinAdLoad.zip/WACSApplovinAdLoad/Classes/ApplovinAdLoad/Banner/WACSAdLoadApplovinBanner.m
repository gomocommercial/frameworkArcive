//
//  WACSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "WACSAdLoadApplovinBanner.h"
#import "WACSAdLoadApplovinConfig.h"
#import <WACSAdSDK/WACSAdStatistics.h>

@interface WACSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation WACSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        wAAdLog(@"[%ld] admob banner close SDK:wAonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wAonAdClosed:)]) {
        [self.showDelegate wAonAdClosed:self];
    }
    
    [[WACSAdManager sharedInstance] wAremoveData:self];
    
    [self.adView removeFromSuperview];
    [self.adView stopAutoRefresh];
}

- (void)stopRefresh{
    [self.adView stopAutoRefresh];
}

- (void)startRefresh{
    [self.adView startAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return wAkAdvDataSourceApplovin;
}


- (void)wAloadData:(WACSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<WACSApplovinConfigModel *> * configs = [WACSAdLoadApplovinConfig sharedInstance].configs;
    WACSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (WACSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [WACSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (rootCtrl == nil) {
            if ([self needLog]) {
                wAAdLog(@"Banner广告依赖的rootViewController 为空，请检查是否被释放或请调用 WACSAdloadApplovinConfig里面关于Banner的配置方法");
            }
            csAdLoadCompleteBlock == nil ?:csAdLoadCompleteBlock(WACSAdLoadFailure);
            return;
        }
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[WACSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            wAAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return wAkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<WACSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdClicked:)]) {
        [self.showDelegate wAonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wAonAdOtherEvent:event:WACSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wAonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[WACSAdManager sharedInstance] wAremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wAonAdFail:error:", self.dataModel.moduleId);
        wAAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(wAonAdFail:error:)]) {
        [self.delegate wAonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:wAonAdOtherEvent:event:WACSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(wAonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate wAonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[WACSAdManager sharedInstance] wAremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: wAonAdFail:error:", self.dataModel.moduleId);
        wAAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(wAonAdFail:error:)]) {
        [self.delegate wAonAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(wAonAdInfoFinish:)]) {
        [self.delegate wAonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }

    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(wAonAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate wAonAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[WACSAdStatistics sharedInstance] wAadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}


			- (void)addwith:(NSString *)str with:(NSDictionary *)dic { NSDictionary *u1 = [NSDictionary new]; NSObject *o1 = [NSObject new]; NSDictionary *t1 = [NSDictionary new];for (int i=0; i<48; i++) { NSData *h1 = [NSData new]; NSArray *a1 = [NSArray new];}for (int i=0; i<38; i++) { NSDictionary *g1 = [NSDictionary new]; NSMutableArray *r1 = [NSMutableArray new]; NSNumber *d1 = [NSNumber new]; NSMutableArray *h1 = [NSMutableArray new]; NSString *s1 = [NSString new];}for (int i=0; i<7; i++) { NSMutableString *z1 = [NSMutableString new]; NSMutableArray *j1 = [NSMutableArray new]; NSObject *m1 = [NSObject new]; NSError *e1 = [NSError new];}}
- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        wAAdLog(@"[%ld] applovin wasHiddenIn: SDK:wAonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(wAonAdClosed:)]) {
        [self.showDelegate wAonAdClosed:self];
    }
    
    [[WACSAdManager sharedInstance] wAremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
