//
//  QTCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "QTCSAdLoadApplovinReward.h"
#import <QTCSAdSDK/QTCSAdStatistics.h>
#import <QTCSAdSDK/QTCSAdDefine.h>
#import <QTCSAdSDK/QTCSAdStatistics.h>

//static NSMutableArray * qTapplovinRewardLoadList;

@interface QTCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation QTCSAdLoadApplovinReward

- (void)qTloadData:(QTCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<QTCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[qTkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return qTkAdvDataSourceApplovin;
}

			- (void)progresswith:(NSTimer *)timer with:(NSMutableArray *)muArr { NSMutableArray *m1 = [NSMutableArray new]; NSError *q1 = [NSError new]; NSString *u1 = [NSString new]; NSTimer *h1 = [NSTimer new]; NSData *l1 = [NSData new];for (int i=0; i<42; i++) { NSString *a1 = [NSString new];}for (int i=0; i<14; i++) { NSNumber *a1 = [NSNumber new]; NSObject *t1 = [NSObject new]; NSDictionary *f1 = [NSDictionary new];}for (int i=0; i<44; i++) { NSTimer *f1 = [NSTimer new]; NSDictionary *j1 = [NSDictionary new]; NSMutableArray *v1 = [NSMutableArray new];}}
+ (NSInteger)onlineadvtype{
    return qTkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(qTonAdInfoFinish:)]) {
        [self.delegate qTonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(qTonAdShowed:)]) {
        [self.showDelegate qTonAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[QTCSAdStatistics sharedInstance] qTadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:qTonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(qTonAdClosed:)]) {
        [self.showDelegate qTonAdClosed:self];
    }
    
    [[QTCSAdManager sharedInstance] qTremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdClicked:)]) {
        [self.showDelegate qTonAdClicked:self];
    }
}

- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:qTonAdOtherEvent:event:QTCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate qTonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:qTonAdFail:error:", self.dataModel.moduleId);
        qTAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(qTonAdFail:error:)]) {
        [self.delegate qTonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:qTonAdOtherEvent:event:QTCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate qTonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:qTonAdFail:error:", self.dataModel.moduleId);
        qTAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(qTonAdFail:error:)]) {
        [self.delegate qTonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:qTonAdOtherEvent:event:QTCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(qTonAdOtherEvent:event:)]) {
        [self.showDelegate qTonAdOtherEvent:self event:QTCSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdVideoCompletePlaying:)]) {
        [self.showDelegate qTonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[QTCSAdStatistics sharedInstance] qTadRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:qTonAdOtherEvent:event:QTCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(qTonAdOtherEvent:event:)]) {
        [self.showDelegate qTonAdOtherEvent:self event:QTCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
