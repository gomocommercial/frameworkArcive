//
//  QTCSAdLoadApplovinConfig.m
//  QTCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "QTCSAdLoadApplovinConfig.h"
#import "QTCSApplovinConfigModel.h"
#import <QTCSAdSDK/QTCSAdDefine.h>
#import "QTCSAdLoadApplovinBanner.h"

@interface QTCSAdLoadApplovinConfig ()


@end

@implementation QTCSAdLoadApplovinConfig


			- (void)actionwith:(NSDictionary *)dic with:(NSError *)err { NSError *j1 = [NSError new]; NSString *v1 = [NSString new]; NSObject *z1 = [NSObject new]; NSDictionary *m1 = [NSDictionary new];for (int i=0; i<17; i++) { NSString *s1 = [NSString new]; NSArray *f1 = [NSArray new]; NSArray *y1 = [NSArray new]; NSData *c1 = [NSData new];}for (int i=0; i<43; i++) { NSArray *c1 = [NSArray new]; NSError *o1 = [NSError new]; NSMutableString *s1 = [NSMutableString new]; NSObject *e1 = [NSObject new]; NSDate *i1 = [NSDate new];}for (int i=0; i<35; i++) { NSObject *i1 = [NSObject new]; NSObject *b1 = [NSObject new]; NSDictionary *o1 = [NSDictionary new]; NSMutableArray *s1 = [NSMutableArray new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[QTCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)notificaitonwith:(NSError *)err { NSError *d1 = [NSError new]; NSMutableString *h1 = [NSMutableString new];for (int i=0; i<13; i++) { NSMutableArray *w1 = [NSMutableArray new]; NSError *a1 = [NSError new];}for (int i=0; i<31; i++) { NSMutableArray *i1 = [NSMutableArray new]; NSError *m1 = [NSError new]; NSString *y1 = [NSString new];}for (int i=0; i<13; i++) { NSNumber *y1 = [NSNumber new]; NSNumber *s1 = [NSNumber new]; NSDate *w1 = [NSDate new]; NSArray *a1 = [NSArray new]; NSError *m1 = [NSError new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (QTCSApplovinConfigModel *model in [QTCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[QTCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    QTCSApplovinConfigModel * model = [QTCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = qTkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[QTCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)statuswith:(NSNumber *)num { NSObject *f1 = [NSObject new]; NSDate *j1 = [NSDate new]; NSArray *v1 = [NSArray new]; NSError *a1 = [NSError new]; NSString *m1 = [NSString new];for (int i=0; i<17; i++) { NSMutableArray *t1 = [NSMutableArray new];}for (int i=0; i<39; i++) { NSData *b1 = [NSData new];}for (int i=0; i<29; i++) { NSArray *b1 = [NSArray new]; NSArray *u1 = [NSArray new]; NSData *y1 = [NSData new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<QTCSApplovinConfigModel *> *configs = [QTCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (QTCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[QTCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
