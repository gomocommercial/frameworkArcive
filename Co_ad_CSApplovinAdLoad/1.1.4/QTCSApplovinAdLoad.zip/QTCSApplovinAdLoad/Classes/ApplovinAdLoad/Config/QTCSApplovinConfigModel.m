//
//  QTCSApplovinConfigModel.m
//  QTCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "QTCSApplovinConfigModel.h"

@implementation QTCSApplovinConfigModel

@end
