//
//  QTCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <QTCSAdSDK/QTCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <QTCSAdSDK/QTCSAdLoadProtocol.h>
#import <QTCSAdSDK/QTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QTCSAdLoadApplovinBanner : QTCSAdLoadBanner <QTCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
