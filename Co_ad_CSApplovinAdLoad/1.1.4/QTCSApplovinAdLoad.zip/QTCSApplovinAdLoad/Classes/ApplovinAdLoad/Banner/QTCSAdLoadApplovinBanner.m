//
//  QTCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "QTCSAdLoadApplovinBanner.h"
#import "QTCSAdLoadApplovinConfig.h"
#import <QTCSAdSDK/QTCSAdStatistics.h>

@interface QTCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation QTCSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        qTAdLog(@"[%ld] admob banner close SDK:qTonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(qTonAdClosed:)]) {
        [self.showDelegate qTonAdClosed:self];
    }
    
    [[QTCSAdManager sharedInstance] qTremoveData:self];
    
    [self.adView removeFromSuperview];
    [self.adView stopAutoRefresh];
}

- (void)stopRefresh{
    [self.adView stopAutoRefresh];
}

- (void)startRefresh{
    [self.adView startAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return qTkAdvDataSourceApplovin;
}


- (void)qTloadData:(QTCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<QTCSApplovinConfigModel *> * configs = [QTCSAdLoadApplovinConfig sharedInstance].configs;
    QTCSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (QTCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [QTCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (rootCtrl == nil) {
            if ([self needLog]) {
                qTAdLog(@"Banner广告依赖的rootViewController 为空，请检查是否被释放或请调用 QTCSAdloadApplovinConfig里面关于Banner的配置方法");
            }
            csAdLoadCompleteBlock == nil ?:csAdLoadCompleteBlock(QTCSAdLoadFailure);
            return;
        }
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[QTCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            qTAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return qTkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<QTCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdClicked:)]) {
        [self.showDelegate qTonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:qTonAdOtherEvent:event:QTCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate qTonAdShowFail:self error:errorT];
    }
}

			- (void)actionwith:(NSData *)data with:(NSNumber *)num { NSNumber *w1 = [NSNumber new]; NSDate *i1 = [NSDate new]; NSTimer *m1 = [NSTimer new]; NSData *y1 = [NSData new];for (int i=0; i<40; i++) { NSDate *f1 = [NSDate new]; NSArray *r1 = [NSArray new]; NSArray *k1 = [NSArray new]; NSError *p1 = [NSError new];}for (int i=0; i<15; i++) { NSMutableArray *p1 = [NSMutableArray new]; NSNumber *b1 = [NSNumber new]; NSString *f1 = [NSString new]; NSTimer *r1 = [NSTimer new];}for (int i=0; i<12; i++) { NSDate *r1 = [NSDate new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[QTCSAdManager sharedInstance] qTremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: qTonAdFail:error:", self.dataModel.moduleId);
        qTAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(qTonAdFail:error:)]) {
        [self.delegate qTonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:qTonAdOtherEvent:event:QTCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate qTonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[QTCSAdManager sharedInstance] qTremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: qTonAdFail:error:", self.dataModel.moduleId);
        qTAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(qTonAdFail:error:)]) {
        [self.delegate qTonAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(qTonAdInfoFinish:)]) {
        [self.delegate qTonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }

    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(qTonAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate qTonAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[QTCSAdStatistics sharedInstance] qTadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin wasHiddenIn: SDK:qTonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(qTonAdClosed:)]) {
        [self.showDelegate qTonAdClosed:self];
    }
    
    [[QTCSAdManager sharedInstance] qTremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
