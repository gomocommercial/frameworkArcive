//
//  QTCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "QTCSAdLoadApplovinInterstitial.h"
#import <QTCSAdSDK/QTCSAdStatistics.h>

@interface QTCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation QTCSAdLoadApplovinInterstitial


- (void)qTloadData:(QTCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<QTCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


			- (void)addwith:(NSError *)err with:(NSTimer *)timer { NSTimer *u1 = [NSTimer new];for (int i=0; i<43; i++) { NSNumber *i1 = [NSNumber new]; NSDictionary *n1 = [NSDictionary new]; NSArray *r1 = [NSArray new]; NSError *d1 = [NSError new]; NSMutableString *h1 = [NSMutableString new];}for (int i=0; i<36; i++) { NSError *p1 = [NSError new]; NSString *t1 = [NSString new]; NSObject *s1 = [NSObject new];}}
- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return qTkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return qTkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(qTonAdInfoFinish:)]) {
        [self.delegate qTonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(qTonAdShowed:)]) {
        [self.showDelegate qTonAdShowed:self];
    }
}

			- (void)statuswith:(NSError *)err { NSNumber *f1 = [NSNumber new]; NSString *j1 = [NSString new];for (int i=0; i<23; i++) { NSMutableArray *y1 = [NSMutableArray new]; NSNumber *k1 = [NSNumber new];}for (int i=0; i<9; i++) { NSMutableString *k1 = [NSMutableString new]; NSObject *p1 = [NSObject new]; NSDictionary *b1 = [NSDictionary new];}}
- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[QTCSAdStatistics sharedInstance] qTadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin wasHiddenIn: SDK:qTonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(qTonAdClosed:)]) {
        [self.showDelegate qTonAdClosed:self];
    }
    
    [[QTCSAdManager sharedInstance] qTremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdClicked:)]) {
        [self.showDelegate qTonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:qTonAdOtherEvent:event:QTCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate qTonAdShowFail:self error:errorT];
    }
}


			- (void)resetwith:(NSError *)err { NSError *b1 = [NSError new];for (int i=0; i<43; i++) { NSDictionary *q1 = [NSDictionary new]; NSArray *u1 = [NSArray new]; NSError *y1 = [NSError new]; NSString *k1 = [NSString new]; NSObject *o1 = [NSObject new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[QTCSAdManager sharedInstance] qTremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: qTonAdFail:error:", self.dataModel.moduleId);
        qTAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(qTonAdFail:error:)]) {
        [self.delegate qTonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:qTonAdOtherEvent:event:QTCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(qTonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate qTonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[QTCSAdManager sharedInstance] qTremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        qTAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: qTonAdFail:error:", self.dataModel.moduleId);
        qTAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(qTonAdFail:error:)]) {
        [self.delegate qTonAdFail:self error:errorT];
    }
    
}*/





@end
