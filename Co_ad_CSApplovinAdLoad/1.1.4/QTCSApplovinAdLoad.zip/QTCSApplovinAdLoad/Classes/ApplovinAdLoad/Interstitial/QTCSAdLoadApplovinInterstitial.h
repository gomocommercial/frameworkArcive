//
//  QTCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <QTCSAdSDK/QTCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <QTCSAdSDK/QTCSAdLoadProtocol.h>
#import <QTCSAdSDK/QTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QTCSAdLoadApplovinInterstitial : QTCSAdLoadInterstitial<QTCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
