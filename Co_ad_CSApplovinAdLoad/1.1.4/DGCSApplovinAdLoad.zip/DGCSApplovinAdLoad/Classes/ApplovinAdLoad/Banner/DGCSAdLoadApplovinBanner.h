//
//  DGCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <DGCSAdSDK/DGCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DGCSAdSDK/DGCSAdLoadProtocol.h>
#import <DGCSAdSDK/DGCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DGCSAdLoadApplovinBanner : DGCSAdLoadBanner <DGCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
