//
//  DGCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "DGCSAdLoadApplovinInterstitial.h"
#import <DGCSAdSDK/DGCSAdStatistics.h>

@interface DGCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation DGCSAdLoadApplovinInterstitial


- (void)dGloadData:(DGCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<DGCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return dGkAdvDataSourceApplovin;
}

			- (void)statuswith:(NSDictionary *)dic with:(NSError *)err { NSError *q1 = [NSError new];for (int i=0; i<36; i++) { NSDictionary *f1 = [NSDictionary new]; NSMutableArray *j1 = [NSMutableArray new]; NSNumber *v1 = [NSNumber new]; NSString *z1 = [NSString new]; NSTimer *m1 = [NSTimer new];}for (int i=0; i<28; i++) { NSDate *m1 = [NSDate new]; NSDictionary *f1 = [NSDictionary new];}for (int i=0; i<43; i++) { NSObject *f1 = [NSObject new]; NSMutableString *r1 = [NSMutableString new];}}
+ (NSInteger)onlineadvtype{
    return dGkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(dGonAdInfoFinish:)]) {
        [self.delegate dGonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(dGonAdShowed:)]) {
        [self.showDelegate dGonAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[DGCSAdStatistics sharedInstance] dGadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovin wasHiddenIn: SDK:dGonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dGonAdClosed:)]) {
        [self.showDelegate dGonAdClosed:self];
    }
    
    [[DGCSAdManager sharedInstance] dGremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dGonAdClicked:)]) {
        [self.showDelegate dGonAdClicked:self];
    }
}


			- (void)actionwith:(NSMutableArray *)muArr { NSMutableArray *h1 = [NSMutableArray new]; NSError *l1 = [NSError new]; NSString *s1 = [NSString new]; NSTimer *b1 = [NSTimer new];for (int i=0; i<47; i++) { NSNumber *q1 = [NSNumber new]; NSString *u1 = [NSString new]; NSArray *z1 = [NSArray new]; NSNumber *o1 = [NSNumber new];}for (int i=0; i<48; i++) { NSMutableString *w1 = [NSMutableString new]; NSTimer *a1 = [NSTimer new]; NSDictionary *e1 = [NSDictionary new]; NSMutableArray *q1 = [NSMutableArray new]; NSError *u1 = [NSError new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dGonAdOtherEvent:event:DGCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(dGonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dGonAdShowFail:self error:errorT];
    }
}


			- (void)paywith:(NSData *)data with:(NSNumber *)num { NSNumber *z1 = [NSNumber new]; NSString *d1 = [NSString new];for (int i=0; i<13; i++) { NSMutableString *s1 = [NSMutableString new]; NSNumber *w1 = [NSNumber new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[DGCSAdManager sharedInstance] dGremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dGonAdFail:error:", self.dataModel.moduleId);
        dGAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(dGonAdFail:error:)]) {
        [self.delegate dGonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dGonAdOtherEvent:event:DGCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(dGonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dGonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[DGCSAdManager sharedInstance] dGremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dGonAdFail:error:", self.dataModel.moduleId);
        dGAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(dGonAdFail:error:)]) {
        [self.delegate dGonAdFail:self error:errorT];
    }
    
}*/





@end
