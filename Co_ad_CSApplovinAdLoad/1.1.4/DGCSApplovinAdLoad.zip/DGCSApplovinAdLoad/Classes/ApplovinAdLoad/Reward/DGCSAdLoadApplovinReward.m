//
//  DGCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "DGCSAdLoadApplovinReward.h"
#import <DGCSAdSDK/DGCSAdStatistics.h>
#import <DGCSAdSDK/DGCSAdDefine.h>
#import <DGCSAdSDK/DGCSAdStatistics.h>

//static NSMutableArray * dGapplovinRewardLoadList;

@interface DGCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation DGCSAdLoadApplovinReward

- (void)dGloadData:(DGCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<DGCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[dGkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return dGkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return dGkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(dGonAdInfoFinish:)]) {
        [self.delegate dGonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(dGonAdShowed:)]) {
        [self.showDelegate dGonAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[DGCSAdStatistics sharedInstance] dGadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:dGonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dGonAdClosed:)]) {
        [self.showDelegate dGonAdClosed:self];
    }
    
    [[DGCSAdManager sharedInstance] dGremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dGonAdClicked:)]) {
        [self.showDelegate dGonAdClicked:self];
    }
}

- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:dGonAdOtherEvent:event:DGCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(dGonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dGonAdShowFail:self error:errorT];
    }
}

			- (void)notificaitonwith:(NSDictionary *)dic with:(NSError *)err { NSError *a1 = [NSError new]; NSString *e1 = [NSString new]; NSTimer *q1 = [NSTimer new]; NSDictionary *u1 = [NSDictionary new];for (int i=0; i<48; i++) { NSDate *j1 = [NSDate new]; NSTimer *n1 = [NSTimer new]; NSData *z1 = [NSData new]; NSMutableString *d1 = [NSMutableString new]; NSNumber *h1 = [NSNumber new];}for (int i=0; i<40; i++) { NSMutableString *p1 = [NSMutableString new]; NSMutableString *i1 = [NSMutableString new];}for (int i=0; i<23; i++) { NSError *i1 = [NSError new]; NSString *n1 = [NSString new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:dGonAdFail:error:", self.dataModel.moduleId);
        dGAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(dGonAdFail:error:)]) {
        [self.delegate dGonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:dGonAdOtherEvent:event:DGCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(dGonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dGonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:dGonAdFail:error:", self.dataModel.moduleId);
        dGAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(dGonAdFail:error:)]) {
        [self.delegate dGonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:dGonAdOtherEvent:event:DGCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dGonAdOtherEvent:event:)]) {
        [self.showDelegate dGonAdOtherEvent:self event:DGCSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dGonAdVideoCompletePlaying:)]) {
        [self.showDelegate dGonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[DGCSAdStatistics sharedInstance] dGadRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dGAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:dGonAdOtherEvent:event:DGCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dGonAdOtherEvent:event:)]) {
        [self.showDelegate dGonAdOtherEvent:self event:DGCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
