//
//  DGCSAdLoadApplovinConfig.m
//  DGCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "DGCSAdLoadApplovinConfig.h"
#import "DGCSApplovinConfigModel.h"
#import <DGCSAdSDK/DGCSAdDefine.h>
#import "DGCSAdLoadApplovinBanner.h"

@interface DGCSAdLoadApplovinConfig ()


@end

@implementation DGCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)statuswith:(NSMutableArray *)muArr { NSMutableString *f1 = [NSMutableString new]; NSObject *k1 = [NSObject new];for (int i=0; i<23; i++) { NSData *z1 = [NSData new]; NSString *d1 = [NSString new];}for (int i=0; i<42; i++) { NSNumber *l1 = [NSNumber new]; NSString *p1 = [NSString new]; NSTimer *b1 = [NSTimer new];}for (int i=0; i<42; i++) { NSDate *b1 = [NSDate new];}}
			- (void)resetwith:(NSMutableString *)mutableStr { NSMutableString *j1 = [NSMutableString new]; NSObject *n1 = [NSObject new]; NSDate *r1 = [NSDate new];for (int i=0; i<15; i++) { NSMutableString *g1 = [NSMutableString new]; NSObject *s1 = [NSObject new]; NSDictionary *w1 = [NSDictionary new]; NSArray *b1 = [NSArray new];}for (int i=0; i<43; i++) { NSDictionary *i1 = [NSDictionary new]; NSDictionary *c1 = [NSDictionary new]; NSMutableString *g1 = [NSMutableString new]; NSNumber *k1 = [NSNumber new]; NSDate *w1 = [NSDate new];}for (int i=0; i<33; i++) { NSNumber *w1 = [NSNumber new]; NSDate *a1 = [NSDate new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[DGCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (DGCSApplovinConfigModel *model in [DGCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[DGCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    DGCSApplovinConfigModel * model = [DGCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = dGkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[DGCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)resumewith:(NSMutableString *)mutableStr with:(NSDate *)date { NSDate *f1 = [NSDate new]; NSArray *j1 = [NSArray new];for (int i=0; i<23; i++) { NSObject *y1 = [NSObject new]; NSDictionary *l1 = [NSDictionary new];}for (int i=0; i<9; i++) { NSTimer *k1 = [NSTimer new]; NSData *p1 = [NSData new]; NSMutableString *b1 = [NSMutableString new];}}
			- (void)cancelwith:(NSDate *)date { NSDate *v1 = [NSDate new]; NSArray *h1 = [NSArray new];for (int i=0; i<13; i++) { NSObject *o1 = [NSObject new]; NSDictionary *a1 = [NSDictionary new]; NSArray *f1 = [NSArray new]; NSNumber *r1 = [NSNumber new]; NSNumber *k1 = [NSNumber new];}for (int i=0; i<35; i++) { NSMutableString *k1 = [NSMutableString new];}for (int i=0; i<25; i++) { NSData *k1 = [NSData new]; NSMutableString *w1 = [NSMutableString new]; NSObject *a1 = [NSObject new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<DGCSApplovinConfigModel *> *configs = [DGCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (DGCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[DGCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
