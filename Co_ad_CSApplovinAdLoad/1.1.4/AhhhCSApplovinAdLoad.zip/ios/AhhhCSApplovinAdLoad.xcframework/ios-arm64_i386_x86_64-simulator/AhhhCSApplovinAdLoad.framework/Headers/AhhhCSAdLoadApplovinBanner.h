//
//  AhhhCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadApplovinBanner : AhhhCSAdLoadBanner <AhhhCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
