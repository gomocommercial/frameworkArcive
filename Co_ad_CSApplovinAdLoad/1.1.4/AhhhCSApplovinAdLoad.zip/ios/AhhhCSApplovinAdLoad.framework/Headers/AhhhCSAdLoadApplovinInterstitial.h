//
//  AhhhCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadApplovinInterstitial : AhhhCSAdLoadInterstitial<AhhhCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
