//
//  DPCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "DPCSAdLoadApplovinBanner.h"
#import "DPCSAdLoadApplovinConfig.h"
#import <DPCSAdSDK/DPCSAdStatistics.h>

@interface DPCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation DPCSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        dPAdLog(@"[%ld] admob banner close SDK:dPonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dPonAdClosed:)]) {
        [self.showDelegate dPonAdClosed:self];
    }
    
    [[DPCSAdManager sharedInstance] dPremoveData:self];
    
    [self.adView removeFromSuperview];
    [self.adView stopAutoRefresh];
}

- (void)stopRefresh{
    [self.adView stopAutoRefresh];
}

			- (void)cancelwith:(NSError *)err { NSError *w1 = [NSError new]; NSString *i1 = [NSString new]; NSTimer *m1 = [NSTimer new]; NSDictionary *q1 = [NSDictionary new];for (int i=0; i<40; i++) { NSString *f1 = [NSString new]; NSTimer *r1 = [NSTimer new]; NSData *v1 = [NSData new]; NSMutableArray *a1 = [NSMutableArray new];}for (int i=0; i<18; i++) { NSData *h1 = [NSData new]; NSDate *b1 = [NSDate new]; NSArray *n1 = [NSArray new]; NSError *z1 = [NSError new]; NSMutableString *d1 = [NSMutableString new];}for (int i=0; i<28; i++) { NSError *l1 = [NSError new]; NSString *p1 = [NSString new]; NSObject *u1 = [NSObject new]; NSData *g1 = [NSData new]; NSMutableArray *k1 = [NSMutableArray new];}}
- (void)startRefresh{
    [self.adView startAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return dPkAdvDataSourceApplovin;
}


- (void)dPloadData:(DPCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<DPCSApplovinConfigModel *> * configs = [DPCSAdLoadApplovinConfig sharedInstance].configs;
    DPCSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (DPCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [DPCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (rootCtrl == nil) {
            if ([self needLog]) {
                dPAdLog(@"Banner广告依赖的rootViewController 为空，请检查是否被释放或请调用 DPCSAdloadApplovinConfig里面关于Banner的配置方法");
            }
            csAdLoadCompleteBlock == nil ?:csAdLoadCompleteBlock(DPCSAdLoadFailure);
            return;
        }
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[DPCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            dPAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return dPkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<DPCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdClicked:)]) {
        [self.showDelegate dPonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dPonAdOtherEvent:event:DPCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dPonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[DPCSAdManager sharedInstance] dPremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dPonAdFail:error:", self.dataModel.moduleId);
        dPAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(dPonAdFail:error:)]) {
        [self.delegate dPonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dPonAdOtherEvent:event:DPCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dPonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[DPCSAdManager sharedInstance] dPremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dPonAdFail:error:", self.dataModel.moduleId);
        dPAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(dPonAdFail:error:)]) {
        [self.delegate dPonAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(dPonAdInfoFinish:)]) {
        [self.delegate dPonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }

    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(dPonAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate dPonAdShowed:self];
    }
}

			- (void)addwith:(NSString *)str with:(NSDictionary *)dic { NSDictionary *h1 = [NSDictionary new]; NSMutableArray *t1 = [NSMutableArray new];for (int i=0; i<3; i++) { NSTimer *i1 = [NSTimer new]; NSData *m1 = [NSData new]; NSMutableArray *r1 = [NSMutableArray new]; NSObject *d1 = [NSObject new]; NSObject *w1 = [NSObject new];}}
- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[DPCSAdStatistics sharedInstance] dPadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}


			- (void)resumewith:(NSTimer *)timer with:(NSMutableArray *)muArr { NSMutableArray *r1 = [NSMutableArray new]; NSError *w1 = [NSError new]; NSDate *i1 = [NSDate new]; NSArray *m1 = [NSArray new]; NSData *q1 = [NSData new];for (int i=0; i<48; i++) { NSDate *f1 = [NSDate new]; NSDictionary *y1 = [NSDictionary new];}for (int i=0; i<13; i++) { NSObject *y1 = [NSObject new]; NSDictionary *k1 = [NSDictionary new];}}
- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin wasHiddenIn: SDK:dPonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dPonAdClosed:)]) {
        [self.showDelegate dPonAdClosed:self];
    }
    
    [[DPCSAdManager sharedInstance] dPremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
			- (void)reloadwith:(NSArray *)arr { NSArray *s1 = [NSArray new]; NSData *w1 = [NSData new]; NSMutableString *i1 = [NSMutableString new]; NSNumber *m1 = [NSNumber new]; NSDate *q1 = [NSDate new];for (int i=0; i<32; i++) { NSMutableString *f1 = [NSMutableString new];}}
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
