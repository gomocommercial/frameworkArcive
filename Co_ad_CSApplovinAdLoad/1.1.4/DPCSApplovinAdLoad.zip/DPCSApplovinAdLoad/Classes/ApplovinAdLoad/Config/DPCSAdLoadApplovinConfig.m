//
//  DPCSAdLoadApplovinConfig.m
//  DPCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "DPCSAdLoadApplovinConfig.h"
#import "DPCSApplovinConfigModel.h"
#import <DPCSAdSDK/DPCSAdDefine.h>
#import "DPCSAdLoadApplovinBanner.h"

@interface DPCSAdLoadApplovinConfig ()


@end

@implementation DPCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[DPCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (DPCSApplovinConfigModel *model in [DPCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[DPCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    DPCSApplovinConfigModel * model = [DPCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = dPkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[DPCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)loadwith:(NSTimer *)timer { NSTimer *l1 = [NSTimer new]; NSDictionary *p1 = [NSDictionary new]; NSMutableArray *b1 = [NSMutableArray new]; NSNumber *g1 = [NSNumber new]; NSDate *k1 = [NSDate new];for (int i=0; i<17; i++) { NSMutableString *z1 = [NSMutableString new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<DPCSApplovinConfigModel *> *configs = [DPCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (DPCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[DPCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
