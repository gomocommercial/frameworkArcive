//
//  DPCSApplovinConfigModel.m
//  DPCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "DPCSApplovinConfigModel.h"

@implementation DPCSApplovinConfigModel

@end
