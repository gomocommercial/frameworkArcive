//
//  DPCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "DPCSAdLoadApplovinReward.h"
#import <DPCSAdSDK/DPCSAdStatistics.h>
#import <DPCSAdSDK/DPCSAdDefine.h>
#import <DPCSAdSDK/DPCSAdStatistics.h>

//static NSMutableArray * dPapplovinRewardLoadList;

@interface DPCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation DPCSAdLoadApplovinReward

- (void)dPloadData:(DPCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<DPCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[dPkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

			- (void)loadwith:(NSDictionary *)dic { NSDictionary *m1 = [NSDictionary new]; NSArray *q1 = [NSArray new];for (int i=0; i<8; i++) { NSTimer *f1 = [NSTimer new]; NSDictionary *j1 = [NSDictionary new];}}
+ (NSInteger)advdatasource{
    return dPkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return dPkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(dPonAdInfoFinish:)]) {
        [self.delegate dPonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(dPonAdShowed:)]) {
        [self.showDelegate dPonAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[DPCSAdStatistics sharedInstance] dPadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:dPonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dPonAdClosed:)]) {
        [self.showDelegate dPonAdClosed:self];
    }
    
    [[DPCSAdManager sharedInstance] dPremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdClicked:)]) {
        [self.showDelegate dPonAdClicked:self];
    }
}

			- (void)resumewith:(NSData *)data { NSData *v1 = [NSData new]; NSMutableString *z1 = [NSMutableString new];for (int i=0; i<13; i++) { NSArray *o1 = [NSArray new]; NSError *a1 = [NSError new];}for (int i=0; i<49; i++) { NSMutableArray *a1 = [NSMutableArray new]; NSError *e1 = [NSError new]; NSString *q1 = [NSString new];}for (int i=0; i<31; i++) { NSError *q1 = [NSError new]; NSNumber *j1 = [NSNumber new]; NSDate *o1 = [NSDate new]; NSArray *a1 = [NSArray new]; NSData *e1 = [NSData new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:dPonAdOtherEvent:event:DPCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dPonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:dPonAdFail:error:", self.dataModel.moduleId);
        dPAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(dPonAdFail:error:)]) {
        [self.delegate dPonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:dPonAdOtherEvent:event:DPCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dPonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:dPonAdFail:error:", self.dataModel.moduleId);
        dPAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(dPonAdFail:error:)]) {
        [self.delegate dPonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:dPonAdOtherEvent:event:DPCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dPonAdOtherEvent:event:)]) {
        [self.showDelegate dPonAdOtherEvent:self event:DPCSAdVideoComplete];
    }

}

			- (void)paywith:(NSDictionary *)dic with:(NSNumber *)num { NSNumber *l1 = [NSNumber new]; NSDate *q1 = [NSDate new]; NSArray *c1 = [NSArray new]; NSData *g1 = [NSData new];for (int i=0; i<8; i++) { NSDictionary *v1 = [NSDictionary new]; NSArray *z1 = [NSArray new]; NSArray *s1 = [NSArray new]; NSError *e1 = [NSError new]; NSString *i1 = [NSString new];}for (int i=0; i<47; i++) { NSError *i1 = [NSError new];}}
- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdVideoCompletePlaying:)]) {
        [self.showDelegate dPonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[DPCSAdStatistics sharedInstance] dPadRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:dPonAdOtherEvent:event:DPCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dPonAdOtherEvent:event:)]) {
        [self.showDelegate dPonAdOtherEvent:self event:DPCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
