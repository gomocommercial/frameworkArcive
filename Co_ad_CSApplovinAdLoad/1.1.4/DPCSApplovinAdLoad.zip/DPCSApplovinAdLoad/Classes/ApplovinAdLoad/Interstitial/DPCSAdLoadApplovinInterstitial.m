//
//  DPCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "DPCSAdLoadApplovinInterstitial.h"
#import <DPCSAdSDK/DPCSAdStatistics.h>

@interface DPCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation DPCSAdLoadApplovinInterstitial


- (void)dPloadData:(DPCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<DPCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


			- (void)reloadwith:(NSData *)data with:(NSObject *)obj { NSObject *c1 = [NSObject new]; NSDictionary *o1 = [NSDictionary new]; NSArray *s1 = [NSArray new]; NSError *e1 = [NSError new];for (int i=0; i<10; i++) { NSDictionary *l1 = [NSDictionary new]; NSTimer *t1 = [NSTimer new]; NSNumber *a1 = [NSNumber new]; NSDate *m1 = [NSDate new];}for (int i=0; i<37; i++) { NSNumber *m1 = [NSNumber new];}for (int i=0; i<9; i++) { NSMutableString *m1 = [NSMutableString new]; NSObject *y1 = [NSObject new]; NSObject *r1 = [NSObject new];}}
- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return dPkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return dPkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(dPonAdInfoFinish:)]) {
        [self.delegate dPonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(dPonAdShowed:)]) {
        [self.showDelegate dPonAdShowed:self];
    }
}

			- (void)paywith:(NSObject *)obj with:(NSMutableArray *)muArr { NSMutableArray *m1 = [NSMutableArray new]; NSNumber *y1 = [NSNumber new]; NSDate *c1 = [NSDate new]; NSTimer *g1 = [NSTimer new];for (int i=0; i<20; i++) { NSNumber *v1 = [NSNumber new]; NSDate *h1 = [NSDate new]; NSArray *l1 = [NSArray new]; NSData *q1 = [NSData new];}for (int i=0; i<48; i++) { NSDate *e1 = [NSDate new]; NSArray *r1 = [NSArray new]; NSNumber *v1 = [NSNumber new]; NSString *z1 = [NSString new]; NSTimer *l1 = [NSTimer new];}for (int i=0; i<38; i++) { NSString *l1 = [NSString new]; NSTimer *s1 = [NSTimer new];}}
- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[DPCSAdStatistics sharedInstance] dPadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin wasHiddenIn: SDK:dPonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dPonAdClosed:)]) {
        [self.showDelegate dPonAdClosed:self];
    }
    
    [[DPCSAdManager sharedInstance] dPremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdClicked:)]) {
        [self.showDelegate dPonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dPonAdOtherEvent:event:DPCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dPonAdShowFail:self error:errorT];
    }
}


			- (void)statuswith:(NSString *)str with:(NSDictionary *)dic { NSDictionary *q1 = [NSDictionary new]; NSMutableArray *c1 = [NSMutableArray new]; NSError *g1 = [NSError new];for (int i=0; i<20; i++) { NSDictionary *v1 = [NSDictionary new]; NSMutableArray *z1 = [NSMutableArray new]; NSNumber *m1 = [NSNumber new]; NSObject *f1 = [NSObject new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[DPCSAdManager sharedInstance] dPremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dPonAdFail:error:", self.dataModel.moduleId);
        dPAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(dPonAdFail:error:)]) {
        [self.delegate dPonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dPonAdOtherEvent:event:DPCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(dPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dPonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[DPCSAdManager sharedInstance] dPremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dPAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dPonAdFail:error:", self.dataModel.moduleId);
        dPAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(dPonAdFail:error:)]) {
        [self.delegate dPonAdFail:self error:errorT];
    }
    
}*/





@end
