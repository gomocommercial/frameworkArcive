//
//  SLCSAdLoadApplovinConfig.m
//  SLCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "SLCSAdLoadApplovinConfig.h"
#import "SLCSApplovinConfigModel.h"
#import <SLCSAdSDK/SLCSAdDefine.h>
#import "SLCSAdLoadApplovinBanner.h"

@interface SLCSAdLoadApplovinConfig ()


@end

@implementation SLCSAdLoadApplovinConfig


			- (void)actionwith:(NSData *)data { NSData *h1 = [NSData new]; NSMutableString *l1 = [NSMutableString new];for (int i=0; i<15; i++) { NSArray *a1 = [NSArray new]; NSData *e1 = [NSData new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

			- (void)loadwith:(NSError *)err with:(NSObject *)obj { NSTimer *w1 = [NSTimer new]; NSDictionary *a1 = [NSDictionary new]; NSMutableArray *e1 = [NSMutableArray new]; NSNumber *q1 = [NSNumber new]; NSString *u1 = [NSString new];for (int i=0; i<38; i++) { NSMutableArray *j1 = [NSMutableArray new]; NSNumber *n1 = [NSNumber new];}for (int i=0; i<6; i++) { NSMutableString *v1 = [NSMutableString new]; NSNumber *z1 = [NSNumber new]; NSDate *m1 = [NSDate new];}for (int i=0; i<6; i++) { NSObject *l1 = [NSObject new]; NSObject *f1 = [NSObject new]; NSDictionary *j1 = [NSDictionary new]; NSMutableArray *v1 = [NSMutableArray new]; NSNumber *z1 = [NSNumber new];}}
+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[SLCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (SLCSApplovinConfigModel *model in [SLCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[SLCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    SLCSApplovinConfigModel * model = [SLCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = sLkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[SLCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)setupwith:(NSDictionary *)dic with:(NSError *)err { NSError *j1 = [NSError new]; NSMutableString *n1 = [NSMutableString new];for (int i=0; i<23; i++) { NSMutableArray *c1 = [NSMutableArray new]; NSError *h1 = [NSError new];}for (int i=0; i<41; i++) { NSMutableArray *p1 = [NSMutableArray new]; NSNumber *t1 = [NSNumber new]; NSDate *f1 = [NSDate new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<SLCSApplovinConfigModel *> *configs = [SLCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (SLCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[SLCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
