//
//  CCCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <CCCSAdSDK/CCCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CCCSAdSDK/CCCSAdLoadProtocol.h>
#import <CCCSAdSDK/CCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CCCSAdLoadApplovinBanner : CCCSAdLoadBanner <CCCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
