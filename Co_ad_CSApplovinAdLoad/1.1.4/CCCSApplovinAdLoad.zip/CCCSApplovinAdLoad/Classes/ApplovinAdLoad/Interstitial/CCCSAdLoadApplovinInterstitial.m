//
//  CCCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "CCCSAdLoadApplovinInterstitial.h"
#import <CCCSAdSDK/CCCSAdStatistics.h>

@interface CCCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation CCCSAdLoadApplovinInterstitial


- (void)cCloadData:(CCCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<CCCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return cCkAdvDataSourceApplovin;
}

			- (void)statuswith:(NSDate *)date with:(NSError *)err { NSError *q1 = [NSError new]; NSMutableString *u1 = [NSMutableString new]; NSObject *g1 = [NSObject new]; NSDate *k1 = [NSDate new];for (int i=0; i<2; i++) { NSString *z1 = [NSString new]; NSObject *e1 = [NSObject new]; NSObject *s1 = [NSObject new]; NSData *j1 = [NSData new];}for (int i=0; i<28; i++) { NSArray *j1 = [NSArray new]; NSData *n1 = [NSData new]; NSMutableString *z1 = [NSMutableString new]; NSNumber *d1 = [NSNumber new];}for (int i=0; i<24; i++) { NSMutableString *d1 = [NSMutableString new]; NSObject *p1 = [NSObject new]; NSDate *t1 = [NSDate new];}}
+ (NSInteger)onlineadvtype{
    return cCkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(cConAdInfoFinish:)]) {
        [self.delegate cConAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(cConAdShowed:)]) {
        [self.showDelegate cConAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[CCCSAdStatistics sharedInstance] cCadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin wasHiddenIn: SDK:cConAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cConAdClosed:)]) {
        [self.showDelegate cConAdClosed:self];
    }
    
    [[CCCSAdManager sharedInstance] cCremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cConAdClicked:)]) {
        [self.showDelegate cConAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:cConAdOtherEvent:event:CCCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(cConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cConAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[CCCSAdManager sharedInstance] cCremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: cConAdFail:error:", self.dataModel.moduleId);
        cCAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(cConAdFail:error:)]) {
        [self.delegate cConAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:cConAdOtherEvent:event:CCCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(cConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cConAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[CCCSAdManager sharedInstance] cCremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: cConAdFail:error:", self.dataModel.moduleId);
        cCAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(cConAdFail:error:)]) {
        [self.delegate cConAdFail:self error:errorT];
    }
    
}*/





@end
