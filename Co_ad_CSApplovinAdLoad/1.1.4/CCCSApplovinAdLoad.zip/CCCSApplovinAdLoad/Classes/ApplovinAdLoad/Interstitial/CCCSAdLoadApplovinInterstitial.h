//
//  CCCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CCCSAdSDK/CCCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CCCSAdSDK/CCCSAdLoadProtocol.h>
#import <CCCSAdSDK/CCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CCCSAdLoadApplovinInterstitial : CCCSAdLoadInterstitial<CCCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
