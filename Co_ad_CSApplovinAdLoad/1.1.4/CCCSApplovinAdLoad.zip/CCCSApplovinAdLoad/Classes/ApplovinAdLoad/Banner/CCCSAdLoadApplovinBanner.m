//
//  CCCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "CCCSAdLoadApplovinBanner.h"
#import "CCCSAdLoadApplovinConfig.h"
#import <CCCSAdSDK/CCCSAdStatistics.h>

@interface CCCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation CCCSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        cCAdLog(@"[%ld] admob banner close SDK:cConAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cConAdClosed:)]) {
        [self.showDelegate cConAdClosed:self];
    }
    
    [[CCCSAdManager sharedInstance] cCremoveData:self];
    
    [self.adView removeFromSuperview];
    [self.adView stopAutoRefresh];
}

- (void)stopRefresh{
    [self.adView stopAutoRefresh];
}

- (void)startRefresh{
    [self.adView startAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return cCkAdvDataSourceApplovin;
}


- (void)cCloadData:(CCCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<CCCSApplovinConfigModel *> * configs = [CCCSAdLoadApplovinConfig sharedInstance].configs;
    CCCSApplovinConfigModel * configT = nil;
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (CCCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [CCCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId] && config.isLoadedBanner == false) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            configT = config;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (rootCtrl == nil) {
            if ([self needLog]) {
                cCAdLog(@"Banner广告依赖的rootViewController 为空，请检查是否被释放或请调用 CCCSAdloadApplovinConfig里面关于Banner的配置方法");
            }
            csAdLoadCompleteBlock == nil ?:csAdLoadCompleteBlock(CCCSAdLoadFailure);
            return;
        }
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[CCCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            cCAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        configT.isLoadedBanner = true;
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return cCkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<CCCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cConAdClicked:)]) {
        [self.showDelegate cConAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:cConAdOtherEvent:event:CCCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cConAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[CCCSAdManager sharedInstance] cCremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: cConAdFail:error:", self.dataModel.moduleId);
        cCAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(cConAdFail:error:)]) {
        [self.delegate cConAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:cConAdOtherEvent:event:CCCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cConAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[CCCSAdManager sharedInstance] cCremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: cConAdFail:error:", self.dataModel.moduleId);
        cCAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(cConAdFail:error:)]) {
        [self.delegate cConAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(cConAdInfoFinish:)]) {
        [self.delegate cConAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }

    [self getRevenueWithAd:ad];
    if ([self.showDelegate respondsToSelector:@selector(cConAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate cConAdShowed:self];
    }
}

- (void)getRevenueWithAd:(nonnull MAAd *)ad{
    double revenue = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(revenue).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    NSString * remark = [NSString stringWithFormat:@"%.10f#USD",revenue];
    [[CCCSAdStatistics sharedInstance] cCadUploadRevenueStatistic:self.dataModel revenue:remark nextCodeId:@""];
}


			- (void)loadwith:(NSMutableArray *)muArr with:(NSDate *)date { NSDate *o1 = [NSDate new]; NSArray *a1 = [NSArray new];for (int i=0; i<44; i++) { NSObject *h1 = [NSObject new];}for (int i=0; i<16; i++) { NSString *p1 = [NSString new]; NSObject *t1 = [NSObject new]; NSDictionary *f1 = [NSDictionary new];}}
- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        cCAdLog(@"[%ld] applovin wasHiddenIn: SDK:cConAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cConAdClosed:)]) {
        [self.showDelegate cConAdClosed:self];
    }
    
    [[CCCSAdManager sharedInstance] cCremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

			- (void)paywith:(NSArray *)arr with:(NSMutableString *)mutableStr { NSMutableString *l1 = [NSMutableString new]; NSObject *s1 = [NSObject new];for (int i=0; i<3; i++) { NSError *e1 = [NSError new]; NSString *r1 = [NSString new];}}
- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
