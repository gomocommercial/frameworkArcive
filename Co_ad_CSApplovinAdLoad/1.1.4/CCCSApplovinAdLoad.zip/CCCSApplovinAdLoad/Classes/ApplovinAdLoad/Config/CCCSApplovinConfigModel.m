//
//  CCCSApplovinConfigModel.m
//  CCCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "CCCSApplovinConfigModel.h"

@implementation CCCSApplovinConfigModel

@end
