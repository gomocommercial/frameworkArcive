//
//  CCCSAdLoadApplovinConfig.m
//  CCCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "CCCSAdLoadApplovinConfig.h"
#import "CCCSApplovinConfigModel.h"
#import <CCCSAdSDK/CCCSAdDefine.h>
#import "CCCSAdLoadApplovinBanner.h"

@interface CCCSAdLoadApplovinConfig ()


@end

@implementation CCCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)actionwith:(NSTimer *)timer { NSArray *l1 = [NSArray new]; NSData *q1 = [NSData new];for (int i=0; i<23; i++) { NSDate *e1 = [NSDate new]; NSMutableArray *r1 = [NSMutableArray new];}for (int i=0; i<9; i++) { NSDictionary *r1 = [NSDictionary new]; NSMutableArray *v1 = [NSMutableArray new]; NSNumber *h1 = [NSNumber new];}for (int i=0; i<42; i++) { NSMutableArray *h1 = [NSMutableArray new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

			- (void)notificaitonwith:(NSMutableArray *)muArr with:(NSString *)str { NSString *a1 = [NSString new];for (int i=0; i<8; i++) { NSMutableString *p1 = [NSMutableString new]; NSNumber *t1 = [NSNumber new]; NSDate *f1 = [NSDate new]; NSTimer *j1 = [NSTimer new]; NSData *o1 = [NSData new];}}
+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[CCCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)cancelwith:(NSString *)str { NSString *m1 = [NSString new]; NSTimer *q1 = [NSTimer new]; NSDictionary *u1 = [NSDictionary new];for (int i=0; i<40; i++) { NSString *j1 = [NSString new]; NSTimer *v1 = [NSTimer new]; NSData *z1 = [NSData new]; NSMutableArray *d1 = [NSMutableArray new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");
    for (CCCSApplovinConfigModel *model in [CCCSAdLoadApplovinConfig sharedInstance].configs) {
        if (model.moudleID == modudleID) {
            [[CCCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
    CCCSApplovinConfigModel * model = [CCCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = cCkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[CCCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    NSMutableArray<CCCSApplovinConfigModel *> *configs = [CCCSAdLoadApplovinConfig sharedInstance].configs;
    NSArray *array = [NSArray arrayWithArray:configs];
    for (CCCSApplovinConfigModel * model in array) {
        if ([model.moudleID isEqualToString:moduleID] && model.isLoadedBanner == true) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            [[CCCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
        }
    }
}

@end
