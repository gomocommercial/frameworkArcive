//
//  PSCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PSCSAdSDK/PSCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PSCSAdSDK/PSCSAdLoadProtocol.h>
#import <PSCSAdSDK/PSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSCSAdLoadApplovinBanner : PSCSAdLoadBanner <PSCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
