//
//  PFCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PFCSAdSDK/PFCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PFCSAdSDK/PFCSAdLoadProtocol.h>
#import <PFCSAdSDK/PFCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PFCSAdLoadApplovinOpen : PFCSAdLoadOpen <PFCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
