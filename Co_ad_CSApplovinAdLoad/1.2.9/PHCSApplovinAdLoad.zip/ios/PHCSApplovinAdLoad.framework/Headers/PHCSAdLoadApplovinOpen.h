//
//  PHCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PHCSAdSDK/PHCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PHCSAdSDK/PHCSAdLoadProtocol.h>
#import <PHCSAdSDK/PHCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PHCSAdLoadApplovinOpen : PHCSAdLoadOpen <PHCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
