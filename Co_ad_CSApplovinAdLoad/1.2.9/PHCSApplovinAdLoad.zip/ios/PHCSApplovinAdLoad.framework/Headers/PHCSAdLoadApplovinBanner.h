//
//  PHCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PHCSAdSDK/PHCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PHCSAdSDK/PHCSAdLoadProtocol.h>
#import <PHCSAdSDK/PHCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PHCSAdLoadApplovinBanner : PHCSAdLoadBanner <PHCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
