//
//  PTCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PTCSAdSDK/PTCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PTCSAdSDK/PTCSAdLoadProtocol.h>
#import <PTCSAdSDK/PTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PTCSAdLoadApplovinBanner : PTCSAdLoadBanner <PTCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
