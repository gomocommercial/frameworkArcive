//
//  PTCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PTCSAdSDK/PTCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PTCSAdSDK/PTCSAdLoadProtocol.h>
#import <PTCSAdSDK/PTCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PTCSAdLoadApplovinReward : PTCSAdLoadReward<PTCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
