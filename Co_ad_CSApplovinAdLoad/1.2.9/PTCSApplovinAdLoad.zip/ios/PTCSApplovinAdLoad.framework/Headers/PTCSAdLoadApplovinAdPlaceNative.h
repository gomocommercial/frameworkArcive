//
//  PTCSAdLoadApplovinAdPlaceNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <PTCSAdSDK/PTCSAdLoadNative.h>
#import <PTCSAdSDK/PTCSAdLoadProtocol.h>
#import <PTCSAdSDK/PTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PTCSAdLoadApplovinAdPlaceNative : PTCSAdLoadNative<PTCSAdLoadProtocol,MAAdPlacerDelegate>

@property(nonatomic, strong) MATableViewAdPlacer *adTablePlacer;
@property(nonatomic, strong) MACollectionViewAdPlacer *adCollectionPlacer;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
