//
//  PTCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PTCSAdSDK/PTCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PTCSAdSDK/PTCSAdLoadProtocol.h>
#import <PTCSAdSDK/PTCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PTCSAdLoadApplovinOpen : PTCSAdLoadOpen <PTCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
