//
//  SJCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <SJCSAdSDK/SJCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SJCSAdSDK/SJCSAdLoadProtocol.h>
#import <SJCSAdSDK/SJCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface SJCSAdLoadApplovinOpen : SJCSAdLoadOpen <SJCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
