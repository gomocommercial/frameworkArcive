//
//  SJCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <SJCSAdSDK/SJCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SJCSAdSDK/SJCSAdLoadProtocol.h>
#import <SJCSAdSDK/SJCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJCSAdLoadApplovinBanner : SJCSAdLoadBanner <SJCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
