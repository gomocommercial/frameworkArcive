//
//  OFCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <OFCSAdSDK/OFCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <OFCSAdSDK/OFCSAdLoadProtocol.h>
#import <OFCSAdSDK/OFCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface OFCSAdLoadApplovinOpen : OFCSAdLoadOpen <OFCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
