//
//  OFCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <OFCSAdSDK/OFCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <OFCSAdSDK/OFCSAdLoadProtocol.h>
#import <OFCSAdSDK/OFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface OFCSAdLoadApplovinBanner : OFCSAdLoadBanner <OFCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
