//
//  SKCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <SKCSAdSDK/SKCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SKCSAdSDK/SKCSAdLoadProtocol.h>
#import <SKCSAdSDK/SKCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface SKCSAdLoadApplovinOpen : SKCSAdLoadOpen <SKCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
