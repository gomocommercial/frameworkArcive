//
//  MEETAICSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <MEETAICSAdSDK/MEETAICSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadProtocol.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MEETAICSAdLoadApplovinBanner : MEETAICSAdLoadBanner <MEETAICSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
