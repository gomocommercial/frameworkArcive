//
//  FSLPCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FSLPCSAdSDK/FSLPCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadProtocol.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadApplovinInterstitial : FSLPCSAdLoadInterstitial<FSLPCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
