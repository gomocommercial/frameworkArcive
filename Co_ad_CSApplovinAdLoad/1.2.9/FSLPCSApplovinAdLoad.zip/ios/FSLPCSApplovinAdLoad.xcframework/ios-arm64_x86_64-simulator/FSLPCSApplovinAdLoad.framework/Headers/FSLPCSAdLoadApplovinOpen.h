//
//  FSLPCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FSLPCSAdSDK/FSLPCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadProtocol.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadApplovinOpen : FSLPCSAdLoadOpen <FSLPCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
