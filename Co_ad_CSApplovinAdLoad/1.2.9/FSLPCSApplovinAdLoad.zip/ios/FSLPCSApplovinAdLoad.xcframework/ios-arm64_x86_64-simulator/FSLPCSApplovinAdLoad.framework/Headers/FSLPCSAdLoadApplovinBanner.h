//
//  FSLPCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <FSLPCSAdSDK/FSLPCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadProtocol.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadApplovinBanner : FSLPCSAdLoadBanner <FSLPCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
