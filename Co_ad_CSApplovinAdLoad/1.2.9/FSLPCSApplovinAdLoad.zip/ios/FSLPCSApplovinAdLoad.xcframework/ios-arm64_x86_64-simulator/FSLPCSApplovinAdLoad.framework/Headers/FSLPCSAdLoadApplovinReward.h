//
//  FSLPCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FSLPCSAdSDK/FSLPCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadProtocol.h>
#import <FSLPCSAdSDK/FSLPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSAdLoadApplovinReward : FSLPCSAdLoadReward<FSLPCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
