//
//  HSCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <HSCSAdSDK/HSCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <HSCSAdSDK/HSCSAdLoadProtocol.h>
#import <HSCSAdSDK/HSCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface HSCSAdLoadApplovinOpen : HSCSAdLoadOpen <HSCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
