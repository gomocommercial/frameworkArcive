//
//  HSCSAdLoadApplovinTemplatesNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <HSCSAdSDK/HSCSAdLoadNative.h>
#import <HSCSAdSDK/HSCSAdLoadProtocol.h>
#import <HSCSAdSDK/HSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface HSCSAdLoadApplovinTemplatesNative : HSCSAdLoadNative<HSCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;
@property (nonatomic, strong) UIView *nativeAdView;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
