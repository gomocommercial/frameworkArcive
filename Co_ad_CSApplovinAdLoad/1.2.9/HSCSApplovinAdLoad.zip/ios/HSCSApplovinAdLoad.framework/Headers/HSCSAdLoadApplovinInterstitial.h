//
//  HSCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <HSCSAdSDK/HSCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <HSCSAdSDK/HSCSAdLoadProtocol.h>
#import <HSCSAdSDK/HSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface HSCSAdLoadApplovinInterstitial : HSCSAdLoadInterstitial<HSCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
