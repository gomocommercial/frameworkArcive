//
//  MACUCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <MACUCSAdSDK/MACUCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MACUCSAdSDK/MACUCSAdLoadProtocol.h>
#import <MACUCSAdSDK/MACUCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MACUCSAdLoadApplovinBanner : MACUCSAdLoadBanner <MACUCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
