//
//  NCCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <NCCSAdSDK/NCCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <NCCSAdSDK/NCCSAdLoadProtocol.h>
#import <NCCSAdSDK/NCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface NCCSAdLoadApplovinOpen : NCCSAdLoadOpen <NCCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
