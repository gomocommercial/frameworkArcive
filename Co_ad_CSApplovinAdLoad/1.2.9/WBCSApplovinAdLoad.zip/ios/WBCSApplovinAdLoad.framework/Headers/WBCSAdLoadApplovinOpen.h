//
//  WBCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <WBCSAdSDK/WBCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <WBCSAdSDK/WBCSAdLoadProtocol.h>
#import <WBCSAdSDK/WBCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface WBCSAdLoadApplovinOpen : WBCSAdLoadOpen <WBCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
