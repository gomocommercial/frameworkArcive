//
//  WBCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <WBCSAdSDK/WBCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <WBCSAdSDK/WBCSAdLoadProtocol.h>
#import <WBCSAdSDK/WBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface WBCSAdLoadApplovinBanner : WBCSAdLoadBanner <WBCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
