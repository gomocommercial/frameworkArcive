//
//  LTCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <LTCSAdSDK/LTCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LTCSAdSDK/LTCSAdLoadProtocol.h>
#import <LTCSAdSDK/LTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LTCSAdLoadApplovinBanner : LTCSAdLoadBanner <LTCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
