//
//  VPCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <VPCSAdSDK/VPCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <VPCSAdSDK/VPCSAdLoadProtocol.h>
#import <VPCSAdSDK/VPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface VPCSAdLoadApplovinInterstitial : VPCSAdLoadInterstitial<VPCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
