//
//  VPCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <VPCSAdSDK/VPCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <VPCSAdSDK/VPCSAdLoadProtocol.h>
#import <VPCSAdSDK/VPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface VPCSAdLoadApplovinBanner : VPCSAdLoadBanner <VPCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
