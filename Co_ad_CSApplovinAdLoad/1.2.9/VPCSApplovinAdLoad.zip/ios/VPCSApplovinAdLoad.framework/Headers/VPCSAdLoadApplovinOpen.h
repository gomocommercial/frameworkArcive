//
//  VPCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <VPCSAdSDK/VPCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <VPCSAdSDK/VPCSAdLoadProtocol.h>
#import <VPCSAdSDK/VPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface VPCSAdLoadApplovinOpen : VPCSAdLoadOpen <VPCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
