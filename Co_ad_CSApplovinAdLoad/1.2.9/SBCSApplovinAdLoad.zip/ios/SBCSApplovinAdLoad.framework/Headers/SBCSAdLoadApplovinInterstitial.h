//
//  SBCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SBCSAdSDK/SBCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SBCSAdSDK/SBCSAdLoadProtocol.h>
#import <SBCSAdSDK/SBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SBCSAdLoadApplovinInterstitial : SBCSAdLoadInterstitial<SBCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
