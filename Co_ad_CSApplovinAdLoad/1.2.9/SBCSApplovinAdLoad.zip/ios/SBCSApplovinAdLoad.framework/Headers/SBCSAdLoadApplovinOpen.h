//
//  SBCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <SBCSAdSDK/SBCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SBCSAdSDK/SBCSAdLoadProtocol.h>
#import <SBCSAdSDK/SBCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface SBCSAdLoadApplovinOpen : SBCSAdLoadOpen <SBCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
