//
//  SBCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <SBCSAdSDK/SBCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SBCSAdSDK/SBCSAdLoadProtocol.h>
#import <SBCSAdSDK/SBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SBCSAdLoadApplovinBanner : SBCSAdLoadBanner <SBCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
