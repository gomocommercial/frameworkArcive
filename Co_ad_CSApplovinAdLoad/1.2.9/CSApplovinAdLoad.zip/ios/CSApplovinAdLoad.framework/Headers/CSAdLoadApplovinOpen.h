//
//  CSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CSAdSDK/CSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadApplovinOpen : CSAdLoadOpen <CSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
