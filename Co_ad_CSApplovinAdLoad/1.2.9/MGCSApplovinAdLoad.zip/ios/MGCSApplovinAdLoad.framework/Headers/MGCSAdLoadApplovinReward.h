//
//  MGCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MGCSAdSDK/MGCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MGCSAdSDK/MGCSAdLoadProtocol.h>
#import <MGCSAdSDK/MGCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MGCSAdLoadApplovinReward : MGCSAdLoadReward<MGCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
