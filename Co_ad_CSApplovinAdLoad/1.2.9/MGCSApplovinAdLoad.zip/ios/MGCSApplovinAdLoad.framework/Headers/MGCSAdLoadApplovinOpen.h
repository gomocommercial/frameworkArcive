//
//  MGCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MGCSAdSDK/MGCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MGCSAdSDK/MGCSAdLoadProtocol.h>
#import <MGCSAdSDK/MGCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MGCSAdLoadApplovinOpen : MGCSAdLoadOpen <MGCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
