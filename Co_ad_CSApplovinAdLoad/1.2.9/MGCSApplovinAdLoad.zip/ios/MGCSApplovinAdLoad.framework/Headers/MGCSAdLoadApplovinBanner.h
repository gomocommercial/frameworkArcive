//
//  MGCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <MGCSAdSDK/MGCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MGCSAdSDK/MGCSAdLoadProtocol.h>
#import <MGCSAdSDK/MGCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGCSAdLoadApplovinBanner : MGCSAdLoadBanner <MGCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
