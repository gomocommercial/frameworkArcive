//
//  CSCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CSCSAdSDK/CSCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSCSAdSDK/CSCSAdLoadProtocol.h>
#import <CSCSAdSDK/CSCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CSCSAdLoadApplovinOpen : CSCSAdLoadOpen <CSCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
