//
//  AWCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <AWCSAdSDK/AWCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AWCSAdSDK/AWCSAdLoadProtocol.h>
#import <AWCSAdSDK/AWCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadApplovinOpen : AWCSAdLoadOpen <AWCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
