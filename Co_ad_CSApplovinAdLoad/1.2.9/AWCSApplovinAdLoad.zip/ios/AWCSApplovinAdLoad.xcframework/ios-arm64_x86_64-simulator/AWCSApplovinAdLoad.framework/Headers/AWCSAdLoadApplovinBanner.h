//
//  AWCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <AWCSAdSDK/AWCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AWCSAdSDK/AWCSAdLoadProtocol.h>
#import <AWCSAdSDK/AWCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadApplovinBanner : AWCSAdLoadBanner <AWCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
