//
//  SKCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SKCSAdSDK/SKCSAdLoadReward.h>
#import <SKCSAdSDK/SKCSAdLoadProtocol.h>
#import <SKCSAdSDK/SKCSAdLoadShowProtocol.h>
#import <AppLovinSDK/AppLovinSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface SKCSAdLoadApplovinReward : SKCSAdLoadReward<SKCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
