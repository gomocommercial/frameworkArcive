//
//  FSPCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FSPCSAdSDK/FSPCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FSPCSAdSDK/FSPCSAdLoadProtocol.h>
#import <FSPCSAdSDK/FSPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSPCSAdLoadApplovinInterstitial : FSPCSAdLoadInterstitial<FSPCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
