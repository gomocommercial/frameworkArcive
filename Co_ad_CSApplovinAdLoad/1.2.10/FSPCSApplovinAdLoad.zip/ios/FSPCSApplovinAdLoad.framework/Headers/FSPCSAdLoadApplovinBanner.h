//
//  FSPCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <FSPCSAdSDK/FSPCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FSPCSAdSDK/FSPCSAdLoadProtocol.h>
#import <FSPCSAdSDK/FSPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSPCSAdLoadApplovinBanner : FSPCSAdLoadBanner <FSPCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
