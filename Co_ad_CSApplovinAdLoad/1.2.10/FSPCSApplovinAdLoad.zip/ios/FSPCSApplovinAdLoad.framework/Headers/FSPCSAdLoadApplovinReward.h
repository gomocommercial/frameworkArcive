//
//  FSPCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FSPCSAdSDK/FSPCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FSPCSAdSDK/FSPCSAdLoadProtocol.h>
#import <FSPCSAdSDK/FSPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FSPCSAdLoadApplovinReward : FSPCSAdLoadReward<FSPCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
