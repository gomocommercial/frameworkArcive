//
//  FSPCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FSPCSAdSDK/FSPCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FSPCSAdSDK/FSPCSAdLoadProtocol.h>
#import <FSPCSAdSDK/FSPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FSPCSAdLoadApplovinOpen : FSPCSAdLoadOpen <FSPCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
