//
//  PPP_PCSApplovinConfigModel.h
//  PPP_PCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class PPP_PCSAdLoadApplovinBanner;
@class  MANativeAdView;

@interface PPP_PCSApplovinConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;

//Banner
@property (nonatomic, assign) CGPoint bannerPosition;
@property (nonatomic, weak) UIViewController *rootViewController;
@property (nonatomic, copy) UIColor *backgroundColor;
/**
 是否展示在自定义额的view上，为true时传入的rootViewController将失效，banner将被添加在show方法传入的对象上
 */
@property (nonatomic, assign) BOOL isShowInCustomerView;

//Banner
@property (nonatomic, weak) PPP_PCSAdLoadApplovinBanner *banner;

//native,请参考native(Manual）文档，创建MANativeAdView并绑定adViewBinder
@property (nonatomic, weak) MANativeAdView *nativeAdView;
//native,请参考native(Ad Placer)文档，传自定义的tableView或collectionView
@property (nonatomic, weak) UITableView *maTableView;
@property (nonatomic, weak) UICollectionView *maCollectionView;
//native Ad Positions,请参考native(Ad Placer)文档
@property (nonatomic, weak) NSArray<NSIndexPath *> *maNativPositions;
//native To change the repeating interval, This value must be greater than or equal to 2; 请参考native(Ad Placer)文档
@property (nonatomic, assign) NSInteger repeatingInterval;
//native remove existing fixed positions 请参考native(Ad Placer)文档
@property (nonatomic, assign) BOOL isRmExitFixdPos;
//native 请参考native(Ad Placer)文档
@property (nonatomic, assign) CGSize palcerAdSize;

@property (nonatomic, assign) BOOL isLoadedBanner;

@end

NS_ASSUME_NONNULL_END
