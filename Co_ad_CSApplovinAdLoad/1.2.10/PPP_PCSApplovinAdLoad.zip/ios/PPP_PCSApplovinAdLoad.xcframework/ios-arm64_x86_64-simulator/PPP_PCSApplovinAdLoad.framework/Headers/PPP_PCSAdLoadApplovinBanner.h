//
//  PPP_PCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PPP_PCSAdSDK/PPP_PCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PPP_PCSAdSDK/PPP_PCSAdLoadProtocol.h>
#import <PPP_PCSAdSDK/PPP_PCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PCSAdLoadApplovinBanner : PPP_PCSAdLoadBanner <PPP_PCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
