//
//  PPP_PCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PPP_PCSAdSDK/PPP_PCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PPP_PCSAdSDK/PPP_PCSAdLoadProtocol.h>
#import <PPP_PCSAdSDK/PPP_PCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PPP_PCSAdLoadApplovinOpen : PPP_PCSAdLoadOpen <PPP_PCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
