//
//  PPP_PCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PPP_PCSAdSDK/PPP_PCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PPP_PCSAdSDK/PPP_PCSAdLoadProtocol.h>
#import <PPP_PCSAdSDK/PPP_PCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PCSAdLoadApplovinInterstitial : PPP_PCSAdLoadInterstitial<PPP_PCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
