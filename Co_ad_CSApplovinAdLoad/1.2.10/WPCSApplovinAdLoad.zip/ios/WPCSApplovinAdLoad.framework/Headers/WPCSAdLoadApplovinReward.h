//
//  WPCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <WPCSAdSDK/WPCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <WPCSAdSDK/WPCSAdLoadProtocol.h>
#import <WPCSAdSDK/WPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface WPCSAdLoadApplovinReward : WPCSAdLoadReward<WPCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
