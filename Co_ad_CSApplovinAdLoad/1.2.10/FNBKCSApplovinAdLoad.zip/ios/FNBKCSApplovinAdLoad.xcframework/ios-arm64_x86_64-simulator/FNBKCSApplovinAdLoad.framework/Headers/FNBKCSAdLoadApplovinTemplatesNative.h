//
//  FNBKCSAdLoadApplovinTemplatesNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <FNBKCSAdSDK/FNBKCSAdLoadNative.h>
#import <FNBKCSAdSDK/FNBKCSAdLoadProtocol.h>
#import <FNBKCSAdSDK/FNBKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FNBKCSAdLoadApplovinTemplatesNative : FNBKCSAdLoadNative<FNBKCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;
@property (nonatomic, strong) UIView *nativeAdView;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
