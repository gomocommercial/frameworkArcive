//
//  FNBKCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FNBKCSAdSDK/FNBKCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FNBKCSAdSDK/FNBKCSAdLoadProtocol.h>
#import <FNBKCSAdSDK/FNBKCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FNBKCSAdLoadApplovinOpen : FNBKCSAdLoadOpen <FNBKCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
