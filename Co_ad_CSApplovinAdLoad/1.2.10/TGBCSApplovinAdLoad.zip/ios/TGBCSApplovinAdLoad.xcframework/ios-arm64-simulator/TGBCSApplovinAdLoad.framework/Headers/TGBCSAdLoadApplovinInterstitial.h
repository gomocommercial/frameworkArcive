//
//  TGBCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <TGBCSAdSDK/TGBCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TGBCSAdSDK/TGBCSAdLoadProtocol.h>
#import <TGBCSAdSDK/TGBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadApplovinInterstitial : TGBCSAdLoadInterstitial<TGBCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
