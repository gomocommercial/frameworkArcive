//
//  TGBCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <TGBCSAdSDK/TGBCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TGBCSAdSDK/TGBCSAdLoadProtocol.h>
#import <TGBCSAdSDK/TGBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadApplovinBanner : TGBCSAdLoadBanner <TGBCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
