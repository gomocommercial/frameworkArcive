//
//  TGBCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TGBCSAdSDK/TGBCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TGBCSAdSDK/TGBCSAdLoadProtocol.h>
#import <TGBCSAdSDK/TGBCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadApplovinOpen : TGBCSAdLoadOpen <TGBCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
