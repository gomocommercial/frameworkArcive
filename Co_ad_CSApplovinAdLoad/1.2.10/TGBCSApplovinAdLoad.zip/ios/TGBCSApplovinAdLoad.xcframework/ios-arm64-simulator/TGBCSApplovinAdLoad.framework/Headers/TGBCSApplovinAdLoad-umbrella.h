#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TGBCSAdLoadApplovinBanner.h"
#import "TGBCSAdLoadApplovinConfig.h"
#import "TGBCSApplovinConfigModel.h"
#import "TGBCSAdLoadApplovinInterstitial.h"
#import "TGBCSAdLoadApplovinAdPlaceNative.h"
#import "TGBCSAdLoadApplovinManualNative.h"
#import "TGBCSAdLoadApplovinTemplatesNative.h"
#import "TGBCSAdLoadApplovinOpen.h"
#import "TGBCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double TGBCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TGBCSApplovinAdLoadVersionString[];

