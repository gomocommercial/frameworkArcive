//
//  TGBCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <TGBCSAdSDK/TGBCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TGBCSAdSDK/TGBCSAdLoadProtocol.h>
#import <TGBCSAdSDK/TGBCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadApplovinReward : TGBCSAdLoadReward<TGBCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
