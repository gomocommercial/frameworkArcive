#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "LOCSAdLoadApplovinBanner.h"
#import "LOCSAdLoadApplovinConfig.h"
#import "LOCSApplovinConfigModel.h"
#import "LOCSAdLoadApplovinInterstitial.h"
#import "LOCSAdLoadApplovinAdPlaceNative.h"
#import "LOCSAdLoadApplovinManualNative.h"
#import "LOCSAdLoadApplovinTemplatesNative.h"
#import "LOCSAdLoadApplovinOpen.h"
#import "LOCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double LOCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char LOCSApplovinAdLoadVersionString[];

