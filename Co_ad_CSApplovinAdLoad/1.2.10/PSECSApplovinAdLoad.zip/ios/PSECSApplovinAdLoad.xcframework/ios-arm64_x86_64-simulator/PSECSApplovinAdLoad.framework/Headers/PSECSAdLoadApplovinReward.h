//
//  PSECSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PSECSAdSDK/PSECSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PSECSAdSDK/PSECSAdLoadProtocol.h>
#import <PSECSAdSDK/PSECSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdLoadApplovinReward : PSECSAdLoadReward<PSECSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
