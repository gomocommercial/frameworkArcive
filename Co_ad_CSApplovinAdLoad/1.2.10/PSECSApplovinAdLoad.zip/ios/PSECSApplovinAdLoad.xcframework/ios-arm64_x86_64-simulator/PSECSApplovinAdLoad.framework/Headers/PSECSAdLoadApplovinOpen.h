//
//  PSECSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PSECSAdSDK/PSECSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PSECSAdSDK/PSECSAdLoadProtocol.h>
#import <PSECSAdSDK/PSECSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdLoadApplovinOpen : PSECSAdLoadOpen <PSECSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
