//
//  PSECSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PSECSAdSDK/PSECSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PSECSAdSDK/PSECSAdLoadProtocol.h>
#import <PSECSAdSDK/PSECSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdLoadApplovinBanner : PSECSAdLoadBanner <PSECSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
