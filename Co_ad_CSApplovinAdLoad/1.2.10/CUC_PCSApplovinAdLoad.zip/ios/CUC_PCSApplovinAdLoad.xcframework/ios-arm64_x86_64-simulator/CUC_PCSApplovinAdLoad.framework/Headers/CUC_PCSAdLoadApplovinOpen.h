//
//  CUC_PCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadApplovinOpen : CUC_PCSAdLoadOpen <CUC_PCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
