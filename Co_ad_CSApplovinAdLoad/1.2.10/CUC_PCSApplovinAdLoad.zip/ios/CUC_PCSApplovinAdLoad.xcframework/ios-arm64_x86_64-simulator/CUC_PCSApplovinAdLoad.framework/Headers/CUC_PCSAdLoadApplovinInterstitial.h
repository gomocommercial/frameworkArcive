//
//  CUC_PCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadApplovinInterstitial : CUC_PCSAdLoadInterstitial<CUC_PCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
