//
//  CUC_PCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadApplovinBanner : CUC_PCSAdLoadBanner <CUC_PCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
