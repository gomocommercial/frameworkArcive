#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "WACSAdLoadApplovinBanner.h"
#import "WACSAdLoadApplovinConfig.h"
#import "WACSApplovinConfigModel.h"
#import "WACSAdLoadApplovinInterstitial.h"
#import "WACSAdLoadApplovinAdPlaceNative.h"
#import "WACSAdLoadApplovinManualNative.h"
#import "WACSAdLoadApplovinTemplatesNative.h"
#import "WACSAdLoadApplovinOpen.h"
#import "WACSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double WACSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char WACSApplovinAdLoadVersionString[];

