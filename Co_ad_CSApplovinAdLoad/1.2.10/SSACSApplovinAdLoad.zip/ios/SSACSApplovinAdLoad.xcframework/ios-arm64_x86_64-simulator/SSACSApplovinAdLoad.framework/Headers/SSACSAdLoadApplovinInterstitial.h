//
//  SSACSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SSACSAdSDK/SSACSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SSACSAdSDK/SSACSAdLoadProtocol.h>
#import <SSACSAdSDK/SSACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SSACSAdLoadApplovinInterstitial : SSACSAdLoadInterstitial<SSACSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
