#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "FurTalesCSAdLoadApplovinBanner.h"
#import "FurTalesCSAdLoadApplovinConfig.h"
#import "FurTalesCSApplovinConfigModel.h"
#import "FurTalesCSAdLoadApplovinInterstitial.h"
#import "FurTalesCSAdLoadApplovinAdPlaceNative.h"
#import "FurTalesCSAdLoadApplovinManualNative.h"
#import "FurTalesCSAdLoadApplovinTemplatesNative.h"
#import "FurTalesCSAdLoadApplovinOpen.h"
#import "FurTalesCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double FurTalesCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char FurTalesCSApplovinAdLoadVersionString[];

