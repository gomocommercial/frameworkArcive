//
//  FurTalesCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FurTalesCSAdSDK/FurTalesCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadProtocol.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdLoadApplovinInterstitial : FurTalesCSAdLoadInterstitial<FurTalesCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
