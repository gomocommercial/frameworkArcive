//
//  FurTalesCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <FurTalesCSAdSDK/FurTalesCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadProtocol.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdLoadApplovinBanner : FurTalesCSAdLoadBanner <FurTalesCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
