//
//  FurTalesCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FurTalesCSAdSDK/FurTalesCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadProtocol.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdLoadApplovinOpen : FurTalesCSAdLoadOpen <FurTalesCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
