//
//  CPSCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <CPSCSAdSDK/CPSCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CPSCSAdSDK/CPSCSAdLoadProtocol.h>
#import <CPSCSAdSDK/CPSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CPSCSAdLoadApplovinBanner : CPSCSAdLoadBanner <CPSCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
