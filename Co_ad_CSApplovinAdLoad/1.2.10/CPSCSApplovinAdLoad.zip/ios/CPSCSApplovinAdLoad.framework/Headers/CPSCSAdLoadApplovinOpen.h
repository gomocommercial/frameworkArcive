//
//  CPSCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CPSCSAdSDK/CPSCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CPSCSAdSDK/CPSCSAdLoadProtocol.h>
#import <CPSCSAdSDK/CPSCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CPSCSAdLoadApplovinOpen : CPSCSAdLoadOpen <CPSCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
