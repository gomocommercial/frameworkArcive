//
//  CPSCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CPSCSAdSDK/CPSCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CPSCSAdSDK/CPSCSAdLoadProtocol.h>
#import <CPSCSAdSDK/CPSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CPSCSAdLoadApplovinInterstitial : CPSCSAdLoadInterstitial<CPSCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
