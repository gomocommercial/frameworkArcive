//
//  WIOCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <WIOCSAdSDK/WIOCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <WIOCSAdSDK/WIOCSAdLoadProtocol.h>
#import <WIOCSAdSDK/WIOCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface WIOCSAdLoadApplovinOpen : WIOCSAdLoadOpen <WIOCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
