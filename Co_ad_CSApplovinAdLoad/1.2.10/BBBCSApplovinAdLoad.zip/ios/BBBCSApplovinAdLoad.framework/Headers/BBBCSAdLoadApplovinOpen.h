//
//  BBBCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <BBBCSAdSDK/BBBCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <BBBCSAdSDK/BBBCSAdLoadProtocol.h>
#import <BBBCSAdSDK/BBBCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface BBBCSAdLoadApplovinOpen : BBBCSAdLoadOpen <BBBCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
