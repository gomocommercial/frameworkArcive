//
//  PACSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PACSAdSDK/PACSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PACSAdSDK/PACSAdLoadProtocol.h>
#import <PACSAdSDK/PACSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PACSAdLoadApplovinOpen : PACSAdLoadOpen <PACSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
