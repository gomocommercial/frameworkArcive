//
//  PACSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PACSAdSDK/PACSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PACSAdSDK/PACSAdLoadProtocol.h>
#import <PACSAdSDK/PACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PACSAdLoadApplovinBanner : PACSAdLoadBanner <PACSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
