//
//  JMSCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <JMSCSAdSDK/JMSCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JMSCSAdSDK/JMSCSAdLoadProtocol.h>
#import <JMSCSAdSDK/JMSCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface JMSCSAdLoadApplovinOpen : JMSCSAdLoadOpen <JMSCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
