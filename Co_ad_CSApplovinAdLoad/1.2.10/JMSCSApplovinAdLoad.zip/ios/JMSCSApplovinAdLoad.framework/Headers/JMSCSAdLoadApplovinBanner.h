//
//  JMSCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <JMSCSAdSDK/JMSCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JMSCSAdSDK/JMSCSAdLoadProtocol.h>
#import <JMSCSAdSDK/JMSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JMSCSAdLoadApplovinBanner : JMSCSAdLoadBanner <JMSCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
