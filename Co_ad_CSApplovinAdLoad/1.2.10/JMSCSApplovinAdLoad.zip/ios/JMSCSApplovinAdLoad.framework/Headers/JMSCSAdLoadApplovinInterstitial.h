//
//  JMSCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <JMSCSAdSDK/JMSCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JMSCSAdSDK/JMSCSAdLoadProtocol.h>
#import <JMSCSAdSDK/JMSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JMSCSAdLoadApplovinInterstitial : JMSCSAdLoadInterstitial<JMSCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
