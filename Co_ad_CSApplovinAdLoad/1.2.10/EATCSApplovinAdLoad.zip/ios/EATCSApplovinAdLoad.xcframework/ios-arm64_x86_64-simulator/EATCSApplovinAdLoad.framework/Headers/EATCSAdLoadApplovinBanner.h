//
//  EATCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <EATCSAdSDK/EATCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <EATCSAdSDK/EATCSAdLoadProtocol.h>
#import <EATCSAdSDK/EATCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface EATCSAdLoadApplovinBanner : EATCSAdLoadBanner <EATCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
