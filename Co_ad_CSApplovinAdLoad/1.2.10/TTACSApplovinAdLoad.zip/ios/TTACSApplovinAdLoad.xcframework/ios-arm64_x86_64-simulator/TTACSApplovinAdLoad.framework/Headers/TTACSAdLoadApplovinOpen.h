//
//  TTACSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TTACSAdSDK/TTACSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TTACSAdSDK/TTACSAdLoadProtocol.h>
#import <TTACSAdSDK/TTACSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdLoadApplovinOpen : TTACSAdLoadOpen <TTACSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
