#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TTACSAdLoadApplovinBanner.h"
#import "TTACSAdLoadApplovinConfig.h"
#import "TTACSApplovinConfigModel.h"
#import "TTACSAdLoadApplovinInterstitial.h"
#import "TTACSAdLoadApplovinAdPlaceNative.h"
#import "TTACSAdLoadApplovinManualNative.h"
#import "TTACSAdLoadApplovinTemplatesNative.h"
#import "TTACSAdLoadApplovinOpen.h"
#import "TTACSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double TTACSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TTACSApplovinAdLoadVersionString[];

