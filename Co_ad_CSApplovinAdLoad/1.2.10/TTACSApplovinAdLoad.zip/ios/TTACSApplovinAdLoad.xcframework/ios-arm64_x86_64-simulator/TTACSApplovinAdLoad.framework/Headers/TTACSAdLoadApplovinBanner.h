//
//  TTACSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <TTACSAdSDK/TTACSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TTACSAdSDK/TTACSAdLoadProtocol.h>
#import <TTACSAdSDK/TTACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TTACSAdLoadApplovinBanner : TTACSAdLoadBanner <TTACSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
