//
//  MTCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MTCSAdSDK/MTCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MTCSAdSDK/MTCSAdLoadProtocol.h>
#import <MTCSAdSDK/MTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MTCSAdLoadApplovinInterstitial : MTCSAdLoadInterstitial<MTCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
