//
//  MTCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <MTCSAdSDK/MTCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MTCSAdSDK/MTCSAdLoadProtocol.h>
#import <MTCSAdSDK/MTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MTCSAdLoadApplovinBanner : MTCSAdLoadBanner <MTCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
