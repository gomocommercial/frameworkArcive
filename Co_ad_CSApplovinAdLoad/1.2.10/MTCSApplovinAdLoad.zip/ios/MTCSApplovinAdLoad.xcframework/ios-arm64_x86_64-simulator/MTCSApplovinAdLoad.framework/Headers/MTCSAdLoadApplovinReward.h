//
//  MTCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MTCSAdSDK/MTCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MTCSAdSDK/MTCSAdLoadProtocol.h>
#import <MTCSAdSDK/MTCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MTCSAdLoadApplovinReward : MTCSAdLoadReward<MTCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
