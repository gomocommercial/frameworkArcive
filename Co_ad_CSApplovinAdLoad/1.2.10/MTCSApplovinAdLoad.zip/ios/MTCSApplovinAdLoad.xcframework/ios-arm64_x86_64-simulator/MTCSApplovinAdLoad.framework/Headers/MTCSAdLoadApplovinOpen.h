//
//  MTCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MTCSAdSDK/MTCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MTCSAdSDK/MTCSAdLoadProtocol.h>
#import <MTCSAdSDK/MTCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MTCSAdLoadApplovinOpen : MTCSAdLoadOpen <MTCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
