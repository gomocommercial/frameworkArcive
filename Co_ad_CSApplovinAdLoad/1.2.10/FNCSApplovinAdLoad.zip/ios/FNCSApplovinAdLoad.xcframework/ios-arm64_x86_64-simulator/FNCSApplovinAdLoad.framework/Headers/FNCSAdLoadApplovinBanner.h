//
//  FNCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <FNCSAdSDK/FNCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FNCSAdSDK/FNCSAdLoadProtocol.h>
#import <FNCSAdSDK/FNCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FNCSAdLoadApplovinBanner : FNCSAdLoadBanner <FNCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
