//
//  FNCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FNCSAdSDK/FNCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FNCSAdSDK/FNCSAdLoadProtocol.h>
#import <FNCSAdSDK/FNCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FNCSAdLoadApplovinOpen : FNCSAdLoadOpen <FNCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
