//
//  PPP_P_CSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadProtocol.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSAdLoadApplovinOpen : PPP_P_CSAdLoadOpen <PPP_P_CSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
