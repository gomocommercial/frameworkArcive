//
//  PPP_P_CSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadProtocol.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSAdLoadApplovinBanner : PPP_P_CSAdLoadBanner <PPP_P_CSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
