//
//  PPP_P_CSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadProtocol.h>
#import <PPP_P_CSAdSDK/PPP_P_CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSAdLoadApplovinInterstitial : PPP_P_CSAdLoadInterstitial<PPP_P_CSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
