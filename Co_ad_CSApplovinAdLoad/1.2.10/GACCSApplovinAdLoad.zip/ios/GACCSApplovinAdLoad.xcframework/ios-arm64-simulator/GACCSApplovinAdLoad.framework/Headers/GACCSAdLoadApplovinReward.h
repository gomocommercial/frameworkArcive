//
//  GACCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <GACCSAdSDK/GACCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <GACCSAdSDK/GACCSAdLoadProtocol.h>
#import <GACCSAdSDK/GACCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadApplovinReward : GACCSAdLoadReward<GACCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
