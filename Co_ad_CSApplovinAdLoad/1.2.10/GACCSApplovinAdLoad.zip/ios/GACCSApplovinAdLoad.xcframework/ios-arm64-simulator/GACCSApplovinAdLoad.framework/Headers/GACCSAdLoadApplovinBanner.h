//
//  GACCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <GACCSAdSDK/GACCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <GACCSAdSDK/GACCSAdLoadProtocol.h>
#import <GACCSAdSDK/GACCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadApplovinBanner : GACCSAdLoadBanner <GACCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
