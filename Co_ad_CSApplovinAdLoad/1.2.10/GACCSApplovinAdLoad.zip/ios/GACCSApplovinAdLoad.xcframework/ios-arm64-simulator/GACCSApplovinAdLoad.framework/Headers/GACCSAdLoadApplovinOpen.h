//
//  GACCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <GACCSAdSDK/GACCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <GACCSAdSDK/GACCSAdLoadProtocol.h>
#import <GACCSAdSDK/GACCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadApplovinOpen : GACCSAdLoadOpen <GACCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
