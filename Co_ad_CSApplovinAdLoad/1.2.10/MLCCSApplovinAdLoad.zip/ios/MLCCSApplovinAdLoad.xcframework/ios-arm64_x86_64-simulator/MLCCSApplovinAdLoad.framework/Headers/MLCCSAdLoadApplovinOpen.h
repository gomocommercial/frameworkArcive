//
//  MLCCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MLCCSAdSDK/MLCCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MLCCSAdSDK/MLCCSAdLoadProtocol.h>
#import <MLCCSAdSDK/MLCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MLCCSAdLoadApplovinOpen : MLCCSAdLoadOpen <MLCCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
