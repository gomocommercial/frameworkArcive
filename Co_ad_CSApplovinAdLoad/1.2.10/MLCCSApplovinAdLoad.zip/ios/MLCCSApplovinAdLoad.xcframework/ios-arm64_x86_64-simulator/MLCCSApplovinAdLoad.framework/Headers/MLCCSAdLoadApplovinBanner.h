//
//  MLCCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <MLCCSAdSDK/MLCCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MLCCSAdSDK/MLCCSAdLoadProtocol.h>
#import <MLCCSAdSDK/MLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MLCCSAdLoadApplovinBanner : MLCCSAdLoadBanner <MLCCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
