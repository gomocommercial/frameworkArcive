//
//  MLCCSAdLoadApplovinManualNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <MLCCSAdSDK/MLCCSAdLoadNative.h>
#import <MLCCSAdSDK/MLCCSAdLoadProtocol.h>
#import <MLCCSAdSDK/MLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MLCCSAdLoadApplovinManualNative : MLCCSAdLoadNative<MLCCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
