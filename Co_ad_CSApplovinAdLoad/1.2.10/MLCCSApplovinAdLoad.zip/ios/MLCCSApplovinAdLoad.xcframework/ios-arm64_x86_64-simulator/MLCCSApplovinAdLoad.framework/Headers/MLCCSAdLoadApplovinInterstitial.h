//
//  MLCCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MLCCSAdSDK/MLCCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MLCCSAdSDK/MLCCSAdLoadProtocol.h>
#import <MLCCSAdSDK/MLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MLCCSAdLoadApplovinInterstitial : MLCCSAdLoadInterstitial<MLCCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
