//
//  AMACSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <AMACSAdSDK/AMACSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AMACSAdSDK/AMACSAdLoadProtocol.h>
#import <AMACSAdSDK/AMACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMACSAdLoadApplovinBanner : AMACSAdLoadBanner <AMACSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
