//
//  AMACSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AMACSAdSDK/AMACSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AMACSAdSDK/AMACSAdLoadProtocol.h>
#import <AMACSAdSDK/AMACSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMACSAdLoadApplovinInterstitial : AMACSAdLoadInterstitial<AMACSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
