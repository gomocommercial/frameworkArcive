//
//  AMACSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AMACSAdSDK/AMACSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AMACSAdSDK/AMACSAdLoadProtocol.h>
#import <AMACSAdSDK/AMACSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AMACSAdLoadApplovinReward : AMACSAdLoadReward<AMACSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
