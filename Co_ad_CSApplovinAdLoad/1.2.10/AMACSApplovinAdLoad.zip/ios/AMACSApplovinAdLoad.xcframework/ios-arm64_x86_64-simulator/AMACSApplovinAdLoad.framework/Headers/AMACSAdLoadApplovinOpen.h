//
//  AMACSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <AMACSAdSDK/AMACSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AMACSAdSDK/AMACSAdLoadProtocol.h>
#import <AMACSAdSDK/AMACSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AMACSAdLoadApplovinOpen : AMACSAdLoadOpen <AMACSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
