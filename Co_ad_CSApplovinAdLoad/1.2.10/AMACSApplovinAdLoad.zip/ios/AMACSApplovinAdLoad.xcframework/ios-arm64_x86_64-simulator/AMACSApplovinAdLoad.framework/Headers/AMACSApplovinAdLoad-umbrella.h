#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "AMACSAdLoadApplovinBanner.h"
#import "AMACSAdLoadApplovinConfig.h"
#import "AMACSApplovinConfigModel.h"
#import "AMACSAdLoadApplovinInterstitial.h"
#import "AMACSAdLoadApplovinAdPlaceNative.h"
#import "AMACSAdLoadApplovinManualNative.h"
#import "AMACSAdLoadApplovinTemplatesNative.h"
#import "AMACSAdLoadApplovinOpen.h"
#import "AMACSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double AMACSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char AMACSApplovinAdLoadVersionString[];

