//
//  TasteLensCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <TasteLensCSAdSDK/TasteLensCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadProtocol.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TasteLensCSAdLoadApplovinReward : TasteLensCSAdLoadReward<TasteLensCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
