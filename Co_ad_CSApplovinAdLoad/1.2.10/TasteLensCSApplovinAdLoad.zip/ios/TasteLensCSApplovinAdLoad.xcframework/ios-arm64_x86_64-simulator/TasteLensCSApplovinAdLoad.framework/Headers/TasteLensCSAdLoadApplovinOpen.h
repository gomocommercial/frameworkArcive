//
//  TasteLensCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TasteLensCSAdSDK/TasteLensCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadProtocol.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TasteLensCSAdLoadApplovinOpen : TasteLensCSAdLoadOpen <TasteLensCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
