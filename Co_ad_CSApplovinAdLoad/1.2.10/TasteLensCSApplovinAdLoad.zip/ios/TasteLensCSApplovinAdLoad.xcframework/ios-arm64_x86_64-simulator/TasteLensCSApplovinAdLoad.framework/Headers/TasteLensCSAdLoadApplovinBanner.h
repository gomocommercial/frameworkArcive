//
//  TasteLensCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <TasteLensCSAdSDK/TasteLensCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadProtocol.h>
#import <TasteLensCSAdSDK/TasteLensCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TasteLensCSAdLoadApplovinBanner : TasteLensCSAdLoadBanner <TasteLensCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
