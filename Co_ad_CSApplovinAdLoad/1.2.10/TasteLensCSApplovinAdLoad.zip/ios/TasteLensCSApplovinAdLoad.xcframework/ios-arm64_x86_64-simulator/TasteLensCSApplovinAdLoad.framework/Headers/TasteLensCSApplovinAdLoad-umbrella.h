#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TasteLensCSAdLoadApplovinBanner.h"
#import "TasteLensCSAdLoadApplovinConfig.h"
#import "TasteLensCSApplovinConfigModel.h"
#import "TasteLensCSAdLoadApplovinInterstitial.h"
#import "TasteLensCSAdLoadApplovinAdPlaceNative.h"
#import "TasteLensCSAdLoadApplovinManualNative.h"
#import "TasteLensCSAdLoadApplovinTemplatesNative.h"
#import "TasteLensCSAdLoadApplovinOpen.h"
#import "TasteLensCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double TasteLensCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TasteLensCSApplovinAdLoadVersionString[];

