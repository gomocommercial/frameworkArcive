//
//  STEPTCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <STEPTCSAdSDK/STEPTCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadProtocol.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdLoadApplovinBanner : STEPTCSAdLoadBanner <STEPTCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
