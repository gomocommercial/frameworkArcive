//
//  STEPTCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <STEPTCSAdSDK/STEPTCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadProtocol.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdLoadApplovinOpen : STEPTCSAdLoadOpen <STEPTCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
