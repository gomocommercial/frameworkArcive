//
//  SKCSAdLoadApplovinTemplatesNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <SKCSAdSDK/SKCSAdLoadNative.h>
#import <SKCSAdSDK/SKCSAdLoadProtocol.h>
#import <SKCSAdSDK/SKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SKCSAdLoadApplovinTemplatesNative : SKCSAdLoadNative<SKCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;
@property (nonatomic, strong) UIView *nativeAdView;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
