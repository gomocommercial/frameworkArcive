//
//  DWCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <DWCSAdSDK/DWCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DWCSAdSDK/DWCSAdLoadProtocol.h>
#import <DWCSAdSDK/DWCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DWCSAdLoadApplovinOpen : DWCSAdLoadOpen <DWCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
