//
//  DWCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <DWCSAdSDK/DWCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DWCSAdSDK/DWCSAdLoadProtocol.h>
#import <DWCSAdSDK/DWCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DWCSAdLoadApplovinBanner : DWCSAdLoadBanner <DWCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
