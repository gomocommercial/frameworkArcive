//
//  DWCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <DWCSAdSDK/DWCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DWCSAdSDK/DWCSAdLoadProtocol.h>
#import <DWCSAdSDK/DWCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DWCSAdLoadApplovinInterstitial : DWCSAdLoadInterstitial<DWCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
