//
//  JLCCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <JLCCSAdSDK/JLCCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JLCCSAdSDK/JLCCSAdLoadProtocol.h>
#import <JLCCSAdSDK/JLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadApplovinBanner : JLCCSAdLoadBanner <JLCCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
