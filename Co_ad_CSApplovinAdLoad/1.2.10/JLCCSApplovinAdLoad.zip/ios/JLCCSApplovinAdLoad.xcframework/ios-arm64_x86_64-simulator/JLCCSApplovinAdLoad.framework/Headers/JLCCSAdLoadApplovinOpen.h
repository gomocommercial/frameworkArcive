//
//  JLCCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <JLCCSAdSDK/JLCCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JLCCSAdSDK/JLCCSAdLoadProtocol.h>
#import <JLCCSAdSDK/JLCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadApplovinOpen : JLCCSAdLoadOpen <JLCCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
