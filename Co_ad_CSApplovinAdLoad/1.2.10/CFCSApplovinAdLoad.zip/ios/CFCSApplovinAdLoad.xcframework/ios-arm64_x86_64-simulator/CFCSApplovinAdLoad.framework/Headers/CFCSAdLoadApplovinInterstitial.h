//
//  CFCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CFCSAdSDK/CFCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CFCSAdSDK/CFCSAdLoadProtocol.h>
#import <CFCSAdSDK/CFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCSAdLoadApplovinInterstitial : CFCSAdLoadInterstitial<CFCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
