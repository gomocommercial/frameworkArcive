//
//  MEETAICSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MEETAICSAdSDK/MEETAICSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadProtocol.h>
#import <MEETAICSAdSDK/MEETAICSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MEETAICSAdLoadApplovinReward : MEETAICSAdLoadReward<MEETAICSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
