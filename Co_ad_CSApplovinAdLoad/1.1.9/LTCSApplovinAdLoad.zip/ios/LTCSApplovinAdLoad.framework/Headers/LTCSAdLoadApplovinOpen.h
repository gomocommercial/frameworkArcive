//
//  LTCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LTCSAdSDK/LTCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LTCSAdSDK/LTCSAdLoadProtocol.h>
#import <LTCSAdSDK/LTCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LTCSAdLoadApplovinOpen : LTCSAdLoadOpen <LTCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
