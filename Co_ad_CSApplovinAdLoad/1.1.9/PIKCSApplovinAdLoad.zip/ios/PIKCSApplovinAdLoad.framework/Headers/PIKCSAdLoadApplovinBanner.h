//
//  PIKCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PIKCSAdSDK/PIKCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PIKCSAdSDK/PIKCSAdLoadProtocol.h>
#import <PIKCSAdSDK/PIKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PIKCSAdLoadApplovinBanner : PIKCSAdLoadBanner <PIKCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
