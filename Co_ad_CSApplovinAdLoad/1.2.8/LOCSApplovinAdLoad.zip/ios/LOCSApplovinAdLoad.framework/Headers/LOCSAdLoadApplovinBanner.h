//
//  LOCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <LOCSAdSDK/LOCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdLoadApplovinBanner : LOCSAdLoadBanner <LOCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
