//
//  SWCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <SWCSAdSDK/SWCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SWCSAdSDK/SWCSAdLoadProtocol.h>
#import <SWCSAdSDK/SWCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface SWCSAdLoadApplovinOpen : SWCSAdLoadOpen <SWCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
