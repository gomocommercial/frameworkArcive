//
//  DCCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <DCCSAdSDK/DCCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadApplovinReward : DCCSAdLoadReward<DCCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
