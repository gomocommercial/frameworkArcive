//
//  DCiosCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <DCiosCSAdSDK/DCiosCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadProtocol.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCiosCSAdLoadApplovinInterstitial : DCiosCSAdLoadInterstitial<DCiosCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
