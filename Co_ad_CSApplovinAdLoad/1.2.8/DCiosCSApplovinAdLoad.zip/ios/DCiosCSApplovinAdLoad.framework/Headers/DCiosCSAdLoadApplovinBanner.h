//
//  DCiosCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <DCiosCSAdSDK/DCiosCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadProtocol.h>
#import <DCiosCSAdSDK/DCiosCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCiosCSAdLoadApplovinBanner : DCiosCSAdLoadBanner <DCiosCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
