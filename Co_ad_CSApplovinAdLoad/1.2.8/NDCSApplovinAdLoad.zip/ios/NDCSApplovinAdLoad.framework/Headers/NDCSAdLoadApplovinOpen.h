//
//  NDCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <NDCSAdSDK/NDCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <NDCSAdSDK/NDCSAdLoadProtocol.h>
#import <NDCSAdSDK/NDCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface NDCSAdLoadApplovinOpen : NDCSAdLoadOpen <NDCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
