//
//  TESTIOSCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadProtocol.h>
#import <TESTIOSCSAdSDK/TESTIOSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TESTIOSCSAdLoadApplovinBanner : TESTIOSCSAdLoadBanner <TESTIOSCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
