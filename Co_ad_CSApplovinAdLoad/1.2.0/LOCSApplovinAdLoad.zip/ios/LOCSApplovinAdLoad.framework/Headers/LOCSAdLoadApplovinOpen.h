//
//  LOCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LOCSAdSDK/LOCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdLoadApplovinOpen : LOCSAdLoadOpen <LOCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
