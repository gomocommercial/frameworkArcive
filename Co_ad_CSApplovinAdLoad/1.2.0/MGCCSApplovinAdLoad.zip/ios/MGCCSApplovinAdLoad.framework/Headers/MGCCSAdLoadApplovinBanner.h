//
//  MGCCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <MGCCSAdSDK/MGCCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MGCCSAdSDK/MGCCSAdLoadProtocol.h>
#import <MGCCSAdSDK/MGCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGCCSAdLoadApplovinBanner : MGCCSAdLoadBanner <MGCCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
