//
//  MGCCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MGCCSAdSDK/MGCCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MGCCSAdSDK/MGCCSAdLoadProtocol.h>
#import <MGCCSAdSDK/MGCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MGCCSAdLoadApplovinReward : MGCCSAdLoadReward<MGCCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
