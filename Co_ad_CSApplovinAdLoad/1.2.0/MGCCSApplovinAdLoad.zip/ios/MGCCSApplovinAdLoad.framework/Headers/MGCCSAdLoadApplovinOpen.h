//
//  MGCCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MGCCSAdSDK/MGCCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MGCCSAdSDK/MGCCSAdLoadProtocol.h>
#import <MGCCSAdSDK/MGCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MGCCSAdLoadApplovinOpen : MGCCSAdLoadOpen <MGCCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
