//
//  DCCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <DCCSAdSDK/DCCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadApplovinBanner : DCCSAdLoadBanner <DCCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
