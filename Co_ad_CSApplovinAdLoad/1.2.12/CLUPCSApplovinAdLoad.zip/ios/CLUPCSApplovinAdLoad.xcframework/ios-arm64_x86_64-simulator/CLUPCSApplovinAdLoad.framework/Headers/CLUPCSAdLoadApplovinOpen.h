//
//  CLUPCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CLUPCSAdSDK/CLUPCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadProtocol.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CLUPCSAdLoadApplovinOpen : CLUPCSAdLoadOpen <CLUPCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
