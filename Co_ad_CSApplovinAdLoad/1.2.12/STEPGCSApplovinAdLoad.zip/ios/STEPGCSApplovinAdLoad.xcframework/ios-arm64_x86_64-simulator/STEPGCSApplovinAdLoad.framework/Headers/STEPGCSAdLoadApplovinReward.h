//
//  STEPGCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <STEPGCSAdSDK/STEPGCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadProtocol.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface STEPGCSAdLoadApplovinReward : STEPGCSAdLoadReward<STEPGCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
