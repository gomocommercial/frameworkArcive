//
//  STEPGCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <STEPGCSAdSDK/STEPGCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadProtocol.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface STEPGCSAdLoadApplovinInterstitial : STEPGCSAdLoadInterstitial<STEPGCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
