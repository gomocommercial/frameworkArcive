//
//  STEPGCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <STEPGCSAdSDK/STEPGCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadProtocol.h>
#import <STEPGCSAdSDK/STEPGCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface STEPGCSAdLoadApplovinBanner : STEPGCSAdLoadBanner <STEPGCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
