//
//  TIVCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <TIVCSAdSDK/TIVCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TIVCSAdSDK/TIVCSAdLoadProtocol.h>
#import <TIVCSAdSDK/TIVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdLoadApplovinBanner : TIVCSAdLoadBanner <TIVCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
