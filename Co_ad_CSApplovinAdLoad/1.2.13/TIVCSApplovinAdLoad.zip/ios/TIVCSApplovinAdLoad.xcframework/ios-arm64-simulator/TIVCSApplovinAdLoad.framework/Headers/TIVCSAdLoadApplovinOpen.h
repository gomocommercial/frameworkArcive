//
//  TIVCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TIVCSAdSDK/TIVCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TIVCSAdSDK/TIVCSAdLoadProtocol.h>
#import <TIVCSAdSDK/TIVCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdLoadApplovinOpen : TIVCSAdLoadOpen <TIVCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
