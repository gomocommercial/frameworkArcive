//
//  TIVCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <TIVCSAdSDK/TIVCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TIVCSAdSDK/TIVCSAdLoadProtocol.h>
#import <TIVCSAdSDK/TIVCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TIVCSAdLoadApplovinReward : TIVCSAdLoadReward<TIVCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
