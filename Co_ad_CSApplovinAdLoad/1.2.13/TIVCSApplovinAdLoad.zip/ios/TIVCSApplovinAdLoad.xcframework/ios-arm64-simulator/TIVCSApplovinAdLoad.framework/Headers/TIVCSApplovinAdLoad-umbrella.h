#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "TIVCSAdLoadApplovinBanner.h"
#import "TIVCSAdLoadApplovinConfig.h"
#import "TIVCSApplovinConfigModel.h"
#import "TIVCSAdLoadApplovinInterstitial.h"
#import "TIVCSAdLoadApplovinAdPlaceNative.h"
#import "TIVCSAdLoadApplovinManualNative.h"
#import "TIVCSAdLoadApplovinTemplatesNative.h"
#import "TIVCSAdLoadApplovinOpen.h"
#import "TIVCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double TIVCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char TIVCSApplovinAdLoadVersionString[];

