//
//  STPBCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <STPBCSAdSDK/STPBCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadApplovinBanner : STPBCSAdLoadBanner <STPBCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
