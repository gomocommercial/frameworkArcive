//
//  STPBCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <STPBCSAdSDK/STPBCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadApplovinOpen : STPBCSAdLoadOpen <STPBCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
