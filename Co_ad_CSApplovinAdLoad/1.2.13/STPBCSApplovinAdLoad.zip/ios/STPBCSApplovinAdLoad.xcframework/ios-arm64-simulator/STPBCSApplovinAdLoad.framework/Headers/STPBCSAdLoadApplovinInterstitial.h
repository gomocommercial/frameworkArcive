//
//  STPBCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <STPBCSAdSDK/STPBCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadApplovinInterstitial : STPBCSAdLoadInterstitial<STPBCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
