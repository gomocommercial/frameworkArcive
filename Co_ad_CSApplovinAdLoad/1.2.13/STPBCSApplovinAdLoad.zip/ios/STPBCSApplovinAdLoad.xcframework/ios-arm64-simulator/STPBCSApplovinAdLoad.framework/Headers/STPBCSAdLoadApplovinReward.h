//
//  STPBCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <STPBCSAdSDK/STPBCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadApplovinReward : STPBCSAdLoadReward<STPBCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
