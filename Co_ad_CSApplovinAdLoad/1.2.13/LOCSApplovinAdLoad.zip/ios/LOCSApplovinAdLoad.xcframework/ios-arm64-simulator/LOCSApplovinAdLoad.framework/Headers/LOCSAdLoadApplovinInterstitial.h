//
//  LOCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <LOCSAdSDK/LOCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LOCSAdSDK/LOCSAdLoadProtocol.h>
#import <LOCSAdSDK/LOCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LOCSAdLoadApplovinInterstitial : LOCSAdLoadInterstitial<LOCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
