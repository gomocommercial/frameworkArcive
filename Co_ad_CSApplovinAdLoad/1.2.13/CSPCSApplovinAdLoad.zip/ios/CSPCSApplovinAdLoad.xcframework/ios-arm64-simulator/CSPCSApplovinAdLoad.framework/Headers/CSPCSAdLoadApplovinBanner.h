//
//  CSPCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <CSPCSAdSDK/CSPCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSPCSAdSDK/CSPCSAdLoadProtocol.h>
#import <CSPCSAdSDK/CSPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSPCSAdLoadApplovinBanner : CSPCSAdLoadBanner <CSPCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
