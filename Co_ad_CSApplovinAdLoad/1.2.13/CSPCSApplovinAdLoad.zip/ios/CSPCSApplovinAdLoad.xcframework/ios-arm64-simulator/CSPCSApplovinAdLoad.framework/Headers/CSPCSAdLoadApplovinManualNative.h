//
//  CSPCSAdLoadApplovinManualNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSPCSAdSDK/CSPCSAdLoadNative.h>
#import <CSPCSAdSDK/CSPCSAdLoadProtocol.h>
#import <CSPCSAdSDK/CSPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSPCSAdLoadApplovinManualNative : CSPCSAdLoadNative<CSPCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
