//
//  CSPCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CSPCSAdSDK/CSPCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSPCSAdSDK/CSPCSAdLoadProtocol.h>
#import <CSPCSAdSDK/CSPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CSPCSAdLoadApplovinReward : CSPCSAdLoadReward<CSPCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
