//
//  CSPCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CSPCSAdSDK/CSPCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSPCSAdSDK/CSPCSAdLoadProtocol.h>
#import <CSPCSAdSDK/CSPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSPCSAdLoadApplovinInterstitial : CSPCSAdLoadInterstitial<CSPCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
