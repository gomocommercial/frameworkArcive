//
//  CSPCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <CSPCSAdSDK/CSPCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSPCSAdSDK/CSPCSAdLoadProtocol.h>
#import <CSPCSAdSDK/CSPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CSPCSAdLoadApplovinOpen : CSPCSAdLoadOpen <CSPCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
