//
//  StepWisdomCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadApplovinReward : StepWisdomCSAdLoadReward<StepWisdomCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
