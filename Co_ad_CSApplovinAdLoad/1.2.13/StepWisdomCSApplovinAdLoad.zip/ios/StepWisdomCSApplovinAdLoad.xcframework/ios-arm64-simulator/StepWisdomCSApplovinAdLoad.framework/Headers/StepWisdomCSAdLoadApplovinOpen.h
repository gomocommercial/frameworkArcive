//
//  StepWisdomCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadApplovinOpen : StepWisdomCSAdLoadOpen <StepWisdomCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
