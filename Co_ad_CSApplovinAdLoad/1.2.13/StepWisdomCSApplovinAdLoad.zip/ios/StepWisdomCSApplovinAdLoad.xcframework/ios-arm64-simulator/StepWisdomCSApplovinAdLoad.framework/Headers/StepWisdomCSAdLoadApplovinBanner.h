//
//  StepWisdomCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadApplovinBanner : StepWisdomCSAdLoadBanner <StepWisdomCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
