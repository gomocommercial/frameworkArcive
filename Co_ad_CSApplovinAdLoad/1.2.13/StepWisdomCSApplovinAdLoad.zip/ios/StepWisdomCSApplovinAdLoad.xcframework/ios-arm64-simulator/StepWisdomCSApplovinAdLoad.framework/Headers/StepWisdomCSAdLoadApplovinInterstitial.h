//
//  StepWisdomCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadApplovinInterstitial : StepWisdomCSAdLoadInterstitial<StepWisdomCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
