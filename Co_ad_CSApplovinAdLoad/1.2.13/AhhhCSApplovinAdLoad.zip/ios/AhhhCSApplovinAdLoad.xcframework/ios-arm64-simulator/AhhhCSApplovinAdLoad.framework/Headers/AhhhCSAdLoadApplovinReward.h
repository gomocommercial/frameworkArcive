//
//  AhhhCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadApplovinReward : AhhhCSAdLoadReward<AhhhCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
