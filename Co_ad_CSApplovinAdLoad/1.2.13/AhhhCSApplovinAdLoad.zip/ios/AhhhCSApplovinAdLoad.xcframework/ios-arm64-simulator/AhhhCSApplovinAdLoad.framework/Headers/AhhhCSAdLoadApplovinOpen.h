//
//  AhhhCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <AhhhCSAdSDK/AhhhCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadApplovinOpen : AhhhCSAdLoadOpen <AhhhCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
