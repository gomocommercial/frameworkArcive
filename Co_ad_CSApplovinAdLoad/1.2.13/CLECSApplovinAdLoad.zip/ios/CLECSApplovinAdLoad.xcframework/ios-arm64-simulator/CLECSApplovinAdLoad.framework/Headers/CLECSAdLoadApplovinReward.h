//
//  CLECSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CLECSAdSDK/CLECSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CLECSAdSDK/CLECSAdLoadProtocol.h>
#import <CLECSAdSDK/CLECSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CLECSAdLoadApplovinReward : CLECSAdLoadReward<CLECSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
