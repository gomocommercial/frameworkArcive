//
//  CLECSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <CLECSAdSDK/CLECSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CLECSAdSDK/CLECSAdLoadProtocol.h>
#import <CLECSAdSDK/CLECSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLECSAdLoadApplovinBanner : CLECSAdLoadBanner <CLECSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
