//
//  ARCSAdLoadApplovinManualNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <ARCSAdSDK/ARCSAdLoadNative.h>
#import <ARCSAdSDK/ARCSAdLoadProtocol.h>
#import <ARCSAdSDK/ARCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface ARCSAdLoadApplovinManualNative : ARCSAdLoadNative<ARCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
