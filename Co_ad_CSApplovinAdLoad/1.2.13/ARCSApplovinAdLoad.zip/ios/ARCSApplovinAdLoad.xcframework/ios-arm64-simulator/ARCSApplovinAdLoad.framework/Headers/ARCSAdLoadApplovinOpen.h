//
//  ARCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <ARCSAdSDK/ARCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <ARCSAdSDK/ARCSAdLoadProtocol.h>
#import <ARCSAdSDK/ARCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface ARCSAdLoadApplovinOpen : ARCSAdLoadOpen <ARCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
