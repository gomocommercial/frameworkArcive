//
//  ARCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <ARCSAdSDK/ARCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <ARCSAdSDK/ARCSAdLoadProtocol.h>
#import <ARCSAdSDK/ARCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface ARCSAdLoadApplovinInterstitial : ARCSAdLoadInterstitial<ARCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
