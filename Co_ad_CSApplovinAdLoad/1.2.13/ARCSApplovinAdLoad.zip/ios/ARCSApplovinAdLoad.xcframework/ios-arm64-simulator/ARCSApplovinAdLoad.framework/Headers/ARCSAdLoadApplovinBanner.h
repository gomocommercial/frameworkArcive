//
//  ARCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <ARCSAdSDK/ARCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <ARCSAdSDK/ARCSAdLoadProtocol.h>
#import <ARCSAdSDK/ARCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface ARCSAdLoadApplovinBanner : ARCSAdLoadBanner <ARCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
