//
//  AKCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AKCSAdSDK/AKCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AKCSAdSDK/AKCSAdLoadProtocol.h>
#import <AKCSAdSDK/AKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AKCSAdLoadApplovinInterstitial : AKCSAdLoadInterstitial<AKCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
