//
//  AKCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <AKCSAdSDK/AKCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AKCSAdSDK/AKCSAdLoadProtocol.h>
#import <AKCSAdSDK/AKCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AKCSAdLoadApplovinOpen : AKCSAdLoadOpen <AKCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
