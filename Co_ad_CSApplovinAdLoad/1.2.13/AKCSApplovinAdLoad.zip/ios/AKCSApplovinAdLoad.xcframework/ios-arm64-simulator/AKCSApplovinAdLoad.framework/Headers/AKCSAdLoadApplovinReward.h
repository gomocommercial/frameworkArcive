//
//  AKCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AKCSAdSDK/AKCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AKCSAdSDK/AKCSAdLoadProtocol.h>
#import <AKCSAdSDK/AKCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AKCSAdLoadApplovinReward : AKCSAdLoadReward<AKCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
