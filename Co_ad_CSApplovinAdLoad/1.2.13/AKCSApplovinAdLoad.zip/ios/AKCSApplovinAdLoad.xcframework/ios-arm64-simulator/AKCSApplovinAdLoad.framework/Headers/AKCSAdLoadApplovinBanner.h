//
//  AKCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <AKCSAdSDK/AKCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AKCSAdSDK/AKCSAdLoadProtocol.h>
#import <AKCSAdSDK/AKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AKCSAdLoadApplovinBanner : AKCSAdLoadBanner <AKCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
