//
//  MLCCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MLCCSAdSDK/MLCCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MLCCSAdSDK/MLCCSAdLoadProtocol.h>
#import <MLCCSAdSDK/MLCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MLCCSAdLoadApplovinReward : MLCCSAdLoadReward<MLCCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
