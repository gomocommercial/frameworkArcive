//
//  PABCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PABCSAdSDK/PABCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PABCSAdSDK/PABCSAdLoadProtocol.h>
#import <PABCSAdSDK/PABCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PABCSAdLoadApplovinInterstitial : PABCSAdLoadInterstitial<PABCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
