//
//  PABCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PABCSAdSDK/PABCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PABCSAdSDK/PABCSAdLoadProtocol.h>
#import <PABCSAdSDK/PABCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PABCSAdLoadApplovinReward : PABCSAdLoadReward<PABCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
