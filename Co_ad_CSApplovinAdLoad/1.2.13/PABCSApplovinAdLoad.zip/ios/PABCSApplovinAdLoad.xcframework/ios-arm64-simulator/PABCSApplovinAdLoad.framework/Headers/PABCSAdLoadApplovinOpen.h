//
//  PABCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PABCSAdSDK/PABCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PABCSAdSDK/PABCSAdLoadProtocol.h>
#import <PABCSAdSDK/PABCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PABCSAdLoadApplovinOpen : PABCSAdLoadOpen <PABCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
