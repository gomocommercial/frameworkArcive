//
//  LUMCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LUMCSAdSDK/LUMCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LUMCSAdSDK/LUMCSAdLoadProtocol.h>
#import <LUMCSAdSDK/LUMCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LUMCSAdLoadApplovinOpen : LUMCSAdLoadOpen <LUMCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
