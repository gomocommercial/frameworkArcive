//
//  LUMCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <LUMCSAdSDK/LUMCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LUMCSAdSDK/LUMCSAdLoadProtocol.h>
#import <LUMCSAdSDK/LUMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LUMCSAdLoadApplovinBanner : LUMCSAdLoadBanner <LUMCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
