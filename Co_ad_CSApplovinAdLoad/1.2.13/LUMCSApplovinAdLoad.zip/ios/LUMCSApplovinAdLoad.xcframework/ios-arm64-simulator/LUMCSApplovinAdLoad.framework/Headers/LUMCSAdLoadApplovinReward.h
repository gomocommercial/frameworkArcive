//
//  LUMCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <LUMCSAdSDK/LUMCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LUMCSAdSDK/LUMCSAdLoadProtocol.h>
#import <LUMCSAdSDK/LUMCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LUMCSAdLoadApplovinReward : LUMCSAdLoadReward<LUMCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
