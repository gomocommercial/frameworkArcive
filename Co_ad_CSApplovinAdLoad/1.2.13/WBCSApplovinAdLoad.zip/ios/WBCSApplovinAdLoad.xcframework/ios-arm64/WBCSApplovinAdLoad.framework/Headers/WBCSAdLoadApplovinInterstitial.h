//
//  WBCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <WBCSAdSDK/WBCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <WBCSAdSDK/WBCSAdLoadProtocol.h>
#import <WBCSAdSDK/WBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface WBCSAdLoadApplovinInterstitial : WBCSAdLoadInterstitial<WBCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
