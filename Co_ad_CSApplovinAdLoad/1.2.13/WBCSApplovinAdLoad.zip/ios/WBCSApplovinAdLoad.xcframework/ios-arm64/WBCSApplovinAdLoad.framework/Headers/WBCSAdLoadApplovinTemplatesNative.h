//
//  WBCSAdLoadApplovinTemplatesNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <WBCSAdSDK/WBCSAdLoadNative.h>
#import <WBCSAdSDK/WBCSAdLoadProtocol.h>
#import <WBCSAdSDK/WBCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface WBCSAdLoadApplovinTemplatesNative : WBCSAdLoadNative<WBCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;
@property (nonatomic, strong) UIView *nativeAdView;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
