//
//  HPFCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <HPFCSAdSDK/HPFCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadApplovinBanner : HPFCSAdLoadBanner <HPFCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
