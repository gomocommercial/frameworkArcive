//
//  HPFCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <HPFCSAdSDK/HPFCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadApplovinInterstitial : HPFCSAdLoadInterstitial<HPFCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
