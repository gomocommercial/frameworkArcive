//
//  HPFCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <HPFCSAdSDK/HPFCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadApplovinReward : HPFCSAdLoadReward<HPFCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
