#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "HPFCSAdLoadApplovinBanner.h"
#import "HPFCSAdLoadApplovinConfig.h"
#import "HPFCSApplovinConfigModel.h"
#import "HPFCSAdLoadApplovinInterstitial.h"
#import "HPFCSAdLoadApplovinAdPlaceNative.h"
#import "HPFCSAdLoadApplovinManualNative.h"
#import "HPFCSAdLoadApplovinTemplatesNative.h"
#import "HPFCSAdLoadApplovinOpen.h"
#import "HPFCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double HPFCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char HPFCSApplovinAdLoadVersionString[];

