//
//  HPFCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <HPFCSAdSDK/HPFCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadApplovinOpen : HPFCSAdLoadOpen <HPFCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
