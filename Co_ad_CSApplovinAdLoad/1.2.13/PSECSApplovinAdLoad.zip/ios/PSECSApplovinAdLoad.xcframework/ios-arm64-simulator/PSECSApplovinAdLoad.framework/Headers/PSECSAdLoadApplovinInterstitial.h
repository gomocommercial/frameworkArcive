//
//  PSECSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PSECSAdSDK/PSECSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PSECSAdSDK/PSECSAdLoadProtocol.h>
#import <PSECSAdSDK/PSECSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSECSAdLoadApplovinInterstitial : PSECSAdLoadInterstitial<PSECSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
