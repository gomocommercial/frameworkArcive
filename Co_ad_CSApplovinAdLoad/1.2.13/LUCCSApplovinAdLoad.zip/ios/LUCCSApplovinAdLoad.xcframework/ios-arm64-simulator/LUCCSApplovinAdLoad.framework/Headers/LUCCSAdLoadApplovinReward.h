//
//  LUCCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <LUCCSAdSDK/LUCCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LUCCSAdSDK/LUCCSAdLoadProtocol.h>
#import <LUCCSAdSDK/LUCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LUCCSAdLoadApplovinReward : LUCCSAdLoadReward<LUCCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
