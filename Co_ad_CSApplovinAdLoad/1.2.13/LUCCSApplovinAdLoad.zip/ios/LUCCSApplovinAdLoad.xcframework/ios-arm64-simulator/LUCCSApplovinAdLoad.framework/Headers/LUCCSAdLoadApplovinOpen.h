//
//  LUCCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LUCCSAdSDK/LUCCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LUCCSAdSDK/LUCCSAdLoadProtocol.h>
#import <LUCCSAdSDK/LUCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LUCCSAdLoadApplovinOpen : LUCCSAdLoadOpen <LUCCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
