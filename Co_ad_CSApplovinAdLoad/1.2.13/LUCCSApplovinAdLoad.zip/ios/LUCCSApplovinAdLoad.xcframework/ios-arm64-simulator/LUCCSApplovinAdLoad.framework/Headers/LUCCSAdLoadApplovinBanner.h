//
//  LUCCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <LUCCSAdSDK/LUCCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LUCCSAdSDK/LUCCSAdLoadProtocol.h>
#import <LUCCSAdSDK/LUCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LUCCSAdLoadApplovinBanner : LUCCSAdLoadBanner <LUCCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
