#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MOVCSAdLoadApplovinBanner.h"
#import "MOVCSAdLoadApplovinConfig.h"
#import "MOVCSApplovinConfigModel.h"
#import "MOVCSAdLoadApplovinInterstitial.h"
#import "MOVCSAdLoadApplovinAdPlaceNative.h"
#import "MOVCSAdLoadApplovinManualNative.h"
#import "MOVCSAdLoadApplovinTemplatesNative.h"
#import "MOVCSAdLoadApplovinOpen.h"
#import "MOVCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double MOVCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char MOVCSApplovinAdLoadVersionString[];

