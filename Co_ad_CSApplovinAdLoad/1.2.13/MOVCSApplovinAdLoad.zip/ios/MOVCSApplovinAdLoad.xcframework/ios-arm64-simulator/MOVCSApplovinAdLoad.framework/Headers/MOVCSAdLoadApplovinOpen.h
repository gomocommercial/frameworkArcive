//
//  MOVCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MOVCSAdSDK/MOVCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MOVCSAdSDK/MOVCSAdLoadProtocol.h>
#import <MOVCSAdSDK/MOVCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MOVCSAdLoadApplovinOpen : MOVCSAdLoadOpen <MOVCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
