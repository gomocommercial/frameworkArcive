//
//  MOVCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MOVCSAdSDK/MOVCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MOVCSAdSDK/MOVCSAdLoadProtocol.h>
#import <MOVCSAdSDK/MOVCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MOVCSAdLoadApplovinReward : MOVCSAdLoadReward<MOVCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
