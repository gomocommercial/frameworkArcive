//
//  MOVCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MOVCSAdSDK/MOVCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MOVCSAdSDK/MOVCSAdLoadProtocol.h>
#import <MOVCSAdSDK/MOVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MOVCSAdLoadApplovinInterstitial : MOVCSAdLoadInterstitial<MOVCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
