//
//  MOVCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <MOVCSAdSDK/MOVCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MOVCSAdSDK/MOVCSAdLoadProtocol.h>
#import <MOVCSAdSDK/MOVCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MOVCSAdLoadApplovinBanner : MOVCSAdLoadBanner <MOVCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
