//
//  GOKCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <GOKCSAdSDK/GOKCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <GOKCSAdSDK/GOKCSAdLoadProtocol.h>
#import <GOKCSAdSDK/GOKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadApplovinInterstitial : GOKCSAdLoadInterstitial<GOKCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
