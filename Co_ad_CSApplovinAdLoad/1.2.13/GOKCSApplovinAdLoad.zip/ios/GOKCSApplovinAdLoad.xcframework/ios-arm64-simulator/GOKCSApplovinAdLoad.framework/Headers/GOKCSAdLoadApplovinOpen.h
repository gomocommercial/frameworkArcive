//
//  GOKCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <GOKCSAdSDK/GOKCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <GOKCSAdSDK/GOKCSAdLoadProtocol.h>
#import <GOKCSAdSDK/GOKCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadApplovinOpen : GOKCSAdLoadOpen <GOKCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
