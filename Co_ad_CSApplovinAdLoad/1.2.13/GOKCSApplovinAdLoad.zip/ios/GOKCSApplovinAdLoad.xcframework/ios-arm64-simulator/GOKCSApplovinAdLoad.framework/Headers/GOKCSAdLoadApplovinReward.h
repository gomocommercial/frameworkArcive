//
//  GOKCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <GOKCSAdSDK/GOKCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <GOKCSAdSDK/GOKCSAdLoadProtocol.h>
#import <GOKCSAdSDK/GOKCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadApplovinReward : GOKCSAdLoadReward<GOKCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
