//
//  GOKCSAdLoadApplovinManualNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <GOKCSAdSDK/GOKCSAdLoadNative.h>
#import <GOKCSAdSDK/GOKCSAdLoadProtocol.h>
#import <GOKCSAdSDK/GOKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadApplovinManualNative : GOKCSAdLoadNative<GOKCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
