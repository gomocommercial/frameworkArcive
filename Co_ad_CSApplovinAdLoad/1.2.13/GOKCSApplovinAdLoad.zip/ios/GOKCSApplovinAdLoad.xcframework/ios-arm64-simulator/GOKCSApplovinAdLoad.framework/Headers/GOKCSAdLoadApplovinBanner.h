//
//  GOKCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <GOKCSAdSDK/GOKCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <GOKCSAdSDK/GOKCSAdLoadProtocol.h>
#import <GOKCSAdSDK/GOKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadApplovinBanner : GOKCSAdLoadBanner <GOKCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
