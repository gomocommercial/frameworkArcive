//
//  QLCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <QLCSAdSDK/QLCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <QLCSAdSDK/QLCSAdLoadProtocol.h>
#import <QLCSAdSDK/QLCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadApplovinBanner : QLCSAdLoadBanner <QLCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
