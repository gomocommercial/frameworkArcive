//
//  QLCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <QLCSAdSDK/QLCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <QLCSAdSDK/QLCSAdLoadProtocol.h>
#import <QLCSAdSDK/QLCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadApplovinOpen : QLCSAdLoadOpen <QLCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
