#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "QLCSAdLoadApplovinBanner.h"
#import "QLCSAdLoadApplovinConfig.h"
#import "QLCSApplovinConfigModel.h"
#import "QLCSAdLoadApplovinInterstitial.h"
#import "QLCSAdLoadApplovinAdPlaceNative.h"
#import "QLCSAdLoadApplovinManualNative.h"
#import "QLCSAdLoadApplovinTemplatesNative.h"
#import "QLCSAdLoadApplovinOpen.h"
#import "QLCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double QLCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char QLCSApplovinAdLoadVersionString[];

