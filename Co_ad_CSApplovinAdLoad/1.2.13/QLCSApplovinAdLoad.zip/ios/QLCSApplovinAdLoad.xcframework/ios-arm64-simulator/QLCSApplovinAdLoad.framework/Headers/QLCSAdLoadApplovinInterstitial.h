//
//  QLCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <QLCSAdSDK/QLCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <QLCSAdSDK/QLCSAdLoadProtocol.h>
#import <QLCSAdSDK/QLCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadApplovinInterstitial : QLCSAdLoadInterstitial<QLCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
