//
//  FFCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FFCSAdSDK/FFCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FFCSAdSDK/FFCSAdLoadProtocol.h>
#import <FFCSAdSDK/FFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdLoadApplovinInterstitial : FFCSAdLoadInterstitial<FFCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
