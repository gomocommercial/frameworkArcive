//
//  FFCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <FFCSAdSDK/FFCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FFCSAdSDK/FFCSAdLoadProtocol.h>
#import <FFCSAdSDK/FFCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdLoadApplovinOpen : FFCSAdLoadOpen <FFCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
