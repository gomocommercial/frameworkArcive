//
//  FFCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FFCSAdSDK/FFCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FFCSAdSDK/FFCSAdLoadProtocol.h>
#import <FFCSAdSDK/FFCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdLoadApplovinReward : FFCSAdLoadReward<FFCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
