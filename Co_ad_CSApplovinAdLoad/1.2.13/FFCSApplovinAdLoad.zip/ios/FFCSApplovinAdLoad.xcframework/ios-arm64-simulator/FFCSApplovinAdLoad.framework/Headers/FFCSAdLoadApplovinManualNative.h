//
//  FFCSAdLoadApplovinManualNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <FFCSAdSDK/FFCSAdLoadNative.h>
#import <FFCSAdSDK/FFCSAdLoadProtocol.h>
#import <FFCSAdSDK/FFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdLoadApplovinManualNative : FFCSAdLoadNative<FFCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
