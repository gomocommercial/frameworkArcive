//
//  FFCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <FFCSAdSDK/FFCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FFCSAdSDK/FFCSAdLoadProtocol.h>
#import <FFCSAdSDK/FFCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FFCSAdLoadApplovinBanner : FFCSAdLoadBanner <FFCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
