//
//  LASCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <LASCSAdSDK/LASCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LASCSAdSDK/LASCSAdLoadProtocol.h>
#import <LASCSAdSDK/LASCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdLoadApplovinInterstitial : LASCSAdLoadInterstitial<LASCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
