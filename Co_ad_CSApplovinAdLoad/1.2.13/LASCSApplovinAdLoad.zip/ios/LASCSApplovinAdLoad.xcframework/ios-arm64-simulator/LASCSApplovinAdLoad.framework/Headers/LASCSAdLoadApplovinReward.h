//
//  LASCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <LASCSAdSDK/LASCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LASCSAdSDK/LASCSAdLoadProtocol.h>
#import <LASCSAdSDK/LASCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdLoadApplovinReward : LASCSAdLoadReward<LASCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
