//
//  LASCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LASCSAdSDK/LASCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LASCSAdSDK/LASCSAdLoadProtocol.h>
#import <LASCSAdSDK/LASCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdLoadApplovinOpen : LASCSAdLoadOpen <LASCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
