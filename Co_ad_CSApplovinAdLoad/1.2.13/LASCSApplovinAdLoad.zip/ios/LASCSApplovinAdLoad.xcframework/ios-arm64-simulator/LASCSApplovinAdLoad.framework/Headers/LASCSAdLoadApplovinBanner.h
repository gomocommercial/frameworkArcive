//
//  LASCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <LASCSAdSDK/LASCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LASCSAdSDK/LASCSAdLoadProtocol.h>
#import <LASCSAdSDK/LASCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LASCSAdLoadApplovinBanner : LASCSAdLoadBanner <LASCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
