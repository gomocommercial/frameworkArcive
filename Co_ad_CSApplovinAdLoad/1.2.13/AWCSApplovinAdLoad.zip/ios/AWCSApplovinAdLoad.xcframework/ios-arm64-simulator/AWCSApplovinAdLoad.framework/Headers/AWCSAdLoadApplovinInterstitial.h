//
//  AWCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AWCSAdSDK/AWCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AWCSAdSDK/AWCSAdLoadProtocol.h>
#import <AWCSAdSDK/AWCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadApplovinInterstitial : AWCSAdLoadInterstitial<AWCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
