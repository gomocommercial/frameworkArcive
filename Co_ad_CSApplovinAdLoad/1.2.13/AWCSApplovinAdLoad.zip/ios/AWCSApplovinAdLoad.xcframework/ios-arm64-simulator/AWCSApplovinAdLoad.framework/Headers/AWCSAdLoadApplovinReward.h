//
//  AWCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <AWCSAdSDK/AWCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <AWCSAdSDK/AWCSAdLoadProtocol.h>
#import <AWCSAdSDK/AWCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface AWCSAdLoadApplovinReward : AWCSAdLoadReward<AWCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
