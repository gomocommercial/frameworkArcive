//
//  CUC_PCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadApplovinReward : CUC_PCSAdLoadReward<CUC_PCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
