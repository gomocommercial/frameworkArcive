//
//  FurTalesCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <FurTalesCSAdSDK/FurTalesCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadProtocol.h>
#import <FurTalesCSAdSDK/FurTalesCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface FurTalesCSAdLoadApplovinReward : FurTalesCSAdLoadReward<FurTalesCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
