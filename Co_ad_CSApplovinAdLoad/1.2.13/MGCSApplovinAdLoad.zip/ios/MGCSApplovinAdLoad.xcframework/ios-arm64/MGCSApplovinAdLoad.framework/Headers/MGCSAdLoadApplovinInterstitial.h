//
//  MGCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MGCSAdSDK/MGCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MGCSAdSDK/MGCSAdLoadProtocol.h>
#import <MGCSAdSDK/MGCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGCSAdLoadApplovinInterstitial : MGCSAdLoadInterstitial<MGCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
