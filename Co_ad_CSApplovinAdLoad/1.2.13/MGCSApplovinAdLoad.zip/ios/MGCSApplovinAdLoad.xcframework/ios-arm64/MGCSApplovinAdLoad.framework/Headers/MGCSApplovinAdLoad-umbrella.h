#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MGCSAdLoadApplovinBanner.h"
#import "MGCSAdLoadApplovinConfig.h"
#import "MGCSApplovinConfigModel.h"
#import "MGCSAdLoadApplovinInterstitial.h"
#import "MGCSAdLoadApplovinAdPlaceNative.h"
#import "MGCSAdLoadApplovinManualNative.h"
#import "MGCSAdLoadApplovinTemplatesNative.h"
#import "MGCSAdLoadApplovinOpen.h"
#import "MGCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double MGCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char MGCSApplovinAdLoadVersionString[];

