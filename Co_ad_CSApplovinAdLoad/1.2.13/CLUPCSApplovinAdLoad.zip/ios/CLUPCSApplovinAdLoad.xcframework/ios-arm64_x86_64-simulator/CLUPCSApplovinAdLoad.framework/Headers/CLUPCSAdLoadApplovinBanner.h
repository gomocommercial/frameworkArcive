//
//  CLUPCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <CLUPCSAdSDK/CLUPCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadProtocol.h>
#import <CLUPCSAdSDK/CLUPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLUPCSAdLoadApplovinBanner : CLUPCSAdLoadBanner <CLUPCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
