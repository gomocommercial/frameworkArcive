#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "CLUPCSAdLoadApplovinBanner.h"
#import "CLUPCSAdLoadApplovinConfig.h"
#import "CLUPCSApplovinConfigModel.h"
#import "CLUPCSAdLoadApplovinInterstitial.h"
#import "CLUPCSAdLoadApplovinAdPlaceNative.h"
#import "CLUPCSAdLoadApplovinManualNative.h"
#import "CLUPCSAdLoadApplovinTemplatesNative.h"
#import "CLUPCSAdLoadApplovinOpen.h"
#import "CLUPCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double CLUPCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char CLUPCSApplovinAdLoadVersionString[];

