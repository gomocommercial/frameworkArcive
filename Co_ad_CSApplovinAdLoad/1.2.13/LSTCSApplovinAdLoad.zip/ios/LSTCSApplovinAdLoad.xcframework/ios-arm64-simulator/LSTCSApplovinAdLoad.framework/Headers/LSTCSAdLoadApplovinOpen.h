//
//  LSTCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LSTCSAdSDK/LSTCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LSTCSAdSDK/LSTCSAdLoadProtocol.h>
#import <LSTCSAdSDK/LSTCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadApplovinOpen : LSTCSAdLoadOpen <LSTCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
