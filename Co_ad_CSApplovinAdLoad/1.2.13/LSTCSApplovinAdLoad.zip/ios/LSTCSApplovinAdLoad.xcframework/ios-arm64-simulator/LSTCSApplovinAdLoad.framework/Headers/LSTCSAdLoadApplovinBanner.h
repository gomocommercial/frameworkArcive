//
//  LSTCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <LSTCSAdSDK/LSTCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LSTCSAdSDK/LSTCSAdLoadProtocol.h>
#import <LSTCSAdSDK/LSTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadApplovinBanner : LSTCSAdLoadBanner <LSTCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
