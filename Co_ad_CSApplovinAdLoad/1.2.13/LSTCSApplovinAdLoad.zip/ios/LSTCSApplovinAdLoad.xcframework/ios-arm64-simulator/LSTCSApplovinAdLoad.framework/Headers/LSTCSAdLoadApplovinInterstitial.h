//
//  LSTCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <LSTCSAdSDK/LSTCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LSTCSAdSDK/LSTCSAdLoadProtocol.h>
#import <LSTCSAdSDK/LSTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadApplovinInterstitial : LSTCSAdLoadInterstitial<LSTCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
