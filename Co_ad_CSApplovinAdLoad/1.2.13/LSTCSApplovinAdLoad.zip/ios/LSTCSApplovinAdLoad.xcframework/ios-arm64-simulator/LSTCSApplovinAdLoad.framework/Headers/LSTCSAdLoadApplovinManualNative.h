//
//  LSTCSAdLoadApplovinManualNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <LSTCSAdSDK/LSTCSAdLoadNative.h>
#import <LSTCSAdSDK/LSTCSAdLoadProtocol.h>
#import <LSTCSAdSDK/LSTCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadApplovinManualNative : LSTCSAdLoadNative<LSTCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
