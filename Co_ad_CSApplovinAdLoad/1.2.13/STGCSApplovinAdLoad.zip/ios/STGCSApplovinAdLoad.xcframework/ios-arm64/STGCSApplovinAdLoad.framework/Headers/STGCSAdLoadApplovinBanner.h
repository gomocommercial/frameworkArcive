//
//  STGCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <STGCSAdSDK/STGCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STGCSAdSDK/STGCSAdLoadProtocol.h>
#import <STGCSAdSDK/STGCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadApplovinBanner : STGCSAdLoadBanner <STGCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
