#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "STGCSAdLoadApplovinBanner.h"
#import "STGCSAdLoadApplovinConfig.h"
#import "STGCSApplovinConfigModel.h"
#import "STGCSAdLoadApplovinInterstitial.h"
#import "STGCSAdLoadApplovinAdPlaceNative.h"
#import "STGCSAdLoadApplovinManualNative.h"
#import "STGCSAdLoadApplovinTemplatesNative.h"
#import "STGCSAdLoadApplovinOpen.h"
#import "STGCSAdLoadApplovinReward.h"

FOUNDATION_EXPORT double STGCSApplovinAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char STGCSApplovinAdLoadVersionString[];

