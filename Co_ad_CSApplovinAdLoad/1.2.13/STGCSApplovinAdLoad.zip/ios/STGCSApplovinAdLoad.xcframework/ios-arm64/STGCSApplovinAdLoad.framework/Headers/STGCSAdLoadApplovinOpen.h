//
//  STGCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <STGCSAdSDK/STGCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STGCSAdSDK/STGCSAdLoadProtocol.h>
#import <STGCSAdSDK/STGCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadApplovinOpen : STGCSAdLoadOpen <STGCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
