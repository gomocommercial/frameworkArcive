//
//  STGCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <STGCSAdSDK/STGCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STGCSAdSDK/STGCSAdLoadProtocol.h>
#import <STGCSAdSDK/STGCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadApplovinReward : STGCSAdLoadReward<STGCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
