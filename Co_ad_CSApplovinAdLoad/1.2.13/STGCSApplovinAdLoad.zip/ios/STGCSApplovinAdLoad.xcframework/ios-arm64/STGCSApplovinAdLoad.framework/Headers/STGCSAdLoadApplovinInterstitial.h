//
//  STGCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <STGCSAdSDK/STGCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <STGCSAdSDK/STGCSAdLoadProtocol.h>
#import <STGCSAdSDK/STGCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadApplovinInterstitial : STGCSAdLoadInterstitial<STGCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
