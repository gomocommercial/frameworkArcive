//
//  JLCCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <JLCCSAdSDK/JLCCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JLCCSAdSDK/JLCCSAdLoadProtocol.h>
#import <JLCCSAdSDK/JLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadApplovinInterstitial : JLCCSAdLoadInterstitial<JLCCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
