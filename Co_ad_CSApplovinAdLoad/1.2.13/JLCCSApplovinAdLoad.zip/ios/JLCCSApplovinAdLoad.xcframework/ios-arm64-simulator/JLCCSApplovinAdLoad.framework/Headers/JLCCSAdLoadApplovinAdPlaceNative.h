//
//  JLCCSAdLoadApplovinAdPlaceNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <JLCCSAdSDK/JLCCSAdLoadNative.h>
#import <JLCCSAdSDK/JLCCSAdLoadProtocol.h>
#import <JLCCSAdSDK/JLCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadApplovinAdPlaceNative : JLCCSAdLoadNative<JLCCSAdLoadProtocol,MAAdPlacerDelegate>

@property(nonatomic, strong) MATableViewAdPlacer *adTablePlacer;
@property(nonatomic, strong) MACollectionViewAdPlacer *adCollectionPlacer;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
