//
//  JLCCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <JLCCSAdSDK/JLCCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JLCCSAdSDK/JLCCSAdLoadProtocol.h>
#import <JLCCSAdSDK/JLCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface JLCCSAdLoadApplovinReward : JLCCSAdLoadReward<JLCCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
