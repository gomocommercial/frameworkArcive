//
//  PCRCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <PCRCSAdSDK/PCRCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCRCSAdSDK/PCRCSAdLoadProtocol.h>
#import <PCRCSAdSDK/PCRCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCRCSAdLoadApplovinBanner : PCRCSAdLoadBanner <PCRCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
