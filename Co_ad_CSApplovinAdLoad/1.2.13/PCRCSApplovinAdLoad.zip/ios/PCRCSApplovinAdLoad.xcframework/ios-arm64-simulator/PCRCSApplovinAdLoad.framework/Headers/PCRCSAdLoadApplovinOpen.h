//
//  PCRCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PCRCSAdSDK/PCRCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCRCSAdSDK/PCRCSAdLoadProtocol.h>
#import <PCRCSAdSDK/PCRCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PCRCSAdLoadApplovinOpen : PCRCSAdLoadOpen <PCRCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
