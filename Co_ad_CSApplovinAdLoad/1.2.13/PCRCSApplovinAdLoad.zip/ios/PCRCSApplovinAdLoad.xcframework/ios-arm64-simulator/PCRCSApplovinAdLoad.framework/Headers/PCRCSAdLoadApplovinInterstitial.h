//
//  PCRCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PCRCSAdSDK/PCRCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCRCSAdSDK/PCRCSAdLoadProtocol.h>
#import <PCRCSAdSDK/PCRCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCRCSAdLoadApplovinInterstitial : PCRCSAdLoadInterstitial<PCRCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
