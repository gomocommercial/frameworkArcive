//
//  PCRCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PCRCSAdSDK/PCRCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCRCSAdSDK/PCRCSAdLoadProtocol.h>
#import <PCRCSAdSDK/PCRCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PCRCSAdLoadApplovinReward : PCRCSAdLoadReward<PCRCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
