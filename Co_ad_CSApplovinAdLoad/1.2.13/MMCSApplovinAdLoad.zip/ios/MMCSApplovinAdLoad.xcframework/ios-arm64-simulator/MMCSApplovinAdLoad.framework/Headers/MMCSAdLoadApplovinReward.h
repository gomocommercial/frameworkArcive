//
//  MMCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MMCSAdSDK/MMCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MMCSAdSDK/MMCSAdLoadProtocol.h>
#import <MMCSAdSDK/MMCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MMCSAdLoadApplovinReward : MMCSAdLoadReward<MMCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
