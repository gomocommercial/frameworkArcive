//
//  MMCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <MMCSAdSDK/MMCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MMCSAdSDK/MMCSAdLoadProtocol.h>
#import <MMCSAdSDK/MMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MMCSAdLoadApplovinInterstitial : MMCSAdLoadInterstitial<MMCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
