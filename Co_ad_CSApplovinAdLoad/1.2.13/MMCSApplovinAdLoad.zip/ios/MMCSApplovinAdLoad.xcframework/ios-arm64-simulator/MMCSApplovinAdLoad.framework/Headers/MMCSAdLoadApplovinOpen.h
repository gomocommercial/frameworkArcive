//
//  MMCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <MMCSAdSDK/MMCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MMCSAdSDK/MMCSAdLoadProtocol.h>
#import <MMCSAdSDK/MMCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface MMCSAdLoadApplovinOpen : MMCSAdLoadOpen <MMCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
