//
//  MMCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <MMCSAdSDK/MMCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <MMCSAdSDK/MMCSAdLoadProtocol.h>
#import <MMCSAdSDK/MMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface MMCSAdLoadApplovinBanner : MMCSAdLoadBanner <MMCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
