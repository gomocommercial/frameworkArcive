//
//  PPCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PPCSAdSDK/PPCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PPCSAdSDK/PPCSAdLoadProtocol.h>
#import <PPCSAdSDK/PPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPCSAdLoadApplovinInterstitial : PPCSAdLoadInterstitial<PPCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
