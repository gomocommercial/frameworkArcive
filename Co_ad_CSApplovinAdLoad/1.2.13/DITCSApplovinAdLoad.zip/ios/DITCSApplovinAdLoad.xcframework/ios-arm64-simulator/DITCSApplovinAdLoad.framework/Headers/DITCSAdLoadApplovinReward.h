//
//  DITCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <DITCSAdSDK/DITCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DITCSAdSDK/DITCSAdLoadProtocol.h>
#import <DITCSAdSDK/DITCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdLoadApplovinReward : DITCSAdLoadReward<DITCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
