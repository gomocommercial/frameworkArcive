//
//  DITCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <DITCSAdSDK/DITCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DITCSAdSDK/DITCSAdLoadProtocol.h>
#import <DITCSAdSDK/DITCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdLoadApplovinBanner : DITCSAdLoadBanner <DITCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
