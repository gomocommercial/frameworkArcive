//
//  DITCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <DITCSAdSDK/DITCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DITCSAdSDK/DITCSAdLoadProtocol.h>
#import <DITCSAdSDK/DITCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdLoadApplovinInterstitial : DITCSAdLoadInterstitial<DITCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
