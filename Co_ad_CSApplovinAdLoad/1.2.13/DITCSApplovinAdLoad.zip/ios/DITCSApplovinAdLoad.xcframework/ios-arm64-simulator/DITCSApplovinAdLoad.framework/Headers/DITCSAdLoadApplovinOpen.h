//
//  DITCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <DITCSAdSDK/DITCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DITCSAdSDK/DITCSAdLoadProtocol.h>
#import <DITCSAdSDK/DITCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DITCSAdLoadApplovinOpen : DITCSAdLoadOpen <DITCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
