//
//  PCSCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PCSCSAdSDK/PCSCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadApplovinReward : PCSCSAdLoadReward<PCSCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
