//
//  PCSCSAdLoadApplovinTemplatesNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCSCSAdSDK/PCSCSAdLoadNative.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadApplovinTemplatesNative : PCSCSAdLoadNative<PCSCSAdLoadProtocol,MANativeAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAd * ad;
@property (nonatomic, strong) UIView *nativeAdView;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
