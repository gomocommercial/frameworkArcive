//
//  PCSCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PCSCSAdSDK/PCSCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadApplovinInterstitial : PCSCSAdLoadInterstitial<PCSCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
