//
//  PCSCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PCSCSAdSDK/PCSCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadApplovinOpen : PCSCSAdLoadOpen <PCSCSAdLoadProtocol,MAAdDelegate, MAAdRevenueDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
