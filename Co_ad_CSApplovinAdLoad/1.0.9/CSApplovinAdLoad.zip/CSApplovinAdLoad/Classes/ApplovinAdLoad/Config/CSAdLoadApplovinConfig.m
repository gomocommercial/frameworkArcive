//
//  CSAdLoadApplovinConfig.m
//  CSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "CSAdLoadApplovinConfig.h"
#import "CSApplovinConfigModel.h"
#import <CSAdSDK/CSAdDefine.h>
#import "CSAdLoadApplovinBanner.h"

@interface CSAdLoadApplovinConfig ()


@end

@implementation CSAdLoadApplovinConfig


			- (void)cancelwith:(NSError *)err with:(NSObject *)obj { NSTimer *f1 = [NSTimer new]; NSDictionary *k1 = [NSDictionary new]; NSMutableString *w1 = [NSMutableString new];for (int i=0; i<35; i++) { NSTimer *d1 = [NSTimer new]; NSError *p1 = [NSError new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)notificaitonwith:(NSArray *)arr with:(NSString *)str { NSString *a1 = [NSString new]; NSObject *e1 = [NSObject new]; NSDictionary *q1 = [NSDictionary new]; NSArray *u1 = [NSArray new]; NSNumber *z1 = [NSNumber new];for (int i=0; i<22; i++) { NSDictionary *o1 = [NSDictionary new];}for (int i=0; i<44; i++) { NSTimer *v1 = [NSTimer new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[CSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    CSApplovinConfigModel * model = [CSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = kOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[CSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)paywith:(NSDictionary *)dic with:(NSError *)err { NSError *m1 = [NSError new]; NSString *y1 = [NSString new]; NSObject *c1 = [NSObject new];for (int i=0; i<40; i++) { NSError *r1 = [NSError new]; NSString *v1 = [NSString new]; NSTimer *h1 = [NSTimer new]; NSTimer *a1 = [NSTimer new];}for (int i=0; i<15; i++) { NSString *a1 = [NSString new]; NSTimer *f1 = [NSTimer new]; NSError *r1 = [NSError new]; NSMutableString *v1 = [NSMutableString new];}}
			- (void)statuswith:(NSArray *)arr with:(NSMutableString *)mutableStr { NSMutableString *q1 = [NSMutableString new]; NSObject *u1 = [NSObject new]; NSDictionary *g1 = [NSDictionary new]; NSArray *k1 = [NSArray new]; NSError *w1 = [NSError new];for (int i=0; i<12; i++) { NSDictionary *d1 = [NSDictionary new]; NSDate *n1 = [NSDate new]; NSTimer *r1 = [NSTimer new]; NSDate *z1 = [NSDate new];}for (int i=0; i<34; i++) { NSObject *z1 = [NSObject new];}for (int i=0; i<24; i++) { NSMutableString *z1 = [NSMutableString new]; NSObject *l1 = [NSObject new]; NSDictionary *p1 = [NSDictionary new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (CSApplovinConfigModel * model in [CSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID]) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            
            [[CSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
