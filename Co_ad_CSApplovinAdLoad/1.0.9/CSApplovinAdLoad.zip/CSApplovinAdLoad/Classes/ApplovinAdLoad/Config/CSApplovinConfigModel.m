//
//  CSApplovinConfigModel.m
//  CSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "CSApplovinConfigModel.h"

@implementation CSApplovinConfigModel

@end
