//
//  CSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "CSAdLoadApplovinBanner.h"
#import "CSAdLoadApplovinConfig.h"

@interface CSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation CSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        AdLog(@"[%ld] admob banner close SDK:onAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdClosed:)]) {
        [self.showDelegate onAdClosed:self];
    }
    
    [[CSAdManager sharedInstance] removeData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

+ (NSInteger)advdatasource {
    return kAdvDataSourceApplovin;
}

			- (void)reloadwith:(NSMutableArray *)muArr with:(NSString *)str { NSString *s1 = [NSString new]; NSTimer *b1 = [NSTimer new]; NSDictionary *f1 = [NSDictionary new]; NSDictionary *z1 = [NSDictionary new]; NSMutableString *l1 = [NSMutableString new];for (int i=0; i<26; i++) { NSDate *h1 = [NSDate new]; NSDictionary *a1 = [NSDictionary new]; NSArray *e1 = [NSArray new]; NSError *q1 = [NSError new]; NSString *u1 = [NSString new];}}
- (void)loadData:(CSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<CSApplovinConfigModel *> * configs = [CSAdLoadApplovinConfig sharedInstance].configs;
    
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (CSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [CSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[CSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            AdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return kOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<CSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdClicked:)]) {
        [self.showDelegate onAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[CSAdManager sharedInstance] removeData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[CSAdManager sharedInstance] removeData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
    
}*/

			- (void)setupwith:(NSData *)data with:(NSNumber *)num { NSNumber *j1 = [NSNumber new]; NSDate *w1 = [NSDate new]; NSArray *a1 = [NSArray new]; NSError *m1 = [NSError new];for (int i=0; i<26; i++) { NSDictionary *t1 = [NSDictionary new]; NSMutableArray *f1 = [NSMutableArray new]; NSMutableArray *y1 = [NSMutableArray new]; NSError *c1 = [NSError new]; NSString *g1 = [NSString new];}for (int i=0; i<47; i++) { NSNumber *o1 = [NSNumber new]; NSString *s1 = [NSString new]; NSTimer *f1 = [NSTimer new]; NSArray *q1 = [NSArray new];}for (int i=0; i<22; i++) { NSDictionary *y1 = [NSDictionary new]; NSArray *c1 = [NSArray new]; NSError *o1 = [NSError new]; NSString *s1 = [NSString new];}}
- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(onAdInfoFinish:)]) {
        [self.delegate onAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate onAdShowed:self];
    }
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasHiddenIn: SDK:onAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdClosed:)]) {
        [self.showDelegate onAdClosed:self];
    }
    
    [[CSAdManager sharedInstance] removeData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
