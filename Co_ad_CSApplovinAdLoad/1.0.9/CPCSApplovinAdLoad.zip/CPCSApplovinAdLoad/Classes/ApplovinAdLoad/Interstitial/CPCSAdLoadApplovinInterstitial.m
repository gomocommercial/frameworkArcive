//
//  CPCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "CPCSAdLoadApplovinInterstitial.h"

@interface CPCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation CPCSAdLoadApplovinInterstitial


			- (void)loadwith:(NSTimer *)timer { NSTimer *r1 = [NSTimer new]; NSData *v1 = [NSData new]; NSMutableString *h1 = [NSMutableString new];for (int i=0; i<35; i++) { NSArray *w1 = [NSArray new]; NSData *a1 = [NSData new];}for (int i=0; i<21; i++) { NSArray *a1 = [NSArray new]; NSError *m1 = [NSError new]; NSError *g1 = [NSError new]; NSDate *k1 = [NSDate new]; NSTimer *o1 = [NSTimer new];}}
- (void)cPloadData:(CPCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
    
}

- (BOOL)isValid{
    return self.ad.ready;
}

			- (void)removewith:(NSMutableString *)mutableStr { NSMutableString *y1 = [NSMutableString new]; NSObject *k1 = [NSObject new]; NSDate *o1 = [NSDate new]; NSArray *a1 = [NSArray new]; NSError *e1 = [NSError new];for (int i=0; i<2; i++) { NSDictionary *t1 = [NSDictionary new]; NSArray *s1 = [NSArray new]; NSMutableArray *q1 = [NSMutableArray new]; NSNumber *v1 = [NSNumber new];}for (int i=0; i<27; i++) { NSMutableString *d1 = [NSMutableString new]; NSNumber *h1 = [NSNumber new]; NSDate *t1 = [NSDate new]; NSArray *s1 = [NSArray new];}for (int i=0; i<24; i++) { NSDate *s1 = [NSDate new]; NSArray *j1 = [NSArray new]; NSData *n1 = [NSData new];}}
- (void)show:(id)target delegate:(id<CPCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return cPkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return cPkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(cPonAdInfoFinish:)]) {
        [self.delegate cPonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(cPonAdShowed:)]) {
        [self.showDelegate cPonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovin wasHiddenIn: SDK:cPonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cPonAdClosed:)]) {
        [self.showDelegate cPonAdClosed:self];
    }
    
    [[CPCSAdManager sharedInstance] cPremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cPonAdClicked:)]) {
        [self.showDelegate cPonAdClicked:self];
    }
}


			- (void)cancelwith:(NSNumber *)num { NSNumber *w1 = [NSNumber new]; NSDate *a1 = [NSDate new];for (int i=0; i<48; i++) { NSMutableString *p1 = [NSMutableString new]; NSObject *b1 = [NSObject new];}for (int i=0; i<34; i++) { NSString *b1 = [NSString new]; NSObject *f1 = [NSObject new]; NSDictionary *r1 = [NSDictionary new];}for (int i=0; i<16; i++) { NSObject *r1 = [NSObject new]; NSDictionary *d1 = [NSDictionary new]; NSMutableArray *i1 = [NSMutableArray new]; NSNumber *m1 = [NSNumber new]; NSDate *y1 = [NSDate new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:cPonAdOtherEvent:event:CPCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(cPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cPonAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[CPCSAdManager sharedInstance] cPremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: cPonAdFail:error:", self.dataModel.moduleId);
        cPAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(cPonAdFail:error:)]) {
        [self.delegate cPonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:cPonAdOtherEvent:event:CPCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(cPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cPonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[CPCSAdManager sharedInstance] cPremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: cPonAdFail:error:", self.dataModel.moduleId);
        cPAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(cPonAdFail:error:)]) {
        [self.delegate cPonAdFail:self error:errorT];
    }
    
}*/





@end
