//
//  CPCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <CPCSAdSDK/CPCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CPCSAdSDK/CPCSAdLoadProtocol.h>
#import <CPCSAdSDK/CPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CPCSAdLoadApplovinInterstitial : CPCSAdLoadInterstitial<CPCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
