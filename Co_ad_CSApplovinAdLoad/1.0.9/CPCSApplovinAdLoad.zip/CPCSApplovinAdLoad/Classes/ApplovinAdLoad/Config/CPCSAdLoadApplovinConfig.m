//
//  CPCSAdLoadApplovinConfig.m
//  CPCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "CPCSAdLoadApplovinConfig.h"
#import "CPCSApplovinConfigModel.h"
#import <CPCSAdSDK/CPCSAdDefine.h>
#import "CPCSAdLoadApplovinBanner.h"

@interface CPCSAdLoadApplovinConfig ()


@end

@implementation CPCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)reloadwith:(NSDictionary *)dic with:(NSNumber *)num { NSNumber *k1 = [NSNumber new]; NSDate *o1 = [NSDate new]; NSTimer *s1 = [NSTimer new]; NSData *e1 = [NSData new];for (int i=0; i<18; i++) { NSDate *l1 = [NSDate new]; NSObject *t1 = [NSObject new]; NSObject *m1 = [NSObject new]; NSDate *q1 = [NSDate new]; NSArray *u1 = [NSArray new];}for (int i=0; i<15; i++) { NSDictionary *c1 = [NSDictionary new]; NSArray *g1 = [NSArray new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[CPCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)actionwith:(NSMutableArray *)muArr { NSMutableArray *h1 = [NSMutableArray new]; NSNumber *l1 = [NSNumber new]; NSMutableString *p1 = [NSMutableString new]; NSNumber *k1 = [NSNumber new];for (int i=0; i<46; i++) { NSData *z1 = [NSData new]; NSMutableString *d1 = [NSMutableString new]; NSMutableString *w1 = [NSMutableString new]; NSObject *i1 = [NSObject new];}}
			- (void)resumewith:(NSError *)err with:(NSObject *)obj { NSObject *f1 = [NSObject new]; NSDictionary *r1 = [NSDictionary new]; NSArray *w1 = [NSArray new]; NSNumber *i1 = [NSNumber new];for (int i=0; i<35; i++) { NSDictionary *p1 = [NSDictionary new]; NSMutableString *b1 = [NSMutableString new]; NSMutableString *u1 = [NSMutableString new]; NSObject *y1 = [NSObject new];}for (int i=0; i<11; i++) { NSMutableString *y1 = [NSMutableString new]; NSObject *k1 = [NSObject new]; NSDate *o1 = [NSDate new]; NSArray *a1 = [NSArray new]; NSError *e1 = [NSError new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    CPCSApplovinConfigModel * model = [CPCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = cPkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[CPCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (CPCSApplovinConfigModel * model in [CPCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID]) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            
            [[CPCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
