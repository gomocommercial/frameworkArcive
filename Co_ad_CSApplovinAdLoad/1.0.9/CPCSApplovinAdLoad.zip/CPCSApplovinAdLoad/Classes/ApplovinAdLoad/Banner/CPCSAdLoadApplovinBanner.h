//
//  CPCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <CPCSAdSDK/CPCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CPCSAdSDK/CPCSAdLoadProtocol.h>
#import <CPCSAdSDK/CPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CPCSAdLoadApplovinBanner : CPCSAdLoadBanner <CPCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
