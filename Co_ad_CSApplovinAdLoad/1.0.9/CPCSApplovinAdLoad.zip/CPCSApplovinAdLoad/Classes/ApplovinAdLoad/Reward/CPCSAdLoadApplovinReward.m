//
//  CPCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "CPCSAdLoadApplovinReward.h"
#import <CPCSAdSDK/CPCSAdStatistics.h>
#import <CPCSAdSDK/CPCSAdDefine.h>

//static NSMutableArray * cPapplovinRewardLoadList;

@interface CPCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation CPCSAdLoadApplovinReward

- (void)cPloadData:(CPCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

			- (void)actionwith:(NSString *)str { NSArray *b1 = [NSArray new]; NSError *g1 = [NSError new];for (int i=0; i<33; i++) { NSDictionary *u1 = [NSDictionary new]; NSMutableString *h1 = [NSMutableString new];}for (int i=0; i<19; i++) { NSError *h1 = [NSError new]; NSMutableString *l1 = [NSMutableString new]; NSObject *s1 = [NSObject new];}for (int i=0; i<2; i++) { NSMutableString *s1 = [NSMutableString new];}}
- (void)show:(id)target delegate:(id<CPCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

			- (void)resumewith:(NSDictionary *)dic with:(NSError *)err { NSError *s1 = [NSError new]; NSString *e1 = [NSString new];for (int i=0; i<8; i++) { NSMutableArray *l1 = [NSMutableArray new]; NSData *t1 = [NSData new];}for (int i=0; i<20; i++) { NSTimer *t1 = [NSTimer new]; NSArray *m1 = [NSArray new]; NSData *q1 = [NSData new]; NSMutableString *c1 = [NSMutableString new];}}
- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[cPkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return cPkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return cPkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(cPonAdInfoFinish:)]) {
        [self.delegate cPonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(cPonAdShowed:)]) {
        [self.showDelegate cPonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:cPonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cPonAdClosed:)]) {
        [self.showDelegate cPonAdClosed:self];
    }
    
    [[CPCSAdManager sharedInstance] cPremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cPonAdClicked:)]) {
        [self.showDelegate cPonAdClicked:self];
    }
}

- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:cPonAdOtherEvent:event:CPCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(cPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cPonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:cPonAdFail:error:", self.dataModel.moduleId);
        cPAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(cPonAdFail:error:)]) {
        [self.delegate cPonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:cPonAdOtherEvent:event:CPCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(cPonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate cPonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:cPonAdFail:error:", self.dataModel.moduleId);
        cPAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(cPonAdFail:error:)]) {
        [self.delegate cPonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:cPonAdOtherEvent:event:CPCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cPonAdOtherEvent:event:)]) {
        [self.showDelegate cPonAdOtherEvent:self event:CPCSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(cPonAdVideoCompletePlaying:)]) {
        [self.showDelegate cPonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[CPCSAdStatistics sharedInstance] cPadRewardVideoCompleteStatistic:self.dataModel];
}

			- (void)addwith:(NSMutableArray *)muArr with:(NSString *)str { NSString *c1 = [NSString new]; NSObject *g1 = [NSObject new]; NSDictionary *k1 = [NSDictionary new]; NSMutableArray *s1 = [NSMutableArray new]; NSNumber *b1 = [NSNumber new];for (int i=0; i<2; i++) { NSDictionary *q1 = [NSDictionary new];}for (int i=0; i<24; i++) { NSTimer *q1 = [NSTimer new]; NSArray *j1 = [NSArray new]; NSError *v1 = [NSError new];}}
- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        cPAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:cPonAdOtherEvent:event:CPCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(cPonAdOtherEvent:event:)]) {
        [self.showDelegate cPonAdOtherEvent:self event:CPCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
