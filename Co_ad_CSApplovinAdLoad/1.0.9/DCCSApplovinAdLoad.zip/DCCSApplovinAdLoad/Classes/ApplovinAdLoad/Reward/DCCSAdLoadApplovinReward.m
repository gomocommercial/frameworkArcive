//
//  DCCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "DCCSAdLoadApplovinReward.h"
#import <DCCSAdSDK/DCCSAdStatistics.h>
#import <DCCSAdSDK/DCCSAdDefine.h>

//static NSMutableArray * dCapplovinRewardLoadList;

@interface DCCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation DCCSAdLoadApplovinReward

- (void)dCloadData:(DCCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<DCCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

			- (void)resetwith:(NSArray *)arr with:(NSString *)str { NSString *g1 = [NSString new];for (int i=0; i<33; i++) { NSMutableArray *n1 = [NSMutableArray new]; NSNumber *z1 = [NSNumber new];}for (int i=0; i<20; i++) { NSMutableArray *z1 = [NSMutableArray new]; NSNumber *l1 = [NSNumber new]; NSDate *p1 = [NSDate new];}for (int i=0; i<2; i++) { NSNumber *p1 = [NSNumber new];}}
			- (void)addwith:(NSError *)err { NSError *s1 = [NSError new]; NSMutableString *b1 = [NSMutableString new]; NSObject *n1 = [NSObject new];for (int i=0; i<25; i++) { NSError *u1 = [NSError new]; NSString *g1 = [NSString new];}for (int i=0; i<11; i++) { NSError *g1 = [NSError new]; NSError *z1 = [NSError new]; NSString *d1 = [NSString new]; NSArray *q1 = [NSArray new]; NSData *u1 = [NSData new];}}
- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[dCkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return dCkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return dCkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(dConAdInfoFinish:)]) {
        [self.delegate dConAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdShowed:)]) {
        [self.showDelegate dConAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:dConAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dConAdClosed:)]) {
        [self.showDelegate dConAdClosed:self];
    }
    
    [[DCCSAdManager sharedInstance] dCremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdClicked:)]) {
        [self.showDelegate dConAdClicked:self];
    }
}

			- (void)paywith:(NSDictionary *)dic { NSDictionary *c1 = [NSDictionary new]; NSArray *g1 = [NSArray new];for (int i=0; i<38; i++) { NSObject *v1 = [NSObject new]; NSDictionary *z1 = [NSDictionary new];}for (int i=0; i<6; i++) { NSTimer *h1 = [NSTimer new]; NSDictionary *l1 = [NSDictionary new]; NSMutableArray *s1 = [NSMutableArray new];}for (int i=0; i<6; i++) { NSData *s1 = [NSData new]; NSMutableArray *b1 = [NSMutableArray new]; NSNumber *n1 = [NSNumber new]; NSNumber *h1 = [NSNumber new]; NSDictionary *l1 = [NSDictionary new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:dConAdOtherEvent:event:DCCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dConAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:dConAdFail:error:", self.dataModel.moduleId);
        dCAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(dConAdFail:error:)]) {
        [self.delegate dConAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:dConAdOtherEvent:event:DCCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dConAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:dConAdFail:error:", self.dataModel.moduleId);
        dCAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(dConAdFail:error:)]) {
        [self.delegate dConAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:dConAdOtherEvent:event:DCCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dConAdOtherEvent:event:)]) {
        [self.showDelegate dConAdOtherEvent:self event:DCCSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdVideoCompletePlaying:)]) {
        [self.showDelegate dConAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[DCCSAdStatistics sharedInstance] dCadRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:dConAdOtherEvent:event:DCCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dConAdOtherEvent:event:)]) {
        [self.showDelegate dConAdOtherEvent:self event:DCCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
