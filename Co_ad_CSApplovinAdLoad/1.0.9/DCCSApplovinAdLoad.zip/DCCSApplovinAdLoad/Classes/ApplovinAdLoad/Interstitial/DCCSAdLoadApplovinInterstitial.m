//
//  DCCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "DCCSAdLoadApplovinInterstitial.h"

@interface DCCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation DCCSAdLoadApplovinInterstitial


- (void)dCloadData:(DCCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<DCCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return dCkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return dCkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(dConAdInfoFinish:)]) {
        [self.delegate dConAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdShowed:)]) {
        [self.showDelegate dConAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin wasHiddenIn: SDK:dConAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dConAdClosed:)]) {
        [self.showDelegate dConAdClosed:self];
    }
    
    [[DCCSAdManager sharedInstance] dCremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdClicked:)]) {
        [self.showDelegate dConAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dConAdOtherEvent:event:DCCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dConAdShowFail:self error:errorT];
    }
}


			- (void)setupwith:(NSObject *)obj with:(NSArray *)arr { NSArray *k1 = [NSArray new]; NSError *w1 = [NSError new]; NSString *a1 = [NSString new]; NSObject *e1 = [NSObject new]; NSDictionary *r1 = [NSDictionary new];for (int i=0; i<22; i++) { NSString *f1 = [NSString new]; NSMutableArray *m1 = [NSMutableArray new]; NSNumber *z1 = [NSNumber new]; NSDate *d1 = [NSDate new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[DCCSAdManager sharedInstance] dCremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dConAdFail:error:", self.dataModel.moduleId);
        dCAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(dConAdFail:error:)]) {
        [self.delegate dConAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dConAdOtherEvent:event:DCCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dConAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[DCCSAdManager sharedInstance] dCremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dConAdFail:error:", self.dataModel.moduleId);
        dCAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(dConAdFail:error:)]) {
        [self.delegate dConAdFail:self error:errorT];
    }
    
}*/





@end
