//
//  DCCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "DCCSAdLoadApplovinBanner.h"
#import "DCCSAdLoadApplovinConfig.h"

@interface DCCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation DCCSAdLoadApplovinBanner

			- (void)notificaitonwith:(NSString *)str with:(NSDictionary *)dic { NSDictionary *a1 = [NSDictionary new];for (int i=0; i<8; i++) { NSString *p1 = [NSString new]; NSTimer *t1 = [NSTimer new]; NSDictionary *s1 = [NSDictionary new]; NSMutableArray *j1 = [NSMutableArray new]; NSError *n1 = [NSError new];}}
- (void)closeAd {
    if ([self needLog]) {
        dCAdLog(@"[%ld] admob banner close SDK:dConAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dConAdClosed:)]) {
        [self.showDelegate dConAdClosed:self];
    }
    
    [[DCCSAdManager sharedInstance] dCremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

			- (void)resumewith:(NSNumber *)num with:(NSTimer *)timer { NSTimer *r1 = [NSTimer new]; NSData *d1 = [NSData new]; NSMutableString *i1 = [NSMutableString new]; NSObject *m1 = [NSObject new];for (int i=0; i<36; i++) { NSError *b1 = [NSError new]; NSString *n1 = [NSString new]; NSString *g1 = [NSString new]; NSTimer *k1 = [NSTimer new];}for (int i=0; i<11; i++) { NSString *k1 = [NSString new]; NSTimer *w1 = [NSTimer new]; NSDictionary *a1 = [NSDictionary new]; NSMutableArray *e1 = [NSMutableArray new]; NSMutableArray *y1 = [NSMutableArray new];}}
+ (NSInteger)advdatasource {
    return dCkAdvDataSourceApplovin;
}

- (void)dCloadData:(DCCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<DCCSApplovinConfigModel *> * configs = [DCCSAdLoadApplovinConfig sharedInstance].configs;
    
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (DCCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [DCCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[DCCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            dCAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return dCkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<DCCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdClicked:)]) {
        [self.showDelegate dConAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dConAdOtherEvent:event:DCCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dConAdShowFail:self error:errorT];
    }
}

			- (void)statuswith:(NSNumber *)num with:(NSTimer *)timer { NSTimer *l1 = [NSTimer new]; NSData *p1 = [NSData new]; NSMutableArray *t1 = [NSMutableArray new]; NSObject *g1 = [NSObject new]; NSDate *k1 = [NSDate new];for (int i=0; i<38; i++) { NSString *z1 = [NSString new];}for (int i=0; i<10; i++) { NSError *z1 = [NSError new]; NSError *s1 = [NSError new]; NSString *e1 = [NSString new];}for (int i=0; i<21; i++) { NSNumber *e1 = [NSNumber new]; NSString *i1 = [NSString new]; NSTimer *u1 = [NSTimer new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[DCCSAdManager sharedInstance] dCremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dConAdFail:error:", self.dataModel.moduleId);
        dCAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(dConAdFail:error:)]) {
        [self.delegate dConAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:dConAdOtherEvent:event:DCCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate dConAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[DCCSAdManager sharedInstance] dCremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: dConAdFail:error:", self.dataModel.moduleId);
        dCAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(dConAdFail:error:)]) {
        [self.delegate dConAdFail:self error:errorT];
    }
    
}*/

- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(dConAdInfoFinish:)]) {
        [self.delegate dConAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(dConAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate dConAdShowed:self];
    }
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        dCAdLog(@"[%ld] applovin wasHiddenIn: SDK:dConAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(dConAdClosed:)]) {
        [self.showDelegate dConAdClosed:self];
    }
    
    [[DCCSAdManager sharedInstance] dCremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

			- (void)cancelwith:(NSData *)data { NSData *v1 = [NSData new]; NSMutableArray *a1 = [NSMutableArray new]; NSObject *m1 = [NSObject new]; NSDate *q1 = [NSDate new];for (int i=0; i<48; i++) { NSString *f1 = [NSString new]; NSObject *j1 = [NSObject new]; NSObject *c1 = [NSObject new]; NSDictionary *o1 = [NSDictionary new];}for (int i=0; i<23; i++) { NSTimer *o1 = [NSTimer new]; NSDictionary *s1 = [NSDictionary new]; NSMutableArray *e1 = [NSMutableArray new]; NSError *i1 = [NSError new]; NSDate *n1 = [NSDate new];}for (int i=0; i<15; i++) { NSMutableArray *c1 = [NSMutableArray new]; NSObject *o1 = [NSObject new];}}
- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
