//
//  DCCSAdLoadApplovinConfig.m
//  DCCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "DCCSAdLoadApplovinConfig.h"
#import "DCCSApplovinConfigModel.h"
#import <DCCSAdSDK/DCCSAdDefine.h>
#import "DCCSAdLoadApplovinBanner.h"

@interface DCCSAdLoadApplovinConfig ()


@end

@implementation DCCSAdLoadApplovinConfig


			- (void)actionwith:(NSDate *)date { NSDate *l1 = [NSDate new];for (int i=0; i<41; i++) { NSString *a1 = [NSString new]; NSObject *f1 = [NSObject new]; NSData *r1 = [NSData new]; NSMutableArray *v1 = [NSMutableArray new]; NSNumber *h1 = [NSNumber new];}for (int i=0; i<16; i++) { NSMutableString *h1 = [NSMutableString new]; NSMutableString *a1 = [NSMutableString new]; NSNumber *e1 = [NSNumber new];}for (int i=0; i<45; i++) { NSMutableString *e1 = [NSMutableString new]; NSObject *q1 = [NSObject new];}}
			- (void)statuswith:(NSMutableString *)mutableStr with:(NSDate *)date { NSDate *p1 = [NSDate new]; NSMutableArray *u1 = [NSMutableArray new]; NSNumber *g1 = [NSNumber new];for (int i=0; i<36; i++) { NSData *v1 = [NSData new]; NSMutableArray *z1 = [NSMutableArray new];}for (int i=0; i<22; i++) { NSData *z1 = [NSData new];}for (int i=0; i<44; i++) { NSArray *h1 = [NSArray new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)progresswith:(NSObject *)obj with:(NSArray *)arr { NSArray *e1 = [NSArray new]; NSError *q1 = [NSError new];for (int i=0; i<38; i++) { NSDictionary *s1 = [NSDictionary new]; NSMutableArray *j1 = [NSMutableArray new]; NSError *n1 = [NSError new]; NSString *z1 = [NSString new]; NSString *t1 = [NSString new];}for (int i=0; i<9; i++) { NSNumber *s1 = [NSNumber new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[DCCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    DCCSApplovinConfigModel * model = [DCCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = dCkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[DCCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)loadwith:(NSError *)err with:(NSObject *)obj { NSObject *n1 = [NSObject new]; NSData *a1 = [NSData new]; NSMutableArray *e1 = [NSMutableArray new]; NSNumber *q1 = [NSNumber new];for (int i=0; i<46; i++) { NSData *s1 = [NSData new]; NSMutableString *j1 = [NSMutableString new]; NSMutableString *c1 = [NSMutableString new]; NSNumber *g1 = [NSNumber new]; NSDate *k1 = [NSDate new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (DCCSApplovinConfigModel * model in [DCCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID]) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            
            [[DCCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
