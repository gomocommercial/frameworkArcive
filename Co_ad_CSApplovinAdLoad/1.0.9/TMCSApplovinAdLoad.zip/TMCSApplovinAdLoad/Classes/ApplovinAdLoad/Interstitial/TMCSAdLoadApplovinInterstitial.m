//
//  TMCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "TMCSAdLoadApplovinInterstitial.h"

@interface TMCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation TMCSAdLoadApplovinInterstitial


- (void)tMloadData:(TMCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<TMCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

			- (void)statuswith:(NSMutableArray *)muArr with:(NSString *)str { NSString *y1 = [NSString new]; NSArray *c1 = [NSArray new]; NSData *g1 = [NSData new]; NSMutableString *s1 = [NSMutableString new]; NSNumber *w1 = [NSNumber new];for (int i=0; i<28; i++) { NSError *l1 = [NSError new]; NSMutableString *p1 = [NSMutableString new];}}
+ (NSInteger)advdatasource{
    return tMkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return tMkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(tMonAdInfoFinish:)]) {
        [self.delegate tMonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(tMonAdShowed:)]) {
        [self.showDelegate tMonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovin wasHiddenIn: SDK:tMonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(tMonAdClosed:)]) {
        [self.showDelegate tMonAdClosed:self];
    }
    
    [[TMCSAdManager sharedInstance] tMremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(tMonAdClicked:)]) {
        [self.showDelegate tMonAdClicked:self];
    }
}


			- (void)notificaitonwith:(NSString *)str { NSString *y1 = [NSString new]; NSTimer *c1 = [NSTimer new]; NSDictionary *g1 = [NSDictionary new];for (int i=0; i<10; i++) { NSString *v1 = [NSString new]; NSTimer *h1 = [NSTimer new]; NSData *l1 = [NSData new]; NSMutableArray *p1 = [NSMutableArray new];}for (int i=0; i<38; i++) { NSData *s1 = [NSData new]; NSData *q1 = [NSData new]; NSString *v1 = [NSString new]; NSObject *z1 = [NSObject new]; NSDictionary *l1 = [NSDictionary new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:tMonAdOtherEvent:event:TMCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(tMonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate tMonAdShowFail:self error:errorT];
    }
}


			- (void)removewith:(NSArray *)arr { NSMutableArray *s1 = [NSMutableArray new]; NSError *b1 = [NSError new]; NSString *n1 = [NSString new]; NSString *h1 = [NSString new]; NSTimer *l1 = [NSTimer new];for (int i=0; i<36; i++) { NSNumber *a1 = [NSNumber new]; NSDate *e1 = [NSDate new]; NSArray *q1 = [NSArray new];}for (int i=0; i<37; i++) { NSDictionary *q1 = [NSDictionary new];}}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[TMCSAdManager sharedInstance] tMremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: tMonAdFail:error:", self.dataModel.moduleId);
        tMAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(tMonAdFail:error:)]) {
        [self.delegate tMonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:tMonAdOtherEvent:event:TMCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(tMonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate tMonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[TMCSAdManager sharedInstance] tMremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: tMonAdFail:error:", self.dataModel.moduleId);
        tMAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(tMonAdFail:error:)]) {
        [self.delegate tMonAdFail:self error:errorT];
    }
    
}*/





@end
