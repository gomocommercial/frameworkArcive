//
//  TMCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <TMCSAdSDK/TMCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TMCSAdSDK/TMCSAdLoadProtocol.h>
#import <TMCSAdSDK/TMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TMCSAdLoadApplovinBanner : TMCSAdLoadBanner <TMCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
