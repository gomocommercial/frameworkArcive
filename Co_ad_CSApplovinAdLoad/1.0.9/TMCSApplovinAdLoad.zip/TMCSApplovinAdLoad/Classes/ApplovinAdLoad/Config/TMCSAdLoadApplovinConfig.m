//
//  TMCSAdLoadApplovinConfig.m
//  TMCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "TMCSAdLoadApplovinConfig.h"
#import "TMCSApplovinConfigModel.h"
#import <TMCSAdSDK/TMCSAdDefine.h>
#import "TMCSAdLoadApplovinBanner.h"

@interface TMCSAdLoadApplovinConfig ()


@end

@implementation TMCSAdLoadApplovinConfig


			- (void)cancelwith:(NSMutableString *)mutableStr with:(NSDate *)date { NSDictionary *g1 = [NSDictionary new]; NSMutableArray *s1 = [NSMutableArray new]; NSNumber *w1 = [NSNumber new];for (int i=0; i<14; i++) { NSString *t1 = [NSString new]; NSTimer *f1 = [NSTimer new]; NSData *j1 = [NSData new];}for (int i=0; i<46; i++) { NSTimer *j1 = [NSTimer new]; NSTimer *c1 = [NSTimer new]; NSData *p1 = [NSData new]; NSString *t1 = [NSString new]; NSString *m1 = [NSString new];}for (int i=0; i<15; i++) { NSError *m1 = [NSError new]; NSString *y1 = [NSString new]; NSTimer *c1 = [NSTimer new]; NSTimer *v1 = [NSTimer new];}}
+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[TMCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)resumewith:(NSNumber *)num { NSNumber *v1 = [NSNumber new]; NSDate *h1 = [NSDate new]; NSTimer *l1 = [NSTimer new]; NSData *y1 = [NSData new];for (int i=0; i<37; i++) { NSDate *e1 = [NSDate new];}for (int i=0; i<9; i++) { NSObject *m1 = [NSObject new];}for (int i=0; i<49; i++) { NSMutableString *m1 = [NSMutableString new]; NSObject *r1 = [NSObject new]; NSData *d1 = [NSData new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    TMCSApplovinConfigModel * model = [TMCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = tMkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[TMCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)notificaitonwith:(NSString *)str with:(NSData *)data { NSData *a1 = [NSData new]; NSMutableString *m1 = [NSMutableString new]; NSNumber *q1 = [NSNumber new];for (int i=0; i<50; i++) { NSData *f1 = [NSData new]; NSMutableString *j1 = [NSMutableString new]; NSObject *v1 = [NSObject new]; NSDate *z1 = [NSDate new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (TMCSApplovinConfigModel * model in [TMCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID]) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            
            [[TMCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
