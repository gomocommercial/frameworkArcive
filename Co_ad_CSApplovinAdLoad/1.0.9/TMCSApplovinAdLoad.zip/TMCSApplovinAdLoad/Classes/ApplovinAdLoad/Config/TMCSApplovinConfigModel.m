//
//  TMCSApplovinConfigModel.m
//  TMCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "TMCSApplovinConfigModel.h"

@implementation TMCSApplovinConfigModel

@end
