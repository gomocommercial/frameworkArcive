//
//  LDCSAdLoadApplovinConfig.m
//  LDCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "LDCSAdLoadApplovinConfig.h"
#import "LDCSApplovinConfigModel.h"
#import <LDCSAdSDK/LDCSAdDefine.h>
#import "LDCSAdLoadApplovinBanner.h"

@interface LDCSAdLoadApplovinConfig ()


@end

@implementation LDCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)resetwith:(NSTimer *)timer with:(NSMutableArray *)muArr { NSMutableArray *s1 = [NSMutableArray new]; NSNumber *k1 = [NSNumber new]; NSDictionary *o1 = [NSDictionary new]; NSDictionary *h1 = [NSDictionary new];for (int i=0; i<35; i++) { NSString *w1 = [NSString new];}for (int i=0; i<24; i++) { NSNumber *w1 = [NSNumber new]; NSString *a1 = [NSString new]; NSTimer *m1 = [NSTimer new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

			- (void)statuswith:(NSObject *)obj with:(NSArray *)arr { NSArray *q1 = [NSArray new]; NSNumber *c1 = [NSNumber new];for (int i=0; i<3; i++) { NSDictionary *r1 = [NSDictionary new]; NSMutableString *v1 = [NSMutableString new]; NSNumber *z1 = [NSNumber new]; NSDate *l1 = [NSDate new]; NSTimer *p1 = [NSTimer new];}for (int i=0; i<46; i++) { NSDate *p1 = [NSDate new]; NSArray *b1 = [NSArray new]; NSData *f1 = [NSData new];}}
+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[LDCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)resumewith:(NSMutableArray *)muArr with:(NSDictionary *)dic { NSDictionary *s1 = [NSDictionary new];for (int i=0; i<43; i++) { NSString *h1 = [NSString new]; NSObject *l1 = [NSObject new]; NSDictionary *p1 = [NSDictionary new]; NSMutableArray *b1 = [NSMutableArray new]; NSError *f1 = [NSError new];}for (int i=0; i<36; i++) { NSMutableArray *n1 = [NSMutableArray new]; NSNumber *r1 = [NSNumber new]; NSString *v1 = [NSString new];}for (int i=0; i<18; i++) { NSNumber *d1 = [NSNumber new]; NSString *i1 = [NSString new]; NSArray *u1 = [NSArray new]; NSError *y1 = [NSError new]; NSMutableString *c1 = [NSMutableString new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    LDCSApplovinConfigModel * model = [LDCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = lDkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[LDCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)actionwith:(NSNumber *)num with:(NSTimer *)timer { NSTimer *j1 = [NSTimer new]; NSData *v1 = [NSData new]; NSMutableArray *z1 = [NSMutableArray new]; NSNumber *m1 = [NSNumber new]; NSDictionary *q1 = [NSDictionary new];for (int i=0; i<17; i++) { NSString *f1 = [NSString new]; NSString *y1 = [NSString new]; NSTimer *c1 = [NSTimer new]; NSDictionary *g1 = [NSDictionary new];}for (int i=0; i<43; i++) { NSTimer *o1 = [NSTimer new]; NSDictionary *s1 = [NSDictionary new]; NSMutableArray *w1 = [NSMutableArray new]; NSNumber *i1 = [NSNumber new]; NSString *n1 = [NSString new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (LDCSApplovinConfigModel * model in [LDCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID]) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            
            [[LDCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
