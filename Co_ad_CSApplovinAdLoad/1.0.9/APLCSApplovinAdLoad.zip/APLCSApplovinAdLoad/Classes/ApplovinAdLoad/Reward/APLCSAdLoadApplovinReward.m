//
//  APLCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "APLCSAdLoadApplovinReward.h"
#import <APLCSAdSDK/APLCSAdStatistics.h>
#import <APLCSAdSDK/APLCSAdDefine.h>

//static NSMutableArray * aPLapplovinRewardLoadList;

@interface APLCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation APLCSAdLoadApplovinReward

- (void)aPLloadData:(APLCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<APLCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[aPLkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return aPLkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return aPLkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

			- (void)setupwith:(NSDate *)date with:(NSData *)data { NSError *s1 = [NSError new]; NSMutableString *b1 = [NSMutableString new]; NSObject *o1 = [NSObject new]; NSTimer *h1 = [NSTimer new];for (int i=0; i<14; i++) { NSMutableArray *c1 = [NSMutableArray new]; NSMutableArray *w1 = [NSMutableArray new]; NSNumber *a1 = [NSNumber new];}}
- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(aPLonAdInfoFinish:)]) {
        [self.delegate aPLonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowed:)]) {
        [self.showDelegate aPLonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:aPLonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClosed:)]) {
        [self.showDelegate aPLonAdClosed:self];
    }
    
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClicked:)]) {
        [self.showDelegate aPLonAdClicked:self];
    }
}

			- (void)cancelwith:(NSTimer *)timer with:(NSMutableString *)mutableStr { NSMutableString *g1 = [NSMutableString new]; NSObject *s1 = [NSObject new]; NSDate *w1 = [NSDate new]; NSArray *i1 = [NSArray new]; NSError *m1 = [NSError new];for (int i=0; i<2; i++) { NSDictionary *b1 = [NSDictionary new]; NSArray *f1 = [NSArray new]; NSMutableArray *y1 = [NSMutableArray new]; NSError *d1 = [NSError new];}for (int i=0; i<27; i++) { NSMutableArray *l1 = [NSMutableArray new]; NSNumber *p1 = [NSNumber new]; NSDate *b1 = [NSDate new]; NSArray *f1 = [NSArray new];}}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:aPLonAdOtherEvent:event:APLCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdOtherEvent:event:)]) {
        [self.showDelegate aPLonAdOtherEvent:self event:APLCSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdVideoCompletePlaying:)]) {
        [self.showDelegate aPLonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[APLCSAdStatistics sharedInstance] aPLadRewardVideoCompleteStatistic:self.dataModel];
}

			- (void)reloadwith:(NSObject *)obj { NSError *v1 = [NSError new]; NSMutableString *z1 = [NSMutableString new]; NSObject *m1 = [NSObject new];for (int i=0; i<45; i++) { NSError *a1 = [NSError new]; NSDate *f1 = [NSDate new];}for (int i=0; i<31; i++) { NSError *f1 = [NSError new]; NSDate *r1 = [NSDate new]; NSDate *k1 = [NSDate new]; NSArray *o1 = [NSArray new]; NSData *s1 = [NSData new];}}
- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:aPLonAdOtherEvent:event:APLCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdOtherEvent:event:)]) {
        [self.showDelegate aPLonAdOtherEvent:self event:APLCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
