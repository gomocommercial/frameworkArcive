//
//  APLCSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "APLCSAdLoadApplovinInterstitial.h"

@interface APLCSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation APLCSAdLoadApplovinInterstitial


			- (void)removewith:(NSDictionary *)dic with:(NSError *)err { NSNumber *i1 = [NSNumber new];for (int i=0; i<8; i++) { NSData *s1 = [NSData new]; NSMutableArray *b1 = [NSMutableArray new]; NSNumber *n1 = [NSNumber new]; NSDate *r1 = [NSDate new]; NSTimer *w1 = [NSTimer new];}for (int i=0; i<50; i++) { NSDate *e1 = [NSDate new]; NSDictionary *s1 = [NSDictionary new];}}
- (void)aPLloadData:(APLCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
}

			- (void)addwith:(NSMutableString *)mutableStr with:(NSDictionary *)dic { NSDictionary *u1 = [NSDictionary new]; NSMutableArray *g1 = [NSMutableArray new];for (int i=0; i<38; i++) { NSTimer *n1 = [NSTimer new]; NSData *z1 = [NSData new];}for (int i=0; i<24; i++) { NSArray *z1 = [NSArray new]; NSData *d1 = [NSData new]; NSMutableString *p1 = [NSMutableString new];}}
- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<APLCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


			- (void)notificaitonwith:(NSArray *)arr { NSArray *p1 = [NSArray new]; NSError *b1 = [NSError new]; NSMutableString *g1 = [NSMutableString new]; NSTimer *s1 = [NSTimer new]; NSDictionary *w1 = [NSDictionary new];for (int i=0; i<50; i++) { NSDate *l1 = [NSDate new];}}
- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return aPLkAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return aPLkOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdInfoFinish:)]) {
        [self.delegate aPLonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowed:)]) {
        [self.showDelegate aPLonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasHiddenIn: SDK:aPLonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClosed:)]) {
        [self.showDelegate aPLonAdClosed:self];
    }
    
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClicked:)]) {
        [self.showDelegate aPLonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
    
}*/





@end
