//
//  APLCSAdLoadApplovinBanner.m
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import "APLCSAdLoadApplovinBanner.h"
#import "APLCSAdLoadApplovinConfig.h"

@interface APLCSAdLoadApplovinBanner ()

@property (nonatomic, assign) BOOL isShowed;

@end

@implementation APLCSAdLoadApplovinBanner

- (void)closeAd {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] admob banner close SDK:aPLonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClosed:)]) {
        [self.showDelegate aPLonAdClosed:self];
    }
    
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

- (NSString *)adClassName {
    return @"ApplovinBanner";;
}

			- (void)cancelwith:(NSNumber *)num with:(NSTimer *)timer { NSTimer *o1 = [NSTimer new]; NSData *s1 = [NSData new];for (int i=0; i<35; i++) { NSDate *h1 = [NSDate new]; NSArray *l1 = [NSArray new];}for (int i=0; i<22; i++) { NSDictionary *t1 = [NSDictionary new]; NSDictionary *e1 = [NSDictionary new]; NSMutableArray *q1 = [NSMutableArray new];}for (int i=0; i<1; i++) { NSDictionary *q1 = [NSDictionary new]; NSMutableArray *c1 = [NSMutableArray new]; NSNumber *g1 = [NSNumber new]; NSString *k1 = [NSString new]; NSTimer *w1 = [NSTimer new];}}
+ (NSInteger)advdatasource {
    return aPLkAdvDataSourceApplovin;
}

			- (void)loadwith:(NSObject *)obj { NSObject *l1 = [NSObject new]; NSDictionary *p1 = [NSDictionary new];for (int i=0; i<45; i++) { NSString *e1 = [NSString new]; NSObject *i1 = [NSObject new];}}
- (void)aPLloadData:(APLCSAdLoadCompleteBlock)csAdLoadCompleteBlock {
    
    NSMutableArray<APLCSApplovinConfigModel *> * configs = [APLCSAdLoadApplovinConfig sharedInstance].configs;
    
    UIViewController * rootCtrl = nil;
    CGPoint bannerPosition = CGPointMake(0, 0);
    UIColor *backgroundColor = [UIColor clearColor];
    for (APLCSApplovinConfigModel * config in configs) {
        if (config.onlineadvtype == [APLCSAdLoadApplovinBanner onlineadvtype]
            && [config.moudleID isEqualToString:self.dataModel.belongsMoudeId]) {
            rootCtrl = config.rootViewController;
            bannerPosition = config.bannerPosition;
            backgroundColor = config.backgroundColor;
            break;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
        
        self.adView = [[MAAdView alloc] initWithAdUnitIdentifier:self.dataModel.fbId];
        self.adView.hidden = YES;
        self.adView.delegate = self;
        // Banner height on iPhone and iPad is 50 and 90, respectively
        CGFloat height = (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 90 : 50;
        if ([[APLCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs containsObject:[NSString stringWithFormat:@"%d",self.dataModel.moduleId]]) {
            height = MAAdFormat.banner.adaptiveSize.height;
            [self.adView setExtraParameterForKey: @"adaptive_banner" value: @"true"];
        }

        if ([self needLog]) {
            aPLAdLog(@"广告高度height=%f",height);
        }
        
        // Stretch to the width of the screen for banners to be fully functional
        CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);

        self.adView.frame = CGRectMake(bannerPosition.x, bannerPosition.y, width, height);

        // Set background or background color for banners to be fully functional
        self.adView.backgroundColor = backgroundColor;

        [rootCtrl.view addSubview:self.adView];

        // Load the ad
        [self.adView loadAd];
        
    });
    
}

- (BOOL)isValid {
    if (self.adView) {
        return true;
    }
    return false;
}

+ (NSInteger)onlineadvtype {
    return aPLkOnlineAdvTypeBanner;
}

- (void)show:(id)traget delegate:(id<APLCSAdLoadShowProtocol>)delegate {
    
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.adView) {
            self.adView.delegate = self;
            self.adView.hidden = NO;
            [self.adView startAutoRefresh];
        }
    });
    
}

- (void)didClickAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClicked:)]) {
        [self.showDelegate aPLonAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(nonnull MAAd *)ad withError:(nonnull MAError *)error {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(nonnull NSString *)adUnitIdentifier withError:(nonnull MAError *)error {
    [self failureWithEndTimer];
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToDisplayAd: SDK:aPLonAdOtherEvent:event:APLCSAdWillDisappear", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate aPLonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
    
    if ([self isTimeOut]) {
        return;
    }
    
    NSError *errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: aPLonAdFail:error:", self.dataModel.moduleId);
        aPLAdLog(@"[%ld] applovin banner:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdFail:error:)]) {
        [self.delegate aPLonAdFail:self error:errorT];
    }
    
}*/

			- (void)notificaitonwith:(NSError *)err with:(NSObject *)obj { NSObject *n1 = [NSObject new]; NSDictionary *z1 = [NSDictionary new]; NSArray *e1 = [NSArray new]; NSNumber *i1 = [NSNumber new];for (int i=0; i<15; i++) { NSData *s1 = [NSData new]; NSMutableString *j1 = [NSMutableString new]; NSMutableString *c1 = [NSMutableString new]; NSObject *g1 = [NSObject new];}}
- (void)didLoadAd:(nonnull MAAd *)ad {
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(aPLonAdInfoFinish:)]) {
        [self.delegate aPLonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
}


#pragma mark - Deprecated Callbacks
- (void)didDisplayAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdShowed:)] && self.isShowed == false) {
        self.isShowed = true;
        [self.showDelegate aPLonAdShowed:self];
    }
}


- (void)didHideAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        aPLAdLog(@"[%ld] applovin wasHiddenIn: SDK:aPLonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(aPLonAdClosed:)]) {
        [self.showDelegate aPLonAdClosed:self];
    }
    
    [[APLCSAdManager sharedInstance] aPLremoveData:self];
    
    self.adView.hidden = YES;
    [self.adView stopAutoRefresh];
}

#pragma mark - MAAdViewAdDelegate Protocol
			- (void)statuswith:(NSString *)str with:(NSDictionary *)dic { NSDictionary *s1 = [NSDictionary new]; NSArray *c1 = [NSArray new];for (int i=0; i<25; i++) { NSTimer *q1 = [NSTimer new]; NSData *v1 = [NSData new];}for (int i=0; i<11; i++) { NSTimer *d1 = [NSTimer new]; NSError *h1 = [NSError new]; NSMutableString *l1 = [NSMutableString new];}for (int i=0; i<44; i++) { NSError *t1 = [NSError new];}}
- (void)didCollapseAd:(nonnull MAAd *)ad {
    
}

- (void)didExpandAd:(nonnull MAAd *)ad {
   
}

@end
