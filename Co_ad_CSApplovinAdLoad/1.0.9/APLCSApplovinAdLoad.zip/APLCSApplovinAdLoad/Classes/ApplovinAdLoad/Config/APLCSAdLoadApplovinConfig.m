//
//  APLCSAdLoadApplovinConfig.m
//  APLCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "APLCSAdLoadApplovinConfig.h"
#import "APLCSApplovinConfigModel.h"
#import <APLCSAdSDK/APLCSAdDefine.h>
#import "APLCSAdLoadApplovinBanner.h"

@interface APLCSAdLoadApplovinConfig ()


@end

@implementation APLCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[APLCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

			- (void)notificaitonwith:(NSDate *)date with:(NSError *)err { NSError *i1 = [NSError new]; NSMutableString *m1 = [NSMutableString new];for (int i=0; i<20; i++) { NSMutableArray *b1 = [NSMutableArray new]; NSError *f1 = [NSError new];}for (int i=0; i<6; i++) { NSMutableArray *n1 = [NSMutableArray new]; NSNumber *r1 = [NSNumber new]; NSString *v1 = [NSString new];}for (int i=0; i<38; i++) { NSNumber *d1 = [NSNumber new]; NSString *h1 = [NSString new]; NSTimer *u1 = [NSTimer new]; NSError *y1 = [NSError new]; NSMutableString *c1 = [NSMutableString new];}}
			- (void)addwith:(NSArray *)arr { NSMutableArray *k1 = [NSMutableArray new]; NSError *o1 = [NSError new]; NSString *a1 = [NSString new]; NSObject *e1 = [NSObject new]; NSDictionary *q1 = [NSDictionary new];for (int i=0; i<42; i++) { NSString *s1 = [NSString new];}for (int i=0; i<2; i++) { NSTimer *c1 = [NSTimer new];}for (int i=0; i<21; i++) { NSDate *c1 = [NSDate new]; NSArray *h1 = [NSArray new]; NSError *t1 = [NSError new]; NSMutableString *s1 = [NSMutableString new]; NSObject *j1 = [NSObject new];}}
			- (void)cancelwith:(NSError *)err { NSError *j1 = [NSError new]; NSString *v1 = [NSString new]; NSTimer *z1 = [NSTimer new]; NSDictionary *d1 = [NSDictionary new]; NSMutableString *q1 = [NSMutableString new];for (int i=0; i<7; i++) { NSTimer *e1 = [NSTimer new]; NSNumber *l1 = [NSNumber new]; NSDate *y1 = [NSDate new]; NSArray *c1 = [NSArray new];}}
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    APLCSApplovinConfigModel * model = [APLCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = aPLkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[APLCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (APLCSApplovinConfigModel * model in [APLCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID]) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            
            [[APLCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
