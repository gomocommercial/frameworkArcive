//
//  APLCSApplovinConfigModel.m
//  APLCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "APLCSApplovinConfigModel.h"

@implementation APLCSApplovinConfigModel

@end
