//
//  SLCSAdLoadApplovinTemplatesNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <SLCSAdSDK/SLCSAdLoadNative.h>
#import <SLCSAdSDK/SLCSAdLoadProtocol.h>
#import <SLCSAdSDK/SLCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SLCSAdLoadApplovinTemplatesNative : SLCSAdLoadNative<SLCSAdLoadProtocol,MANativeAdDelegate>

@property (nonatomic, strong) MAAd * ad;
@property (nonatomic, strong) UIView *nativeAdView;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
