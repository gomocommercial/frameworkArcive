//
//  PPCSAdLoadApplovinTemplatesNative.h
//  AdDemo
//
//  Created by zhangxin on 2024/4/3.
//  Copyright © 2024 zhangxin. All rights reserved.
//
#import <AppLovinSDK/AppLovinSDK.h>
#import <PPCSAdSDK/PPCSAdLoadNative.h>
#import <PPCSAdSDK/PPCSAdLoadProtocol.h>
#import <PPCSAdSDK/PPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPCSAdLoadApplovinTemplatesNative : PPCSAdLoadNative<PPCSAdLoadProtocol,MANativeAdDelegate>

@property (nonatomic, strong) MAAd * ad;
@property (nonatomic, strong) UIView *nativeAdView;


/// 关闭广告
- (void)closeAd;
@end

NS_ASSUME_NONNULL_END
