//
//  PPCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PPCSAdSDK/PPCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PPCSAdSDK/PPCSAdLoadProtocol.h>
#import <PPCSAdSDK/PPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PPCSAdLoadApplovinOpen : PPCSAdLoadOpen <PPCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
