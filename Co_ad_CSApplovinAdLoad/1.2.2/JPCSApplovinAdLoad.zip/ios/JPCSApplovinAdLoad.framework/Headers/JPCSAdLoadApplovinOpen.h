//
//  JPCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <JPCSAdSDK/JPCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdLoadApplovinOpen : JPCSAdLoadOpen <JPCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
