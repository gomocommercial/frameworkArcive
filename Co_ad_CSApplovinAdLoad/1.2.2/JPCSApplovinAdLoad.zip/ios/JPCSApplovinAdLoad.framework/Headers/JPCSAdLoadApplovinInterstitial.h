//
//  JPCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <JPCSAdSDK/JPCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdLoadApplovinInterstitial : JPCSAdLoadInterstitial<JPCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
