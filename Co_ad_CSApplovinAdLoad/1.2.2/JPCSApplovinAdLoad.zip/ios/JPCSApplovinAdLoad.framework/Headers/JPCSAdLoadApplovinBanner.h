//
//  JPCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <JPCSAdSDK/JPCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdLoadApplovinBanner : JPCSAdLoadBanner <JPCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
