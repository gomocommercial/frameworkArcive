//
//  JPCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <JPCSAdSDK/JPCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <JPCSAdSDK/JPCSAdLoadProtocol.h>
#import <JPCSAdSDK/JPCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface JPCSAdLoadApplovinReward : JPCSAdLoadReward<JPCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
