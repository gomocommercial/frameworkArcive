//
//  SMCSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <SMCSAdSDK/SMCSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SMCSAdSDK/SMCSAdLoadProtocol.h>
#import <SMCSAdSDK/SMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface SMCSAdLoadApplovinBanner : SMCSAdLoadBanner <SMCSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

@end

NS_ASSUME_NONNULL_END
