//
//  SMCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <SMCSAdSDK/SMCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <SMCSAdSDK/SMCSAdLoadProtocol.h>
#import <SMCSAdSDK/SMCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface SMCSAdLoadApplovinReward : SMCSAdLoadReward<SMCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
