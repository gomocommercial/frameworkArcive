//
//  PSCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PSCSAdSDK/PSCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PSCSAdSDK/PSCSAdLoadProtocol.h>
#import <PSCSAdSDK/PSCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSCSAdLoadApplovinInterstitial : PSCSAdLoadInterstitial<PSCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
