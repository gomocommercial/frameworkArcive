//
//  PSCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PSCSAdSDK/PSCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PSCSAdSDK/PSCSAdLoadProtocol.h>
#import <PSCSAdSDK/PSCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PSCSAdLoadApplovinOpen : PSCSAdLoadOpen <PSCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
