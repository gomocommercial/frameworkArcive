//
//  CSApplovinConfigModel.h
//  CSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class CSAdLoadApplovinBanner;
@class  MANativeAdView;

@interface CSApplovinConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;

//Banner
@property (nonatomic, assign) CGPoint bannerPosition;
@property (nonatomic, weak) UIViewController *rootViewController;
@property (nonatomic, copy) UIColor *backgroundColor;
//Banner
@property (nonatomic, weak) CSAdLoadApplovinBanner *banner;

//native,请参考native(Manual）文档，创建MANativeAdView并绑定adViewBinder
@property (nonatomic, weak) MANativeAdView *nativeAdView;
//native,请参考native(Ad Placer)文档，传自定义的tableView或collectionView
@property (nonatomic, weak) UITableView *maTableView;
@property (nonatomic, weak) UICollectionView *maCollectionView;
//native Ad Positions,请参考native(Ad Placer)文档
@property (nonatomic, weak) NSArray<NSIndexPath *> *maNativPositions;
//native To change the repeating interval, This value must be greater than or equal to 2; 请参考native(Ad Placer)文档
@property (nonatomic, assign) NSInteger repeatingInterval;
//native remove existing fixed positions 请参考native(Ad Placer)文档
@property (nonatomic, assign) BOOL isRmExitFixdPos;
//native 请参考native(Ad Placer)文档
@property (nonatomic, assign) CGSize palcerAdSize;

@property (nonatomic, assign) BOOL isLoadedBanner;

@end

NS_ASSUME_NONNULL_END
