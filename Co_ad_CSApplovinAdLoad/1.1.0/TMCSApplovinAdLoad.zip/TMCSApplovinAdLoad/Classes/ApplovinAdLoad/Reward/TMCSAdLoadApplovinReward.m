//
//  TMCSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "TMCSAdLoadApplovinReward.h"
#import <TMCSAdSDK/TMCSAdStatistics.h>
#import <TMCSAdSDK/TMCSAdDefine.h>

//static NSMutableArray * tMapplovinRewardLoadList;

@interface TMCSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation TMCSAdLoadApplovinReward

- (void)tMloadData:(TMCSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

- (void)show:(id)target delegate:(id<TMCSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[tMkCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

			- (void)reloadwith:(NSArray *)arr { NSArray *r1 = [NSArray new];for (int i=0; i<31; i++) { NSObject *g1 = [NSObject new]; NSDictionary *s1 = [NSDictionary new]; NSDictionary *d1 = [NSDictionary new]; NSMutableString *q1 = [NSMutableString new]; NSNumber *u1 = [NSNumber new];}}
			- (void)paywith:(NSError *)err { NSError *c1 = [NSError new]; NSMutableString *g1 = [NSMutableString new];for (int i=0; i<8; i++) { NSArray *v1 = [NSArray new]; NSError *z1 = [NSError new];}for (int i=0; i<26; i++) { NSMutableArray *h1 = [NSMutableArray new]; NSError *l1 = [NSError new]; NSString *s1 = [NSString new];}}
- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return tMkAdvDataSourceApplovin;
}

			- (void)loadwith:(NSMutableArray *)muArr { NSMutableArray *d1 = [NSMutableArray new]; NSNumber *h1 = [NSNumber new]; NSDate *u1 = [NSDate new]; NSArray *y1 = [NSArray new]; NSError *k1 = [NSError new];for (int i=0; i<28; i++) { NSDictionary *r1 = [NSDictionary new]; NSTimer *z1 = [NSTimer new]; NSTimer *s1 = [NSTimer new]; NSDictionary *w1 = [NSDictionary new]; NSMutableArray *a1 = [NSMutableArray new];}for (int i=0; i<25; i++) { NSData *i1 = [NSData new]; NSMutableArray *m1 = [NSMutableArray new];}for (int i=0; i<11; i++) { NSArray *b1 = [NSArray new]; NSData *f1 = [NSData new]; NSMutableString *r1 = [NSMutableString new];}}
+ (NSInteger)onlineadvtype{
    return tMkOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(tMonAdInfoFinish:)]) {
        [self.delegate tMonAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    double ecpm = ad.revenue > 0 ? ad.revenue : 0;
    self.preEcpm = @(ecpm).stringValue;
    self.nextAdId = ad.creativeIdentifier;
    if ([self.showDelegate respondsToSelector:@selector(tMonAdShowed:)]) {
        [self.showDelegate tMonAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward wasHiddenIn: SDK:tMonAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(tMonAdClosed:)]) {
        [self.showDelegate tMonAdClosed:self];
    }
    
    [[TMCSAdManager sharedInstance] tMremoveData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(tMonAdClicked:)]) {
        [self.showDelegate tMonAdClicked:self];
    }
}

- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:tMonAdOtherEvent:event:TMCSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(tMonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate tMonAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:tMonAdFail:error:", self.dataModel.moduleId);
        tMAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(tMonAdFail:error:)]) {
        [self.delegate tMonAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:tMonAdOtherEvent:event:TMCSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(tMonAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate tMonAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:tMonAdFail:error:", self.dataModel.moduleId);
        tMAdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(tMonAdFail:error:)]) {
        [self.delegate tMonAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:tMonAdOtherEvent:event:TMCSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(tMonAdOtherEvent:event:)]) {
        [self.showDelegate tMonAdOtherEvent:self event:TMCSAdVideoComplete];
    }

}

			- (void)removewith:(NSMutableArray *)muArr { NSMutableArray *s1 = [NSMutableArray new]; NSNumber *j1 = [NSNumber new];for (int i=0; i<13; i++) { NSData *q1 = [NSData new]; NSMutableString *c1 = [NSMutableString new];}}
- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(tMonAdVideoCompletePlaying:)]) {
        [self.showDelegate tMonAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[TMCSAdStatistics sharedInstance] tMadRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        tMAdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:tMonAdOtherEvent:event:TMCSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(tMonAdOtherEvent:event:)]) {
        [self.showDelegate tMonAdOtherEvent:self event:TMCSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
