//
//  TMCSAdLoadApplovinConfig.m
//  TMCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "TMCSAdLoadApplovinConfig.h"
#import "TMCSApplovinConfigModel.h"
#import <TMCSAdSDK/TMCSAdDefine.h>
#import "TMCSAdLoadApplovinBanner.h"

@interface TMCSAdLoadApplovinConfig ()


@end

@implementation TMCSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)paywith:(NSMutableString *)mutableStr with:(NSDate *)date { NSDictionary *l1 = [NSDictionary new]; NSArray *q1 = [NSArray new]; NSNumber *c1 = [NSNumber new]; NSString *g1 = [NSString new];for (int i=0; i<26; i++) { NSMutableString *v1 = [NSMutableString new]; NSNumber *z1 = [NSNumber new]; NSNumber *s1 = [NSNumber new]; NSDate *e1 = [NSDate new]; NSArray *i1 = [NSArray new];}for (int i=0; i<47; i++) { NSDate *i1 = [NSDate new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

			- (void)loadwith:(NSMutableString *)mutableStr with:(NSDate *)date { NSDictionary *n1 = [NSDictionary new]; NSArray *s1 = [NSArray new]; NSNumber *e1 = [NSNumber new]; NSString *i1 = [NSString new]; NSTimer *u1 = [NSTimer new];for (int i=0; i<48; i++) { NSData *r1 = [NSData new]; NSMutableArray *v1 = [NSMutableArray new];}for (int i=0; i<4; i++) { NSData *d1 = [NSData new];}}
			- (void)progresswith:(NSTimer *)timer { NSTimer *t1 = [NSTimer new]; NSData *s1 = [NSData new]; NSMutableString *j1 = [NSMutableString new];for (int i=0; i<45; i++) { NSArray *y1 = [NSArray new]; NSData *d1 = [NSData new];}for (int i=0; i<31; i++) { NSArray *d1 = [NSArray new]; NSNumber *p1 = [NSNumber new]; NSNumber *i1 = [NSNumber new]; NSString *m1 = [NSString new]; NSTimer *q1 = [NSTimer new];}for (int i=0; i<3; i++) { NSDate *y1 = [NSDate new]; NSTimer *c1 = [NSTimer new]; NSData *o1 = [NSData new]; NSData *z1 = [NSData new]; NSMutableString *l1 = [NSMutableString new];}}
+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[TMCSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    TMCSApplovinConfigModel * model = [TMCSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = tMkOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[TMCSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

			- (void)resetwith:(NSData *)data with:(NSObject *)obj { NSObject *y1 = [NSObject new]; NSDictionary *c1 = [NSDictionary new]; NSMutableArray *o1 = [NSMutableArray new]; NSError *s1 = [NSError new]; NSString *e1 = [NSString new];for (int i=0; i<22; i++) { NSMutableArray *l1 = [NSMutableArray new];}}
+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (TMCSApplovinConfigModel * model in [TMCSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID]) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            
            [[TMCSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
