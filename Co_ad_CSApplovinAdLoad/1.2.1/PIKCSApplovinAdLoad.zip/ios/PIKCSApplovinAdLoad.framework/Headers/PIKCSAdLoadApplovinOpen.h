//
//  PIKCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <PIKCSAdSDK/PIKCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PIKCSAdSDK/PIKCSAdLoadProtocol.h>
#import <PIKCSAdSDK/PIKCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface PIKCSAdLoadApplovinOpen : PIKCSAdLoadOpen <PIKCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
