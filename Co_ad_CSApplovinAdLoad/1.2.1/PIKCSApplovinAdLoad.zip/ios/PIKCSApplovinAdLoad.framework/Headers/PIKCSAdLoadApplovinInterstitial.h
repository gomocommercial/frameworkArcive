//
//  PIKCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <PIKCSAdSDK/PIKCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <PIKCSAdSDK/PIKCSAdLoadProtocol.h>
#import <PIKCSAdSDK/PIKCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface PIKCSAdLoadApplovinInterstitial : PIKCSAdLoadInterstitial<PIKCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
