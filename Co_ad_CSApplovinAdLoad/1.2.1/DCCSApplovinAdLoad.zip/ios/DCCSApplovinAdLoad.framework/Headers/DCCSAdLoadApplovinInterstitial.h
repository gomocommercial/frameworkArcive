//
//  DCCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <DCCSAdSDK/DCCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadApplovinInterstitial : DCCSAdLoadInterstitial<DCCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
