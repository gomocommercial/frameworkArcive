//
//  DCCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <DCCSAdSDK/DCCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <DCCSAdSDK/DCCSAdLoadProtocol.h>
#import <DCCSAdSDK/DCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface DCCSAdLoadApplovinOpen : DCCSAdLoadOpen <DCCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
