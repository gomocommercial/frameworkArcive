//
//  APLCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <APLCSAdSDK/APLCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <APLCSAdSDK/APLCSAdLoadProtocol.h>
#import <APLCSAdSDK/APLCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface APLCSAdLoadApplovinOpen : APLCSAdLoadOpen <APLCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
