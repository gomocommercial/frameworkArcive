//
//  APLCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <APLCSAdSDK/APLCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <APLCSAdSDK/APLCSAdLoadProtocol.h>
#import <APLCSAdSDK/APLCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface APLCSAdLoadApplovinInterstitial : APLCSAdLoadInterstitial<APLCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
