//
//  LDCSApplovinConfigModel.m
//  LDCSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "LDCSApplovinConfigModel.h"

@implementation LDCSApplovinConfigModel

@end
