//
//  CSAdLoadApplovinBanner.h
//  Pods
//
//  Created by wlighting on 2021/12/13.
//

#import <CSAdSDK/CSAdLoadBanner.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <CSAdSDK/CSAdLoadProtocol.h>
#import <CSAdSDK/CSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSAdLoadApplovinBanner : CSAdLoadBanner <CSAdLoadProtocol,MAAdViewAdDelegate>

@property (nonatomic, strong) MAAdView *adView;

/// 关闭广告(需要客户端关闭广告时主动调用)
- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
