//
//  CSAdLoadApplovinConfig.m
//  CSApplovinAdLoad
//
//  Created by wlighting on 2021/12/13.
//

#import "CSAdLoadApplovinConfig.h"
#import "CSApplovinConfigModel.h"
#import <CSAdSDK/CSAdDefine.h>
#import "CSAdLoadApplovinBanner.h"

@interface CSAdLoadApplovinConfig ()


@end

@implementation CSAdLoadApplovinConfig


+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

			- (void)loadwith:(NSNumber *)num with:(NSTimer *)timer { NSArray *b1 = [NSArray new]; NSData *f1 = [NSData new]; NSMutableString *s1 = [NSMutableString new]; NSObject *w1 = [NSObject new];for (int i=0; i<45; i++) { NSNumber *l1 = [NSNumber new]; NSString *p1 = [NSString new]; NSString *i1 = [NSString new]; NSTimer *u1 = [NSTimer new];}for (int i=0; i<21; i++) { NSDate *u1 = [NSDate new]; NSTimer *y1 = [NSTimer new]; NSData *k1 = [NSData new]; NSMutableArray *o1 = [NSMutableArray new]; NSMutableArray *h1 = [NSMutableArray new];}for (int i=0; i<42; i++) { NSData *h1 = [NSData new];}}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.configs = [NSMutableArray array];
        self.adaptiveModudleIDs = [NSMutableArray array];
    }
    return self;
}

			- (void)notificaitonwith:(NSDate *)date { NSDictionary *p1 = [NSDictionary new]; NSArray *u1 = [NSArray new]; NSNumber *g1 = [NSNumber new];for (int i=0; i<15; i++) { NSData *v1 = [NSData new]; NSMutableString *z1 = [NSMutableString new];}for (int i=0; i<2; i++) { NSData *z1 = [NSData new]; NSMutableString *l1 = [NSMutableString new]; NSMutableString *e1 = [NSMutableString new]; NSObject *i1 = [NSObject new]; NSDate *m1 = [NSDate new];}}
+ (void)setBannerConfigWithAdaptiveMoudleIDs:(NSArray <NSString *>*)adaptiveModudleIDs {

    [[CSAdLoadApplovinConfig sharedInstance].adaptiveModudleIDs addObjectsFromArray:adaptiveModudleIDs];
}

+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID bannerAdPosition:(CGPoint)bannerPosition adBackgroundColor:(UIColor *)backgroundColor  rootViewController:(UIViewController *)rootViewController {
    
    NSAssert(modudleID.length > 0, @"modudleID 为空");
    NSAssert(rootViewController, @"rootViewController 为 nil");

    CSApplovinConfigModel * model = [CSApplovinConfigModel new];
    model.moudleID = modudleID;
    model.onlineadvtype = kOnlineAdvTypeBanner;
    model.bannerPosition = bannerPosition;
    model.backgroundColor = backgroundColor;
    model.rootViewController = rootViewController;
    [[CSAdLoadApplovinConfig sharedInstance].configs addObject:model];
    
}

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID{
    for (CSApplovinConfigModel * model in [CSAdLoadApplovinConfig sharedInstance].configs) {
        if ([model.moudleID isEqualToString:moduleID]) {
            model.banner.adView.hidden = YES;
            [model.banner.adView stopAutoRefresh];
            
            [[CSAdLoadApplovinConfig sharedInstance].configs removeObject:model];
            return;
        }
    }
}

@end
