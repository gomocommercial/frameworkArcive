//
//  CSAdLoadApplovinInterstitial.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "CSAdLoadApplovinInterstitial.h"

@interface CSAdLoadApplovinInterstitial ()<MAAdDelegate>

@end

@implementation CSAdLoadApplovinInterstitial


- (void)loadData:(CSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    self.ad = [[MAInterstitialAd alloc] initWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];

    [self startTimer];
}

- (BOOL)isValid{
    return self.ad.ready;
}

- (void)show:(id)target delegate:(id<CSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    [self.ad showAd];
}


			- (void)progresswith:(NSDictionary *)dic with:(NSNumber *)num { NSNumber *m1 = [NSNumber new];for (int i=0; i<43; i++) { NSData *b1 = [NSData new]; NSMutableString *f1 = [NSMutableString new]; NSNumber *j1 = [NSNumber new]; NSDate *v1 = [NSDate new]; NSTimer *z1 = [NSTimer new];}for (int i=0; i<36; i++) { NSDate *z1 = [NSDate new]; NSArray *l1 = [NSArray new]; NSData *p1 = [NSData new]; NSString *c1 = [NSString new]; NSObject *g1 = [NSObject new];}}
- (NSString *)adClassName{
    return @"ApplovinInterstitial";
}

+ (NSInteger)advdatasource{
    return kAdvDataSourceApplovin;
}

+ (NSInteger)onlineadvtype{
    return kOnlineAdvTypeInterstitial;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad
{
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }
    if ([self.delegate respondsToSelector:@selector(onAdInfoFinish:)]) {
        [self.delegate onAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
   
}

#pragma mark - Ad Display Delegate



- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowed:)]) {
        [self.showDelegate onAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasHiddenIn: SDK:onAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdClosed:)]) {
        [self.showDelegate onAdClosed:self];
    }
    
    [[CSAdManager sharedInstance] removeData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovin wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdClicked:)]) {
        [self.showDelegate onAdClicked:self];
    }
}


- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}


- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    [self failureWithEndTimer];
    [[CSAdManager sharedInstance] removeData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, error);
    }
    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    [self failureWithEndTimer];
    [[CSAdManager sharedInstance] removeData:self];
    if ([self isTimeOut]) {
        return;
    }
    
    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    
    if ([self needLog]) {
        AdLog(@"[%ld] applovin didFailToLoadAdForAdUnitIdentifier: SDK: onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin 全屏:error:%@", self.dataModel.moduleId, errorT);
    }
    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
    
}*/





@end
