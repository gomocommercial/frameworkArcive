//
//  CSAdLoadApplovinReward.m
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import "CSAdLoadApplovinReward.h"
#import <CSAdSDK/CSAdStatistics.h>
#import <CSAdSDK/CSAdDefine.h>

//static NSMutableArray * applovinRewardLoadList;

@interface CSAdLoadApplovinReward ()<MARewardedAdDelegate>

@end

@implementation CSAdLoadApplovinReward

- (void)loadData:(CSAdLoadCompleteBlock)csAdLoadCompleteBlock{
    self.csAdLoadCompleteBlock = csAdLoadCompleteBlock;
    
    self.ad = [MARewardedAd sharedWithAdUnitIdentifier: self.dataModel.fbId];
    self.ad.delegate = self;
    
    [self.ad loadAd];
    
    [self startTimer];

}

- (BOOL)isValid{
    
    if (self.ad) {
        return self.ad.ready;
    }
    return false;
}

			- (void)removewith:(NSString *)str { NSDate *y1 = [NSDate new]; NSTimer *c1 = [NSTimer new];for (int i=0; i<8; i++) { NSNumber *r1 = [NSNumber new]; NSDate *d1 = [NSDate new];}}
			- (void)actionwith:(NSArray *)arr { NSArray *t1 = [NSArray new]; NSData *s1 = [NSData new]; NSString *c1 = [NSString new];for (int i=0; i<15; i++) { NSArray *r1 = [NSArray new]; NSNumber *d1 = [NSNumber new]; NSString *h1 = [NSString new]; NSTimer *l1 = [NSTimer new];}}
- (void)show:(id)target delegate:(id<CSAdLoadShowProtocol>)delegate{
    self.showDelegate = delegate;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.ad) {
            self.ad.delegate = self;
            [self.ad showAd];
        }
    });
}

- (void)timeOutNotification:(NSNotification *)notify{
    if (![notify.object isKindOfClass:NSDictionary.class]) {
        return;
    }
    NSObject * failAdload = notify.object[kCSLoadAdTimeOutNotificationKey];
    if (self == failAdload) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        [self failureWithEndTimer];
    }
}

			- (void)resetwith:(NSNumber *)num with:(NSTimer *)timer { NSTimer *y1 = [NSTimer new]; NSData *k1 = [NSData new]; NSMutableArray *o1 = [NSMutableArray new]; NSNumber *a1 = [NSNumber new];for (int i=0; i<12; i++) { NSData *h1 = [NSData new];}for (int i=0; i<34; i++) { NSArray *p1 = [NSArray new];}for (int i=0; i<24; i++) { NSDate *p1 = [NSDate new]; NSArray *t1 = [NSArray new]; NSNumber *g1 = [NSNumber new];}}
- (NSString *)adClassName{
    return @"ApplovinReward";
}

+ (NSInteger)advdatasource{
    return kAdvDataSourceApplovin;
}

			- (void)statuswith:(NSDictionary *)dic { NSDictionary *o1 = [NSDictionary new]; NSMutableString *s1 = [NSMutableString new]; NSNumber *w1 = [NSNumber new]; NSDate *i1 = [NSDate new]; NSTimer *m1 = [NSTimer new];for (int i=0; i<18; i++) { NSObject *b1 = [NSObject new]; NSDate *f1 = [NSDate new];}for (int i=0; i<36; i++) { NSObject *n1 = [NSObject new]; NSDictionary *r1 = [NSDictionary new]; NSArray *v1 = [NSArray new];}}
+ (NSInteger)onlineadvtype{
    return kOnlineAdvTypeVideo;
}

#pragma mark - Ad Load Delegate

- (void)didLoadAd:(MAAd *)ad {
    
    if ([self isTimeOut]) {
        return;
    }
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didLoadAd: sdk: onAdInfoFinish", self.dataModel.moduleId);
    }

    if ([self.delegate respondsToSelector:@selector(onAdInfoFinish:)]) {
        [self.delegate onAdInfoFinish:self];
    }
    [self succeeWithEndTimer];
    
}


#pragma mark - Ad Display Delegate

- (void)didDisplayAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward wasDisplayedIn: SDK:onAdShowed", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowed:)]) {
        [self.showDelegate onAdShowed:self];
    }
}

- (void)didHideAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward wasHiddenIn: SDK:onAdClosed", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdClosed:)]) {
        [self.showDelegate onAdClosed:self];
    }
    
    [[CSAdManager sharedInstance] removeData:self];
}

- (void)didClickAd:(MAAd *)ad
{
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward wasClickedIn: SDK:onAdClicked", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdClicked:)]) {
        [self.showDelegate onAdClicked:self];
    }
}

- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error {
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear,error = %@", self.dataModel.moduleId,error);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error
{
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:error.code userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, error);
    }

    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
        
}
/*
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode {
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didFailToDisplayAd: SDK:onAdOtherEvent:event:CSAdWillDisappear,error = %@", self.dataModel.moduleId,errorCode);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdShowFail:error:)]) {
        NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:self.dataModel.fbId}];
        [self.showDelegate onAdShowFail:self error:errorT];
    }
}



- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode {
    if ([self isTimeOut]) {
        return;
    }
    [self failureWithEndTimer];

    NSError * errorT = [NSError errorWithDomain:@"com.ad" code:errorCode userInfo:@{NSLocalizedDescriptionKey:adUnitIdentifier}];
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didFailToLoadAdForAdUnitIdentifier:withErrorCode: SDK:onAdFail:error:", self.dataModel.moduleId);
        AdLog(@"[%ld] applovin video :error:%@", self.dataModel.moduleId, errorT);
    }

    if ([self.delegate respondsToSelector:@selector(onAdFail:error:)]) {
        [self.delegate onAdFail:self error:errorT];
    }
    
}*/

#pragma mark - MARewardedAdDelegate Protocol

- (void)didCompleteRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didCompleteRewardedVideoForAd:: SDK:onAdOtherEvent:event:CSAdVideoComplete", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdOtherEvent:event:)]) {
        [self.showDelegate onAdOtherEvent:self event:CSAdVideoComplete];
    }

}

- (void)didRewardUserForAd:(nonnull MAAd *)ad withReward:(nonnull MAReward *)reward {

    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didRewardUserForAd:withReward: SDK:onAdVideoCompletePlaying", self.dataModel.moduleId);
    }
    if ([self.showDelegate respondsToSelector:@selector(onAdVideoCompletePlaying:)]) {
        [self.showDelegate onAdVideoCompletePlaying:self];
    }
    //激励视频统计
    [[CSAdStatistics sharedInstance] adRewardVideoCompleteStatistic:self.dataModel];
}

- (void)didStartRewardedVideoForAd:(nonnull MAAd *)ad {
    if ([self needLog]) {
        AdLog(@"[%ld] applovinReward didStartRewardedVideoForAd: SDK:onAdOtherEvent:event:CSAdVideoStart", self.dataModel.moduleId);
    }
    
    if ([self.showDelegate respondsToSelector:@selector(onAdOtherEvent:event:)]) {
        [self.showDelegate onAdOtherEvent:self event:CSAdVideoStart];
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
