//
//  BCCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <BCCSAdSDK/BCCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface BCCSAdLoadApplovinOpen : BCCSAdLoadOpen <BCCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
