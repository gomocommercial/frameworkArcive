//
//  BCCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <BCCSAdSDK/BCCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <BCCSAdSDK/BCCSAdLoadProtocol.h>
#import <BCCSAdSDK/BCCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface BCCSAdLoadApplovinInterstitial : BCCSAdLoadInterstitial<BCCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
