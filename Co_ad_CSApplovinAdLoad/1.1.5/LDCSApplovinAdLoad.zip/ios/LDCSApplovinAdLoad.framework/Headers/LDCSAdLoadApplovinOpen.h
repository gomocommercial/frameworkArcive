//
//  LDCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <LDCSAdSDK/LDCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <LDCSAdSDK/LDCSAdLoadProtocol.h>
#import <LDCSAdSDK/LDCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface LDCSAdLoadApplovinOpen : LDCSAdLoadOpen <LDCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
