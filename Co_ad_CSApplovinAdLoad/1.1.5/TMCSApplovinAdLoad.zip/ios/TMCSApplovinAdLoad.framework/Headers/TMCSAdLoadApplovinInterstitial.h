//
//  TMCSAdLoadApplovinInterstitial.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/8/27.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <TMCSAdSDK/TMCSAdLoadInterstitial.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TMCSAdSDK/TMCSAdLoadProtocol.h>
#import <TMCSAdSDK/TMCSAdLoadShowProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface TMCSAdLoadApplovinInterstitial : TMCSAdLoadInterstitial<TMCSAdLoadProtocol>
@property (nonatomic, strong) MAInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
