//
//  TMCSAdLoadApplovinReward.h
//  CSAdSDK_Example
//
//  Created by Zy on 2019/9/2.
//  Copyright © 2019 dengnengwei. All rights reserved.
//

#import <TMCSAdSDK/TMCSAdLoadReward.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TMCSAdSDK/TMCSAdLoadProtocol.h>
#import <TMCSAdSDK/TMCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TMCSAdLoadApplovinReward : TMCSAdLoadReward<TMCSAdLoadProtocol>

@property (nonatomic, strong) MARewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
