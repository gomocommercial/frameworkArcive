//
//  TMCSAdLoadApplovinOpen.h
//  AFNetworking
//
//  Created by Zy on 2020/10/30.
//

#import <TMCSAdSDK/TMCSAdLoadOpen.h>
#import <AppLovinSDK/AppLovinSDK.h>
#import <TMCSAdSDK/TMCSAdLoadProtocol.h>
#import <TMCSAdSDK/TMCSAdLoadShowProtocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface TMCSAdLoadApplovinOpen : TMCSAdLoadOpen <TMCSAdLoadProtocol,MAAdDelegate>

@property (nonatomic, strong) MAAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
