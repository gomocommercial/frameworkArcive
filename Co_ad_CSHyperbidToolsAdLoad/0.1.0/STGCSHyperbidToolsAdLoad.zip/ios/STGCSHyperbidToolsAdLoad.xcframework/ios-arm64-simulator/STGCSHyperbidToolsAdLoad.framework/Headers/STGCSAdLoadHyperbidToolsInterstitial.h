//
//  STGCSAdLoadHyperbidToolsInterstitial.h
//  STGCSHyperbidToolsAdLoad
//

#import <STGCSAdSDK/STGCSAdLoadInterstitial.h>
#import <STGCSAdSDK/STGCSAdLoadProtocol.h>
#import <STGCSAdSDK/STGCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadHyperbidToolsInterstitial : STGCSAdLoadInterstitial <STGCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
