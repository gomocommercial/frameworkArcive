//
//  STGCSAdLoadHyperbidToolsReward.h
//  STGCSHyperbidToolsAdLoad
//

#import <STGCSAdSDK/STGCSAdLoadReward.h>
#import <STGCSAdSDK/STGCSAdLoadProtocol.h>
#import <STGCSAdSDK/STGCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadHyperbidToolsReward : STGCSAdLoadReward <STGCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
