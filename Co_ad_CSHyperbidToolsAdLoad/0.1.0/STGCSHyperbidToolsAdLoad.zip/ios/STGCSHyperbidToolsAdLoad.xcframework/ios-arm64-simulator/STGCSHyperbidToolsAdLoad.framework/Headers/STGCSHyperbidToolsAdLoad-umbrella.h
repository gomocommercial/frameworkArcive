#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "STGCSAdLoadHyperbidToolsBanner.h"
#import "STGCSAdLoadHyperbidToolsConfig.h"
#import "STGCSHyperbidToolsConfigModel.h"
#import "STGCSAdLoadHyperbidToolsInterstitial.h"
#import "STGCSAdLoadHyperbidToolsNative.h"
#import "STGCSAdLoadHyperbidToolsOpen.h"
#import "STGCSAdLoadHyperbidToolsReward.h"

FOUNDATION_EXPORT double STGCSHyperbidToolsAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char STGCSHyperbidToolsAdLoadVersionString[];

