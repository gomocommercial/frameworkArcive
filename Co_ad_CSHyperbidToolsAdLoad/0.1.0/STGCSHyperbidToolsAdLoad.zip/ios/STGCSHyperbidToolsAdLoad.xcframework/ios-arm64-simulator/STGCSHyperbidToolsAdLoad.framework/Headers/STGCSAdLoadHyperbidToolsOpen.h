//
//  STGCSAdLoadHyperbidToolsOpen.h
//  STGCSHyperbidToolsAdLoad
//

#import <STGCSAdSDK/STGCSAdLoadOpen.h>
#import <STGCSAdSDK/STGCSAdLoadProtocol.h>
#import <STGCSAdSDK/STGCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadHyperbidToolsOpen : STGCSAdLoadOpen <STGCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
