//
//  STGCSAdLoadHyperbidToolsBanner.h
//  STGCSHyperbidToolsAdLoad
//

#import <STGCSAdSDK/STGCSAdLoadBanner.h>
#import <STGCSAdSDK/STGCSAdLoadProtocol.h>
#import <STGCSAdSDK/STGCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STGCSAdLoadHyperbidToolsBanner : STGCSAdLoadBanner <STGCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
