//
//  GACCSAdLoadHyperbidToolsBanner.h
//  GACCSHyperbidToolsAdLoad
//

#import <GACCSAdSDK/GACCSAdLoadBanner.h>
#import <GACCSAdSDK/GACCSAdLoadProtocol.h>
#import <GACCSAdSDK/GACCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadHyperbidToolsBanner : GACCSAdLoadBanner <GACCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
