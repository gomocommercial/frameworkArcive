//
//  GACCSAdLoadHyperbidToolsInterstitial.h
//  GACCSHyperbidToolsAdLoad
//

#import <GACCSAdSDK/GACCSAdLoadInterstitial.h>
#import <GACCSAdSDK/GACCSAdLoadProtocol.h>
#import <GACCSAdSDK/GACCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadHyperbidToolsInterstitial : GACCSAdLoadInterstitial <GACCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
