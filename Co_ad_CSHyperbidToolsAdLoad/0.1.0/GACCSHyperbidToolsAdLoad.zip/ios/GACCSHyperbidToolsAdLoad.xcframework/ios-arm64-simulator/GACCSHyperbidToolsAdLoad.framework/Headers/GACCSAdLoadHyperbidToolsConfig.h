//
//  GACCSAdLoadHyperbidToolsConfig.h
//  GACCSHyperbidToolsAdLoad
//

#import <Foundation/Foundation.h>
#import <MCSDK/MCSDK.h>
#import "GACCSHyperbidToolsConfigModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadHyperbidToolsConfig : NSObject

@property (nonatomic, strong) NSMutableArray<GACCSHyperbidToolsConfigModel *> *configs;

+ (instancetype)sharedInstance;

/// Set ad source value used by fetcher matching.
/// Default is `gACkAdvDataSourceHyperbidTools`.
+ (void)setAdDataSource:(NSInteger)adDataSource;
+ (NSInteger)adDataSource;

/// Banner config
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID
                   bannerAdPosition:(CGPoint)bannerPosition
                         bannerSize:(CGSize)bannerSize
                  adBackgroundColor:(UIColor *)backgroundColor
                  rootViewController:(UIViewController *)rootViewController
                isShowInCustomerView:(BOOL)isShowInCustomerView
                             sceneId:(nullable NSString *)sceneId;

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID;

/// Native config
+ (void)setNativeConfigWithMoudleId:(NSString *)modudleID
                         nativeView:(nullable MCNativeAdView *)nativeView
                            sceneId:(nullable NSString *)sceneId;

+ (void)removeNativeConfigWithModuleId:(NSString *)moduleId;

@end

NS_ASSUME_NONNULL_END
