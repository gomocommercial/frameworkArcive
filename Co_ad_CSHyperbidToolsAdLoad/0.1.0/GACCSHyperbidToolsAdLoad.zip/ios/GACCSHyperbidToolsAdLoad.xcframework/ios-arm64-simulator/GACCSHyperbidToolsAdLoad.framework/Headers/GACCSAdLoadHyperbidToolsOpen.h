//
//  GACCSAdLoadHyperbidToolsOpen.h
//  GACCSHyperbidToolsAdLoad
//

#import <GACCSAdSDK/GACCSAdLoadOpen.h>
#import <GACCSAdSDK/GACCSAdLoadProtocol.h>
#import <GACCSAdSDK/GACCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadHyperbidToolsOpen : GACCSAdLoadOpen <GACCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
