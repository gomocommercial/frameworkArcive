//
//  GACCSAdLoadHyperbidToolsReward.h
//  GACCSHyperbidToolsAdLoad
//

#import <GACCSAdSDK/GACCSAdLoadReward.h>
#import <GACCSAdSDK/GACCSAdLoadProtocol.h>
#import <GACCSAdSDK/GACCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface GACCSAdLoadHyperbidToolsReward : GACCSAdLoadReward <GACCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
