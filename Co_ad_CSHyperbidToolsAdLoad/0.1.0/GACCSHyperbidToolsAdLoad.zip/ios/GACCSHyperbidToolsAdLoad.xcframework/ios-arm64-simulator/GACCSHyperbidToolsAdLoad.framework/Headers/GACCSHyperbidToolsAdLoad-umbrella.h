#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "GACCSAdLoadHyperbidToolsBanner.h"
#import "GACCSAdLoadHyperbidToolsConfig.h"
#import "GACCSHyperbidToolsConfigModel.h"
#import "GACCSAdLoadHyperbidToolsInterstitial.h"
#import "GACCSAdLoadHyperbidToolsNative.h"
#import "GACCSAdLoadHyperbidToolsOpen.h"
#import "GACCSAdLoadHyperbidToolsReward.h"

FOUNDATION_EXPORT double GACCSHyperbidToolsAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char GACCSHyperbidToolsAdLoadVersionString[];

