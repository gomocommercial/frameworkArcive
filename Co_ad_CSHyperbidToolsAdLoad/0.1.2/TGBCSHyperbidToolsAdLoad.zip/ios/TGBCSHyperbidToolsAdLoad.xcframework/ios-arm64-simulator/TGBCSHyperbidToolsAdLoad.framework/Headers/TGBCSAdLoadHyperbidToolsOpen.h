//
//  TGBCSAdLoadHyperbidToolsOpen.h
//  TGBCSHyperbidToolsAdLoad
//

#import <TGBCSAdSDK/TGBCSAdLoadOpen.h>
#import <TGBCSAdSDK/TGBCSAdLoadProtocol.h>
#import <TGBCSAdSDK/TGBCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadHyperbidToolsOpen : TGBCSAdLoadOpen <TGBCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
