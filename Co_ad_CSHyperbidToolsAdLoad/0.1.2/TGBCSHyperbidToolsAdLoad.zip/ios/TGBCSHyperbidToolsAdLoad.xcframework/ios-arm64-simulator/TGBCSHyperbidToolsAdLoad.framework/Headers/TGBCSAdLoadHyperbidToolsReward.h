//
//  TGBCSAdLoadHyperbidToolsReward.h
//  TGBCSHyperbidToolsAdLoad
//

#import <TGBCSAdSDK/TGBCSAdLoadReward.h>
#import <TGBCSAdSDK/TGBCSAdLoadProtocol.h>
#import <TGBCSAdSDK/TGBCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadHyperbidToolsReward : TGBCSAdLoadReward <TGBCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
