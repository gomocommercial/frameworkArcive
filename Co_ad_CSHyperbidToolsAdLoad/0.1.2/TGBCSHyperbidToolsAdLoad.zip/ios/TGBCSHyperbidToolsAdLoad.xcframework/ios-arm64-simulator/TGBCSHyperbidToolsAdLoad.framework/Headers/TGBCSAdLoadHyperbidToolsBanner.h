//
//  TGBCSAdLoadHyperbidToolsBanner.h
//  TGBCSHyperbidToolsAdLoad
//

#import <TGBCSAdSDK/TGBCSAdLoadBanner.h>
#import <TGBCSAdSDK/TGBCSAdLoadProtocol.h>
#import <TGBCSAdSDK/TGBCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadHyperbidToolsBanner : TGBCSAdLoadBanner <TGBCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
