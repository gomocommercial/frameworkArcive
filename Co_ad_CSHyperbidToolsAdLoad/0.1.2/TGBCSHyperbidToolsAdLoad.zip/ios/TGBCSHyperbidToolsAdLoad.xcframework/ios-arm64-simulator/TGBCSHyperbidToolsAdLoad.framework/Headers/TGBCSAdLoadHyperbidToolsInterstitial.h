//
//  TGBCSAdLoadHyperbidToolsInterstitial.h
//  TGBCSHyperbidToolsAdLoad
//

#import <TGBCSAdSDK/TGBCSAdLoadInterstitial.h>
#import <TGBCSAdSDK/TGBCSAdLoadProtocol.h>
#import <TGBCSAdSDK/TGBCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSAdLoadHyperbidToolsInterstitial : TGBCSAdLoadInterstitial <TGBCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
