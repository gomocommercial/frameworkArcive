//
//  QLCSAdLoadHyperbidToolsBanner.h
//  QLCSHyperbidToolsAdLoad
//

#import <QLCSAdSDK/QLCSAdLoadBanner.h>
#import <QLCSAdSDK/QLCSAdLoadProtocol.h>
#import <QLCSAdSDK/QLCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadHyperbidToolsBanner : QLCSAdLoadBanner <QLCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
