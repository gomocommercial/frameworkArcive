//
//  QLCSAdLoadHyperbidToolsNative.h
//  QLCSHyperbidToolsAdLoad
//

#import <QLCSAdSDK/QLCSAdLoadNative.h>
#import <QLCSAdSDK/QLCSAdLoadProtocol.h>
#import <QLCSAdSDK/QLCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadHyperbidToolsNative : QLCSAdLoadNative <QLCSAdLoadProtocol, MCNativeAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCNativeAdLoader *nativeAdLoader;
@property (nonatomic, strong, nullable) MCNativeAdView *nativeAdView;
@property (nonatomic, strong, nullable) MCAdInfo *ad;

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
