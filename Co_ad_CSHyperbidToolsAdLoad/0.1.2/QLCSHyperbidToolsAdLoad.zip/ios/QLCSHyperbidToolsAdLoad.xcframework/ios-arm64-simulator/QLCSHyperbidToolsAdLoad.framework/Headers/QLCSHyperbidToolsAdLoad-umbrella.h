#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "QLCSAdLoadHyperbidToolsBanner.h"
#import "QLCSAdLoadHyperbidToolsConfig.h"
#import "QLCSHyperbidToolsConfigModel.h"
#import "QLCSAdLoadHyperbidToolsInterstitial.h"
#import "QLCSAdLoadHyperbidToolsNative.h"
#import "QLCSAdLoadHyperbidToolsOpen.h"
#import "QLCSAdLoadHyperbidToolsReward.h"

FOUNDATION_EXPORT double QLCSHyperbidToolsAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char QLCSHyperbidToolsAdLoadVersionString[];

