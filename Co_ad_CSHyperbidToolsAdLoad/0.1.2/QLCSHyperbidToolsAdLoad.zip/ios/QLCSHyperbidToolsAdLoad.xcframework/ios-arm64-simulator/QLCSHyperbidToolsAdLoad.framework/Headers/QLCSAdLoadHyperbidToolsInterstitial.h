//
//  QLCSAdLoadHyperbidToolsInterstitial.h
//  QLCSHyperbidToolsAdLoad
//

#import <QLCSAdSDK/QLCSAdLoadInterstitial.h>
#import <QLCSAdSDK/QLCSAdLoadProtocol.h>
#import <QLCSAdSDK/QLCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadHyperbidToolsInterstitial : QLCSAdLoadInterstitial <QLCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
