//
//  QLCSAdLoadHyperbidToolsReward.h
//  QLCSHyperbidToolsAdLoad
//

#import <QLCSAdSDK/QLCSAdLoadReward.h>
#import <QLCSAdSDK/QLCSAdLoadProtocol.h>
#import <QLCSAdSDK/QLCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadHyperbidToolsReward : QLCSAdLoadReward <QLCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
