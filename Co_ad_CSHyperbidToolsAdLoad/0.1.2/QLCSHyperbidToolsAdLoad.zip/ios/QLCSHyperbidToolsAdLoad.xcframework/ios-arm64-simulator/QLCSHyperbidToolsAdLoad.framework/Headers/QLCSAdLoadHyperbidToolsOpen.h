//
//  QLCSAdLoadHyperbidToolsOpen.h
//  QLCSHyperbidToolsAdLoad
//

#import <QLCSAdSDK/QLCSAdLoadOpen.h>
#import <QLCSAdSDK/QLCSAdLoadProtocol.h>
#import <QLCSAdSDK/QLCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLCSAdLoadHyperbidToolsOpen : QLCSAdLoadOpen <QLCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
