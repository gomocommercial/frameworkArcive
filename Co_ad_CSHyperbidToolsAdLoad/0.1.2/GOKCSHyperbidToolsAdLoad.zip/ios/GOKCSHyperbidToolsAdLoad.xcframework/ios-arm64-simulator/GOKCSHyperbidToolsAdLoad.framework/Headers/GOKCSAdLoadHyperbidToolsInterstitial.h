//
//  GOKCSAdLoadHyperbidToolsInterstitial.h
//  GOKCSHyperbidToolsAdLoad
//

#import <GOKCSAdSDK/GOKCSAdLoadInterstitial.h>
#import <GOKCSAdSDK/GOKCSAdLoadProtocol.h>
#import <GOKCSAdSDK/GOKCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadHyperbidToolsInterstitial : GOKCSAdLoadInterstitial <GOKCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
