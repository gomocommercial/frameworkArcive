//
//  GOKCSAdLoadHyperbidToolsBanner.h
//  GOKCSHyperbidToolsAdLoad
//

#import <GOKCSAdSDK/GOKCSAdLoadBanner.h>
#import <GOKCSAdSDK/GOKCSAdLoadProtocol.h>
#import <GOKCSAdSDK/GOKCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadHyperbidToolsBanner : GOKCSAdLoadBanner <GOKCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
