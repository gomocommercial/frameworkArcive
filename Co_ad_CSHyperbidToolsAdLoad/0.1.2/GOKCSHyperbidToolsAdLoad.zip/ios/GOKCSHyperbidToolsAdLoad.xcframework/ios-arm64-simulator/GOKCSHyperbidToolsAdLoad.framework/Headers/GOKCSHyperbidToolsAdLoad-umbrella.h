#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "GOKCSAdLoadHyperbidToolsBanner.h"
#import "GOKCSAdLoadHyperbidToolsConfig.h"
#import "GOKCSHyperbidToolsConfigModel.h"
#import "GOKCSAdLoadHyperbidToolsInterstitial.h"
#import "GOKCSAdLoadHyperbidToolsNative.h"
#import "GOKCSAdLoadHyperbidToolsOpen.h"
#import "GOKCSAdLoadHyperbidToolsReward.h"

FOUNDATION_EXPORT double GOKCSHyperbidToolsAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char GOKCSHyperbidToolsAdLoadVersionString[];

