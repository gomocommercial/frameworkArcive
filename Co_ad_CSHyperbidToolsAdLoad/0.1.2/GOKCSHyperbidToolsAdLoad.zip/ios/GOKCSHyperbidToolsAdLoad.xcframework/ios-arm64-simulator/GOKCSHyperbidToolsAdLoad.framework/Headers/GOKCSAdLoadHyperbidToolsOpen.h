//
//  GOKCSAdLoadHyperbidToolsOpen.h
//  GOKCSHyperbidToolsAdLoad
//

#import <GOKCSAdSDK/GOKCSAdLoadOpen.h>
#import <GOKCSAdSDK/GOKCSAdLoadProtocol.h>
#import <GOKCSAdSDK/GOKCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadHyperbidToolsOpen : GOKCSAdLoadOpen <GOKCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
