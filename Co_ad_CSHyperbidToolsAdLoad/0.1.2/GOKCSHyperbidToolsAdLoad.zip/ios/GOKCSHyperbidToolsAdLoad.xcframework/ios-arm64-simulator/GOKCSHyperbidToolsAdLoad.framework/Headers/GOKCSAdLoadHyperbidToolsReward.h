//
//  GOKCSAdLoadHyperbidToolsReward.h
//  GOKCSHyperbidToolsAdLoad
//

#import <GOKCSAdSDK/GOKCSAdLoadReward.h>
#import <GOKCSAdSDK/GOKCSAdLoadProtocol.h>
#import <GOKCSAdSDK/GOKCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSAdLoadHyperbidToolsReward : GOKCSAdLoadReward <GOKCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
