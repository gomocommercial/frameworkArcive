#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "STPBCSAdLoadHyperbidToolsBanner.h"
#import "STPBCSAdLoadHyperbidToolsConfig.h"
#import "STPBCSHyperbidToolsConfigModel.h"
#import "STPBCSAdLoadHyperbidToolsInterstitial.h"
#import "STPBCSAdLoadHyperbidToolsNative.h"
#import "STPBCSAdLoadHyperbidToolsOpen.h"
#import "STPBCSAdLoadHyperbidToolsReward.h"

FOUNDATION_EXPORT double STPBCSHyperbidToolsAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char STPBCSHyperbidToolsAdLoadVersionString[];

