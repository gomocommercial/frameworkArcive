//
//  STPBCSAdLoadHyperbidToolsNative.h
//  STPBCSHyperbidToolsAdLoad
//

#import <STPBCSAdSDK/STPBCSAdLoadNative.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadHyperbidToolsNative : STPBCSAdLoadNative <STPBCSAdLoadProtocol, MCNativeAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCNativeAdLoader *nativeAdLoader;
@property (nonatomic, strong, nullable) MCNativeAdView *nativeAdView;
@property (nonatomic, strong, nullable) MCAdInfo *ad;

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
