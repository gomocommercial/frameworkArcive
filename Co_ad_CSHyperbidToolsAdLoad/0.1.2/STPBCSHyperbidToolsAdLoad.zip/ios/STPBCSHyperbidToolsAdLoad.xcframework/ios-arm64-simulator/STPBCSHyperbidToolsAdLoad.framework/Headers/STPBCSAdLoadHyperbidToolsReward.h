//
//  STPBCSAdLoadHyperbidToolsReward.h
//  STPBCSHyperbidToolsAdLoad
//

#import <STPBCSAdSDK/STPBCSAdLoadReward.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadHyperbidToolsReward : STPBCSAdLoadReward <STPBCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
