//
//  STPBCSAdLoadHyperbidToolsBanner.h
//  STPBCSHyperbidToolsAdLoad
//

#import <STPBCSAdSDK/STPBCSAdLoadBanner.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadHyperbidToolsBanner : STPBCSAdLoadBanner <STPBCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
