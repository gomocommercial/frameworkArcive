//
//  STPBCSAdLoadHyperbidToolsInterstitial.h
//  STPBCSHyperbidToolsAdLoad
//

#import <STPBCSAdSDK/STPBCSAdLoadInterstitial.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadHyperbidToolsInterstitial : STPBCSAdLoadInterstitial <STPBCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
