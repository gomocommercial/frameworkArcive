//
//  STPBCSAdLoadHyperbidToolsOpen.h
//  STPBCSHyperbidToolsAdLoad
//

#import <STPBCSAdSDK/STPBCSAdLoadOpen.h>
#import <STPBCSAdSDK/STPBCSAdLoadProtocol.h>
#import <STPBCSAdSDK/STPBCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STPBCSAdLoadHyperbidToolsOpen : STPBCSAdLoadOpen <STPBCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
