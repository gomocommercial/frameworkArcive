//
//  StepWisdomCSAdLoadHyperbidToolsInterstitial.h
//  StepWisdomCSHyperbidToolsAdLoad
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadInterstitial.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadHyperbidToolsInterstitial : StepWisdomCSAdLoadInterstitial <StepWisdomCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
