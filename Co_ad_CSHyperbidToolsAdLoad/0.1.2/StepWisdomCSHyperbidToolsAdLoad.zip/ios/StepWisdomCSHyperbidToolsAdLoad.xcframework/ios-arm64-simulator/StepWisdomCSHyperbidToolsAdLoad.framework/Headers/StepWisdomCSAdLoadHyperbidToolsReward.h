//
//  StepWisdomCSAdLoadHyperbidToolsReward.h
//  StepWisdomCSHyperbidToolsAdLoad
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadReward.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadHyperbidToolsReward : StepWisdomCSAdLoadReward <StepWisdomCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
