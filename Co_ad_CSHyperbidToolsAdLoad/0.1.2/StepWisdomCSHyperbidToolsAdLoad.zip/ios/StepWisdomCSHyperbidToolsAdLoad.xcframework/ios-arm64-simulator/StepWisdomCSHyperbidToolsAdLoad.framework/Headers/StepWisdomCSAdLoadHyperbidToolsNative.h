//
//  StepWisdomCSAdLoadHyperbidToolsNative.h
//  StepWisdomCSHyperbidToolsAdLoad
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadNative.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadHyperbidToolsNative : StepWisdomCSAdLoadNative <StepWisdomCSAdLoadProtocol, MCNativeAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCNativeAdLoader *nativeAdLoader;
@property (nonatomic, strong, nullable) MCNativeAdView *nativeAdView;
@property (nonatomic, strong, nullable) MCAdInfo *ad;

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
