//
//  StepWisdomCSAdLoadHyperbidToolsOpen.h
//  StepWisdomCSHyperbidToolsAdLoad
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadOpen.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadHyperbidToolsOpen : StepWisdomCSAdLoadOpen <StepWisdomCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
