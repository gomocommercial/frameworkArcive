//
//  StepWisdomCSAdLoadHyperbidToolsBanner.h
//  StepWisdomCSHyperbidToolsAdLoad
//

#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadBanner.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadProtocol.h>
#import <StepWisdomCSAdSDK/StepWisdomCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSAdLoadHyperbidToolsBanner : StepWisdomCSAdLoadBanner <StepWisdomCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
