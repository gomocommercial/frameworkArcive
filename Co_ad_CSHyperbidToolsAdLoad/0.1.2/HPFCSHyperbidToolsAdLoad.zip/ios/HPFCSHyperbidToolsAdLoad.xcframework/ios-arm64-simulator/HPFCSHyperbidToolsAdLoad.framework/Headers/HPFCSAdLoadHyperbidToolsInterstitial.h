//
//  HPFCSAdLoadHyperbidToolsInterstitial.h
//  HPFCSHyperbidToolsAdLoad
//

#import <HPFCSAdSDK/HPFCSAdLoadInterstitial.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadHyperbidToolsInterstitial : HPFCSAdLoadInterstitial <HPFCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
