//
//  HPFCSAdLoadHyperbidToolsReward.h
//  HPFCSHyperbidToolsAdLoad
//

#import <HPFCSAdSDK/HPFCSAdLoadReward.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadHyperbidToolsReward : HPFCSAdLoadReward <HPFCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
