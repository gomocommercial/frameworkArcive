//
//  HPFCSAdLoadHyperbidToolsOpen.h
//  HPFCSHyperbidToolsAdLoad
//

#import <HPFCSAdSDK/HPFCSAdLoadOpen.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadHyperbidToolsOpen : HPFCSAdLoadOpen <HPFCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
