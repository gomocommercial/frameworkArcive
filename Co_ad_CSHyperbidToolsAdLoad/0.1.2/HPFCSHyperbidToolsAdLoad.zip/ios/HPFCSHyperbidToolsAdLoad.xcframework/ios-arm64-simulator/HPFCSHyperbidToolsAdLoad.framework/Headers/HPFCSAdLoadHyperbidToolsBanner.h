//
//  HPFCSAdLoadHyperbidToolsBanner.h
//  HPFCSHyperbidToolsAdLoad
//

#import <HPFCSAdSDK/HPFCSAdLoadBanner.h>
#import <HPFCSAdSDK/HPFCSAdLoadProtocol.h>
#import <HPFCSAdSDK/HPFCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPFCSAdLoadHyperbidToolsBanner : HPFCSAdLoadBanner <HPFCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
