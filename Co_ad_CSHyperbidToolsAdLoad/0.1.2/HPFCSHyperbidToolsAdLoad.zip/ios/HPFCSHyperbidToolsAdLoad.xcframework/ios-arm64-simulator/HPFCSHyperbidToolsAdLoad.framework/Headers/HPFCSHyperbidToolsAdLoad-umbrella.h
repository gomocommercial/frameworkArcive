#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "HPFCSAdLoadHyperbidToolsBanner.h"
#import "HPFCSAdLoadHyperbidToolsConfig.h"
#import "HPFCSHyperbidToolsConfigModel.h"
#import "HPFCSAdLoadHyperbidToolsInterstitial.h"
#import "HPFCSAdLoadHyperbidToolsNative.h"
#import "HPFCSAdLoadHyperbidToolsOpen.h"
#import "HPFCSAdLoadHyperbidToolsReward.h"

FOUNDATION_EXPORT double HPFCSHyperbidToolsAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char HPFCSHyperbidToolsAdLoadVersionString[];

