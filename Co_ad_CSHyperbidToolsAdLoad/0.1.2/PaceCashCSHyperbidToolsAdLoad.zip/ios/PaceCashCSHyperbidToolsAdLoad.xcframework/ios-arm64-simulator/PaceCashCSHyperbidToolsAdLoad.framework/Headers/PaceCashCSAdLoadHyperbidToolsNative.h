//
//  PaceCashCSAdLoadHyperbidToolsNative.h
//  PaceCashCSHyperbidToolsAdLoad
//

#import <PaceCashCSAdSDK/PaceCashCSAdLoadNative.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadProtocol.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashCSAdLoadHyperbidToolsNative : PaceCashCSAdLoadNative <PaceCashCSAdLoadProtocol, MCNativeAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCNativeAdLoader *nativeAdLoader;
@property (nonatomic, strong, nullable) MCNativeAdView *nativeAdView;
@property (nonatomic, strong, nullable) MCAdInfo *ad;

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
