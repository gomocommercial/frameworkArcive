//
//  PaceCashCSAdLoadHyperbidToolsReward.h
//  PaceCashCSHyperbidToolsAdLoad
//

#import <PaceCashCSAdSDK/PaceCashCSAdLoadReward.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadProtocol.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashCSAdLoadHyperbidToolsReward : PaceCashCSAdLoadReward <PaceCashCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
