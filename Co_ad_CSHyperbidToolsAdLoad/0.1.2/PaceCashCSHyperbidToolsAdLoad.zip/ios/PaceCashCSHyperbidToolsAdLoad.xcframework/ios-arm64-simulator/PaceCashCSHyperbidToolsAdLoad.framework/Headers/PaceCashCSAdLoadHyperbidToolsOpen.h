//
//  PaceCashCSAdLoadHyperbidToolsOpen.h
//  PaceCashCSHyperbidToolsAdLoad
//

#import <PaceCashCSAdSDK/PaceCashCSAdLoadOpen.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadProtocol.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashCSAdLoadHyperbidToolsOpen : PaceCashCSAdLoadOpen <PaceCashCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
