//
//  PaceCashCSAdLoadHyperbidToolsBanner.h
//  PaceCashCSHyperbidToolsAdLoad
//

#import <PaceCashCSAdSDK/PaceCashCSAdLoadBanner.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadProtocol.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashCSAdLoadHyperbidToolsBanner : PaceCashCSAdLoadBanner <PaceCashCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
