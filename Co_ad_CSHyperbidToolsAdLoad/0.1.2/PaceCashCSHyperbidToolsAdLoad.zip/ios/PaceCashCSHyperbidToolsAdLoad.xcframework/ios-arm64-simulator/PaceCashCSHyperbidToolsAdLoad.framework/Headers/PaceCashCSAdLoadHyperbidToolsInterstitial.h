//
//  PaceCashCSAdLoadHyperbidToolsInterstitial.h
//  PaceCashCSHyperbidToolsAdLoad
//

#import <PaceCashCSAdSDK/PaceCashCSAdLoadInterstitial.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadProtocol.h>
#import <PaceCashCSAdSDK/PaceCashCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PaceCashCSAdLoadHyperbidToolsInterstitial : PaceCashCSAdLoadInterstitial <PaceCashCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
