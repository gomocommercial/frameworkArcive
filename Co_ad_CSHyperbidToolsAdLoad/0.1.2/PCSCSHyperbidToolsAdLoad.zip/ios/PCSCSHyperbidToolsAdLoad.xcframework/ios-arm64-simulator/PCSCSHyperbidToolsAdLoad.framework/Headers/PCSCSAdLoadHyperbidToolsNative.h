//
//  PCSCSAdLoadHyperbidToolsNative.h
//  PCSCSHyperbidToolsAdLoad
//

#import <PCSCSAdSDK/PCSCSAdLoadNative.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadHyperbidToolsNative : PCSCSAdLoadNative <PCSCSAdLoadProtocol, MCNativeAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCNativeAdLoader *nativeAdLoader;
@property (nonatomic, strong, nullable) MCNativeAdView *nativeAdView;
@property (nonatomic, strong, nullable) MCAdInfo *ad;

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
