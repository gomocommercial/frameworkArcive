//
//  PCSCSAdLoadHyperbidToolsReward.h
//  PCSCSHyperbidToolsAdLoad
//

#import <PCSCSAdSDK/PCSCSAdLoadReward.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadHyperbidToolsReward : PCSCSAdLoadReward <PCSCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
