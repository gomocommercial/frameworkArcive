//
//  PCSCSAdLoadHyperbidToolsOpen.h
//  PCSCSHyperbidToolsAdLoad
//

#import <PCSCSAdSDK/PCSCSAdLoadOpen.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadHyperbidToolsOpen : PCSCSAdLoadOpen <PCSCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
