#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "PCSCSAdLoadHyperbidToolsBanner.h"
#import "PCSCSAdLoadHyperbidToolsConfig.h"
#import "PCSCSHyperbidToolsConfigModel.h"
#import "PCSCSAdLoadHyperbidToolsInterstitial.h"
#import "PCSCSAdLoadHyperbidToolsNative.h"
#import "PCSCSAdLoadHyperbidToolsOpen.h"
#import "PCSCSAdLoadHyperbidToolsReward.h"

FOUNDATION_EXPORT double PCSCSHyperbidToolsAdLoadVersionNumber;
FOUNDATION_EXPORT const unsigned char PCSCSHyperbidToolsAdLoadVersionString[];

