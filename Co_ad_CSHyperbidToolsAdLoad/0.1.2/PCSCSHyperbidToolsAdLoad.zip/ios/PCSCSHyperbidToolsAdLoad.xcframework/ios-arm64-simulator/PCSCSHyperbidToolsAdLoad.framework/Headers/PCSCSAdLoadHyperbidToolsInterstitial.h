//
//  PCSCSAdLoadHyperbidToolsInterstitial.h
//  PCSCSHyperbidToolsAdLoad
//

#import <PCSCSAdSDK/PCSCSAdLoadInterstitial.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadHyperbidToolsInterstitial : PCSCSAdLoadInterstitial <PCSCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
