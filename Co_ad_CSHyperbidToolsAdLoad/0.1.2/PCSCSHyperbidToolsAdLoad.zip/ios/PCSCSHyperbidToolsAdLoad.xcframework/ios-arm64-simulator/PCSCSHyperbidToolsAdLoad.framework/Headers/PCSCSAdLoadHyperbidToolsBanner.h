//
//  PCSCSAdLoadHyperbidToolsBanner.h
//  PCSCSHyperbidToolsAdLoad
//

#import <PCSCSAdSDK/PCSCSAdLoadBanner.h>
#import <PCSCSAdSDK/PCSCSAdLoadProtocol.h>
#import <PCSCSAdSDK/PCSCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSAdLoadHyperbidToolsBanner : PCSCSAdLoadBanner <PCSCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
