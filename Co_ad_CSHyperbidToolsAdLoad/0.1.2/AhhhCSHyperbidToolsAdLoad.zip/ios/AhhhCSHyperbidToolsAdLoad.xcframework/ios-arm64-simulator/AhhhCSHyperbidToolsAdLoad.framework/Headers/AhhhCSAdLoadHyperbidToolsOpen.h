//
//  AhhhCSAdLoadHyperbidToolsOpen.h
//  AhhhCSHyperbidToolsAdLoad
//

#import <AhhhCSAdSDK/AhhhCSAdLoadOpen.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadHyperbidToolsOpen : AhhhCSAdLoadOpen <AhhhCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
