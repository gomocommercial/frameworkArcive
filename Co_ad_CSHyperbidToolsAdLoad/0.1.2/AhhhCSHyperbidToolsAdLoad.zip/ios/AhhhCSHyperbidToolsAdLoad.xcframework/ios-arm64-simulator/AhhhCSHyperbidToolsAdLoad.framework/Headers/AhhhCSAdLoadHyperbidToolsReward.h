//
//  AhhhCSAdLoadHyperbidToolsReward.h
//  AhhhCSHyperbidToolsAdLoad
//

#import <AhhhCSAdSDK/AhhhCSAdLoadReward.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadHyperbidToolsReward : AhhhCSAdLoadReward <AhhhCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
