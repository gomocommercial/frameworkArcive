//
//  AhhhCSAdLoadHyperbidToolsInterstitial.h
//  AhhhCSHyperbidToolsAdLoad
//

#import <AhhhCSAdSDK/AhhhCSAdLoadInterstitial.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadHyperbidToolsInterstitial : AhhhCSAdLoadInterstitial <AhhhCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
