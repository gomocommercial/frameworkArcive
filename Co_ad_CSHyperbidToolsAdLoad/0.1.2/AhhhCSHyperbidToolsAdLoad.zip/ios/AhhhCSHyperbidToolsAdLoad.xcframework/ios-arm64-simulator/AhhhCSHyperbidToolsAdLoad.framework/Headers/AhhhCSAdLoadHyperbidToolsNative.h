//
//  AhhhCSAdLoadHyperbidToolsNative.h
//  AhhhCSHyperbidToolsAdLoad
//

#import <AhhhCSAdSDK/AhhhCSAdLoadNative.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadHyperbidToolsNative : AhhhCSAdLoadNative <AhhhCSAdLoadProtocol, MCNativeAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCNativeAdLoader *nativeAdLoader;
@property (nonatomic, strong, nullable) MCNativeAdView *nativeAdView;
@property (nonatomic, strong, nullable) MCAdInfo *ad;

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
