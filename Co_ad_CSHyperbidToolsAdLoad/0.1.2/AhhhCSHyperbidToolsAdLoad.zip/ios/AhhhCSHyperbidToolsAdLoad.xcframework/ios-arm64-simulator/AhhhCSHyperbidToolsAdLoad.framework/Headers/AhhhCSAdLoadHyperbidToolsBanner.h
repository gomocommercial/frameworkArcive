//
//  AhhhCSAdLoadHyperbidToolsBanner.h
//  AhhhCSHyperbidToolsAdLoad
//

#import <AhhhCSAdSDK/AhhhCSAdLoadBanner.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadProtocol.h>
#import <AhhhCSAdSDK/AhhhCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSAdLoadHyperbidToolsBanner : AhhhCSAdLoadBanner <AhhhCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
