//
//  LSTCSAdLoadHyperbidToolsInterstitial.h
//  LSTCSHyperbidToolsAdLoad
//

#import <LSTCSAdSDK/LSTCSAdLoadInterstitial.h>
#import <LSTCSAdSDK/LSTCSAdLoadProtocol.h>
#import <LSTCSAdSDK/LSTCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadHyperbidToolsInterstitial : LSTCSAdLoadInterstitial <LSTCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
