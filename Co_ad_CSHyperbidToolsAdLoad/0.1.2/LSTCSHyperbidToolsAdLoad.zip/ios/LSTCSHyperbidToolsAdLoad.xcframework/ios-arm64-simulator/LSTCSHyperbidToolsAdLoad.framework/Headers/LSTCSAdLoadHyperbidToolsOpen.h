//
//  LSTCSAdLoadHyperbidToolsOpen.h
//  LSTCSHyperbidToolsAdLoad
//

#import <LSTCSAdSDK/LSTCSAdLoadOpen.h>
#import <LSTCSAdSDK/LSTCSAdLoadProtocol.h>
#import <LSTCSAdSDK/LSTCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadHyperbidToolsOpen : LSTCSAdLoadOpen <LSTCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
