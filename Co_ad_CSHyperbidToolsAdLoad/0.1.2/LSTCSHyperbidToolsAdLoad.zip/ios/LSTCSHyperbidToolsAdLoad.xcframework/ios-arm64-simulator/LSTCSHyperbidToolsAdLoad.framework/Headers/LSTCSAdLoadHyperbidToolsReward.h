//
//  LSTCSAdLoadHyperbidToolsReward.h
//  LSTCSHyperbidToolsAdLoad
//

#import <LSTCSAdSDK/LSTCSAdLoadReward.h>
#import <LSTCSAdSDK/LSTCSAdLoadProtocol.h>
#import <LSTCSAdSDK/LSTCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadHyperbidToolsReward : LSTCSAdLoadReward <LSTCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
