//
//  LSTCSAdLoadHyperbidToolsBanner.h
//  LSTCSHyperbidToolsAdLoad
//

#import <LSTCSAdSDK/LSTCSAdLoadBanner.h>
#import <LSTCSAdSDK/LSTCSAdLoadProtocol.h>
#import <LSTCSAdSDK/LSTCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSTCSAdLoadHyperbidToolsBanner : LSTCSAdLoadBanner <LSTCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
