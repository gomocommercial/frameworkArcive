//
//  STEPTCSAdLoadHyperbidToolsReward.h
//  STEPTCSHyperbidToolsAdLoad
//

#import <STEPTCSAdSDK/STEPTCSAdLoadReward.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadProtocol.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdLoadHyperbidToolsReward : STEPTCSAdLoadReward <STEPTCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
