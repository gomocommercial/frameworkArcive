//
//  STEPTCSAdLoadHyperbidToolsOpen.h
//  STEPTCSHyperbidToolsAdLoad
//

#import <STEPTCSAdSDK/STEPTCSAdLoadOpen.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadProtocol.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdLoadHyperbidToolsOpen : STEPTCSAdLoadOpen <STEPTCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
