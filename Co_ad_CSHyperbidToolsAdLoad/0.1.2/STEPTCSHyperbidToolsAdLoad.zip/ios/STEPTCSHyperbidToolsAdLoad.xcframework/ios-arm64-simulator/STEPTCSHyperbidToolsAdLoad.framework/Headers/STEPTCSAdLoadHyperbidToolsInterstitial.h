//
//  STEPTCSAdLoadHyperbidToolsInterstitial.h
//  STEPTCSHyperbidToolsAdLoad
//

#import <STEPTCSAdSDK/STEPTCSAdLoadInterstitial.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadProtocol.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdLoadHyperbidToolsInterstitial : STEPTCSAdLoadInterstitial <STEPTCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
