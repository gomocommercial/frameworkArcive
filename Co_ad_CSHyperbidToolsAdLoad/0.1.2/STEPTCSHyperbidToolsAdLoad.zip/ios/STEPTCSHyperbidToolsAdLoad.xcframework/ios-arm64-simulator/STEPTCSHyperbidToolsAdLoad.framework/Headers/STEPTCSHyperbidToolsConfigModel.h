//
//  STEPTCSHyperbidToolsConfigModel.h
//  STEPTCSHyperbidToolsAdLoad
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@class STEPTCSAdLoadHyperbidToolsBanner;

@interface STEPTCSHyperbidToolsConfigModel : NSObject

@property (nonatomic, assign) NSInteger onlineadvtype;
@property (nonatomic, copy) NSString *moudleID;

// Banner
@property (nonatomic, assign) CGPoint bannerPosition;
@property (nonatomic, assign) CGSize bannerSize;
@property (nonatomic, weak) UIViewController *rootViewController;
@property (nonatomic, copy) UIColor *backgroundColor;
@property (nonatomic, assign) BOOL isShowInCustomerView;
@property (nonatomic, copy) NSString *sceneId;
@property (nonatomic, weak) STEPTCSAdLoadHyperbidToolsBanner *banner;
@property (nonatomic, assign) BOOL isLoadedBanner;

// Native
@property (nonatomic, weak) MCNativeAdView *nativeAdView;

@end

NS_ASSUME_NONNULL_END
