//
//  STEPTCSAdLoadHyperbidToolsNative.h
//  STEPTCSHyperbidToolsAdLoad
//

#import <STEPTCSAdSDK/STEPTCSAdLoadNative.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadProtocol.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdLoadHyperbidToolsNative : STEPTCSAdLoadNative <STEPTCSAdLoadProtocol, MCNativeAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCNativeAdLoader *nativeAdLoader;
@property (nonatomic, strong, nullable) MCNativeAdView *nativeAdView;
@property (nonatomic, strong, nullable) MCAdInfo *ad;

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
