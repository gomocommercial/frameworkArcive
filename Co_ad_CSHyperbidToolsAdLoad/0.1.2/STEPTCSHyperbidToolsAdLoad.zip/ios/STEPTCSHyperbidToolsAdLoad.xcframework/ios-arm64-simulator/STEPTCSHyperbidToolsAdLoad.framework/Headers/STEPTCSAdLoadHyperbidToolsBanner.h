//
//  STEPTCSAdLoadHyperbidToolsBanner.h
//  STEPTCSHyperbidToolsAdLoad
//

#import <STEPTCSAdSDK/STEPTCSAdLoadBanner.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadProtocol.h>
#import <STEPTCSAdSDK/STEPTCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdLoadHyperbidToolsBanner : STEPTCSAdLoadBanner <STEPTCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
