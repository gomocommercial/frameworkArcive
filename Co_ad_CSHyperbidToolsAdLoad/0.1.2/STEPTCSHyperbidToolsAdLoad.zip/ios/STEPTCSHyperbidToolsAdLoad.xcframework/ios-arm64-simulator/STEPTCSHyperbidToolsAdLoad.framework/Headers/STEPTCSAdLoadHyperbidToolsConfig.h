//
//  STEPTCSAdLoadHyperbidToolsConfig.h
//  STEPTCSHyperbidToolsAdLoad
//

#import <Foundation/Foundation.h>
#import <MCSDK/MCSDK.h>
#import "STEPTCSHyperbidToolsConfigModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface STEPTCSAdLoadHyperbidToolsConfig : NSObject

@property (nonatomic, strong) NSMutableArray<STEPTCSHyperbidToolsConfigModel *> *configs;

+ (instancetype)sharedInstance;

/// Set ad source value used by fetcher matching.
/// Default is `sTEPTkAdvDataSourceHyperbidTools`.
+ (void)setAdDataSource:(NSInteger)adDataSource;
+ (NSInteger)adDataSource;

/// Banner config
+ (void)setBannerConfigWithMoudleId:(NSString *)modudleID
                   bannerAdPosition:(CGPoint)bannerPosition
                         bannerSize:(CGSize)bannerSize
                  adBackgroundColor:(UIColor *)backgroundColor
                  rootViewController:(UIViewController *)rootViewController
                isShowInCustomerView:(BOOL)isShowInCustomerView
                             sceneId:(nullable NSString *)sceneId;

+ (void)removeBannerConfigWithMoudleId:(NSString *)moduleID;

/// Native config
+ (void)setNativeConfigWithMoudleId:(NSString *)modudleID
                         nativeView:(nullable MCNativeAdView *)nativeView
                            sceneId:(nullable NSString *)sceneId;

+ (void)removeNativeConfigWithModuleId:(NSString *)moduleId;

@end

NS_ASSUME_NONNULL_END
