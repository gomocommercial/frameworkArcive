//
//  CUC_PCSAdLoadHyperbidToolsNative.h
//  CUC_PCSHyperbidToolsAdLoad
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadNative.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadHyperbidToolsNative : CUC_PCSAdLoadNative <CUC_PCSAdLoadProtocol, MCNativeAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCNativeAdLoader *nativeAdLoader;
@property (nonatomic, strong, nullable) MCNativeAdView *nativeAdView;
@property (nonatomic, strong, nullable) MCAdInfo *ad;

- (void)closeAd;

@end

NS_ASSUME_NONNULL_END
