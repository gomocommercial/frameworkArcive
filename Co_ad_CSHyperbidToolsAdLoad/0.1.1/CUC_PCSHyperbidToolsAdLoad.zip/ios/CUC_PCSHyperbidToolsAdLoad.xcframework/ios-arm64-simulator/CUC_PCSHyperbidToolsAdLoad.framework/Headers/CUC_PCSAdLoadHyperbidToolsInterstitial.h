//
//  CUC_PCSAdLoadHyperbidToolsInterstitial.h
//  CUC_PCSHyperbidToolsAdLoad
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadInterstitial.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadHyperbidToolsInterstitial : CUC_PCSAdLoadInterstitial <CUC_PCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCInterstitialAd *ad;

@end

NS_ASSUME_NONNULL_END
