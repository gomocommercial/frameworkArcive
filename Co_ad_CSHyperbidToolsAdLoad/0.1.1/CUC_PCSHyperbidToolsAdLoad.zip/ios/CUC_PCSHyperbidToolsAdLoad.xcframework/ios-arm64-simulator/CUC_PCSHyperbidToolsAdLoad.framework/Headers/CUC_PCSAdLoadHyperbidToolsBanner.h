//
//  CUC_PCSAdLoadHyperbidToolsBanner.h
//  CUC_PCSHyperbidToolsAdLoad
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadBanner.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadHyperbidToolsBanner : CUC_PCSAdLoadBanner <CUC_PCSAdLoadProtocol, MCBannerAdViewAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCBannerAdView *adView;

@end

NS_ASSUME_NONNULL_END
