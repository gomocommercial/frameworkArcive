//
//  CUC_PCSAdLoadHyperbidToolsReward.h
//  CUC_PCSHyperbidToolsAdLoad
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadReward.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadHyperbidToolsReward : CUC_PCSAdLoadReward <CUC_PCSAdLoadProtocol, MCRewardedAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCRewardedAd *ad;

@end

NS_ASSUME_NONNULL_END
