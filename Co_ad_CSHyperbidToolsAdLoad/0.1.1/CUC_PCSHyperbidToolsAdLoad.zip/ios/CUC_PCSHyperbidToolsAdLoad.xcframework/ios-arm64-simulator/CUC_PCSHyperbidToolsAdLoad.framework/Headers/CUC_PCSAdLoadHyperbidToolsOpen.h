//
//  CUC_PCSAdLoadHyperbidToolsOpen.h
//  CUC_PCSHyperbidToolsAdLoad
//

#import <CUC_PCSAdSDK/CUC_PCSAdLoadOpen.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadProtocol.h>
#import <CUC_PCSAdSDK/CUC_PCSAdLoadShowProtocol.h>
#import <MCSDK/MCSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUC_PCSAdLoadHyperbidToolsOpen : CUC_PCSAdLoadOpen <CUC_PCSAdLoadProtocol, MCAdDelegate, MCAdRevenueDelegate>

@property (nonatomic, strong) MCAppOpenAd *ad;

@end

NS_ASSUME_NONNULL_END
