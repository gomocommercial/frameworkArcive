//
// Created by zhangjiemin on 2018/7/4.
//

#import <Foundation/Foundation.h>

#define GM_PURPOSE_PURCHASE @"PRODUCT_PURCHASE"
#define GM_PURPOSE_RECHARGE @"VCOIN_RECHARGE"
#define GM_PURPOSE_SUBCRIPTION @"PRODUCT_SUBSCRIPTION"

@interface PaymentConfig : NSObject
@property (nonatomic,copy) NSString *accessToken;
@property (nonatomic,copy) NSString *accountId;
@property(nonatomic, assign) BOOL isTest;//是否是测试环境 YES代表debug环境
@property(nonatomic, copy) NSString *localPassword;
@property(nonatomic, copy) NSString *staticUUID;

- (void)initPaymentConfigDebugWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password;

- (void)initPaymentConfigReleaseWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password;

- (NSString *)getPayStateDomain;

- (NSString *)getSignatureKey;

- (NSString *)getClientID;

- (NSString *)getStaticUUID;

- (void)setStaticUUID:(NSString *)uuid;

+ (instancetype)sharedManger;
@end
