//
// Created by zhangjiemin on 2018/7/5.
//

#import <Foundation/Foundation.h>

@class SKProduct;


@interface ProductModel : NSObject
@property (nonatomic) NSInteger gold_coin;
@property (nonatomic) NSInteger diamond;
@property (nonatomic, copy) NSString *gold_coin_img_url;
@property (nonatomic) float price;
//
@property (nonatomic, strong) NSString *product_id;

@property (nonatomic,copy) NSString *currency_code;
@property (nonatomic,copy) NSString *price_readable;
@property (nonatomic,copy) NSString *product_desc;
@property (nonatomic, copy) NSString* tran_id;  //tran_id
@property (nonatomic, copy) NSString *purpose;   //内购的途径
@property (nonatomic,strong) SKProduct *product;
@property (nonatomic,strong) NSDictionary *productDic;
@property (nonatomic) Boolean isPayment;

- (instancetype)initWithProduct:(SKProduct *)product;


+(instancetype)modelWithJSON:(NSDictionary *)json;

-(NSDictionary *)modelToJSONObject;
@end
