//
//  PAY_TESTPayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PAY_TESTPayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "PAY_TESTPayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^PAY_TESTPayNotificationStateApiCompleteBlock) (PAY_TESTPayNotificationHTTPResponse *response);

@interface PAY_TESTPayNotificationStateApiManager : AFHTTPSessionManager
+ (PAY_TESTPayNotificationStateApiManager *)pAY_TESTsharedManager;
//支付成功新增后台 通知接口
-(void)pAY_TESTcheckiOSIAPPayOrderWithPayNotificationModel:(PAY_TESTPayNotificationModel *)payNotificationModel  complete:(PAY_TESTPayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
