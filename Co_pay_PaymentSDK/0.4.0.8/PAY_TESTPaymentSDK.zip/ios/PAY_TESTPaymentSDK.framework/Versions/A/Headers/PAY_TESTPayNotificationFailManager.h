//
//  PAY_TESTPayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "PAY_TESTPayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PAY_TESTPayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)pAY_TESTsaveToCacheWithProductId:(NSString *)product_id;
+(PAY_TESTPayNotificationModel*)pAY_TESTunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)pAY_TESTdelSerializedBean:(PAY_TESTPayNotificationModel*)bean;
+(NSArray <PAY_TESTPayNotificationModel *>*)pAY_TESTgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)pAY_TESTretryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
