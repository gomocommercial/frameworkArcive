//
//  StepWisdomCSInfo.h
//  StepWisdomCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface StepWisdomCSInfo : NSObject

/// 获取本地语言
+ (NSString *)stepWisdomcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)stepWisdomcsGetSimInfo;

/// 获取IP地址
+ (NSString *)stepWisdomcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)stepWisdomcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)stepWisdomcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)stepWisdomcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)stepWisdomcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)stepWisdomcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
