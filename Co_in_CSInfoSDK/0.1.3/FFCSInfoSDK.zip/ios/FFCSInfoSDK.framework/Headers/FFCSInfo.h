//
//  FFCSInfo.h
//  FFCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FFCSInfo : NSObject

/// 获取本地语言
+ (NSString *)fFcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)fFcsGetSimInfo;

/// 获取IP地址
+ (NSString *)fFcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)fFcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)fFcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)fFcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)fFcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)fFcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
