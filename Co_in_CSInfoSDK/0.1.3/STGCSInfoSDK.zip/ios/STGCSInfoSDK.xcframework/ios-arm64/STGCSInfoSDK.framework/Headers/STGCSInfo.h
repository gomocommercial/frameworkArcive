//
//  STGCSInfo.h
//  STGCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface STGCSInfo : NSObject

/// 获取本地语言
+ (NSString *)sTGcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)sTGcsGetSimInfo;

/// 获取IP地址
+ (NSString *)sTGcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)sTGcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)sTGcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)sTGcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)sTGcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)sTGcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
