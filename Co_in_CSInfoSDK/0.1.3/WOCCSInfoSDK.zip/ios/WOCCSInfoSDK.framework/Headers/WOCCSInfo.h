//
//  WOCCSInfo.h
//  WOCCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface WOCCSInfo : NSObject

/// 获取本地语言
+ (NSString *)wOCcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)wOCcsGetSimInfo;

/// 获取IP地址
+ (NSString *)wOCcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)wOCcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)wOCcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)wOCcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)wOCcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)wOCcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
