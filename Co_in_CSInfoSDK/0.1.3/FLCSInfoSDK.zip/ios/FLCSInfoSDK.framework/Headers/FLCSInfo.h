//
//  FLCSInfo.h
//  FLCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FLCSInfo : NSObject

/// 获取本地语言
+ (NSString *)fLcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)fLcsGetSimInfo;

/// 获取IP地址
+ (NSString *)fLcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)fLcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)fLcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)fLcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)fLcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)fLcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
