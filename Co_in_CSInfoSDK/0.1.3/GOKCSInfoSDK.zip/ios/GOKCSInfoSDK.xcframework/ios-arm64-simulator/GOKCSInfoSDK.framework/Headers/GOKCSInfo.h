//
//  GOKCSInfo.h
//  GOKCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GOKCSInfo : NSObject

/// 获取本地语言
+ (NSString *)gOKcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)gOKcsGetSimInfo;

/// 获取IP地址
+ (NSString *)gOKcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)gOKcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)gOKcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)gOKcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)gOKcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)gOKcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
