//
//  TRCSInfo.h
//  TRCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TRCSInfo : NSObject

/// 获取本地语言
+ (NSString *)tRcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)tRcsGetSimInfo;

/// 获取IP地址
+ (NSString *)tRcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)tRcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)tRcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)tRcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)tRcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)tRcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
