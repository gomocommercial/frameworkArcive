//
//  DESCSInfo.h
//  DESCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DESCSInfo : NSObject

/// 获取本地语言
+ (NSString *)dEScsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)dEScsGetSimInfo;

/// 获取IP地址
+ (NSString *)dEScsGetIPAddress;

/// 获取VPN地址
+ (NSString *)dEScsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)dEScsGetDNSAddresses;

/// 获取设备名
+ (NSString *)dEScsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)dEScsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)dEScsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
