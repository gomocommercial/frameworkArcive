//
//  MOLCSInfo.h
//  MOLCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MOLCSInfo : NSObject

/// 获取本地语言
+ (NSString *)mOLcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)mOLcsGetSimInfo;

/// 获取IP地址
+ (NSString *)mOLcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)mOLcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)mOLcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)mOLcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)mOLcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)mOLcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
