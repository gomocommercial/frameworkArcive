//
//  CSCSInfo.h
//  CSCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSCSInfo : NSObject

/// 获取本地语言
+ (NSString *)cScsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)cScsGetSimInfo;

/// 获取IP地址
+ (NSString *)cScsGetIPAddress;

/// 获取VPN地址
+ (NSString *)cScsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)cScsGetDNSAddresses;

/// 获取设备名
+ (NSString *)cScsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)cScsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)cScsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
