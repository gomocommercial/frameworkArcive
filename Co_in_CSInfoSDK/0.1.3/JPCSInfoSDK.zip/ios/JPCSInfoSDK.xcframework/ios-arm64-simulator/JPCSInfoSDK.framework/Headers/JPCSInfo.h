//
//  JPCSInfo.h
//  JPCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JPCSInfo : NSObject

/// 获取本地语言
+ (NSString *)jPcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)jPcsGetSimInfo;

/// 获取IP地址
+ (NSString *)jPcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)jPcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)jPcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)jPcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)jPcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)jPcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
