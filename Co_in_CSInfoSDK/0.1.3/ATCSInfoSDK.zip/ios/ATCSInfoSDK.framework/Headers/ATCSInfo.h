//
//  ATCSInfo.h
//  ATCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ATCSInfo : NSObject

/// 获取本地语言
+ (NSString *)aTcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)aTcsGetSimInfo;

/// 获取IP地址
+ (NSString *)aTcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)aTcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)aTcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)aTcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)aTcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)aTcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
