//
//  FSLPCSInfo.h
//  FSLPCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSLPCSInfo : NSObject

/// 获取本地语言
+ (NSString *)fSLPcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)fSLPcsGetSimInfo;

/// 获取IP地址
+ (NSString *)fSLPcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)fSLPcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)fSLPcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)fSLPcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)fSLPcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)fSLPcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
