//
//  CLECSInfo.h
//  CLECSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLECSInfo : NSObject

/// 获取本地语言
+ (NSString *)cLEcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)cLEcsGetSimInfo;

/// 获取IP地址
+ (NSString *)cLEcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)cLEcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)cLEcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)cLEcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)cLEcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)cLEcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
