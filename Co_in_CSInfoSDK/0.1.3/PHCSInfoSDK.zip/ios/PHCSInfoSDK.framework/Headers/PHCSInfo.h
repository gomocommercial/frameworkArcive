//
//  PHCSInfo.h
//  PHCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PHCSInfo : NSObject

/// 获取本地语言
+ (NSString *)pHcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)pHcsGetSimInfo;

/// 获取IP地址
+ (NSString *)pHcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)pHcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)pHcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)pHcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)pHcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)pHcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
