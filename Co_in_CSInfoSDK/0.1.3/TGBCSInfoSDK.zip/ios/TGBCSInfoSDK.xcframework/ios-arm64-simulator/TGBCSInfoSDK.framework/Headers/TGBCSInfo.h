//
//  TGBCSInfo.h
//  TGBCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TGBCSInfo : NSObject

/// 获取本地语言
+ (NSString *)tGBcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)tGBcsGetSimInfo;

/// 获取IP地址
+ (NSString *)tGBcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)tGBcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)tGBcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)tGBcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)tGBcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)tGBcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
