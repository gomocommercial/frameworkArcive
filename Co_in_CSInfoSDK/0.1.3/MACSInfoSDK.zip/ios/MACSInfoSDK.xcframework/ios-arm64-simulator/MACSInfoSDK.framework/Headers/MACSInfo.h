//
//  MACSInfo.h
//  MACSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MACSInfo : NSObject

/// 获取本地语言
+ (NSString *)mAcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)mAcsGetSimInfo;

/// 获取IP地址
+ (NSString *)mAcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)mAcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)mAcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)mAcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)mAcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)mAcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
