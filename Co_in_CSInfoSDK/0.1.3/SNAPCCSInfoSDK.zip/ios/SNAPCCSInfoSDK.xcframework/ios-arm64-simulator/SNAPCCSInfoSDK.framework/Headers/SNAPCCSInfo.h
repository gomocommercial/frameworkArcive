//
//  SNAPCCSInfo.h
//  SNAPCCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SNAPCCSInfo : NSObject

/// 获取本地语言
+ (NSString *)sNAPCcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)sNAPCcsGetSimInfo;

/// 获取IP地址
+ (NSString *)sNAPCcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)sNAPCcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)sNAPCcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)sNAPCcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)sNAPCcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)sNAPCcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
