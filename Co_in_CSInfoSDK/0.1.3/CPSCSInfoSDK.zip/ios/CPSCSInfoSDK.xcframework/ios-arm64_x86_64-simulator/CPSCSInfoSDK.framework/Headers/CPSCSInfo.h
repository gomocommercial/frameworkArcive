//
//  CPSCSInfo.h
//  CPSCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CPSCSInfo : NSObject

/// 获取本地语言
+ (NSString *)cPScsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)cPScsGetSimInfo;

/// 获取IP地址
+ (NSString *)cPScsGetIPAddress;

/// 获取VPN地址
+ (NSString *)cPScsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)cPScsGetDNSAddresses;

/// 获取设备名
+ (NSString *)cPScsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)cPScsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)cPScsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
