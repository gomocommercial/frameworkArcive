//
//  TACSInfo.h
//  TACSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TACSInfo : NSObject

/// 获取本地语言
+ (NSString *)tAcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)tAcsGetSimInfo;

/// 获取IP地址
+ (NSString *)tAcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)tAcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)tAcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)tAcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)tAcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)tAcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
