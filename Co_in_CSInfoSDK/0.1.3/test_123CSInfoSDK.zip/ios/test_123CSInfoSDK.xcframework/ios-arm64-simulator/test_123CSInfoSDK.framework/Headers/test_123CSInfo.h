//
//  test_123CSInfo.h
//  test_123CSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface test_123CSInfo : NSObject

/// 获取本地语言
+ (NSString *)test_123csGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)test_123csGetSimInfo;

/// 获取IP地址
+ (NSString *)test_123csGetIPAddress;

/// 获取VPN地址
+ (NSString *)test_123csGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)test_123csGetDNSAddresses;

/// 获取设备名
+ (NSString *)test_123csGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)test_123csGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)test_123csGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
