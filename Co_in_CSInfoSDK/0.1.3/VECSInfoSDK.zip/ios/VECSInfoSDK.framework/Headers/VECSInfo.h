//
//  VECSInfo.h
//  VECSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface VECSInfo : NSObject

/// 获取本地语言
+ (NSString *)vEcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)vEcsGetSimInfo;

/// 获取IP地址
+ (NSString *)vEcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)vEcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)vEcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)vEcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)vEcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)vEcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
