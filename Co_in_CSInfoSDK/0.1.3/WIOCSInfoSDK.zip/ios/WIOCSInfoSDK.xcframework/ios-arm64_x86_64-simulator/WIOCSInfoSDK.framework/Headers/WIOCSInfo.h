//
//  WIOCSInfo.h
//  WIOCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface WIOCSInfo : NSObject

/// 获取本地语言
+ (NSString *)wIOcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)wIOcsGetSimInfo;

/// 获取IP地址
+ (NSString *)wIOcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)wIOcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)wIOcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)wIOcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)wIOcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)wIOcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
