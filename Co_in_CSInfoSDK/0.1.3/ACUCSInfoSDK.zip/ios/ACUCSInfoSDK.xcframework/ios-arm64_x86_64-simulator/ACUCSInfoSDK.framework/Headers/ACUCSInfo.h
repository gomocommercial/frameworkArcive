//
//  ACUCSInfo.h
//  ACUCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ACUCSInfo : NSObject

/// 获取本地语言
+ (NSString *)aCUcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)aCUcsGetSimInfo;

/// 获取IP地址
+ (NSString *)aCUcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)aCUcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)aCUcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)aCUcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)aCUcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)aCUcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
