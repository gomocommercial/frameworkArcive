//
//  Co_ad_CSInfo.h
//  Co_ad_CSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_ad_CSInfo : NSObject

/// 获取本地语言
+ (NSString *)co_ad_csGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)co_ad_csGetSimInfo;

/// 获取IP地址
+ (NSString *)co_ad_csGetIPAddress;

/// 获取VPN地址
+ (NSString *)co_ad_csGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)co_ad_csGetDNSAddresses;

/// 获取设备名
+ (NSString *)co_ad_csGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)co_ad_csGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)co_ad_csGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
