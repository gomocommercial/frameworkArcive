#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "Co_ad_CSInfo.h"

FOUNDATION_EXPORT double Co_ad_CSInfoSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char Co_ad_CSInfoSDKVersionString[];

