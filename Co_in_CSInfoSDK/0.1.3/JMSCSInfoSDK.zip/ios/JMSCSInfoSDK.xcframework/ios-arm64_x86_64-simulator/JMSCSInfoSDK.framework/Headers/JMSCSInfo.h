//
//  JMSCSInfo.h
//  JMSCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JMSCSInfo : NSObject

/// 获取本地语言
+ (NSString *)jMScsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)jMScsGetSimInfo;

/// 获取IP地址
+ (NSString *)jMScsGetIPAddress;

/// 获取VPN地址
+ (NSString *)jMScsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)jMScsGetDNSAddresses;

/// 获取设备名
+ (NSString *)jMScsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)jMScsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)jMScsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
