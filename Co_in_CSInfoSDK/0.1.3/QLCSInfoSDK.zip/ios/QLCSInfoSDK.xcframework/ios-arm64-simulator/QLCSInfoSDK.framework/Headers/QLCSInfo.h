//
//  QLCSInfo.h
//  QLCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLCSInfo : NSObject

/// 获取本地语言
+ (NSString *)qLcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)qLcsGetSimInfo;

/// 获取IP地址
+ (NSString *)qLcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)qLcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)qLcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)qLcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)qLcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)qLcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
