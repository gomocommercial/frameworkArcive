//
//  GACCSInfo.h
//  GACCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GACCSInfo : NSObject

/// 获取本地语言
+ (NSString *)gACcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)gACcsGetSimInfo;

/// 获取IP地址
+ (NSString *)gACcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)gACcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)gACcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)gACcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)gACcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)gACcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
