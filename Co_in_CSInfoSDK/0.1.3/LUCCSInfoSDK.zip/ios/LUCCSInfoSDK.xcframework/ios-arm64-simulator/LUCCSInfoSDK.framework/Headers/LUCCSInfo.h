//
//  LUCCSInfo.h
//  LUCCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LUCCSInfo : NSObject

/// 获取本地语言
+ (NSString *)lUCcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)lUCcsGetSimInfo;

/// 获取IP地址
+ (NSString *)lUCcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)lUCcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)lUCcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)lUCcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)lUCcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)lUCcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
