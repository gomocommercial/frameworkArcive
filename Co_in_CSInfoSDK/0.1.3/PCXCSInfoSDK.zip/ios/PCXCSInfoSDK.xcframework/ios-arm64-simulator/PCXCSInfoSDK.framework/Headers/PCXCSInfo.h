//
//  PCXCSInfo.h
//  PCXCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCXCSInfo : NSObject

/// 获取本地语言
+ (NSString *)pCXcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)pCXcsGetSimInfo;

/// 获取IP地址
+ (NSString *)pCXcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)pCXcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)pCXcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)pCXcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)pCXcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)pCXcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
