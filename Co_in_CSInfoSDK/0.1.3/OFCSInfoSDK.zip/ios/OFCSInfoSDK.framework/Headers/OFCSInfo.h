//
//  OFCSInfo.h
//  OFCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OFCSInfo : NSObject

/// 获取本地语言
+ (NSString *)oFcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)oFcsGetSimInfo;

/// 获取IP地址
+ (NSString *)oFcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)oFcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)oFcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)oFcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)oFcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)oFcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
