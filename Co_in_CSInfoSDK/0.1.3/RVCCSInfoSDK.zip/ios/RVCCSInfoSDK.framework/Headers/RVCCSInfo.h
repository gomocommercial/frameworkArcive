//
//  RVCCSInfo.h
//  RVCCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RVCCSInfo : NSObject

/// 获取本地语言
+ (NSString *)rVCcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)rVCcsGetSimInfo;

/// 获取IP地址
+ (NSString *)rVCcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)rVCcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)rVCcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)rVCcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)rVCcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)rVCcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
