//
//  DGCSInfo.h
//  DGCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DGCSInfo : NSObject

/// 获取本地语言
+ (NSString *)dGcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)dGcsGetSimInfo;

/// 获取IP地址
+ (NSString *)dGcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)dGcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)dGcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)dGcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)dGcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)dGcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
