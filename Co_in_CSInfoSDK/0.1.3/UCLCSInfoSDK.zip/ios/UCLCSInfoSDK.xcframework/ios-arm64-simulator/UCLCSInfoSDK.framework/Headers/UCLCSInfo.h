//
//  UCLCSInfo.h
//  UCLCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UCLCSInfo : NSObject

/// 获取本地语言
+ (NSString *)uCLcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)uCLcsGetSimInfo;

/// 获取IP地址
+ (NSString *)uCLcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)uCLcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)uCLcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)uCLcsGetDeviceName;

/// 获取国家名:国家编号的字典
+ (NSDictionary <NSString*,NSString*>*)uCLcsGetCountryNameDictionary;

/// 获取设备编号:设备名的字典
+ (NSDictionary <NSString*,NSString*>*)uCLcsGetDeviceNameDictionary;
@end

NS_ASSUME_NONNULL_END
