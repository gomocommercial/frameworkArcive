//
//  PCSCSInfo.h
//  PCSCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCSCSInfo : NSObject

/// 获取本地语言
+ (NSString *)pCScsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)pCScsGetSimInfo;

/// 获取IP地址
+ (NSString *)pCScsGetIPAddress;

/// 获取VPN地址
+ (NSString *)pCScsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)pCScsGetDNSAddresses;

/// 获取设备名
+ (NSString *)pCScsGetDeviceName;

@end

NS_ASSUME_NONNULL_END
