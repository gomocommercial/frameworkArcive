//
//  PPP_PCSInfo.h
//  PPP_PCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_PCSInfo : NSObject

/// 获取本地语言
+ (NSString *)pPP_PcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)pPP_PcsGetSimInfo;

/// 获取IP地址
+ (NSString *)pPP_PcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)pPP_PcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)pPP_PcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)pPP_PcsGetDeviceName;

@end

NS_ASSUME_NONNULL_END
