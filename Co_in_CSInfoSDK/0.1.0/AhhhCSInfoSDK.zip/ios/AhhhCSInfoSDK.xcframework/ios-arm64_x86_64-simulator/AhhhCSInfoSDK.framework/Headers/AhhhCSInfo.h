//
//  AhhhCSInfo.h
//  AhhhCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AhhhCSInfo : NSObject

/// 获取本地语言
+ (NSString *)ahhhcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)ahhhcsGetSimInfo;

/// 获取IP地址
+ (NSString *)ahhhcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)ahhhcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)ahhhcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)ahhhcsGetDeviceName;

@end

NS_ASSUME_NONNULL_END
