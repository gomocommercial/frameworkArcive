//
//  AMACSInfo.h
//  AMACSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMACSInfo : NSObject

/// 获取本地语言
+ (NSString *)aMAcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)aMAcsGetSimInfo;

/// 获取IP地址
+ (NSString *)aMAcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)aMAcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)aMAcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)aMAcsGetDeviceName;

@end

NS_ASSUME_NONNULL_END
