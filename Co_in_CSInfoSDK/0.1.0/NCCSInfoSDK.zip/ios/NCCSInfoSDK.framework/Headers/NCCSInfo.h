//
//  NCCSInfo.h
//  NCCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NCCSInfo : NSObject

/// 获取本地语言
+ (NSString *)nCcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)nCcsGetSimInfo;

/// 获取IP地址
+ (NSString *)nCcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)nCcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)nCcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)nCcsGetDeviceName;

@end

NS_ASSUME_NONNULL_END
