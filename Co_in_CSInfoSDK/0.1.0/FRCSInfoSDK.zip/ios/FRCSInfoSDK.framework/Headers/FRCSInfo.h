//
//  FRCSInfo.h
//  FRCSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FRCSInfo : NSObject

/// 获取本地语言
+ (NSString *)fRcsGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)fRcsGetSimInfo;

/// 获取IP地址
+ (NSString *)fRcsGetIPAddress;

/// 获取VPN地址
+ (NSString *)fRcsGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)fRcsGetDNSAddresses;

/// 获取设备名
+ (NSString *)fRcsGetDeviceName;

@end

NS_ASSUME_NONNULL_END
