//
//  PPP_P_CSInfo.h
//  PPP_P_CSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPP_P_CSInfo : NSObject

/// 获取本地语言
+ (NSString *)pPP_P_csGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)pPP_P_csGetSimInfo;

/// 获取IP地址
+ (NSString *)pPP_P_csGetIPAddress;

/// 获取VPN地址
+ (NSString *)pPP_P_csGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)pPP_P_csGetDNSAddresses;

/// 获取设备名
+ (NSString *)pPP_P_csGetDeviceName;

@end

NS_ASSUME_NONNULL_END
