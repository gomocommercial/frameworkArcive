#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "PPP_P_CSInfo.h"

FOUNDATION_EXPORT double PPP_P_CSInfoSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char PPP_P_CSInfoSDKVersionString[];

