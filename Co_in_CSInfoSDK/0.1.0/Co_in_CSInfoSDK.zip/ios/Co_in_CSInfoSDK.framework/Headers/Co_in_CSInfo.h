//
//  Co_in_CSInfo.h
//  Co_in_CSInfoSDK
//
//  Created by Zy on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_in_CSInfo : NSObject

/// 获取本地语言
+ (NSString *)co_in_csGetLanguage;

/// 获取sim卡信息，格式(运营商名字_ISO国家代码_移动国家代码_移动网络代码）
+ (NSString *)co_in_csGetSimInfo;

/// 获取IP地址
+ (NSString *)co_in_csGetIPAddress;

/// 获取VPN地址
+ (NSString *)co_in_csGetVPNAddress;

/// 获取DNS数组
+ (NSArray *)co_in_csGetDNSAddresses;

/// 获取设备名
+ (NSString *)co_in_csGetDeviceName;

@end

NS_ASSUME_NONNULL_END
