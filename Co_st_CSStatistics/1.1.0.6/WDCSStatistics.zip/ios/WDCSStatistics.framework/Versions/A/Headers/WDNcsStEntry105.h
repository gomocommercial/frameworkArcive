//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "WDNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface WDNcsStEntry105 : WDNcsStEntry103


@end
