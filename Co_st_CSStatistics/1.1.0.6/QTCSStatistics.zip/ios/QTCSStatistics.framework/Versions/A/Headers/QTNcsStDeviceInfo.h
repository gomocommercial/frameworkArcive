//
//  QTNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QTNcsStDeviceInfo : NSObject

+ (NSDictionary *)qTdevice;

+ (NSDictionary *)qTdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)qTUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)qTadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)qTgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)qTgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)qTgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)qTgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)qTgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)qTgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)qTgetCPUType;


/**
 App ID
 */
+ (NSString *)qTgetAppID;


/**
 Bundle ID
 */
+ (NSString *)qTgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)qTgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)qTgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)qTgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)qTgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)qTgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)qTisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)qTgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
