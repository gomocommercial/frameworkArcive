//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "FLNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface FLNcsStEntry105 : FLNcsStEntry103


@end
