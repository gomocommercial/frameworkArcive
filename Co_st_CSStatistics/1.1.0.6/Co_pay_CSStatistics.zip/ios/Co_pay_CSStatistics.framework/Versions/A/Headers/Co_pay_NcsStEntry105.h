//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "Co_pay_NcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface Co_pay_NcsStEntry105 : Co_pay_NcsStEntry103


@end
