//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Co_pay_NcsStTest : NSObject

+(void)co_pay_test;

+(void)co_pay_testOld;

@end
