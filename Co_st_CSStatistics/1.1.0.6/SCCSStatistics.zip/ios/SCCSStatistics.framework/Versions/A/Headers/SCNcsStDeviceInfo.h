//
//  SCNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCNcsStDeviceInfo : NSObject

+ (NSDictionary *)sCdevice;

+ (NSDictionary *)sCdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)sCUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)sCadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)sCgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)sCgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)sCgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)sCgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)sCgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)sCgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)sCgetCPUType;


/**
 App ID
 */
+ (NSString *)sCgetAppID;


/**
 Bundle ID
 */
+ (NSString *)sCgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)sCgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)sCgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)sCgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)sCgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)sCgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)sCisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)sCgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
