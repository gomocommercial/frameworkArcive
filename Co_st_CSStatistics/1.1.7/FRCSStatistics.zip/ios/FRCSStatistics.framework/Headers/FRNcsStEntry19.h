//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "FRNcsStEntryData.h"

/**
 * 19协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=6914524
 */
@interface FRNcsStEntry19 : FRNcsStEntryData

/**
 * 字段21：来源
 */
@property (strong, nonatomic) NSString* originalLogo;

/**
 * 字段22：真版标识
 */
@property (strong, nonatomic) NSString* genuineKey;


/**
 * 字段26：IDFA
 */
@property (strong, nonatomic) NSString* idfa;


/// 是否活跃
@property (assign, nonatomic) BOOL isActivity;


/// 总时长，单位秒
@property (nonatomic, assign) NSTimeInterval time;

@end
