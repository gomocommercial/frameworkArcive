//
//  XSNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XSNcsStDeviceInfo : NSObject

+ (NSDictionary *)xSdevice;

+ (NSDictionary *)xSdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)xSUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)xSadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)xSgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)xSgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)xSgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)xSgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)xSgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)xSgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)xSgetCPUType;


/**
 App ID
 */
+ (NSString *)xSgetAppID;


/**
 Bundle ID
 */
+ (NSString *)xSgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)xSgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)xSgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)xSgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)xSgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)xSgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)xSisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)xSgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
