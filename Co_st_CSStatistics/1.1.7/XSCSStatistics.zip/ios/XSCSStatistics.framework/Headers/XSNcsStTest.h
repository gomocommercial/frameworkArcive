//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface XSNcsStTest : NSObject

+(void)xStest;

+(void)xStestOld;

@end
