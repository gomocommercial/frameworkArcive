//
//  QBNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface QBNcsStDeviceInfo : NSObject

+ (NSDictionary *)qBdevice;

+ (NSDictionary *)qBdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)qBUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)qBadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)qBgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)qBgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)qBgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)qBgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)qBgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)qBgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)qBgetCPUType;


/**
 App ID
 */
+ (NSString *)qBgetAppID;


/**
 Bundle ID
 */
+ (NSString *)qBgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)qBgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)qBgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)qBgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)qBgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)qBgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)qBisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)qBgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
