//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface GSNcsStTest : NSObject

+(void)gStest;

+(void)gStestOld;

@end
