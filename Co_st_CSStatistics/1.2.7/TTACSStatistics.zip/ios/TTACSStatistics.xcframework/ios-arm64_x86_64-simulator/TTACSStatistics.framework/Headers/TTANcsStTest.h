//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface TTANcsStTest : NSObject

+(void)tTAtest;

+(void)tTAtestOld;

@end
