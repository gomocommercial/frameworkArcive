//
//  TTANcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface TTANcsStDeviceInfo : NSObject

+ (NSDictionary *)tTAdevice;

+ (NSDictionary *)tTAdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)tTAUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)tTAadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)tTAgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)tTAgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)tTAgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)tTAgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)tTAgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)tTAgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)tTAgetCPUType;


/**
 App ID
 */
+ (NSString *)tTAgetAppID;


/**
 Bundle ID
 */
+ (NSString *)tTAgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)tTAgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)tTAgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)tTAgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)tTAgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)tTAgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)tTAisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)tTAgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
