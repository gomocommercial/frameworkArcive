//
//  MACUNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface MACUNcsStDeviceInfo : NSObject

+ (NSDictionary *)mACUdevice;

+ (NSDictionary *)mACUdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)mACUUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)mACUadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)mACUgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)mACUgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)mACUgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)mACUgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)mACUgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)mACUgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)mACUgetCPUType;


/**
 App ID
 */
+ (NSString *)mACUgetAppID;


/**
 Bundle ID
 */
+ (NSString *)mACUgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)mACUgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)mACUgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)mACUgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)mACUgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)mACUgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)mACUisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)mACUgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
