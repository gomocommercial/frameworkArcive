//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "SSANcsStEntryData.h"

@class SSANcsStInitParams;
@class SSANcsStInitParamsMaker;
@class SSANcsStEntryDataMaker;
@class SSANcsStEntry103Maker;
@class SSANcsStEntry19Maker;
@class SSANcsStEntry45Maker;
@class SSANcsStEntry59Maker;
@class SSANcsStEntry101Maker;
@class SSANcsStEntry102Maker;
@class SSANcsStEntry104Maker;
@class SSANcsStEntry105Maker;
@class SSANcsStEntry28Maker;

NS_ASSUME_NONNULL_BEGIN

@interface SSANcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)sSAsetup:(SSANcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)sSAsetupByBlock:(void(^)(SSANcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * 
 */
+ (SSANcsStInitParams *)sSAgetCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/


/// 上传设备捕获信息
+ (void)sSAuploadDeviceInfo;
/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)sSAupload:(SSANcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)sSAuploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)sSAuploadCustom:(void(^)(SSANcsStEntryDataMaker *maker)) block;

/// 自定义19协议上传
/// @param isActivity 是否为前台活跃状态
/// @param time 持续时间（仅在isActivity为false时有效）
+ (void)sSAupload19:(BOOL)isActivity time:(NSTimeInterval)time;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)sSAupload19:(void(^)(SSANcsStEntry19Maker *maker)) block;

/**
 * 上传45协议
 * @param block
 */
+ (void)sSAupload45:(void(^)(SSANcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)sSAupload59:(void(^)(SSANcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)sSAupload101:(void(^)(SSANcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)sSAupload102:(void(^)(SSANcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)sSAupload103:(void(^)(SSANcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)sSAupload104:(void(^)(SSANcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)sSAupload105:(void(^)(SSANcsStEntry105Maker *maker)) block;

/**
 * 上传28协议
 * @param block
 */
+ (void)sSAupload28:(void(^)(SSANcsStEntry28Maker *maker)) block;

/**
 * 会话 ID，一次冷启动内唯一
 */
+ (NSString *)sSAgetSessionId;

/**
 * 会话开始时间，生成会话 ID 时的时间
 */
+ (NSString *)sSAgetSessionStartTime;

/**
 * 启动次数，SDK 单独统计
 */
+ (NSInteger)sSAgetLaunchCount;

@end

NS_ASSUME_NONNULL_END
