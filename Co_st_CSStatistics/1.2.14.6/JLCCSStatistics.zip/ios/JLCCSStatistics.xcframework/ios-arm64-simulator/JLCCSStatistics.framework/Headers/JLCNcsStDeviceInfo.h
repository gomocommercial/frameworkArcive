//
//  JLCNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface JLCNcsStDeviceInfo : NSObject

+ (NSDictionary *)jLCdevice;

+ (NSDictionary *)jLCdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)jLCUDIDString;

/**
 获取 UUID 获取历史日志（用于调试）
 */
+ (NSArray<NSDictionary *> *)jLCgetUUIDFetchLogs;


/**
 Apple广告 id
 */
+ (NSString *)jLCadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)jLCgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)jLCgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)jLCgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)jLCgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)jLCgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)jLCgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)jLCgetCPUType;


/**
 App ID
 */
+ (NSString *)jLCgetAppID;


/**
 Bundle ID
 */
+ (NSString *)jLCgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)jLCgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)jLCgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)jLCgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)jLCgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)jLCgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)jLCisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)jLCgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
