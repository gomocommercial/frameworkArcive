//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>
#import "PSENcsStEntryData.h"

/**
 * 29协议：GOPUSH推送
 */
@interface PSENcsStEntry29 : PSENcsStEntryData

/**
 * 字段11：token
 */
@property (strong, nonatomic) NSString* token;

@end
