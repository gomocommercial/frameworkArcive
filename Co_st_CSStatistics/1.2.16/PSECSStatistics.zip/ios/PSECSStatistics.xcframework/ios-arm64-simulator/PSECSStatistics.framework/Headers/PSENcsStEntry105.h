//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "PSENcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface PSENcsStEntry105 : PSENcsStEntry103


@end
