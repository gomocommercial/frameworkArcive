//
//  PSENcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PSENcsStDeviceInfo : NSObject

+ (NSDictionary *)pSEdevice;

+ (NSDictionary *)pSEdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pSEUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pSEadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pSEgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pSEgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pSEgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pSEgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pSEgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pSEgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pSEgetCPUType;


/**
 App ID
 */
+ (NSString *)pSEgetAppID;


/**
 Bundle ID
 */
+ (NSString *)pSEgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)pSEgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pSEgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pSEgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pSEgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pSEgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pSEisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pSEgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
