//
//  FNNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface FNNcsStDeviceInfo : NSObject

+ (NSDictionary *)fNdevice;

+ (NSDictionary *)fNdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)fNUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)fNadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)fNgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)fNgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)fNgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)fNgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)fNgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)fNgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)fNgetCPUType;


/**
 App ID
 */
+ (NSString *)fNgetAppID;


/**
 Bundle ID
 */
+ (NSString *)fNgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)fNgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)fNgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)fNgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)fNgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)fNgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)fNisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)fNgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
