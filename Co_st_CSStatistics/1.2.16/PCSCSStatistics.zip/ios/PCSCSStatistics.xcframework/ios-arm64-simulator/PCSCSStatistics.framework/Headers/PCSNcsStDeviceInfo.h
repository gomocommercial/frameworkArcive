//
//  PCSNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PCSNcsStDeviceInfo : NSObject

+ (NSDictionary *)pCSdevice;

+ (NSDictionary *)pCSdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pCSUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pCSadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pCSgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pCSgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pCSgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pCSgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pCSgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pCSgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pCSgetCPUType;


/**
 App ID
 */
+ (NSString *)pCSgetAppID;


/**
 Bundle ID
 */
+ (NSString *)pCSgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)pCSgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pCSgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pCSgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pCSgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pCSgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pCSisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pCSgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
