//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>
#import "Co_st_NcsStEntryData.h"

/**
 * 29协议：GOPUSH推送
 */
@interface Co_st_NcsStEntry29 : Co_st_NcsStEntryData

/**
 * 字段11：token
 */
@property (strong, nonatomic) NSString* token;

@end
