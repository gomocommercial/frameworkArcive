//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Co_st_NcsStTest : NSObject

+(void)co_st_test;

+(void)co_st_testOld;

@end
