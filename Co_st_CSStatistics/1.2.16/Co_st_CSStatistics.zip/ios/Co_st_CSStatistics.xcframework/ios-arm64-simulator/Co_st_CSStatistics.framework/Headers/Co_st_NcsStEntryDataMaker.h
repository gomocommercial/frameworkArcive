//
// Created by matt on 2019-01-17.
//

#import <Foundation/Foundation.h>
#import "Co_st_NcsStEntryData.h"

@class Co_st_NcsStEntryDataMaker;
@class Co_st_NcsStEntryData;

typedef Co_st_NcsStEntryDataMaker *(^DotNSStringBase)(NSString *);
typedef Co_st_NcsStEntryDataMaker *(^DotBoolBase)(BOOL);
typedef Co_st_NcsStEntryDataMaker *(^DotPriorityBase)(NcsPriority);
typedef Co_st_NcsStEntryDataMaker *(^DotCallbackBase)(NcsStUploadCallback);
typedef Co_st_NcsStEntryData *(^DotMakeBase)();


@interface Co_st_NcsStEntryDataMaker : NSObject

/**
 * 上传的完整数据
 */
@property (strong, nonatomic, readonly) DotNSStringBase data;

/**
 * 协议id
 */
@property (strong, nonatomic, readonly) DotNSStringBase protocalId;

/**
 * 优先级，优先级高的先传
 */
@property (strong, nonatomic, readonly) DotPriorityBase priority;

/**
 * 是否独立上传(不参与拼接)，默认NO
 */
@property (strong, nonatomic, readonly) DotBoolBase uploadSeperately;

/**
 * 上传callback，如果应用重启恢复重传，则这个参数会丢失。
 */
@property (strong, nonatomic, readonly) DotCallbackBase callback;

/**
 * 构建NcsStEntryData对象
 */
@property (strong, nonatomic, readonly) DotMakeBase make;

@end
