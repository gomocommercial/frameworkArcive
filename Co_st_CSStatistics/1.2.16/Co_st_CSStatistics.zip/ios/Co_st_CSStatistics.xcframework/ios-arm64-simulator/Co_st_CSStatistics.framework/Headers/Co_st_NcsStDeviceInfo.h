//
//  Co_st_NcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface Co_st_NcsStDeviceInfo : NSObject

+ (NSDictionary *)co_st_device;

+ (NSDictionary *)co_st_deviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)co_st_UDIDString;

/**
 Apple广告 id
 */
+ (NSString *)co_st_advertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)co_st_getCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)co_st_getDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)co_st_getDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)co_st_getAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)co_st_getAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)co_st_getiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)co_st_getCPUType;


/**
 App ID
 */
+ (NSString *)co_st_getAppID;


/**
 Bundle ID
 */
+ (NSString *)co_st_getBundleId;


/**
 获取当前IP
 */
+ (NSString *)co_st_getIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)co_st_getDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)co_st_getIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)co_st_getCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)co_st_getCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)co_st_isIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)co_st_getDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
