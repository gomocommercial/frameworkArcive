//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "Co_st_NcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface Co_st_NcsStEntry105 : Co_st_NcsStEntry103


@end
