//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "Co_st_NcsStEntryData.h"

@class Co_st_NcsStInitParams;
@class Co_st_NcsStInitParamsMaker;
@class Co_st_NcsStEntryDataMaker;
@class Co_st_NcsStEntry103Maker;
@class Co_st_NcsStEntry19Maker;
@class Co_st_NcsStEntry45Maker;
@class Co_st_NcsStEntry59Maker;
@class Co_st_NcsStEntry101Maker;
@class Co_st_NcsStEntry102Maker;
@class Co_st_NcsStEntry104Maker;
@class Co_st_NcsStEntry105Maker;
@class Co_st_NcsStEntry28Maker;
@class Co_st_NcsStEntry29Maker;

NS_ASSUME_NONNULL_BEGIN

@interface Co_st_NcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)co_st_setup:(Co_st_NcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)co_st_setupByBlock:(void(^)(Co_st_NcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * 
 */
+ (Co_st_NcsStInitParams *)co_st_getCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/


/// 上传设备捕获信息
+ (void)co_st_uploadDeviceInfo;
/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)co_st_upload:(Co_st_NcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)co_st_uploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)co_st_uploadCustom:(void(^)(Co_st_NcsStEntryDataMaker *maker)) block;

/// 自定义19协议上传
/// @param isActivity 是否为前台活跃状态
/// @param time 持续时间（仅在isActivity为false时有效）
+ (void)co_st_upload19:(BOOL)isActivity time:(NSTimeInterval)time;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)co_st_upload19:(void(^)(Co_st_NcsStEntry19Maker *maker)) block;

/// 更新19协议用户属性（第41个字段）
/// @param afid 按需要设置，appsflyer 生成的ID
/// @param caid 按需要设置，caid 是国内才有的
/// @param gender 性别（社交产品使用，没有留空即可，编号对照：0-男，1-女，2-第三性别）
/// @param accid 社交产品注册ID
/// @param cusInfo 客户端自定义参数

+ (void)co_st_upload19: (nullable NSString *)afid caid: (nullable NSString *)caid gender: (nullable NSString *)gender accid: (nullable NSString *)accid cusInfo: (nullable NSDictionary<NSString *, id> *)cusInfo;

/**
 * 上传45协议
 * @param block
 */
+ (void)co_st_upload45:(void(^)(Co_st_NcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)co_st_upload59:(void(^)(Co_st_NcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)co_st_upload101:(void(^)(Co_st_NcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)co_st_upload102:(void(^)(Co_st_NcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)co_st_upload103:(void(^)(Co_st_NcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)co_st_upload104:(void(^)(Co_st_NcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)co_st_upload105:(void(^)(Co_st_NcsStEntry105Maker *maker)) block;

/**
 * 上传28协议
 * @param block
 */
+ (void)co_st_upload28:(void(^)(Co_st_NcsStEntry28Maker *maker)) block;

/**
 * 上传29协议
 * @param block
 */
+ (void)co_st_upload29:(void(^)(Co_st_NcsStEntry29Maker *maker)) block;

/**
 * 会话 ID，一次冷启动内唯一
 */
+ (NSString *)co_st_getSessionId;

/**
 * 会话开始时间，生成会话 ID 时的时间
 */
+ (NSString *)co_st_getSessionStartTime;

/**
 * 启动次数，SDK 单独统计
 */
+ (NSInteger)co_st_getLaunchCount;

@end

NS_ASSUME_NONNULL_END
