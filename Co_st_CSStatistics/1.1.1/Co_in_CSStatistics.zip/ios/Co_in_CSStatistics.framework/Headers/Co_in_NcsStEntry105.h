//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "Co_in_NcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface Co_in_NcsStEntry105 : Co_in_NcsStEntry103


@end
