//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Co_bc_NcsStTest : NSObject

+(void)co_bc_test;

+(void)co_bc_testOld;

@end
