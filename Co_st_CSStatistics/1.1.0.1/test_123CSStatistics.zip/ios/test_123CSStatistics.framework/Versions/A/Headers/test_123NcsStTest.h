//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface test_123NcsStTest : NSObject

+(void)test_123test;

+(void)test_123testOld;

@end
