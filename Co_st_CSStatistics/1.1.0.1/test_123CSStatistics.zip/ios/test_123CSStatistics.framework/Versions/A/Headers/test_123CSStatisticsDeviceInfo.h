//
//  CSDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "test_123NcsStDeviceInfo.h"

__attribute__((deprecated("use Class NcsStEntryFieldUtil instead")))
@interface test_123CSStatisticsDeviceInfo : test_123NcsStDeviceInfo

@end
