//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "test_123NcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface test_123NcsStEntry105 : test_123NcsStEntry103


@end
