//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "SWNcsStEntryData.h"

@class SWNcsStInitParams;
@class SWNcsStInitParamsMaker;
@class SWNcsStEntryDataMaker;
@class SWNcsStEntry103Maker;
@class SWNcsStEntry19Maker;
@class SWNcsStEntry45Maker;
@class SWNcsStEntry59Maker;
@class SWNcsStEntry101Maker;
@class SWNcsStEntry102Maker;
@class SWNcsStEntry104Maker;
@class SWNcsStEntry105Maker;

NS_ASSUME_NONNULL_BEGIN

@interface SWNcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)sWsetup:(SWNcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)sWsetupByBlock:(void(^)(SWNcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * 
 */
+ (SWNcsStInitParams *)sWgetCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/


/// 上传设备捕获信息
+ (void)sWuploadDeviceInfo;
/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)sWupload:(SWNcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)sWuploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)sWuploadCustom:(void(^)(SWNcsStEntryDataMaker *maker)) block;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)sWupload19:(void(^)(SWNcsStEntry19Maker *maker)) block;

/**
 * 上传45协议
 * @param block
 */
+ (void)sWupload45:(void(^)(SWNcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)sWupload59:(void(^)(SWNcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)sWupload101:(void(^)(SWNcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)sWupload102:(void(^)(SWNcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)sWupload103:(void(^)(SWNcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)sWupload104:(void(^)(SWNcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)sWupload105:(void(^)(SWNcsStEntry105Maker *maker)) block;


@end

NS_ASSUME_NONNULL_END
