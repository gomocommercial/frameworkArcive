//
//  FaceVCNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FaceVCNcsStDeviceInfo : NSObject

+ (NSDictionary *)faceVCdevice;

+ (NSDictionary *)faceVCdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)faceVCUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)faceVCadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)faceVCgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)faceVCgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)faceVCgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)faceVCgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)faceVCgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)faceVCgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)faceVCgetCPUType;


/**
 App ID
 */
+ (NSString *)faceVCgetAppID;


/**
 Bundle ID
 */
+ (NSString *)faceVCgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)faceVCgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)faceVCgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)faceVCgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)faceVCgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)faceVCgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)faceVCisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)faceVCgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
