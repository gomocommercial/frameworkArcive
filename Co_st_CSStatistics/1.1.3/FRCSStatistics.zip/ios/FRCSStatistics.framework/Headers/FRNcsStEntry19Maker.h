//
// Created by matt on 2019-01-02.
//

#import <Foundation/Foundation.h>


@class FRNcsStEntry19Maker;
@class FRNcsStEntry19;

typedef FRNcsStEntry19Maker *(^DotNSString19)(NSString *);
typedef FRNcsStEntry19 *(^DotMake19)();

@interface FRNcsStEntry19Maker : NSObject


/**
 * 字段21：来源
 */
@property (strong, nonatomic, readonly) DotNSString19 originalLogo;

/**
 * 字段22：真版标识
 */
@property (strong, nonatomic, readonly) DotNSString19 genuineKey;

/**
 * 字段26：IDFA
 */
@property (strong, nonatomic, readonly) DotNSString19 idfa;

/**
 * 构建NcsStEntry19对象
 */
@property (strong, nonatomic, readonly) DotMake19 make;


@end
