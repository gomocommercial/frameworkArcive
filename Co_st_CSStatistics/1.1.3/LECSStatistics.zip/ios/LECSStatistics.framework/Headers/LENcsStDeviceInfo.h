//
//  LENcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LENcsStDeviceInfo : NSObject

+ (NSDictionary *)lEdevice;

+ (NSDictionary *)lEdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)lEUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)lEadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)lEgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)lEgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)lEgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)lEgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)lEgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)lEgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)lEgetCPUType;


/**
 App ID
 */
+ (NSString *)lEgetAppID;


/**
 Bundle ID
 */
+ (NSString *)lEgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)lEgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)lEgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)lEgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)lEgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)lEgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)lEisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)lEgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
