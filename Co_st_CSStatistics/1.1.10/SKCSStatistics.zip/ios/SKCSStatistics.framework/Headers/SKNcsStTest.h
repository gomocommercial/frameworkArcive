//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface SKNcsStTest : NSObject

+(void)sKtest;

+(void)sKtestOld;

@end
