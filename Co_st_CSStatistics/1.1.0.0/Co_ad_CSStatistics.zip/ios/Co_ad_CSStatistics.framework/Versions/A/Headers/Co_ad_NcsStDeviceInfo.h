//
//  Co_ad_NcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Co_ad_NcsStDeviceInfo : NSObject

+ (NSDictionary *)co_ad_device;

+ (NSDictionary *)co_ad_deviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)co_ad_UDIDString;

/**
 Apple广告 id
 */
+ (NSString *)co_ad_advertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)co_ad_getCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)co_ad_getDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)co_ad_getDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)co_ad_getAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)co_ad_getAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)co_ad_getiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)co_ad_getCPUType;


/**
 App ID
 */
+ (NSString *)co_ad_getAppID;


/**
 Bundle ID
 */
+ (NSString *)co_ad_getBundleId;


/**
 获取当前IP
 */
+ (NSString *)co_ad_getIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)co_ad_getDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)co_ad_getIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)co_ad_getCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)co_ad_getCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)co_ad_isIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)co_ad_getDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
