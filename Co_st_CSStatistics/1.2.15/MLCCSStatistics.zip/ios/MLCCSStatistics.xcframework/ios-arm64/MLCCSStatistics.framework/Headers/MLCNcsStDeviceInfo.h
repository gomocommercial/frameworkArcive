//
//  MLCNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface MLCNcsStDeviceInfo : NSObject

+ (NSDictionary *)mLCdevice;

+ (NSDictionary *)mLCdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)mLCUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)mLCadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)mLCgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)mLCgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)mLCgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)mLCgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)mLCgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)mLCgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)mLCgetCPUType;


/**
 App ID
 */
+ (NSString *)mLCgetAppID;


/**
 Bundle ID
 */
+ (NSString *)mLCgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)mLCgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)mLCgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)mLCgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)mLCgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)mLCgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)mLCisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)mLCgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
