//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface MLCNcsStTest : NSObject

+(void)mLCtest;

+(void)mLCtestOld;

@end
