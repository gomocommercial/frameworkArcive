//
//  LZNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface LZNcsStDeviceInfo : NSObject

+ (NSDictionary *)lZdevice;

+ (NSDictionary *)lZdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)lZUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)lZadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)lZgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)lZgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)lZgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)lZgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)lZgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)lZgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)lZgetCPUType;


/**
 App ID
 */
+ (NSString *)lZgetAppID;


/**
 Bundle ID
 */
+ (NSString *)lZgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)lZgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)lZgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)lZgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)lZgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)lZgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)lZisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)lZgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
