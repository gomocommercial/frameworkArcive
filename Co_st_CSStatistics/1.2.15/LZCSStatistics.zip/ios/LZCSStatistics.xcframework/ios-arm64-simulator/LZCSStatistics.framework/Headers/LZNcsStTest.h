//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface LZNcsStTest : NSObject

+(void)lZtest;

+(void)lZtestOld;

@end
