//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class LZNcsStEntry29Maker;
@class LZNcsStEntry29;

typedef LZNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef LZNcsStEntry29 *(^DotMake29)(void);

@interface LZNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
