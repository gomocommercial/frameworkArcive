//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface DITNcsStTest : NSObject

+(void)dITtest;

+(void)dITtestOld;

@end
