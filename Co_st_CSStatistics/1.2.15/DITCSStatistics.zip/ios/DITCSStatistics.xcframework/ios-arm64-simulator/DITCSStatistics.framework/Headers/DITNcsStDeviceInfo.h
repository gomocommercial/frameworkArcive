//
//  DITNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface DITNcsStDeviceInfo : NSObject

+ (NSDictionary *)dITdevice;

+ (NSDictionary *)dITdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)dITUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)dITadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)dITgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)dITgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)dITgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)dITgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)dITgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)dITgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)dITgetCPUType;


/**
 App ID
 */
+ (NSString *)dITgetAppID;


/**
 Bundle ID
 */
+ (NSString *)dITgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)dITgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)dITgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)dITgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)dITgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)dITgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)dITisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)dITgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
