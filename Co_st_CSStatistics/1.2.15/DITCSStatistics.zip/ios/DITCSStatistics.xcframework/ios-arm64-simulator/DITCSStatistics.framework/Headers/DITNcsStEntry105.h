//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "DITNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface DITNcsStEntry105 : DITNcsStEntry103


@end
