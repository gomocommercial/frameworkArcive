//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class DITNcsStEntry29Maker;
@class DITNcsStEntry29;

typedef DITNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef DITNcsStEntry29 *(^DotMake29)(void);

@interface DITNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
