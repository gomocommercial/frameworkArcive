//
// Created by matt on 2019-01-02.
//

#import <Foundation/Foundation.h>


@class DITNcsStEntry19Maker;
@class DITNcsStEntry19;

typedef DITNcsStEntry19Maker *(^DotNSString19)(NSString *);
typedef DITNcsStEntry19 *(^DotMake19)(void);
typedef DITNcsStEntry19Maker *(^DotBool19)(BOOL);
typedef DITNcsStEntry19Maker *(^DotDouble19)(double);

@interface DITNcsStEntry19Maker : NSObject


/**
 * 字段21：来源
 */
@property (strong, nonatomic, readonly) DotNSString19 originalLogo;

/**
 * 字段22：真版标识
 */
@property (strong, nonatomic, readonly) DotNSString19 genuineKey;

/**
 * 字段26：IDFA
 */
@property (strong, nonatomic, readonly) DotNSString19 idfa;

/**
 * 构建NcsStEntry19对象
 */
@property (strong, nonatomic, readonly) DotMake19 make;

/// 是否活跃
@property (strong, nonatomic, readonly) DotBool19 isActivity;


/// 总时长，单位秒
@property (strong, nonatomic, readonly) DotDouble19 time;


/**
 字段41：用户属性，使用标准json格式上传，包含CAID,AFID等
 格式：
 {
 "afid":"xxxxxxxxxxxxxxxxx",
 "caid":"xxxxxxxxx",
 "gender":"编号", -------------性别（社交产品使用，没有留空即可，编号对照：0-男，1-女，2-第三性别）
 }
 */
@property (strong, nonatomic, readonly) DotNSString19 userInfo;

@end
