//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface PICNcsStTest : NSObject

+(void)pICtest;

+(void)pICtestOld;

@end
