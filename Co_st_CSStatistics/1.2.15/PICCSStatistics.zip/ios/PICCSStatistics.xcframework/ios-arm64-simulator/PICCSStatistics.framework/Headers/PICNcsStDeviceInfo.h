//
//  PICNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PICNcsStDeviceInfo : NSObject

+ (NSDictionary *)pICdevice;

+ (NSDictionary *)pICdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pICUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pICadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pICgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pICgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pICgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pICgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pICgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pICgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pICgetCPUType;


/**
 App ID
 */
+ (NSString *)pICgetAppID;


/**
 Bundle ID
 */
+ (NSString *)pICgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)pICgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pICgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pICgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pICgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pICgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pICisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pICgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
