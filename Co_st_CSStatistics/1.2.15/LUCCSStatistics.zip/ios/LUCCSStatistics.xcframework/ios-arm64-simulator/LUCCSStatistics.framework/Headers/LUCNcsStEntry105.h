//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "LUCNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface LUCNcsStEntry105 : LUCNcsStEntry103


@end
