//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>
#import "LUCNcsStEntryData.h"

/**
 * 29协议：GOPUSH推送
 */
@interface LUCNcsStEntry29 : LUCNcsStEntryData

/**
 * 字段11：token
 */
@property (strong, nonatomic) NSString* token;

@end
