//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class CSPNcsStEntry29Maker;
@class CSPNcsStEntry29;

typedef CSPNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef CSPNcsStEntry29 *(^DotMake29)(void);

@interface CSPNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
