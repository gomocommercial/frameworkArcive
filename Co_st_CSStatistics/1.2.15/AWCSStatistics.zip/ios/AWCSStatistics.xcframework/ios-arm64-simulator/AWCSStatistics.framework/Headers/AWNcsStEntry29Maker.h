//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class AWNcsStEntry29Maker;
@class AWNcsStEntry29;

typedef AWNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef AWNcsStEntry29 *(^DotMake29)(void);

@interface AWNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
