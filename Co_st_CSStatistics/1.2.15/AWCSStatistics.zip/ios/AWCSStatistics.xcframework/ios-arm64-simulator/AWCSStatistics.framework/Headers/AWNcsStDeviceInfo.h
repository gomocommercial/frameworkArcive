//
//  AWNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface AWNcsStDeviceInfo : NSObject

+ (NSDictionary *)aWdevice;

+ (NSDictionary *)aWdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)aWUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)aWadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)aWgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)aWgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)aWgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)aWgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)aWgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)aWgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)aWgetCPUType;


/**
 App ID
 */
+ (NSString *)aWgetAppID;


/**
 Bundle ID
 */
+ (NSString *)aWgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)aWgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)aWgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)aWgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)aWgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)aWgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)aWisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)aWgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
