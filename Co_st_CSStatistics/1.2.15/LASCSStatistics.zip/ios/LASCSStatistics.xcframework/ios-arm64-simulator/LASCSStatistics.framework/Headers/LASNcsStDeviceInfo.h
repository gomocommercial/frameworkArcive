//
//  LASNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface LASNcsStDeviceInfo : NSObject

+ (NSDictionary *)lASdevice;

+ (NSDictionary *)lASdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)lASUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)lASadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)lASgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)lASgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)lASgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)lASgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)lASgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)lASgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)lASgetCPUType;


/**
 App ID
 */
+ (NSString *)lASgetAppID;


/**
 Bundle ID
 */
+ (NSString *)lASgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)lASgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)lASgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)lASgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)lASgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)lASgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)lASisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)lASgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
