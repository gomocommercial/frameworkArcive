//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface LASNcsStTest : NSObject

+(void)lAStest;

+(void)lAStestOld;

@end
