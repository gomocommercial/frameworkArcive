//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class LASNcsStEntry29Maker;
@class LASNcsStEntry29;

typedef LASNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef LASNcsStEntry29 *(^DotMake29)(void);

@interface LASNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
