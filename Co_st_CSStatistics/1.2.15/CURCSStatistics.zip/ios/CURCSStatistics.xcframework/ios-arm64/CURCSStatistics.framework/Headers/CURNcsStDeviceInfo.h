//
//  CURNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface CURNcsStDeviceInfo : NSObject

+ (NSDictionary *)cURdevice;

+ (NSDictionary *)cURdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)cURUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)cURadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)cURgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)cURgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)cURgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)cURgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)cURgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)cURgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)cURgetCPUType;


/**
 App ID
 */
+ (NSString *)cURgetAppID;


/**
 Bundle ID
 */
+ (NSString *)cURgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)cURgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)cURgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)cURgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)cURgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)cURgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)cURisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)cURgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
