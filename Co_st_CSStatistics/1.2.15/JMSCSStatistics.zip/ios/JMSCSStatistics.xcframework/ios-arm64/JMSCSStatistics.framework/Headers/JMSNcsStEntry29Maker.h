//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class JMSNcsStEntry29Maker;
@class JMSNcsStEntry29;

typedef JMSNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef JMSNcsStEntry29 *(^DotMake29)(void);

@interface JMSNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
