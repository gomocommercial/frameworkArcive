//
//  JMSNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface JMSNcsStDeviceInfo : NSObject

+ (NSDictionary *)jMSdevice;

+ (NSDictionary *)jMSdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)jMSUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)jMSadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)jMSgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)jMSgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)jMSgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)jMSgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)jMSgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)jMSgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)jMSgetCPUType;


/**
 App ID
 */
+ (NSString *)jMSgetAppID;


/**
 Bundle ID
 */
+ (NSString *)jMSgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)jMSgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)jMSgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)jMSgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)jMSgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)jMSgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)jMSisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)jMSgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
