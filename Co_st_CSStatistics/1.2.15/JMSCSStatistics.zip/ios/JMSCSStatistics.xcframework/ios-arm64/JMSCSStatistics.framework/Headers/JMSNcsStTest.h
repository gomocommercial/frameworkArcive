//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface JMSNcsStTest : NSObject

+(void)jMStest;

+(void)jMStestOld;

@end
