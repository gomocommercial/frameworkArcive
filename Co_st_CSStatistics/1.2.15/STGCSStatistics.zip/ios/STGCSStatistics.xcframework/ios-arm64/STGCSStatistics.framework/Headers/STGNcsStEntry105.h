//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "STGNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface STGNcsStEntry105 : STGNcsStEntry103


@end
