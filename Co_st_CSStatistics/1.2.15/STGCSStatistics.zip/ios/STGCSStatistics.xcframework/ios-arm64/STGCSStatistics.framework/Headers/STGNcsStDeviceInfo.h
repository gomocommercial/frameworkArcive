//
//  STGNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface STGNcsStDeviceInfo : NSObject

+ (NSDictionary *)sTGdevice;

+ (NSDictionary *)sTGdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)sTGUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)sTGadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)sTGgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)sTGgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)sTGgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)sTGgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)sTGgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)sTGgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)sTGgetCPUType;


/**
 App ID
 */
+ (NSString *)sTGgetAppID;


/**
 Bundle ID
 */
+ (NSString *)sTGgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)sTGgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)sTGgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)sTGgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)sTGgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)sTGgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)sTGisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)sTGgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
