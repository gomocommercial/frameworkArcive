//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface STGNcsStTest : NSObject

+(void)sTGtest;

+(void)sTGtestOld;

@end
