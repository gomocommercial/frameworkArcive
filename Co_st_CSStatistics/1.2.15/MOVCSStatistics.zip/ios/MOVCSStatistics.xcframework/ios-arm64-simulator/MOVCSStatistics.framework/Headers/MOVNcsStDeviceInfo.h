//
//  MOVNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface MOVNcsStDeviceInfo : NSObject

+ (NSDictionary *)mOVdevice;

+ (NSDictionary *)mOVdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)mOVUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)mOVadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)mOVgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)mOVgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)mOVgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)mOVgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)mOVgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)mOVgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)mOVgetCPUType;


/**
 App ID
 */
+ (NSString *)mOVgetAppID;


/**
 Bundle ID
 */
+ (NSString *)mOVgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)mOVgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)mOVgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)mOVgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)mOVgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)mOVgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)mOVisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)mOVgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
