//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface DESNcsStTest : NSObject

+(void)dEStest;

+(void)dEStestOld;

@end
