//
//  DESNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface DESNcsStDeviceInfo : NSObject

+ (NSDictionary *)dESdevice;

+ (NSDictionary *)dESdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)dESUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)dESadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)dESgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)dESgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)dESgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)dESgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)dESgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)dESgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)dESgetCPUType;


/**
 App ID
 */
+ (NSString *)dESgetAppID;


/**
 Bundle ID
 */
+ (NSString *)dESgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)dESgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)dESgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)dESgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)dESgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)dESgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)dESisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)dESgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
