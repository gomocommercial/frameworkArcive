//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "ZyNewNcsStEntryData.h"

@class ZyNewNcsStInitParams;
@class ZyNewNcsStInitParamsMaker;
@class ZyNewNcsStEntryDataMaker;
@class ZyNewNcsStEntry103Maker;
@class ZyNewNcsStEntry19Maker;
@class ZyNewNcsStEntry45Maker;
@class ZyNewNcsStEntry59Maker;
@class ZyNewNcsStEntry101Maker;
@class ZyNewNcsStEntry102Maker;
@class ZyNewNcsStEntry104Maker;
@class ZyNewNcsStEntry105Maker;

NS_ASSUME_NONNULL_BEGIN

@interface ZyNewNcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)zyNewsetup:(ZyNewNcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)zyNewsetupByBlock:(void(^)(ZyNewNcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * @return
 */
+ (ZyNewNcsStInitParams *)zyNewgetCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/

/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)zyNewupload:(ZyNewNcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)zyNewuploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)zyNewuploadCustom:(void(^)(ZyNewNcsStEntryDataMaker *maker)) block;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)zyNewupload19:(void(^)(ZyNewNcsStEntry19Maker *maker)) block;

/**
 * 上传45协议
 * @param block
 */
+ (void)zyNewupload45:(void(^)(ZyNewNcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)zyNewupload59:(void(^)(ZyNewNcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)zyNewupload101:(void(^)(ZyNewNcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)zyNewupload102:(void(^)(ZyNewNcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)zyNewupload103:(void(^)(ZyNewNcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)zyNewupload104:(void(^)(ZyNewNcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)zyNewupload105:(void(^)(ZyNewNcsStEntry105Maker *maker)) block;


@end

NS_ASSUME_NONNULL_END
