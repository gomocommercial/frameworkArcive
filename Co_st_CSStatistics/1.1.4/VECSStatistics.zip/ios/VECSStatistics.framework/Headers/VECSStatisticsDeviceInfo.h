//
//  CSDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VENcsStDeviceInfo.h"

__attribute__((deprecated("use Class NcsStEntryFieldUtil instead")))
@interface VECSStatisticsDeviceInfo : VENcsStDeviceInfo

@end
