//
//  CSNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CSNcsStDeviceInfo : NSObject

+ (NSDictionary *)cSdevice;

+ (NSDictionary *)cSdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)cSUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)cSadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)cSgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)cSgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)cSgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)cSgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)cSgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)cSgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)cSgetCPUType;


/**
 App ID
 */
+ (NSString *)cSgetAppID;


/**
 Bundle ID
 */
+ (NSString *)cSgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)cSgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)cSgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)cSgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)cSgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)cSgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)cSisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)cSgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
