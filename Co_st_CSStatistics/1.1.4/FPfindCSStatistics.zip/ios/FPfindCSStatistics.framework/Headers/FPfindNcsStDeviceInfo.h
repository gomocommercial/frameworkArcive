//
//  FPfindNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FPfindNcsStDeviceInfo : NSObject

+ (NSDictionary *)fPfinddevice;

+ (NSDictionary *)fPfinddeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)fPfindUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)fPfindadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)fPfindgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)fPfindgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)fPfindgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)fPfindgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)fPfindgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)fPfindgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)fPfindgetCPUType;


/**
 App ID
 */
+ (NSString *)fPfindgetAppID;


/**
 Bundle ID
 */
+ (NSString *)fPfindgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)fPfindgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)fPfindgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)fPfindgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)fPfindgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)fPfindgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)fPfindisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)fPfindgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
