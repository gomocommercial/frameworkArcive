//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "FPfindNcsStEntryData.h"

@class FPfindNcsStInitParams;
@class FPfindNcsStInitParamsMaker;
@class FPfindNcsStEntryDataMaker;
@class FPfindNcsStEntry103Maker;
@class FPfindNcsStEntry19Maker;
@class FPfindNcsStEntry45Maker;
@class FPfindNcsStEntry59Maker;
@class FPfindNcsStEntry101Maker;
@class FPfindNcsStEntry102Maker;
@class FPfindNcsStEntry104Maker;
@class FPfindNcsStEntry105Maker;

NS_ASSUME_NONNULL_BEGIN

@interface FPfindNcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)fPfindsetup:(FPfindNcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)fPfindsetupByBlock:(void(^)(FPfindNcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * 
 */
+ (FPfindNcsStInitParams *)fPfindgetCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/


/// 上传设备捕获信息
+ (void)fPfinduploadDeviceInfo;
/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)fPfindupload:(FPfindNcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)fPfinduploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)fPfinduploadCustom:(void(^)(FPfindNcsStEntryDataMaker *maker)) block;

/// 自定义19协议上传
/// @param isActivity 是否为前台活跃状态
/// @param time 持续时间（仅在isActivity为false时有效）
+ (void)fPfindupload19:(BOOL)isActivity time:(NSTimeInterval)time;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)fPfindupload19:(void(^)(FPfindNcsStEntry19Maker *maker)) block;

/**
 * 上传45协议
 * @param block
 */
+ (void)fPfindupload45:(void(^)(FPfindNcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)fPfindupload59:(void(^)(FPfindNcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)fPfindupload101:(void(^)(FPfindNcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)fPfindupload102:(void(^)(FPfindNcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)fPfindupload103:(void(^)(FPfindNcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)fPfindupload104:(void(^)(FPfindNcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)fPfindupload105:(void(^)(FPfindNcsStEntry105Maker *maker)) block;


@end

NS_ASSUME_NONNULL_END
