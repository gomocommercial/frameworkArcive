//
//  CUC_PNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface CUC_PNcsStDeviceInfo : NSObject

+ (NSDictionary *)cUC_Pdevice;

+ (NSDictionary *)cUC_PdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)cUC_PUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)cUC_PadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)cUC_PgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)cUC_PgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)cUC_PgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)cUC_PgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)cUC_PgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)cUC_PgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)cUC_PgetCPUType;


/**
 App ID
 */
+ (NSString *)cUC_PgetAppID;


/**
 Bundle ID
 */
+ (NSString *)cUC_PgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)cUC_PgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)cUC_PgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)cUC_PgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)cUC_PgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)cUC_PgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)cUC_PisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)cUC_PgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
