//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class CUC_PNcsStEntry29Maker;
@class CUC_PNcsStEntry29;

typedef CUC_PNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef CUC_PNcsStEntry29 *(^DotMake29)(void);

@interface CUC_PNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
