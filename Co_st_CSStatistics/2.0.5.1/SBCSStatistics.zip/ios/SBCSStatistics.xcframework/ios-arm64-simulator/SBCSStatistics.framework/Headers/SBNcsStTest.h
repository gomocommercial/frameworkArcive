//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface SBNcsStTest : NSObject

+(void)sBtest;

+(void)sBtestOld;

@end
