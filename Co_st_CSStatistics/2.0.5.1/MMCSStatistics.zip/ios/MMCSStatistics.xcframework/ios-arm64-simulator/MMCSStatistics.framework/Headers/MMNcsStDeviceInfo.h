//
//  MMNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface MMNcsStDeviceInfo : NSObject

+ (NSDictionary *)mMdevice;

+ (NSDictionary *)mMdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)mMUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)mMadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)mMgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)mMgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)mMgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)mMgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)mMgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)mMgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)mMgetCPUType;


/**
 App ID
 */
+ (NSString *)mMgetAppID;


/**
 Bundle ID
 */
+ (NSString *)mMgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)mMgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)mMgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)mMgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)mMgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)mMgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)mMisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)mMgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
