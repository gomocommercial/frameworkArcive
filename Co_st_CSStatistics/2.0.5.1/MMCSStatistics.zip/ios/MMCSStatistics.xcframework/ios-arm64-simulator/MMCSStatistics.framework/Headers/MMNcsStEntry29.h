//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>
#import "MMNcsStEntryData.h"

/**
 * 29协议：GOPUSH推送
 */
@interface MMNcsStEntry29 : MMNcsStEntryData

/**
 * 字段11：token
 */
@property (strong, nonatomic) NSString* token;

@end
