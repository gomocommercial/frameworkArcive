//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>
#import "ARNcsStEntryData.h"

/**
 * 29协议：GOPUSH推送
 */
@interface ARNcsStEntry29 : ARNcsStEntryData

/**
 * 字段11：token
 */
@property (strong, nonatomic) NSString* token;

@end
