//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "JPNcsStEntryData.h"

/**
 * 104协议：非实时统计，格式与103一致
 * http://wiki.3g.net.cn/pages/viewpage.action?pageId=18776101
 */
@interface JPNcsStEntry28 : JPNcsStEntryData

/**
 * 13:firebase实例ID appInstanceId
 */
@property (strong, nonatomic) NSString* firebaseInstanceId;

/**
 * 15:firebaseToken
 */
@property (strong, nonatomic) NSString* firebaseToken;

/**
 * 17:自定义主题信息，多个用英文逗号分隔
 */
@property (strong, nonatomic) NSString* customInfo;

/**
 * 18:firebase版本号
 */
@property (strong, nonatomic) NSString* firebaseVersion;

@end
