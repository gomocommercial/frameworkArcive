//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class TIVNcsStEntry29Maker;
@class TIVNcsStEntry29;

typedef TIVNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef TIVNcsStEntry29 *(^DotMake29)(void);

@interface TIVNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
