//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "TIVNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface TIVNcsStEntry105 : TIVNcsStEntry103


@end
