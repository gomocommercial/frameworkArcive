//
//  TIVNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface TIVNcsStDeviceInfo : NSObject

+ (NSDictionary *)tIVdevice;

+ (NSDictionary *)tIVdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)tIVUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)tIVadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)tIVgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)tIVgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)tIVgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)tIVgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)tIVgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)tIVgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)tIVgetCPUType;


/**
 App ID
 */
+ (NSString *)tIVgetAppID;


/**
 Bundle ID
 */
+ (NSString *)tIVgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)tIVgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)tIVgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)tIVgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)tIVgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)tIVgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)tIVisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)tIVgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
