//
//  FSLGNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface FSLGNcsStDeviceInfo : NSObject

+ (NSDictionary *)fSLGdevice;

+ (NSDictionary *)fSLGdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)fSLGUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)fSLGadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)fSLGgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)fSLGgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)fSLGgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)fSLGgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)fSLGgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)fSLGgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)fSLGgetCPUType;


/**
 App ID
 */
+ (NSString *)fSLGgetAppID;


/**
 Bundle ID
 */
+ (NSString *)fSLGgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)fSLGgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)fSLGgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)fSLGgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)fSLGgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)fSLGgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)fSLGisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)fSLGgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
