//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface CHTRNcsStTest : NSObject

+(void)cHTRtest;

+(void)cHTRtestOld;

@end
