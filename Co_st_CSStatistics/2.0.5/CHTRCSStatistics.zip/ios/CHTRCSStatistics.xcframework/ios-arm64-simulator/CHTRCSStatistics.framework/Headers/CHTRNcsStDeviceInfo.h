//
//  CHTRNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface CHTRNcsStDeviceInfo : NSObject

+ (NSDictionary *)cHTRdevice;

+ (NSDictionary *)cHTRdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)cHTRUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)cHTRadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)cHTRgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)cHTRgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)cHTRgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)cHTRgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)cHTRgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)cHTRgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)cHTRgetCPUType;


/**
 App ID
 */
+ (NSString *)cHTRgetAppID;


/**
 Bundle ID
 */
+ (NSString *)cHTRgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)cHTRgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)cHTRgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)cHTRgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)cHTRgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)cHTRgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)cHTRisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)cHTRgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
