//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface CFXNcsStTest : NSObject

+(void)cFXtest;

+(void)cFXtestOld;

@end
