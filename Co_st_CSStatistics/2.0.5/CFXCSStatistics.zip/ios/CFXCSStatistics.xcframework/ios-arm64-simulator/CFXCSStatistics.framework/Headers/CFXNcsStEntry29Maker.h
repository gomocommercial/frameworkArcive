//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class CFXNcsStEntry29Maker;
@class CFXNcsStEntry29;

typedef CFXNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef CFXNcsStEntry29 *(^DotMake29)(void);

@interface CFXNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
