//
//  CFXNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface CFXNcsStDeviceInfo : NSObject

+ (NSDictionary *)cFXdevice;

+ (NSDictionary *)cFXdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)cFXUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)cFXadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)cFXgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)cFXgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)cFXgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)cFXgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)cFXgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)cFXgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)cFXgetCPUType;


/**
 App ID
 */
+ (NSString *)cFXgetAppID;


/**
 Bundle ID
 */
+ (NSString *)cFXgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)cFXgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)cFXgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)cFXgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)cFXgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)cFXgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)cFXisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)cFXgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
