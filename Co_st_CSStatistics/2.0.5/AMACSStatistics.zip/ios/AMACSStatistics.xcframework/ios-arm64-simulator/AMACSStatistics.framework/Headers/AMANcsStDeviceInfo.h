//
//  AMANcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface AMANcsStDeviceInfo : NSObject

+ (NSDictionary *)aMAdevice;

+ (NSDictionary *)aMAdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)aMAUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)aMAadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)aMAgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)aMAgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)aMAgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)aMAgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)aMAgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)aMAgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)aMAgetCPUType;


/**
 App ID
 */
+ (NSString *)aMAgetAppID;


/**
 Bundle ID
 */
+ (NSString *)aMAgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)aMAgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)aMAgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)aMAgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)aMAgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)aMAgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)aMAisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)aMAgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
