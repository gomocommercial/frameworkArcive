//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface AMANcsStTest : NSObject

+(void)aMAtest;

+(void)aMAtestOld;

@end
