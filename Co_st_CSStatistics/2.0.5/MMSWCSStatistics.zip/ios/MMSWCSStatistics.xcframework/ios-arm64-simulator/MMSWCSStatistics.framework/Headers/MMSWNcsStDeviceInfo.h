//
//  MMSWNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface MMSWNcsStDeviceInfo : NSObject

+ (NSDictionary *)mMSWdevice;

+ (NSDictionary *)mMSWdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)mMSWUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)mMSWadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)mMSWgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)mMSWgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)mMSWgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)mMSWgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)mMSWgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)mMSWgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)mMSWgetCPUType;


/**
 App ID
 */
+ (NSString *)mMSWgetAppID;


/**
 Bundle ID
 */
+ (NSString *)mMSWgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)mMSWgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)mMSWgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)mMSWgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)mMSWgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)mMSWgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)mMSWisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)mMSWgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
