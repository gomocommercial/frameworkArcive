//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface CNANcsStTest : NSObject

+(void)cNAtest;

+(void)cNAtestOld;

@end
