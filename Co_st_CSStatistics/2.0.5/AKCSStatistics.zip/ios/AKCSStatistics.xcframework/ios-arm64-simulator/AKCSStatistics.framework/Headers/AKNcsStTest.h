//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface AKNcsStTest : NSObject

+(void)aKtest;

+(void)aKtestOld;

@end
