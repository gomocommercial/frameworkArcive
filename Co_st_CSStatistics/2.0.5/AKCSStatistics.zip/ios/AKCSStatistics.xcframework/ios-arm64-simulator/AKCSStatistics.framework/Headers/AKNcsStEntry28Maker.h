//
// Created by matt on 2018-12-28.
//

#import <Foundation/Foundation.h>


@class AKNcsStEntry28Maker;
@class AKNcsStEntry28;

typedef AKNcsStEntry28Maker *(^DotNSString28)(NSString *);
typedef AKNcsStEntry28 *(^DotMake28)(void);

@interface AKNcsStEntry28Maker : NSObject


/**
 * 13:firebase实例ID appInstanceId
 */
@property (strong, nonatomic, readonly) DotNSString28 firebaseInstanceId;

/**
 * 15:firebaseToken
 */
@property (strong, nonatomic, readonly) DotNSString28 firebaseToken;

/**
 * 17:自定义主题信息，多个用英文逗号分隔
 */
@property (strong, nonatomic, readonly) DotNSString28 customInfo;

/**
 * 18:firebase版本号
 */
@property (strong, nonatomic, readonly) DotNSString28 firebaseVersion;

/**
 * 构建NcsStEntry28对象
 */
@property (strong, nonatomic, readonly) DotMake28 make;

@end
