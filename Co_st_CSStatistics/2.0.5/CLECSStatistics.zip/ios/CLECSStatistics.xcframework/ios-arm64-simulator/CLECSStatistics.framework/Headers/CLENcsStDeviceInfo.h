//
//  CLENcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface CLENcsStDeviceInfo : NSObject

+ (NSDictionary *)cLEdevice;

+ (NSDictionary *)cLEdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)cLEUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)cLEadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)cLEgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)cLEgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)cLEgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)cLEgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)cLEgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)cLEgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)cLEgetCPUType;


/**
 App ID
 */
+ (NSString *)cLEgetAppID;


/**
 Bundle ID
 */
+ (NSString *)cLEgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)cLEgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)cLEgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)cLEgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)cLEgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)cLEgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)cLEisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)cLEgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
