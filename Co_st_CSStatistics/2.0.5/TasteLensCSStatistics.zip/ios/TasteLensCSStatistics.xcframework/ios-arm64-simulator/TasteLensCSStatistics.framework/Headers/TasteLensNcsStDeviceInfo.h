//
//  TasteLensNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface TasteLensNcsStDeviceInfo : NSObject

+ (NSDictionary *)tasteLensdevice;

+ (NSDictionary *)tasteLensdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)tasteLensUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)tasteLensadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)tasteLensgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)tasteLensgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)tasteLensgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)tasteLensgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)tasteLensgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)tasteLensgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)tasteLensgetCPUType;


/**
 App ID
 */
+ (NSString *)tasteLensgetAppID;


/**
 Bundle ID
 */
+ (NSString *)tasteLensgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)tasteLensgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)tasteLensgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)tasteLensgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)tasteLensgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)tasteLensgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)tasteLensisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)tasteLensgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
