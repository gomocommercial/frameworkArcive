//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface TasteLensNcsStTest : NSObject

+(void)tasteLenstest;

+(void)tasteLenstestOld;

@end
