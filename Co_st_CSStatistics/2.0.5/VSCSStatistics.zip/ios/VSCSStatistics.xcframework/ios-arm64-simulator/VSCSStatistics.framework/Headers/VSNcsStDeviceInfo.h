//
//  VSNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface VSNcsStDeviceInfo : NSObject

+ (NSDictionary *)vSdevice;

+ (NSDictionary *)vSdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)vSUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)vSadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)vSgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)vSgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)vSgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)vSgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)vSgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)vSgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)vSgetCPUType;


/**
 App ID
 */
+ (NSString *)vSgetAppID;


/**
 Bundle ID
 */
+ (NSString *)vSgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)vSgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)vSgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)vSgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)vSgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)vSgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)vSisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)vSgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
