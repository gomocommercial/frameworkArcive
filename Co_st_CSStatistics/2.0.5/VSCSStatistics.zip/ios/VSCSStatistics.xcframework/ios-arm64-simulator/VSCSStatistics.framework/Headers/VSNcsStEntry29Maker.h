//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class VSNcsStEntry29Maker;
@class VSNcsStEntry29;

typedef VSNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef VSNcsStEntry29 *(^DotMake29)(void);

@interface VSNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
