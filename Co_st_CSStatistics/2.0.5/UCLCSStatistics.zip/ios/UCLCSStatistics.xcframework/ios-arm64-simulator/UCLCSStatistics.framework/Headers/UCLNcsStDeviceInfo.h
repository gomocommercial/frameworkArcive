//
//  UCLNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface UCLNcsStDeviceInfo : NSObject

+ (NSDictionary *)uCLdevice;

+ (NSDictionary *)uCLdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)uCLUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)uCLadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)uCLgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)uCLgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)uCLgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)uCLgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)uCLgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)uCLgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)uCLgetCPUType;


/**
 App ID
 */
+ (NSString *)uCLgetAppID;


/**
 Bundle ID
 */
+ (NSString *)uCLgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)uCLgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)uCLgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)uCLgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)uCLgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)uCLgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)uCLisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)uCLgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
