//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface UCLNcsStTest : NSObject

+(void)uCLtest;

+(void)uCLtestOld;

@end
