//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface MoveCashNcsStTest : NSObject

+(void)moveCashtest;

+(void)moveCashtestOld;

@end
