//
//  MoveCashNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface MoveCashNcsStDeviceInfo : NSObject

+ (NSDictionary *)moveCashdevice;

+ (NSDictionary *)moveCashdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)moveCashUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)moveCashadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)moveCashgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)moveCashgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)moveCashgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)moveCashgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)moveCashgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)moveCashgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)moveCashgetCPUType;


/**
 App ID
 */
+ (NSString *)moveCashgetAppID;


/**
 Bundle ID
 */
+ (NSString *)moveCashgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)moveCashgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)moveCashgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)moveCashgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)moveCashgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)moveCashgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)moveCashisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)moveCashgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
