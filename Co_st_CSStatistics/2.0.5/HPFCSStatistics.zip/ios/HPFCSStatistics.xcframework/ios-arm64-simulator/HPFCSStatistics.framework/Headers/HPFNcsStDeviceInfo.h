//
//  HPFNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface HPFNcsStDeviceInfo : NSObject

+ (NSDictionary *)hPFdevice;

+ (NSDictionary *)hPFdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)hPFUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)hPFadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)hPFgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)hPFgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)hPFgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)hPFgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)hPFgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)hPFgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)hPFgetCPUType;


/**
 App ID
 */
+ (NSString *)hPFgetAppID;


/**
 Bundle ID
 */
+ (NSString *)hPFgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)hPFgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)hPFgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)hPFgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)hPFgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)hPFgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)hPFisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)hPFgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
