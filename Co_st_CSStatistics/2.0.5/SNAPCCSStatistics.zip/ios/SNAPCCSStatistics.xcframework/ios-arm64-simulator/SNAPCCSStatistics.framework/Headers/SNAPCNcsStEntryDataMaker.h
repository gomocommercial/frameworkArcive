//
// Created by matt on 2019-01-17.
//

#import <Foundation/Foundation.h>
#import "SNAPCNcsStEntryData.h"

@class SNAPCNcsStEntryDataMaker;
@class SNAPCNcsStEntryData;

typedef SNAPCNcsStEntryDataMaker *(^DotNSStringBase)(NSString *);
typedef SNAPCNcsStEntryDataMaker *(^DotBoolBase)(BOOL);
typedef SNAPCNcsStEntryDataMaker *(^DotPriorityBase)(NcsPriority);
typedef SNAPCNcsStEntryDataMaker *(^DotCallbackBase)(NcsStUploadCallback);
typedef SNAPCNcsStEntryData *(^DotMakeBase)();


@interface SNAPCNcsStEntryDataMaker : NSObject

/**
 * 上传的完整数据
 */
@property (strong, nonatomic, readonly) DotNSStringBase data;

/**
 * 协议id
 */
@property (strong, nonatomic, readonly) DotNSStringBase protocalId;

/**
 * 优先级，优先级高的先传
 */
@property (strong, nonatomic, readonly) DotPriorityBase priority;

/**
 * 是否独立上传(不参与拼接)，默认NO
 */
@property (strong, nonatomic, readonly) DotBoolBase uploadSeperately;

/**
 * 上传callback，如果应用重启恢复重传，则这个参数会丢失。
 */
@property (strong, nonatomic, readonly) DotCallbackBase callback;

/**
 * 构建NcsStEntryData对象
 */
@property (strong, nonatomic, readonly) DotMakeBase make;

@end
