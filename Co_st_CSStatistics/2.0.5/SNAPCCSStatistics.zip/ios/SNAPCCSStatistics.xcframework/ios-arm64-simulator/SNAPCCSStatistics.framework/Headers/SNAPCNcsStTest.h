//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface SNAPCNcsStTest : NSObject

+(void)sNAPCtest;

+(void)sNAPCtestOld;

@end
