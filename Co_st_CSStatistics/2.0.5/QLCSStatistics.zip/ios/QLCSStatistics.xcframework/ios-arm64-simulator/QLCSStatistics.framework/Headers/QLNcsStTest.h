//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface QLNcsStTest : NSObject

+(void)qLtest;

+(void)qLtestOld;

@end
