//
//  QLNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface QLNcsStDeviceInfo : NSObject

+ (NSDictionary *)qLdevice;

+ (NSDictionary *)qLdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)qLUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)qLadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)qLgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)qLgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)qLgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)qLgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)qLgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)qLgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)qLgetCPUType;


/**
 App ID
 */
+ (NSString *)qLgetAppID;


/**
 Bundle ID
 */
+ (NSString *)qLgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)qLgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)qLgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)qLgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)qLgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)qLgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)qLisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)qLgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
