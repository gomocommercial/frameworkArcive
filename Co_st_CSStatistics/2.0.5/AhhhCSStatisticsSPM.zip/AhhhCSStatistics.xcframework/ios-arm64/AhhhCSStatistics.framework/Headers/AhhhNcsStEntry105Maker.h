//
// Created by matt on 2018-12-28.
//

#import <Foundation/Foundation.h>
#import "AhhhNcsStEntry105Maker.h"

@class AhhhNcsStEntry105Maker;
@class AhhhNcsStEntry105;

typedef AhhhNcsStEntry105Maker *(^DotNSString105)(NSString *);
typedef AhhhNcsStEntry105 *(^DotMake105)();

@interface AhhhNcsStEntry105Maker : NSObject

/**
 * 15:功能点ID
 */
@property (strong, nonatomic, readonly) DotNSString105 functionId;

/**
 * 16:统计对象
 */
@property (strong, nonatomic, readonly) DotNSString105 statisticsObject;

/**
 * 17:操作代码
 */
@property (strong, nonatomic, readonly) DotNSString105 operationCode;

/**
 * 18:操作结果
 */
@property (strong, nonatomic, readonly) DotNSString105 operationResult;

/**
 * 19:入口
 */
@property (strong, nonatomic, readonly) DotNSString105 entrance;

/**
 * 20:Tab分类
 */
@property (strong, nonatomic, readonly) DotNSString105 tabCategory;

/**
 * 21:位置
 */
@property (strong, nonatomic, readonly) DotNSString105 position;

/**
 * 22:关联对象
 */
@property (strong, nonatomic, readonly) DotNSString105 associationObject;

/**
 * 23:广告ID
 */
@property (strong, nonatomic, readonly) DotNSString105 advertId;

/**
 * 24:备注
 */
@property (strong, nonatomic, readonly) DotNSString105 remark;

/**
 * 构建NcsStEntry105对象
 */
@property (strong, nonatomic, readonly) DotMake105 make;

@end
