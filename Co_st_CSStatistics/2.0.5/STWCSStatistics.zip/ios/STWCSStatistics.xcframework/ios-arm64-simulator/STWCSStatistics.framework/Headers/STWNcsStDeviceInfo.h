//
//  STWNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface STWNcsStDeviceInfo : NSObject

+ (NSDictionary *)sTWdevice;

+ (NSDictionary *)sTWdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)sTWUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)sTWadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)sTWgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)sTWgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)sTWgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)sTWgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)sTWgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)sTWgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)sTWgetCPUType;


/**
 App ID
 */
+ (NSString *)sTWgetAppID;


/**
 Bundle ID
 */
+ (NSString *)sTWgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)sTWgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)sTWgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)sTWgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)sTWgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)sTWgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)sTWisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)sTWgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
