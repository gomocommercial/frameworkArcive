//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface DCNcsStTest : NSObject

+(void)dCtest;

+(void)dCtestOld;

@end
