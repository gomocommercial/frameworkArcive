//
//  DCNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface DCNcsStDeviceInfo : NSObject

+ (NSDictionary *)dCdevice;

+ (NSDictionary *)dCdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)dCUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)dCadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)dCgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)dCgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)dCgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)dCgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)dCgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)dCgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)dCgetCPUType;


/**
 App ID
 */
+ (NSString *)dCgetAppID;


/**
 Bundle ID
 */
+ (NSString *)dCgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)dCgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)dCgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)dCgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)dCgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)dCgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)dCisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)dCgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
