//
//  JPNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface JPNcsStDeviceInfo : NSObject

+ (NSDictionary *)jPdevice;

+ (NSDictionary *)jPdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)jPUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)jPadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)jPgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)jPgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)jPgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)jPgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)jPgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)jPgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)jPgetCPUType;


/**
 App ID
 */
+ (NSString *)jPgetAppID;


/**
 Bundle ID
 */
+ (NSString *)jPgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)jPgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)jPgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)jPgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)jPgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)jPgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)jPisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)jPgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
