//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface FurTalesNcsStTest : NSObject

+(void)furTalestest;

+(void)furTalestestOld;

@end
