//
//  FurTalesNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface FurTalesNcsStDeviceInfo : NSObject

+ (NSDictionary *)furTalesdevice;

+ (NSDictionary *)furTalesdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)furTalesUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)furTalesadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)furTalesgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)furTalesgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)furTalesgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)furTalesgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)furTalesgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)furTalesgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)furTalesgetCPUType;


/**
 App ID
 */
+ (NSString *)furTalesgetAppID;


/**
 Bundle ID
 */
+ (NSString *)furTalesgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)furTalesgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)furTalesgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)furTalesgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)furTalesgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)furTalesgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)furTalesisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)furTalesgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
