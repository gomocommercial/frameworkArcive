//
//  PaceCashNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PaceCashNcsStDeviceInfo : NSObject

+ (NSDictionary *)paceCashdevice;

+ (NSDictionary *)paceCashdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)paceCashUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)paceCashadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)paceCashgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)paceCashgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)paceCashgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)paceCashgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)paceCashgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)paceCashgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)paceCashgetCPUType;


/**
 App ID
 */
+ (NSString *)paceCashgetAppID;


/**
 Bundle ID
 */
+ (NSString *)paceCashgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)paceCashgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)paceCashgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)paceCashgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)paceCashgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)paceCashgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)paceCashisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)paceCashgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
