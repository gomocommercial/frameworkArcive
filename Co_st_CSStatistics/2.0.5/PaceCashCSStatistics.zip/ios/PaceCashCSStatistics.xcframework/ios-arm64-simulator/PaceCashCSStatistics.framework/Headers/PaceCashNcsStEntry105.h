//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "PaceCashNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface PaceCashNcsStEntry105 : PaceCashNcsStEntry103


@end
