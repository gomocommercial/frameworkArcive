//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface PaceCashNcsStTest : NSObject

+(void)paceCashtest;

+(void)paceCashtestOld;

@end
