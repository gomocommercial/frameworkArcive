//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface SBCNcsStTest : NSObject

+(void)sBCtest;

+(void)sBCtestOld;

@end
