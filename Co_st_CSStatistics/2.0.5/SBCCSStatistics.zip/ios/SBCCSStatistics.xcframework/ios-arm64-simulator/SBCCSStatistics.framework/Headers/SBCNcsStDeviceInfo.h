//
//  SBCNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface SBCNcsStDeviceInfo : NSObject

+ (NSDictionary *)sBCdevice;

+ (NSDictionary *)sBCdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)sBCUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)sBCadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)sBCgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)sBCgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)sBCgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)sBCgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)sBCgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)sBCgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)sBCgetCPUType;


/**
 App ID
 */
+ (NSString *)sBCgetAppID;


/**
 Bundle ID
 */
+ (NSString *)sBCgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)sBCgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)sBCgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)sBCgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)sBCgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)sBCgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)sBCisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)sBCgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
