//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "SBCNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface SBCNcsStEntry105 : SBCNcsStEntry103


@end
