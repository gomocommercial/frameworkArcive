//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface StepWisdomNcsStTest : NSObject

+(void)stepWisdomtest;

+(void)stepWisdomtestOld;

@end
