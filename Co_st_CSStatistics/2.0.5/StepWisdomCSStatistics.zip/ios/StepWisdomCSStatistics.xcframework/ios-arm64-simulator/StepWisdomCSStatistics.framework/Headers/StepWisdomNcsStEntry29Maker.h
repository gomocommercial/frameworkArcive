//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class StepWisdomNcsStEntry29Maker;
@class StepWisdomNcsStEntry29;

typedef StepWisdomNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef StepWisdomNcsStEntry29 *(^DotMake29)(void);

@interface StepWisdomNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
