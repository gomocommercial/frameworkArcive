//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class STPBNcsStEntry29Maker;
@class STPBNcsStEntry29;

typedef STPBNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef STPBNcsStEntry29 *(^DotMake29)(void);

@interface STPBNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
