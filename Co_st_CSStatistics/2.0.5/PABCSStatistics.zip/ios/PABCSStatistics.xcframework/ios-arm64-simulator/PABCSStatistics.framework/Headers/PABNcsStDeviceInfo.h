//
//  PABNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PABNcsStDeviceInfo : NSObject

+ (NSDictionary *)pABdevice;

+ (NSDictionary *)pABdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pABUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pABadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pABgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pABgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pABgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pABgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pABgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pABgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pABgetCPUType;


/**
 App ID
 */
+ (NSString *)pABgetAppID;


/**
 Bundle ID
 */
+ (NSString *)pABgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)pABgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pABgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pABgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pABgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pABgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pABisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pABgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
