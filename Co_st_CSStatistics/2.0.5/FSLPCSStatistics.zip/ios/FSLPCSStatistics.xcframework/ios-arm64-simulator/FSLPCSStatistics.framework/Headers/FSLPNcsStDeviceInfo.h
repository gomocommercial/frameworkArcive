//
//  FSLPNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface FSLPNcsStDeviceInfo : NSObject

+ (NSDictionary *)fSLPdevice;

+ (NSDictionary *)fSLPdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)fSLPUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)fSLPadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)fSLPgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)fSLPgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)fSLPgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)fSLPgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)fSLPgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)fSLPgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)fSLPgetCPUType;


/**
 App ID
 */
+ (NSString *)fSLPgetAppID;


/**
 Bundle ID
 */
+ (NSString *)fSLPgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)fSLPgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)fSLPgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)fSLPgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)fSLPgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)fSLPgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)fSLPisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)fSLPgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
