//
//  STEPTNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface STEPTNcsStDeviceInfo : NSObject

+ (NSDictionary *)sTEPTdevice;

+ (NSDictionary *)sTEPTdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)sTEPTUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)sTEPTadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)sTEPTgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)sTEPTgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)sTEPTgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)sTEPTgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)sTEPTgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)sTEPTgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)sTEPTgetCPUType;


/**
 App ID
 */
+ (NSString *)sTEPTgetAppID;


/**
 Bundle ID
 */
+ (NSString *)sTEPTgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)sTEPTgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)sTEPTgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)sTEPTgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)sTEPTgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)sTEPTgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)sTEPTisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)sTEPTgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
