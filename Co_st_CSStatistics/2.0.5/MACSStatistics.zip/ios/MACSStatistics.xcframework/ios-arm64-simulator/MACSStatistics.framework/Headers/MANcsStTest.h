//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface MANcsStTest : NSObject

+(void)mAtest;

+(void)mAtestOld;

@end
