//
//  MANcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface MANcsStDeviceInfo : NSObject

+ (NSDictionary *)mAdevice;

+ (NSDictionary *)mAdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)mAUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)mAadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)mAgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)mAgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)mAgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)mAgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)mAgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)mAgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)mAgetCPUType;


/**
 App ID
 */
+ (NSString *)mAgetAppID;


/**
 Bundle ID
 */
+ (NSString *)mAgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)mAgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)mAgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)mAgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)mAgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)mAgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)mAisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)mAgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
