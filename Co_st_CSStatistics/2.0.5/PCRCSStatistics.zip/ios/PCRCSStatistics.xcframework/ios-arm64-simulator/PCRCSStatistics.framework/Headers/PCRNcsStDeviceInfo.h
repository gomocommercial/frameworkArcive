//
//  PCRNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PCRNcsStDeviceInfo : NSObject

+ (NSDictionary *)pCRdevice;

+ (NSDictionary *)pCRdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pCRUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pCRadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pCRgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pCRgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pCRgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pCRgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pCRgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pCRgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pCRgetCPUType;


/**
 App ID
 */
+ (NSString *)pCRgetAppID;


/**
 Bundle ID
 */
+ (NSString *)pCRgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)pCRgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pCRgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pCRgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pCRgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pCRgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pCRisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pCRgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
