//
//  CWNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface CWNcsStDeviceInfo : NSObject

+ (NSDictionary *)cWdevice;

+ (NSDictionary *)cWdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)cWUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)cWadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)cWgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)cWgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)cWgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)cWgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)cWgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)cWgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)cWgetCPUType;


/**
 App ID
 */
+ (NSString *)cWgetAppID;


/**
 Bundle ID
 */
+ (NSString *)cWgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)cWgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)cWgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)cWgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)cWgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)cWgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)cWisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)cWgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
