//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "TANcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface TANcsStEntry105 : TANcsStEntry103


@end
