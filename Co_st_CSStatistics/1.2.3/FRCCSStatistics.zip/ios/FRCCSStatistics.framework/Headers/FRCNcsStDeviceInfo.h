//
//  FRCNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface FRCNcsStDeviceInfo : NSObject

+ (NSDictionary *)fRCdevice;

+ (NSDictionary *)fRCdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)fRCUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)fRCadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)fRCgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)fRCgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)fRCgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)fRCgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)fRCgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)fRCgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)fRCgetCPUType;


/**
 App ID
 */
+ (NSString *)fRCgetAppID;


/**
 Bundle ID
 */
+ (NSString *)fRCgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)fRCgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)fRCgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)fRCgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)fRCgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)fRCgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)fRCisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)fRCgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
