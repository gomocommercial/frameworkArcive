//
//  LECNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface LECNcsStDeviceInfo : NSObject

+ (NSDictionary *)lECdevice;

+ (NSDictionary *)lECdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)lECUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)lECadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)lECgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)lECgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)lECgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)lECgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)lECgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)lECgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)lECgetCPUType;


/**
 App ID
 */
+ (NSString *)lECgetAppID;


/**
 Bundle ID
 */
+ (NSString *)lECgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)lECgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)lECgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)lECgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)lECgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)lECgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)lECisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)lECgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
