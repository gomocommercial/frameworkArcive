//
// Created by matt on 2019-01-02.
//

#import <Foundation/Foundation.h>


@class PPNcsStEntry19Maker;
@class PPNcsStEntry19;

typedef PPNcsStEntry19Maker *(^DotNSString19)(NSString *);
typedef PPNcsStEntry19 *(^DotMake19)(void);
typedef PPNcsStEntry19Maker *(^DotBool19)(BOOL);
typedef PPNcsStEntry19Maker *(^DotDouble19)(double);

@interface PPNcsStEntry19Maker : NSObject


/**
 * 字段21：来源
 */
@property (strong, nonatomic, readonly) DotNSString19 originalLogo;

/**
 * 字段22：真版标识
 */
@property (strong, nonatomic, readonly) DotNSString19 genuineKey;

/**
 * 字段26：IDFA
 */
@property (strong, nonatomic, readonly) DotNSString19 idfa;

/**
 * 构建NcsStEntry19对象
 */
@property (strong, nonatomic, readonly) DotMake19 make;

/// 是否活跃
@property (strong, nonatomic, readonly) DotBool19 isActivity;


/// 总时长，单位秒
@property (strong, nonatomic, readonly) DotDouble19 time;
@end
