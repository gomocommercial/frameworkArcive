//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface ATNcsStTest : NSObject

+(void)aTtest;

+(void)aTtestOld;

@end
