//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface BCNcsStTest : NSObject

+(void)bCtest;

+(void)bCtestOld;

@end
