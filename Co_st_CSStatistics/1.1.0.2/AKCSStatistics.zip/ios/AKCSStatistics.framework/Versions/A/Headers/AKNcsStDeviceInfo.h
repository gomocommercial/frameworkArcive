//
//  AKNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AKNcsStDeviceInfo : NSObject

+ (NSDictionary *)aKdevice;

+ (NSDictionary *)aKdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)aKUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)aKadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)aKgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)aKgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)aKgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)aKgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)aKgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)aKgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)aKgetCPUType;


/**
 App ID
 */
+ (NSString *)aKgetAppID;


/**
 Bundle ID
 */
+ (NSString *)aKgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)aKgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)aKgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)aKgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)aKgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)aKgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)aKisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)aKgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
