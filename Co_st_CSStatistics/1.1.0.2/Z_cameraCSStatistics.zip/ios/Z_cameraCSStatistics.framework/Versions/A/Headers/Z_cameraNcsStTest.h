//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Z_cameraNcsStTest : NSObject

+(void)z_cameratest;

+(void)z_cameratestOld;

@end
