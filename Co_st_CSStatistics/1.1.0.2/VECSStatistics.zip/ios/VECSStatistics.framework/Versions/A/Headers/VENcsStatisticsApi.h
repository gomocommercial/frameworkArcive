//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "VENcsStEntryData.h"

@class VENcsStInitParams;
@class VENcsStInitParamsMaker;
@class VENcsStEntryDataMaker;
@class VENcsStEntry103Maker;
@class VENcsStEntry19Maker;
@class VENcsStEntry45Maker;
@class VENcsStEntry59Maker;
@class VENcsStEntry101Maker;
@class VENcsStEntry102Maker;
@class VENcsStEntry104Maker;
@class VENcsStEntry105Maker;

NS_ASSUME_NONNULL_BEGIN

@interface VENcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)vEsetup:(VENcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)vEsetupByBlock:(void(^)(VENcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * @return
 */
+ (VENcsStInitParams *)vEgetCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/

/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)vEupload:(VENcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)vEuploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)vEuploadCustom:(void(^)(VENcsStEntryDataMaker *maker)) block;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)vEupload19:(void(^)(VENcsStEntry19Maker *maker)) block;

/**
 * 上传45协议
 * @param block
 */
+ (void)vEupload45:(void(^)(VENcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)vEupload59:(void(^)(VENcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)vEupload101:(void(^)(VENcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)vEupload102:(void(^)(VENcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)vEupload103:(void(^)(VENcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)vEupload104:(void(^)(VENcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)vEupload105:(void(^)(VENcsStEntry105Maker *maker)) block;


@end

NS_ASSUME_NONNULL_END
