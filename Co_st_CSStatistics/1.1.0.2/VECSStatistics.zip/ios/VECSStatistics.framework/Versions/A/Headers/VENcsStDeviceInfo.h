//
//  VENcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VENcsStDeviceInfo : NSObject

+ (NSDictionary *)vEdevice;

+ (NSDictionary *)vEdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)vEUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)vEadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)vEgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)vEgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)vEgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)vEgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)vEgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)vEgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)vEgetCPUType;


/**
 App ID
 */
+ (NSString *)vEgetAppID;


/**
 Bundle ID
 */
+ (NSString *)vEgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)vEgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)vEgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)vEgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)vEgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)vEgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)vEisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)vEgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
