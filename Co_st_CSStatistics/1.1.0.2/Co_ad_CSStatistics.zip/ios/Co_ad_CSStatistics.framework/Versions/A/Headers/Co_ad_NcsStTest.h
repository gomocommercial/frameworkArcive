//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Co_ad_NcsStTest : NSObject

+(void)co_ad_test;

+(void)co_ad_testOld;

@end
