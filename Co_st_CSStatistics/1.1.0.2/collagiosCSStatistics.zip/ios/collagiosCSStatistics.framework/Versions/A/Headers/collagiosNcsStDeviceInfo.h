//
//  collagiosNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface collagiosNcsStDeviceInfo : NSObject

+ (NSDictionary *)collagiosdevice;

+ (NSDictionary *)collagiosdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)collagiosUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)collagiosadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)collagiosgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)collagiosgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)collagiosgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)collagiosgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)collagiosgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)collagiosgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)collagiosgetCPUType;


/**
 App ID
 */
+ (NSString *)collagiosgetAppID;


/**
 Bundle ID
 */
+ (NSString *)collagiosgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)collagiosgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)collagiosgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)collagiosgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)collagiosgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)collagiosgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)collagiosisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)collagiosgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
