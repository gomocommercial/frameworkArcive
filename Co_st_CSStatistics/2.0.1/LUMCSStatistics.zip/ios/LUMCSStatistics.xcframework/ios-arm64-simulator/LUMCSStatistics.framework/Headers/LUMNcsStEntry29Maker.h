//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class LUMNcsStEntry29Maker;
@class LUMNcsStEntry29;

typedef LUMNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef LUMNcsStEntry29 *(^DotMake29)(void);

@interface LUMNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
