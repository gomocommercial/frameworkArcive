//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface GACNcsStTest : NSObject

+(void)gACtest;

+(void)gACtestOld;

@end
