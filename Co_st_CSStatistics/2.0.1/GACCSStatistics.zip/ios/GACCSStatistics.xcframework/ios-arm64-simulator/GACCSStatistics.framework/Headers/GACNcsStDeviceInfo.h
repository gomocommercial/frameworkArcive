//
//  GACNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface GACNcsStDeviceInfo : NSObject

+ (NSDictionary *)gACdevice;

+ (NSDictionary *)gACdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)gACUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)gACadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)gACgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)gACgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)gACgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)gACgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)gACgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)gACgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)gACgetCPUType;


/**
 App ID
 */
+ (NSString *)gACgetAppID;


/**
 Bundle ID
 */
+ (NSString *)gACgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)gACgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)gACgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)gACgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)gACgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)gACgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)gACisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)gACgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
