//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "AhhhNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface AhhhNcsStEntry105 : AhhhNcsStEntry103


@end
