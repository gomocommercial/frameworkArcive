//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface AhhhNcsStTest : NSObject

+(void)ahhhtest;

+(void)ahhhtestOld;

@end
