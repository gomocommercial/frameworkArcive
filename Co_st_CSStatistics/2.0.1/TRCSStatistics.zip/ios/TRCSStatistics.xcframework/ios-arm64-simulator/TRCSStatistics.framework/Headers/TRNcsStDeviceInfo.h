//
//  TRNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface TRNcsStDeviceInfo : NSObject

+ (NSDictionary *)tRdevice;

+ (NSDictionary *)tRdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)tRUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)tRadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)tRgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)tRgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)tRgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)tRgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)tRgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)tRgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)tRgetCPUType;


/**
 App ID
 */
+ (NSString *)tRgetAppID;


/**
 Bundle ID
 */
+ (NSString *)tRgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)tRgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)tRgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)tRgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)tRgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)tRgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)tRisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)tRgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
