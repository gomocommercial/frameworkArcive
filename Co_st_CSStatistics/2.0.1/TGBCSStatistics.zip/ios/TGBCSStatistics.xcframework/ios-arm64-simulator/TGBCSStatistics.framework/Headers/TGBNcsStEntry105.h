//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "TGBNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface TGBNcsStEntry105 : TGBNcsStEntry103


@end
