//
//  TGBNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface TGBNcsStDeviceInfo : NSObject

+ (NSDictionary *)tGBdevice;

+ (NSDictionary *)tGBdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)tGBUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)tGBadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)tGBgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)tGBgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)tGBgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)tGBgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)tGBgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)tGBgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)tGBgetCPUType;


/**
 App ID
 */
+ (NSString *)tGBgetAppID;


/**
 Bundle ID
 */
+ (NSString *)tGBgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)tGBgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)tGBgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)tGBgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)tGBgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)tGBgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)tGBisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)tGBgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
