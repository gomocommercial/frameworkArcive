//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface TGBNcsStTest : NSObject

+(void)tGBtest;

+(void)tGBtestOld;

@end
