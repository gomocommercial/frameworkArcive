//
//  MTNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface MTNcsStDeviceInfo : NSObject

+ (NSDictionary *)mTdevice;

+ (NSDictionary *)mTdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)mTUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)mTadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)mTgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)mTgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)mTgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)mTgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)mTgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)mTgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)mTgetCPUType;


/**
 App ID
 */
+ (NSString *)mTgetAppID;


/**
 Bundle ID
 */
+ (NSString *)mTgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)mTgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)mTgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)mTgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)mTgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)mTgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)mTisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)mTgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
