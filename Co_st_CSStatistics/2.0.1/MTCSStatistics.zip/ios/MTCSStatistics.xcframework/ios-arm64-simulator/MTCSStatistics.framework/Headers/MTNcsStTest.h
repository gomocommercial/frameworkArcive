//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface MTNcsStTest : NSObject

+(void)mTtest;

+(void)mTtestOld;

@end
