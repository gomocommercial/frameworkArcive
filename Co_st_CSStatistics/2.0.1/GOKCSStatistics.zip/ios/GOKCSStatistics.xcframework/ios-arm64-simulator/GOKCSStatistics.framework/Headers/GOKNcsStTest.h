//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface GOKNcsStTest : NSObject

+(void)gOKtest;

+(void)gOKtestOld;

@end
