//
//  GOKNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface GOKNcsStDeviceInfo : NSObject

+ (NSDictionary *)gOKdevice;

+ (NSDictionary *)gOKdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)gOKUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)gOKadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)gOKgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)gOKgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)gOKgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)gOKgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)gOKgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)gOKgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)gOKgetCPUType;


/**
 App ID
 */
+ (NSString *)gOKgetAppID;


/**
 Bundle ID
 */
+ (NSString *)gOKgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)gOKgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)gOKgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)gOKgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)gOKgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)gOKgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)gOKisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)gOKgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
