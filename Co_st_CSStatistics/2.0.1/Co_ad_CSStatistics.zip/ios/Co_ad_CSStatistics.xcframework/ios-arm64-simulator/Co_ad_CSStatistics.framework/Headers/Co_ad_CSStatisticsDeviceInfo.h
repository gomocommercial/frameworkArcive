//
//  CSDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Co_ad_NcsStDeviceInfo.h"

__attribute__((deprecated("use Class NcsStEntryFieldUtil instead")))
@interface Co_ad_CSStatisticsDeviceInfo : Co_ad_NcsStDeviceInfo

@end
