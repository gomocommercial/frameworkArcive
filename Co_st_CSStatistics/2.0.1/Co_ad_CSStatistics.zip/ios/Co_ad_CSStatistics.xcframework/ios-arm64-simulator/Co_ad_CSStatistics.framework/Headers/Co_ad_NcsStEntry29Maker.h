//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class Co_ad_NcsStEntry29Maker;
@class Co_ad_NcsStEntry29;

typedef Co_ad_NcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef Co_ad_NcsStEntry29 *(^DotMake29)(void);

@interface Co_ad_NcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
