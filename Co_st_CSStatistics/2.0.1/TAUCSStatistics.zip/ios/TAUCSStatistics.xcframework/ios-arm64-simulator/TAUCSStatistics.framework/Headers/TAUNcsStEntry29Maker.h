//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class TAUNcsStEntry29Maker;
@class TAUNcsStEntry29;

typedef TAUNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef TAUNcsStEntry29 *(^DotMake29)(void);

@interface TAUNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
