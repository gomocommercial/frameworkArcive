//
//  PCXNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PCXNcsStDeviceInfo : NSObject

+ (NSDictionary *)pCXdevice;

+ (NSDictionary *)pCXdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pCXUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pCXadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pCXgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pCXgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pCXgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pCXgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pCXgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pCXgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pCXgetCPUType;


/**
 App ID
 */
+ (NSString *)pCXgetAppID;


/**
 Bundle ID
 */
+ (NSString *)pCXgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)pCXgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pCXgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pCXgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pCXgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pCXgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pCXisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pCXgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
