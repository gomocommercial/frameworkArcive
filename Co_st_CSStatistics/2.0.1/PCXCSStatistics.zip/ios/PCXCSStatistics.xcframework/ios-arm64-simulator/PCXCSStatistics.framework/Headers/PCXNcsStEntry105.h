//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "PCXNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface PCXNcsStEntry105 : PCXNcsStEntry103


@end
