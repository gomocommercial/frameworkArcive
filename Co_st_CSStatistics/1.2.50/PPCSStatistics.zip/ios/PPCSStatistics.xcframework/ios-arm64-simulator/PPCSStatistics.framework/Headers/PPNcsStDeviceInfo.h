//
//  PPNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PPNcsStDeviceInfo : NSObject

+ (NSDictionary *)pPdevice;

+ (NSDictionary *)pPdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pPUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pPadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pPgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pPgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pPgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pPgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pPgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pPgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pPgetCPUType;


/**
 App ID
 */
+ (NSString *)pPgetAppID;


/**
 Bundle ID
 */
+ (NSString *)pPgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)pPgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pPgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pPgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pPgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pPgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pPisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pPgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
