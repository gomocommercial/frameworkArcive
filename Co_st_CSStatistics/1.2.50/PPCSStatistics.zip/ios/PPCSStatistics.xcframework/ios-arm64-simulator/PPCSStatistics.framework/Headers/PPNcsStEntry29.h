//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>
#import "PPNcsStEntryData.h"

/**
 * 29协议：GOPUSH推送
 */
@interface PPNcsStEntry29 : PPNcsStEntryData

/**
 * 字段11：token
 */
@property (strong, nonatomic) NSString* token;

@end
