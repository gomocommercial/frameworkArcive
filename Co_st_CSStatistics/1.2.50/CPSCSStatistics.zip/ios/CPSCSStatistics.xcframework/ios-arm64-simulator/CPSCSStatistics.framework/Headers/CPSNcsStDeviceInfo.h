//
//  CPSNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface CPSNcsStDeviceInfo : NSObject

+ (NSDictionary *)cPSdevice;

+ (NSDictionary *)cPSdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)cPSUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)cPSadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)cPSgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)cPSgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)cPSgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)cPSgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)cPSgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)cPSgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)cPSgetCPUType;


/**
 App ID
 */
+ (NSString *)cPSgetAppID;


/**
 Bundle ID
 */
+ (NSString *)cPSgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)cPSgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)cPSgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)cPSgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)cPSgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)cPSgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)cPSisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)cPSgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
