//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface WBNcsStTest : NSObject

+(void)wBtest;

+(void)wBtestOld;

@end
