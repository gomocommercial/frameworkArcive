//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class FSPNcsStEntry29Maker;
@class FSPNcsStEntry29;

typedef FSPNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef FSPNcsStEntry29 *(^DotMake29)(void);

@interface FSPNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
