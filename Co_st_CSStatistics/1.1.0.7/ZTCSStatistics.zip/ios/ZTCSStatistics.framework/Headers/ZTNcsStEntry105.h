//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "ZTNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface ZTNcsStEntry105 : ZTNcsStEntry103


@end
