//
//  LONcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LONcsStDeviceInfo : NSObject

+ (NSDictionary *)lOdevice;

+ (NSDictionary *)lOdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)lOUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)lOadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)lOgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)lOgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)lOgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)lOgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)lOgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)lOgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)lOgetCPUType;


/**
 App ID
 */
+ (NSString *)lOgetAppID;


/**
 Bundle ID
 */
+ (NSString *)lOgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)lOgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)lOgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)lOgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)lOgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)lOgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)lOisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)lOgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
