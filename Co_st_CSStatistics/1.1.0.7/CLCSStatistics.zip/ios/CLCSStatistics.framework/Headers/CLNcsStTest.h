//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface CLNcsStTest : NSObject

+(void)cLtest;

+(void)cLtestOld;

@end
