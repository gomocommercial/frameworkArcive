//
//  FXiosNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FXiosNcsStDeviceInfo : NSObject

+ (NSDictionary *)fXiosdevice;

+ (NSDictionary *)fXiosdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)fXiosUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)fXiosadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)fXiosgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)fXiosgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)fXiosgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)fXiosgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)fXiosgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)fXiosgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)fXiosgetCPUType;


/**
 App ID
 */
+ (NSString *)fXiosgetAppID;


/**
 Bundle ID
 */
+ (NSString *)fXiosgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)fXiosgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)fXiosgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)fXiosgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)fXiosgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)fXiosgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)fXiosisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)fXiosgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
