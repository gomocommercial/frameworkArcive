//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface PZNcsStTest : NSObject

+(void)pZtest;

+(void)pZtestOld;

@end
