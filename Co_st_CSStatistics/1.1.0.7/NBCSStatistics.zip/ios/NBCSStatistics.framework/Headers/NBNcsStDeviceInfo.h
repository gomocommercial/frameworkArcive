//
//  NBNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NBNcsStDeviceInfo : NSObject

+ (NSDictionary *)nBdevice;

+ (NSDictionary *)nBdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)nBUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)nBadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)nBgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)nBgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)nBgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)nBgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)nBgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)nBgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)nBgetCPUType;


/**
 App ID
 */
+ (NSString *)nBgetAppID;


/**
 Bundle ID
 */
+ (NSString *)nBgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)nBgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)nBgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)nBgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)nBgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)nBgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)nBisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)nBgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
