//
// Created by matt on 2019-01-02.
//

#import <Foundation/Foundation.h>


@class NBNcsStEntry19Maker;
@class NBNcsStEntry19;

typedef NBNcsStEntry19Maker *(^DotNSString19)(NSString *);
typedef NBNcsStEntry19 *(^DotMake19)();

@interface NBNcsStEntry19Maker : NSObject


/**
 * 字段21：来源
 */
@property (strong, nonatomic, readonly) DotNSString19 originalLogo;

/**
 * 字段22：真版标识
 */
@property (strong, nonatomic, readonly) DotNSString19 genuineKey;

/**
 * 字段26：IDFA
 */
@property (strong, nonatomic, readonly) DotNSString19 idfa;

/**
 * 构建NcsStEntry19对象
 */
@property (strong, nonatomic, readonly) DotMake19 make;


@end
