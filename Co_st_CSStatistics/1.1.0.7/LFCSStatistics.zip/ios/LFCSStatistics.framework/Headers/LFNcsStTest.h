//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface LFNcsStTest : NSObject

+(void)lFtest;

+(void)lFtestOld;

@end
