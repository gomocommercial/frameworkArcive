//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "RCNcsStEntryData.h"

/**
 * 19协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=6914524
 */
@interface RCNcsStEntry19 : RCNcsStEntryData

/**
 * 字段21：来源
 */
@property (strong, nonatomic) NSString* originalLogo;

/**
 * 字段22：真版标识
 */
@property (strong, nonatomic) NSString* genuineKey;


/**
 * 字段26：IDFA
 */
@property (strong, nonatomic) NSString* idfa;

@end
