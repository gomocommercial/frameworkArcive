//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "Co_bc_NcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface Co_bc_NcsStEntry105 : Co_bc_NcsStEntry103


@end
