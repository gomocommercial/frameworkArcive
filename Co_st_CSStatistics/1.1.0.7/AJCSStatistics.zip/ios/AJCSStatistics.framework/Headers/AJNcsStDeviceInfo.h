//
//  AJNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AJNcsStDeviceInfo : NSObject

+ (NSDictionary *)aJdevice;

+ (NSDictionary *)aJdeviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)aJUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)aJadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)aJgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)aJgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)aJgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)aJgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)aJgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)aJgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)aJgetCPUType;


/**
 App ID
 */
+ (NSString *)aJgetAppID;


/**
 Bundle ID
 */
+ (NSString *)aJgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)aJgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)aJgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)aJgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)aJgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)aJgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)aJisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)aJgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
