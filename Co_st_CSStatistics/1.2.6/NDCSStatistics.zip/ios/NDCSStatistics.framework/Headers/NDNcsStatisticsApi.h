//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "NDNcsStEntryData.h"

@class NDNcsStInitParams;
@class NDNcsStInitParamsMaker;
@class NDNcsStEntryDataMaker;
@class NDNcsStEntry103Maker;
@class NDNcsStEntry19Maker;
@class NDNcsStEntry45Maker;
@class NDNcsStEntry59Maker;
@class NDNcsStEntry101Maker;
@class NDNcsStEntry102Maker;
@class NDNcsStEntry104Maker;
@class NDNcsStEntry105Maker;
@class NDNcsStEntry28Maker;

NS_ASSUME_NONNULL_BEGIN

@interface NDNcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)nDsetup:(NDNcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)nDsetupByBlock:(void(^)(NDNcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * 
 */
+ (NDNcsStInitParams *)nDgetCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/


/// 上传设备捕获信息
+ (void)nDuploadDeviceInfo;
/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)nDupload:(NDNcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)nDuploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)nDuploadCustom:(void(^)(NDNcsStEntryDataMaker *maker)) block;

/// 自定义19协议上传
/// @param isActivity 是否为前台活跃状态
/// @param time 持续时间（仅在isActivity为false时有效）
+ (void)nDupload19:(BOOL)isActivity time:(NSTimeInterval)time;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)nDupload19:(void(^)(NDNcsStEntry19Maker *maker)) block;

/**
 * 上传45协议
 * @param block
 */
+ (void)nDupload45:(void(^)(NDNcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)nDupload59:(void(^)(NDNcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)nDupload101:(void(^)(NDNcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)nDupload102:(void(^)(NDNcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)nDupload103:(void(^)(NDNcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)nDupload104:(void(^)(NDNcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)nDupload105:(void(^)(NDNcsStEntry105Maker *maker)) block;

/**
 * 上传28协议
 * @param block
 */
+ (void)nDupload28:(void(^)(NDNcsStEntry28Maker *maker)) block;

/**
 * 会话 ID，一次冷启动内唯一
 */
+ (NSString *)nDgetSessionId;

/**
 * 会话开始时间，生成会话 ID 时的时间
 */
+ (NSString *)nDgetSessionStartTime;

/**
 * 启动次数，SDK 单独统计
 */
+ (NSInteger)nDgetLaunchCount;

@end

NS_ASSUME_NONNULL_END
