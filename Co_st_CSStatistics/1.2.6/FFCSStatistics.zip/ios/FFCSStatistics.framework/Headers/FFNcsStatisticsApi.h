//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "FFNcsStEntryData.h"

@class FFNcsStInitParams;
@class FFNcsStInitParamsMaker;
@class FFNcsStEntryDataMaker;
@class FFNcsStEntry103Maker;
@class FFNcsStEntry19Maker;
@class FFNcsStEntry45Maker;
@class FFNcsStEntry59Maker;
@class FFNcsStEntry101Maker;
@class FFNcsStEntry102Maker;
@class FFNcsStEntry104Maker;
@class FFNcsStEntry105Maker;
@class FFNcsStEntry28Maker;

NS_ASSUME_NONNULL_BEGIN

@interface FFNcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)fFsetup:(FFNcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)fFsetupByBlock:(void(^)(FFNcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * 
 */
+ (FFNcsStInitParams *)fFgetCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/


/// 上传设备捕获信息
+ (void)fFuploadDeviceInfo;
/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)fFupload:(FFNcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)fFuploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)fFuploadCustom:(void(^)(FFNcsStEntryDataMaker *maker)) block;

/// 自定义19协议上传
/// @param isActivity 是否为前台活跃状态
/// @param time 持续时间（仅在isActivity为false时有效）
+ (void)fFupload19:(BOOL)isActivity time:(NSTimeInterval)time;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)fFupload19:(void(^)(FFNcsStEntry19Maker *maker)) block;

/**
 * 上传45协议
 * @param block
 */
+ (void)fFupload45:(void(^)(FFNcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)fFupload59:(void(^)(FFNcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)fFupload101:(void(^)(FFNcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)fFupload102:(void(^)(FFNcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)fFupload103:(void(^)(FFNcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)fFupload104:(void(^)(FFNcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)fFupload105:(void(^)(FFNcsStEntry105Maker *maker)) block;

/**
 * 上传28协议
 * @param block
 */
+ (void)fFupload28:(void(^)(FFNcsStEntry28Maker *maker)) block;

/**
 * 会话 ID，一次冷启动内唯一
 */
+ (NSString *)fFgetSessionId;

/**
 * 会话开始时间，生成会话 ID 时的时间
 */
+ (NSString *)fFgetSessionStartTime;

/**
 * 启动次数，SDK 单独统计
 */
+ (NSInteger)fFgetLaunchCount;

@end

NS_ASSUME_NONNULL_END
