//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface FFNcsStTest : NSObject

+(void)fFtest;

+(void)fFtestOld;

@end
