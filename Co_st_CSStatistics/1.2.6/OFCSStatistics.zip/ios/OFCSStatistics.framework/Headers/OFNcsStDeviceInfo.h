//
//  OFNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface OFNcsStDeviceInfo : NSObject

+ (NSDictionary *)oFdevice;

+ (NSDictionary *)oFdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)oFUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)oFadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)oFgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)oFgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)oFgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)oFgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)oFgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)oFgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)oFgetCPUType;


/**
 App ID
 */
+ (NSString *)oFgetAppID;


/**
 Bundle ID
 */
+ (NSString *)oFgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)oFgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)oFgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)oFgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)oFgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)oFgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)oFisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)oFgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
