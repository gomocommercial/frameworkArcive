//
//  NCNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface NCNcsStDeviceInfo : NSObject

+ (NSDictionary *)nCdevice;

+ (NSDictionary *)nCdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)nCUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)nCadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)nCgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)nCgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)nCgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)nCgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)nCgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)nCgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)nCgetCPUType;


/**
 App ID
 */
+ (NSString *)nCgetAppID;


/**
 Bundle ID
 */
+ (NSString *)nCgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)nCgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)nCgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)nCgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)nCgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)nCgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)nCisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)nCgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
