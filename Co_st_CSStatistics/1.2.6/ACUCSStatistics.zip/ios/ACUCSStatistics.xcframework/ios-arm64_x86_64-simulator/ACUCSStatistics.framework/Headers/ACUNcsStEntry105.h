//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "ACUNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface ACUNcsStEntry105 : ACUNcsStEntry103


@end
