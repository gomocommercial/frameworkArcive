//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface MGNcsStTest : NSObject

+(void)mGtest;

+(void)mGtestOld;

@end
