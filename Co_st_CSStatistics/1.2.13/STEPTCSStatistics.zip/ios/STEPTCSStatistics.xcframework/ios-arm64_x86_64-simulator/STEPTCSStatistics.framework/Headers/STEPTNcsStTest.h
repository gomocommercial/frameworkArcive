//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface STEPTNcsStTest : NSObject

+(void)sTEPTtest;

+(void)sTEPTtestOld;

@end
