//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "PPP_P_NcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface PPP_P_NcsStEntry105 : PPP_P_NcsStEntry103


@end
