//
//  PPP_P_NcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PPP_P_NcsStDeviceInfo : NSObject

+ (NSDictionary *)pPP_P_device;

+ (NSDictionary *)pPP_P_deviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pPP_P_UDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pPP_P_advertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pPP_P_getCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pPP_P_getDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pPP_P_getDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pPP_P_getAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pPP_P_getAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pPP_P_getiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pPP_P_getCPUType;


/**
 App ID
 */
+ (NSString *)pPP_P_getAppID;


/**
 Bundle ID
 */
+ (NSString *)pPP_P_getBundleId;


/**
 获取当前IP
 */
+ (NSString *)pPP_P_getIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pPP_P_getDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pPP_P_getIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pPP_P_getCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pPP_P_getCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pPP_P_isIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pPP_P_getDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
