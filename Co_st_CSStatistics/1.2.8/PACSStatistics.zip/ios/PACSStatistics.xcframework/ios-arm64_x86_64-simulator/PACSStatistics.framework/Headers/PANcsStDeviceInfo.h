//
//  PANcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PANcsStDeviceInfo : NSObject

+ (NSDictionary *)pAdevice;

+ (NSDictionary *)pAdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pAUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pAadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pAgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pAgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pAgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pAgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pAgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pAgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pAgetCPUType;


/**
 App ID
 */
+ (NSString *)pAgetAppID;


/**
 Bundle ID
 */
+ (NSString *)pAgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)pAgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pAgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pAgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pAgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pAgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pAisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pAgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
