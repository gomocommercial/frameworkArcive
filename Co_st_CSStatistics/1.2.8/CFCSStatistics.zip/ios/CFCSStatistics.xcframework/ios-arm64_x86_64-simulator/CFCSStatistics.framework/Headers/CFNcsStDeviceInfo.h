//
//  CFNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface CFNcsStDeviceInfo : NSObject

+ (NSDictionary *)cFdevice;

+ (NSDictionary *)cFdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)cFUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)cFadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)cFgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)cFgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)cFgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)cFgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)cFgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)cFgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)cFgetCPUType;


/**
 App ID
 */
+ (NSString *)cFgetAppID;


/**
 Bundle ID
 */
+ (NSString *)cFgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)cFgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)cFgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)cFgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)cFgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)cFgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)cFisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)cFgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
