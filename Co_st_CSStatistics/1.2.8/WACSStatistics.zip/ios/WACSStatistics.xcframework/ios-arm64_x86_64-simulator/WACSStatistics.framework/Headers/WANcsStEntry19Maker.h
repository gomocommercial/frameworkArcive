//
// Created by matt on 2019-01-02.
//

#import <Foundation/Foundation.h>


@class WANcsStEntry19Maker;
@class WANcsStEntry19;

typedef WANcsStEntry19Maker *(^DotNSString19)(NSString *);
typedef WANcsStEntry19 *(^DotMake19)(void);
typedef WANcsStEntry19Maker *(^DotBool19)(BOOL);
typedef WANcsStEntry19Maker *(^DotDouble19)(double);

@interface WANcsStEntry19Maker : NSObject


/**
 * 字段21：来源
 */
@property (strong, nonatomic, readonly) DotNSString19 originalLogo;

/**
 * 字段22：真版标识
 */
@property (strong, nonatomic, readonly) DotNSString19 genuineKey;

/**
 * 字段26：IDFA
 */
@property (strong, nonatomic, readonly) DotNSString19 idfa;

/**
 * 构建NcsStEntry19对象
 */
@property (strong, nonatomic, readonly) DotMake19 make;

/// 是否活跃
@property (strong, nonatomic, readonly) DotBool19 isActivity;


/// 总时长，单位秒
@property (strong, nonatomic, readonly) DotDouble19 time;
@end
