//
//  FSPNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface FSPNcsStDeviceInfo : NSObject

+ (NSDictionary *)fSPdevice;

+ (NSDictionary *)fSPdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)fSPUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)fSPadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)fSPgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)fSPgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)fSPgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)fSPgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)fSPgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)fSPgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)fSPgetCPUType;


/**
 App ID
 */
+ (NSString *)fSPgetAppID;


/**
 Bundle ID
 */
+ (NSString *)fSPgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)fSPgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)fSPgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)fSPgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)fSPgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)fSPgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)fSPisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)fSPgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
