//
//  FNBKNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface FNBKNcsStDeviceInfo : NSObject

+ (NSDictionary *)fNBKdevice;

+ (NSDictionary *)fNBKdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)fNBKUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)fNBKadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)fNBKgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)fNBKgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)fNBKgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)fNBKgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)fNBKgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)fNBKgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)fNBKgetCPUType;


/**
 App ID
 */
+ (NSString *)fNBKgetAppID;


/**
 Bundle ID
 */
+ (NSString *)fNBKgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)fNBKgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)fNBKgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)fNBKgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)fNBKgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)fNBKgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)fNBKisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)fNBKgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
