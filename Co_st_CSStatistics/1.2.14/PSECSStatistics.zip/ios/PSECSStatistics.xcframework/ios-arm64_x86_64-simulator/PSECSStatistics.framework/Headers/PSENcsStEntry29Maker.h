//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class PSENcsStEntry29Maker;
@class PSENcsStEntry29;

typedef PSENcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef PSENcsStEntry29 *(^DotMake29)(void);

@interface PSENcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
