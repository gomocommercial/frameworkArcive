//
//  STNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface STNcsStDeviceInfo : NSObject

+ (NSDictionary *)sTdevice;

+ (NSDictionary *)sTdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)sTUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)sTadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)sTgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)sTgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)sTgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)sTgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)sTgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)sTgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)sTgetCPUType;


/**
 App ID
 */
+ (NSString *)sTgetAppID;


/**
 Bundle ID
 */
+ (NSString *)sTgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)sTgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)sTgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)sTgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)sTgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)sTgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)sTisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)sTgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
