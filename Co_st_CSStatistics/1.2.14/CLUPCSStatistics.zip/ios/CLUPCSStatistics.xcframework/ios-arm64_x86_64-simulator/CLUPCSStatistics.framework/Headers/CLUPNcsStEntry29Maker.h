//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>

@class CLUPNcsStEntry29Maker;
@class CLUPNcsStEntry29;

typedef CLUPNcsStEntry29Maker *(^DotNSString29)(NSString *);
typedef CLUPNcsStEntry29 *(^DotMake29)(void);

@interface CLUPNcsStEntry29Maker : NSObject

/**
 * 字段11：token
 */
@property (strong, nonatomic, readonly) DotNSString29 token;

/**
 * 构建NcsStEntry29对象
 */
@property (strong, nonatomic, readonly) DotMake29 make;

@end
