//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "PUSNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface PUSNcsStEntry105 : PUSNcsStEntry103


@end
