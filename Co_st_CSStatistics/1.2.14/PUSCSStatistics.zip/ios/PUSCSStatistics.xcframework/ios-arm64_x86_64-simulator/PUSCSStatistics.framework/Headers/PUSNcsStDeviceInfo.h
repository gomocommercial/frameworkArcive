//
//  PUSNcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface PUSNcsStDeviceInfo : NSObject

+ (NSDictionary *)pUSdevice;

+ (NSDictionary *)pUSdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)pUSUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)pUSadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)pUSgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)pUSgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)pUSgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)pUSgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)pUSgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)pUSgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)pUSgetCPUType;


/**
 App ID
 */
+ (NSString *)pUSgetAppID;


/**
 Bundle ID
 */
+ (NSString *)pUSgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)pUSgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)pUSgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)pUSgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)pUSgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)pUSgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)pUSisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)pUSgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
