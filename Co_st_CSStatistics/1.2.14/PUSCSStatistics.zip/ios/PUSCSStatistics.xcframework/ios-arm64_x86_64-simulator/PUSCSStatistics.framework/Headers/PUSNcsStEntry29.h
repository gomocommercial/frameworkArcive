//
// Created by matt on 2025-01-22.
//

#import <Foundation/Foundation.h>
#import "PUSNcsStEntryData.h"

/**
 * 29协议：GOPUSH推送
 */
@interface PUSNcsStEntry29 : PUSNcsStEntryData

/**
 * 字段11：token
 */
@property (strong, nonatomic) NSString* token;

@end
