//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "AhhhNcsStEntryData.h"

@class AhhhNcsStInitParams;
@class AhhhNcsStInitParamsMaker;
@class AhhhNcsStEntryDataMaker;
@class AhhhNcsStEntry103Maker;
@class AhhhNcsStEntry19Maker;
@class AhhhNcsStEntry45Maker;
@class AhhhNcsStEntry59Maker;
@class AhhhNcsStEntry101Maker;
@class AhhhNcsStEntry102Maker;
@class AhhhNcsStEntry104Maker;
@class AhhhNcsStEntry105Maker;
@class AhhhNcsStEntry28Maker;

NS_ASSUME_NONNULL_BEGIN

@interface AhhhNcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)ahhhsetup:(AhhhNcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)ahhhsetupByBlock:(void(^)(AhhhNcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * 
 */
+ (AhhhNcsStInitParams *)ahhhgetCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/


/// 上传设备捕获信息
+ (void)ahhhuploadDeviceInfo;
/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)ahhhupload:(AhhhNcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)ahhhuploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)ahhhuploadCustom:(void(^)(AhhhNcsStEntryDataMaker *maker)) block;

/// 自定义19协议上传
/// @param isActivity 是否为前台活跃状态
/// @param time 持续时间（仅在isActivity为false时有效）
+ (void)ahhhupload19:(BOOL)isActivity time:(NSTimeInterval)time;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)ahhhupload19:(void(^)(AhhhNcsStEntry19Maker *maker)) block;

/**
 * 上传45协议
 * @param block
 */
+ (void)ahhhupload45:(void(^)(AhhhNcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)ahhhupload59:(void(^)(AhhhNcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)ahhhupload101:(void(^)(AhhhNcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)ahhhupload102:(void(^)(AhhhNcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)ahhhupload103:(void(^)(AhhhNcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)ahhhupload104:(void(^)(AhhhNcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)ahhhupload105:(void(^)(AhhhNcsStEntry105Maker *maker)) block;

/**
 * 上传28协议
 * @param block
 */
+ (void)ahhhupload28:(void(^)(AhhhNcsStEntry28Maker *maker)) block;
@end

NS_ASSUME_NONNULL_END
