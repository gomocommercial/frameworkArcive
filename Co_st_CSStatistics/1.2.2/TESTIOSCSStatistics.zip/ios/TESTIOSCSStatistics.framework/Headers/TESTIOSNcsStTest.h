//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface TESTIOSNcsStTest : NSObject

+(void)tESTIOStest;

+(void)tESTIOStestOld;

@end
