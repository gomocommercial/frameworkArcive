//
//  HONcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
@interface HONcsStDeviceInfo : NSObject

+ (NSDictionary *)hOdevice;

+ (NSDictionary *)hOdeviceForNetworkMonitor;


/// CTTelephonyNetworkInfo 单例
+ (CTTelephonyNetworkInfo *)getTelephonyNetInfo;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)hOUDIDString;

/**
 Apple广告 id
 */
+ (NSString *)hOadvertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)hOgetCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)hOgetDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)hOgetDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)hOgetAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)hOgetAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)hOgetiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)hOgetCPUType;


/**
 App ID
 */
+ (NSString *)hOgetAppID;


/**
 Bundle ID
 */
+ (NSString *)hOgetBundleId;


/**
 获取当前IP
 */
+ (NSString *)hOgetIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)hOgetDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)hOgetIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)hOgetCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)hOgetCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)hOisIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)hOgetDeviceModel;

//获取网路状态
+ (NSString *)getNetType;

@end
