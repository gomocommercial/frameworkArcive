//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "CLUNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface CLUNcsStEntry105 : CLUNcsStEntry103


@end
