//
// Created by matt on 2019-01-02.
//

#import <Foundation/Foundation.h>


@class DGNcsStEntry19Maker;
@class DGNcsStEntry19;

typedef DGNcsStEntry19Maker *(^DotNSString19)(NSString *);
typedef DGNcsStEntry19 *(^DotMake19)(void);
typedef DGNcsStEntry19Maker *(^DotBool19)(BOOL);
typedef DGNcsStEntry19Maker *(^DotDouble19)(double);

@interface DGNcsStEntry19Maker : NSObject


/**
 * 字段21：来源
 */
@property (strong, nonatomic, readonly) DotNSString19 originalLogo;

/**
 * 字段22：真版标识
 */
@property (strong, nonatomic, readonly) DotNSString19 genuineKey;

/**
 * 字段26：IDFA
 */
@property (strong, nonatomic, readonly) DotNSString19 idfa;

/**
 * 构建NcsStEntry19对象
 */
@property (strong, nonatomic, readonly) DotMake19 make;

/// 是否活跃
@property (strong, nonatomic, readonly) DotBool19 isActivity;


/// 总时长，单位秒
@property (strong, nonatomic, readonly) DotDouble19 time;
@end
