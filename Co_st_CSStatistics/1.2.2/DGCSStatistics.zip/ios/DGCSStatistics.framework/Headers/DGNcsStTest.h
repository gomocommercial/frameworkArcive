//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface DGNcsStTest : NSObject

+(void)dGtest;

+(void)dGtestOld;

@end
