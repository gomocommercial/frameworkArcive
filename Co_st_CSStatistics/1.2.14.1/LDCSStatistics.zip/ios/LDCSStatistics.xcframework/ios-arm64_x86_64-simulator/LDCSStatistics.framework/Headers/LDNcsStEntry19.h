//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "LDNcsStEntryData.h"

/**
 * 19协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=6914524
 */
@interface LDNcsStEntry19 : LDNcsStEntryData

/**
 * 字段21：来源
 */
@property (strong, nonatomic) NSString* originalLogo;

/**
 * 字段22：真版标识
 */
@property (strong, nonatomic) NSString* genuineKey;


/**
 * 字段26：IDFA
 */
@property (strong, nonatomic) NSString* idfa;


/// 是否活跃
@property (assign, nonatomic) BOOL isActivity;


/// 总时长，单位秒
@property (nonatomic, assign) NSTimeInterval time;

/**
 字段41: 用户属性
 使用标准json格式上传，包含CAID,AFID等

 格式：
 {
 "afid":"xxxxxxxxxxxxxxxxx",
 "caid":"xxxxxxxxx",
 "gender":"编号", -------------性别（社交产品使用，没有留空即可，编号对照：0-男，1-女，2-第三性别）
 }
 */
@property (nonatomic, strong) NSString *userInfo;

@end
